# 方案 B 实施记录（真实账户、风险与复盘）

> 用途：跨轮次、跨模型续做。每轮只完成一个子阶段，结束时更新本文件「下一步」。
> 续做口令：「读取实施记录，从上次未完成项继续」。
> 位置：`quant_dashboard/quant_dashboard/docs/PLAN_B_IMPLEMENTATION_LOG.md`（未纳入 git，需用户自行决定是否提交）。

## 当前进度

| 阶段 | 状态 | 日期 |
|---|---|---|
| 阶段0 基线 | ✅ 完成 | 2026-10-27 |
| 阶段1A F1 JCS 评价语义 | ✅ 完成（本机演练 ✅、71 项测试通过；真实库迁移在下次启动服务时执行） | 2026-10-27 |
| 阶段1B F2 旧联合回测隔离/时序 | ✅ 完成（本机测试通过；真实行情 v2.1 结果已生成） | 2026-10-28 |
| 阶段1C F5 持久化/备份恢复/CI/deploy | ✅ 完成（本机 13 项通过、真实库备份恢复演练 ✅、CI 已移至仓库根）；远程部署未授权未执行 | 2026-10-28 |
| 阶段2A 现金台账事件模型+导入 | ✅ 完成（本机 42 项通过）；真实交割单试导入待用户择机 | 2026-10-28 |
| 阶段2B 四种收益口径 API/页面 | ✅ 完成（本机 50 项通过；页面标签待用户目视确认） | 2026-10-29 |
| 阶段3A ETF 成分穿透 (F3) | ✅ 完成（本机 62 项通过；成分已刷新 15/16 核验）；证券13 芯片 ETF 无指数权重来源 | 2026-10-29 |
| 阶段3B-1 证券13 成分来源（基金报告持仓替代） | ✅ 完成（本机刷新核验通过：2026-06-30 半年报，54 只，覆盖 99.97%） | 2026-10-29 |
| 阶段3B-2 集中度穿透视角（诊断） | ✅ 完成（本机 71 项通过；两口径对比已取得） | 2026-10-29 |
| 阶段3B-3 风险贡献口径与压力情景 | ✅ 完成（本机 91 项通过；真实持仓情景已取得） | 2026-10-29 |
| 阶段3B-4 穿透与风险页面 | ✅ 完成（本机 cjs 测试通过；页面目视待用户确认） | 2026-10-29 |
| 阶段3B-5 集中度执行口径切换为穿透 | ✅ 完成（本机 97 项通过；真实数据对照已确认） | 2026-10-29 |
| 阶段4A 决定记录与成交关联 | ✅ 完成（本机 40 项通过；路由加载正常） | 2026-10-29 |
| 阶段4B-1 复盘比较（后端） | ✅ 完成（本机 14+43 项通过；真实试算已出结果，待逐只核对） | 2026-10-29 |
| 阶段4B-2 决定/复盘页面 | ✅ 完成（本机 cjs + 41 项通过；页面目视待用户确认） | 2026-10-29 |
| 最终交付物（事实表/复盘示例/未完成清单） | ✅ 完成（`docs/PLAN_B_FINAL_REPORT.md`） | 2026-10-29 |
| 全量测试 | ✅ 1232 通过；方案 B 引起的 1 项已修（复测 5 passed）；其余 2 项为既有问题，已登记 | 2026-10-29 |
| 验收修补（6 项正确性/测试契约） | ✅ 完成（本机离线 1240 通过 / 0 失败 / 0 跳过 / 35 排除；前端 6/6） | 2026-10-29 |

（阶段1 拆成 1A/1B/1C，每轮做一个，以控制额度。）

---

## 阶段0：基线（2026-10-27）

### 0.1 执行环境限制（每轮先看）

- 本会话通过桥接访问用户 Windows 电脑，**没有电脑上的 shell**：不能直接运行 `git status`、`.venv` 中的 pytest 或服务。
- 可行做法：把需要的文件拷到云端容器，在**副本**上修改与测试，再写回电脑。测试在云端独立 Python 环境运行，依赖需另装，与用户 `.venv` 可能有差异，须在报告中说明。
- 写回电脑前必须比对目标文件 mtime，未变化才覆盖（保留用户在此期间的修改）。
- `git status` 以解析 `.git/index` 并比对文件大小/修改时间近似得到，非 git 命令原生输出。

### 0.2 入口、存储与配置

| 项 | 实际位置 | 备注 |
|---|---|---|
| Git 根 | `<仓库根目录>` | 分支 main；最近提交 2026-10-26 08:28 "fix: dashboard snapshot self-heal + factor history concurrent write-safe" |
| 外层工作区 | `<工作区目录>`（另一个 git 仓库） | `.gitignore` 忽略 `quant_dashboard/`，两仓库独立 |
| 应用 | `…\quant_dashboard\quant_dashboard` | FastAPI；入口 `main.py`；Windows 启动 `启动服务器.bat` |
| 主 SQLite | `services/data_lake/alphacore.db`（+WAL） | 由 `services/db/connection.py` 计算：`dirname(dirname(__file__))/data_lake` = `services/data_lake` |
| 根 data_lake | `quant_dashboard/data_lake/` | Parquet/JSON 缓存，Compose 挂载与 backup.sh 覆盖的是这里 |
| 历史遗留 | 应用根 `alpha_core.db`（0 字节，已入 git） | 非主库，勿误用 |
| CI | `quant_dashboard/.github/workflows/ci.yml` | 不在 Git 根 `.github/`，GitHub 不会识别 |
| 部署 | `docker-compose.yml`、`deploy.sh`、`backup.sh`、`restore.bat`、`backup.bat` | |
| 严格 ready 判定 | `services/deployment_readiness.py::evaluate_deployment_readiness` | 已有，deploy.sh 未接入 |

### 0.3 工作区未提交修改（必须保留）

按 index 比对，以下与 HEAD 不同（大小变化，修改时间 2026-10-25～26）——主要是 JCS v27 / 决策控制相关的进行中工作：

- 已修改：`dashboard_modules/decision/jcs.py`、`dashboard_modules/decision/snapshot.py`、`dashboard_modules/decision_engine.py`、`dashboard_modules/market_temp.py`、`dashboard_modules/run_strategies.py`、`services/db/decision.py`、`services/db/connection.py`、`services/db/execution.py`、`routers/decision.py`、`engines/compliance_engine.py`、`decision.html`
- 未跟踪：`services/jcs_validation.py`、`dashboard_modules/decision/controls.py`、`dashboard_modules/decision/quality.py`、`tests/test_decision_framework_v27.py`、`tests/test_jcs_frontend.cjs`、`tests/test_jcs_production_controls.py`、`docs/PROJECT_FOCUS_*_20261026.md`
- 仅抽查了上述关键文件，未对全仓库逐一比对；其他目录可能还有未提交修改。

### 0.4 ⚠ 额外发现：账户隐私文件已纳入 git

以下文件被 git 跟踪（`git ls-files` 等价结果）：`20260521资金股份查询.txt`、`20261022历史成交查询.txt`、`quant_dashboard/20260405资金股份查询.txt`、`quant_dashboard/portfolio_store.json`、`quant_dashboard/trade_history.json`。
外层有「一键推送.bat」。若远端仓库公开或共享，存在账户信息外泄风险。**未读取内容、未改动**；是否 `git rm --cached` 并加入 `.gitignore`、是否需清理远端历史，需用户决定。

### 0.5 F1–F6 核对表

| 编号 | 状态 | 核对依据（当前工作树） |
|---|---|---|
| F1 JCS 评价语义 | **仍存在** | `services/db/decision.py:111 backfill_accuracy` 仍以 `jcs >= 50` 判定看多；`jcs.py` 已新增未提交的 `v27` direction/confidence（`_compute_direction_confidence_v27`，`display_score = 50+50*direction`），但未写入 decision_log，回填未使用 |
| F2 旧联合回测 | **仍存在** | `engines/portfolio_backtest.py:240` 循环中同月 `regime` × 同月 `returns.loc[month]`；`:68` Tushare 失败直接 `_generate_synthetic_returns`（seed=42）；`:131` 缺失资产用 `fallback_annual` 固定收益；结果无数据性质字段；调用方 `routers/aiae.py:662 /portfolio_backtest`、`services/strategy_pipeline.py:569` |
| F3 ETF 成分 | **仍存在** | 快照 `data_lake/industry_index_constituents.json`：retrieved 2026-09-07，15 条权重日 2026-08-31（至今 57 天 > 45 天），1 条 `INDEX_WEIGHT_UNAVAILABLE`；`build_constituent_snapshot` 只保存 `head(top_n)`，`top_n=5`；仅指数权重（`index_weight`），无基金实际持仓。读取层时效校验仍在（应保留）。刷新入口 `refresh_industry_constituents`，调度方待查 |
| F4 收益口径 | **仍存在** | `portfolio_engine.get_nav_history`（:886）用当前持仓权重回放；`trade_import.classify_side`（:279-284）把红利/利息/转账等归为 `cash`，仅 `skipped` 计数；`drawdown.py` 已有风险资产 TWR（成交回滚），复用 |
| F5 持久化/交付 | **仍存在** | DB 在 `services/data_lake`；compose 仅挂 `./data_lake:/app/data_lake`（:38）；`backup.sh:32` 只备份 `${APP_DIR}/data_lake`；CI 文件不在 Git 根；`deploy.sh:113` 接受 `starting`；`:137-138` 带 Key 的 POST `{"value":80}` 只要非 401/403 即算通过（缺必填 `date`，可能是 422） |
| F6 证据不足 | **仍存在（属事实，需保持）** | `config/industry_validation.json passed=false`（OOS 胜率/盈亏比/回撤等闸门未过，point_in_time_universe 未过）；`strategy_runtime.json` MR：BEAR=rejected，BULL/RANGE=insufficient_evidence；多资产仍为启发式（未重读） |

### 0.6 待修问题：调用链、影响、复现、拟改文件

**F1（阶段1A）**
- 调用链：预热/定时 → `dashboard_modules/decision/accuracy.py::backfill_signal_accuracy`（:67，:90/:125 调用）→ `services/db/decision.py::backfill_accuracy` → `decision_log.signal_correct`；展示：`routers/decision.py` `/accuracy`、`/accuracy-dashboard` → `get_accuracy_stats / by_jcs_level / by_regime / rolling / get_shadow_comparison`（:309/:311 同样用 `>=50`）→ `decision.html` 准确率面板。
- `backfill_signal_accuracy` 的上游调度者（warmup_pipeline / main.py）尚未确认。
- 最小复现：六方向全 -1 → JCS=100；设 T+5 收益 -5% → `signal_correct=0`（应为正确）。
- 方案要点：decision_log 新增 `signal_direction`(-1/0/1)、`direction_source`、`eval_horizon_days`、`eval_version`、`model_version`；新记录在写入时保存方向（来自 v27 direction 或 directions 加权符号，取写入时刻值）；回填只评价有方向的记录，`direction=0` 记为不评价；历史无方向记录 `signal_correct=-2`（不可评价）或单独状态列，**不用当前模型重算**；统计接口与影子对比同步；前端说明文案同步。迁移沿用 `migrate_decision_log_v2` 模式（ALTER ADD COLUMN）。
- 拟改：`services/db/connection.py`（迁移）、`services/db/decision.py`、`dashboard_modules/decision/accuracy.py`、写入 decision_log 的调用处（待查）、`routers/decision.py`（如需）、`decision.html` 文案、新增 `tests/test_jcs_accuracy_direction.py`。

**F2（阶段1B）**
- 调用链：`/api/v1/aiae/portfolio_backtest` 与月度自检 → `run_portfolio_backtest` → 写 `portfolio_backtest_results.json`。
- 最小复现：某月各资产收益 10%，仅改该月月末 regime → 当月策略收益 0.17% ↔ 10%。
- 方案要点：第 t 月月末信号只作用于 t+1 月收益；结果加 `data_provenance`（real/estimated/synthetic，按资产按月）；合成回退默认关闭，仅显式 `allow_synthetic=True`（测试/演示）；固定收益填充改为标记缺失并剔除或标 estimated；把 `V5_联合配置` 等重命名/注明为「ETF 持有收益代理」；旧 `portfolio_backtest_results.json` 加失效标记（保留文件，不删除）；API/自检读取时若 provenance 非 real 或版本旧则标注不可作证据。
- 拟改：`engines/portfolio_backtest.py`、`routers/aiae.py`、`services/strategy_pipeline.py`、新增 `tests/test_portfolio_backtest_timing.py`；前端展示位置待查（`strategy.html`/`backtest.html`）。

**F5（阶段1C）**
- 方案要点：统一 DB 路径契约（环境变量 `ALPHACORE_DB_PATH`，默认保持现路径不迁移，compose 增加对应挂载）；backup.sh 增加 SQLite 在线备份（`sqlite3 .backup` 或 Python `Connection.backup`，带 WAL 一致性）与恢复校验脚本（表结构、记录数、decision_evidence/manual_decisions/成交关联）；CI 移至 Git 根 `.github/workflows/` 并设 `working-directory: quant_dashboard`；deploy.sh 只接受 ready 契约（调用 `deployment_readiness`），认证检查改为无副作用的 GET/HEAD 受保护端点或专用 `auth-check`，严格判定 2xx。
- 在副本上演练，不碰真实库；真实部署/迁移标为待执行。

**F3 / F4 / F6**：留待阶段2–3；F6 无需修改，后续只需确保 UI/API 不提升评级。

### 0.7 阶段0 实际做了的检查

- 只读：目录列举、git index 解析、关键源码 grep/阅读、3 个配置/快照 JSON 的字段统计。
- 未运行任何测试或服务；未修改任何项目文件（仅新增本记录）。

---

## 阶段1A：F1 JCS 评价语义（2026-10-27）

### 结果
- F1 已修复（代码层）。原复现在原代码上重现：JCS 全看空、T+5 跌 5% → `signal_correct=0`；修复后 → 1。
- 评价规则（`services/jcs_accuracy.py`，`EVAL_VERSION=jcs-direction-eval-v1`）：写入当日由生产 JCS 各引擎方向按 `_JCS_WEIGHTS` 加权得净方向，|净值|<0.10 记中性；只评价净方向与沪深300 T→T+5 收益符号；中性/持平/无方向不计入。
- 历史记录：迁移把旧 `signal_correct` 转存到 `legacy_signal_correct`，主列置空，`eval_status=legacy_direction_unknown`；**不重算**。之后 `force_recalc` 也无法把它们变回可评价。
- 同日重写保护：已有 T+5 收益的行，方向字段不再被覆盖。
- V4/V6"准确率对比"及"建议切换模型"已停用（同样把分数≥50当看多）。
- 前端：准确率面板增加口径说明与未计入条数；V4/V6 标签页显示停用说明；`simulation.js` 版本号 v52→v53。
- 未改 `jcs.py` 等进入模型指纹的文件（`model_fingerprint` 覆盖 jcs/conflicts/quality/snapshot/action_plan/controls），因此不影响现有证据指纹。

### 修改文件
| 文件 | 变更 |
|---|---|
| `services/jcs_accuracy.py` | 新增：方向推导、评价、口径元数据 |
| `services/db/connection.py` | `migrate_decision_log_v2` 新增 10 列 + 旧判定隔离（幂等） |
| `services/db/decision.py` | upsert 写方向字段并防覆盖；`backfill_accuracy` 按方向评价；`get_accuracy_stats` 增加 `evaluation`/`coverage`/`history[].direction`；`get_shadow_comparison` 停用 |
| `dashboard_modules/decision_engine.py` | `log_daily_decision` 写入方向字段（+3 行） |
| `static/js/decision/simulation.js` | 口径说明、覆盖披露、停用提示 |
| `decision.html` | simulation.js 缓存版本 v53 |
| `tests/test_jcs_accuracy_direction.py` | 新增 8 项回归测试（临时库） |
| `_dev_tools/f1_migration_drill.py` | 新增：真实库只读备份到临时副本→迁移→核对 |

### 检查
- 云端副本 + pytest 9.1.1（Python 3.13，无 fastapi，redis 用测试桩）：新增 8 项全过。
- 相关既有测试 `test_decision_framework_v27 / test_decision_scientific_validation / test_decision_engine / test_v261_infrastructure`：修改前 7 失败/108 通过，修改后 7 失败/116 通过；失败项完全相同，原因均为云端缺模块/配置（fastapi、mean_reversion_engine、vol_regime、行业配置），非本次引入。
- 未能在云端运行：`test_jcs_production_controls.py`、`test_jcs_order_contract.py`（需 fastapi）、`test_jcs_frontend.cjs`（未运行）。
- 迁移演练：云端用合成旧库验证脚本（integrity ok、各表行数不变、旧判定 2/2 转存）。**真实库未演练**（含账户数据，按约束不上传云端）。

### 待用户本机执行（阶段1A 收尾）
```powershell
cd "<项目目录>"
.\.venv\Scripts\python.exe -B _dev_tools\f1_migration_drill.py
.\.venv\Scripts\python.exe -B -m pytest tests/test_jcs_accuracy_direction.py tests/test_jcs_production_controls.py tests/test_jcs_order_contract.py tests/test_decision_framework_v27.py -o addopts="" -q -p no:cacheprovider
```
演练输出 ✅ 后，下次正常启动服务即会对真实库执行迁移（`main.py` 启动调用 `migrate_decision_log_v2`）；建议启动前先手动备份 `services/data_lake/alphacore.db*`。

**本机结果（2026-10-27 11:21，用户执行）**
- 演练：integrity ok；decision_log 6 行，迁移前有判定 3 条（旧判定 2 正确 / 1 错误）→ 全部转存 legacy 列；其余 3 行无 T+5 收益、也无当时方向，后续回填时会标为 legacy；所有表行数不变；✅。
- 测试（用户 .venv，含 fastapi）：`test_jcs_accuracy_direction / test_jcs_production_controls / test_jcs_order_contract / test_decision_framework_v27` 共 71 passed（15 条第三方库弃用警告，非本项目）。
- 结论：阶段1A 本机验证完成。真实库迁移将在用户下次启动服务时执行（尚未发生）。
- 影响：真实库当前 6 条记录全部不可评价，准确率面板将显示"冷启动"，新方向记录需约 5 个交易日后才开始产生评价样本。

### 遗留
- 历史行可否从 `decision_evidence`（写入时的 JCS 结果，含 directions）恢复当时方向：需按日期唯一匹配，未做；当前一律不可评价。
- `NEUTRAL_BAND=0.10` 为本次设定的评价参数，变更需升级 `EVAL_VERSION`。

---

## 阶段1B：F2 旧联合回测（2026-10-27）

### 结果
- 时序偏差已修复并复现确认：旧代码只改 2024-10 月末信号，2024-10 当月收益 0.17% ↔ 10.0%（与评审一致）；新代码两种信号下均为 5.08%（由 2024-09 月末信号决定）。
- 规则（`BACKTEST_VERSION=portfolio-proxy-v2-lagged-signal`）：t 月末 regime/仓位上限只作用于 t+1 月收益；无前月信号的首月不评价；只评价全部 5 只代理 ETF 都有真实收益的**连续**月份（遇缺口截断，不拼接）。
- 合成数据：默认关闭；行情失败返回 `data_unavailable`。仅 `allow_synthetic=True` 时生成，结果 `evidence_grade=synthetic_demo_only`，不写结果文件。
- 固定收益填充（`fallback_annual`）已删除；缺失资产保持缺失。
- 数据性质：结果含 `data_provenance`（逐资产）、`evidence_grade`、`coverage`、`methodology`；`is_performance_evidence` 恒为 False。
- 命名："V5_联合配置"改为 `V5配额_ETF持有代理`，label 标明"ETF 持有收益代理（非子策略实盘）"。
- 收益缓存：只接受带来源记录（`portfolio_backtest_returns.provenance.json`）的缓存；旧 `portfolio_backtest_returns.parquet` 无来源记录 → 忽略（不删除），下次运行时会被带来源的新缓存覆盖。
- 旧结果：`portfolio_backtest_results.json` 未改动；经 `load_backtest_results` 读取时附加 `evidence_status=invalidated_legacy` 与原因。
- 月度自检：只与同版本、真实行情的代理结果比较 Sharpe；旧结果标记为 `backtest_baseline=invalidated_legacy`，不参与；行情不可用时记 ERROR，不合成。
- 前端：未发现页面使用 `/api/v1/aiae/portfolio_backtest`（已检索 strategy/backtest/index/portfolio.html 与 static/js），无需改前端。

### 修改文件
| 文件 | 变更 |
|---|---|
| `engines/portfolio_backtest.py` | 重写：纯函数 `simulate`、滞后信号、来源标注、合成默认关闭、`load_backtest_results` |
| `routers/aiae.py` | `/portfolio_backtest` 改用 `load_backtest_results`；缺文件时只用真实行情（CRLF 保留） |
| `services/strategy_pipeline.py` | 月度自检 Check 2 只比较同版本真实代理结果（CRLF 保留） |
| `tests/test_portfolio_backtest_timing.py` | 新增 9 项回归测试 |

### 检查
- 云端 pytest：新增 9 项通过；相关既有测试（strategy_pipeline/decision 系列/v261/F1）修改前 9 失败 121 通过 → 修改后 9 失败 130 通过，失败项逐条相同（云端缺 fastapi、strategies 包、部分配置）。
- 云端新增 `tushare` 测试桩（仅 scratchpad，不进仓库），所有行情调用均失败。
- 未在真实行情上重新生成结果（云端无 Tushare；也未在用户机运行，以免覆盖结果文件）。

### 待用户本机执行
```powershell
cd "<项目目录>"
.\.venv\Scripts\python.exe -B -m pytest tests/test_portfolio_backtest_timing.py tests/test_strategy_pipeline.py -o addopts="" -q -p no:cacheprovider
```
**本机结果（2026-10-28 23:03，用户执行）**：`test_portfolio_backtest_timing` + `test_strategy_pipeline` 共 16 passed（1 条第三方弃用警告）。云端因缺 `strategies` 包未能运行的 2 项 pipeline 测试在本机通过。真实行情 v2 代理结果尚未生成。

可选：`.\.venv\Scripts\python.exe -B engines\portfolio_backtest.py` 用真实行情生成 v2 代理结果（会覆盖 `portfolio_backtest_results.json`；如需保留旧文件请先复制备份）。

### 1B 补充：真实行情取数修复（2026-10-28）
- 用户本机首次运行 `engines\portfolio_backtest.py`：5 只 ETF 全部失败，按设计返回"真实行情不可用"，未生成合成结果、未覆盖结果文件（用户已先备份为 `portfolio_backtest_results.legacy_20261028.json`）。
- 根因（读取用户 .venv 中 `tushare/pro/data_pro.py` 确认）：`pro_bar(asset='FD', freq='M')` 无对应分支，`data` 未赋值 → 重试 3 次后抛 `IOError('ERROR.')`；且 `adj` 只在 asset='E' 分支生效，基金只能得到未复权价格。
- 推论：旧代码遇到同一异常会走合成收益回退。旧结果期间为 2018-01~2026-05，但 515100 成立于 2020-05-22（10jqka 基金概况页，2026-10-28 查阅），2018 年不可能有真实行情 → 旧结果至少该资产为非真实数据，进一步支持将其标为失效。
- 修复：改用 `fund_daily` × `fund_adj` 自行计算月末复权收益，按年分段请求；缺复权因子时拒绝使用未复权价格（记 `missing_adj_factor`）。版本升为 `portfolio-proxy-v2.1-lagged-signal-adj`（旧 v2 缓存不会被复用）。
- 测试：新增 2 项（分红日复权后不计为亏损、缺复权因子拒绝），共 11 项通过（云端）。
- 风险：`fund_adj` 可能需要更高 Tushare 积分；若权限不足会显示 `missing_adj_factor`。

### 1B 本机真实行情结果（2026-10-28 23:36，用户执行）
- 测试：`test_portfolio_backtest_timing` 11 passed；随后 pytest 清理 `%TEMP%\pytest-of-<用户名>\pytest-current` 报 PermissionError（Windows 临时目录权限，非测试失败）。今后本机命令加 `--basetemp "$env:TEMP\alphacore_pytest"`。
- 取数：5 只 ETF 全部 `real_tushare_fund_daily_x_fund_adj`（fund_adj 权限可用）；515100 自 2020-08 起有月收益。
- 结果已写入 `portfolio_backtest_results.json`（v2.1，research_proxy）；旧文件备份为 `portfolio_backtest_results.legacy_20261028.json`。
- 区间 2020-08~2026-06，71 月；V5 代理 CAGR 7.3% / MDD 8.8% / Sharpe 0.81；等权 8.1% / 12.3% / 0.73；纯红利低波 8.7% / 11.4% / 0.65；纯沪深300 2.9% / 36.5% / 0.24。
- 同平均仓位静态对照（云端由结果文件计算：平均仓位 x%，等权×x% + 现金 x%/年，月度再平衡）：CAGR x% / MDD x% / Sharpe 0.88。V5 相对其月均超额 x%，t≈1.15（n=71），统计上不可区分；超额可能来自偏重红利低波的配额而非择时，未做分解。
- 解读边界：AIAE 阈值/配额可能在同段历史上设定（未核实），属样本内；R1、R5 各仅 4 个月。不作为择时有效性证据，F6 评级不变。

### 遗留
- `aiae_true_history.parquet` 的历史输入是否含事后修订数据未核查（月末取数 + M2 按 t-1 发布规则，其余字段未查）。
- `engines/production_check.check_backtest_results` 读取的是另一产物 `aiae_backtest_v4_results.json`（`engines/aiae_backtest_v4.py`），未核查其时序与合成数据问题，列入后续。
- 交易成本、滑点、申赎/涨跌停未计入代理回测（已在 methodology 声明）。
- **AIAE 月度历史只到 2026-05**（月末信号 102 月），导致回测止于 2026-06；需查 `aiae_true_history.parquet` 更新链路。
- 收益缓存含未完结的当月（2026-10）；当前因无信号未被使用，但信号补齐后可能误用。待修：`_fetch_from_tushare` 排除当前未完结月份。
- 待做：在结果中内置"同平均仓位静态基准"与"配额不变、不择时"基准，分离资产配置与择时贡献。

---

## 阶段1C：F5 持久化、备份恢复、CI、部署（2026-10-28）

### 复核时新增的事实
- `update.sh` 每次更新执行 `docker rm -f` 重建容器；主库在容器内 `/app/services/data_lake`（未挂载），git 又忽略 `data_lake/`（任意层级），服务器代码目录通常没有该库 → **按现配置每次更新后主库可能从空库开始**（远程实际状况未核实）。
- `.dockerignore` 的 `data_lake/` 只匹配构建上下文根目录 → 构建机上若存在 `services/data_lake/alphacore.db`，会被打进镜像；券商账单 txt 也会进入镜像。
- 人工决策库 `data_lake/analysis_decisions.db` 位于挂载卷内，与主库持久化方式不一致；`backup.sh`/`backup.bat` 均直接复制运行中的 SQLite 文件（WAL 模式下可能不一致）。
- `deploy.sh` 健康检查即使失败也继续并打印"部署成功"。`update.sh` 已接入严格 ready 契约（复用，未改动该部分）。

### 修改
| 文件 | 变更 |
|---|---|
| `services/db/connection.py` | `ALPHACORE_DB_DIR` 环境变量覆盖主库目录；未设置时默认不变 |
| `docker-compose.yml` | `ALPHACORE_DB_DIR=/app/data_lake/db`（落在已挂载的 `./data_lake`） |
| `.dockerignore` | 排除任意层级 `data_lake/`、`*.db*`、券商账单 txt |
| `migrate_db_to_volume.sh`（新） | 停旧容器前把容器内主库在线复制到 `./data_lake/db`；已有则跳过、绝不覆盖；integrity_check |
| `deploy.sh` | 停容器前调用迁移；就绪改为轮询 `services.deployment_readiness`（`starting` 不再通过，超时 exit 1）；认证改用无副作用探针并严格判定 401/200，Key 经 `curl -K -` 传入不进进程参数 |
| `update.sh` | `docker rm -f` 前调用迁移，失败则中止且旧容器保持运行 |
| `routers/system.py` | 新增 `POST /api/v1/system/auth_check`（受中间件保护、无读写） |
| `_dev_tools/db_backup.py`（新） | `backup`（sqlite backup API，含 WAL）/`verify`（独立临时目录恢复 + 完整性/表结构/逐表行数与内容哈希/执行单关联）/`restore`（先 verify，默认拒绝覆盖） |
| `backup.sh` | 增加一致性快照 + 恢复校验，失败则备份失败；删除 data_lake 中的原始 SQLite 副本 |
| `backup.bat` | 打包前生成一致性快照并校验 |
| `docs/F5_ci_root_workflow.yml`（新，待用户手动放置） | 仓库根 CI 工作流：`working-directory: quant_dashboard`、`cache-dependency-path`。`.github` 为受保护路径，远程工具无法写入，需用户复制到 Git 根 `.github/workflows/ci.yml` 并删除应用目录下旧文件 |
| `tests/test_db_backup_restore.py`、`tests/test_auth_check_probe.py`（新） | 5 + 3 项 |

### 检查
- 云端 pytest：新增备份/恢复 5 项通过；认证探针 3 项因无 fastapi 跳过（需本机）。相关既有测试修改前 9 失败/137 通过 → 修改后 9 失败/142 通过，失败项逐条相同。
- `deploy.sh` 新就绪/认证段落：用本地模拟服务实际执行 3 种情形——正常通过；`starting` → exit 1；有效 Key 返回 422 → exit 1。
- `migrate_db_to_volume.sh`：用模拟 docker 执行 3 个分支（容器未运行跳过 / 迁移成功且 integrity ok / 再次执行不覆盖）。
- `bash -n` 语法检查：deploy.sh、update.sh、backup.sh、migrate 脚本通过；CI 与 compose YAML 解析通过。
- **未执行**：真实 Docker 构建/部署、远程服务器迁移、GitHub 上 CI 实际运行（未授权；CI 首次运行结果待观察，全量 `pytest tests/` 在 CI 环境能否通过未知）。

### 待用户本机执行
```powershell
cd "<项目目录>"
.\.venv\Scripts\python.exe -B -m pytest tests/test_db_backup_restore.py tests/test_auth_check_probe.py tests/test_deployment_readiness.py -o addopts="" -q -p no:cacheprovider --basetemp "$env:TEMP\alphacore_pytest"
.\.venv\Scripts\python.exe -B _dev_tools\db_backup.py backup --out "$env:TEMP\alphacore_db_drill"
.\.venv\Scripts\python.exe -B _dev_tools\db_backup.py verify --dir "$env:TEMP\alphacore_db_drill"
```
（备份演练只读真实库，快照写在临时目录；输出只含表名与行数。）

**本机结果（2026-10-28 23:50，用户执行）**
- 测试：`test_db_backup_restore / test_auth_check_probe / test_deployment_readiness` 13 passed（4 条第三方弃用警告）。
- 真实库备份演练：main 14 表 1788 行、analysis 2 表 634 行；两库 integrity ok；执行单关联违例 0；决策-快照缺失 0；独立临时目录恢复后表结构/逐表行数与内容哈希一致 ✅。演练快照位于用户 `%TEMP%\alphacore_db_drill`（含账户数据，建议用后删除）。
- CI：用户已将 `docs/F5_ci_root_workflow.yml` 复制到 Git 根 `.github/workflows/ci.yml`，并删除应用目录下旧文件。尚未提交/推送，GitHub 上首次运行结果待观察。

### 远程部署时（需用户授权后执行）
1. 先在服务器 `docker exec quant_dashboard_app ls -la /app/services/data_lake/` 确认容器内主库现状。
2. 用 `update.sh` 正常更新即可：它会先调用迁移脚本，再重建容器。
3. 更新后在服务器执行 `python3 _dev_tools/db_backup.py backup/verify` 一次，确认 `data_lake/db/alphacore.db` 中 decision_log/decision_evidence 行数。

### 遗留
- Git 仓库跟踪的账单/持仓文件（见 0.4）仍在 git 中；`.dockerignore` 只阻止进入镜像，不影响 git 与远端。
- 应用根 `portfolio_store.json`、`trade_history.json` 的持久化路径（update.sh 迁到 data_lake）未逐一核对读取方。
- `backup.bat` 仍压缩整个仓库目录（含 .venv），未优化。

---

## 阶段2A：整账户现金台账（2026-10-28）

### 现状核对
- 成交导入 `services/trade_import.py`：成交台账 `data_lake/trade_ledger.json` 已按 key 幂等去重；红利/利息/转账/逆回购行只计数丢弃；"银行转证券/证券转银行"写法无法识别（进 errors）；无证券代码的银证转账行被当作"代码无法解析"。
- 资金股份查询导入 `portfolio_engine.import_from_txt` 覆盖写 `portfolio_store.json`，历史余额快照不保留 → 无法做期间现金对账。
- 未读取任何真实账单内容（隐私约束）；列名来自现有 `COLUMN_ALIASES`。

### 实现
| 文件 | 变更 |
|---|---|
| `services/account_ledger.py`（新） | 现金事件模型与只追加台账 `data_lake/account_ledger.json`：settlement / deposit / withdrawal / dividend / interest / tax / fee / repo / unclassified；更正 corrections（void/replace，原事件不改）；余额快照 snapshots；`summarize`、`reconcile_cash`、`investment_pnl`、`cash_coverage_ok` |
| `services/trade_import.py` | ParseResult 增加 `cash_rows`、`has_net_amount`；资金类行（含无代码的银证转账）保留给现金台账；识别"银行转证券/证券转银行"；`import_trade_file` 与 `scan_import_folder` 同步写现金台账（失败不回滚成交台账，但在返回中可见） |
| `engines/portfolio_engine.py` | `import_from_txt` 后追加余额快照（`as_of` = 导入日期，已在来源中注明非券商导出时点）；失败仅告警 |
| `tests/test_account_ledger.py`（新） | 11 项，合成交割单 |

### 规则
- 事件键：成交 = `settle:` + 成交台账 key 指纹（与成交台账去重一致）；资金行 = 行内容指纹 + 同文件相同行序号 → 重复导入、区间重叠的不同导出均不重复记账，同日真实重复的两笔红利保留两笔。
- 成交现金：有"发生金额"直接采用（已含费用）；否则 ∓成交金额 − 费用；费用也缺 → `cash_estimated`/`fees_unknown`。
- 现金覆盖：只有含"发生金额"列的导出算覆盖；覆盖区间 = 文件内最早~最晚行日期（保守：查询区间末尾无记录的日子视为未覆盖）。
- 对账：期初余额 + 区间事件 = 期末余额；`reconciled`（容差 1 元）/ `unexplained_difference` / `insufficient_cash_coverage`（不把差额当盈亏或错误）。
- 投资损益 = 期末总资产 − 期初总资产 − 净入出金。
- 不记录资金账号/股东代码。`account_ledger.json` 位于 data_lake（git 忽略、容器挂载、backup.sh 覆盖）。

### 检查
- 云端：新增 11 项 + 既有 `test_trade_import` 12 项通过；相关既有测试修改前 12 失败/112 通过 → 修改后 12 失败/123 通过，失败项逐条相同（云端缺 trailing_stop/strategies 等模块）。
- `portfolio_engine` 钩子仅做语法检查，未在云端运行（依赖多）；需本机验证。
- 关键性质对应：1→`test_deposits_are_not_investment_pnl`；2→`test_reimport_and_overlapping_export_are_idempotent`；3→`test_trade_fees_not_double_counted`、`test_events_typed_and_signed`；4→`test_reconcile_with_broker_balance`、`test_trade_only_export_has_no_cash_coverage`。

### 待用户本机执行
```powershell
cd "<项目目录>"
.\.venv\Scripts\python.exe -B -m pytest tests/test_account_ledger.py tests/test_trade_import.py tests/test_drawdown.py -o addopts="" -q -p no:cacheprovider --basetemp "$env:TEMP\alphacore_pytest"
```
**本机结果（2026-10-28 23:58）**：`test_account_ledger / test_trade_import / test_drawdown` 共 42 passed（含云端无法运行的 drawdown 测试）。

真实账单试导入（只在本机，输出只含计数）：在页面或现有导入入口照常导入一份**交割单/资金流水**（含"发生金额"列）；`20261022历史成交查询.txt` 这类历史成交导出没有资金列，只会产生估算交收事件。

### 遗留
- 已导入过的历史文件不会自动补记现金事件（成交台账按文件哈希跳过已扫描文件）；需要时重新上传或提供一次性回填脚本（2B 前评估）。
- 公司行为（送转、拆分、ETF 份额折算）尚未建模；本次只处理现金。
- 余额快照 `as_of` 用导入日期；若补导旧的资金股份查询会错配日期，后续可从文件头或文件名取日期。
- 通达信"历史成交"只能导出 60 天（用户已说明），交割单的可导出范围未知。

---

## 阶段2B：四种收益口径（2026-10-29）

### 现状核对
- `/portfolio/nav`（`get_nav_history`）用当前持仓权重回放；组合页标题已写"模拟净值（假设持仓不变）"，但 API 无口径字段。另发现两处数据处理问题并复现：①缺失日收益用 `ffill` 前向填充（把前一日涨跌复制成虚构收益）；②沪深300基准取末尾 N 条而非按日期对齐。人工数据下旧实现终值 1.331 / 基准 [1.1,1.1,1.1]，修正后 1.2705 / [1,1,1]。
- `drawdown.monitor`：`realized` 为风险资产 TWR（成交回滚），`proforma` 为当前持仓回看；决策页标为"实盘"，未说明不含现金。
- `/portfolio/snapshots`（每日快照）总资产 = 当日收盘估值 + 最近一次导入的现金，非券商确认；前端未使用，未改动，**不用于整账户收益**。
- 未找到简报/归因直接引用上述净值做收益结论的代码路径（`brinson`、`report_generator` 未逐一深查，列入遗留）。

### 实现
| 文件 | 变更 |
|---|---|
| `services/return_basis.py`（新） | 口径目录 `BASES`（account_total_actual / risk_asset_twr / current_holdings_simulation / strategy_backtest，含 is_actual_history / includes_cash / external_flows_handled）；`twr_chain`、`modified_dietz`、`xirr`；`account_returns`（券商总资产快照 + 现金台账入出金） |
| `engines/portfolio_engine.py` | `get_nav_history` 全部返回带口径字段；去除收益 ffill（缺失按 0 计并返回 `missing_return_cells`）；基准按交易日对齐 |
| `services/drawdown.py` | `realized` 标 `risk_asset_twr`，`proforma` 标 `current_holdings_simulation` |
| `engines/portfolio_backtest.py` | 结果标 `strategy_backtest` |
| `routers/portfolio.py` | 新增 `GET /api/v1/portfolio/returns`：整账户收益 + 四口径目录 |
| `portfolio.html`、`static/js/portfolio_manager.js` | 标题改"当前持仓历史模拟 · 非真实历史业绩"；覆盖率标签显示缺失日收益个数与口径；JS 版本 v41 |
| `static/js/decision/trailing_stop_panel.js`、`decision.html` | 回撤区"实盘高水位"→"风险资产高水位 · 风险资产 TWR（不含现金）"；"当前持仓回看（模拟）"；JS 版本 v9 |
| `tests/test_return_basis.py`（新） | 9 项 |

### 整账户收益规则
- 估值：只用券商总资产快照（资金股份查询导入，as_of = 导入日）。少于 2 个 → `insufficient_valuations`。
- 外部资金流：现金台账 deposit/withdrawal；区间无现金覆盖 → `insufficient_cash_coverage`。
- TWR：每个入出金日都有快照 → 精确连乘；否则 Modified Dietz 近似并标 `twr_method=modified_dietz_approx`。约定入出金计入当日估值。
- MWR：XIRR 年化。投资损益 = 期末 − 期初 − 净入出金。

### 检查
- 云端：新增 9 项通过；相关既有测试（含 drawdown、trade_import、account_ledger 等）修改前 8 失败/116 通过 → 修改后 8 失败/136 通过，失败项逐条相同（云端缺 strategies 模块与部分配置）。云端用 `data_manager` 测试桩以实例化 PortfolioEngine（不进仓库）。
- 新旧对照：`get_nav_history` 数值修正已用人工数据对比旧代码确认（见上）。
- 未验证：页面实际渲染（无浏览器运行）；`/portfolio/returns` 端点经 FastAPI 的调用（云端无 fastapi）。

### 待用户本机执行
```powershell
cd "<项目目录>"
.\.venv\Scripts\python.exe -B -m pytest tests/test_return_basis.py tests/test_drawdown.py tests/test_account_ledger.py tests/test_portfolio_backtest_timing.py -o addopts="" -q -p no:cacheprovider --basetemp "$env:TEMP\alphacore_pytest"
```
**本机结果（2026-10-29 00:07）**：`test_return_basis / test_drawdown / test_account_ledger / test_portfolio_backtest_timing` 共 50 passed。

启动服务后可打开组合页、决策页确认标签；浏览器访问 `/api/v1/portfolio/returns` 查看整账户收益状态（目前预计为 insufficient_*，因为尚无两次以上带总资产的快照和交割单覆盖）。

### 遗留
- 整账户日度净值曲线（每日 = 风险资产市值 + 台账现金）未实现；需台账现金覆盖连续后再做。
- `brinson_engine`、`report_generator`、`narrative_engine` 中如引用收益，尚未接入口径字段。
- `/portfolio/snapshots` 为系统估算估值，后续可标口径或停用。

---

## 阶段3A：ETF 成分穿透（F3，2026-10-29）

### 现状核对（F3 仍存在）
- 快照 `data_lake/industry_index_constituents.json` 仍为 2026-09-07 获取、权重日 2026-08-31（至 10-29 为 59 天 > 45 天）；1 条 `INDEX_WEIGHT_UNAVAILABLE`。
- 更新链路：`main.py` 每周六 08:30 定时任务依次执行 `refresh_existing_industry_universe → refresh_industry_constituents → 验证`，同一 try 块，前一步异常则成分不刷新；或该时段服务未运行。具体原因需看本机日志（未拷贝日志，含账户金额）。
- `build_constituent_snapshot` 只保存前 `constituent_top_n=5`；记录仅为跟踪指数权重，未区分基金实际持仓；无任何"ETF 成分 + 直接持股"合并计算。
- 研究标签与正式名称可能不一致：如 证券16 研究标签"算力/AI基建"，正式名称"华宝中证信息技术应用创新产业ETF"，跟踪 指数02 中证信创。
- 研究池只有 16 只 ETF；研究池外的实际持仓 ETF 无成分来源。

### 实现
| 文件 | 变更 |
|---|---|
| `services/industry_constituents.py` | 快照 schema 2：保留全部成分 `constituents`（`top_constituents` 仍为前 N，兼容旧接口）；`weight_coverage_pct`、`exposure_basis=tracking_index_weight`、`fund_holdings_available=False`、`membership`；读取时过期/未核验同时清空完整成分；旧 schema 1 快照标 `constituents_complete=False`；刷新时合并 `config/lookthrough_extra_etfs.json` 中**带出处**的持仓 ETF（不改动冻结的研究池） |
| `config/lookthrough_extra_etfs.json`（新） | 空模板：研究池外持仓 ETF 的跟踪指数登记处，必须填 source（基金合同/招募说明书，查阅日期） |
| `services/lookthrough.py`（新） | `build_lookthrough`：直接持股 + ETF×指数权重 → 公司暴露（按 ts_code 合并，标记重叠）、行业暴露（本地 stock_list 行业字段，缺失记"行业未知"）；未知暴露单列（成分过期/缺失、权重覆盖 <100%、不支持品种）；现金单列；每只 ETF 返回正式名称、跟踪指数、研究标签、权重日期、核验状态 |
| `routers/portfolio.py` | 新增 `GET /api/v1/portfolio/lookthrough` |
| `tests/test_lookthrough.py`（新） | 11 项 |

### 检查
- 云端：新增 11 项 + 既有 `test_industry_constituents` 5 项通过；相关既有测试修改前 3 失败/83 通过 → 修改后 3 失败/94 通过，失败项相同。`test_compliance_engine`、`test_correlation_concentration` 在云端因缺 `audit_engine` 无法收集，需本机运行。
- 性质 5 → `test_same_company_merged_across_etfs_and_direct_holding`；性质 6 → `test_stale_or_missing_constituents_are_unknown_not_zero`、`test_partial_weight_coverage_residual_is_unknown`、`test_legacy_top_n_snapshot_is_marked_incomplete`。
- 未执行：真实 Tushare 成分刷新（云端无行情权限）；穿透接口对真实持仓的输出（含账户数据，只在本机）。

### 待用户本机执行
```powershell
cd "<项目目录>"
.\.venv\Scripts\python.exe -B -m pytest tests/test_lookthrough.py tests/test_industry_constituents.py tests/test_compliance_engine.py tests/test_correlation_concentration.py -o addopts="" -q -p no:cacheprovider --basetemp "$env:TEMP\alphacore_pytest"
# 刷新成分 (只打印汇总, 不打印权重):
.\.venv\Scripts\python.exe -B -c "from services.industry_constituents import refresh_industry_constituents as r; s=r(); print('as_of', s['as_of'], 'schema', s['schema_version']); [print(x['etf_code'], x['is_verified'], x['as_of'], len(x['constituents']), x['weight_coverage_pct'], x['issues']) for x in s['records']]"
# 查定时刷新为何停止 (只显示匹配行):
Select-String -Path logs\*.log -Pattern "行业ETF主数据周度校验异常" | Select-Object -Last 5
```
**本机结果（2026-10-29 00:14）**
- 测试：`test_lookthrough / test_industry_constituents / test_compliance_engine / test_correlation_concentration` 62 passed（含云端无法收集的两个文件）。
- 成分刷新：快照 schema 2，as_of 2026-10-29；15/16 只 ETF 核验通过，权重日 2026-09-30（30 天，≤45 天），完整成分 19~100 只/ETF，权重覆盖 99.99%~100%。
- **证券13（国泰CES半导体芯片，跟踪 990001.OTH 中华半导体芯片）`INDEX_WEIGHT_UNAVAILABLE`**：Tushare `index_weight` 无该 CES 指数权重。半导体是用户主要研究方向，该 ETF 若为实际持仓，其暴露在穿透中整体显示为未知。需另找来源（基金定期报告前十大持仓 `fund_portfolio`、或中华交易服务/CES 官方成分）——列为 3B 前置事项。
- 日志检索"行业ETF主数据周度校验异常"无匹配：定时任务未因该异常失败；更可能是周六 08:30 服务未运行（本机间歇运行），或日志已轮转。原因未最终确定。

刷新会覆盖 `data_lake/industry_index_constituents.json`（公开指数数据，非账户数据）。之后启动服务，浏览器打开 `/api/v1/portfolio/lookthrough` 查看已知/未知占比。

### 遗留
- 研究池外持仓 ETF（如[名称已脱敏]类）需在 `lookthrough_extra_etfs.json` 登记经核对的跟踪指数后才能穿透；未登记前显示为未知。
- 基金实际持仓（季报/半年报，`fund_portfolio`）未接入；当前仅指数权重近似。
- 产业链环节（设计/制造/设备/材料等）映射未建立；行业依赖 stock_list 是否含 industry 字段。
- `concentration.py` / `compliance_engine.py` 现有主题集中度仍按名称/关键词归类，未改为使用穿透结果（3B 处理）。
- 穿透结果的页面展示未做（3B 与风险面板一起做）。
- 定时任务把多个刷新放在同一 try 块，前一步失败会阻断成分刷新（日志未见该异常，暂不改）。本机间歇运行时周任务可能错过：考虑启动时若快照超过 max_age 则补刷新。
- 证券13 芯片 ETF 无指数权重来源（见上）。

---

## 阶段3B-1：证券13 成分来源（2026-10-29）

用户要求顺序：先补 证券13 成分来源，再做集中度、风险贡献、压力情景、穿透页面。3B 拆为 4 轮。

### 来源核对
- 证券13 全称"国泰CES半导体芯片行业交易型开放式指数证券投资基金"，成立 2019-05-16，跟踪中华交易服务半导体芯片行业指数（同花顺基金概况 basic.10jqka.com.cn/证券13/summary.html，2026-10-29 查阅）。
- 未找到可程序化获取的该指数完整成分权重公开来源；Tushare `index_weight` 无 990001.OTH。
- Tushare `fund_portfolio`：公募基金持仓，季度更新；字段 ts_code/ann_date/end_date/symbol/mkv/amount/stk_mkv_ratio/stk_float_ratio（tushare.pro/document/2?doc_id=121，2026-10-29 查阅）。文档未说明季报是否仅前十大；按中国基金季报惯例通常只披露前十大，故未披露部分计为未知。积分要求以用户账户实际调用结果为准。

### 实现
- `services/industry_constituents.py`：ETF **仅因** `INDEX_WEIGHT_UNAVAILABLE` 失败时，刷新会对其调用 `fund_portfolio`（近 400 天），用最新**已公告**报告期（`ann_date ≤ 参考日`，避免未来信息）构建成分；同期同股票取最新公告。记录标 `exposure_basis=fund_reported_holdings`、`fallback_from`、`reported_ann_date`、`max_age_days=136`。校验：≥5 只、比例为正、合计 0~105%、报告期末距参考日 ≤136 天，否则 `FUND_HOLDINGS_*` 不核验。读取时按记录自身 max_age 复核时效。
- 时效规则说明：136 天 = 一个季度 + 45 天公告滞后，是基金报告的发布节奏；指数权重 45 天阈值未改变。
- `services/lookthrough.py`：基金报告未披露部分记 `FUND_HOLDINGS_UNDISCLOSED_REMAINDER` 未知；每只 ETF 返回 `exposure_basis` 与 `reported_ann_date`；说明文字改为逐 ETF 口径。
- 权重含义：`stk_mkv_ratio` 为占基金股票市值比例，近似作为占 ETF 价值比例（ETF 股票仓位通常接近满仓，未精确扣除现金）。

### 检查
- 云端：`test_lookthrough` 17 项（新增 6 项：仅缺指数权重时启用、未披露余量为未知、公告前不可用、过期与按记录时效复核、同股取最新公告、刷新流程只对缺权重 ETF 调基金持仓）+ `test_industry_constituents` 5 项通过。
- 未执行：真实 `fund_portfolio` 调用（权限/返回条数待本机确认）。

### 其他
- 设备上的实施记录曾被回退到 3A 写入前的版本（mtime 晚于写入，内容仅缺本工具写入段落），已在当前版本上补回。疑为编辑器打开该文件后自动保存。

### 待用户本机执行
```powershell
cd "<项目目录>"
.\.venv\Scripts\python.exe -B -m pytest tests/test_lookthrough.py tests/test_industry_constituents.py -o addopts="" -q -p no:cacheprovider --basetemp "$env:TEMP\alphacore_pytest"
.\.venv\Scripts\python.exe -B -c "from services.industry_constituents import refresh_industry_constituents as r; s=r(); x=[i for i in s['records'] if i['etf_code']=='证券13'][0]; print(x['exposure_basis'], x['is_verified'], x['as_of'], x.get('reported_ann_date'), len(x['constituents']), x['weight_coverage_pct'], x['issues'])"
```

**本机结果与修正（2026-10-29 00:23）**
- 测试 22 passed。
- 首次真实刷新：证券13 取到最新报告期 2026-09-30（公告 2026-10-27），但返回不足 5 行 → `FUND_HOLDINGS_COUNT_TOO_SMALL`，未核验。推测为季报刚公告、数据源尚未收录完整（未核实）。
- 修正：从最新已公告报告期往前取第一个通过校验的期次（例如 6-30 半年报），跳过的期次及原因记入 `skipped_periods`，并加信息项 `FUND_HOLDINGS_NEWER_PERIOD_SKIPPED`；更早期次超时效即停止。新增 2 项测试，云端 24 passed。待本机重跑刷新。

**第二次本机刷新（2026-10-29 00:26）与修正**
- 结果：9-30 期仅 2 行（跳过）；6-30 期 88 行但因个别行占比无效整期被否（`FUND_HOLDINGS_VALUE_INVALID`）；3-31 期 15 行且已超时效。
- 修正：无效占比行（缺失/≤0）逐行剔除并计数（`dropped_rows`、信息项 `FUND_HOLDINGS_ROWS_DROPPED`），剔除部分在穿透中计为未知；有效行 <5 才否决该期。新增 2 项测试，云端 26 passed。待本机第三次刷新确认。

**第三次本机刷新（2026-10-29 00:28）——通过**
- 证券13：`fund_reported_holdings`，is_verified=True，报告期 2026-06-30（公告 2026-08-31），54 只，占股票市值合计 99.97%。
- 剔除 34 行（均为占比 0，无缺失值）；剔除后覆盖仍 99.97%，影响可忽略。推测为四舍五入为 0 的零星持仓（如新股中签），未核实。
- 9-30 期仅 2 行被跳过；数据源收录完整后再次刷新会自动切换。
- 注意：此口径为 4 个月前的报告期持仓，与其余 15 只的指数权重（2026-09-30）口径、时点不同，穿透结果逐 ETF 标注。

---

## 阶段3B-2：集中度的穿透视角（2026-10-29）

### 现状核对
- `services/concentration.py` 主题集中度：ETF 按**名称关键词**整只归入单一主题，个股按 stock_basic 行业映射；阈值 40%/60%（`strategy_runtime.json → concentration` 可覆盖）。
- `engines/compliance_engine.py` 主题集中度规则（>40% 禁止新增，>60% 硬阻断）调用同一 `classify_theme`；规则说明却写"含 ETF 穿透归类"，与实现不符。
- 前端 `static/js/renderers.js` 渲染 `ps.concentration`（来自某个未拷贝的生产者模块，本轮未追到；`concentration.py` 在已拷贝代码中仅被 compliance_engine 引用）。

### 决策：执行口径不变，穿透仅作复核
把归类改为穿透会改变"禁止新增/硬阻断"的触发，属风控规则变更，需用户授权；本轮不改执行等级与阈值，不新增单一公司等阈值。

### 实现
| 文件 | 变更 |
|---|---|
| `services/concentration.py` | 新增 `lookthrough_view`（持仓 → 公司 → 行业 → 与关键词口径同一 `INDUSTRY_THEME_MAP` 的主题；未知单列不分摊；前 10 公司及其来源/重叠；每只 ETF 口径与日期）；新增 `explain`（触发原因、归类依据占比、数据可信度、应复核事项，描述性，不判定）；`compute_from_store` 附加 `lookthrough`、`explain`（穿透失败显式记 error）；`summarize` 带出精简版 |
| `engines/compliance_engine.py` | 规则说明改为"ETF 按名称关键词整只归类, 个股按行业"（行为不变） |
| `tests/test_concentration_lookthrough.py`（新） | 4 项 |

### 检查
- 云端：新增 4 项通过；相关既有测试修改前 3 失败/63 通过 → 修改后 3 失败/88 通过，失败项相同。`test_compliance_engine`、`test_correlation_concentration` 需本机运行。
- 设备上实施记录再次被回退（3B-1 完成段落丢失，mtime 晚于写入），已补回。请在编辑器中关闭该文件。

### 待用户本机执行
```powershell
cd "<项目目录>"
.\.venv\Scripts\python.exe -B -m pytest tests/test_concentration_lookthrough.py tests/test_compliance_engine.py tests/test_correlation_concentration.py tests/test_lookthrough.py -o addopts="" -q -p no:cacheprovider --basetemp "$env:TEMP\alphacore_pytest"
# 只看两种口径的主题对比与未知占比 (不打印持仓金额):
.\.venv\Scripts\python.exe -B -c "from services.concentration import compute_from_store as c; r=c(); print('关键词口径:', r.get('top_theme'), r.get('top_pct'), r.get('level')); lv=r.get('lookthrough',{}); print('穿透已知%', lv.get('known_pct_of_invested'), '未知%', (lv.get('unknown') or {}).get('pct_of_invested')); [print(' ', t['theme'], t['pct_of_invested']) for t in lv.get('themes',[])[:6]]; [print(' *', x) for x in r.get('explain',{}).get('review_items',[])]"
```

**本机结果（2026-10-29 00:33）**
- 测试：71 passed（含 compliance / correlation_concentration）。
- 关键词口径：最大主题"半导体电子"占权益 x%，level=danger（执行等级未变）。
- 穿透口径：可识别 x%，未知 x%；可识别部分中"半导体电子"占持仓 x%，其余主题均 ≤x%。
- x% 市值按 ETF 名称关键词整只归类。
- 成分未核验、整只计入未知的 ETF：证券10、证券11、证券12（均不在研究池，未在 `lookthrough_extra_etfs.json` 登记）。
- 解读（事实）：即使只看可识别部分，半导体电子也已占持仓过半；未知 x% 的实际构成无法确认。两口径都显示高度集中，穿透未改变"集中"的判断，只是让可识别与不可识别部分分开可见。

### 待用户决定
- 是否把合规层主题集中度的执行依据从"名称关键词"切换为"穿透结果"（未知部分如何计入需同时决定）。

### 遗留
- 定位 `ps.concentration` 的生产者并在页面展示 `explain`（3B-4）。

---

## 阶段3B-2b：登记 3 只研究池外持仓 ETF（2026-10-29）

| 代码 | 正式名称 | 跟踪指数 | 指数代码（Tushare 格式） | 出处 |
|---|---|---|---|---|
| 证券10 | [名称已脱敏] | [名称已脱敏] | 指数01 | 天天基金基金档案；中证指数官方指数单张（样本 40，半年调样） |
| 证券11 | [名称已脱敏] | [名称已脱敏] | 指数03（后缀推定） | 天天基金基金档案；国证指数官网编制方案文件名 gz_指数03（正文未能读取）及媒体报道 |
| 证券12 | [名称已脱敏] | [名称已脱敏] | 指数04 | 天天基金基金档案；中证指数官方指数单张（样本 50） |

- 写入 `config/lookthrough_extra_etfs.json`（每条含 source 与查阅日期 2026-10-29）；`_with_extra_holdings` 云端读取校验通过。
- 指数03 依据较弱（官方 PDF 被 robots 拒绝），已在 source 注明；若 Tushare 无该指数权重，刷新会自动改用基金报告持仓。
- 设备上实施记录第三次被回退（3B-2 本机结果段落丢失），已补回。
**本机刷新结果（2026-10-29 00:38）**
- 证券10、证券11、证券12：`holding_extra`，均以 `tracking_index_weight` 核验通过，权重日 2026-09-30，成分 40 / 30 / 50 只，覆盖 ≈100%（指数03 代码在 Tushare 可用，推定成立）。
- 证券13：仍为 `fund_reported_holdings`（2026-06-30，54 只）。
- 集中度穿透视角：可识别 x%，未知 x%（上轮 x%）。主题占持仓：半导体电子 x%、电力设备新能源 x%、化工原料 x%、医药医疗 x%、机器人智能制造 x%、软件互联网 x%。关键词口径同主题 x%（占权益）。
- 25 家公司同时出现在多只 ETF 或直接持股中。
- 解读（事实）：两口径差约 3 个百分点，穿透确认持仓高度集中于半导体电子；差额来自 ETF 成分中的非半导体公司（如[名称已脱敏] 的其他行业成分）。注意 证券13 成分为 6 月末时点。

## 阶段3B-3：风险贡献口径与压力情景（2026-10-29）

### 现状核对
- `services/portfolio_vol.py` 已有：250 日等权波动 + 收缩相关、风险贡献 `risk_share`、`data_quality`（覆盖率/代理权重/过期权重/价格日期/最少样本）、历史回放、β 线性压力（沪深300 x%、[名称已脱敏] x%/x%、连续跌停）。缺：样本窗口起止日期、价格来源与复权状态说明、压力结果"条件估计"标注；压力不使用穿透暴露。
- `/portfolio/stress-test` 为 AIAE 各档调仓模拟（rebalance_engine），与本轮产业冲击不同，不重复建设。

### 实现
| 文件 | 变更 |
|---|---|
| `services/portfolio_vol.py` | 结果新增 `risk_basis`（估计方法、窗口交易日、样本起止日、收缩强度、价格来源 `data_lake/daily_prices`、复权状态"未标注 + 异常跳变剔除阈值"、代理规则与比例、过期比例、"非未来波动保证"）；β 压力每项加 `nature`（条件估计、非预测）。计算口径未改 |
| `services/stress_lookthrough.py`（新） | 以穿透主题暴露施加显式主题冲击：估值压缩（半导体电子 -30%、软件互联网 -25%、其余权益 -10%）、产业需求下降（半导体电子 -25%、电力设备新能源/机器人 -10%、其余 -5%）、相关性上升（全部权益 -20%）。参数为**示例假设、未校准**，可在 `strategy_runtime.json → stress_lookthrough.scenarios` 覆盖；未知暴露给区间（情景内最轻~最重冲击），现金 0 冲击；输出主题与公司损失前 5、局限说明 |
| `routers/portfolio.py` | 抽出 `_compute_lookthrough`；新增 `GET /api/v1/portfolio/stress-lookthrough` |
| `services/industry_constituents.py` | `_with_extra_holdings` 路径改为调用时解析（修复测试读取真实登记文件导致的失败） |
| `tests/test_stress_lookthrough.py`（新 5 项）、`tests/test_risk_basis.py`（新 1 项）、`tests/test_lookthrough.py`（隔离修正） | |

### 检查
- 云端：新增 6 项通过；相关既有测试修改前 3 失败/40 通过 → 修改后 3 失败/71 通过（含 lookthrough/concentration 新测试），失败项相同。`test_vol_overlay` 云端缺 `services.vol_regime` 无法收集，需本机运行。
- 发现并修复：上轮登记 3 只 ETF 后，`test_refresh_calls_fund_portfolio_only_for_missing_index` 会读到真实登记文件而失败（本机也会失败）。
- 设备上实施记录第四次被回退，已补回。

### 待用户本机执行
```powershell
cd "<项目目录>"
.\.venv\Scripts\python.exe -B -m pytest tests/test_stress_lookthrough.py tests/test_risk_basis.py tests/test_lookthrough.py tests/test_vol_overlay.py tests/test_concentration_lookthrough.py -o addopts="" -q -p no:cacheprovider --basetemp "$env:TEMP\alphacore_pytest"
# 压力情景 (只打印百分比, 不打印金额):
.\.venv\Scripts\python.exe -B -c "import routers.portfolio as p; from services.concentration import INDUSTRY_THEME_MAP as M; from services.stress_lookthrough import run; r=run(p._compute_lookthrough(top=10**6), lambda i: M.get(i,i)); print(r['param_source']); [print(s['name'], '已知损失%', s['known_loss_pct'], '含未知区间%', s['total_loss_pct_range'], '主要主题', [(t['theme'], t['shock']) for t in s['by_theme'][:2]]) for s in r['scenarios']]"
```

**本机结果（2026-10-29 03:12）**
- 测试：91 passed（含云端无法收集的 test_vol_overlay）。
- 穿透压力情景（占总资产，含现金；参数为默认示例假设、未校准）：估值压缩 x%；产业需求下降 x%；相关性上升 x%。未知暴露为 0，故区间上下限相同。三情景损失主要来自半导体电子主题。
- 由相关性上升情景（全部权益 x% → 总资产 x%）可推知权益约占总资产 x%（推算，未直接读取）。
- Redis 未运行时降级为内存缓存（日志提示），不影响计算。

### 遗留
- 压力参数未校准：可用历史区间（如半导体指数历次回撤）校准，或由用户按自己的研究判断设定。
- 未计非线性（跌停无法成交、流动性折价）；β 压力中的跳空情景部分覆盖。

---

## 阶段3B-4：穿透与风险页面（2026-10-29）

### 实现（只读展示，不改执行逻辑）
| 文件 | 变更 |
|---|---|
| `static/js/lookthrough_panel.js`（新） | 渲染 `/portfolio/lookthrough` 与 `/portfolio/stress-lookthrough`：KPI（可识别%、未知%、现金%、重叠公司数）、行业暴露、前 10 公司（来源与重叠）、ETF 成分来源表（正式名称/研究标签/跟踪指数/口径/日期/公告日/核验状态）、未知暴露明细（原因中文化）、压力情景（条件估计横幅、参数来源、冲击假设、损失或区间、主要来源、局限）。全部输出经 HTML 转义 |
| `portfolio.html` | 新增折叠面板"🧩 穿透暴露与压力情景"（复用现有折叠机制与 pf/slip 样式，面板内少量局部样式）；引入 `lookthrough_panel.js?v=1` |
| `static/js/renderers.js`、`index.html` | 首页主题集中度行的悬停提示追加 `explain.review_items`；renderers.js 版本 v10 |
| `tests/test_lookthrough_panel.cjs`（新） | 渲染与转义、未知/零未知文案、口径与日期、压力区间显示 |

### 检查
- `node tests/test_lookthrough_panel.cjs` 通过；JS 语法检查通过。
- 云端无头浏览器以模拟接口数据渲染组合页面板截图：结构与内容正确；云端缺项目 CSS，KPI 卡片无样式（本机有）。据截图修正"未知 0% 仍显示'不是零风险'"的文案。
- 未在本机浏览器实测；`ps.concentration` 的后端生产者仍未定位，若其未调用 `concentration.summarize`，首页悬停提示不会出现复核要点。
- 设备上实施记录第五次被回退（仅本工具写入段落丢失），已补回。疑为编辑器或其他 AI 工具持有该文件旧内容。

### 待用户本机执行
```powershell
cd "<项目目录>"
node tests\test_lookthrough_panel.cjs
# 启动服务后打开组合页, 展开"🧩 穿透暴露与压力情景"目视确认
Select-String -Path *.py,services\*.py,engines\*.py,routers\*.py,dashboard_modules\*.py -Pattern "concentration import|compute_from_store\(|concentration\.summarize" | Select-Object Path,LineNumber
```
（最后一条用于定位首页集中度的后端生产者，只输出文件名与行号。）

### 本机结果（2026-10-29）
- `node tests/test_lookthrough_panel.cjs` → `lookthrough panel ok`。
- 首页集中度生产者已定位：`dashboard_modules/assemble_response.py::_build_position_stack`（约第 83 行）调用 `concentration.compute_from_store(target_equity_pct=cap)` 后经 `summarize` 输出 `ps.concentration`；`summarize` 会带上 `explain`，因此首页悬停的复核要点会出现，无需再改。
- 其余引用：`engines/compliance_engine.py`（合规关键词口径，未改）、`routers/portfolio.py`、`services/portfolio_vol.py`、`services/dashboard_builder.py`（波动预算，不涉及集中度）。

---

## 阶段3B-5：主题集中度执行口径切换为穿透（2026-10-29，用户决定）

用户决定："按穿透后的实际持仓"。阈值（40% / 60%、合规规则 40%/60%/30% 提示）不变，只换归类口径。

### 实现
| 文件 | 变更 |
|---|---|
| `services/concentration.py` | 新增 `theme_rows()`（面板与合规共用）；配置 `concentration.classification_basis`，默认 `lookthrough`，可设 `keyword` 回旧口径。ETF 按已核验成分拆到公司 → 行业 → 主题；成分不可用（过期/缺失/未登记/查询失败）及未披露余量 → 按 ETF 名称关键词**保守回退**并单列 `fallback`（不当作零暴露）；固收类 ETF、`theme_overrides` 指定的代码不穿透。穿透到公司但无本地行业 → "行业未知"，不受主题上限约束，超 10% 时提示。超限指令注明"金额为穿透后的主题暴露，卖出 ETF 需按主题占比折算"。`compute_from_store` 附 `keyword_reference`（旧口径最大主题/占比/等级，仅对照）；`explain` 与 `summarize` 标明口径与回退比例。新增 `cached_industry_map()`（按文件 mtime 缓存） |
| `engines/compliance_engine.py` | `_theme_buckets` 改用 `theme_rows`（同一口径与配置）；规则描述更新 |
| `tests/test_concentration_basis_switch.py`（新） | 拆分与回退不归零、固收不穿透、同阈值判定、宽基拆分与行业未知豁免、keyword 口径可切回、explain/summarize、合规同口径、查询异常可见回退 |
| `tests/test_concentration_lookthrough.py`、`tests/test_decision_framework_v27.py` | 隔离真实成分快照（注入成分查询）；原 keyword 说明测试显式指定 keyword 口径；原合规测试在"成分不可用"下验证回退结果与旧口径一致（57%） |

### 检查（云端副本）
- 相关 80 项通过；全量对比修改前后失败集合一致（23 项均为云端缺 fastapi 等依赖的既有失败），无新增失败。
- 首次运行发现"warning 级指令未注明穿透折算"，已修代码（非改断言）。
- 未用真实持仓运行；真实等级、上限金额变化待本机对照。

### 待用户本机执行
```powershell
cd "<项目目录>"
.\.venv\Scripts\python.exe -B -m pytest tests/test_concentration_basis_switch.py tests/test_concentration_lookthrough.py tests/test_compliance_engine.py tests/test_decision_framework_v27.py tests/test_lookthrough.py tests/test_stress_lookthrough.py -o addopts="" -q -p no:cacheprovider --basetemp "$env:TEMP\alphacore_pytest"
.\.venv\Scripts\python.exe -B -c "from services import concentration as c; r=c.compute_from_store(); k=r.get('keyword_reference') or {}; print('basis', r.get('classification_basis'), '| top', r.get('top_theme'), r.get('top_pct'), r.get('level'), '| fallback%', r.get('fallback_pct_of_equity'), '| keyword', k.get('top_theme'), k.get('top_pct'), k.get('level'), '| overrides', len(c.load_concentration_config().get('theme_overrides') or {}))"
```
（第二条只输出口径、主题与百分比，不含金额。）

### 本机结果（2026-10-29）
- 6 个测试文件 97 项通过。
- 真实持仓：穿透口径最大主题「半导体电子」x%（占权益），等级 danger；名称回退 x%（全部成分可用）；旧关键词口径 x%，同为 danger；`theme_overrides` 0 条。
- 结论：口径切换未改变等级，主题上限与减持金额改按穿透暴露计算。

---

## 阶段4A：决定记录与成交关联（2026-10-29）

### 现状核对
- `services/manual_decisions.py` 已有快照绑定的 MR 计划（planned）与观察（watch/declined/self_directed），存于 `data_lake/analysis_decisions.db`，请求幂等；但只覆盖 MR 信号，没有理由/反证/持有期，也没有与真实成交的关联。
- 成交台账 `trade_ledger.json` 的 `key`（日期|成交号|代码|方向|数量|价格）稳定、去重，现金台账 settlement 事件已引用它。
- 结论：沿用同一库与同一成交 key，不另建系统；`manual_decisions.py` 不改（其文件内容参与 MR 计划快照指纹）。

### 实现
| 文件 | 变更 |
|---|---|
| `services/decision_journal.py`（新） | 决定记录写入同一张 `analysis_decisions` 表（kind=journal），状态 采用/未采用/暂不行动，意图 buy/sell/rebalance/hold；必填理由，采用须填反证；预期持有期、复盘日、关联原决定（须存在）。决定日早于今天须显式标 `retrospective`。记录时绑定快照：最新 `decision_evidence`（id/模型版本/时间）、持仓导入日与文件指纹、主题集中度口径/最大主题/等级；缺失项列入 `missing`。新表 `decision_trade_links`（只追加 link/unlink，以最后一条为准）。关联规则：仅 采用/MR 已确认计划 可关联；代码须在决定内、方向一致（调仓不限方向）、成交日不早于决定日；一笔成交只属于一条决定；取消关联须写原因。执行状态只由已确认关联推出（"未关联成交"不等于未执行）；费用缺失不猜。候选成交按代码/方向/14 天窗口筛出，须人工确认 |
| `routers/analysis.py` | 新增 `POST/GET /api/v1/analysis/journal`、`GET /journal/{id}`、`GET /journal/{id}/candidates`、`POST /journal/{id}/links`、`POST /journal/{id}/unlink`（pydantic 严格校验） |
| `tests/test_decision_journal.py`（新） | 三类结果都记录且带快照；理由/反证/代码校验；事后补记须标记；幂等与冲突；候选≠关联；关联/取消只追加与执行汇总（费用未知不猜）；早于决定/方向/代码/台账不存在拒绝；未采用/暂不行动/维持不能关联；一笔成交一个决定；已有 MR 计划可关联且原记录不变；关联原决定须存在；快照缺失项标记 |

### 检查（云端副本）
- `test_decision_journal.py` + `test_manual_decisions.py` 27 项通过；全量对比无新增失败。路由仅做语法检查（云端无 fastapi），待本机验证。
- 未做页面；录入与关联先通过接口，界面放在 4B 与复盘视图一起做。

### 待用户本机执行
```powershell
cd "<项目目录>"
.\.venv\Scripts\python.exe -B -m pytest tests/test_decision_journal.py tests/test_manual_decisions.py tests/test_personal_analysis.py -o addopts="" -q -p no:cacheprovider --basetemp "$env:TEMP\alphacore_pytest"
.\.venv\Scripts\python.exe -B -c "import routers.analysis as a; print(sorted(r.path for r in a.router.routes))"
```

### 本机结果（2026-10-29）
- `test_decision_journal.py`、`test_manual_decisions.py`、`test_personal_analysis.py` 共 40 项通过。
- 路由加载正常：`/api/v1/analysis/journal`（GET/POST）、`/journal/{decision_id}`、`/candidates`、`/links`、`/unlink` 均已注册，原有 `/mr`、`/plans`、`/observations`、`/records` 不变。

---

## 阶段4B-1：复盘比较（后端，2026-10-29）

4B 拆为 4B-1（比较计算与接口）与 4B-2（页面），本轮只做 4B-1。

### 实现
| 文件 | 变更 |
|---|---|
| `services/decision_review.py`（新） | **组合区间比较**：同一起点的三条路径——实际操作（期初风险资产 + 区间真实成交，卖出所得留作现金、买入从现金支付，费用按台账）、维持期初组合、每月首个交易日再平衡到期初权重（未计再平衡费用）。持仓由 `drawdown.holdings_history` 台账回滚；日收益用 `trailing_stop.normalize_bars` 复权收盘（拆分/分红连续化），期初市值与成交按原始收盘。口径 `risk_asset_twr` 的自融资变体：区间内入出金与现金利息不计（三条路径相同）。区间内净买入 > 期初风险资产 x% → 实际收益率不比较、只给增减值；费用未知按 0 并提示；区间内有除权的标的提示份额回滚偏差。**单条决定**：采用/MR 计划且已关联成交 → 与"不做这些成交"比较（卖出：所得 − 若持有的价值；买入：持有价值 − 成本；以成交价为锚、成交日收盘后按复权收益推算）；目标日 = 复盘日或决定日 + 预期持有期，未到则用最新行情并标"中期读数"。未采用/暂不行动 → "若当时执行"方向性对照（只给涨跌幅，标为假设）。采用未关联、维持不动 → 不评价。**不足以评价**（不出数字）：少于 20 个交易日、起点早于成交台账首笔前一交易日（期初持仓未知）、起止日缺行情。汇总：事后补记与中期读数单列，执行样本 < 10 条明确说明不构成能力证据 |
| `routers/analysis.py` | 新增 `GET /api/v1/analysis/review/portfolio?start=&end=`、`GET /api/v1/analysis/review/decisions` |
| `tests/test_decision_review.py`（新） | 人工行情、期望值手算：实际 vs 维持（卖出后资产继续上涨 → 增减值为负且等于手算值）；再平衡偏离；不足以评价三种情形；净买入时不比较收益率；费用未知提示；拆分不造成假亏损并提示；卖出/买入决定增减值；中期读数；过近不足以评价；未采用的假设对照；未关联/维持不评价；汇总分列与小样本提示 |

### 检查（云端副本）
- 新增 12 项通过；全量对比修改前后失败集合一致（18 项为云端缺依赖的既有失败），无新增失败。
- 首轮测试暴露起点早于成交台账首笔 → 判为"期初持仓未知"，属设计如此，测试改用台账首笔前一交易日为起点（未改断言含义）。
- 已知局限：持仓回滚不处理区间内拆分份额（与回撤模块相同，已提示）；分红现金不单独计入（复权价已含）；未用真实数据试算。

### 待用户本机执行
```powershell
cd "<项目目录>"
.\.venv\Scripts\python.exe -B -m pytest tests/test_decision_review.py tests/test_decision_journal.py tests/test_drawdown.py -o addopts="" -q -p no:cacheprovider --basetemp "$env:TEMP\alphacore_pytest"
.\.venv\Scripts\python.exe -B -c "import json; from services import trade_import as ti, decision_review as dr; t=ti.load_ledger()['trades']; s=min(x['date'] for x in t); r=dr.portfolio_review('2000-01-01'); s=r.get('earliest_start') or s; r=dr.portfolio_review(s); print(r.get('status'), r.get('reason'), r.get('from'), r.get('to'), r.get('trading_days'), [(p['label'], p['return'], p['max_drawdown']) for p in r.get('paths',[])], 'added_vs_hold%', r.get('value_added_vs_hold_pct'), r.get('caveats'))"
```
（第二条自动取最早可用起点，只输出收益率、回撤与百分比，不含金额。）

### 本机结果（2026-10-29）
- `test_decision_review.py`、`test_decision_journal.py`、`test_drawdown.py` 共 43 项通过。
- 真实试算：`insufficient`——区间起止日缺行情：证券03、证券07、证券08、证券09、证券01（成交台账中出现过、本地 `data_lake/daily_prices` 无日线的个股，多为已清仓）。按规则不出数字，未用合成价格补。
- 处理：用既有 `trailing_stop_service.sync_prices` 补同步这 5 只日线（Tushare，个股 asset=E，自 2024-01-01），再重跑试算：
```powershell
.\.venv\Scripts\python.exe -B -c "from services.trailing_stop_service import sync_prices; print(sync_prices(['证券03','证券07','证券08','证券09','证券01']))"
```
  若成交台账早于 2024-01-01 或同步失败，试算仍会是"不足以评价"，届时可指定更晚的起点（`portfolio_review('YYYY-MM-DD')`）。
- 同步结果：5 只全部成功，但日志显示只是增量 (20261024→20261029)，即本地早有这些文件。缺行情的真实原因更可能是**各标的最新行情日不同**：默认终点取了所有标的中最晚的日期，较早停更的标的在终点无价。
- 修正（`services/decision_review.py`）：默认终点改为"区间内相关标的共同最新行情日"（结果带 `end_rule`）；缺行情时逐只说明缺起点/终点/成交日，并给出本地行情起止日期（`missing_detail`）；指定终点而个别标的未更新到终点时沿用最后收盘并在 caveats 注明。新增测试 1 项，相关 25 项通过（云端）。
```powershell
.\.venv\Scripts\python.exe -B -m pytest tests/test_decision_review.py -o addopts="" -q -p no:cacheprovider --basetemp "$env:TEMP\alphacore_pytest"
.\.venv\Scripts\python.exe -B -c "from services import decision_review as dr; r=dr.portfolio_review('2000-01-01'); r=dr.portfolio_review(r.get('earliest_start') or '2024-01-02'); print(r.get('status'), r.get('reason'), r.get('from'), r.get('to'), r.get('end_rule'), r.get('trading_days'), [(p['label'], p['return'], p['max_drawdown']) for p in r.get('paths',[])], 'added_vs_hold%', r.get('value_added_vs_hold_pct'), r.get('caveats'))"
```
- 本机复跑（13 项通过）：`insufficient 区间内缺行情: 证券01 缺成交日 2026-09-07 (本地行情 2026-09-16~2026-10-29)`——成交早于该股首个行情日，判断为新股中签（上市前本无市场价），不是数据缺失。
- 修正：上市前成交的标的，自首笔成交日至上市前一日按成交价（发行价）计值，上市首日起用收盘价；上市首日涨跌计入实际路径，caveats 注明。新增测试 1 项（14 项通过，云端）。
- 本机真实试算（2026-10-29，14 项通过）：区间 2026-09-01 ~ 2026-10-29（终点＝相关标的共同最新行情日），36 个交易日。
  维持期初组合 x%（最大回撤 x%）；每月再平衡 x%（x%）；实际操作收益率不比较（区间净买入约为期初风险资产 x%，动用额外资金），相对维持期初组合的增减值 x%（占期初风险资产）。
  提示：证券01 上市前按成交价计值；45 笔成交费用未知按 0 计（实际路径偏乐观）。
- 解读边界：36 个交易日、单一区间，不构成判断能力的证据；x% 的幅度需逐只核对（期初持仓由成交台账回滚，台账若漏记成交会使期初持仓失真），核对命令见下。
- 逐只核对（用户本机输出，仅权重与涨跌）：期初 14 只，前五 证券12 x%/x%、证券15 x%/x%、证券11 x%/x%、证券17 x%/x%、证券14 x%/x%；全部下跌 x%~x%。按权重加总 ≈ x%，与"维持期初组合 x%"一致 → 计算内部自洽。外部新闻显示 10 月科创板多日下跌（东方财富收盘播报），幅度未逐日外部核验；期初持仓是否与券商 9/1 持仓一致待用户确认。

---

## 阶段4B-2：决定与复盘页面（2026-10-29）

前提：用户未逐项回复 9/1 持仓核对，以继续指令视为大致一致；若后续发现不一致，先修数据再看复盘数字。

### 实现（只记录与复盘，不下单、不改持仓）
| 文件 | 变更 |
|---|---|
| `static/js/decision_review_panel.js`（新） | 组合区间比较（默认先探测成交台账最早可用起点；三条路径收益/回撤；相对维持期初组合的增减值%；"不足以评价"只显示原因与最早起点；caveats 全显示）；决定录入表单（前端校验：代码格式、理由必填、采用须填反证、持有期正整数；request_id 每次提交前生成、成功后更换，保证幂等）；决定列表与单条复盘（执行对比、中期读数、不足以评价、假设对照分别标注，补记单列）；汇总与小样本提示；成交关联：候选成交须点"确认关联"，已属其他决定的不可点；取消关联须填原因。金额（期初/期末价值、增减值金额、成交数量与价格）默认显示 ***，勾选"显示金额"才显示。所有输出 HTML 转义；POST 走既有 `AC.secureFetch`（X-API-Key） |
| `portfolio.html` | 新增折叠面板 ZONE 5c"📝 决定记录与复盘"（复用 pf 折叠机制与样式，面板内少量局部样式）；引入 `decision_review_panel.js?v=1` |
| `tests/test_decision_review_panel.cjs`（新） | 金额默认隐藏/切换显示、不比较时不出数字、不足以评价无表格、转义、各类复盘标签、仅采用/计划且非维持可关联、候选与取消关联、录入校验与代码规范化 |

### 检查（云端）
- `node tests/test_decision_review_panel.cjs`、`node tests/test_lookthrough_panel.cjs` 通过；语法检查通过。
- 无头浏览器（本地 HTTP + 模拟接口）截图：结构与标签正确；云端缺项目 CSS 故样式简陋。
- 未在本机浏览器实测录入、关联与取消关联的完整流程。

### 待用户本机执行
```powershell
cd "<项目目录>"
node tests\test_decision_review_panel.cjs
.\.venv\Scripts\python.exe -B -m pytest tests/test_decision_review.py tests/test_decision_journal.py tests/test_manual_decisions.py -o addopts="" -q -p no:cacheprovider --basetemp "$env:TEMP\alphacore_pytest"
# 启动服务, 打开组合页, 展开"📝 决定记录与复盘": 看组合比较; 可试记一条"暂不行动 / 维持不动"验证录入 (会写入真实决定库, 只追加)
```

### 本机结果（2026-10-29）
- `node tests\test_decision_review_panel.cjs` → `decision review panel ok`。
- `test_decision_review.py`、`test_decision_journal.py`、`test_manual_decisions.py` 共 41 项通过。
- 浏览器目视与真实录入流程未反馈，留待用户确认。

---

## 最终交付物（2026-10-29）

- 新增 `docs/PLAN_B_FINAL_REPORT.md`：结论、事实表（来源/口径/日期/核验状态）、真实数据复盘示例（仅百分比）、未完成清单（按优先级）、全量测试命令。
- 无决定记录，单条决定复盘示例暂缺（如实说明）。
- 模型投资评级未因本轮工作提升（F6）。

---

## 全量测试（2026-10-29）

### 第一次本机运行
- node：5 个 `tests/*.cjs` 全部通过（decision review panel、JCS frontend、lookthrough panel、multi-asset frontend、personal analysis frontend）。
- pytest：`164 passed, 2142 errors`；错误全部是 `ValueError: I/O operation on closed file`（用例 setup/teardown 阶段，自 `test_api_smoke.py` 起），最终 pytest 自身退出时同样报错。**没有任何断言失败（FAILED 0）**。
- 诊断：`main.py` 开头为 Windows 控制台 UTF-8 用 `io.TextIOWrapper(sys.stdout.buffer)` 新建包装并替换 `sys.stdout/stderr`。在 pytest 下 `sys.stdout` 是捕获流，新包装被回收时关闭了底层捕获文件 → 其后全部用例报错。属**既有问题**（main.py 修改时间 2026-10-25，方案 B 未改过该段），此前分文件运行未导入 main，故未暴露。云端用最小复现确认（原写法报同样错误；新写法 4 passed）。
- 修复（`main.py`，CRLF 保留）：优先 `stream.reconfigure(encoding="utf-8", errors="replace", line_buffering=True)` 就地修改，不新建包装；仅在不支持时才回退到原写法；`pytest` 已加载时不改动输出流。正常启动服务时控制台 UTF-8 行为不变。

### 第二次本机运行（修复 main.py 后，4 分 43 秒）
- `3 failed, 1232 passed, 2 subtests passed`；node 5/5 通过。
- `test_production_check::test_ci_runs_code_only_production_readiness_gate`：读旧位置 `quant_dashboard/.github/workflows/ci.yml`，该文件已按 1C 迁至仓库根（根目录 `ci.yml` 仍含 `python engines/production_check.py --code-only`）→ **方案 B 引起**，已修测试：优先读仓库根、旧位置兼容，断言内容不变。
- `test_fetch_macro::test_fetch_macro_data_async`：未安装 pytest-asyncio（`Unknown pytest.mark.asyncio`），且需联网取 VIX/汇率 → 既有环境问题，与方案 B 无关，未改。
- `test_integration_smoke::TestDecisionHubAPI::test_hub_has_data_freshness`：`integration` 标记，请求正在运行的本机服务 `/api/v1/decision/hub`，结果取决于当时数据新鲜度；相关代码（routers/decision.py 2026-10-26）方案 B 未改。→ 核查：当前 `dashboard_modules/decision_engine.py` 的 `data_freshness` 按信号源（来自 `build_signal_decay`）生成键，状态为 ok/unknown；测试（V21.2，2026-05）仍要求固定键 dashboard/aiae/strategy/global 且状态 ok/stale → **测试与现行接口契约不一致，属既有过期测试**。方案 B 阶段1A 只在同文件 `log_daily_decision` 加了 3 行方向字段，未改该结构（基线记录显示该文件在方案 B 前已有未提交修改）。按约束不改断言掩盖，列入未完成清单另行处理。
- 另：CI 的 `pytest tests/` 会收集上述联网/需服务的用例，CI 上可能失败（未在 GitHub 运行验证），列入未完成清单。

---

## 验收修补（2026-10-29）

范围：只修正确性与测试契约，不扩功能。修改前核对：本机文件与云端副本逐一比较一致（无外部未提交修改需保留）。每项先写回归测试（修复前失败），再修实现；全部人工数据、临时库/临时目录，不碰真实台账。

| # | 文件 | 要点 |
|---|---|---|
| 1 成交信息补全 | `services/trade_import.py`（merge_into_ledger）、`services/account_ledger.py`（_enrich_settlements、effective_events 支持 enrich） | 同 key 只补缺失的 fees/net_amount，记录 enrichments（旧/新/来源/时间），原 source 保留；不一致登记 ledger.conflicts（去重），返回 enriched/conflicts/conflict_details；现金台账原事件不改，追加 enrich 更正，完整度只升不降，同级不一致报告冲突 |
| 2 单条决定复盘 | `services/decision_review.py`（_review_executed） | 成交价 → 成交日原始收盘 → 复权收益衔接；成交日无行情 → 不足以评价；items 增加 fill_vs_close |
| 3 整账户 TWR | `services/return_basis.py`（flow_timing、twr_segmented、account_returns）、`services/account_ledger.py`（资金事件记录 time） | 开盘前/收盘后时点精确分段；盘中/未知 → 区间 + 中值（approx_flow_timing_unknown）；缺流前估值 → modified_dietz_approx；输出 twr_range/twr_note/valuation_timing |
| 4 数据新鲜度 | `dashboard_modules/decision/quality.py`（SOURCE_CADENCE、freshness_status、build_freshness）、`dashboard_modules/decision_engine.py`、`static/js/decision/risk_alerts.js`、`static/css/decision.css`（fresh-missing）、`decision.html`（risk_alerts v54、decision.css v55）、`tests/test_integration_smoke.py`（按现行契约） | ok/stale/missing/future/unknown + 原因 + 允许落后交易日（默认值，未逐一核对发布日历） |
| 5 穿透守恒 | `services/lookthrough.py`（split_etf_value、coverage_complete、conservation_check）、`services/concentration.py`（theme_rows 共用） | 残余全部计入未知；≤100.5% 缩放标注；>100.5% WEIGHTS_EXCEED_100 整只未知 |
| 6 测试契约 | `pytest.ini`、`tests/test_fetch_macro.py` | 默认排除 integration 与 network，去掉相互抵消的 -v/-q；宏观离线 8 项 + network 3 项；asyncio.run 免 pytest-asyncio；其余测试文件静态检查均已用替身 |

新增测试：`test_trade_enrichment.py`、`test_decision_review_fill_link.py`、`test_twr_flow_timing.py`、`test_data_freshness.py`、`test_freshness_bar.cjs`、`test_lookthrough_conservation.py`。更新：`test_return_basis.py`（精确分段用例显式给出收盘后入金时间——这是本次修正的契约本身；另增"时间未知不得标精确"）。

云端检查：相关 187 项通过（另 4 项为云端缺前端文件、修改前后相同）；前端 cjs 4/4 通过；修改前后对比无新增失败；网络测试在云端（无外网）按预期失败，已标记排除。

文件被覆盖：本机实施记录多次被旧内容覆盖，**原因未明**（无进程级证据）。此前"编辑器或其他 AI 工具"的说法是推测，撤回为"原因未明"。

---

### 本机最终运行（2026-10-29）
- `pytest`（默认配置，排除 integration 与 network）：1240 passed, 35 deselected, 2 subtests passed, 36 warnings（第三方弃用），0 failed, 0 skipped，253 秒。
- node：6/6 通过（含新增 freshness bar）。
- 未运行：`-m network`（3 项）、`-m integration`（需运行中服务）、远程 CI。

---

## 真实数据副本验收 · 准备（2026-10-29）

分工：本会话检查代码、补历史快照日期支持、写本机验收脚本；用户本机运行并回传脱敏汇总；正式导入保留待执行。

### 检查发现与修补
- **测试污染真实现金台账**（方案 B 阶段 2A 引入）：`trade_import._record_account_ledger` 在 path 未传时用 `ledger_path_for(None)` → 真实 `data_lake/account_ledger.json`；`test_trailing_api` 只替换了 `LEDGER_PATH`，经接口导入测试成交时写入真实现金台账（该文件 07:12 在测试运行期间被修改）。修复：跟随 `path or LEDGER_PATH`；`record_parse` 内容未变不写文件；`conftest.py` 增加真实数据指纹防护（汇总中报告）。真实台账中的痕迹未删除，由验收脚本统计。
- **历史快照日期**：`PortfolioEngine.import_from_txt` 的快照 `as_of` 与 `import_date` 均为导入当天。修复：`resolve_statement_date`（显式 > 文件名 YYYYMMDD > 未知，绝不回退为导入当天）；新增参数 `as_of / valuation_time / source_name / persist`；快照记录 `valuation_time / valuation_timing / date_basis / positions / recorded_at`；日期未知不记快照；`routers/portfolio.py` 导入接口传入文件名与可选的 `as_of`、`valuation_time`。
- **收益口径**：快照估值时点不是收盘后或未知 → TWR 不标精确（`approx_valuation_timing_unknown`）；来源注明"as_of=导入日期"的旧快照不参与（`excluded_legacy_snapshots`）。
- **现金覆盖**：`cash_coverage_ok` 只含周末的空档不算缺口（节假日仍算）。
- 原测试夹具补充 `valuation_timing: close`（流时点测试假设收盘后估值，属本次契约收紧）。

### 新增
- `_dev_tools/plan_b_reconcile.py`：备份 → 清单 → 副本试导入 → 重复导入（实质内容指纹；导入日志按设计追加，不参与比较）→ 费用补全统计 → 券商对账 → 停止条件 → （通过后）收益/穿透/复盘 → 污染痕迹 → 真实文件指纹自检。退出码 0/3/2/1。
- 测试：`test_statement_snapshot.py`（9）、`test_plan_b_reconcile.py`（6）。

### 检查（云端）
- 相关测试全部通过；全量对比无新增失败（多通过 15 项，其余失败为云端副本缺模块的既有情况）。

---

### 副本验收第 1 轮（用户本机，2026-10-29 07:47，脱敏汇总）
- 账单（已移出仓库，放在 `<账单目录>`）：交割单 09-02~10-27（89 行：成交 50、资金行 36、跳过 36、失败 1）；历史成交 09-02~10-27（50 笔全部重复；27 条逆回购行无发生金额，按规则不入现金台账）；资金股份查询 10-29（15 只，账单内部自洽，估值时点未声明）。
- 副本：成交新增 6、补全 44、冲突 0；现金事件新增 82、补全 4；原缺费用 45 笔 → 补全 44、剩 1（疑似同笔但编号不同）；重复导入稳定；真实文件未改；真实现金台账中有 h.txt 测试残留 7 条事件（未删除）。
- 收益验收按规则停止：只有一份资金股份查询（缺期初快照）；1 笔费用待确认。
- 诊断：失败行为"新股入账"（证券01）；剩余 1 笔为同一新股，"新股申购"行在历史成交中无成交编号，与交割单编号不同 → 第 1 轮副本中这笔新股可能被记了两次（6 笔新增之一），现金台账也可能各记一笔扣款。
- 修复（先写测试）：`classify_side` 把"新股入账"识别为股份划转（`ipo_credit`），计数跳过、不当作买入；`merge_into_ledger` 遇到疑似同笔（来自不同文件，日期/代码/方向/数量/价格相同，至少一方无编号）不自动新增，登记 `possible_duplicate` 冲突，对应现金结算暂不记入；两边编号都有且不同时视为真实分笔成交。验收脚本显示疑似同笔清单，费用原因中单列"疑似同笔已登记待确认"，并按冲突停止。清单读取兼容 BOM。新增测试 4 项。

### 副本验收第 2 轮（07:55，修补后）
- 失败行 0（新股入账计为 ipo_credit）；成交新增 5（第 1 轮的 6 笔中，那笔重复的新股已改为待确认）；疑似同笔 1（证券01，历史成交 vs 交割单）；原缺费用 45 笔：补全 44，1 笔待确认；重复导入稳定；真实文件未改。
- 收益验收停止：缺期初快照、1 处冲突待确认。结果已写入最终报告第七节。

### 核实清单（第 3 轮代码，按用户 4 点要求）
- 期初快照：`store_provenance` 只报告当前持仓文件 (portfolio_store) 的导入日期、日期依据、文件修改时间、最后导入记录时间、导入后是否再被修改；`confirmed_as_opening` 恒为 false，与 10-29 账单的比较仅作"未确认锚点"参考。只有一份带日期快照时，输出"新起点 = 10-29 收盘后快照，此前区间期初资料不足"。
- 证券01：`ParseResult.ipo_credit_rows` 保留新股入账行；`ipo_checklist` 逐文件列出该代码的成交行、股份入账行、缴款/中签资金行（只给日期、业务类型、类别、是否有编号、数量/金额是否与对方一致的布尔值），并统计副本中股份记账次数、缴款结算次数、待确认疑似同笔、净股数是否与账单一致。不自动合并、不删除。
- h.txt：`test_trace` 用测试夹具 `tdx_bytes(FIXTURE_ROWS)` 重建文件，核对源文件 sha256 与每条事件内容，确认为测试来源后才在副本 `add_correction(..., "void", 原因)` 作废（原事件保留）；与真实成交键重合的事件不作废、单列。报告作废前后有效事件数、净现金变动差（占总资产 %）、结算估算变化；检查隔离修复 (`ledger_path_for(path or LEDGER_PATH)`) 是否在位。
- `difference_list`：期初/期末各证券数量、现金变动与余额、证券01 股份与缴款各计一次、疑似测试记录、当前持仓文件作为期初；状态为 不一致/待确认 的项加入停止原因。
- 测试：`test_plan_b_reconcile.py` 10 项（新增 3）；相关测试 85 passed / 1 skipped；真实数据防护通过。

### 副本验收第 3 轮（08:27，脱敏汇总）
- 资金股份查询：未声明估值时点 → 记为"未知"（文件修改时间 10-29 07:46，开盘前，不可能是 10-29 收盘后数据）。
- 当前持仓文件：2026-10-23 旧版导入（导入日期非账单日期），导入后未被修改；与 10-29 账单 15/15 一致（仅参考，未采用为期初）。
- 证券01：交割单"配售缴款" 09-07 与历史成交"配售申购" 09-07 数量、金额一致，均无成交编号；"新股入账" 09-15 一次；副本中股份记 1 次、缴款结算 1 次，净股数与账单一致；疑似同笔仍待用户确认。
- h.txt：源文件指纹与测试夹具一致、7 条与夹具逐条一致 → 确认测试来源；隔离修复在位。其中 5 条与真实成交编号相同（夹具取自真实成交），保留；2 条在副本作废；作废影响净现金变动约为总资产的 x%。
- 本机 pytest：34 项全部通过，但收尾时 pytest 清理自身临时目录 (`pytest-current`) 被 Windows 拒绝访问而报错；改用 `--basetemp` 规避。真实文件由脚本自检确认未改。

### 第 4 轮代码
- h.txt 逐条去向：日期、代码、方向、处理方式、账单中是否有同日同代码的现金记录。对账区间内"作废但账单无对应"或"保留且账单另有一份"→ 待确认，除非作废后区间现金与券商余额核平（写明依据）。新增测试 2 项。

### 副本验收第 4 轮（08:34）与用户补充
- 用户说明：客户端只能导出最近 60 天；近期不定时加仓。→ 不可能取得 09-02 前的期初原件。
- 更正：上一轮把资金股份查询判为"开盘前导出"有误 — 修改时间 07:46 为本机时区时间，即北京时间 10-29 20:46，是收盘后快照；清单恢复 valuation_time 20:46。
- h.txt 逐条：作废 2 条（09-04 证券05 买、09-17 证券01 卖）在账单中均有同日同代码现金记录；保留 5 条为真实成交的唯一现金记录（来源标签为 h.txt）。区间内无未解释项。
- 交割单表头含"剩余数量""剩余金额"（列名，无数据）。

### 第 5 轮代码：交割单逐笔余额对账
- `trade_import`：新增列别名 remaining_qty（剩余数量/股份余额/剩余股数）、remaining_cash（剩余金额/资金余额/本次余额）；`ParseResult.balance_rows` 按文件顺序保留每行结余（任何类别）。已验证成交数量/成交金额/清算金额/佣金不串列（"其中：净佣金"不重复计费）。
- `plan_b_reconcile.running_balance`：① 券商数据连续性（上一行结余 + 本行变动 = 本行结余；新股缴款/入账允许 0 或 +数量）；② 反推期初数量与现金，期间无记录的证券推定不变（依赖交割单完整，已标注）；③ 与"以 10-29 账单为锚、按副本台账成交回滚"的期初、账单期末、台账期间现金变动比较；容差 1 元；只输出计数、一致性和占总资产比例。
- 只有一份账单时，差异清单的期初/期末/现金改用逐笔余额结果；收益验收仍停止：只有数量与现金，没有期初估值快照（需按期初收盘价估值，未实现）。
- 测试：新增 4 项（解析不串列、全一致、现金断链、数量不一致）；相关测试 91 passed / 1 skipped。

### 用户决定（2026-10-29 09:19）
1. 证券01：09-07 配售缴款与配售申购为同一次中签。
2. h.txt 中与真实成交共用的 5 条：同意只更正来源标签（原事件保留）。
3. 定期提醒导出账单：已建定期任务"账单导出提醒"（每月 28 日本机时间 07:47，即北京时间收盘后当晚）。
4. 收益起点：按 10-29 收盘后起算；09-02~10-29 不计收益，只核对数量与现金。

### 第 6 轮代码：执行用户决定（只在副本）
- `trade_import.confirm_possible_duplicate_same`：疑似同笔冲突标记 resolution（决定、原因、时间），原冲突保留；用来报行补全已有成交的空字段（费用、发生金额），现金台账以 enrich 更正补全该笔结算（不新增事件）。`merge_into_ledger`：已确认同笔的来报再导入时按重复处理，不再登记冲突、不记现金 → 幂等。
- `account_ledger`：新增 `relabel` 更正（只能改 source_file，必须写原因），在 effective_events 中显示 `relabeled_from`；不影响 void/replace。
- `plan_b_reconcile`：清单 `_decisions`（same_allotment / relabel_shared_test_events / returns_start）；`apply_confirmations` 在副本执行；门禁冲突数扣除已确认项；证券01 核对显示 user_confirmed_same；`returns_plan` 说明起点快照与估值时点，替代"需要两份快照"的停止原因，改为"等待下一份收盘后快照"。
- 测试：新增 5 项；相关测试 96 passed / 1 skipped。

### 副本验收第 5 轮（09:24，执行用户决定后）
- 证券01 已确认同笔：冲突 0、缺费用 0（45/45 补全）、股份与缴款各 1 次。h.txt：作废 2、改来源 5，估算结算 0。重复导入稳定；真实文件未改；本机 pytest 45 passed。
- 交割单逐笔余额：现金 86 行连续无断链，期初/期末现金差 0（容差 1 元）；期初数量 14/14 一致；数量断链 3 处，全部在资金行附近：09-21 证券03 红利入账、09-23 证券04 股息红利差异扣税、09-24 证券03 证券买入（受前一条红利行影响）；期末 证券04 "账单持有但推算无"（其在交割单中只有扣税行）。
- 判断：券商在红利/扣税行的"剩余数量"不是持股余额（行为推断，未打开账单核实）。修正：资金类行不参与股数结余与期初反推，只计数备查（cash_rows_not_used_for_shares）；只有资金行的证券按"期间无股数变动"推定不变。新增测试 2 项；相关测试通过。

### 副本验收第 6 轮（09:32）
- 数量断链 0（资金行 4 行不参与股数核对，其中 3 行"剩余数量"与持股不同）；期初 14/14、期末 15/15、现金期初/期末差 0；证券01 一致；h.txt 作废 2、改来源 5；差异清单无"不一致"或"待确认"。唯一停止原因：收益从 10-29 起算，等待下一份收盘后快照。结果已写入最终报告第七节。

### 第 7 轮代码：正式导入工具（用户答复"1、现在做 2、等下一份快照再做"，按"正式导入现在做；收益等下一份快照"理解）
- `plan_b_reconcile --apply`：先完整跑一遍副本核实；前置条件为真实文件核实期间未变、重复导入稳定、差异清单无"不一致/待确认"、期初/期末/现金三项均为"一致"、唯一允许的停止原因是"收益等待下一份快照"。
- 执行：持久备份到 用户目录\AlphaCore_backups\plan_b_时间戳（含 .db，SQLite 在线备份），校验两份台账备份与核实开始时指纹一致；再次确认真实文件未变；只替换 trade_ledger.json、account_ledger.json（原子替换）；用同一批账单复核（必须无新增/补全、决定无需再执行、差异清单通过），失败自动从备份还原并校验。写 apply_receipt.json（前后指纹、决定、备份清单）。不改 portfolio_store.json、trade_history.json、数据库。
- `--restore 备份目录`：按回执还原两份台账；若导入后台账已有新变化则拒绝（`--force` 才还原）。
- h.txt 区间判断在只有一份快照时改用交割单逐笔余额区间与现金结果。
- 测试：新增 7 项（写入并可还原、未通过时拒绝、核实后文件变化时拒绝、复核失败自动回滚、还原保护、带决定写入后复核稳定、核心对账项不足时拒绝）；相关测试 99 passed / 1 skipped。

### 正式导入（09:47，用户本机 `--apply`）
- 结果 applied：备份 `用户目录\AlphaCore_backups\plan_b_20261029_094717`；替换两份台账；写入后复核新增/补全 0、差异清单全部一致、problems 空。本机 pytest 30 passed（plan_b）。

### 第 8 轮代码：导入后收尾
- `test_trace`：h.txt 事件已在真实台账逐条作废或改来源时，状态为 resolved_in_ledger（"已在正式台账处理"），不再依赖测试数据比对 → 测试数据脱敏后不会重新变为"待确认"。
- 测试数据脱敏：`tests/test_trade_import.py` ROWS 中成交编号、委托编号、股东代码替换为虚构值（保留 A 开头=沪、数字开头=深的规则），相应断言同步；日期、代码、价格、数量未改。
- 测试：相关测试 120 passed / 1 skipped；新增断言覆盖"测试数据改动后已处理记录仍被识别"。

### 提交前检查与本地提交（2026-10-29）
- 新增 `_dev_tools/commit_prep.py`（只读 git）：inventory 分类并对拟提交文件做敏感扫描（真实账单标识符、真实成交"代码+数量+价格"同行、真实持仓"代码+数量"同行、疑似股东代码〔明显虚构的除外〕、密钥、手机号、本机路径），只输出文件、行号与类别；verify 核对暂存区与清单完全一致，暂存内容出现真实标识符/成交/持仓/股东代码/密钥则不允许提交。测试 `tests/test_commit_prep.py`（临时 git 仓库）。
- 测试样本脱敏：`test_trade_import.py`、`test_trade_enrichment.py`、`test_plan_b_reconcile.py` 中取自真实账户的成交改为虚构样本，断言同步。
- 文档：最终报告更新过时状态（真实数据已导入、收益起点、未完成清单）；报告与本记录入库版本脱敏（证券代码与名称、持仓比例、收益数字、本机路径与所在地），原始版本另存仓库外私人目录。
- 忽略规则：券商导出、真实台账/持仓/成交历史、账户配置、数据库、应用 data_lake、备份、旧版留档、密钥、scratch 与缓存。`backup.bat` 中的本机用户目录改为 `%USERPROFILE%`。
- 只做本地提交；不推送、不改写历史、不删除本地数据。历史隐私文件另列清单，推送前处理。

## 下一步

1. 11-28 提醒到达后导出新账单，运行验收脚本（不加 --apply）计算首个收益区间；对账通过后再用 --apply 导入新增记录。
2. 推送前：处理 git 历史中的私人文件（另列清单）；`一键推送.bat` 改为按清单暂存（当前为 `git add -A`）。
3. 待办（用户 10-29 同意下次顺手改）：验收脚本"真实现金台账疑似测试写入"一段仍提示"未自动删除, 由用户决定"；h.txt 已在正式台账处理（作废 2、改来源 5）后应显示"已在正式台账处理"。纯提示文字，不影响结果。

### 导入后确认（09:55）
- 不加 --apply 再运行：同一批账单新增/补全 0、快照新增 0；h.txt 状态 resolved_in_ledger（作废 2、改来源 5）；期初/期末/现金/证券01 一致；唯一停止原因为等待下一份收盘后快照；真实文件未改。本机 pytest 45 passed。

## 决策中枢 JCS 定位：宏观环境读数（2026-11-01）

### 定位决策
- 用户确认：**JCS = 宏观环境读数**。只描述宏观环境，不输出仓位、不涉及下单权限、不用操作语言；执行区不得引用 JCS 分数/等级。
- 4 个实施选择委托 Claude 决定：MR 移出 + 剩余权重等比例归一；BOND 移出；基础分单因子跳变本轮只披露不改公式；方向网格与冲突列表归入 JCS 一侧。详见 `docs/JCS_MACRO_ENV_DECISION.md`。
- 说明：页面实际位于 `decision.html`（决策中枢），不在 `strategy.html`。

### A：定位脱钩与口径修正
- 模型版本 `jcs-26.0-macro-env`，历史序列断点 2026-11-02；准确率评价版本 `jcs-direction-eval-v2`；多资产 `multi-asset-v2.3`；决策契约 `decision-controls-v2`。
- 执行区唯一仓位数字 = AIAE 执行目标（与 `/portfolio/vol-budget` 同源 `services.aiae_execution.current_view_and_execution`）；删除模型参考仓位（AIAE 上限 × JCS 系数）、风控"JCS 门槛"、多资产"JCS<40"闸门、路径生成器 JCS 条件。
- 修复：回撤刹车减仓豁免（`decrease` 未识别）；仓位超限规则不再给出第二个目标与节奏；参数对比改用生产公式。
- 同一快照改前/改后：JCS 27.1 低 → 51.7 一般（主要来自 MR 移出后的单因子跳变，非环境变好）；执行结论不变（风险阻断）；执行区仓位数字由 4 个变为 1 个（执行目标 25%）。
- 验证（云端，缺 fastapi/tushare 等依赖的用例无法运行）：已暂存测试 899 项中，改前改后失败集合相同（均为环境缺依赖），新增/改写用例全部通过；离线 JCS 验证器 8000 组通过；JS：test_jcs_frontend / test_multi_asset_frontend / test_freshness_bar 通过；ruff F/E9 无新增。
- 需本机复跑：`test_jcs_order_contract`、`test_multi_asset_api`（fastapi）以及全量 pytest。

### B：信息结构与视觉（第 8–15 条）
- 布局：左 = 宏观环境读数（JCS 分数、宏观因子网格、冲突、成分、新鲜度），右 = 执行（执行目标、分区、约束原因、风控、权限）；窄屏（≤1100px）执行区排在前面。
- 风险说明只在执行卡风险栏完整出现一次；徽章悬停只列规则名；执行理由只列规则名摘要。
- 脚注：必看两行（"JCS 只描述宏观环境…"、数据覆盖）；口径细节（待核验、方向分布、V27 影子、模型版本）折叠到"口径细节"。
- 日期：观测日期统一 YYYY-MM-DD 并注明来源当地日期（北京/纽约）；接收时间带时区的换算为北京时间，不带时区的如实标"未标时区"。
- 去掉 JCS 模块全部 emoji（标题、执行图标、冲突提示、徽章）。
- 颜色：红/绿只表示看多/看空，且改为红涨绿跌（原为绿涨红跌）；环形图、等级、数据健康、新鲜度、成分条改用中性色阶；全部颜色为 `static/css/jcs_macro.css` 中的 CSS 变量，JS 不再内联颜色。
- 去掉毛玻璃、重阴影、16px 大圆角、发光、呼吸动画、hover 位移（仅限 JCS 模块；页面其他卡片仍用旧 glass-decision 样式）。
- 风险阻断：红色实线边框 + 红色左栏 + 实心红底"禁止下单"徽章 + 红色标题；修复旧样式把阻断徽章渲染成绿色的问题。
- 验证：test_jcs_frontend（含 emoji / 渐变 / 毛玻璃 / 红涨绿跌 / 内联颜色静态检查）通过；桌面 1440 与手机 390 截图无横向溢出、无脚本错误（云端用真实 CSS 与 JS 渲染，数据为同一快照的服务端输出）。

### 后续修补（2026-11-01 晚）
- 决策契约版本：`/hub` 路由仍按 v1 判定，导致 v2 结果全部被撤回为"数据降级"。契约版本改为 `controls.CONTRACT_VERSION` 单一常量；撤回时清空执行分区、约束与评估日。已部署并在服务器实时核实：风险阻断、执行目标 25%（回撤刹车决定）、徽章红底。
- CI：#80 失败为叙事测试段落名未同步（已修）；#81/#82 失败为 `test_gold_signal_engine` 的既有时间炸弹——测试用机器本地时钟生成 FRED 观测日期，UTC 机器在 00:00–约 05:00（美东前一晚）会生成"晚于美东今天"的观测，被新鲜度检查判为 future。与 JCS 改动无关（原代码在 TZ=UTC 下同样失败），#79 恰在该时段之外运行。修复：测试日期以美东日期为终点；TZ=UTC / Asia/Shanghai / America/Chicago 下均通过（在故障时段内验证）。
- VIX 观测日期：`fetch_vix_for_dashboard` 原只返回数值，下游 JCS 恒判"待核验"。现记录观测日期（美东交易日）：yfinance/FRED 用序列日期，TradingView 优先用报价/日线时间，无时间的实时报价按美东最近交易时段推定（basis=session_derived，工作日近似）；磁盘缓存保存日期，旧缓存无日期如实留空。宏观卡片与热循环写入 `data_as_of/observation_basis/source/updated_at`。新增 7 项测试。
- 日报：去掉"JCS 置信度/联合置信度"与由 JCS 推出的操作语言；今日决策改为执行状态 + 执行分区 + AIAE 执行目标；"建议仓位"行更名为"AIAE 矩阵上限"。
- 未做（有意）：页面其他卡片的毛玻璃样式统一——属全页视觉改版，范围大、收益低，与 JCS 无关。

## 深度审计页定位与口径修正 · 方案 A（2026-11-02）
### 定位决策（用户确认）
- 审计页回答两个问题，分开呈现、分开打分：A. 系统可信吗（数据新鲜度、引擎运行、参数证据、系统状态）；B. 组合是否违反已定风险规则（只读取合规引擎在决策中枢同一快照上的结果，本页不自带阈值）。不再用一个"可信度总分"混合 A 与 B（总分拆分在方案 B 完成）。
- 旧执行器 audit_enforcer 退役：自动强平、交易阻断文件、静音/降级、执行器开关全部删除；风控拦截只保留在合规引擎的下单环节 (create_order)。删除"挡住手工记账"。
- 回撤基准维持全历史高水位；已核实回撤为剔除出入金的风险资产时间加权净值 (TWR)，追加资金不稀释回撤；本轮不调整刹车阈值。

### A：口径修正（第 1–6 条）
- 风控：逐条映射合规引擎 9 条规则（hard_block 未通过=失败，soft_warn 未通过=警告，规则异常=失败，无结果=失败 fail-closed）；删除本页单票20%/行业40%/总仓位95%/AIAE×110%/静态止损线/回测回撤/"合规引擎就绪"计分项；config.AUDIT_CONFIG 中对应风险阈值与参数接口 audit 块一并删除。合规引擎对"减仓"候选的豁免 (越线禁止加仓/回撤刹车) 显示为只读，不显示为通过。
- 只读读数（不计分）：账户回撤（口径标注）、止损执行状态（跟踪止盈 RED/LEGACY，链接 decision.html#trailing-stop-panel）、相关性集中度（补充）。缓存为空时回落到 data_lake/trailing_snapshots 最近日终快照。
- 策略健康：只评 MR/DIV/MOM/GEM 等权 25%；验证状态与执行总览同源 (run-all 发布 sleeve_evidence 缓存)；红利/动量旧证据文件取较严；MR 另查三态生命周期与参数完整性取较严；保留失败数断路器与 MR 核心联锁。ERP 移出，改为系统状态"ERP v4 前向记录"（缺1交易日=警告，连续≥2=断档失败）。
- 只读：GET /api/v1/audit 不写阻断、不写历史；POST /api/v1/audit/save 手动保存；每个交易日 16:45 定时保存。
- 删除：engines/audit_enforcer.py、根目录 audit_enforcer.py、audit_enforcer_runtime.json、3 处 audit_enforcement_log.json、2 处 audit_trade_block.json；portfolio_engine 阻断校验；update.sh 迁移项；页面静音按钮、执行器面板、"止损强平确认"弹窗 (原按钮只有 console.log)。
- 同一时点改前/改后对比：可信度 75→71；风控 59（自算）→ 合规结论"阻断"（主题集中度 86%>60% 硬阻断、仓位 96% 超 AIAE 矩阵上限 63% 达 33pp 硬阻断、组合波动预算软警告）；策略健康 58→55（ERP 30 分移出，DIV/MOM 由旧证据 70 改为执行总览口径 60）。
- 两项风险检查由失败改为非计分（已向用户说明）：旧"止损合规"（成本价静态线 14 只破线）改以跟踪止盈引擎为准（10-30 日终 RED 2 只：仕佳光子、生益科技）；旧"相关性集中度"（93.5%）改为补充读数，集中度红线以合规引擎主题集中度为准（本次为硬阻断）。
- 测试：新增 tests/test_audit_page_scope.py；改写策略健康评分测试；删除 ERP 旧证据与执行器测试。用户本机相关 8 个测试文件 121 passed。

### 待确认（已在方案 B 处理，见下）
- 合规引擎重启后读不到刹车/越线缓存会放行加仓方向 → B 改为回落到日终快照。
- 记账"单票超过 20% 拒绝" → B 删除。

## 深度审计页 · 方案 B：结构调整（2026-11-02）
- 页面拆为两个独立读数：A 系统可信度 = 数据新鲜度 / 引擎运行 / 参数证据 / 系统状态 四项等权 (25%)；一票否决 = AIAE 数据新鲜度、合规引擎运行、ERP v4 前向记录（连续缺 ≥2 个交易日），任一失败 A 直接判失败，否决项不参与平均。B 组合合规 = 合规引擎结论（通过/警告/阻断/不可用），不打分、不进入 A。删除"可信度总分"及 35/25/20/10/10 权重。
- 引擎运行 = 因子引擎三项 + 合规/漂移模块就绪；系统状态 = Tushare/数据湖/依赖/ECharts/服务进程/事件日志。
- 决策缓存陈旧时合规结论会被撤回；审计改为同步重算一次 (与决策页同一函数)，不再显示"不可用"。
- 审计历史：audit_log 新增 schema_version / trust_status / compliance_status / trigger（幂等迁移）；trust_score 记 A 分数，分组得分与否决项写入 summary_json；旧五维列不再写入。schema_version 为空的旧记录 = 旧口径，与新记录不可比（断点 2026-11-02）。页面趋势改用新存储键重新累积。
- 合规引擎：drawdown_brake / trailing_stop_report 缓存缺失时回落到 data_lake/trailing_snapshots 最近日终快照（仍按 as_of 判过期），消除服务重启后的放行。测试用 conftest 自动屏蔽真实快照。
- 记账：删除 portfolio_engine.add_position 的单票 20% 拒绝（单票上限只在合规引擎下单环节拦截）。
- 删除根目录兼容转接 audit_engine.py（全仓无引用）。audit_core.js 保留：个股深研页 (比亚迪/深南电路/中芯国际) 在用，不是死代码。
- 本机实测（22:37）：A 83 · 需关注（数据新鲜度 85、引擎运行 99、参数证据 55、系统状态 95；三项否决均通过）；B 阻断（主题集中度 86% 与仓位超限 33pp 两条硬阻断、组合波动预算软警告；越线/回撤刹车为减仓豁免只读；账户回撤 31.5% 三档、止损 RED 2 只为只读读数）。改后打开页面未写审计历史（最近一条仍为改前 21:01）。桌面 1440 与手机 375 无横向溢出、无脚本错误。
- 一致性 (#8)：审计页组合合规与决策中枢风险栏读同一快照的同一 compliance 对象；仓位数字公式与决策页相同。未处理：决策页风险矩阵"板块集中度"按行业/持仓合计计算，与合规主题口径不同（不在本轮范围）。
- 遗留：组合波动预算 (vol_budget) 只在内存缓存，服务重启后到总览重建前该软警告规则按"无数据"放行，暂无持久化快照可回落。视觉打磨（卡片排布、雷达/仪表盘配色）留到下一轮。

## 风险状态统一读取 · 重启后放行修复（2026-11-02）
- P0（已推送 b7479df）：执行层只从内存缓存读回撤刹车，本机无 Redis 时服务重启到下一次日终提交之间上限瀑布缺"回撤刹车"一档，唯一仓位数字被放宽（实测有效上限 63% 而非 25%）。新增 services/risk_state.py 统一读取：回撤刹车/跟踪止盈状态 = 缓存 → data_lake/trailing_snapshots 最近日终快照（过期仍按 as_of 判定）；执行层、合规引擎、审计页三处改为经此读取。重启后本机实测：瀑布 AIAE 63 → 市场 63 → 波动预算 65.8 → 回撤刹车 25 → 有效 25，执行目标 25（约束来源=回撤刹车），风险事件 drawdown_brake。同提交补上 B 漏写的"审计遇陈旧决策缓存同步重算合规"。
- 组合波动预算：risk_state.vol_budget = 缓存 → 按本地持仓与行情当场重算（与总览构建同一函数）并回写缓存；合规规则"组合波动预算"重启后不再按"无数据"放行。
- 集中度口径统一：决策页风险矩阵的持仓集中度改为调用合规引擎 _theme_buckets（ETF 穿透、占账户总资产），红线 40% / 硬阻断 60% 从合规引擎读取，前端不再写死；标签"实际持仓 · 合规主题口径 (占账户)"。无持仓时的候选信号分布保留并标注"候选信号 (非持仓)"。旧口径（按行业、以持仓合计为分母）删除。
- 测试隔离：conftest 自动屏蔽真实日终快照与波动预算重算；新增执行层重启场景、缓存优先、波动预算重算、风险矩阵与合规同数 4 项测试。
- ERP 缓存新鲜度误判（本机）：本机 data_lake 有离线研究产物 erp_allocation_price.parquet（2026-10-25 生成、线上不刷新），被计入"核心缓存"导致判失败；服务器无此文件、同代码判通过。新鲜度检查排除 _allocation_ / _research / _validation 研究产物，核心 PE/收益率/利率文件仍照常检查。
- 阿里云部署 (f8e6b11) 后实测：A 87 可信（三项否决通过）；B 阻断；执行目标上限 AIAE 63 → 波动预算 65.8 → 回撤刹车 25 → 有效 25；账户回撤 28.6% 三档；止损已触发未执行 3 只（胜宏科技、仕佳光子、生益科技）。服务器日终数据比本机新（本机停在 10-30）。

## 深度审计页 · 视觉改版（2026-11-02）
- 范围：只改视觉，口径与评分逻辑不变（四项等权、否决规则、合规引擎结论、接口原有字段与数字均未改）。用户确认问题表 a–d：删除仪表盘与雷达图（与四项分数重复）、删除 5 个 KPI 卡（全部重复）、删除告警横幅（A/B 失败项已在首屏分列）、B 规则行不再显示 100/40/70 分数，改为状态标签（B 本就不计分，接口字段保留）。
- 版式：标题行（深度审计 · 只读 · 接口版本号 · 审计时间/耗时；保存/重新审计放在顶栏操作区，与其他页一致）→ 首屏左 A 系统可信度、右 B 组合合规并列 → A 四项一行 4 列（≤1200px 为 2×2），点卡片展开明细，默认展开最差项 → B 单独成块：判定来源 + 合规规则 (9) + 只读读数 (3)。
- 一票否决：触发时 A 块红框加左栏，主数字换成"否决"，均分缩为"仅供参考，不作判定"，触发项整行标出。否决阈值写成常量 `engines/audit_engine.py`：`ERP_V4_GAP_TOLERANCE_DAYS=1`（缺 1 个交易日 = 正常延迟 → 警告，不否决）、`ERP_V4_GAP_VETO_DAYS=2`（连续缺 ≥2 = 断档 → 否决）、`VETO_RULES`（三项的通过/警告/否决文案；AIAE 新鲜度与合规引擎运行无容忍区）、`TRUST_PASS_MIN=85`/`TRUST_WARN_MIN=70`；判定行为与改前相同。接口 `system_trust` 新增只读字段 `veto_rules`、`status_rules`（追加，不改原字段）。页面逐项显示阈值；否决项在容忍区（警告）而 A 仍为"可信"时，A 块下方固定显示说明"否决项在容忍范围内（警告），未触发否决…越过容忍区即否决"。
- 只读读数与计分行区分：B 分"合规规则"与"只读读数（不判定、不计分）"两组；读数行浅底、虚线分隔、无分数条；减仓豁免两条规则标"豁免·只读"。
- 颜色：全部集中在 `static/css/audit.css` 的 `:root` 变量；状态色只用于状态（`--status-pass/warn/fail/info`），阻断/否决单独定义 `--status-block*`，不复用涨跌色；涨跌色 `--au-up/--au-down` 保留红涨绿跌定义（本页暂无涨跌数据）。分数、等级、进度条改中性色。JS 不再内联任何颜色（只输出 class）。
- 去掉：emoji（页面主体）、渐变、毛玻璃、发光、重阴影、大圆角、背景光球、扫描线、脉冲/呼吸动画、数字滚动动画（改为直接显示终值）、hover 位移；ECharts 不再加载。接口文案中的绿/黄/红圆点改为 CSS 色点。快照时间按北京时间显示（带时区的换算，不带时区的标"未标时区"）。
- 审计趋势：本轮隐藏（原读浏览器本地存储，每打开一次页面记一个点，与服务端审计历史口径冲突）。
- 侧边栏/顶栏：顶栏结构不变；侧边栏为全站 `sidebar.js` 统一渲染，本页不单独改（只清掉硬编码副本里的内联颜色）。
- 验证（云端暂存副本，Playwright 用改前同一份接口数据渲染）：桌面 1440 与手机 375 无横向溢出、无脚本错误；手机首屏同时可见 A 分数与 B 结论；另用模拟数据（ERP v4 缺 2 个交易日）截"否决触发"状态。`node tests/test_audit_frontend.cjs` 通过（新增静态检查：主体无 emoji、JS 无内联颜色、CSS 颜色只在 :root、无渐变/毛玻璃/循环动画、`--status-block` 已定义、仪表盘/雷达/本地趋势/KPI/横幅已移除、否决阈值说明存在）。`tests/test_audit_page_scope.py`：改前 27 过 2 败、改后 28 过 2 败，失败的 2 项改前改后相同，均为云端缺模块（`data`、`aiae_params`），新增"否决阈值常量与接口字段"用例通过。全量 pytest 需本机复跑。
- 待办（另开一项）：① ~~审计趋势改读服务端审计历史~~（已完成，见下节）；② ~~侧边栏全站去 emoji~~（已完成，见"全站导航去 emoji"一节）。

## 深度审计页 · 审计趋势改读服务端历史（2026-11-02）
- 决策（用户委托"科学决策"）：趋势只读服务端 `audit_log`，不再用浏览器本地存储。
  - 口径一致：只取 `schema_version` 等于当前 `AUDIT_SCHEMA_VERSION` 的记录。旧口径（schema_version 为空，含风控的"可信度总分"）与其他口径版本只计数，在页面上注明"已排除 N 条"，不画进趋势；口径版本一变，趋势从断点重新累积。
  - 采样一致：每个日期一个点。同日优先 16:45 每日定时记录（trigger=daily），没有定时记录时取当天最后一次手动保存；手动点画空心，以示区别。打开页面不写历史（与方案 A 一致）。
  - A/B 分开：A 线 = A 系统可信度（纵轴虚线标出 85/70 分界，取自后端常量；否决日用菱形加阻断色，不只靠颜色区分）；B 只画状态条（通过/警告/阻断/不可用），不计分、不画成分数线。
  - 少于 2 个日期时不画线，只显示记录表与说明（记录来源：16:45 定时或"保存审计"）。
- 改动：`services/db/alerts.py` 新增 `get_audit_trend(schema_version, days)`（只读，每日去重）；`routers/audit.py` 新增 `GET /api/v1/audit/trend?days=7–90`（返回 points、排除条数、分界 thresholds）；原 `/audit/history` 不变。页面趋势区用内联 SVG（不加载 ECharts），颜色全部走 audit.css 变量；"保存审计"成功后刷新趋势。字段名用 `a_score`（列名仍是 trust_score），避免和旧"可信度总分"混淆。
- 测试：新增 `test_audit_trend_only_current_schema_one_point_per_day`（旧口径/其他版本排除计数、同日定时优先、无定时取最后一条、否决项透传）；`test_audit_frontend.cjs` 增加趋势读服务端接口的检查。云端：audit_page_scope 29 过 2 败（2 项为云端缺模块，与前一轮相同）；前端测试通过；用模拟 8 日数据与单日数据渲染 1440/375，无横向溢出、无脚本错误。
- 注意：新接口需要重启服务后才可用；未重启时页面趋势区显示"读取失败（需重启服务）"，不影响 A/B 主体。

## 全站导航去 emoji（2026-11-02）
- 范围：全站统一组件 `static/js/sidebar.js`（侧边栏 + 手机底部 Tab 栏），所有页面都经它渲染，一处修改全站生效。只改图标与徽章样式，导航项、分组、链接、顺序不变。
- 图标：emoji 改为单色线性 SVG（`stroke=currentColor`，颜色跟随导航文字与激活态，不新增颜色）：总览=面板格、因子=折线、产业=厂房、策略=调节杆、回测=回溯、海外=地球、决策=靶心、简报=文档、审计=盾牌对勾、个股深研=文件夹、组合=公文包；个股深研子项用小圆点；展开箭头 ▶ 与收起按钮 ◀ 也换成 SVG（这两个字符在 Windows 上可能按彩色 emoji 渲染）。
- 个股深研 7 个 "DEEP" 徽章去掉内联彩色，统一用 `.badge-beta` 样式。
- 新增 `static/css/sidebar.css`（由 sidebar.js 与 mobile.css 一同动态加载）：图标尺寸、收缩态与平板（≤1024px）居中；顺带修正平板收缩态下"个股深研"父项未居中（原样式只覆盖了 nav-item）。
- 缓存：17 个页面的 `sidebar.js?v=` 各 +1，避免浏览器继续用旧脚本。各页 HTML 里硬编码的旧侧边栏副本仍带 emoji，但 sidebar.js 加载时会整体替换；本轮没逐页删除（风险大、收益小，页面加载完成后不可见）。
- 测试：新增 `tests/test_sidebar_frontend.cjs`（无 emoji/▶◀、无内联颜色与写死颜色、引用的图标都有定义、sidebar.css 随组件加载）；用旧 sidebar.js 跑该测试会失败（已验证测试有效）。云端渲染审计页：桌面 1440 展开/收缩、平板 1000、手机 375 底栏，侧边栏与底栏 emoji 数为 0，无内联样式，无脚本错误。
- 未做：右下角 AI 助手悬浮按钮（`ai_assistant.js`）与各页面内容区的 emoji 不属于导航组件；侧边栏底部的头像仍从外部站点 pravatar.cc 加载，后续可换成本地占位。

## 决策中枢精简 · 审计与方案（2026-11-02）
- 方案：`docs/DECISION_HUB_SLIMMING_PLAN.md`（09:12 用户确认，第 8 节为确认修订）；改前基线：`docs/DECISION_HUB_BASELINE_20261102.md`，截图存仓库外 `D:\FIONA\alphacore_baselines\20261102\`。
- 原则：决策中枢只回答"今天该怎么做"；AIAE 执行目标是唯一仓位数字，合规引擎是唯一风险判定，跟踪止盈是唯一止损执行入口，JCS/AIAE/ERP/海外读数只作背景。
- 实施顺序：C1 门控 → C2 隐藏开关与下线 → C3 1a 结构 → C4 宏观背景 → C5 执行区（波动预算瀑布 + 降仓路径）→ C6 复盘标签 → C7 规则文档 → C8 日报口径 → C9 合规文案 → C10 关闭 JCS 低分告警推送。每步单独提交，核对执行目标 / 合规结论 / 跟踪止盈三项数字不变。
- 1b/1c 视觉轮次暂停，精简完成后按新结构重新规划。

### C1 · 调仓路径门控（2026-11-02）
- 问题：`GET /api/v1/decision/optimize-path` 直接用 BL 优化权重生成分批调仓路径，绕过了 `/position-path` 的 `create_order` 门控（服务端恒不授予下单权限）。
- 改动：`routers/decision.py` 新增 `_order_path_gate()`，`/position-path` 与 `/optimize-path` 共用。未授权时 `/optimize-path` 不运行优化、不生成路径，返回与 `/position-path` 相同的阻断结构（`path: null`）。`optimizer.js` 遇到阻断响应改为提示，不再按路径渲染（v=53）。
- 测试：新增 `tests/test_order_path_gate.py`（阻断时不调用优化器和路径生成；两接口阻断文案一致）。云端暂存副本无法安装依赖（PyPI 不可达），只做了语法检查；pytest 需在本机运行。
- 排查：其他未门控的调仓 / 下单类接口见方案第 9 节。`/optimize`、`/portfolio/rebalance` 在 C2 随页面隐藏，建议后续加同一门控；手动 MR 计划不检查合规硬阻断，另开一项。
- 关键数字：此改动不涉及 /hub、合规、跟踪止盈计算。

### C2 · 模块开关与下线（只隐藏，2026-11-02）
- 新增唯一开关 `config/decision_modules.json`（每项含 label / hidden_on / reason / restore_if，review_on 2026-11-30），由 `services/decision_modules.py` 读取。配置缺失或损坏时全部按开启处理；执行 / 合规 / 跟踪止盈三个核心模块不受开关控制。接口为只读的 `GET /api/v1/decision/modules`。
- 前端：`static/js/decision/modules.js` 先于各面板脚本加载，关闭的面板加 `.dm-off` 隐藏，各加载入口通过 `DM.on()` 判断后不再发请求。没有删除任何代码。
- 本步隐藏 17 项（隐藏日期 2026-11-02，恢复条件见配置）：全球温度 + 风险传染、多资产雷达、波段守卫、AI 叙事、NLP 情报、V5 配额·压力测试、情景模拟器、组合优化标签、尾部风险、风控绩效 + 近 2 年绩效、相关性热力图 + MCTR、Jaccard、板块集中度、Brinson、漂移监控、复盘日历标签、参数对比按钮。
- 后台：波段守卫关闭后，`warmup_swing_guard` 直接跳过，15:35 DAG、15:40 定时和启动预热三处入口一起停。NLP 情报的 09:35 / 15:15 任务保留，供首页使用。全球温度仍在 /hub 内计算，日报在用，C8 处理。
- 承接：MCTR 由组合页承接；持仓相关性由审计页「相关性簇 / 有效独立敞口」承接；漂移由策略页承接；信号准确率 T+5 和准确率仪表板暂留风险矩阵标签，C6 移到复盘。
- 测试：新增 `tests/test_decision_modules.cjs`（加载顺序、关闭项都有选择器且元素存在、核心面板不受控、各加载入口有开关判断、接口失败按开启处理）和 `tests/test_decision_modules.py`（配置故障全开、核心不可关、波段守卫关闭时预热不写缓存、接口只读）。云端已跑前端测试：decision_modules、jcs_frontend、multi_asset_frontend、freshness_bar、sidebar 全部通过；pytest 需在本机运行。

### C3 · 1a 结构：共用变量 + 模块顺序 + 今日结论（2026-11-02）
- 共用变量：`decision.css` 的 `:root` 新增 `--dc-*`（表面、线、文字）和状态色 `--status-pass/warn/fail/block/info`，与审计页同值。阻断色 `--status-block` 单独定义，不复用失败色或涨跌色。
- 模块顺序（只调结构，不改口径、数字和接口）：今日结论 → 执行（AIAE 执行目标，从 JCS 双栏中拆出，置顶）→ 合规 → 跟踪止盈 → 仓位调整路径 → 波动率预算 → 分隔线「背景 · 不作执行依据」→ JCS 读数 → AIAE 面板 → 市场动态 → 已隐藏模块 → 参考手册。
- 今日结论：执行目标仓位（附当前仓位）· 合规状态（N 条硬阻断）· 止损已触发未执行 N 只；三项都可点击跳转。数据通过事件取自执行区、合规面板、跟踪止盈面板的同一次加载结果（`ac:action-plan` / `ac:compliance` / `ac:trailing`），`today_summary.js` 自己不发请求、不计算。「已触发未执行」= 跟踪止盈 summary.RED（已触发、次日开盘卖出）。
- 测试：新增 `tests/test_today_summary.cjs`（不发请求、跳转锚点存在、模块顺序、三项文案与状态）。云端前端测试 jcs_frontend、decision_modules、today_summary、multi_asset、freshness_bar 全部通过。

### C4 · 合并：宏观背景（2026-11-02）
- AIAE 宏观仓位面板、市场动态、JCS 读数合并为一个「宏观背景」折叠面板（`#macro-bg-panel`，默认折叠），位于分隔线「背景 · 不作执行依据」之下。三块内部结构和渲染逻辑不变，只是挪到同一个面板里。
- 折叠行摘要写全名称和单位：「AIAE 配置比例 24.4%（R3 档）· JCS 56.8 一般」，避免与执行目标仓位混淆。展开时按实际宽度重绘 AIAE 仪表（折叠期间初始化的宽度为 0）。
- 删除 AIAE 面板标题里的「权重35%」。
- 不改：AIAE 分档条、中性色阶等视觉（属于 1c，暂停中）；JCS 口径与数字不变。
- 测试：`tests/test_today_summary.cjs` 增加宏观背景包含三块、默认折叠、无「权重35%」的检查。jcs_frontend 的 JCS 区段检查不受影响（区段边界不变）。

### C5 · 合并：执行区（约束瀑布 + 降仓路径 + 分批状态）· 降仓节奏统一（2026-11-02）
- 执行区新增三块，数据只取后端已有字段：
  - 「执行目标从哪来」：读 `action_plan.constraints`（AIAE 矩阵上限 / 市场尾部刹车 / 组合波动预算 / 组合回撤刹车，最严约束标出）→ = 执行目标。
  - 「降仓路径」：当前仓位 → 执行目标、差额（`execution_gap`）、约 ¥ 金额（回撤刹车降仓清单 `execution.reduce_amount`）、节奏（`execution_layer.reduce_days`）。"每日约 X pp" 只是差额 ÷ 天数的换算。
  - 分批调仓路径状态一行：下单权限关闭时显示"未获批，暂停生成"。
- 波动率预算面板、仓位调整路径卡片并入执行区后，在模块开关里关闭（`vol_budget`、`position_path`，隐藏日期 2026-11-02）。两者都不再单独请求；引擎、合规规则、`/position-path` 接口都保留（组合页在用）。
- 降仓节奏统一（用户决定）：只保留"分 3–5 个交易日"一个说法，唯一来源是 `aiae_params.EXEC_PARAMS["reduce_days"]`。执行层结果新增结构化字段 `reduce_days`；回撤刹车降仓清单说明由"金额大可分 1–3 个交易日"改为"分 {reduce_days} 个交易日完成（与 AIAE 执行层节奏一致）"。目标、档位、金额都不变。
- 测试：新增 `tests/test_exec_path.cjs`（换算与文案、不读 JCS、不写死 1–3 天、HTML 转义）和 `tests/test_reduce_pace_unified.py`。

### C6 · 复盘标签（2026-11-02）
- 标签「决策时间线」改名为「复盘」，包含三部分：
  - 执行目标 vs 实际仓位：新增只读接口 `GET /api/v1/decision/exec-vs-actual`（`services/exec_history.py`）。执行目标取自执行层前向记录（评估日 / 风险事件日写入，其余日沿用）；实际仓位取自跟踪止盈日终快照 `drawdown.invested_pct`。执行层 2026-10-30 上线，之前的日期不回填。图为阶梯线（目标）加虚线（实际），配表格和目标变更记录。
  - 背景读数验证（默认折叠）：原风险矩阵的「信号准确率 T+5」「准确率分析仪表板」移入，标明不作执行依据。
  - 跳转链接：组合页「决定记录与复盘」（`/portfolio.html#pf-decision-zone`）。
- 旧「近 30 天 JCS 与仓位趋势」由开关 `timeline` 关闭：图中的"建议仓位"是 AIAE 矩阵上限，不是执行目标。`decision_log` 写入保留，准确率、告警、日报仍在用。
- 口径说明：实际仓位（快照，回撤刹车口径）与执行区"当前仓位"的分母相差约 0.1–0.3pp，页面已注明。
- 测试：新增 `tests/test_review.cjs`、`tests/test_exec_history.py`。

### C7 · 决策规则合并为唯一文档（2026-11-02）
- 新增 `docs/DECISION_RULES.md`。第 1 节为现行规则：执行目标、偏离分区与"分 3–5 个交易日"节奏、合规 9 条规则、跟踪止盈执行规则、背景读数定位，各条注明代码出处。第 2 节逐条核对原「决策参考手册」和「风险管理 SOP」的每一条，标为保留 / 改口径 / 废止并写明原因。
- 原手册中与已定规则冲突的条目全部废止：按 JCS 分档加减仓、"减至建议仓位"、尾部风险分数分档、权重表（含已移出的 MR）、波段守卫复查、指数绩效健康基准等。
- 页面：参考手册卡片、风险 SOP 卡片、已经清空的风险矩阵标签由开关关闭（`ref_manual` / `risk_sop` / `risk_tab`）；在宏观背景下方和复盘标签底部各留一个文档链接（GitHub 仓库路径 `quant_dashboard/docs/DECISION_RULES.md`）。
- 测试：新增 `tests/test_rules_doc.cjs`（合规规则名全部出现在文档中、节奏统一、页面链接、开关关闭）。

### C8 · 日报口径修正（A，2026-11-02）
- `dashboard_modules/report_generator.py`：
  - 执行摘要中「AIAE 矩阵上限 61%」行改为「执行目标（唯一仓位数字）」和「当前仓位」，AIAE 档位标为背景。
  - 叙事去掉"对应 AIAE 矩阵上限""仓位目标上调 / 下调 X%"，改为"仓位以 AIAE 执行目标 X% 为准"。档位和 VIX 描述只写环境，不写操作。尾部风险段落不再写"降至建议水平的 70%"，改为"仓位以执行目标为准、风险以合规为准"。
  - 「四引擎信号面板」权重表（AIAE 35 / ERP 25 / VIX 20 / MR 20）删除，换成「宏观背景读数（不作执行依据）」：AIAE 配置比例、ERP、VIX、JCS，无权重、无 MR。
  - 全球市场附录去掉「建议仓位」「操作」两列，标题改为"全球市场读数（背景，不含仓位或操作建议）"。
  - 合规声明改为"仓位只引用 AIAE 执行目标，风险判定以合规引擎为准；其余读数只作背景"。
  - 历史回看：去掉矩阵上限和 MR，注明执行目标历史见复盘标签。
  - LLM 提示词：去掉矩阵上限、MR、引擎方向计数和昨日仓位；加入执行目标、当前仓位、合规结论；要求"不得给出新的仓位数字、加减比例或买卖建议"，替换原"最后一段必须给出明确的操作建议"。
  - 摘要字段新增 `execution_target`；`suggested_position` 作兼容字段保留并注明只作背景。
- 测试：新增 `tests/test_daily_report_scope.py`（日报、提示词、历史回看均不出现被禁内容）。用模拟数据渲染过一份，结果符合要求。
- 注意：日报改动需要重启服务后生效；16:35 定时日报和 report.html 用同一段代码。

### C9 · 合规「仓位超限检查」文案（B，只改文案，2026-11-02）
- `engines/compliance_engine.py`：文案改为「AIAE 矩阵上限 61%；当前执行目标 25%（受回撤刹车约束）。当前仓位 96% 超过矩阵上限 35pp，禁止加仓；降仓目标与节奏以 AIAE 执行目标为准……」。执行目标读执行层状态；最严约束通过和回撤刹车上限、组合波动预算上限比对来标出，比对不上时不标；执行目标不可用时写"当前执行目标不可用"。
- 判定逻辑不变：仍是"实际仓位超过 AIAE 矩阵上限 10pp 即硬阻断"。判定基准是否改为执行目标另开一项评估，要避免和回撤刹车规则重复阻断。
- 测试：新增 `tests/test_compliance_wording.py`（文案、判定阈值不变、约束标签三种情况）。

### C10 · 关闭 JCS 低分告警推送（D，2026-11-02）
- `services/alert_monitor.py`：`jcs_low` 规则加 `enabled: False`，扫描时跳过已关闭的规则。JCS 低分不再写入告警表，也不推送 Server酱、邮件或企微。规则定义保留，恢复时删除该字段即可。其他告警（VIX、Regime 切换、尾部风险）不变。
- 测试：新增 `tests/test_jcs_alert_disabled.py`（规则保留但关闭；JCS = 12 时扫描不写入、不触发，VIX 告警照常触发）。

### 本轮精简后的待办（2026-11-02）
- ~~【高】C 首页口径~~（已完成，见「首页口径统一」A1–A3，2026-11-02）：`services/concentration.py` 集中度分母为"权益"，合规为"账户"，阈值同为 40%；首页"可执行上限"（`assemble_response` 调 `build_decision_view` 时未传回撤数据）不含回撤刹车。两者都要与决策中枢统一。
- ~~合规「仓位超限检查」判定基准是否改为执行目标~~（已完成：用户决定改为执行目标，见「首页口径统一」B，2026-11-02）。
- ~~重启后预热期 /hub 结果被缓存：收盘后缓存时长 300s × 4 = 20 分钟，合规在这段时间内可能多出"数据缺失即阻断"的条目（安全方向，但会误导核对）。建议冷启动结果不缓存或缩短缓存时长。~~（已完成，见「预热期读数缓存」一节）
- ~~手动 MR 计划（`/analysis/mr/{code}/preview`）买入方向不检查合规硬阻断和执行目标：建议加"合规禁止加仓"阻断。~~（已完成，见「买入合规门控」一节）
- ~~`/decision/optimize`、`/portfolio/rebalance` 仍会输出逐只调仓建议（页面已隐藏）：建议加同一门控，或改为只读研究读数。~~（已完成，改为同一买入门控：加仓行标为合规阻断，减仓保留，见「买入合规门控」一节）
- ~~告警文案仍带操作性措辞："Regime 切换 → 建议调整至新 Regime 对应水平""尾部风险 → 降仓至 70% 建议水平"。建议改成以执行目标和合规为准，或下线尾部风险告警。~~（已完成，见「告警文案口径」一节）
- 观察期：隐藏模块观察到 2026-11-30（`config/decision_modules.json` 的 review_on），到期由用户决定是否彻底删除。
- 1b/1c 视觉轮次：按精简后结构重新规划（今日结论、执行区、合规、跟踪止盈、宏观背景、复盘）。
- 补记（C8 测试修正，2026-11-02）：本机全量 pytest 1737 通过、1 失败。失败的是 `test_ai_prompt_forbids_new_position_numbers`：本机真实事件日志里有"MR 技术面切换"这类背景事件，进入了提示词，而该测试断言提示词中不出现字符串 "MR"。测试改为隔离事件日志，并把断言精确到"MR 技术面读数""四引擎方向计数""61%"。日报代码本身未改。

### 修复 · AIAE 报告 500（当日换手率 NaN，2026-11-02，与精简无关）
- 现象：策略页「AIAE 仓位管控」无数据，`/api/v1/aiae/report` 和 `/aiae/refresh` 返回 500；本机与服务器（C3）相同。
- 原因（本机诊断已确认）：`engines/hf_proxy_engine.py` 计算换手率 Z-Score 时，当日 daily_basic 尚未发布，中位数为 NaN。`tanh(NaN)` 经 `max/min` 截断后变成 **+1.0**，被当作"换手率极高"计入 HF Delta（今日 +1.411pt 中约 +1.05pt 来自这个错值）；同时 `latest_turnover`、`zscore` 两个 NaN 写进报告，JSON 序列化失败导致 500。
- 修复：跳过非有限值，以最近一个有效交易日为 latest；Z-Score 非有限时该子指标判为失败，权重按原逻辑在剩余指标间重新归一。HF 估算只用于展示和因子趋势记录，不参与 AIAE 分档、矩阵上限或执行目标。
- 测试：新增 `tests/test_hf_turnover_nan.py`。诊断脚本放在仓库外：`D:\FIONA\alphacore_baselines\diag_aiae_report.py`（只读）。

## 错误操作 / 错误数字防线三项（2026-11-02）
- 范围：待办中三项"错误操作或错误数字会传到用户面前"的问题，每项单独提交。已定规则不变：AIAE 执行目标是全站唯一仓位数字；合规引擎是唯一风险判定；跟踪止盈是唯一止损执行入口；JCS/AIAE/ERP/海外读数只作背景。
- 本轮无本机命令行：代码在云端副本修改、测试后写回本机；提交由用户执行；核对通过内置浏览器读本机服务的只读接口。
- 关键数字基线（改前 17:25 UTC）：执行目标 25%（当前 96.2%，分区 reduce）；合规 blocked —— 硬阻断「主题集中度」「仓位超限检查」，警告「组合波动预算」；跟踪止盈 RED 2 / YELLOW 1 / GREEN 13，回撤刹车三档。三项改动后每次重启复核，均与基线一致。

### 买入合规门控（提交 b8fe6ec）
- 问题：手动 MR 计划（`strategy.html` → `personal_analysis.js` → `GET /analysis/mr/{code}/preview` → `POST /analysis/plans`）只查 MR 自身限额，不读合规引擎；合规硬阻断时仍能确认买入计划。`full_optimize` 合规调用异常时默认 status=passed（失败放行）；`/portfolio/rebalance` 的 BUY_SIGNAL 不查合规。
- 改动：新增 `services/compliance_gate.py: buy_gate()`。在决策中枢同一账户快照上（`decision_engine._account_inputs()`，自 `get_hub_data` 抽出，逻辑不变）以 direction="increase" 运行合规引擎（`compliance_for_direction`）。硬阻断 → 拒绝（COMPLIANCE_HARD_BLOCK）；合规异常 / unknown / 无结论 → 默认拒绝（COMPLIANCE_UNAVAILABLE）；仅警告 → 放行并显示。卖出 / 减仓不调用门控。
  - 按买入方向判定只会更严：页面合规按执行方向（降仓）判定时，「组合回撤刹车」「越线禁止加仓」放行、「AIAE 过热」R4 不拦；买入方向下均阻断。
  - MR 计划：买入预览加入门控结果（逐条列出阻断规则名与原文），合规结论进入快照指纹（合规变化后确认须重新预览）；确认被拒时提示"计划被合规门控拒绝"。
  - 组合优化（`/decision/optimize`、`/optimize-custom`）：改用门控，未放行时加仓行标为 blocked（页面显示"合规阻断"），减仓行保留；去掉失败放行。`/optimize-path`、`/position-path` 已在 C1 门控，不变。
  - 调仓指令（`/portfolio/rebalance`）：未放行时 BUY_SIGNAL → BLOCKED，卖出指令不变；压力测试（假设档位情景）不经门控。
- 排查清单（不门控的入口及理由）：成交登记 `/slippage/orders`、交割单 / 持仓导入（记录已发生成交）；决定记录 `/analysis/journal`、观察记录（记录本人决定）；`/portfolio/trade` 只在 legacy 模式开放且有下单权限门控。
- 测试：新增 `tests/test_compliance_buy_gate.py`（硬阻断拒绝且列出规则、不可用默认拒绝、仅警告放行、按买入方向、卖出不调用门控、合规变化使快照失效、优化器/调仓只拦买入、优化器不再失败放行；在旧代码上 15 条失败）；`test_manual_decisions.py` 夹具默认放行门控；前端 `test_personal_analysis_frontend.cjs` 增加门控渲染断言。本机相关测试 111 通过。
- 真实账户核对：MR 买入核查（159995.SZ）被拒，合规硬阻断 4 条（主题集中度、仓位超限检查、越线禁止加仓、组合回撤刹车）；卖出核查门控显示"不受限"。

### 告警文案口径（提交 29dd91c）
- 原则：告警、推送、行动项中仓位一律引用执行目标（`aiae_execution.target_text()` → "AIAE 执行目标 25%"），不再出现其他仓位数字或加减仓建议。告警表中已有历史告警不改写。

| 位置 | 渠道 | 修改前 | 修改后 |
|---|---|---|---|
| 尾部风险告警 | 告警表 + Server酱/邮件/企微 | 建议：降仓至70%建议水平 + 严格止损 | 处于危险区间（启发式读数，只作背景）。仓位以 AIAE 执行目标 T% 为准，止损以「持仓跟踪止盈」为准 |
| Regime 切换告警 | 同上 | 建议审查仓位是否需要调整至新 Regime 对应水平 | AIAE 档位切换为 Rn（背景读数，不直接调仓）。仓位以 AIAE 执行目标 T% 为准，执行层按规则重新评估 |
| VIX 极端恐慌告警 | 同上 | 触发全策略风控降权。规则: 仓位上限30%，禁止新建仓 | 合规「VIX 紧急刹车」生效：禁止加仓。仓位以 AIAE 执行目标 T% 为准 |
| VIX 恐慌告警 | 同上 | 注意仓位风控 | 合规「VIX 紧急刹车」生效：暂停加仓；仓位以 AIAE 执行目标 T% 为准 |
| 回撤刹车推送 | 同上 | 标题「组合回撤 x% · 三档 · 降至 25%」；正文「仓位上限 25% (当前 96%), 需降仓约 ¥…」 | 标题「组合回撤 x% · 三档」；正文「回撤刹车生效: 禁止新增买入。仓位以 AIAE 执行目标 T% 为准 (当前 96%); 回撤刹车降仓清单约 ¥…」 |
| 回撤刹车行动项 | 跟踪止盈面板 | 标题「组合回撤刹车 · 三档 · 降至 25% · 降仓 ¥…」；正文「仓位上限 25%, 当前 96%…执行后仓位约 25%」 | 标题「组合回撤刹车 · 三档 · 降仓 ¥…」；正文「仓位以 AIAE 执行目标 T% 为准, 当前 96%。回撤刹车降仓清单约 ¥…」 |
| 回撤预算行动项 | 跟踪止盈面板 | 回撤预算: 当前结构下仓位宜 ≤ 40% / 对应仓位上限 40% | 回撤预算偏紧 (风险读数)；不另给仓位数字，仓位以 AIAE 执行目标为准 |
| ERP v4 分档变化 | 告警表（原同时推送） | ERP v4 分档上调 65% → 80%；目标仓位 70%，按每周 +5pp 分批加仓 | ERP v4 读数分档上调（背景读数）；ERP 只作背景，仓位以 AIAE 执行目标为准 |
| ERP v4 分批 | 同上 | ERP v4 进入分批加仓；目标仓位 X%，分档 Y% | ERP v4 读数进入分批阶段（背景读数）；同上说明 |
| ERP v4 利率正常化 | 同上 | …分档 Y% | 删去分档数字；同上说明 |
| 决策页警示（含日报「风险与警报」） | 页面 + 日报 | VIX≥35→仓位上限30% / 熔断→仓位归零 / ≥3引擎看空→降至防御仓位 / R5→仓位上限15% | 引用对应合规规则名（VIX 紧急刹车 / AIAE 过热限制）或注明背景读数 + 仓位以 AIAE 执行目标为准 |
| 漂移监控 R5 / R1 / 逼近切换 | 策略页 | 建议仓位 ≤15% / 建议分3批建仓至60-80% / 仓位变动约 ±X%，建议提前准备调仓方案 | 背景读数；合规「AIAE 过热限制」禁止建仓 / 买入须先通过合规门控 / 仓位以执行目标为准（删去档位-仓位对照表与 position_impact 字段） |
| 再入场信号 | 跟踪止盈面板 | …已触发 | 追加「买入前须通过合规门控 (硬阻断时不可买入)」 |

- ERP v4 推送（用户决定）：与 JCS 一致，背景读数只写告警表、不推送 Server酱/邮件/企微；ERP v4 前向记录 CSV 不受影响。
- AI 叙事（用户决定"无调用方即停用"）：排查结果为除决策中枢已隐藏的面板外无其他调用方（日报用 `report_generator` 自身叙事，无定时任务）。`/decision/narrative`、`/narrative/generate` 在模块开关 narrative 关闭时返回 status=disabled，不读缓存、不生成、不调用大模型；恢复时打开 `config/decision_modules.json` 的 narrative。
- 测试：新增 `tests/test_alert_wording.py`（模板禁用写法正则、执行目标引用、回撤推送/行动项、ERP 事件无仓位数字且不推送、决策页警示、漂移监控、再入场、叙事接口停用）；`test_alert_monitor.py` 模板格式化测试补 target 参数。本机相关测试 132 通过。
- 核对：重启后三项关键数字不变；叙事接口返回 disabled；行动项正文已引用执行目标。核对中发现行动项/推送标题仍带档位标签「降至 25%」，补改为只显示档位名（`_tier_name`），已包含在同一提交。

### 预热期读数缓存（提交 5218d07）
- 现象（本机复现）：重启后约 47 秒内 Dashboard 未就绪、无 VIX 读数，合规「VIX 紧急刹车」按"读数不可用"判硬阻断，该结果写入 `swr_decision_hub`（收盘后 300s×4 = 20 分钟，周末 ×8 = 40 分钟）；预热完成后现算的合规无此条。重启前一刻旧进程仍在提供该缓存（已 694 秒）。
- 预热期产生的数据：启动时核心预热串行执行 ERP → AIAE（发布 aiae_ctx）→ Rates（+15s）→ Dashboard（+30s，含 VIX / 波动预算）；完成前 `/hub` 用残缺缓存现算：AIAE 未就绪 → 决策锁定，「AIAE 过热」「仓位超限」按数据缺失判硬阻断；VIX 未就绪 → 「VIX 紧急刹车」硬阻断；执行目标可能不可用。缓存层：`services/cache_service.py` 的 SWR 键 `swr_decision_hub`（`/compliance-check`、审计页共用）和 `swr_risk_matrix`；Redis 模式下会跨进程保留。
- 改动：新增 `services/warmup_state.py`（进程内状态，不写 Redis）。lifespan 登记核心任务并清除重启前的 `swr_decision_hub` / `swr_risk_matrix`；四个核心预热函数用 `@track` 记录完成（`warmup_dashboard_cache` 改为返回 True/False，原先吞掉失败）。
  - warming（未超时）：`/hub`、`/compliance-check`、`/risk-matrix`、`/audit` 不计算、不读旧缓存、不写缓存，返回 status=warming_up；`/audit/save` 与每日审计快照不写；买入门控默认拒绝。
  - partial（用户决定：超时 10 分钟或核心任务失败，不得按正常处理）：照常现算但不写缓存，对应合规规则维持"数据缺失即硬阻断"，买入门控随之拒绝；响应附 warmup.message"部分数据缺失：XX"，页面顶部提示；记日志（每次进入只记一次）。之后缺失任务成功（08:30 早间补偿 / 15:35）即自动恢复。
  - 页面：决策页 warming 时只显示"数据加载中…待完成：XX"，今日结论执行目标 / 合规显示"数据加载中"，15 秒后自动刷新；合规面板同样处理；审计页显示"数据加载中"并 15 秒重试，"保存审计"提示"预热中，暂不保存"。缓存版本号：decision.js v59、global_analytics.js v57、today_summary.js v2、audit.js v77。
- 测试：新增 `tests/test_warmup_gate.py`（状态机、超时按缺失、失败后补齐恢复、track 装饰器、启动清缓存、预热期接口不计算不写缓存、partial 现算不缓存、审计不写、买入门控拒绝、VIX 缺失仍硬阻断）与 `tests/test_warmup_frontend.cjs`。云端全量（依赖用替身）相对改动前无新增失败。
- 核对（重启实测）：重启后 12 秒起接口返回 warming_up，待完成项 4 → 3 → 1 → 0；决策页显示"数据加载中"，无读数；运行 70 秒时预热完成，页面自动恢复，执行目标 25% / 合规两条硬阻断 + 一条警告（无 VIX 假阻断）/ 跟踪止盈 RED 2 YELLOW 1 GREEN 13 三档，与基线一致；回撤刹车标题已不带"降至 25%"。

### 本轮新增待办（2026-11-02 用户登记）
- 【高】MR 预览自带限额（总仓位 95%、单票 20%、行业 40%、MR 敞口上限）与合规并行，属第二套风控判定，下一轮优先处理。
- 优化器总上限 95%、调仓引擎目标仓位（AIAE 档位配额）、情景模拟"建议仓位"、海外 ERP 引擎"建议仓位 / 降至 50%"字样。
- 合规规则原文中的数字（VIX 30%、R5 15%、回撤刹车"仓位上限 X%"）；执行层说明里回撤刹车档位标签（`portfolio_vol.py` 的"净值回撤 x% · 三档 · 降至 25%"）同属此类。

## 首页口径统一 · 仓位超限检查基准（2026-11-02）
- 范围：首页所有仓位 / 集中度 / 上限类数字与决策中枢统一（A1–A3），合规「仓位超限检查」判定基准改为执行目标（B，用户在评估后决定实施）。已定规则不变：AIAE 执行目标是全站唯一仓位数字；合规引擎是唯一风险判定；跟踪止盈是唯一止损执行入口；JCS/AIAE/ERP/海外读数只作背景。
- 本轮无本机命令行：代码在云端副本修改、测试后逐步写回本机，每步由用户提交；核对通过内置浏览器读本机服务。截图（改前 6 / A2 后 3 / 最终 5）由用户存仓库外 `D:\FIONA\alphacore_baselines\home_20261102\`。
- 审计结论（改前，本机 11:2x）：首页 13 处仓位类数字中，横幅"建议仓位"、行动条"建议仓位"、仓位研判大数字、"可执行上限"都显示 AIAE 矩阵上限 61%（`_build_position_stack` 调 `build_decision_view` 未传回撤数据，缺回撤刹车一档）；仓位缺口仪表读 `action_plan.position_target`（已恒为 null）后回退到 `snapshot.suggested_position`（= 矩阵上限）；首页集中度 `services/concentration.py` 分母为权益（88.8%），合规为账户（87%）；一致度门槛用宏观因子一致度决定"能否调仓"；背景区另有 Cap 条、五档仓位区间、"每周减 5%""3 天清仓"、策略卡建议仓位，以及 ERP v4"仓位以 v4 为准: 65%"。

### A1 · 合规主题集中度附带结构化读数（提交 4ea606d）
- `engines/compliance_engine.py`：新增 `theme_metrics()`，「主题集中度」检查结果附 `metrics`（basis=account、最大主题、占账户%、40/60 阈值、level、前 5 主题），与判定同源（`_theme_buckets`），判定不变。买入门控 `compliance_gate._rows` 只取 rule_id / rule_name / detail，不受影响（有断言）。
- 测试：新增 `tests/test_compliance_theme_metrics.py`（旧代码上 3 条失败）。本机合规相关 66 通过。

### A2 · 首页执行区改读决策中枢（提交 725ef8a）
- 后端：删除 `assemble_response._build_position_stack` / `_build_rebalance_gate` 与 `market_temp.position_stack` 字段；`action_plan` 新增 `execution_instruction`、`reduce_days`（执行层原文，最终结论会覆盖 reasoning），撤回缓存时一并清空。
- 前端：`renderExecStack(hub)` 统一渲染横幅、行动条、仓位研判（大数字 = 执行目标；"执行目标从哪来"列出四档约束并标最严；当前仓位 / 偏离 / 分区 / 执行层原文）、主题集中度（只读合规 metrics，占账户）；执行偏离仪表读 `execution_target` / `execution_gap`，文案引用执行层，不再"分 2–3 批""优先清退高波动标的"。中枢预热返回 warming_up → 显示"数据加载中"并 15 秒重试；中枢不可用 / 撤回 → 显示"不可用"，不回退到矩阵上限。renderers v15、script v22、styles v25。
- 测试：新增 `tests/test_home_caliber.cjs`（静态口径 + 替身 DOM 喂入本机数字：执行目标 / 偏离 / 集中度 / 撤回不回退 / 预热分支先于渲染）。本机相关 80 通过。

### A3 · 首页背景区去仓位数字与操作指令（提交 7e37dcf）
- AIAE 温度计删 Cap 条，档位说明改为"背景读数 · 仓位以执行目标为准，风险以合规为准"（R4/R5 注明合规「AIAE 过热限制」）；横幅 AIAE 标签改为档位（R3）。
- 策略配置：只显示策略权重（"策略权重 · 背景"），删"仓位上限: 61%"和矩阵上限 × 权重的名义仓位。
- 原"明日交易计划"卡改名「AIAE 档位 · 背景读数」：删 Cap、五档仓位区间与操作指令列、核心指令与情景预判（含"启动系统减仓至 40% 以下"），改为一条口径说明。
- 策略卡第二项：MR 卖出信号数、动量买入信号数、红利趋势向上 x/8、AIAE 档位（原"建议 x% / 满仓位 / Cap"）；五策略共振卡 AIAE 指标改为档位。
- ERP v4 区块（`erp_zone_chart.js`）：标为背景读数 / 前向观察，删"仓位以 v4 为准: 65%""偏离目标 ≥15pp 才调仓"与执行规则文字，"目标仓位"列 / 图例 / 右轴改为"v4 档位"（数值去 %）。v4 前向记录与告警不受影响。
- 仓位研判集中度说明压短为"占账户 · 硬阻断"，阈值放在悬停提示（A2 核对时发现窄栏换行过多）。
- 测试：新增 `tests/test_home_background.cjs`；`test_home_caliber.cjs` 版本号检查改为 ≥。本机 39 通过。

### B · 合规「仓位超限检查」以执行目标为基准（提交 384bd96）
- 评估（只读，用户决定后实施）：旧基准为矩阵上限时，刹车触发且仓位处于执行目标 +10pp 与矩阵上限 +10pp 之间（如目标 25、仓位 50），页面按降仓方向判定时回撤规则放行、仓位检查也放行 → 合规显示通过而执行区"必须降仓"；矩阵上限下调到周五评估前也会出现合规阻断 / 执行区维持的不一致。改基准后与执行分区"必须降仓"（> 10pp）同步。
- 改动：`_check_position_vs_cap` 基准 = AIAE 执行目标，超出 > 10pp 不通过；执行目标不可用 → 不通过（不回退矩阵上限）；文案"AIAE 执行目标 25%（受回撤刹车约束）。当前仓位 x% 超出执行目标 ypp，禁止加仓；按执行目标分批降仓（分 3–5 个交易日…）"。`decision_engine` 中枢与 `compliance_for_direction`（买入门控）都把同一次执行层结果（execution_target、与目标相等的约束 = execution_binding）传入合规。
- 级别：硬阻断；唯一例外为最严约束只有「组合波动预算」且 `enforce_in_compliance=false` 时为软警告（保持"波动预算不强制"的现有配置，用户未另行决定时的默认；今日最严约束为回撤刹车，不涉及）。
- 重复阻断：页面按执行方向判定，偏离 > 10pp 为降仓方向（回撤规则放行，仅本规则阻断），≤ 10pp 时本规则通过（回撤规则在非降仓方向阻断）——有测试。买入方向（门控）下两条同时阻断，与改前相同。
- `docs/DECISION_RULES.md` 规则表同步。测试：`test_compliance_wording.py` 按新基准重写（情景：无刹车 / 刹车 / 目标不可用 / 级别 / 不重复阻断），`test_compliance_engine.py` 三条改为执行目标，`test_compliance_buy_gate.py` 断言传入执行目标；`test_decision_framework_v27.py` 的"分批"断言显式传入执行目标（不再依赖本机执行层状态文件），文案补"分批"。本机全量 1793 通过 1 失败（即该文案，已修），复跑相关 85 通过。

### 核对（本机，重启并预热完成后 19:4x）
| 指标 | 首页 | 决策中枢 | 审计页 / 执行层 |
|---|---|---|---|
| 执行目标 | 25%（横幅 / 行动条 / 仓位研判 / 偏离仪表） | 25.0% | 执行层 25 |
| 当前仓位 · 偏离 | 100% · +75.0pp · 必须降仓 | 100.0% | 执行层 100 · 75 |
| 合规 | 2 硬阻断（主题集中度、仓位超限检查）+ 1 警告（组合波动预算） | 同 | 审计页同 |
| 主题集中度 | 半导体电子 87%（占账户） | 合规 87% | — |
| 跟踪止盈 | — | 已触发未执行 1 只 | RED 1 / YELLOW 1 / GREEN 13 |
- 与中午基线（96.2% / RED 2 / 16 只持仓）的差异来自账户本身（持仓 15 只），执行目标 25% 与合规结论各步前后不变。买入门控（159995 预览）拒绝，4 条硬阻断，与会话 1 实测相同。

### 本轮新增待办（2026-11-02）
- 【高】当前仓位两套口径同屏：合规 `_position_from_valuation`（实时估值，今晚 98%）vs 执行层 `invested_pct`（日终快照，100%）；首页「执行建议」引用合规原文"当前仓位 98%，超出 73pp"，旁边偏离仪表 100% / +75pp。建议合规改用执行层同一当前仓位，或文案注明口径。
- 【高】MR 预览自带限额与合规并行（上轮登记，仍待处理）。
- ERP v4 区间表"区间"列仍为"加仓区 / 买入线 / 卖出线 / 减仓区"等后端标签；首页"建议周期 5–8 个交易日"、五策略共振卡权重百分比属背景读数，未改。
- `services/concentration.py`（权益口径）首页已不再使用，组合页 / 策略页是否仍引用待排查后决定保留或统一。

### B 补丁 · 账户仓位先于执行目标核验（提交 079334b）
- CI #108 / #109 失败：`test_jcs_production_controls::test_unknown_account_exposure_is_not_replaced_by_model_target` 在 CI（无执行层状态文件）中得到"执行目标不可用"而非"实际仓位不可用"。`_check_position_vs_cap` 改为先核验账户敞口、再核验执行目标（缺任何一个都不通过）；CI #110 通过。

## 当前仓位口径统一（项 1，2026-11-02，方案见 `docs/ACCOUNT_EXPOSURE_AND_MR_LIMITS_PLAN.md`）
- **口径切换日期：2026-11-02。** 此前合规（仓位超限 / 单票 / 主题权重）在对账单导入当日用券商表头「资产」作分母，执行层用 市值 + 快照现金；自本日起全站同一分母。
- 唯一来源 `services/account_exposure.py: current_exposure()`：分母 = 持仓市值 + 现金（有「可用」用「可用」，否则「余额」；「冻结」不计入，单独显示）；分子扣逆回购；价格导入当日用对账单价、之后用最新收盘（`_pick_price` 现行规则）。券商表头「资产」只作一致性校验，相差 > 0.5% 时显示处与门控结论标注"券商资产与 市值+现金 不一致 ¥x"。
- `portfolio_engine.get_valuation`：总资产 = 持仓市值 + 现金（不再用表头「资产」）；返回 cash / cash_basis / broker_frozen / broker_total_asset / imported_at、逐只 price_as_of；解析器补读表头「可用 / 冻结 / 可取」（旧快照无此字段 → 按「余额」）。
- 改读唯一来源：决策中枢快照与合规（单票、主题同一分母）、执行层 `compute_from_store` 的 invested_pct（实时口径；回测 / 显式传入快照时不变）、回撤刹车 `marked_equity` 与 MR 预览的现金取值、组合页、日报。
- 显示：首页执行栈 / 偏离仪表、决策页今日结论（悬浮）/ 降仓路径、组合页、日报、合规"仓位超限检查"原文均标注"持仓截至 MM-DD HH:MM 对账单 · 价格 MM-DD 收盘"。
- 买入门控：两口径相差 > 0.5% 时取较高值（结论附"仓位口径"警告）；持仓快照过时检查——流水中有快照之后的成交、或快照早于最近一个已收盘交易日 15:00 → 拒绝（`HOLDINGS_STALE`，与硬阻断同时出现时写入阻断结论）；交易日开盘后快照早于今日开盘 → 放行并警告"持仓可能已过时，请先导入对账单"（`STALE_INTRADAY_REJECT` 可改为拒绝）。
- `/portfolio/rebalance` 停用，返回 status=disabled「已停用」；`rebalance_engine` 目标逻辑未改，11-30 隐藏模块复查时决定是否删除。
- 测试：新增 `test_account_exposure.py`（分母、可用 / 冻结、逆回购、表头校验、门控取较高、过时三种情形、门控接入、接口停用）、`test_position_asof.cjs`（首页 / 决策页 / 组合页标注）；`test_compliance_buy_gate.py` 门控用例固定"口径一致 + 快照新鲜"；`test_warmup_frontend.cjs` 版本号断言改为 ≥。
- 已知：MR 预览仍用对账单价重估持仓（项 2 改为成交后合规门控时一并处理）；27,001 元表头差额构成待用户在券商客户端核对「资金余额 / 冻结资金 / 可取资金」后确认。

### 项 1 核对与提交（提交 90a865e，已部署）
- 本机全量 pytest 1808 通过、前端 18 项通过；重启预热完成后：执行目标 25%（不变）；当前仓位全站 100%（偏离 +75.0pp），首页 / 决策页 / 组合页均标注"持仓截至 11-02 17:48 对账单 · 价格 11-02 收盘"，首页附"券商资产与 市值+现金 不一致 ¥27,001"；合规 2 硬阻断（主题 88.7%、仓位超限，原文带时间标注）+ 1 警告（波动预算）；跟踪止盈 RED 1 / YELLOW 1 / GREEN 13（不变）；买入门控（159995）拒绝，4 条硬阻断不变，另附"持仓快照：对账单早于今日开盘…持仓可能已过时，请先导入对账单"警告（A 股 11-03 盘中）；`/portfolio/rebalance` 返回"已停用"；组合页总资产由表头 1,357,141.67 变为 市值+现金 1,330,140.91。

## MR 预览自带限额并入合规（项 2，2026-11-02，方案见 `docs/ACCOUNT_EXPOSURE_AND_MR_LIMITS_PLAN.md` 第 2 节）
- 买入门控改为成交后检查：`buy_gate(order={ts_code, name, notional})` → `decision_engine.apply_order` 把这笔买入加到当前持仓（统一口径、同一分母，总资产不变），对成交后组合运行合规；结果附 `post_trade`（成交后总仓位、单标的、订单所在主题）。MR 预览传入订单；优化器 / 调仓仍按当前组合（不传订单）。成交后组合无法计算 → 合规不可用 → 拒绝。
- 合规补充（用户决定 b、c）：
  - b：买入订单使所在主题成交后 > 40% → 硬阻断（"禁止新增该主题"）；买入其他主题不受 b 影响；不传订单（页面 / 优化器）时 40–60% 仍为软警告。
  - c：仓位超限检查上限 = min(执行目标 + 10pp, 95%)。
  - 单票（a 维持个股 20% / ETF 35%）、仓位超限、主题在有订单时文案写"成交后"。
- MR 预览删除风险类限额：`TOTAL_CAP`、`SINGLE_LIMIT`、`SECTOR_LIMIT`、`SECTOR_UNKNOWN`、`MR_EXPOSURE_CAP`（及名称关键词行业归类、MR 敞口估算）；信号动态单笔上限只显示，超出时醒目提示 `DYNAMIC_POS_CAP_EXCEEDED`（不拦截）。保留策略 / 可行性检查：`OBSERVATION_ONLY`、`ENTRY_CAP_ZERO`、`DATA_UNAVAILABLE`、`MARKET_SNAPSHOT_CHANGED`、`PORTFOLIO_UNAVAILABLE_OR_STALE`、`HOLDING_MARK_UNAVAILABLE`、`ACCOUNT_VALUE_UNAVAILABLE`、`INSUFFICIENT_CASH`、`INSUFFICIENT_HOLDINGS`；门控新增 `HOLDINGS_STALE` 文案。
- 预览页「计划后仓位」买入取门控成交后数字（总仓位 / 单标的 / 主题），不再显示关键词"行业"；卖出仍用本地估算。
- `docs/DECISION_RULES.md` 规则表同步（单票、主题、仓位超限）。
- 测试：新增 `test_mr_limits_in_compliance.py`（成交后组合、情景 S1–S9、页面语义不变、门控传单、MR 只保留可行性检查）、`test_mr_preview_compliance_frontend.cjs`；`test_manual_decisions.py` / `test_compliance_buy_gate.py` 门控替身接受订单参数。
- 已知：新建仓标的若无行业映射（ETF 穿透 / 名称回退也无结果），按合规现有规则"无行业数据不计入主题上限"，b 不触发（原 MR `SECTOR_UNKNOWN` 已按方案删除）。

### 项 2 核对与提交（提交 6bfa00e，已部署）
- 本机全量 pytest 1822 通过、前端 19 项通过。服务器与本机重启后核对：执行目标 25%；合规 2 硬阻断 + 1 警告；159995 预览拒绝，阻断码只剩 COMPLIANCE_HARD_BLOCK / INSUFFICIENT_CASH / OBSERVATION_ONLY，合规原文"成交后"（本机主题 88.8%、成交后仓位 100.06%），动态单笔上限提示"只提示，不拦截"。
- 服务器账户数据与本机不同（对账单 11-03 07:45、主题 92%、跟踪止盈 GREEN 11 + LEGACY 2、越线 2 只），服务器回撤刹车"当前 96.1%"≠ 统一口径 100% → 登记待办 1、2（`docs/ACCOUNT_AUTHORITY_AND_RISK_REFRESH_PLAN.md`）。

## 导入后风险状态重算（待办 2，2026-11-02，方案见 `docs/ACCOUNT_AUTHORITY_AND_RISK_REFRESH_PLAN.md` 第 2 节）
- 核实：跟踪止盈页面每次访问现算；但合规「越线禁止加仓」「组合回撤刹车」与执行层回撤刹车约束读的缓存只在日终提交（出现新收盘）时写，导入对账单只重算波动预算、导入成交只清页面缓存 → 同日导入后合规与执行目标用旧状态。
- 改动：`trailing_stop_service.refresh_risk_state(trigger)` / `write_risk_state`（日终提交共用）刷新 `trailing_stop_report` / `drawdown_brake` 缓存并落盘 `data_lake/risk_state_live.json`，附 computed_at / holdings_as_of / trigger；不改已发布止损线下限、日终快照与发布日志。`risk_state` 读取顺序：缓存 → 落盘文件 → 日终快照。`/portfolio/import`、`/portfolio/trades/import` 成功后先重算再失效持仓与决策缓存（成交导入补失效决策缓存），结果附 `risk_state`（重算失败不影响导入，显式返回 error）。
- 显示：首页执行栈"组合回撤刹车"行、决策页"执行目标从哪来"、跟踪止盈页回撤面板（"合规 / 执行所用：状态计算于 MM-DD HH:MM（持仓截至 … 对账单）"）。
- 入金 / 出金检查点：回撤按风险资产 TWR（持仓 × 价格，现金不进净值，持仓由对账单 + 成交台账回滚还原）；银证转账类为 cash 行不进成交台账 → 入金不改变回撤读数与档位，只降低仓位比例；非总资产口径，无需修正。
- 测试：新增 `test_risk_refresh_after_import.py`（重算写入与时间、不改发布状态、合规与执行读到新状态、重启读落盘、导入失败不阻断、约束带时间、入金 / 出金不扭曲回撤）、`test_risk_state_asof_frontend.cjs`；`conftest.py` 每个测试把 `LIVE_RISK_PATH` 指向临时文件，并把 `risk_state_live.json` 纳入真实数据防护。

### 待办 2 核对与提交（提交 f8445cf，已部署）
- 服务器部署后回撤刹车处显示"状态为 11-02 日终计算"（合规所用 96.1%、页面现算 100%，证实同日导入不重算）；重新导入对账单后：状态计算于 11-03 12:57（持仓 12:56），合规 / 执行所用 98% = 统一口径 98% = 跟踪止盈页 98%。入金 / 出金检查点：回撤为风险资产 TWR，已补测试。27,001 元口径差额关闭（券商资产 = 市值 + 可用）；"可用比余额多 27,000.76"待用户核对。12:56 那份为 11-02 对账单重新导入（服务器 import_date 11-02）→ "持仓截至"应改用对账单自身时间（登记）。

## 安全修复（2026-11-03，方案见 `docs/ACCOUNT_AUTHORITY_AND_RISK_REFRESH_PLAN.md` 1.4）
- 核实：8000 对外直连、明文 HTTP、读取免认证、写入令牌已设置但开发模式、备份仅本机未加密且 KEEP_DAYS 被脚本写死 30 覆盖。
- 已完成：SSH 仅密钥登录（验证通过）；隧道 `localhost:18000`；`docker-compose.yml` 端口改 `127.0.0.1:8000:8000` 并部署（服务器只监听本机）；`backup.sh` 保留天数读取 crontab 传入值（365）。
- 延后（用户决定）：安全组删除 8000；生产模式 + 更换令牌；备份加密口令与异地拉取；读取鉴权随视觉会话 1b 之后实施。

## 合规「AIAE 过热限制」档位缺失 fail-closed（2026-11-03）
- 问题：`_check_aiae_overheat` 以 `snapshot.get("aiae_regime", 3)` 取档位，缺失时按 R3 放行加仓（fail open），与预热期 / 买入门控"数据缺失不放行买入"不一致。
- 改动：`_aiae_regime` 只接受 1–5 的整数（缺失 / 非数 / 越界 / 布尔 → 无效）；无效时加仓方向不通过（硬阻断），减仓 / 持有通过并注明缺失；有效档位判定不变。首页主结论在后端无执行结论时不再按 AIAE 档位兜底"满配进攻 / 清仓防守"等，改为"执行结论暂不可用"（`renderers.js`，v19）。`docs/DECISION_RULES.md` 规则表同步。
- 测试：新增 `test_aiae_regime_fail_closed.py`（18 项：缺失 / 无效 9 种取值阻断加仓、减仓 / 持有放行、有效档位解析与判定不变、完整合规运行中出现在 blocks）；`test_home_caliber.cjs` 增加兜底文案断言；`test_risk_state_asof_frontend.cjs` 版本断言改为 ≥。云端全量无新增失败。

## 测试隔离全面检查（第 7 项，2026-11-03，进行中）
- 背景：本机资金流水中有 3 条来源为 `h.txt`（`test_trailing_api` 的测试文件名）的结算记录；11-03 本机全量测试期间 `erp_daily_history.json` 被改动（来源待定：本机服务或测试）。代码中写 data_lake 的位置 124 处，大量为相对路径 `data_lake`（按当前目录解析），逐个改路径无法穷尽。
- 守卫（`tests/conftest.py`）：Python 审计钩子拦截写操作——`open` 写模式 / `os.open` 写标志 / rename / replace / remove / rmdir / mkdir（新建）/ truncate / shutil 复制 / `sqlite3.connect`（非 `mode=ro`），另包 `DataFrame.to_parquet`（pyarrow 直接写盘，钩子看不到）。受保护：`data_lake/`、`services/data_lake/`、`config/`、仓库根目录文件。命中即阻止该次写入并记录（被测代码吞掉异常也有记录）；测试收尾时有记录 → 该测试失败并列出"路径 ← 代码位置（测试位置）"；收集 / 导入阶段的写入 → 会话判失败。已存在目录的 `makedirs(exist_ok=True)`、带 `dir_fd` 的相对路径（TemporaryDirectory 清理）不计。
- 重定向：账户 / 状态文件每个测试指向临时目录（成交流水、导入原文件目录、资金流水、持仓快照、跟踪止盈状态与日终快照、执行状态与前向日志、ERP v4 前向日志、MR 决策库、AIAE 因子历史、PortfolioEngine 数据目录、风险状态落盘）；行情缓存仍可只读访问，写入由守卫拦截。
- 自检：`tests/test_real_data_write_guard.py`（绝对 / 相对路径、os.open、sqlite 非只读、makedirs、replace、to_parquet 被阻止并记录；吞掉异常仍记录；只读与临时目录写入放行；状态路径已重定向）。云端全量：守卫无命中，无新增失败。
- 待本机全量运行：本机有真实行情与状态文件，引擎会走到写缓存的分支；守卫会把所有写真实路径的测试列出，再逐个改为写临时目录。
- 本机第一轮（守卫生效）：1856 通过，命中 5 处写真实路径（均已阻止，真实文件未改）——
  - `tests/test_e2e_v33.py`：手工端到端脚本（无测试函数），在收集阶段整段执行：联网计算 ERP 并写 `erp_daily_history.json`、`erp_pe_ttm.parquet`、`erp_m1_history.parquet`、`chinabond_yield_10y.parquet`，还会改当前目录。**11-03 `erp_daily_history.json` 被改的来源即此**。→ pytest 下整文件跳过，保留手工运行。
  - `tests/test_audit_11_14.py` 导入动量引擎时，市场波动刹车在收集阶段把状态写入 `vol_overlay_state.json`。→ 会话级与每个测试都把 `vol_regime._state_path` 指向临时目录。
  - `tests/test_aiae_scientific_validation.py`（V5 报告对齐）：真实 AIAE 报告写 `hf_proxy_cache.json`。→ `hf_proxy_engine.HF_CACHE_FILE` 会话级与每个测试重定向。（该测试会联网约 8 秒，属测试设计问题，另登记。）
  - `tests/test_aiae_warmup_context.py`（2 个）：预热先同步指数行情（联网 + 写 `daily_prices/*.parquet`）。→ 本文件停用指数同步（只测 AIAE 上下文发布）。
  - `tests/test_warmup_gate.py`：门控读到本机真实账户（券商资产与 市值+现金 不一致 → 传入 current_override），替身不接受该参数而失败。→ 替身接受关键字参数；conftest 默认把门控的账户仓位与快照检查设为中性（测门控的测试自行替换）。
- 本机第二轮：1857 通过、1 跳过（e2e 脚本），命中 1 处——`tests/test_rates_p0_semantics.py` 生成利率报告时取中债 10Y（联网 AKShare + 写 `chinabond_yield_10y.parquet`）。→ 本文件把中债读取设为不可用（只测美债规则语义，与无网络环境一致）。

- 本机第三轮：1857 通过、1 跳过，守卫无命中，真实数据防护未修改；耗时由 150–195 秒降至 82 秒（不再联网）。第 7 项完成。

## 数据迁移（本机 → 服务器，2026-11-03，方案见 `docs/ACCOUNT_AUTHORITY_AND_RISK_REFRESH_PLAN.md` 1.5）
- 迁移前备份：`KEEP_DAYS=365 bash backup.sh` → `alphacore_20261103_165429.tar.gz`（保留 365 天已生效）。
- 跟踪止盈 7 项人工设置（一次性脚本，先预览再写入，写入前自动备份 `trailing_stop_state.json.bak_premigrate_20261103_165516`；审计记录"迁移自本机 + 原操作时间"；重复运行全部"已一致"）：159218 / 159516 / 159995 / 588000 于 10-22 重设基准（1.185 / 0.532 / 0.882 / 1.377，RSI左侧交易）；002851 于 10-30 重设基准 77.72（AI电源长期配置，越线后的例外，复盘时留意）；688019、688981 设为核心仓。迁移后"跟踪前已越线"清零（002851 转 GREEN）。
- 重新导入（只导交割单 / 历史成交）：20261029历史成交、20261029交割单（补全 2 条、1 条疑似同笔）、20261030交割单、20261022历史成交；新增成交 0（60 笔两边一致）；导入后风险状态自动重算（11-03 22:06）。
- 疑似同笔：688837.SH 2026-09-07 新股缴款 500 股 @ 27.60（已有记录来自 20261102历史成交、无成交编号；来报来自 20261102交割单、成交编号 0700754014）。本机 10-29 已确认同一笔；服务器以应用自身 `confirm_possible_duplicate_same` 复现，原来报文件不在本机 → 以内容相同的 20261029交割单 中同一行确认并在原因中写明（文件指纹为 20261029 交割单）。结果 resolved 1、补全 fees / net_amount、现金补全 1。
- 存档（只存档、不并入）：服务器 `data_lake/archive/` ← 本机主库一致性副本 `local_alphacore_20261103.db`（6–10 月决策记录 / 持仓快照 / 日报，含测试写入的执行单）、6 月停用旧库 `local_legacy_alphacore_202606.db`、本机 AIAE 执行前向日志（10-30 执行目标 64→50→25 的记录）；`trailing_snapshots/2026-10-22.json` 补入服务器。
- 核对（重跑账户清单 + 资金流水逐条）：作废 / 更正后的有效资金记录两边各 97 条、金额逐条一致、期间现金变动 +26,428.01 一致（本机原始 99 条中 2 条为 10-29 已作废的 h.txt 测试写入）；成交 60 笔一致；跟踪止盈 18 只、审计 12 条一致；服务器日终快照 9 份（含 10-22）。
- 迁移中发现：服务器 11-03 跟踪止盈 RED 2（沪电股份 11-03 首次跌破、仕佳光子 10-30 起已逾期）/ YELLOW 1 / GREEN 12——是否执行由用户决定。
- 临时文件：服务器 `/root/acct_*`、`mig_trailing.py`、`fix_dup.py`、`jgd_1029.txt`、容器 `/tmp/*`，本机 `D:\FIONA\账单\` 下清单 / 副本 / 测试输出——由用户删除；云端暂存的账户数据副本已删除。
- Xshell 改为密钥登录（`C:\Users\Roy Zhou\.ssh\id_rsa`，服务器已关闭密码登录）；私钥需另行备份。

## 决策中枢视觉 1b · 行动区（2026-11-03，方案见 `docs/DECISION_HUB_VISUAL_1B_1C_PLAN.md`）
- 范围：只改视觉与展示文案，不改判定、口径、接口字段与数字。已定规则不变：AIAE 执行目标是全站唯一仓位数字；合规引擎是唯一风险判定；跟踪止盈是唯一止损执行入口；JCS/AIAE/ERP/海外读数只作背景。隐藏模块（23 项）不做视觉处理。
- 本轮无本机命令行：代码在云端副本修改、测试后写回本机（逐文件核对与云端副本字节一致）；未重启服务（页面文件按磁盘读取、no-cache）；提交由用户执行。可见模块以页面实际渲染核对：顶栏、标题、新鲜度栏、标签（决策概览 / 复盘）、今日结论、执行区、合规、跟踪止盈、宏观背景（1c）。
- 共用变量 `static/css/ac_tokens.css`（唯一定义处，用户确认"只用 var() 引用"）：`--dc-*` 表面 / 线 / 文字、`--mkt-up/--mkt-down`（红涨绿跌，只表示涨跌）、`--status-pass/warn/info/legacy/block/fail`（只表示状态）、`--cat-*` 图表分类色。`decision.css`、`jcs_macro.css`（`--jcs-*`）、`audit.css`（`--au-*` 与状态色）、`trailing_stop.css`（`--ts-*` Tailwind 色板）、`vol_budget.css`（`--vb-*`，面板已隐藏只改引用）改为引用，不再定义色值；对照表见方案第 3 节。审计页一并引用（`audit.html` 加一行）。`styles.css` 全站旧变量第 2 轮。
- 阻断色：用户在跟踪止盈 / 合规面板实数对比后选定洋红 `#d6409f`（与涨色 `#f05252` 色相差 38°，与警告色无冲突）；失败 = 同色相只描边。改前审计页阻断色 `#f04848` 与涨色几乎相同、`--jcs-risk` 与 `--jcs-up` 同值。
- 行动区（新增 `static/css/decision_action.css`，最后加载，只作用于可见行动区与页面框架）：面板实底 + 1px 边框 + 6px 圆角，去毛玻璃 / 阴影 / 入场动画；去掉合规总状态、风控徽章、严重警示卡、未读数、刷新按钮的循环闪烁 / 发光，硬阻断改为"实心阻断色总状态 + 阻断行实底 + 左侧粗线 + 正文加粗 + '硬阻断'文字标签"；新鲜度栏状态点 + 非正常时附文字（滞后 / 缺失 / 待核验 / 时间异常）；顶栏告警铃改线性 SVG；标题"决策中枢"；折叠箭头改 CSS（▶ 在 Windows 上可能按彩色 emoji 渲染）。
- 合规（`global_analytics.js`）：结论列 🛑/⚠️/🟢 → 文字标签"硬阻断 / 警告 / 通过"；规则级别 "hard block / soft warn" → "硬阻断级 / 警告级"；接口 summary 中的 emoji 不显示（接口不改）。
- 跟踪止盈（`trailing_stop_panel.js`、`trailing_stop.css`）：
  - **红涨绿跌修正**：改前 `.ts-pos` 绿 / `.ts-neg` 红（涨跌色反了）；改为 `--mkt-up` / `--mkt-down`，按符号着色（正红、负绿、零中性）：持仓盈亏、回合收益、规则 − 实际、亏损加仓相对成本。本机实页核对持仓表 15 个盈亏数字颜色方向全部正确（正 2、负 13）。
  - "超单票风险预算 / 行情滞后 / 需减"改用警告色 `.ts-warn`（原借用跌色）。
  - 结论条加状态标签（已触发 / 回撤刹车 / 待决 / 待执行 / 待处理）；回撤一档原紫色改警告色，二 / 三档用阻断色；渐变改实底 + 左线；骨架屏闪光改静态；emoji 改文字；"状态计算于"内联样式改 `.ac-computed`；接口文案中的 emoji 不显示。
  - 兜底数字：上限缺失原显示"/ 100%" → "--"；`equity || 1`（缺失时占比失真）→ 缺失不显示占比；`rerisk_recover || 0.5` → 缺失不显示该句。
  - **修复显示缺陷（2000px 限高截断持仓表）**：通用 `.dh-collapsible-body { max-height: 2000px; overflow: hidden }` 作用于跟踪止盈面板。核实（本机浏览器、11-03 实数、改前 `trailing_stop.css` 注入并移除新覆盖样式）：面板内容高 3291px（"正常持有"展开时），持仓表起点 2093px > 2000px → **改前持仓表整表被截断不可见**；改后内容高度与改前相同（1b 未增加高度）。持仓表起点距限高仅约 90px，是否截断随降仓清单行数、横幅数量变化（09:09 改前截图时仍可见）。修复：跟踪止盈展开时不限高。
- 今日结论：当前仓位数据时间由仅悬浮改为卡片下方直接显示（手机可见），悬浮保留。执行区"持仓截至…"、约束行时间统一 `.ac-asof`。
- 预留样式类（ac_tokens.css）：`.ac-asof`、`.ac-computed`、`.ac-state-loading/.ac-state-partial`（已用于预热 / 部分缺失提示）、`.ac-hint`、`.ac-posttrade`（第 2 轮接 MR 预览）、`.ac-authority-banner/.ac-authority-tag`（非权威横幅，另一会话接入）、`.ac-tag-*`。
- 缓存版本号：ac_tokens v2（新）、decision.css v62、jcs_macro v4、vol_budget v4、trailing_stop.css v10、decision_action v2（新）、audit.css v17；today_summary v4、exec_path v4、hub_core v59、global_analytics v58、risk_alerts v55、trailing_stop_panel v13、decision.js v60。
- 测试：新增 `tests/test_decision_visual_1b.cjs`（行动区无 emoji、JS 不内联颜色、色值变量只在 ac_tokens 且同值不重名、加载顺序、无渐变 / 毛玻璃 / 循环动画、阻断与涨色色相差、`.ts-pos/.ts-neg` 方向与按符号着色、警示不借用跌色、接口 emoji 不显示、兜底数字、合规文字标签沙箱渲染、预留类、隐藏模块不受影响、跟踪止盈不限高；用改前代码运行失败）。`test_audit_frontend`、`test_jcs_frontend` 断言改读 ac_tokens；`test_risk_state_asof_frontend`、`test_warmup_frontend` 版本号断言改为 ≥。云端前端 20 项全部通过（改前 19 项通过）；全量 pytest 未在云端运行（本轮无 Python 改动），需本机复跑。
- 核对（本机实页，改前 09:09 / 改后 09:2x，数字一致）：执行目标 25%（当前 100%，持仓截至 11-02 17:48 对账单 · 价格 11-03 收盘）；合规 blocked —— 硬阻断「主题集中度」「仓位超限检查」+ 警告 1（组合波动预算）；跟踪止盈 RED 1 / YELLOW 1 / GREEN 13，回撤刹车三档；买入门控（159995 MR 预览）拒绝，合规硬阻断 4 条（主题集中度、仓位超限检查、越线禁止加仓、组合回撤刹车）+ INSUFFICIENT_CASH、OBSERVATION_ONLY，与改前相同。桌面 1440 / 手机 375 无横向溢出；页面脚本全部加载。
- 未做：日报弹窗按钮 emoji（第 2 轮）；隐藏模块；宏观背景（1c）。

### 1b 期间登记的待办（2026-11-03）
- 【中】跟踪止盈回撤刹车"仓位上限 x%""≤25%"改为说明性写法（如"回撤三档约束 → 执行目标上限 25%"），避免看起来像第二个仓位数字。
- 【低】缓存过期后首次加载显示"缓存或断路器降级 / 执行目标不可用"，与预热期"数据加载中"提示不统一（11-03 09:08 本机复现，数秒后接口正常）。
- 【低】service worker（sw.js）注册失败的控制台错误（sw.js 不在 1b 改动范围；改前是否已出现未核实）。

## 测试守卫修正 · CI 收集中断 + 测试离线（2026-11-03，与 1b 无关，单独提交）
- 现象：CI #116 起（真实数据写入守卫上线）连续失败；#118 日志：27 个测试文件在**收集阶段**报 `PermissionError: [测试守卫] 禁止写入真实数据路径: data_lake`，`Interrupted: 27 errors during collection`，一个测试未运行（#115 及之前通过）。本机全量另有 5 个 ERROR（守卫已阻止写入）。
- 原因 1（CI）：CI 检出的代码没有 `data_lake/`（git 忽略），多个模块导入时 `os.makedirs(data_lake/...)`；守卫把"新建目录"当写入拦截（本机目录已存在故放行）。
- 原因 2（本机 5 个）：缓存超过 6 小时后引擎联网取数并写真实缓存——`services/fred_guard.py` 写 `data_lake/fred_cache/DGS10.parquet`（`test_rates_p0_semantics`）；`erp_hk_engine._fetch_southbound_tushare` 写 `data_lake/hk_southbound_flow.json`（`test_erp_global_p0` ×3、`test_hk_valuation`）。上一轮本机全量无命中是因为当时缓存未过期。
- 改动（只改测试代码）：
  - `tests/conftest.py` 守卫：**新建空目录（mkdir / makedirs）放行**——不改动、不删除真实数据；目录内写文件、改名、删除、写库照常拦截。
  - `tests/conftest.py` 新增自动夹具 `_offline_external_sources`：测试中 FRED 只读现有缓存（不论新旧）、不调用 API（按数据源不可用处理）、不写缓存；港股南向不调用 Tushare（读现有 JSON 或默认值）。`test_fred_guard*.py`（测缓存机制本身、自带临时目录与假数据源）不受影响。
  - `tests/test_real_data_write_guard.py`：去掉"makedirs 应被拦截"一项，新增"新建目录放行、目录内写文件仍拦截"（直接调用审计钩子判定，不在真实 data_lake 留目录）。
  - 新增 `tests/test_offline_external_sources.py`（FRED API 不被调用；旧缓存可读且不写新缓存；南向不拉取）。
- 验证：云端最小沙盒（无 data_lake，模拟 CI）——旧 conftest 复现导入阶段被拦截；新 conftest 守卫与离线自检通过（其余 1 项因沙盒缺账户模块失败、1 项因无 pyarrow 跳过，非改动问题）。本机全量与 CI 待用户复跑；CI 首次完整运行可能暴露其他"无缓存时联网写缓存"的测试，届时按同一方式补。
- 补充（CI #119：收集不再中断，1860 通过、2 ERROR；#120：1861 通过、1 ERROR）：都是 `engines/aiae_engine.py:96` 写 `data_lake/aiae_fund_position.json`——CI 无该文件时 AIAE 引擎首次创建会写"基金仓位种子文件"（本机文件存在故不触发）。第一版在离线夹具里替换 `_load_fund_position`，#120 中 `test_market_temp_erp_v4` 仍命中（该测试经根目录 `aiae_engine` 兼容层取引擎，CI 中补丁未作用到，原因未完全查明）。改为在守卫层处理：`_FIRST_RUN_SEEDS = ("aiae_fund_position.json",)`——目标文件**不存在**时的创建照样阻止（文件不生成，引擎捕获异常后用内存种子），但不判测试失败；文件已存在时任何写入照常记录、判失败。业务代码不改。`test_offline_external_sources.py` 改为直接测该判定。

## 测试守卫统一修复 · 取代 #119 / #121 的放宽（2026-11-03）
- 背景：#119 为让 CI 收集通过而"所有新建目录一律放行"，#121 为基金仓位种子文件加了守卫白名单（`_FIRST_RUN_SEEDS`）。两者都是为通过测试而放宽防护，不符合"不得放宽防护或加白名单绕过"的原则，本提交一并撤回，改为**重定向 + 桩数据**。
- 诊断（本机干净克隆模拟 CI：联网、假 token、无 data_lake；诊断模式只放行临时克隆与 %TEMP% 内写入，其余路径拦截并记录）：真实路径写入共 4 类——(i) 导入时建目录 `data_lake`（`hf_proxy_engine.py:49`）、`data_lake/fred_cache`（`fred_guard.py:68`）；(ii) `data/data_manager.py:32–36` 建 financials / daily_prices / industry_prices_qfq（`test_audit_page_scope.py:292`，同时用假 token 请求 Tushare）；(iii) `aiae_engine.py:96/102` 写 `aiae_fund_position.json` 种子；(iv) pytest 自身缓存临时目录 `pytest-cache-files-*`。没有任何写到克隆与 %TEMP% 之外的写入；真实 data_lake 未变化。
- 改动：
  - 守卫唯一例外（用户批准）：只放行**仓库 `data_lake/` 目录树内新建空目录**——原因：(i) 发生在模块导入（收集阶段），早于任何夹具，测试无法先重定向；空目录不含数据、不改动已有文件。`config/`、`services/data_lake/`、仓库根目录下新建目录仍拦截（含 `makedirs(exist_ok=True)` 时目录已存在的情形，照样记录）；目录内文件写入一律拦截。
  - 撤回 `_FIRST_RUN_SEEDS` 白名单。`engines/aiae_engine.py` 新增 `_fund_position_file()`：环境变量 `ALPHACORE_AIAE_FUND_POSITION_FILE` 优先，未设置（生产）仍为 `data_lake/aiae_fund_position.json`，行为不变（与月度历史文件 `ALPHACORE_AIAE_HISTORY_FILE` 同一做法）；`_load_fund_position` / `update_fund_position` 改用它。`tests/conftest.py` 在导入时于临时目录预置种子（82.0% / 2025-12-31，与引擎内置首次启动种子同值），每个测试开始前重置。
  - FRED：测试中缓存目录指向本测试的空临时目录（不再读本机真实缓存，本机与 CI 一致），API 调用按熔断处理不联网。南向 Tushare 仍为桩。
  - DataManager：`data.data_manager`（及根目录同名模块，如有）数据目录指向临时目录，Tushare 客户端换成"一调用就报错"的桩。
  - pytest 缓存：`pytest.ini` 设 `cache_dir = $ALPHACORE_PYTEST_CACHE_DIR`，conftest 设为 `%TEMP%/alphacore_pytest_cache`——只改位置、守卫不豁免，`--lf` 仍可用。
  - 字节码：干净检出无 `__pycache__`，导入根目录 / `config/` 下模块会在受保护路径建目录；conftest 设 `sys.pycache_prefix` 到 %TEMP%（只改位置，不豁免；沙盒模拟发现，诊断清单未出现）。
  - 新增联网拦截（收紧）：审计事件 `socket.connect` 目标非回环地址 → 拦截（PermissionError，按连接失败处理）并判该测试失败；`@pytest.mark.network` 的测试不受限（默认不运行）；`ALPHACORE_TEST_NET=record` 只记录不拦截，会话结束列出清单。
  - 联网清单：
    - `test_brinson_engine.py::test_basic_structure` 经 `brinson_engine._fetch_benchmark_sector_weights` 请求 Tushare `index_weight`（失败时本就退回静态兜底）→ 测试中直接用静态兜底权重打桩，不标 network。
    - `test_aiae_scientific_validation.py::TestV5DecisionLogic::test_v5_report_payload_alignment`：`generate_report` 调用高频代理引擎，ETF 资金流（510300 / 159915 / 510500，`hf_proxy_engine` 线程池 `hf-etf`）与截面缓存（换手率 / 融资，`tushare_daily_cache` 线程池 `xs-*`）请求 Tushare → conftest 中 `hf_proxy_engine.pro` 换成 Tushare 桩；截面缓存读本测试的空临时缓存文件、缺失日期不补拉（`_safe` 桩，按数据源不可用）。
  - 第一轮"只记录"模式漏报第二项的原因（已修正）：
    1. 归属：联网发生在线程池工作线程里，调用栈上没有测试帧，记录为"测试 ?"；清单按整行文字去重，所有线程里的联网（无论来自哪个测试）合并成一行"connect … (测试 ?)"，被误读为 brinson 测试的另一条记录。→ 改为按"当前测试"（`pytest_runtest_protocol` 设置的 nodeid，覆盖 setup / call / teardown 与其间所有线程）归属；记录模式按测试分组列出每个来源与次数，不跨测试去重；记录中带线程名与业务代码最近 3 层调用帧。
    2. 并发漏检（防护缺陷）：守卫记录时把全局开关临时关闭（防递归），同一时刻其他线程的联网 / 写入趁空档不经检查直接放行、不留记录。证据：拦截模式两轮中 3 只 ETF 并发拉取，2 只被拦，510500 照样联网成功（干净克隆返回"您的token不对"、本机拿到数据，`1 ETFs, 61天`）。旧实现下 8 线程并发连接自测只拦下 1–3 个。→ 防递归改为按线程的标记，不再动全局开关（写入守卫同样修正）；新增自测：8 线程并发联网 / 并发写真实路径必须全部拦截并各留一条记录、归属当前测试。
    - 清单完整性：拦截模式下任何一次联网都会使当时正在运行的测试失败（按时间归属，与线程无关），测试之外的联网使整个会话失败；两轮拦截模式全量（干净克隆 + 本机）只有上面一个测试失败、没有会话级联网。修正后再以记录模式（按测试分组）与拦截模式各跑一轮确认清单为空。
  - 自测：`test_real_data_write_guard.py` 改为"data_lake 树内建目录放行 / config、services/data_lake、根目录、`data_lake_x` 拦截 / 目录内写文件拦截 / 已存在目录 makedirs 仍记录 / 联网拦截与回环放行 / 真实 socket 连接被拒"；`test_offline_external_sources.py` 去掉种子白名单用例，新增 FRED 空临时缓存目录、DataManager 重定向与 Tushare 桩、基金仓位种子在临时目录。
- 验证（2026-11-03 11:32 已执行，输出 `D:\FIONA\alphacore_baselines\final_20261103_113239`：记录模式联网清单两种环境均为 0 个测试、0 次连接（各 1867 通过、4 跳过）；拦截模式 干净克隆 1870 passed, 1 skipped, 35 deselected；本机 1870 passed, 1 skipped, 35 deselected；前端测试 22 个全部通过；真实 data_lake 文件清单不变）：本机干净克隆与本机真实环境两种条件全量 pytest（默认拦截模式）+ 前端测试；真实 data_lake 前后文件清单（路径 / 大小 / 修改时间）一致。部署后服务器核对：AIAE 基金仓位读数与改动前一致、执行目标不变。
- 长期待办：(b) 引擎改为用到时才建缓存目录（`hf_proxy_engine`、`fred_guard` 等导入时 makedirs），之后撤销守卫的"data_lake 树内新建空目录"例外。
- 待办：一键推送前自动跑本机全量 pytest 和前端测试，任一失败则中止推送。update.sh 查 CI 状态暂不做。
- 服务器部署核对（2026-11-03 11:47，提交 119891c，容器 `quant_dashboard_app`）：容器内无 `ALPHACORE_AIAE_*` 环境变量；基金仓位读取路径 `/app/data_lake/aiae_fund_position.json`，读数 83.19% / 2026-10-30 / ths_api，与部署前（旧代码，同一容器）一致；决策中枢执行目标 25.0%（当前 97.9%，由组合回撤刹车决定），与部署前的回撤三档上限一致，本次改动不涉及执行目标计算。

## 决策中枢视觉 1c · 宏观背景与复盘（2026-11-03，方案见 `docs/DECISION_HUB_VISUAL_1B_1C_PLAN.md` 第 11 节）
- 改前截图：11:5x，服务器页面（经隧道 localhost:18000），桌面 1440 与手机 375，不另存。复盘标签显示 11-02、11-03 执行目标均为 25.0%。
- 提交 A（前端视觉与展示，判定与接口不变）：
  - AIAE 面板：标题改为"AIAE 配置热度 · 背景"（不作执行依据）；ECharts 彩虹半环改为中性 R1–R5 档位条（区间取后端 `regime_thresholds`，缺失时不显示区间）；读数行写明"权益配置热度，非仓位"；删除每档"仓位 x%"；去 emoji、发光（`regimeGlow` / `dangerPulse`）、毛玻璃、hover 位移；手机端五档不再溢出。
  - 去掉前端默认数字（档位 3、AIAE 22、上限 55、斜率 0、融资热度 2.0、基金仓位 80、默认阈值）：缺数据显示 "--"、不画进度条、标签"数据缺失"。超警戒线用警告色加文字标签"超警戒线"（背景读数，不用阻断色）。锁定横幅改为"AIAE 数据质量不足，读数仅供参考"（原文案含"仓位建议"）。
  - 市场动态：不显示接口图标（emoji），严重度改为文字标签，冲击芯片中性色；标题"市场动态 · 背景"。
  - 复盘 · 背景读数验证：去全部 emoji；准确率数字中性色；成熟度、连续命中改为文字标签；去掉"建议在此级别下增加执行力度"等操作建议；T+5 收益柱改为红涨绿跌（原为绿涨红跌），图表颜色取 `ac_tokens.css` 变量。
  - 隐藏模块不处理；JCS 只复核，不改。新增 `tests/test_decision_visual_1c.cjs`。
  - 改后截图（12:41，本机服务）补充两处，用户同意随提交 A：
    - 市场动态冲击说明里的"仓位 55% → 25% (↓30%)"（9-07 VIX 飙升事件，来自后端情景冲击结果）与"执行目标是唯一仓位数字"冲突。前端**临时过滤**：只去掉"仓位 x% → y%"这一段及其括注，事件名称和其他说明保留。后端情景冲击的仓位文案登记到第 2 轮待办。
    - 准确率分析标签列加宽到 128px 且不换行（原"JCS 40–70 一般"会折行）。
  - 生产就绪检查 `engines/production_check.py::check_frontend_v5_sync`（CI 第三步也会跑）：原契约要求 `hub_core.js` 保留默认阈值副本 `_DEFAULT_REGIME_THRESHOLDS`，并且与后端一致。1c 已删除这份副本（缺阈值时不显示区间），旧检查因此判失败（本机两种环境全量各 1 项失败）。契约改为：前端必须读取 `snapshot.regime_thresholds`；保留副本时，副本必须与后端一致；没有副本时判通过（只有后端一份阈值，不存在漂移）。其余判定不变，抽出纯函数 `frontend_threshold_status`，`tests/test_production_check.py` 新增 5 种情形。
- 提交 B（后端缺省值改为 None，方案 11.3 节第 1–3 项）：
  - `dashboard_modules/decision/snapshot.py`：`margin_heat`、`fund_position` 缺失为 None（原 2.0 / 80）。
  - `services/position_engine.py`：首页 `risk_panel` 缺数据时 value 为 None、status 为 `"unknown"`；`overall_risk` 只按已知项判定，有缺项且未触及 high / medium 时为 `"unknown"`。原写法对 None 做比较会抛 TypeError（`dashboard_builder` 透传 None 时）；有数据时分级与原来完全一致（参数化覆盖阈值边界）。
  - `dashboard_modules/assemble_response.py`：首页 AIAE 温度计两字段缺失为 None（原 0，首页显示成"0%"）；`static/js/renderers.js` 两处改为显示 "--"。
  - 融资热度来源与日期（用户 12:42 要求）：`services/aiae_safety.build_aiae_context` 透传 `margin_heat_meta` 中的融资交易日（`margin_heat_date`）与降级标记（`margin_heat_fallback`），决策页显示"Tushare 融资余额 / 总市值 · 截至 2026-11-02"。引擎降级（融资余额或市值用了缺省值）时，决策页快照、首页温度计与首页风险面板都不显示数值（显示 "--"、状态"未知"），因为缺省值算出的 2.0 左右和真实值无法区分。
  - 影响：只影响展示与首页风险状态文字。合规引擎、执行目标链路、跟踪止盈、回撤刹车都不读取这两个字段（源码断言），带与不带这两个字段时，执行层 `evaluate` 与 `run_compliance_check` 结果完全相同（测试 `tests/test_aiae_display_missing.py`）。
- 核实：页面融资热度"2.00%"是真实值（`is_fallback=false`，三所齐全，融资 11-02 / 市值 11-03，2.30 万亿 / 115.19 万亿）。当前 V6A 以简单值定档，融资热度不影响档位与执行目标。登记【高】待办：AIAE 引擎融资热度缺省值改为不可用并降级标注（方案第 10 节）。
- 验证（云端沙盒，依赖不全的部分用桩）：前端 21 个 `.cjs` 全部通过；新测试对旧代码失败、对新代码通过；后端在可运行的范围内，改动前后的失败集合一致（均为沙盒缺 fastapi 等依赖），新增 110 项通过。本机两种环境全量 pytest 与改后截图由用户执行，结果补记。
- 提交与部署（2026-11-03）：e957849（A）、8389732（B）、bd6a958（补齐 A 的 `production_check.py` / `test_production_check.py` 与 B 的 `aiae_safety.py`：前两次提交时漏选，CI #123 因此失败）。提交前两种环境全量 pytest 各 1983 通过、前端测试全部通过；CI **#124** 通过。12:55 服务器部署 bd6a958，预热后经隧道只读核对：执行目标 25.0%（当前 97.9%）、合规 2 条硬阻断、止损已触发 2 只，与部署前一致；AIAE 读数 24.3%·R3，档位条高亮 R3（23.83–26.25%）；融资热度"2.00% · Tushare 融资余额 / 总市值 · 截至 2026-11-02"（`margin_heat_fallback=false`）；基金仓位 83.19%（同花顺 · 截至 2026-10-30）；市场动态无"仓位 x% → y%"。

## 推送前检查 · 一键推送提交前自动测试（2026-11-03）

- 起因：1c 两次提交漏选 3 个文件，本机测试是绿的（测的是工作区），CI #123 失败。
- 实现：
  - 新增 `_dev_tools/pre_push_check.py`；外层 `一键推送.bat`（v4.1，NEWS 仓库）在 quant_dashboard 提交前调用它，取代原来的无条件 `git add -A`。NEWS 仓库流程不变。
  - 暂存区为空而工作区有改动：先列出将加入的全部文件，输入 A 才 `git add -A`，直接回车不加入。
  - 已修改或新建、但不在本次提交里的代码文件（.py / .js / .cjs / .html / .css / .md / 配置等；.json 只算 `config/` 下的）：逐个列出，输入 YES 才继续，否则中止。其他文件只提示。非交互运行时一律中止。
  - 测试干净快照：`git checkout-index` 导出暂存区（暂存区为空而本地有未推送提交时即为 HEAD）到临时目录，按 CI 步骤跑 AST 语法检查、pytest 全量（离线，占位令牌，不带 `API_SECRET_KEY` / `ALPHACORE_ENV`）、`production_check.py --code-only`、`tests/*.cjs`。快照里没有 `.env` 和被忽略的 `data_lake`，漏选的文件在快照里不存在。任一失败 → 列出失败项，不提交、不推送。临时目录用后删除。
  - 选择只测干净快照（约 1.5 分钟），不在推送时再跑真实环境：快照才是即将提交的内容，漏选能在这一步暴露；真实环境全量 pytest 改动较大时手动跑。
  - 跳过开关（仅紧急）：`ALPHACORE_SKIP_TESTS=1` 且 `ALPHACORE_SKIP_REASON` 非空才跳过；只设开关不写原因 → 中止。跳过时文件确认照样执行；原因写入本次推送日志与常设的 `.push-logs\skipped-tests.log`；提交说明末尾加 `[skip-tests: 原因]`（提交已在推送前手动完成时无法追加，以日志为准）。
  - 提交说明由检查脚本写入临时文件，bat 用 `git commit -F`（中文原因不经命令行转义）。
- 测试：`tests/test_pre_push_check.py` 10 项（临时 git 仓库 + 假 runner：大写 YES 才放行、非交互中止、测的是暂存区版本而非工作区、漏选文件不在快照、A 先列出再加入、无内容不测、未推送提交照测、失败中止并记日志、跳过须写原因、跳过时记录与标记）。云端沙盒在真实 conftest 守卫下通过；另用临时仓库端到端跑真实步骤（含失败的 pytest 与 .cjs）确认失败项列出、退出码 1。bat 本身无法在沙盒运行，以本轮推送作首次实测。
- 首次实测（20:33，提交 b0c4afa 未推送）：检查按设计拦下推送（pytest 1993 通过；前端 20/21，`test_warmup_frontend.cjs` 失败）。原因不在被测代码：本机 `core.autocrlf=true`，快照导出成 CRLF，而该测试按 `\n` 查找 `decision.js` 片段；CI 在 Linux 检出为 LF，不受影响，本机工作区的该文件也是 LF，所以真实环境测试通过。修正：导出快照时加 `-c core.autocrlf=false -c core.eol=lf`，换行与 CI 一致；不改测试、不放宽检查。新增测试 `test_snapshot_line_endings_match_ci_even_with_autocrlf`（按字节读快照；对旧代码失败、对新代码通过），共 11 项。
- 本机真实环境随后跑出这 3 项失败（`test_tests_run_on_index_snapshot_not_worktree`、`test_unpushed_commit_is_tested_when_stage_empty`、新加的换行测试）：测试用 `write_text` 建临时仓库，Windows 上写成 CRLF 存入，快照原样导出，与预期的 LF 不符；检查脚本本身无误（在沙盒用 CRLF 写入复现同样 3 项）。修正测试：临时文件按字节写（`w()`）。沙盒在全局 `core.autocrlf=true` 下 11 项通过，换行测试对旧检查代码仍失败。
- 同次运行暴露一键推送的问题：日志中"finished"出现在 NEWS 处理过程中，错误计数为 2（实际只有 quant_dashboard 失败）。`一键推送.bat` 一直是 LF 换行，cmd 对 LF 批处理查找标签（`call :LOG`、`goto`）可能错位，v4.1 新增标签后触发。修正：bat 改为 CRLF，内容不变。NEWS 仓库本次推送（6a7d6ae）正常。
- 本轮同时更新 `docs/ACCOUNT_AUTHORITY_AND_RISK_REFRESH_PLAN.md` 1.4 节：服务器安全 ① ② 完成（删除 8000 规则、生产模式、更换令牌、清理旧 `.env` 备份），剩余 ③ 备份加密。
- 提交与推送（2026-11-03）：quant_dashboard 62095ff（b0c4afa 两次修正后合并为一个提交），NEWS f5a1d40（`一键推送.bat` v4.1 CRLF）。推送前本机真实环境 pytest 1994 通过；一键推送的快照检查 AST / pytest 1994 / production_check 10/10 / 前端 21/21 全部通过（138 秒）；CI **#125** 通过。只改工具、测试与文档，服务器无需部署。剩余待办（备份加密 ③、`dashboard_data_stale` 排查、令牌再换一次）用户决定 12 月以后再处理。

## 组合页精简（2026-11-03，方案见 `docs/PORTFOLIO_SLIMMING_PLAN.md`）

- 审计（21:2x，本机 8000 非权威；服务器隧道当时未连上）：顶栏徽章由前端 PfAlerts 12 条规则汇总，本机显示 2 BLOCK（单票超配 科创50ETF 25.1%、显著跑输基准），合规实际为 2 条硬阻断（主题集中度 半导体电子 88.7%、仓位超限检查）；半导体集中度同页 3 个数字（饼图 54% / 穿透行业 73.7% / 合规主题 88.7%）；120D 波动 10.2% vs 波动预算 45.7%；120D 回撤 −26.1%（当前持仓模拟）vs 回撤刹车当前 −30.3%；Trade 弹窗与「调整仓位」列在个人分析模式下恒 403；清零无门控、无备份。
- 21:54 用户确认方案 6 项 + 穿透差异核实 + 视觉待办只记录（方案第 8 节）。提交顺序 P0 → P1 → P2 → P3 → P4。
- 穿透 73.7% vs 合规 88.7% 已核实：同一拆分与分母，差别在归类层级。合规主题「半导体电子」= 半导体 73.72 + 元器件 12.22（沪电股份 7.91、深南电路 3.49 直接持有，其余 ETF 成分 0.82）+ 通信设备 2.66（仕佳光子 1.39 直接、睿创微纳 0.59 经科创50ETF、其余 0.68）+ IT设备 0.05 + 电器仪表 0.01 = 88.66；本机无手工归类。按用户规则并列显示并写明口径（P3）。

### P0 · 清零后端门控（单独提交）
- `POST /portfolio/reset` 默认 403；环境变量 `ALPHACORE_ALLOW_PORTFOLIO_RESET=1`（须恰为 "1"）才放行；请求体 `confirm_total_asset` 与当前估值总资产相差 ≤ ¥1，否则 409；缺失或非数字 422；估值不可读 503。
- `PortfolioEngine.reset_portfolio` 清零前先 `backup_store()`：持仓文件复制到同目录 `archive/portfolio_store.<时间>.pre_reset.json`；备份失败抛异常、不清零（接口返回 ERR_RESET）。返回值新增 `backup_path`，操作日志注明备份文件名。
- 前端清零弹窗改为输入当前总资产（按钮在 P4 隐藏）。
- 测试：新增 `tests/test_portfolio_reset_guard.py`（17 项：默认拒绝、开关须恰为 1、缺/错总资产、估值不可用、备份失败不清零、放行时备份内容 = 清零前原文件）；对旧代码失败、对新代码通过。云端沙盒（PyPI 不可用，fastapi / tushare / redis 用仓库外桩）全量 pytest 改动前后失败集合相同（均为沙盒缺 pyarrow 等依赖，10 项），新增 17 项通过；前端 21 个 `.cjs` 全部通过。本机两种环境全量 pytest 由用户执行，结果补记。
- 本机真实环境 pytest 2011 passed / 1 skipped，前端测试全部通过；推送前快照检查通过。提交 f6dd88a（2026-11-03 22:16 推送）。
- 不涉及：执行目标、合规、跟踪止盈、买入门控、当前仓位的计算代码均未改动。

### P1 · 合规徽章与告警条只读合规引擎
- 新增 `static/js/portfolio_compliance.js`：徽章与核心资产区告警条只读 `/decision/compliance-check`（与决策中枢、审计页同一结果）。blocked 且有阻断明细 → "合规阻断 · N 条硬阻断"（告警条列合规原文并注明来源）；warning → "合规警告 · N 条"；仅 passed 且有检查项、无阻断无警告、非部分缺失时显示"合规通过"；warming_up → "合规加载中"（15 秒重试，最多 40 次）；接口失败 / 状态未知 / 状态与明细矛盾 → "合规不可用"（提示"不代表合规通过"，60 秒重试，最多 3 次）。徽章为链接，跳转 `decision.html#compliance-engine-panel`，显示"读取于 HH:MM"。
- 删除 `PfAlerts` 全部 12 条前端阈值规则（单票 20%、仓位 90%、行业 40%、波动 30%、跑输基准 BLOCK、Beta / 因子 / 滑点规则及"评估止损或加仓摊薄"等操作文案）。"价格源降级"改为数据质量提示（非风险判定）。Brinson / 因子 / 滑点面板的告警条不再有内容（面板在 P4 隐藏）。
- 实测（服务器隧道 22:1x）：合规接口一次返回 `status=unknown`、无检查项，约 20 秒后恢复为阻断 2 条；新徽章此时显示"合规不可用"并重试。与 1b 期间登记的【低】"缓存过期后首次加载显示不统一"属同一现象，未另处理。
- 测试：新增 `tests/test_portfolio_compliance_badge.cjs`（状态映射、9 种异常不显示通过、HTML 转义、徽章链接、源码无旧阈值）；对 P0 代码失败、对新代码通过。前端 22 个 `.cjs` 全部通过；云端沙盒全量 pytest 失败集合与 P0 相同。提交 2d525fc（2026-11-03 22:23 推送）。

### P2 · 当前仓位只读 account_exposure
- `GET /portfolio/valuation` 附带 `account_exposure`（同一次估值调用 `services/account_exposure.from_valuation`，与决策中枢、合规、买入门控同一函数）；计算失败为 `{status: unavailable, pct: null}`，原估值字段不变。
- 组合页"当前仓位"只读 `account_exposure.pct` 与 `label`（持仓截至 … 对账单 · 价格 … 收盘）；删除前端逆回购识别与分母重算、"未追踪 x%"（实为逆回购 + 导入日市值差，名不副实）、按 >90% / >80% 着色（前端阈值）；不可用时显示 "--"，不用其他数字替代。文案"总仓位"改为"当前仓位"。
- 数字核对：改前前端算法与 `from_valuation` 公式相同（本机 100.0% = 决策中枢 100），本次只改来源，不改数字。
- 测试：新增 `tests/test_portfolio_valuation_exposure.py`（3 项：附带字段 = `from_valuation` 结果、失败为 unavailable、估值失败响应不变）与 `tests/test_portfolio_position_source.cjs`（源码无自算、ok / 5 种不可用输入）；均对 P1 代码失败、对新代码通过。前端 23 个 `.cjs` 全部通过；云端沙盒全量 pytest 失败集合不变（新增 3 项通过）。
- 注意：后端改动需重启服务才生效；重启前页面当前仓位显示 "--"（安全方向）。
- 本机 pytest 2014 passed / 1 skipped，前端全部通过。提交 e8b9d14（22:33 推送）。
- 服务器部署 e8b9d14（11-04 12:39 服务器时间），经隧道只读核对（22:40）：组合页徽章"合规阻断 · 2 条硬阻断"（主题集中度、仓位超限检查）；组合页当前仓位 97.9% = 决策中枢 97.9% = `account_exposure` 97.9%（持仓截至 11-03 12:56 对账单 · 价格 11-03 收盘）；执行目标 25%；跟踪止盈 11-03 RED 2 / YELLOW 1 / GREEN 12；买入门控（MR 预览 588000 买入）`allowed=false`、`COMPLIANCE_HARD_BLOCK`、gate_pct 97.9；未带 API Key 的清零请求 401（带 Key 时默认 403 由单元测试覆盖）。与部署前一致。

### 服务器台账核实（2026-11-03 22:40，用户在服务器执行只读命令）
- 资金股份快照：10-30（20261030资金股份查询，¥1,304,833.71）、11-02 两条（20261102资金股份查询，¥1,357,141.18 / .67）；均无估值时点（`valuation_timing=unknown`）。**没有 10-29 收盘后快照**；通达信无法补导过去某日的资金股份。
- 含发生金额的资金来源（交割单）：08-31→10-27、10-09→10-27、09-03→10-30、09-07→11-02（20261103交割单查询），覆盖连续到 11-02。区间 10-30→11-02 入出金 0，整账户 TWR +4.01%（近似：快照无估值时点）。
- 疑点核实：数据库 `portfolio_snapshots` 的日期是记录日（每日 15:35 记录当时持仓文件），台账快照日期是对账单日期，两者不是同一口径，台账无误。11-03 12:56 导入的是 20261102 对账单，因此当前仓位标注"持仓截至 11-03 12:56 对账单"实为导入时间（对账单无估值时点时回落到导入时间）——登记待办。
- 用户决定（22:4x）：账户收益从 10-30 收盘起算，页面写明"10-29 收盘快照缺失，自 10-30 起"。
- 以后延长区间：每个交易日收盘后导出「资金股份查询」+「交割单查询」，在服务器导入；导入时填写估值时点（如 15:10）才能精确分段（组合页导入弹窗目前不传 `valuation_time`，登记待办）。

### P3 · 收益 / 回撤 / 波动 / 风险贡献 / 穿透口径
- 核心资产 KPI 新增 `static/js/portfolio_kpis.js`，三项只读唯一来源：账户收益 ← `/portfolio/returns?start=2026-10-29`（ok 时显示 TWR、区间、"近似"，起点晚于 10-29 时写明缺失；否则"数据不足"+原因）；组合波动 ← `/portfolio/vol-budget` 的 `portfolio.portfolio_vol` / `target_vol`（与合规「组合波动预算」同一计算）；当前回撤 ← 同一视图 `waterfall[drawdown]`（`risk_state.drawdown_brake`），只显示回撤与档位，不显示"降至 x%"。删除「建仓以来 ROI」、120D 波动 / 夏普 / 最大回撤（`/portfolio/risk` 不再用于 KPI）。
- 风险贡献：MCTR 图删除，改为穿透区折叠表，读波动预算 `portfolio.positions[].risk_share`（250 日 + 收缩相关，与合规同源）。
- 穿透区顶部合规行：读合规 `sector_concentration.metrics`（P1 同一次请求，经 `pf:compliance` 事件），后端 `/portfolio/lookthrough` 新增 `theme_view`（`services/concentration.industry_theme_breakdown`，同一 `INDUSTRY_THEME_MAP`）。两者相差 ≤ 0.5pp 时并列写明口径（"合规判定 · 主题「半导体电子」占账户 88.7% …；其中 行业 半导体 73.7% + 元器件 12.2% + 通信设备 2.7% + 其他 0.1%"），否则只显示合规数字、行业拆分收进展开项并标"口径不一致，以合规为准"。
- 后端结构化字段：`services/portfolio_vol.build_decision_view` 回撤行新增 `dd`、`tier`（只读，上限瀑布与有效上限不变）。
- 测试：新增 `tests/test_portfolio_p3_sources.py`（4 项）与 `tests/test_portfolio_kpis.cjs`（服务器实际返回形状、5 种不足、回撤不显示仓位数字、风险贡献排序与转义、页面无 ROI/夏普/MCTR、穿透并列 / 不一致 / 缺失三种情形）；均对 P2 代码失败、对新代码通过。`test_portfolio_position_source.cjs` 截取范围随 ROI 删除调整。前端 24 个 `.cjs` 全部通过；云端沙盒全量 pytest 失败集合不变（新增 4 项通过）；`test_vol_overlay` / 穿透 / 集中度相关 97 项通过。
- 行业饼图仍由 `/portfolio/risk` 绘制，P4 隐藏。
- 本机 pytest 2018 passed / 1 skipped，前端全部通过。提交 3cf3423（22:52 推送）。
- 服务器部署 3cf3423 后经隧道核对（22:58）：账户收益 +4.01%（10-30 收盘 → 11-02 收盘 · 10-29 收盘快照缺失，自 10-30 起 · 近似）；组合波动 44.9%（目标 30%）；当前回撤 -33.1%（回撤刹车第 3 档）；徽章合规阻断 2 条；当前仓位 97.9% = 执行层；执行目标 25%；跟踪止盈 RED 2 / YELLOW 1 / GREEN 12；买入门控 allowed=false（COMPLIANCE_HARD_BLOCK）。与部署前一致。
- **发现（服务器数据缺口，登记【高】待办）**：服务器穿透接口 4 只 ETF（588000 科创50、159995 芯片、159516 半导体设备、510300 沪深300）为 `CONSTITUENT_ETF_NOT_FOUND`，未知暴露 47.2%（本机为 3.45%）——服务器缺 ETF 成分数据。因此服务器合规主题集中度（90.0%）对这几只 ETF 走的是按名称回退，而不是穿透；穿透区行业合计 47.0% 与合规 90.0% 相差 > 0.5pp，页面按设计只显示合规数字、行业拆分收进展开项并标"口径不一致，以合规为准"。需排查服务器成分数据的来源 / 同步（本机有、服务器无）。

### P4 · 隐藏开关与按钮处理
- 新增 `config/portfolio_modules.json`（8 个模块关闭，`hidden_on=2026-11-03`，`review_on=2026-12-01`，各写原因与恢复条件）、`services/portfolio_modules.py`（复用 `services/decision_modules.load_modules`：未列出默认开启，配置缺失 / 损坏全部开启）、只读接口 `GET /portfolio/modules`、前端 `static/js/portfolio_modules.js`（`.pm-off` 隐藏；`PfModules.on()` 供加载入口判断）。
- 关闭：行业饼图（不穿透）、迷你走势线（当前持仓模拟、无标注）、Brinson、当前持仓历史模拟、三因子、滑点（含 Bootstrap 写入按钮）、新增仓位 / Trade 弹窗、清零按钮。关闭的模块不发请求：`/portfolio/risk`、`/portfolio/nav`、`/portfolio/brinson`（Tushare）、`/portfolio/factor-attribution`、`/slippage/*` 在开关关闭时都不再请求。后端接口与引擎保留（只有组合页调用，无定时任务）。
- 删除：持仓表「调整仓位」列（只打开恒 403 的弹窗）；导入后「调仓路径」提示（目标取 AIAE 矩阵上限，不是执行目标）。
- 交易记录 → 成交记录：改读成交台账 `/portfolio/trades?limit=50`（导入的交割单 / 历史成交，显示总笔数）；原 `/portfolio/history` 为系统操作日志，前端不再调用（接口保留）。
- 结构：穿透暴露与压力情景（默认展开）、决定记录与复盘上移到持仓表之后。
- 恢复方法：把 `config/portfolio_modules.json` 对应模块改为 `"enabled": true`，刷新页面即可（不需重启）。
- 测试：新增 `tests/test_portfolio_modules.cjs`（8 个模块配置齐全、选择器在页面存在、关闭时加 `.pm-off`、接口失败全部开启、加载入口均经开关、按钮 / 提示删除、成交台账、结构顺序）与 `tests/test_portfolio_modules.py`（3 项）；均对 P3 代码失败、对新代码通过。前端 25 个 `.cjs` 全部通过；云端沙盒全量 pytest 失败集合不变（新增 3 项通过）。
- 本机 pytest 2021 passed / 1 skipped，前端全部通过。提交 4f39bb5（23:04 推送）。
- 服务器部署 4f39bb5 后经隧道核对（23:1x）：8 个模块均已隐藏，导入 / 同步按钮保留；持仓表无「操作」列；成交记录"共 60 笔"（成交台账）；穿透区默认展开。页面加载只请求 modules / compliance-check / valuation / lookthrough / stress-lookthrough / review×2 / returns / trades / vol-budget，`/portfolio/risk`、`/nav`、`/brinson`、`/factor-attribution`、`/history`、`/slippage/*`、`/decision/position-path` 均未请求。执行目标 25%；当前仓位 97.9%（组合页 = 执行层）；合规阻断 2 条（主题集中度、仓位超限检查）；跟踪止盈 RED 2 / YELLOW 1 / GREEN 12；买入门控 allowed=false（COMPLIANCE_HARD_BLOCK）。与改前一致。
- 页面高度（服务器数据）：桌面 1440 为 3,458px（改前本机 4,523），手机 375 为 5,936px（改前 7,724）。其中穿透区默认展开占 1,256 / 2,417px；折叠时约 2,200 / 3,520px，与方案估算一致。
- 本轮收尾。登记待办（见 `docs/PORTFOLIO_SLIMMING_PLAN.md` 第 9 节）：【高】服务器缺 ETF 成分数据；当前仓位标注在对账单无估值时点时显示导入时间、导入弹窗不传 `valuation_time`；审计页白算 `calculate_risk_metrics`；波动预算与估值价格日期不一致；决定记录存的是权益口径集中度。视觉问题见方案第 7 节。隐藏模块 2026-12-01 复查。

## 服务器 ETF 成分缺失修复（2026-11-03/04，方案见 `docs/ETF_CONSTITUENT_FIX_PLAN.md`）
- 审计（11-03 23:2x）：持仓登记表 `config/lookthrough_extra_etfs.json` 被 .gitignore 排除、只在本机 → 服务器成分刷新只含研究池 → 科创50 / 芯片 / 半导体设备 `CONSTITUENT_ETF_NOT_FOUND`，合规对其按名称整只归类；沪深300 两边都未登记。服务器成分快照获取于 10-10，此后三个周六均未写入（推测周六任务失败，原写法第一步失败会跳过成分刷新）。本机与服务器权重均为 9-30，11-14 起过期。主题集中度：本机 名称 91.7% / 穿透 88.7%；服务器 名称 90.0% / 穿透 ≈ 86.9%（推测）。审计中"科创50 约 23% 查不到行业"为沙盒缺行业表所致，已更正。
- 用户决定（11-04 01:52）：登记表放服务器 `data_lake/`（不进 git，scp 一次）；穿透判定 + 行业未知并列与警告（C2）；510300 登记 000300.SH（出处见方案第 3 节）；任务失败告警与审计页任务状态（C3）；截止 11-14。

### C1 · 登记表位置、成分刷新与审计读数
- `services/industry_constituents.py`：新增 `DATA_EXTRA_HOLDINGS_PATH`（`data_lake/lookthrough_extra_etfs.json`）与 `extra_holdings_path()`（data_lake → config）；`extra_holdings_info()`（位置、修改时间、内容指纹前 12 位、有效条数，不含持仓数量金额）；`constituent_refresh_reasons()` / `refresh_constituents_if_needed()`（快照获取 > 7 天、持仓 ETF 不可穿透、权重距过期 ≤ 10 天）；`constituent_health()`（审计读数）。
- `main.py`：周六 `industry_universe_refresh` 四步独立执行、成分刷新排第一，任一步失败记录后整体抛错（C3 记录结果）；新增交易日 08:40 `constituent_refresh_check`。
- `engines/audit_engine.py`：A 区数据新鲜度新增"ETF 成分（合规穿透）"读数（不带分数，不参与评分；有持仓 ETF 按名称归类 / 权重 ≤ 10 天过期 / 登记表缺失时为"警告"）。
- 本机登记表（不进 git）追加 510300.SH → 000300.SH（出处见方案），供用户拷到服务器 `data_lake/`。
- 测试：新增 `tests/test_constituent_refresh.py`（7 项：读取顺序、元信息、刷新原因含服务器 11-03 实际情形与 11-04 "剩 10 天"、只在需要时刷新、健康读数、审计读数不计分、调度源码）；`tests/test_lookthrough.py` 隔离新的 data_lake 路径。新测试对旧代码失败、对新代码通过；穿透 / 成分 / 审计相关 89 项通过；云端沙盒全量 pytest 失败集合不变；前端 25 个 `.cjs` 全部通过。
- 不涉及判定：合规规则、执行目标、跟踪止盈、买入门控、当前仓位代码未改；服务器在拷贝登记表并刷新后，主题集中度预计从 90.0% 变为 ≈ 86.9%（按穿透），结论仍为硬阻断。
- 本机 pytest 2028 passed / 1 skipped，前端全部通过；11-04 02:03 推送并部署到服务器。用户 scp 登记表到服务器 `data_lake/lookthrough_extra_etfs.json`（11-04 16:07 北京时间）并手动刷新：20 条记录全部可用（研究池 16 + 登记 4），权重日期 2026-10-30，快照获取 2026-11-04 08:08 UTC。
- 隧道核对（11-04 02:1x）：持仓 5 只 ETF 均可穿透（含 510300），未知暴露 0%；合规主题「半导体电子」**90.0% → 86.8%**（按穿透；审计估算 ≈ 86.9%），结论仍为硬阻断（主题集中度 + 仓位超限检查）；组合页穿透区与合规一致，改为并列显示（行业 半导体 72.5% + 元器件 11.3% + 通信设备 2.9% + 其他 0.1%）。执行目标 25%、当前仓位 97.9%、跟踪止盈 RED 2 / YELLOW 1 / GREEN 12、买入门控 allowed=false（COMPLIANCE_HARD_BLOCK）不变。审计页"ETF 成分（合规穿透）"为读数（可穿透 5/5，不计分），登记表指纹 2e5a883e8728 与本机文件一致；A 区可信度 86（可信）。
- 服务器排查（用户 11-04 01:57 提供）：成分快照此前最后写入 10-10 08:30（周六）；`/app/config/` 无登记表；跟踪止盈日终 11-04 15:51 正常；容器随每次部署重建，`docker logs` 只有本次启动以来的内容，无法回溯周六失败原因（C3 处理）。服务器时区为北京时间。

### C3 · 定时任务运行记录与失败告警（用户 11-04 02:11 要求先于 C2）
- 新增 `services/job_runs.py`：`tracked()` 包装任务，结果写 `data_lake/job_runs.json`（持久化，部署不丢；每任务保留最近 20 次）。判为失败：抛异常；运行期间本线程写出 ERROR 日志（现有回调吞掉异常只写日志的情形；"ac" / "alphacore" 命名空间不向 root 传播，三处都挂）；返回 dict 的 status ∈ {error, failed, degraded} 或 errors 非空。原函数返回值与异常行为不变。
- 关键任务（用户指定）：trailing_stop_daily、daily_warmup、constituent_refresh_check、aiae_fund_position_update、audit_daily_snapshot —— 失败当天即推送（写告警表 + 复用 alert_monitor 推送通道，同一任务每天 1 次）；其他任务连续失败 ≥ 3 次推送（每天 1 次）。
- 新增看门狗 `job_watchdog`（每 30 分钟）：按调度规则推算最近一次应运行时间，过 45 分钟仍未成功的关键任务推送"未运行"（每天 1 次）。逾期只从首次启用记录之后算起（`tracking_started` 只记第一次，之后停机期间错过的运行也算逾期）。
- `main.py`：`scheduler.start()` 前 `wrap_scheduler()` 包装全部任务（含看门狗）；`audit_daily_snapshot` 失败日志由 warning 改为 error（据此判失败）。`services/warmup_pipeline.daily_warmup_callback` 返回 `{ok, errors, duration_sec}`（Phase 1 在子线程执行，失败不出现在本线程日志，靠返回值判定）。
- 审计页 A 区系统状态新增"定时任务运行"读数：关键任务最近成功时间、失败 / 逾期标记，其他任务的异常；不带分数、不参与评分；关键任务失败或逾期为"警告"。
- NLP 情报（nlp_scan_am / pm，调 DeepSeek）核实：首页「AI 情报流」（index.html `intel-feed-section`，renderers.js 读 `/api/v1/intelligence/latest`、可手动"扫描"）仍在使用 → **本轮不暂停**，是否连同首页面板一起下线待用户决定。
- 测试：新增 `tests/test_job_runs.py`（17 项：成功 / 异常 / 吞掉异常的 ERROR 日志（3 个命名空间）/ WARNING 不算失败 / 7 种返回值 / 关键任务当天推送且不重复 / 非关键连续 3 次推送 / 关键任务集合 / 逾期推算与宽限 / 追踪起点只记一次 / 看门狗只推关键任务且每天 1 次 / 包装调度器不重复 / 审计读数不计分 / main 接线）；对 C1 代码失败、对新代码通过。云端沙盒全量 pytest 失败集合不变（新增 17 项通过）；前端 25 个 `.cjs` 全部通过。
- 不涉及判定：执行目标、合规、跟踪止盈、买入门控、当前仓位计算未改。推送通道取服务器 `config/alert_config.json` 的 `channels_enabled`；未配置微信 / 企微 / 邮件时只写告警表（首页告警铃可见）。
- 本机 pytest 2045 passed / 1 skipped，前端全部通过；11-04 02:20 推送（push-20261104-022055）。服务器部署后日志 `[16:25:08] 定时任务运行记录已启用: 22 个任务`，`data_lake/job_runs.json` 已建立（`tracking_started` 2026-11-04T16:25:08）。
- 隧道核对（11-04 02:2x）：审计页 A 区「定时任务运行」读数列出 22 个任务；关键任务今天 15:35 / 15:50 / 16:00 在启用前已运行，显示"无记录"、不算逾期；盘中轮询已有成功记录。执行目标 25%、合规阻断 2 条（主题集中度 86.8%、仓位超限检查）、跟踪止盈 RED 2 / YELLOW 1 / GREEN 12、买入门控（合规硬阻断即不放行，permissions.increase=false）不变；当前仓位 98.0%（11-04 收盘价更新，持仓 / 现金未变，口径未变）。

### C2 · 合规主题集中度：按名称归类与行业未知（规则见 `docs/DECISION_RULES.md` 1.2.1）
- `engines/compliance_engine.py`：新增 `_theme_analysis()`（与原 `_theme_buckets` 同一组 `theme_rows`，buckets 不变；另带出按 ETF 汇总的 `name_fallback`（整只 / 权重未覆盖余量、原因码与中文原因、是否宽基豁免）与 `unknown_industry`）；`_theme_buckets()` 改为调用它。`theme_metrics` 增加 `classification_basis`、`name_fallback`、`name_fallback_pct`、`unknown_industry`、`unknown_industry_pct`、`unknown_adjusted_pct`、`unknown_warn`、`basis_note`（一句说明，各页面共用）。
- 新增规则 `unknown_crossing()`：穿透值未超 40% / 60%，「穿透值 + 行业未知」超过 → 主题集中度软警告（不升级硬阻断）；已超阈值时在说明中补"另有穿透后行业未知 x%"。原阈值、硬阻断条件、买入成交后判定不变。
- 显示：组合页穿透区合规行（`lookthrough_panel.js`）、决策中枢合规区主题集中度行（`global_analytics.js` + `decision.css` 一条样式）、审计页 B 区（`audit_engine._compliance_checks` 在主题集中度 detail 后附"口径：…"）、首页仓位卡（行业未知超线时等级后标注，悬停显示口径）。买入门控只读 rule_id / rule_name / detail，不受新字段影响。
- 测试：新增 `tests/test_compliance_unknown_industry.py`（11 项：阈值跨越、按 ETF 列行业未知、新警告、无未知不报警、只多不少、硬阻断不变并附说明、整只 / 余量按名称归类与宽基标注、buckets 与原口径相同、keyword 口径标注、买入门控不受影响、审计 B 区 detail）与 `tests/test_compliance_basis_note.cjs`（组合页两分支 + 转义、决策中枢只在主题集中度行显示、首页标注）；对 C3 代码失败、对新代码通过。云端沙盒全量 pytest 失败集合不变（新增 11 项通过）；前端 26 个 `.cjs` 全部通过。
- 数字影响（预计）：服务器当前 5 只 ETF 全部可穿透、行业未知 0% → 主题 86.8% 与结论（硬阻断）不变，只多出口径说明；成分过期 / 缺失时显示"按名称归类，非穿透"及原因。
- 本机推送 11-04 02:46（push-20261104-024632，NEWS 3e4d8f6）。服务器部署后经隧道核对（11-04 03:1x）：合规主题「半导体电子」86.8%，结论硬阻断（主题集中度 + 仓位超限检查）不变；`basis_note` = "持仓 ETF 均按成分穿透；穿透后行业未知 0%"，按名称归类 0 只，`unknown_warn=false`。组合页穿透区、决策中枢合规区（仅主题集中度行）、审计页 B 区均显示同一口径说明。执行目标 25%、当前仓位 98.0%、跟踪止盈 RED 2 / YELLOW 1 / GREEN 12、加仓 / 下单权限关闭不变。ETF 成分修复（C1–C3）本轮收尾。

## AI 服务暂停与任务开关（2026-11-04）
- 起因：C3 首日记录发现日报 16:35 失败，`deepseek 调用最终失败: HTTP Error 402: Payment Required`（DeepSeek 余额不足）。用户决定先不充值，AI 模块去留并入首页精简；要求现在加开关，避免连续失败告警。
- 核实：DeepSeek 调用方为日报叙事（`dashboard_modules/report_generator`）、首页 AI 情报流（`engines/news_intelligence`，定时 nlp_scan_am / pm + 手动扫描）、AI 助手（`routers/assistant`）、AI 叙事（`services/narrative_engine`，2026-11-02 已随模块开关停用）。执行目标、合规、跟踪止盈、买入门控、当前仓位均不调用。
- **日报不暂停**：日报叙事本就有规则模板兜底（按代码：AI 调用失败 → `_build_narrative` 回退规则模板 → 照常保存），今天 16:35 被记为失败是因为 AI 调用写了 ERROR 日志；当天日报内容未在服务器核实（按日期查询今天会重新生成并再次调用大模型，故未查）。AI 服务暂停后日报直接用模板，不调 DeepSeek，照常生成、记为成功。日报产出只有两个读取方：`report.html`（历史回看）与决策中枢「生成日报」按钮（按需生成，同样走模板）；决定记录、复盘、审计历史都不读日报。
- 新增 `config/job_switches.json`（进 git，无密钥）与 `services/job_switches.py`：`jobs.<id>.enabled=false` 任务到点不运行（`job_runs.tracked` 调用前检查，不调用、不记失败）；`ai_services.enabled=false` 不调用大模型。未列出 = 开启；文件缺失 / 损坏 = 全部开启。本次暂停：`ai_services`、`nlp_scan_am`、`nlp_scan_pm`；关键任务一个未暂停（测试校验）。
- 关键任务被暂停（用户要求）：审计页 A 区为**警告**，显示"已暂停（关键任务不应暂停）"，仍按逾期计算，看门狗推送并写明"被开关暂停"；启动日志对关键任务写 warning。非关键任务暂停：不算逾期，单列"已暂停：…（原因）"，暂停前的旧失败不列为异常。
- 首页 AI 情报流：`/intelligence/latest` 附 `paused`（`label` = "已暂停 · 内容截至 MM-DD HH:MM"，内容时间取缓存扫描时间，否则取事件最晚 `created_at` 由 UTC 换算北京时间）；时间处显示该标签，扫描按钮停用，卡片仍显示最后一次内容。手动扫描接口返回 `status=paused`，不拉新闻、不调用大模型。
- AI 助手：新增 `GET /assistant/status`；打开面板即查询，暂停时显示"AI 服务暂停（余额不足）"，禁用输入框、发送与快捷问题；`/assistant/chat` 暂停时直接返回该提示（`code=2, paused=true`），不报原始错误。
- 审计页文案：从未成功过的任务由"无记录 · 失败"改为"从未成功 · 最近失败"。
- 测试：新增 `tests/test_job_switches.py`（11 项：缺失 / 损坏 = 全部开启、仓库配置无关键任务暂停且 id 有效、暂停任务不运行不记录、非关键暂停不逾期 / 关键暂停仍逾期、看门狗推送暂停的关键任务、审计读数（暂停单列 / 关键暂停为警告 / 新文案）、日报用模板且不调用大模型、NLP 扫描不拉新闻、AI 助手提示、情报流标签与 UTC 换算、启动日志接线）与 `tests/test_ai_pause_frontend.cjs`（情报流暂停 / 未暂停、扫描返回暂停、助手打开即检查与禁用输入）；对改前代码失败、对新代码通过。`tests/conftest.py` 把开关文件指向临时不存在路径（= 全部开启），既有 NLP 测试不受仓库暂停状态影响；`tests/test_job_runs.py` 一处断言随文案更新。云端沙盒全量 pytest 失败集合不变（新增 11 项通过），前端 27 个 `.cjs` 全部通过。
- 恢复：把 `config/job_switches.json` 对应项改为 `"enabled": true` 并重新部署（配置随镜像发布）。
- 推送 11-04 08:40（push-20261104-084051），服务器部署 013a455（北京时间 22:44）。启动日志：`定时任务已暂停: nlp_scan_am / nlp_scan_pm`、`AI 服务已暂停`、`定时任务运行记录已启用: 22 个任务`。隧道核对：`/assistant/status` 返回暂停；首页情报流时间处"已暂停 · 内容截至 11-04 15:15"、扫描按钮停用、仍显示 6 张旧卡片；打开 AI 助手显示"AI 服务暂停（余额不足）"，输入、发送、快捷问题均禁用（预热期间首次打开可能延迟 1–2 秒出现）；审计页 A 区"定时任务运行"为信息级，NLP 两项列在"已暂停"、不逾期，日报显示"从未成功 · 最近失败"（今天 16:35 那次，明天起按规则模板应为成功）。执行目标 25%、合规阻断 2 条（主题集中度、仓位超限检查）、加仓 / 下单权限关闭不变；当前仓位 98.0% → 100%、跟踪止盈 RED 2 / YELLOW 1 / GREEN 12 → RED 1 / GREEN 13，原因是用户 11-04 18:23 在服务器导入了 11-04 对账单（现金 ¥18.59），非本次代码改动。

## 权威环境收尾（2026-11-04，方案见 `docs/ACCOUNT_AUTHORITY_AND_RISK_REFRESH_PLAN.md` 1.3 续 / 1.4 续）
- 审计（08:5x，代码静态核对，提交 30429ba）：`ACCOUNT_AUTHORITY` 代码中无任何读取，1.2 四条均未实施（本机导入可写；买入门控无非权威分支，本机被拒只因合规硬阻断）；本机 `alert_config` 开启 serverchan + email，本机服务运行时会用本机数据对外推送；`account_exposure._snapshot_time` 用 `fromisoformat("15:10")` 解析估值时点必然失败 → 回落导入时间（门控过时检查同用）；`.ac-authority-*` 样式只在 decision / audit 两页加载；融资热度缺省 1.85 / 95 / 2.0；审计页 `calculate_risk_metrics` 白算。
- 用户确认（09:09）：A 未设置按非权威，部署前只读核对服务器 `.env` 有 `ACCOUNT_AUTHORITY=server`，审计页显示环境；B 本机停推送 + 拒绝 `/analysis/*` 写入；C 估值时点未知按持仓过时，弹窗时点必填无默认值；D 见下。本轮实施完成前用户关闭本机服务，只用服务器隧道。
- **用户 11-04 确认：收益自 10-30 收盘起算**（有真实券商快照，不用推算值）。此前 11-03 22:4x 记录的"自 10-30 起"为当时数据缺口的回退显示，规则仍写 10-29；今天起规则本身改为 10-30 收盘，`docs/DECISION_RULES.md` 同步（代码起点常量随 2a 口径提交更新）。

### 1a · 本机关闭导入 / 清零 / 账户写入 + 门控 + 推送（行为提交）
- 新增 `services/account_authority.py`：`ACCOUNT_AUTHORITY=server` 为权威，`local` / 未设置 / 其他值均为非权威（每次调用读环境变量）；`require_authoritative()` 非权威 → 403 `{code: NON_AUTHORITATIVE, message}`；`status()` 含账户数据截至时间（持仓快照时点、对账单日期、成交台账最后一笔）；启动日志写明环境（`main.py` lifespan）。
- 拒绝（非权威，函数第一句）：`/portfolio/import`、`/portfolio/trades/import`、`/portfolio/trades/scan`、`/portfolio/reset`、`/portfolio/trade`、`/portfolio/drawdown/baseline`、`/portfolio/trailing-stops/run｜{code}/rebaseline｜sleeve｜anchor｜ack`、`/analysis/plans｜observations｜journal｜journal/{id}/links｜unlink`。导入类提示"本环境非权威（本机开发），请在服务器导入（localhost:18000）"。`/portfolio/sync`（只拉行情）保留。
- 买入门控 `buy_gate` 第一步：非权威 → `allowed=false`、`reason_code=NON_AUTHORITATIVE`、`status=non_authoritative`，不运行合规；服务器照旧由合规判定。
- 对外推送：`alert_monitor._push_all_channels` 与 serverchan / email / 企微三个通道函数在非权威环境直接返回（只写告警表）；跟踪止盈日终、C3 任务告警、市场事件推送都经此函数。
- 只读接口 `GET /api/v1/system/authority`；审计页 A 区系统状态新增"账户数据环境"读数（权威 / 非权威，未设置为警告，不计分）。
- 测试：`tests/conftest.py` 默认 `ACCOUNT_AUTHORITY=server`（测试代表服务器行为，无条件覆盖本机 `.env`；只是测试环境设定，未改真实数据写入守卫）；新增 `tests/test_account_authority.py`（25 项：环境判定 5 种取值、16 个写入接口在 local / 未设置 / 大小写 / 无效值下均 403、导入提示文案、服务器放行（清零仍由原开关拒绝）、AST 源码契约（16 个路由第一句为守卫）、`/portfolio/sync` 不拦、门控非权威先拒且不跑合规、服务器门控照旧、非权威不发 serverchan / email / 企微、服务器照常推送、`/system/authority` 与审计读数）；对改前代码失败（19 项）、对新代码通过。云端沙盒全量 pytest：2066 passed / 24 failed，失败集合与改动前相同（沙盒缺 pyarrow / 部分文件、FastAPI 用仓库外最小替身，24 项改前即失败）；前端 27 个 `.cjs` 全部通过。本机两种环境全量 pytest 由一键推送执行。
- 5 项核对：执行目标、合规结论、跟踪止盈的计算代码未改；买入门控只在非权威环境多一条拒绝（服务器不变）；当前仓位未改。部署前须确认服务器 `.env` 有 `ACCOUNT_AUTHORITY=server`，否则服务器导入会被拒绝。
- 本机推送 11-04 09:29（push-20261104-092928，提交 6cc6d49）：本机快照测试 pytest 2092 passed / 1 skipped，前端 27/27，production_check 通过。
- 服务器部署前只读核对（09:32）：`.env` 与容器均**无** `ACCOUNT_AUTHORITY` → 暂停部署；用户追加 `ACCOUNT_AUTHORITY=server`（`.env` 第 10 行，恰好一行）后 `bash update.sh` 部署。部署后：容器 `printenv ACCOUNT_AUTHORITY` = server；`/system/authority` 返回 authoritative=true、"权威"（账户截至 `holdings_as_of` 2026-11-04T18:23，`valuation_time_known=false` —— 该时间为导入时间，2a 处理）；隧道核对（09:4x）审计页 A 区"账户数据环境"= 权威 · ACCOUNT_AUTHORITY=server。执行目标 25%、合规阻断 2 条（主题集中度、仓位超限检查）、跟踪止盈 RED 1 / GREEN 13、加仓权限关闭（hub permissions.increase=false；今日 MR 信号 35 只均为卖出方向，未能用 MR 预览直接走买入门控）、当前仓位 100%（持仓截至 11-04 18:23 对账单 · 价格 11-04 收盘），与部署前一致。

### 1b · 本机界面：导入 / 清零 / 账户写入按钮禁用并写明"请在服务器导入"（界面提交）
- `static/js/alphacore_utils.js`：`AC.authority()`（读 `/api/v1/system/authority`，页面内缓存；读取失败 = 状态未知，按非权威处理，不默认为权威）、`AC.accountWriteBlockedText()`、`AC.lockAccountWrites(root)`（禁用 `[data-ac-account-write]` 并写 title）、`AC.errorText()`（detail 为字符串 / `{code, message}` / Pydantic 数组）。
- 修正 `AC.secureFetch`：原先任何 403 都清除本地令牌并弹"安全拦截"，非权威 403 与清零停用 403 会误清令牌；现只在 401 或认证中间件的 403（body.status = forbidden / unauthorized）时清除，接口自身的业务拒绝原样返回给调用方按 detail 显示。认证失败行为不变。
- 组合页：导入、清零、交易按钮标 `data-ac-account-write`，非权威 / 状态未知时禁用，按钮旁显示"请在服务器导入"（悬停为完整说明）；"同步数据"（只拉行情）不禁用；导入 / 清零失败提示读 detail。
- 决策中枢跟踪止盈面板：导入成交、扫描文件夹、同步并重算、重设 / 撤销回撤基准、重新承保、建仓日、核心 / 卫星、已执行确认（9 个操作）禁用并在工具栏显示"请在服务器导入"；点击守卫与失败提示读 detail（403 无 message 字段）。
- MR 分析（strategy.html）：加入观察 / 本次不采用 / 确认记录计划禁用并写明原因；计划预览照常（门控返回 NON_AUTHORITATIVE，不可确认）。决定记录（组合页）：记录按钮禁用，关联 / 取消关联点击时提示。
- 服务器（权威）不变：`AC.authority()` 返回 authoritative=true 时不禁用任何按钮。
- 版本号：`alphacore_utils.js` v2→3（strategy / treasury v204→205）、`portfolio_manager.js` 48、`portfolio.css` 38、`decision_review_panel.js` 2、`personal_analysis.js` 7、`trailing_stop_panel.js` 14、`trailing_stop.css` 11。`tests/test_mr_preview_compliance_frontend.cjs` 版本断言由"等于 6"改为"不低于 6"。
- 测试：新增 `tests/test_authority_frontend.cjs`（错误文字 5 种、权威状态成功 / 3 种失败为未知 / 缓存与强制刷新、文案与按钮禁用、secureFetch 业务 403 保留令牌而 401 / 403 forbidden 清除、组合页 / 跟踪止盈 9 个操作 / MR 分析 / 决定记录接线、页面脚本版本）；对 1a 代码失败、对新代码通过。前端 28 个 `.cjs` 全部通过；云端沙盒全量 pytest 2066 passed / 24 failed，失败集合与改动前相同。
- 5 项核对：只改前端按钮状态与提示文字，执行目标、合规、跟踪止盈、买入门控、当前仓位的计算与接口均未改。本机界面效果需在本机服务运行时查看（本轮本机服务关闭，按测试与源码核对）；服务器页面按钮应照常可用。
- 本机推送 11-04 09:42（push-20261104-094258，提交 c1606be）：pytest 2092 passed / 1 skipped，前端 28/28。用户部署到服务器后测试导入文件正常（权威环境按钮可用）。

### 2a · 估值时点口径：对账单日期 + 导入时填写的时点，未知按持仓过时；收益起算日 10-30（口径提交）
- `services/account_exposure.py`：新增 `snapshot_meta(store)` 与 `parse_valuation_time()`。持仓时点 = 对账单日期（`import_date`，日期来源为 unknown 时视为未知）+ `valuation_time`（HH:MM / HHMM / HH:MM:SS，兼容完整时间戳）。**不再回落到导入时间 `imported_at`**（原 `_snapshot_time` 用 `fromisoformat("15:10")` 解析必然失败，实际一直用导入时间）。
  - `from_valuation` 增加 `holdings_date`、`valuation_time_known`；时点未知时 `holdings_as_of=None`，标注"持仓截至 MM-DD 对账单（估值时点未知）"。仓位数字不变。
  - 买入门控 `staleness`：估值时点未知 → stale（`time_unknown=True`，原因"对账单（MM-DD）估值时点未知，持仓按过时处理；请重新导入并填写估值时点（收盘后导出填 15:00，盘中导出填实际时间）"）。只会比改前更严（改前用的导入时间是最晚可能时点）；只有买入门控调用 `staleness`。
- `services/trailing_stop_service._holdings_as_of`：时点未知时只给对账单日期；`services/risk_state.state_label` 对应标注"（持仓截至 MM-DD 对账单 · 估值时点未知）"。`services/account_authority` 账户截至时间同口径。
- `/portfolio/import`：`valuation_time` 校验并规范为 HH:MM（"1510" → "15:10"，" 9:05 " → "09:05"）；格式不对返回 `ERR_VALUATION_TIME`，不导入；留空 = 未知（接口保持可选，弹窗在 2b 设为必填）。
- 现金台账 `record_balance_snapshot`：同日同金额的快照原无时点、本次带时点 → 只补写 `valuation_time` / `valuation_timing`，记 `valuation_time_filled_at`，金额不变、不重复记；已有时点不覆盖。
- 估值接口 `get_valuation` 增加 `statement_date`、`valuation_time`；组合页 `positionAsOfLabel`（标注兜底）改读这两项，不再读 `imported_at`。
- 收益起算日：`static/js/portfolio_kpis.js` `RULE_START` 2026-10-29 → **2026-10-30**（用户 11-04 确认）；10-30 起算不再标"缺失"，起点晚于 10-30 时仍写明。版本 `portfolio_kpis.js` v2、`portfolio_manager.js` v49。
- 测试（原测试按旧规则写的夹具随规则更新，先说明）：`tests/test_account_exposure.py` 夹具 STORE 补 `valuation_time: "17:48"`（原由导入时间推得；数字与断言不变），新增 3 项（导入时间不冒充 / 时点拼接与非法值 / 时点未知门控 HOLDINGS_STALE）；`tests/test_portfolio_kpis.cjs` 起算日断言改 10-30 并加"起点晚于规则日"用例；`tests/test_position_asof.cjs` 组合页标注改用对账单日期 + 估值时点并加"导入时间不冒充"用例。新增 `tests/test_valuation_time.py`（15 项：时点规范化 4 种、留空 3 种、非法 4 种不导入、台账补写且不覆盖、风险状态标注、跟踪止盈不用导入时间、估值接口字段）。新增 / 改动测试对 1b 代码失败（16 项 + 2 个前端）、对新代码通过。云端沙盒全量 pytest 2084 passed / 24 failed，失败集合与改动前相同；前端 28 个 `.cjs` 全部通过。
- 5 项核对：执行目标、合规结论、跟踪止盈判定、当前仓位数字的计算未改（只改时间标注）；买入门控在估值时点未知时多一条"持仓过时"拒绝（更严）。**部署后服务器现有 11-04 对账单（18:23 导入、无时点）会显示"估值时点未知"、门控按过时处理**——门控目前本就因合规硬阻断拒绝，结论不变；2b 上线后用户重新导入 11-04 对账单并填 15:00 即恢复。
- 本机推送 11-04 09:55（push-20261104-095537，提交 884e297）：pytest 2110 passed / 1 skipped，前端 28/28。按约定 2a 与 2b 一起部署。

### 2b · 组合页导入弹窗：估值时点必填（界面提交）
- `portfolio.html` 导入弹窗在确认按钮前新增"估值时点 必填"（`<input type="time" required>`，**无默认值**），提示"收盘后导出填 15:00，盘中导出填实际时间"；同时显示对账单日期（取自文件名 YYYYMMDD；文件名无日期时提示"将不记录历史快照，持仓时点未知"）。
- `portfolio_manager.js`：打开弹窗清空时点；未填或格式不对（HH:MM）时"确认导入"禁用，点击提示补填；导入请求带 `valuation_time`（后端 2a 已校验并规范）。版本 `portfolio_manager.js` v50、`portfolio.css` v39。
- 测试：新增 `tests/test_import_valuation_time.cjs`（必填、无默认值、提示文案、位于确认按钮前、打开时清空、未填不能确认、请求带 valuation_time、时点格式 4 合法 / 6 非法、版本号）；对 2a 代码失败、对新代码通过。前端 29 个 `.cjs` 全部通过；云端沙盒全量 pytest 2084 passed / 24 failed，失败集合与改动前相同。
- 5 项核对：只改导入弹窗，执行目标、合规、跟踪止盈、买入门控、当前仓位计算未改。部署后用户重新导入 11-04 对账单并填 15:00，持仓时点恢复为"11-04 15:00"，门控不再因估值时点未知判为过时。
- 本机推送 11-04 10:02（push-20261104-100226）。
- 2b 补（用户 10:11 要求，界面）：估值时点输入框旁加 3 个常用时点快捷按钮"15:00 收盘后 / 11:30 午休 / 09:00 开盘前"，**只在点击时填入**，仍无默认值；选中高亮，重新打开弹窗清除。版本 `portfolio_manager.js` v51、`portfolio.css` v40；`tests/test_import_valuation_time.cjs` 增加快捷按钮断言。前端 29 个 `.cjs` 全部通过（只改前端，后端未动）。
- 2a / 2b 部署核对（11-04 10:1x，隧道）：用户重新导入 11-04 对账单并选 15:00 后，组合页"持仓截至 11-04 15:00 对账单 · 价格 11-04 收盘"、`valuation_time_known=true`；跟踪止盈风险状态"持仓截至 11-04 15:00 对账单"；执行目标 25%、合规阻断 2 条、跟踪止盈 RED 1 / GREEN 13、加仓权限关闭、当前仓位 100% 不变。账户收益为"数据不足"：区间 10-30 → 11-04，服务器交割单只覆盖到 11-02（缺 11-03、11-04 含发生金额的交割单）——数据缺口，非本次改动（11-04 对账单 18:23 导入时区间已延到 11-04）；用户导出 11-03～11-04 交割单在服务器导入后恢复。

### 3 · 非权威标注：本机全站横幅 + 执行目标 / 合规 / 跟踪止盈 / 回撤刹车旁标注（界面提交）
- 新增 `static/js/authority_banner.js`：读 `/api/v1/system/authority`（优先用 `AC.authority()`）。只有 authoritative=true（服务器）时什么都不显示；本机或读取失败（状态未知，不默认为权威）时在 `<main>` 顶部插入 `.ac-authority-banner`："非权威数据（本机开发） · 账户截至 MM-DD HH:MM 对账单（估值时点未知时只写日期） · 成交记录至 MM-DD · 执行建议以服务器为准（localhost:18000）"；状态未知时"权威状态未知 · 无法确认本页是否为服务器权威数据 · 执行建议以服务器为准"。
- `.ac-authority-tag`"非权威"（未知时"状态未知"，悬停写明账户截至时间与"以服务器为准"）：静态位置用 `data-ac-authority-tag` 标记——首页 执行目标 / 执行目标从哪来（含回撤刹车）/ 主题集中度 · 合规；决策中枢 今日结论 3 项（执行目标、合规、止损已触发）/ 执行 · AIAE 执行目标 / 预交易合规审查 / 持仓跟踪止盈；组合页 合规徽章 / 当前回撤（回撤刹车）；审计页 B 组合合规。动态渲染位置（跟踪止盈面板"组合回撤 · 分档刹车"、决策中枢"执行目标从哪来 / 降仓路径"）由脚本在面板重绘后补上（MutationObserver，200ms 合并），不重复添加。
- 新增 `static/css/authority.css`（两个类，颜色用阻断色 `var(--status-block, #d6409f)` 带回退，不定义变量；`ac_tokens.css` 原预留类保留），17 个页面加载样式与脚本（决策中枢放在 `decision_action.css` 之前，保持其为最后一个样式表）。首页"执行目标从哪来"标题补"含回撤刹车"字样。
- 本地静态渲染检查（Playwright，模拟 `/system/authority` 返回 local，其余接口 503）：决策中枢 7 处、组合页 3 处、首页 4 处标注，横幅正常；组合页导入 / 清零 / 交易按钮为禁用（1b）。
- 测试：新增 `tests/test_authority_banner.cjs`（服务器不显示、本机横幅文案与账户截至 / 估值时点未知 / 无快照、状态未知也标注、标注与横幅不重复、17 个页面加载、11 处标注位置、动态选择器、样式不定义变量）；对 2b 代码失败、对新代码通过。前端 30 个 `.cjs` 全部通过（只改前端与页面）。
- 5 项核对：只读 `/system/authority` 并加文字标注，执行目标、合规、跟踪止盈、买入门控、当前仓位均未改。
- 本机推送并部署 3（11-04 10:2x）。隧道核对：服务器 `authoritative=true`，决策中枢无横幅、0 处"非权威"标注，`authority_banner.js` 已加载。

### 顺手项 · AIAE 融资热度缺省值改为"不可用"并标注降级（行为提交；方案见 `docs/DECISION_HUB_VISUAL_1B_1C_PLAN.md` 第 10 节【高】）
- `engines/aiae_engine.compute_margin_heat`：缺融资余额、缺总市值、总市值 ≤0 / 非数字、融资余额或总市值为抓取失败的回退数据（`is_fallback`）→ `value=None`、`status=unavailable`、`degraded_reason`（如"融资余额为回退数据"），WARN 日志；不再用 1.85 / 95 / 2.0 计算。真实数据下数值不变。
- `compute_aiae_v1` / `compute_aiae_v1_decomposed`：融资热度不可用 → AIAE_V1 融合值 None、分解中融资因子 raw / normalized / contribution 为 None 且 `status=unavailable`、`degraded`"融资热度不可用（降级），AIAE_V1 融合值不可用"；其余两因子照常。`generate_signals` 不出融资信号；高频估算与因子趋势快照在融合值缺失时跳过。`margin_heat_meta` 增加 `status` / `degraded_reason`。
- 分档：V5/V6（现行，AIAE简 分档）不受影响；V3 模式下分档依据缺失 → `classify_regime` 抛 `ValueError`（fail-closed，走已有"AIAE 档位缺失"处理）。
- `services/overseas_aiae_background.build_global_payload`：A 股融合值为 None 时不参与温度比较（`cn_temp=None`），不再因 None 报错。
- 下游已按 None 处理（1c 提交 B：首页 / 决策中枢 / 合规 / 日报读到 None 显示"--"或跳过）。策略页融资热度卡片的"不可用（降级）"显示在随后的界面提交。
- 测试：新增 `tests/test_aiae_margin_heat_unavailable.py`（12 项：真实值不变、7 种缺失 / 回退 / 无效情形不可用且不出缺省数字、融合值与分解、无融资信号、V5/V6 分档不受影响而 V3 fail-closed、海外背景容忍 None）；对改前代码 12 项全失败、对新代码通过。`tests/test_aiae_engine.py::test_zero_market_cap` 原断言缺省值 2.0，按新规则改为"不可用"（先说明）。云端沙盒全量 pytest 2096 passed / 24 failed，失败集合与改动前相同。
- 5 项核对：执行目标（V6 按 AIAE简 分档）、合规、跟踪止盈、买入门控、当前仓位未改；当前服务器融资数据为真实值（11-03 核实），读数不变。
- 本机推送并部署融资热度行为提交（11-04 10:3x）。

### 顺手项 · 策略页融资热度"不可用（降级）"显示（界面提交）
- `static/js/strategy_aiae.js` 融资热度卡片：`margin_heat` 为 None 或 `margin_heat_meta.status=unavailable` 时显示"--（降级）"、标签"降级"、说明"不可用（降级）：<原因> · 不用缺省值"，不画刻度条；原先 `Number(c.margin_heat || 0)` 会把缺失显示成 0.00%"杠杆出清"。
- 因子瀑布图：融资降级时只画 AIAE简 / 基金仓位两个因子，不画融合值总柱（原先缺融合值时用累计值顶替），图下写"融资热度不可用（降级）：AIAE V1 融合值与融资因子不显示"。版本 `strategy_aiae.js` v215。
- 测试：新增 `tests/test_aiae_margin_degraded_frontend.cjs`（降级显示与原因、不画刻度条、正常值照常、源码无 `|| 0` 顶替、瀑布图因子与无总柱、页面版本）；对改前代码失败、对新代码通过。前端 31 个 `.cjs` 全部通过。
- 5 项核对：只改策略页显示，执行目标、合规、跟踪止盈、买入门控、当前仓位未改。
- 本机推送并部署融资热度界面提交（11-04 10:4x）。

### 顺手项 · 审计页删除白算的 `calculate_risk_metrics`（行为提交；登记见 `docs/PORTFOLIO_SLIMMING_PLAN.md` 第 9 节）
- `engines/audit_engine._get_live_portfolio`：删除 `engine.calculate_risk_metrics()` 调用（唯一调用方 `_compliance_checks` 以 `pos_list, _, total_asset, _, _, _` 丢弃该返回值；该函数拉 120 日行情计算行业敞口等，属白算）。返回签名不变，第 5 项固定为 None；降级路径（引擎不可用读 JSON）原本即为 None。`/portfolio/risk` 接口仍可单独调用（组合页已隐藏）。
- 测试：新增 `tests/test_audit_no_wasted_risk_metrics.py`（2 项：不再调用且返回值不变、源码中唯一调用方丢弃该位）；对改前代码失败、对新代码通过。云端沙盒全量 pytest 2098 passed / 24 failed，失败集合与改动前相同。
- 5 项核对：审计页 A / B 读数来源不变；执行目标、合规、跟踪止盈、买入门控、当前仓位未改。`docs/PORTFOLIO_SLIMMING_PLAN.md` 第 9 节该条随本提交划掉。
- 用户 11-04 10:48 确认已部署。

### 4 · 读取鉴权（行为提交，本轮最后一个；方案见 1.4 续 ⑤；上线观察 1–2 天后视为完成）
- `services/auth_middleware.py`：`/api/` 下 GET / HEAD 也校验 `X-API-Key`（与写入同一令牌、同一比较）；OPTIONS 预检、`/health`、`/docs`、`/redoc`、`/openapi.json`、页面、静态文件、`/sw.js`、`/manifest.json`、`/version` 不在 `/api/` 下或在公开清单，不校验。读取鉴权开启时，原 7 个免令牌 POST 前缀也要令牌。生产模式未配置令牌 → `/api/` 读取同样 503；开发模式未配置 → 放行（读取只警告一次）。新增 `read_auth_enabled()`（环境变量 `ALPHACORE_READ_AUTH`，每次请求读取；`0/false/off/no` 关闭，其余或未设置为开启）、`read_auth_status()`；`main.py` 启动日志写明读取鉴权状态。写入鉴权不受开关影响。
- `static/js/alphacore_utils.js`（v4 / 策略页与国债页 v206）：包装 `window.fetch`——同源 `/api/` 请求自动带 `localStorage` 令牌（已带的不覆盖，跨域 / 不同端口不带，页面与静态文件不带）；读取遇认证失败（401，或 403 且 `status=forbidden/unauthorized`）每页只弹一次输入框，403 先清除旧令牌，输入后刷新，取消则页面底部显示"需要访问令牌"提示条（带"输入令牌"按钮）；业务 403（如非权威）不处理；写入失败仍由 `secureFetch` 处理。`secureFetch` 读取遇认证失败改为原样返回，交给包装统一弹窗（避免一页多次弹窗）。`report.html` 补加载 `alphacore_utils.js`（17 个页面均在页面脚本之前加载）。
- 内部调用核对：定时任务、看门狗、预热直接调函数不经 HTTP；`Dockerfile` 健康检查 / `update.sh` / `backup.sh` 只访问 `/health`；`deploy.sh` 用 `POST /system/auth_check` 带令牌，不受影响。手工脚本 `_test_api.py`（不带令牌 GET `/decision/hub`）开启后会 401，仅本机调试用，未改。
- 测试：新增 `tests/test_read_auth.py`（23 项：`/api/` 读取无令牌 401 / 错令牌 403 / 正确 200、HEAD 同样校验、`/health` `/version` 页面与静态免令牌、OPTIONS 不拦、写入照旧、原免令牌 POST 开启时需令牌、开关关闭 / 恢复即时生效且写入不受影响、缺省开启、生产无令牌 503 / 开发放行、状态文字）、`tests/test_read_auth_frontend.cjs`（自动带令牌、跨域与静态不带、已带不覆盖、Headers 对象、并发失败只弹一次并刷新、403 清令牌、取消显示提示条、业务 403 不处理、POST 不由包装弹窗、secureFetch 读写分工、17 个页面版本与加载顺序）。改动的测试：`test_analysis_api.py` 原"读取无需鉴权"改为"开启时需令牌 / 带令牌 200 / 开关 0 时免令牌"（行为本身变了，不是放宽）；`test_api_smoke.py`（integration，默认排除）的 TestClient 带本机 `.env` 令牌（未配置时不带）；`test_authority_frontend.cjs` 版本号 v3→v4。`conftest.py` 未改。云端沙盒全量 pytest 2121 passed / 24 failed，失败与基线完全相同（无新增）；前端 32 个文件全部通过。
- 5 项核对：只改认证与前端请求头，执行目标、合规、跟踪止盈、买入门控、当前仓位的计算未改；上线前后各核对一次。
- 本机推送并部署（`bash update.sh`，11-04 11:0x 美中 / 01:03 服务器）。服务器核对：无令牌 `GET /api/v1/system/authority` → 401，`/health` → 200，启动日志"读取鉴权: 开启, /api/ 读取需 X-API-Key (/health 与页面除外)"。待办：浏览器 18000 输入一次令牌后各页正常与 5 项核对；次日看审计页 A 区定时任务运行记录；观察 1–2 天后视为完成。
- 修补（11-04 11:2x，界面提交）：Claude 内置浏览器不支持 `prompt()`（调用即抛错"prompt() is not supported."），读取 401 后既不弹框也无提示条，页面空白。改为：`AC._promptKey` 捕获异常；弹窗不可用、取消或留空时，页面底部提示条自带密码输入框（回车 / "保存并刷新"），不再依赖弹窗；`secureFetch` 写入无令牌且不支持弹窗时显示同一输入条并取消该次操作。`alphacore_utils.js` v5 / 策略页与国债页 v207。测试：`test_read_auth_frontend.cjs` 增加"prompt 抛错 → 输入条、空值不保存、回车保存并刷新、写入取消不发请求"；本地 Playwright 模拟 prompt 抛错：输入条出现，填令牌回车后刷新、请求带令牌、提示条消失。前端 32 个文件全部通过。只改前端令牌输入方式，5 项未改。

## 组合页视觉轮（2026-11-04，方案见 `docs/PORTFOLIO_SLIMMING_PLAN.md` 第 10 节）

- 审计与改前基线（服务器经隧道，只读，12:3x CST）：执行目标 25%；合规 blocked（硬阻断：主题集中度、仓位超限检查；警告：组合波动预算）；跟踪止盈 RED 1 / GREEN 13；买入门控不允许加仓；当前仓位 100.0%；账户收益 +10.26% / 回撤 −26.2%（第 3 档）/ 波动 46.3%；14 只、总市值 ¥1,438,741.59。页面高度（`#dashboard-main`）桌面 3,451px、手机 6,253px，手机持仓表横向滚动（770 / 301px）。
- B 核实：`drawdown_brake`、`stop_breach_no_add` 均 passed，detail"减仓操作, 不受限制"——页面级检查按减仓方向评估，设计如此，非缺数据放行（未登记【高】待办）。
- 12:36 用户确认（方案 10.2）。提交顺序 V1 → A → V2 → V3。

### V1 · 基础（样式与文案）
- `portfolio.html` 最先加载 `ac_tokens.css?v=2`；`portfolio.css` 分"可见模块 / 隐藏模块"两节：可见一节只用 `var()`（无字面色值、渐变、毛玻璃、阴影、循环 / 入场动画、hover 位移），面板实底 + 1px 线 + 6px 圆角（保留 `glass-panel` 类名，`.pf-content .glass-panel` 覆盖）；隐藏一节为 8 个关闭模块原样式，Trade / 清零弹窗共用类限定到 `#trade-modal` / `#reset-modal`，两弹窗外观不变。
- 去 emoji（标题、按钮、导入弹窗、Toast、JS 文本；接口文案 `stripEmoji` 过滤，Toast 改纯文本写入）；去英文与中英混排（Portfolio Management、TOTAL NET ASSET VALUE、CASH、MKT VALUE、Position Monitoring、Import、CANCEL、TXT → SYSTEM、Empty Portfolio）；页面标题"投资组合"；删写死的"● LIVE"；穿透区 / 决定记录区内联 `<style>` 移入 portfolio.css。
- 涨跌语义类 `.ac-up / .ac-down / .ac-flat`（`--mkt-up / --mkt-down`）：持仓表盈亏（原 `pnl>=0 → pf-up` 为绿色，方向反了且 0 算涨）、导入预览现价、决定复盘实际收益（原 `dr-pos` 绿 / `dr-neg` 红，反了）；"若执行"假设对照不着色。占比条去 `weightColor`（>15% 红、>10% 黄）改中性。
- 穿透 KPI 由 `slip-kpi-*`（滑点模块类名）改 `lt-kpi-*`；决定记录按钮由 `slip-refresh-btn` 改 `pf-btn pf-btn-sm`（无测试引用）。
- 版本号：portfolio.css 40→41，portfolio_manager.js 51→52，lookthrough_panel.js 2→3，decision_review_panel.js 2→3。`test_import_valuation_time.cjs` 断言 `portfolio_manager.js?v=52`（原因：本提交改动该文件）。
- 测试：新增 `tests/test_portfolio_visual.cjs`（ac_tokens 先加载、portfolio.css 不定义变量、可见一节无字面色值 / 渐变 / 毛玻璃 / 阴影 / 动画 / 位移、隐藏一节只含隐藏模块选择器、可见区域无 emoji 与英文、可见渲染函数无内联颜色、涨跌类方向、假设对照不着色、隐藏模块选择器与 `.pm-off`、权威收尾轮标记、估值时点必填无默认值）；前端 34 个 `.cjs` 全部通过。
- 5 项核对：只改样式与文案，执行目标、合规、跟踪止盈、买入门控、当前仓位与 KPI 数字未改。

### A · valuation 价格保留 3 位小数（行为提交，排在 V2 之前）
- `PortfolioEngine.get_valuation` 的 `price` 由 `safe_round(·, 2)` 改为 3 位：ETF 报价到 0.001（服务器 11-04：159995 0.836、159516 0.481、159218 1.168、510300 4.175，原显示 0.84 / 0.48 / 1.17 / 4.17）；个股原价 2 位不变。
- 下游（全仓库扫描 15 个 `get_valuation()` 调用方 + 前端）：市值、权重、盈亏、总资产、当前仓位、合规、波动预算、回撤刹车、跟踪止盈、决策中枢、审计页等均用未取整价格或不读 `price`，**不变**。唯一读 `price` 的计算是 `get_intraday_pnl`（portfolio_engine.py:555）→ `/portfolio/intraday-pnl` 与 AI 助手日内摘要（AI 已暂停，`intraday_pnl.js` 无页面加载）：按 11-04 持仓，日内盈亏合计变化 −946.40 元（159995 −984.80、510300 −87.50、159218 −24.60、159516 +150.50；个股与 588000 为 0）。该接口 `current_price` 输出仍按 2 位取整（未改）。
- 测试：新增 `tests/test_valuation_price_precision.py`（ETF 3 位、个股不变、市值 / 权重 / 总资产与未取整价格一致）；对改前代码 1 项失败、改后通过。云端沙盒（PyPI 不可用，tushare 用仓库外桩）引擎相关 pytest 42 项通过；全量 pytest 由用户本机执行。
- 5 项核对：执行目标、合规、跟踪止盈、买入门控、当前仓位不读 `price`，不变。

### V2 · 第一屏（顶栏、核心资产区、持仓表）
- 顶栏：合规徽章阻断实底洋红 / 警告 warn 描边 / 通过 pass 描边 / 加载中与不可用 info；不可用时徽章内直接写"不代表通过"（`#pf-compliance-note`）；"读取于 HH:MM"与跳转保留。导入为唯一实色按钮、同步为描边按钮；本机禁用态改中性虚线并追加"不可用"，不用阻断色（"请在服务器导入"提示沿用权威收尾轮）。
- 核心资产区：总资产中性唯一大数字；副行"N 只持仓 · 当前仓位 x% · 现金 y%"；`.ac-asof` 持仓截至行；新增"执行目标 x% · 来自决策中枢"（读首页执行区同一接口 `/api/v1/decision/hub` 的 `action_plan.execution_target`，带 `data-ac-authority-tag`，不可用 "--"，不算差额）。五个 KPI 同一组件，顺序 市值 / 现金 / 账户收益 / 当前回撤 / 组合波动，每个都有来源与时间行（市值"价格 MM-DD 收盘"、现金"对账单 MM-DD · 可用资金"）。账户收益红涨绿跌；"数据不足"用 `.ac-state-partial` 写接口 note。回撤、波动数字中性；回撤刹车档位标签与决策中枢 `TIER_CLS` 同一映射（第 3 档阻断实底"回撤刹车第 3 档"，不显示 label 中的"降至 25%"）；波动只写"目标 30%"，状态标签读合规「组合波动预算」（当前"警告"）。
- 持仓表：新增 `static/js/portfolio_view.js`（纯展示）：市值降序；类型标签按代码前缀（规则见方案 10.5）；ETF 成本价 / 现价 3 位、个股 2 位；占比条中性 `--dc-data`、以最大持仓为满格（替换 `weight*5`）、weight 缺失 "--"；盈亏金额与百分比同色（单元格级）；成本价兜底 `.ac-tag-warn`、券商 / TS 为 info 小字；表头下图例；名称、行业经 `esc()` 转义（顺手项：原先直接拼接 HTML）。
- 版本号：portfolio.css 41→42，portfolio_manager.js 52→53，portfolio_kpis.js 3→4，portfolio_compliance.js 2→3，新增 portfolio_view.js?v=1。断言同步：`test_import_valuation_time.cjs`（manager v=53）、`test_export_coverage_frontend.cjs`（kpis v=4），原因：本提交改动这两个文件。
- 测试：`test_portfolio_visual.cjs` 增加类型标签规则表、价格精度、市值降序、盈亏方向与不整行着色、占比条比例尺与缺失、成本兜底标签、转义、KPI 顺序与来源行、回撤 / 波动无涨跌类、档位映射与决策中枢一致、波动标签读合规、执行目标接口与 "--"、无"仓位上限 / 降至"、徽章样式与"不代表通过"、唯一实色按钮、禁用态非阻断色。前端 35 个 `.cjs` 全部通过。
- 5 项核对：只改展示；执行目标、合规、跟踪止盈、买入门控、当前仓位、三个 KPI 数字、持仓只数与总市值未改。

### V3 · 下半页（穿透、决定记录、成交记录、导入弹窗、手机端）
- 穿透：合规判定行移到折叠区外，作为本区第一信息（状态标签读合规检查项：硬阻断 / 警告 / 通过 + 主题读数 + "唯一判定"），下一行行业拆分，口径不一致 warn；`basis_note` 未写行业未知时补"按 ETF 分列"小字。行业 / 公司暴露改中性水平条（降序，已知行业取前 8 + "其余 N 个行业"），"行业未知"不参与截断、始终末行（`--dc-data-dim` + "未知"标签，0% 也单列）。风险贡献改为仓位占比 / 风险占比两列并排中性条（同一比例尺，无颜色阈值）。压力情景标"条件估计 · 非预测"，数字中性。折叠标题 CSS chevron、整行可点。
- 决定记录：采用 / 未采用 / 暂不行动为中性文字标签；"不足以评价"为 info 标签；假设对照中性；表单控件同高（30px）、按钮 `pf-btn`；"显示金额"保留、默认隐藏。
- 成交记录：改表格（日期 / 方向 / 名称代码 / 数量 / 价格 / 金额 / 费用，数字右对齐千分位，ETF 价格 3 位）；买入 / 卖出为中性描边标签。
- 导入弹窗：对账单日期 `.ac-asof`；（V1 已去 emoji / TXT → SYSTEM / CANCEL、必填标签、确认按钮禁用虚线、快捷时点选中 `--dc-line-strong` 实底）。
- 手机 375：首屏总资产、当前仓位、合规徽章（徽章整行置顶）；KPI 两列、数字不换行；持仓表改卡片列表（名称 + 代码 + 类型 / 市值 + 占比 / 盈亏%，点开看行业、数量、成本价、现价、盈亏金额），不横向滚动；不到 2% 的持仓合并为"其余 N 只 · 合计 x%"默认收起（常量 `MOBILE_GROUP_BELOW_PCT = 2`，注明展示用、非风险阈值；成本价兜底与 weight 缺失不参与；桌面不合并）；穿透区手机默认折叠（合规行在折叠区外）。
- 高度：云端用同形状夹具渲染（非服务器数据）桌面 3,275 → 2,820px、手机 5,626 → 2,098px；服务器实测待部署后经隧道复核（改前 3,451 / 6,253px）。
- 版本号：portfolio.css 42→43，portfolio_view.js 1→2，portfolio_manager.js 53→54，portfolio_kpis.js 4→5，lookthrough_panel.js 3→4，decision_review_panel.js 3→4；`test_import_valuation_time.cjs`（v=54）、`test_export_coverage_frontend.cjs`（v=5）断言同步，原因同上。
- 测试：`test_portfolio_visual.cjs` 增加行业未知不截断且末行、无未知时也单列、穿透无颜色、合规行状态标签与位置、按 ETF 未知小字、风险贡献并排条、压力中性、chevron、决定记录中性 / info 标签、成交记录中性方向标签与价格精度、导入弹窗、手机两列 KPI / 卡片 / 合并规则 / 穿透默认折叠。前端 35 个 `.cjs` 全部通过。
- 5 项核对：只改展示；执行目标、合规、跟踪止盈、买入门控、当前仓位、三个 KPI 数字、持仓只数与总市值未改。

### V3b · 可见文字显示中文（17:3x 用户"显示中文"）
- 渲染后逐词扫描可见文字：持仓表 / 手机卡片价格来源标签 "TS" → "收盘价"（悬浮仍注明 Tushare），图例同步；穿透合规行 "INDUSTRY_THEME_MAP" → "与合规用同一张行业→主题映射表"。
- 保留：ETF、代码后缀 .SH / .SZ、AIAE（专有名词 / 证券代码）；合规接口原文中的 "pp"、导入提示 ".txt"、行业名 "IT设备"（接口数据，前端不改）。
- 版本号：portfolio_view.js 2→3、lookthrough_panel.js 4→5；`test_portfolio_visual.cjs` 增加"可见文字无 TS / INDUSTRY_THEME_MAP"断言；前端 35 个 `.cjs` 全部通过。

### 部署后复核（2026-11-04 18:05 CST，服务器经隧道，只读）
- 页面版本：`portfolio_view.js?v=3`、`lookthrough_panel.js?v=5`、`portfolio_manager.js?v=54`（V1、A、V2、V3、V3b 均已上线）。
- 基线核对与改前一致：执行目标 25%；合规 blocked，硬阻断"主题集中度、仓位超限检查"，警告"组合波动预算"；`drawdown_brake` / `stop_breach_no_add` 仍 passed（减仓方向）；跟踪止盈 RED 1 / GREEN 13；买入门控不允许加仓（increase = false）；当前仓位 100.0%；账户收益 +10.26% / 当前回撤 −26.2%（第 3 档）/ 组合波动 46.3%；14 只、总市值 ¥1,438,741.59、总资产 ¥1,438,760.18。
- A 生效：ETF 现价 159218 1.168、159516 0.481、159995 0.836、510300 4.175、588000 1.340；个股（如 688019 207.00）不变；市值、总资产未变。
- 页面高度（`#dashboard-main`）：桌面 1440 3,451 → 3,097px；手机 375 6,253 → 2,069px（约 −67%），无横向滚动（375 / 375），KPI 5 个数字均未换行或截断；手机持仓"其余 4 只 · 合计 5.4%"默认收起，穿透默认折叠、合规行可见。
- 截图：`D:\FIONA\google AI\Claude outputs\portfolio_visual_20261104\screenshots\`（改前服务器 4 张、改后本机 6 张、改后服务器 5 张，README 写明环境与高度）。
- 观察（未改，登记）：桌面"前 10 大公司暴露"表的行业列较窄，"半导体"等会折成两行；本机未带令牌时模块开关接口读不到，8 个关闭模块按 P4 规则全部显示（旧样式）。

### 复核两点的处理（2026-11-04 18:1x，用户授权按专业判断）
- 公司暴露表行业列折行：行业单元格加 `lt-ind` 并 `white-space: nowrap`；云端渲染核对 10 行行业名均为单行。lookthrough_panel.js 5→6，portfolio.css 43→44。
- 模块开关读不到时：由"全部视为开启"（P4）改为**保持隐藏**（fail-closed，只限本页 8 个可选模块）。理由：这 8 个模块因口径误导（历史模拟、Brinson、因子、行业饼图）、死入口（Trade、滑点）或破坏性（清零）而关闭，开关读不到（本机未带令牌、接口异常）时不应重新露出；读不到时持仓、穿透等主体内容不受影响。做法：11 个元素在 HTML 里默认带 `.pm-off`（脚本未运行也不露出），接口明确返回且 `enabled !== false` 才去掉；非 success 响应（如 401）按读取失败处理；`pmOn` 在开关脚本缺失时按关闭。后端 `services/portfolio_modules.py`"配置文件缺失 / 损坏 → 全部开启"未改（那是能读到的明确结果）；决策中枢开关规则未改。portfolio_modules.js 1→2，portfolio_manager.js 54→55。
- 测试：`test_portfolio_modules.cjs` 失败分支改为断言"保持隐藏"（原断言"全部开启"，因规则变更而改），并新增 401 响应、默认 `.pm-off`、明确开启时去掉、`pmOn` 缺失按关闭；`test_import_valuation_time.cjs` 断言 v=55；`test_portfolio_visual.cjs` 隐藏区标记同步。前端 35 个 `.cjs` 全部通过；云端渲染核对开关正常与 401 两种情况下 8 个模块均不显示、穿透区正常。

### 两项待办的处理与提交说明更正（2026-11-04 18:3x，用户授权按专业判断）
- **持仓表跟踪止盈状态列：做。** 理由：哪只持仓止损已触发是"账户现在是什么样"的事实，本页原先看不到；只读、读决策中枢同一接口 `/api/v1/portfolio/trailing-stops`（`positions[].status`），前端不判定，不写操作（不出现"卖出 / 次日开盘"等），点击跳 `decision.html#trailing-stop-panel`（唯一止损执行入口）。显示：RED"止损已触发"（阻断实底，真实禁止状态）、LEGACY"遗留越线"（legacy 描边）、YELLOW"临近止损线"（warn）、ACTION"到达止盈档"（info）、GREEN"正常"（灰字）、NO_DATA"无行情"；读取失败 "--"。手机卡片：非正常状态在摘要行可见，且不参与小仓位合并。portfolio_view.js 3→4、portfolio_manager.js 55→56、portfolio.css 44→45；`test_import_valuation_time.cjs` 断言 v=56；`test_portfolio_visual.cjs` 新增第 15 组断言。
- **隐藏模块内的绿涨红跌：本轮不改。** 理由：8 个模块对用户不可见，改了无可见收益；按 `config/portfolio_modules.json` 的 restore_if，恢复前本就要重写（真实区间权重、按成交台账等），届时一并按红涨绿跌与 `ac_tokens.css` 处理，避免改两次。保留在方案 10.6 待办。
- **提交说明更正（历史不改写）：** 视觉轮 7 次提交均以默认说明"update: daily update"提交——原因是我给的推送命令把说明写成了 PowerShell 注释，而 `一键推送.bat` 读的是环境变量 `ALPHACORE_COMMIT_MSG`，未设置时用默认值。已推送的 main 不强推改写（会影响服务器拉取与 CI），以此处对照为准：
  - `bb4609c` V1：ac_tokens 接入、去装饰、去 emoji、红涨绿跌、英文清理
  - `9f59718` A：valuation 价格保留 3 位小数（ETF 报价到 0.001）
  - `aa8a43c` V2：顶栏、核心资产区、持仓表
  - `5eee018` V3：穿透、决定记录、成交记录、导入弹窗、手机端
  - `401ef09` V3b：可见文字显示中文（价格来源标签、映射表说明）
  - `22cb388` 部署后复核记录（基线一致、实测高度、截图位置）
  - `d61f98f` 公司暴露行业名不折行；模块开关读不到时保持隐藏
  之后的推送命令改为先设 `$env:ALPHACORE_COMMIT_MSG`。

### 隐藏模块配色待办挂到恢复条件（2026-11-04 18:5x）
- `config/portfolio_modules.json` 8 个模块的 `restore_if` 末尾各加"恢复前须按组合页视觉轮规范改写样式（红涨绿跌、只用 ac_tokens.css 变量、去 emoji 与渐变，见方案 10.6）"，恢复模块时打开配置即可看到；开关值、隐藏日期、原因未改。
- `test_portfolio_modules.cjs` 增加断言：每个模块的恢复条件都含该要求。前端 35 个 `.cjs` 全部通过。

## 插入任务 · 暂停月度 CI 与 11-01 月度 CI 只读核实（2026-11-04 19:5x–20:1x）
- 起因：全站栏目审计发现月度 CI（`strategy_ci_monthly`，每月 1 日 02:00 北京时间 = 前一日 12:00 美中）结果为 ACCEPT / REVALIDATED 时会自动发布参数，违反"预注册参数不改"。用户 19:49 要求先暂停，并只读核实 11-01 那次运行；计划另存为 `docs/SITE_SLIMMING_ROUNDS.md`（拍板 Q1=A、Q2=A、Q3=B、Q4=A）。

### 配置提交 · 暂停 strategy_ci_monthly
- `config/job_switches.json` 新增 `strategy_ci_monthly`：enabled=false、paused_on 2026-11-04、reason（自动发布 MR 参数；ERP 自动调参已由 `ERP_CI_AUTO_OPTIMIZE` 停用）、restore_if（第 0 轮 0a 改为只评估不发布后恢复）。只改配置。
- 生效方式：`main.py` 启动时 `services/job_runs.wrap_scheduler` 给全部任务包上 `tracked`，每次运行前读取开关；非关键任务，审计页 A 区显示"已暂停"，不按逾期推送。同一任务里的 AIAE V5 月度自检也一并停止，第 0 轮拆分。
- 自检：JSON 可解析；暂停集合为 nlp_scan_am / nlp_scan_pm / strategy_ci_monthly，不含关键任务和日报，任务 id 都在 `JOB_LABELS` 内（即 `tests/test_job_switches.py::test_repo_config_valid_and_no_critical_job_paused` 的条件）。全量测试由一键推送执行。
- 部署后核对：`docker logs quant_dashboard_app 2>&1 | grep "定时任务已暂停"` 应出现 strategy_ci_monthly；5 项（执行目标、合规、跟踪止盈、买入门控、当前仓位）应不变。

### 11-01 月度 CI 只读核实（用户在服务器执行，20:04）
- 结论：**没有改任何策略参数，无需回滚。**
- `ci_runs`（data_lake/db/alphacore.db，UTC）自 10-25 起共 4 条，全部是 MR，全部未发布：
  - 10-31 18:00:11Z（= 11-01 02:00 北京，定时）BEAR REJECT；18:00:28Z RANGE INSUFFICIENT_EVIDENCE；18:00:44Z BULL INSUFFICIENT_EVIDENCE
  - 11-01 01:07:47Z（= 09:07 北京，非定时）只有 BEAR，REJECT。来源未查明（可能是回测页 CI 面板或 POST /api/v1/ci/run），列入第 0 轮
- 挑战者参数（被否 / 证据不足，均未采用）：
  - BEAR：N_trend 120→60、rsi_period 6→14、rsi_buy 20→50、rsi_sell 52→65、bias_buy −2.0→−3.0
  - RANGE：N_trend 120→90、rsi_buy 30→40、bias_buy −2.5→−2.0、stop_loss 0.10→0.07
  - BULL：N_trend 60→90、rsi_buy 35→40、stop_loss 0.06→0.08
- ERP 没有记录：`engines/erp_params.py` `ERP_CI_AUTO_OPTIMIZE = False`（10-24 起），`run_erp_ci` 直接返回 DISABLED、不落库。审计时写的"ERP 网格搜索自动发布"已不成立，目前只有 MR 能自动发布。
- 参数版本：仓库与运行中容器均为 revision 11（2026-10-25T17:20+08:00，`manual:static_caps_by_class`）。
- 推断（容器已多次重建，日志不在，无法直接证实）：两次 MR 运行按代码会经 `record_ci_outcome` 在容器内写 MR lifecycle（只改状态与时间戳，不改参数，revision 递增），随后分别被 02:33 和 09:14（北京）的部署重建覆盖回仓库版本。现行 lifecycle 仍是 10-14 的验证记录（BEAR rejected，RANGE / BULL insufficient_evidence），状态与 11-01 结论一致，只是时间戳旧；BEAR 的 next_validate_after（10-28）已过。
- 对第 0 轮的补充（已写入 `docs/SITE_SLIMMING_ROUNDS.md`）：lifecycle 不应写在会被部署覆盖的运行时配置里；手动触发要记录来源；出错 / 停用的运行也要落库。

### 补充 · 11-01 月度 CI 核实结论（供第 0 轮方案参考，2026-11-04 20:4x）
- 依据：服务器 `ci_runs` 只读查询（用户 20:04 执行）、仓库与运行中容器的 `strategy_runtime.json`、`/root/backups/update.log` 构建记录、本机代码与文件时间。本会话没有调用任何 `/ci/*` 接口。
- 时间均为北京时间（服务器与调度器时区）；美中 = 北京 − 14 小时。11-01 是周日，A 股休市。

**1. 参数改动（改前 / 改后）：无**
- 两次运行都没有发布：只有 ACCEPT / REVALIDATED 才会调用 `publish_ci_parameters`，这两次分别是 REJECT 和 INSUFFICIENT_EVIDENCE。
- MR 在用参数（revision 11，部署前后一致，仓库 = 容器）：
  - BEAR：N_trend 120、rsi_period 6、rsi_buy 20、rsi_sell 52、bias_buy −2.0
  - RANGE：120、14、30、65、−2.5
  - BULL：60、14、35、75、−1.5
  - 止损（strategies.mr.stop_losses）也未改
- 挑战者参数均未采用，见上一节。ERP 自动调参已停用，没有运行。

**2. 运行时配置的写入：只有 MR lifecycle（推断）**
推断依据：代码上，REJECT / INSUFFICIENT_EVIDENCE 会经 `record_ci_outcome` 写入；容器已重建、日志不在，无法直接证实。

| 运行 | 改前 | 改后（推断） | 生效区间 | 被哪次部署覆盖 |
|---|---|---|---|---|
| 定时 02:00:11–02:00:44 | BEAR rejected（10-14 验证，复验日 10-28 已过 → 有效状态 stale）；RANGE / BULL insufficient_evidence（复验日 11-13） | BEAR rejected，复验日约 11-15；RANGE / BULL insufficient_evidence，复验日约 12-01；验证时间改为当时 | 约 02:00 → 02:33，约 32 分钟 | 11-01 02:33:02 构建完成的部署（美中 10-31 12:33，MR 前复权改动） |
| 非定时 09:07:47 | 同上（02:33 部署已恢复为仓库版本） | BEAR rejected，复验日约 11-15 | 约 09:07 → 09:15，约 7 分钟 | 11-01 09:14:56 构建完成的部署 |

- 构建完成后才替换容器，实际覆盖时刻比上表晚几秒到几分钟。
- 覆盖之后，lifecycle 回到仓库里 10-14 的记录，一直到现在。

**3. 这期间谁读到了什么**
- 读到被改参数的：没有，参数没改。
- lifecycle 的读取方：
  - `engines/mean_reversion_engine`：`get_mr_lifecycle` → `parameter_lifecycle` 标签、`allow_new_entries`、`needs_reoptimize`
  - `/api/v1/params/strategy-config` 的 `mr.lifecycle`
  - 策略页 MR 的显示
- 实际影响：
  - 只有状态为 validated 时 `allow_new_entries` 才为 true。改前改后三态都不是 validated，MR 买入信号照旧降为 `no_entry`，所以 MR 信号和 MR 预览结果不变
  - 唯一差别是 BEAR 的显示状态：窗口内从"stale（复验过期）"变成"rejected"
- 买入门控：11-01 还没上线（11-02 加入）。现行 `services/compliance_gate.py` 也不读 MR 参数或 lifecycle。
- 窗口内的读取：工作日定时任务（周一至周五）不在窗口内。若有读取，只能来自当时打开的页面或会话调用；容器日志已随重建丢失，无法逐条列出。

**4. 两次运行的来源**
- 02:00 那次：定时任务 `strategy_ci_monthly`（每月 1 日 02:00，Asia/Shanghai），确定。
- 09:07 那次只跑了 BEAR。按本机代码，只有 `run_mr_ci` 会写 `ci_runs`，只跑单一状态必须显式传 `regime="BEAR"`。逐一排查：
  - 回测页"运行 CI"按钮：只发送 `{strategy}`、不带 regime，会跑满三态。只有 RANGE / BULL 优化器返回空、跳过且不落库时才会只剩 BEAR；02:00 同样的数据下两态都正常，可能性低。
  - 定时任务：不是。不在定时点，其他任务也不调用 `run_mr_ci`；`needs_reoptimize` 只是显示字段，不触发运行。
  - 最可能：会话或手动调用了 `POST /api/v1/ci/run {"strategy":"mr","regime":"BEAR"}`，或在容器里直接调用 `run_mr_ci("BEAR")`。旁证有三点：
    - 本机 `mr_validation.py`、`mean_reversion_engine.py`、`price_adjust.py` 修改于美中 10-31 12:27（= 北京 02:27，MR 前复权修复），随后 02:33 部署
    - BEAR 是当时唯一复验期已过的状态（复验日 10-28）
    - 运行后 7 分钟又有一次部署
  - 这些都符合"会话改完前复权后复验 BEAR"，但这项工作没有写进本日志，来源无法证实。
- 两次 BEAR 运行（前复权修复前、后）的挑战者参数和结论完全相同。

**5. 对第 0 轮方案的提示**
- 回测页"运行 CI"（`POST /ci/run`）遇到 ACCEPT 会直接自动发布，不需要再点"批准"。月度任务暂停只挡住定时入口，手动入口仍然开着。
- `ci_runs` 增加触发来源字段（定时 / 接口 / 脚本）与调用方；会话执行的验证必须写日志。
- lifecycle 移出会被部署覆盖的运行时配置（改存 data_lake 或数据库），否则复验结论每次部署都会丢。
- 出错、停用的运行也落库。

**约定（用户 20:35）**：第 0 轮完成前，会话不调用任何 `/ci/*` 接口；用户不点回测页"批准"。建议"运行 CI"按钮同样不点。

## 第 0 轮方案确认 · 月度 CI 只评估不发布（2026-11-04 21:1x–21:3x，方案见 `docs/ROUND0_CI_EVALUATE_ONLY_PLAN.md`）
- 方案会话（只出方案）：读代码和文档、静态阅读，未调用任何 `/ci/*` 接口，未改服务器状态。未取新基线（最近一次为 18:05 部署后复核），实施会话开头经隧道再取。
- 新发现：
  - 人工批准写的是容器内运行时配置，部署时会被覆盖，批准结果留不住
  - MR 发布会把 lifecycle 设为 validated，从而打开 MR 开仓
  - MR 从来不产出 REVIEW，批准入口对 MR 无效
  - 两种情况静默跳过不落库：MR 优化器返回空、ERP 停用
  - 11-04 读取鉴权的 fetch 包装让回测页"运行 CI"现在能真正触发并发布
  - 推断：11-01 时按钮不带令牌，应被 401 拒绝，09:07 那次基本可以排除回测页（待核实 11-01 的生产模式和前端版本）
  - 外链头像共 12 处
- 用户确认（21:28）：
  - D1 = A：批准只做记录并生成参数补丁，参数经仓库提交、推送部署后生效
  - D2：运行 CI 与批准按钮在 0b 一起隐藏
  - D3：做服务器写操作日志，不记令牌、不记导入文件内容（只记文件名 / 大小 / 行数 / 结果），按月轮换并设单文件上限
  - D4：接口触发 CI 须填 reason
- 约定扩大：0a 部署前，回测页"运行 CI""批准"按钮都不点；第 0 轮完成前，会话不调用任何 `/ci/*` 接口。
- 暂停月度 CI 的配置（`1cec27a`，20:11 推送）：用户 21:28 核对，服务器已生效。
- 文档改动（本机，未推送；随 0a-1 一起推送）：
  - `docs/SITE_SLIMMING_ROUNDS.md`：通用约束新增固定规则 8，补修订记录和进度行
  - 新增 `docs/ROUND0_CI_EVALUATE_ONLY_PLAN.md`
  - 本条日志
- 实施顺序：0a-1 → 0a-2 → 0a-3 → 0a-4 → 0a-5 → 0a-6 → 0b → 0c，在权威环境收尾轮完成后（11-05 起）开始。
- 21:32 用户授权按专业判断剩余细节，已写入方案第 7 节：
  - 会话与部署：分三个会话，每步单独提交和推送，每组结束部署一次
  - 暂停配置：0a-1 开工时在审计页 A 区再读一次确认
  - 批准接口不设环境开关：方案 A 下批准只记录，真正的闸门是仓库提交；开关要重建容器两次。保留令牌、手输 run_id、必填 note、写操作日志
  - 头像块整块去掉
  - 已核实：`compare_regime` 的 REJECT 表示现任参数也通不过门槛，自动写 rejected 语义正确；审计页 A 区为通用行渲染，0a-6 不需要改前端
  - 0a-1 时用一条只读 git 命令把 11-01 来源落成结论
  - 接受 0a-5 后 V5 自检于 11-30 12:30（美中）照常运行
- 22:08 用户规定（已写入方案 3.4、第 7 节 J10，以及通用约束固定规则 9）：
  - 批准后生成的参数补丁，会话不得自行提交
  - 须先列出参数改前 / 改后、run_id、验证结果，用户针对该 run_id 明确同意后才提交
  - 实施日志记录用户何时同意
  - 0a-3 的批准接口相应返回审阅摘要，供会话原样列出
- 22:10 用户授权按专业判断，定两点：
  - 保留通用约束固定规则 9（第 0 轮之后月度 CI 仍会产出待批准结果，而通用约束是每个会话都读的）
  - 保留"概括授权不算同意"的口径
  - 本次授权只针对这两处规则设计，不构成对任何未来参数补丁的同意
- 22:23 文档推送安排改为：三份文档（通用约束规则 8 / 9、本方案、本日志）可先作为一次纯文档提交单独推送，不需要部署；不必等 0a-1。实际推送时间由 0a-1 会话补记。

## 决策中枢视觉 2 · 行动区收尾（2026-11-04/05，方案见 `docs/DECISION_HUB_VISUAL_1B_1C_PLAN.md` 第 12 节）
- 审计（11-04 22:4x，只读）与确认：22:59 用户 Q1–Q4 均选 A；23:10 同意 `tests/test_export_coverage_frontend.cjs` 版本号断言同步，要求档位阶梯写明进入 / 退出条件。见方案 12.1–12.3。
- 与第 0 轮并行：只改方案 12.4 所列文件；不动 `decision.html` 的 user-profile 块与 `sidebar.js` 引用行。写回前核对（23:2x）：0b 未开工（`decision.html` 仍为外链头像、`sidebar.js?v=5`，本日志无 0a / 0b 实施条目）；第 0 轮文档提交 `9d1c9b5` 已于 11-04 22:29 推送（本机 main = origin/main），工作区干净；本轮各文件与审计时读取的版本一致。
- 基线（服务器经隧道只读，11-05 13:11 北京 = 11-04 23:11 美中）：执行目标 25%（最严约束：组合回撤刹车 25%；AIAE 矩阵 60%、市场尾部刹车后 60%、组合波动预算 64.8%）；合规 blocked，硬阻断"主题集中度、仓位超限检查"，警告"组合波动预算"；跟踪止盈 RED 1 / YELLOW 0 / GREEN 13 / LEGACY 0；加仓权限关闭（increase = false）；当前仓位 100.0%（持仓截至 11-04 15:00 对账单 · 价格 11-04 收盘）；回撤 −26.2%（高点 09-23，谷底 11-03 −33.1%）、3 档、cap 25、退出线 −16.5%；回撤刹车口径 invested_pct 100.0%（与 account_exposure 本次数值相同，口径差异仍在，见方案 12.2 第 3 项）。读取期间未触发日终补跑，未调用 `/ci/*`，未点"生成日报"（规则 8：无服务器写操作）。截图：`D:\FIONA\alphacore_baselines\20261105_decision_visual_2\`（服务器实拍 + 同一份服务器数据的云端改前 / 改后渲染，README 写明）。

### 提交 1 · 跟踪止盈回撤刹车说明性写法与进入 / 退出条件（界面提交）
- `static/js/decision/trailing_stop_panel.js`（v16）：
  - 结论条 / KPI / 约束格改为"k 档约束 → 执行目标上限 x%"，未触发写"回撤未触发 · 不约束执行目标"；数字仍为 `brake.cap_pct`（= 执行目标"∧ 组合回撤刹车"一档的约束值）。
  - 档位阶梯：每档"进入 ≥ x% · 执行目标上限 x%"，0 档"不约束"；上方说明行"回撤刹车档位 → 约束执行目标上限"；下方写进入 / 退出条件（`replay_tiers`：收盘回撤触及档位线即升档；自谷底收复 50% 的回撤才降一档，每次一档，降档后重新计谷底，不看持续天数），当前回撤低于进入线时写明仍在该档的原因。
  - 水下曲线档位标注只写"k 档"，悬停为说明性写法；标题标签"k 档 · 禁止加仓"（不再显示配置档位名中的"降至 x%"）；重设基准确认框写"k 档回撤刹车"。
  - Q1 = A：不显示回撤刹车口径的仓位数字（KPI"当前 y%"、约束格当前值、降仓清单"执行后仓位约 x%"），降仓金额照旧；Q2 = A：去掉"预算 28% 下仓位"格，年化波动并入"未来一年最大回撤"格。
- `static/css/trailing_stop.css`（v13）：`.ts-dd-ladder-cap` 说明行；阶梯第三列不换行（含中文，改非等宽）；回撤单元格 6 列 → 5 列。
- `decision.html`：只升两处版本号（`trailing_stop.css` 12→13、`trailing_stop_panel.js` 15→16）。
- 测试：新增 `tests/test_decision_visual_2.cjs`（沙箱加载面板、与服务器同形状夹具：无"仓位上限 / 仓位 / 上限 / 降至 / 下仓位 / 执行后仓位 / ≤ x%"；回撤口径与模拟仓位数字不显示；"执行目标上限 x%"= cap_pct = 档位配置值 = 执行目标回撤约束值；进入 / 退出说明；0 档不约束；源码约定：`portfolio_vol` 回撤约束读 `cap_pct`、`drawdown_service.brief` 发布 `cap_pct`、`replay_tiers` 退出规则；版本号）。对改前代码失败（"仍出现'仓位上限'"）、对改后代码通过。`tests/test_export_coverage_frontend.cjs` 版本号断言 v=15 / v=12 → v=16 / v=13（用户 23:10 同意；原因：本提交改动这两个文件）。云端前端 35 个 `.cjs` 全部通过；全量 pytest 由一键推送执行（本提交无 Python 改动）。
- 5 项核对：只改展示文案与样式，执行目标、合规、跟踪止盈、买入门控、当前仓位的计算与接口均未改；部署（与第 0 轮第一组合并）后经隧道复核 5 项与跟踪止盈计数、回撤读数与档位。
- 推送：推送时间与提交号随提交 2 补记。
- 提交 1 推送：11-04 23:23（push-20261104-232325，提交 `3fa18c1`）：本机快照测试 pytest 2172 passed / 1 skipped，production_check 通过，前端 35/35。未部署（与第 0 轮第一组合并部署）。

### 提交 2 · 日报弹窗外观（界面提交）
- `decision.html`：日报弹窗标题"投委会决策简报"与"复制全文""下载 .md"按钮去 emoji；`decision_action.css` 版本号 3→4。未动 user-profile 块、`sidebar.js` 引用行与参数对比弹窗标记。
- `static/css/decision_action.css`（v4）：新增"日报弹窗"一节，全部限定在 `#report-overlay` 下（`.report-overlay / .report-modal-header / .btn-report-action` 与参数版本对比弹窗共用，对比弹窗属隐藏模块，不变）：遮罩去毛玻璃；面板 `--dc-surface` 实底 + 1px `--dc-line-strong` + 6px 圆角（`--dc-radius`）、无阴影、无上滑入场动画；标题去全站 h3 装饰色条；"复制全文 / 下载 .md / 关闭"三个按钮同一中性描边样式；"已复制"为通过色描边（文字由 JS 改为"已复制"）；关闭 × 的 hover 中性。只用 `ac_tokens.css` 变量。正文 `.report-content`（后端 markdown，含 emoji）按约定不动，归第 1 轮 1e。
- `static/js/decision/risk_alerts.js`（日报弹窗 JS）：已核对无 emoji，复制后按钮本就回到"复制全文"，未改。
- 测试：`tests/test_decision_visual_2.cjs` 补日报弹窗部分（弹窗标记与 generateReport / showReportModal / closeReportModal / copyReport / downloadReport 无 emoji；三个按钮文字与同一样式；无内联样式；样式选择器全部以 `#report-overlay` 开头；实底 / 6px / 无阴影 / 无动画 / 无字面色值；不涉及参数对比弹窗；`decision_action.css` 版本号）。对提交 1 代码失败（"日报弹窗标记含 emoji"）、对新代码通过。云端前端 35 个 `.cjs` 全部通过（含 1b / 1c）；本提交无 Python 改动。
- 截图：按用户 Q4，日报弹窗只做云端渲染（打桩正文，不在服务器点"生成日报"），见基线目录 `云端渲染_改前 / 改后_*_report.png`。
- 5 项核对：只改弹窗外观，执行目标、合规、跟踪止盈、买入门控、当前仓位均未改。
- 推送：11-04 23:31 美中（push-20261104-233152，提交 `3d0612a`；pytest 2172 passed / 1 skipped，前端 35/35）。部署与复核见「权威环境收尾核对 · 决策中枢视觉 2 与第 0 轮 0b 合并部署 · 部署后复核（2026-11-05）」。

## 第 0 轮 0b · 回测页 CI 入口隐藏、去掉外链头像（2026-11-05，界面提交；方案见 `docs/ROUND0_CI_EVALUATE_ONLY_PLAN.md` 3.8）
- 顺序调整（用户 11-05 提出）：0b 提前到 0a 之前做，会话三改为 0a-5 + 0a-6；已记入方案第 4 节和第 7 节 J1。理由：
  - 0b 与 0a 没有代码依赖，文件不重叠（0a 全是后端，0a-6 已核实不改前端）
  - 提前能更早关掉 F9：回测页"运行 CI""批准"在 18000 点了能真正触发 CI，结果为 ACCEPT 就会发布
- 开工前核对（11-05 02:0x 美中，只读）：
  - 决策中枢视觉 2 已推送：`3fa18c1`（push-20261104-232325）、`3d0612a`（push-20261104-233152，pytest 2172 passed / 1 skipped，前端 35/35）；本机 main = origin/main = `3d0612a`
  - 本日志无 0a 实施条目，0a 涉及的后端文件未改动，没有并行的 0a 会话；本步目标文件与暂存区一致
  - 本会话没有本机命令行：git 状态靠读 `.git/index`、refs 和推送日志核对
- 实搜结果：
  - 外链头像块 13 处 = `static/js/sidebar.js` 163–168 + 12 个 HTML（audit / decision / index / strategy / treasury + 7 个个股页）；方案 F12 与 3.8 写的"12 处 / 11 个 HTML"不准。`static/js` 其余文件没有
  - `sidebar.js` 引用 17 页：v=5 ×9（audit、backtest、decision、factor、index、industry、portfolio、report、treasury），v=4 ×7（个股页），v=205 ×1（strategy）
  - 回测页行号与 11-05 静态阅读一致（backtest.html 149 / 159；backtest.js 1237 / 1253 / 1274 / 1307 / 1367 / 1386），`backtest.js?v=52`
  - 已有前端 `.cjs` 与相关 pytest 没有断言 `sidebar.js` / `backtest.js` 旧版本号
- 用户确认（02:25）：
  - 策略下拉框（只被 triggerCI 读取，且有判空）随"运行 CI"按钮一起用注释隐藏，"↻ 刷新"保留
  - 待批准判断：`approval_status` 有值（非空）时只看它；缺失或为 null 时回退 `status === 'REVIEW'`（0a-1 迁移后旧记录可能是 null）；测试补 null + REVIEW 夹具
  - 回测页加载 `ac_tokens.css`；"没有可见的运行 CI 按钮"按解析后的 DOM 断言；头像块是删除不是注释
  - 不启动本机 8000（权威收尾核对前本机服务保持关闭）；改前经 18000 只读查看，改后用云端渲染，部署后再经 18000 复核
- 改动（19 个文件 + 新增 1 个测试；各文件原有换行 CRLF / LF 与 BOM 不变）：
  - `backtest.html`：`ac_tokens.css?v=2` 作为第一个样式表；策略下拉框与"▶ 运行 CI"按钮放进 HTML 注释（原标记保留，注明第 0 轮起隐藏、批准走服务器 curl 人工流程）；空状态改为"暂无 CI 记录"；`backtest.js` v52→53；`sidebar.js` v5→206
  - `static/js/backtest.js`（v53）：
    - 新增 `_ciIsPending` / `_ciPendingTag`
    - 卡片和历史行原"✓ 批准"按钮的位置改为 `.ac-tag.ac-tag-info`"待批准 · 人工流程"（中性色，不用阻断色），其他状态渲染不变
    - 空状态同上
    - `triggerCI` / `acceptCIRun` 保留，加注释"第 0 轮起入口隐藏，批准走服务器 curl 人工流程"
  - `static/js/sidebar.js`：删去生成头像块的 7 行，头注释记一行
  - 12 个 HTML 删去静态头像块；17 个引用页 `sidebar.js` 统一 v=206
  - 未改的残留样式（第 2 轮样式合并时清理，已登记）：styles.css 284–313（.user-profile / .user-info）、visual_excellence.css 48 与 103–111、mobile.css 34；sidebar.css 没有相关规则
- 测试：新增 `tests/test_round0_ui.cjs`（11 组检查，不联网、不调 `/ci/*`）
  - 根目录 HTML 与 `static/js` 不含 pravatar.cc / "基金经理 Pro" / "顶级投研权限"
  - 13 处头像块源码里不再有 user-profile（删除而非注释）；沙箱运行 `sidebar.js` 渲染侧栏：导航与收起按钮照常，无头像块
  - 17 个引用页 `sidebar.js` 版本号一致，且不是旧值（1 / 4 / 5 / 205）
  - 回测页用极简 HTML 解析（注释不算节点）断言 DOM：没有 #ci-run-btn、#ci-strategy-select、triggerCI / acceptCIRun 调用和"运行 CI"按钮，"↻ 刷新"仍在；原标记以注释保留，两个函数仍在
  - 沙箱渲染 CI 历史：待批准 5 组夹具（REVIEW 无字段 / ACCEPT + PENDING / REVIEW + null / REVIEW + 空串 / REVALIDATED + PENDING），卡片与历史行各只出现一个中性标签、没有按钮；非待批准 6 组（REJECT、ACCEPT 无字段、INSUFFICIENT_EVIDENCE、ERROR、REVIEW + APPROVED、ACCEPT + 空串）不显示标签
  - "其他状态渲染不变"：与改前 v52 代码渲染结果（去掉批准按钮后规范化）的 sha256 逐条比对
  - 空状态为"暂无 CI 记录"，源码不含"点击「运行 CI」"；`ac_tokens.css` 最先加载；`backtest.js` 版本号 > 52
  - 对改前代码 11 组全部失败，对改后代码通过
  - 云端前端 `.cjs` 36/36 通过；在 LF 副本（与推送快照同为 LF）上也是 36/36。已有测试未改。全量 pytest 由一键推送在本机跑（本提交无 Python 改动）
- 改前经 18000 只读查看（11-05 02:40–02:44 美中 = 16:40–16:44 北京）：
  - 决策中枢 / 组合 / 策略 / 中芯国际页，1440×900 展开、收起，375 手机
  - 服务器 `sidebar.js?v=5`，外链头像实际从 pravatar.cc 加载
  - 收起态：收起按钮 767–811 px，头像 811–872 px；展开态 1440×900 下收起按钮在 960 px，落在视口外（原有问题，与去头像无关，已登记第 2 轮）
  - 手机端：侧栏隐藏，底栏 5 项
  - 只发 GET，没有调用 `/ci/*`，没有点任何按钮，没有打开回测页
  - 收起态是临时写本页 localStorage `ac-sidebar-collapsed=true`，看完已删除恢复（原为未设置）
- 5 项基线（同一次只读查看，状态计算于 11-05 16:28 北京）：
  - 执行目标 25.0%：最严约束为组合回撤刹车 25%；AIAE 矩阵 60%、尾部刹车后 60%、组合波动预算 65.0%
  - 合规 blocked：硬阻断"主题集中度、仓位超限检查"，警告"组合波动预算"
  - 跟踪止盈：页面分组只有"已触发 1""正常持有 13"，没有其他分组，与 11-05 13:11 北京基线（RED 1 / YELLOW 0 / GREEN 13 / LEGACY 0）一致
  - 加仓权限关闭（禁止下单 · 风险复核）
  - 当前仓位 100.0%（持仓截至 11-04 15:00 对账单 · 价格 11-05 收盘）
- 截图：`D:\FIONA\alphacore_baselines\20261105_0b\`（README 写明来源）
  - `服务器18000_改前\`：12 张，分辨率受浏览器面板限制
  - `云端渲染_改前\`、`云端渲染_改后\`：各 13 张，云端 Chromium，接口全部打桩、外链全部拦截
  - 回测页 CI 面板只做云端渲染：`/ci/history` 打桩 6 条（REVIEW 旧形状、ACCEPT + PENDING、REJECT、REVIEW + null、ACCEPT 旧形状、ERROR）
  - 云端改后：收起按钮落到底部（828–872 px），展开态不变；手机端侧栏本就隐藏，决策中枢、组合两页与改前逐像素相同，策略页（时钟）和个股页（背景动画）只有动态区域不同。未错位，不需要占位
- 5 项核对：只改前端展示，执行目标、合规、跟踪止盈、买入门控、当前仓位的计算与接口都没改。部署后经 18000 复核 5 项，并只读查看同样 4 页 × 3 视图
- 登记（本步不改）：CI 面板副标题"自动化参数优化 + 质量门检查"在 0a 部署后就不准确了，已记入 `docs/SITE_SLIMMING_ROUNDS.md` 第 2 轮视觉待办，随回测页整页处理
- 推送 / 部署：11-05 07:36 美中推送（push-20261105-073307，提交 `ad0989d`；pytest 2172 passed / 1 skipped，前端 36/36，production_check 通过），GitHub Actions CI #166 通过。用户定（07:48）：权威环境收尾核对完成后与决策中枢视觉 2（`3fa18c1`、`3d0612a`）合并部署；11-05 22:04:58 北京已部署，复核见下一节

## 权威环境收尾核对 · 决策中枢视觉 2 与第 0 轮 0b 合并部署 · 部署后复核（2026-11-05）
- 收尾核对（07:5x 美中 = 21:5x 北京，经 18000 只读；只发 GET，没有调用 `/ci/*`，没有点"保存审计"等写操作按钮）：
  - 读取鉴权后 16 个页面正常打开，没有 401 / 403，也没有出现令牌输入条
  - 因子分析页没开：页面一打开就自动 POST `/api/v1/factor-analysis`（factor.js 119 行 `runAnalysis('roe')`），按规则 8 不开；用户定第 2 轮下线时一并确认不再发出
  - 回测页（只加载、不展开 CI 面板）有两个请求一直 404：`/api/aiae/aiae_v5_backtest`、`/api/aiae/aiae_v5_signal_history`（backtest.html 417–418 行，路径少 `/v1/`），与鉴权无关，原本就有，登记第 2 轮
  - 审计页 A 区定时任务 11-05 五个关键任务都按时：ETF 成分检查 08:40、收盘预热 15:37、跟踪止盈日终 15:51、AIAE 基金仓位 16:00、审计历史 16:45；暂停的只有 NLP 情报两项和月度策略 CI（已知）
  - 审计页 A 87 分（可信），三个一票否决项通过；账户数据环境显示"权威 · ACCOUNT_AUTHORITY=server"
  - 5 项：执行目标 25.0%（回撤刹车最严；AIAE 矩阵 60%、尾部刹车后 60%、组合波动预算 65.2%）；合规 2 条硬阻断（主题集中度、仓位超限检查）+ 组合波动预算警告；跟踪止盈已触发 1（沪电股份）、正常持有 14；下单权限关闭；当前仓位 99.0%（持仓截至 11-05 15:00 对账单 · 价格 11-05 收盘）
  - 与 02:44 美中相比：服务器在此期间导入了 11-05 15:00 对账单（风险状态 19:10 北京重算，本会话没有任何写操作），当前仓位 100%→99%、持仓 14→15 只（新增生益电子）、主题 88%→87%；执行目标、合规结论、下单权限不变
- **用户结论（08:02 美中）：权威环境收尾轮现在算完成。** 理由：
  - 读取鉴权已满 1 天，16 个页面和 11-05 五个关键任务都正常
  - 定时任务、看门狗、预热直接调函数、不经 HTTP（11-04 已核实），再等一天得不到新信息
  - 周六的行业池刷新也不经 HTTP，周一在审计页 A 区看一眼即可
  - 备注：本机 8000 的非权威界面（1b 按钮禁用、3 横幅）仍只按测试与源码核对过，本机服务重新开启时可顺带看一眼
- 部署（规则 8：改变服务器状态，由用户在服务器执行）：
  - 部署前核对（22:03 北京）：审计页 A 区只列关键任务和暂停任务，另对照 `main.py` 全部调度（Asia/Shanghai），22:03–22:33 没有定时任务；只有按间隔循环的行情轮询（30 秒，夜间抓 VIX）、告警扫描（10 分钟）、事件监控（5 分钟）、看门狗（30 分钟），重启后接着跑
  - 用户执行 `cd /root/quant_dashboard/quant_dashboard && bash update.sh`，11-05 22:04:58 北京完成（耗时 23s，构建 6s），代码 `ad0989d`，一并带上决策中枢视觉 2 的 `3fa18c1`、`3d0612a`
  - 三个提交：`3fa18c1`（视觉 2 提交 1，11-04 23:23 美中推送）、`3d0612a`（视觉 2 提交 2，11-04 23:31）、`ad0989d`（第 0 轮 0b，11-05 07:36，CI #166 通过）
- 部署后复核（22:07–22:15 北京，经 18000 只读）：
  - 5 项与部署前一致（25.0%；2 条硬阻断 + 波动预算警告；已触发 1 / 正常持有 14；下单权限关闭；99.0%）；审计页仍为"权威 · ACCOUNT_AUTHORITY=server"，定时任务运行记录重启后仍在
  - 读取鉴权：浏览器里不带令牌请求 `GET /api/v1/system/authority` 返回 401，`/health` 200
  - 决策中枢：跟踪止盈面板为"回撤 3 档约束 → 执行目标上限 25%"，面板内不再出现"仓位上限 x% / ≤ x% / 降至 x%"；日报弹窗（只读 DOM 与计算样式，没有点"生成日报"）标题"投委会决策简报"无 emoji，按钮"复制全文 / 下载 .md / 关闭"，面板实底、6px 圆角、无阴影、遮罩不模糊
  - 0b：决策中枢 / 组合 / 策略 / 中芯国际页都加载 `sidebar.js?v=206`，没有 .user-profile，也没有 pravatar.cc 请求；收起态收起按钮 828–872 px（与云端改后渲染一致）；手机端侧栏隐藏、底栏 5 项
  - 回测页只加载页面：`backtest.js?v=53`、`ac_tokens.css` 最先加载、没有"运行 CI"按钮和策略下拉框、CI 区只剩"↻ 刷新"、空状态"暂无 CI 记录"，没有 `/ci/*` 请求
  - 截图：`D:\FIONA\alphacore_baselines\20261105_0b\服务器18000_部署后\`（12 张）；收起态临时写的 localStorage 已删除恢复
- 【高】回撤数字两处不一致（排查只读，不改代码；修复放到第 0 轮之后，与后端仓位文案统一一起做，已登记 `docs/DECISION_HUB_VISUAL_1B_1C_PLAN.md` 12.6）：
  - 来源：两个数出自同一函数 `drawdown.monitor`（`trailing_stop_service.build_report` → `drawdown_service.section`）的 `brake.dd`，时点不同
    - 26.1%：缓存 `drawdown_brake.dd`，由 `write_risk_state` 在导入后重算时写入（`computed_at` 11-05 19:10:35，`holdings_as_of` 11-05 15:00），经 `services/risk_state.drawdown_brake()` 读取。执行目标（AIAE 执行层回撤刹车一档）、合规 `drawdown_brake`、审计页只读读数、组合页"当前回撤（回撤刹车）"都用这个
    - 26.4%：`GET /portfolio/trailing-stops` 每次现算的 `drawdown.brake.dd`（= `realized.current_dd` = −0.2636），显示在跟踪止盈面板回撤 KPI、回撤分档区、行动队列
  - 口径：两边相同。风险资产时间加权净值（不含现金），日收益 = 前一日持仓 × 价格变动 ÷ 前一日持仓市值；现金与资金进出不进入净值，所以 11-05 对账单里的资金进出对两边都没有影响；仓位分母（持仓市值 + 快照现金）两边也相同（invested_pct 都是 99%）
  - 差异原因（推测，未在服务器数据上核实）：19:10 之后输入变了，而缓存只在日终 / 导入时重算。最可能是 11-05 对账单新增的生益电子（688183.SH）在 19:10 还没有日线，被排除在净值之外；之后页面读取触发后台行情同步，补到了日线。台账成交只到 11-03（11-04 / 11-05 的成交未导入），持仓回滚把这 281 股当成自 09-02 起一直持有，于是它整段走势进入历史净值，回撤变为 26.4%
  - 已核实的另外两点：① 净值最后一天是 11-04，不是 11-05：沪电股份、通富微电没有 11-05 收盘（滞后 1 天，未达"滞后 >1 天才同步"的门槛），净值截到所有持仓都有收盘价的最后一天，所以两个数都是 11-04 收盘的回撤，而页面写的是"价格 11-05 收盘"；② 台账只到 11-03，而对账单是 11-05，最近两天的持仓回滚是近似（沪电 1200→800、生益电子新增都没有成交记录）
  - 执行目标用的那个数（26.1%）不算错：两边都是三档、上限 25%；退出三档要回撤收窄到约 16.6%，按 11-04 净值需单日上涨约 13%。两个数都受上面两点影响，严格说都不是 11-05 收盘的准确值
  - 修复建议：
    1. 一个来源：行情同步完成后调用 `refresh_risk_state("price_sync")`；跟踪止盈面板与回撤区改为显示风险状态里的数和它的计算时间，现算值与状态不同时另标"现算（未计入风险状态）"
    2. 写明净值截止日：风险状态带上净值最后一天；某些持仓缺当日收盘时标"回撤截至 MM-DD 收盘（n 只缺当日行情）"
    3. 行情补齐：日终后（如 18:30）对缺当日收盘的持仓再同步一次，不等到滞后 2 天
    4. 台账覆盖：对账单日期晚于台账最后成交日时，回撤刹车标"成交未导入至 MM-DD，持仓回滚为近似"，并提示导入交割单；审计页 A 区可加警告
    5. 测试：新持仓先无日线、后补到日线，风险状态与页面现算一致
  - 可选的服务器只读核实（用户自行决定是否执行）：`ls -l --time-style=+%F_%T data_lake/daily_prices/688183.SH.parquet` 修改时间若晚于 19:10:35，即证实上面的推测；`python3 -c "import json;d=json.load(open('data_lake/risk_state_live.json'));print(d.get('computed_at'),d.get('trigger'));print(d.get('drawdown_brake'))"` 可看缓存那一份
- 登记第 2 轮（`docs/SITE_SLIMMING_ROUNDS.md` 第 2 轮下线清单）：回测页两个 404 随整页处理；因子分析页下线时确认自动 POST 不再发出

## 第 0 轮 0a-1 · CI 只评估不发布、触发来源、落库补全（2026-11-05，行为提交；方案见 `docs/ROUND0_CI_EVALUATE_ONLY_PLAN.md` 3.1 / 3.2）
- 开工前（11-05 08:2x–08:3x 美中，只读；没有调用任何 `/ci/*`）：
  - 交割单：未导入。服务器台账仍为 63 笔（09-02～11-03），风险状态计算于 11-05 19:10:35 北京。用户 08:3x 定：先开工，会话一组末部署之前导入 11-04～11-05 交割单并告知时间，届时按规则 8 记入本日志；部署前的 5 项核对、"跟踪止盈面板回撤 = 执行列回撤"的核对都用导入后的数据
  - J3：审计页 A 区「定时任务运行」显示"已暂停: 策略 CI 每月1日"（11-05 22:29:01 北京 = 08:29 美中读取）
  - 补记文档推送：规则 8 / 9 写入通用约束的提交 `9d1c9b5`，11-04 22:26 美中推送（push-20261104-222641；pytest 2172 passed，前端 34/34，NEWS `81e0cbd`）
  - 方案行号与描述核对：与现状一致。核对时提的 4 条，用户 08:3x 确认照做并补充：
    1. ERP 优化器返回空结果原来不落库，改为写 ERROR
    2. `ci_runs` 加 `validation` 列（JSON），带 `schema_version`；迁移前的旧记录为空，0a-3 一律拒绝批准，不当作通过
    3. `/ci/accept` 鉴权照旧在前（无令牌仍 401），通过后返回 409、不发布；列出发布函数在仓库里的全部调用方（见下）
    4. 旧测试换成新测试，逐条写对照；dry_run 测试改为 spy 断言发布函数没被调用，不打桩
- J8 结论（用户 08:33 美中在本机执行两条只读 git 命令，输出已贴回）：
  - 事实：10-25 以来 `static/js/alphacore_utils.js` 共 5 个提交。11-01 之前只有 `0ca94c0`（10-29 初始提交）和 `f85df9f`（10-31 界面打磨）
  - 事实：给同源 `/api/` 请求自动带 X-API-Key 的 `window.fetch` 包装，是 `edae1bd`（11-04 11:02 美中"APIKEY验证"）才加的；之后 `d44641c`（11-04 11:21）只改了输入弹窗
  - 事实：11-01 时唯一带令牌的机制是 `AC.secureFetch`（`0ca94c0` 起就有，`prompt` 弹窗输入后存 localStorage），要显式调用才生效；回测页 `triggerCI` / `acceptCIRun` 用的是裸 `fetch`，不经过它
  - 推断：11-01 时回测页按钮发出的 `POST /ci/run` 不带令牌，F10 的第 ② 点成立。前提是 `backtest.js` 这两处当时也是裸 `fetch`：现状如此，0b 只加了注释、没改调用，但本命令没查 `backtest.js` 的历史。第 ① 点（11-01 服务器为生产模式且配了令牌）这条命令覆盖不到
  - 按 J8 约定到此为止，不再追查；0a-1 之后所有入口都不发布，且都记来源
- 发布函数 `publish_ci_parameters` 的全部调用方：本机仓库 456 个 .py 全文搜索（应用目录 + 根目录脚本 + `strategies/` + `_dev_tools/` 含 `_archived/` + `dashboard_modules/` + `data/` + `models/`，以及 `scratch/mr_ci_dry_run.py`）；`tests/` 只搜了云端已有的 80 个测试文件，其余由推送命令第 1 步的 `git grep` 补全
  - 改前有两个运行时调用方，0a-1 都删除了：
    - `services/strategy_pipeline.py` 185 行 `_publish_accepted_run`：被 `run_mr_ci`（ACCEPT / REVALIDATED）和 `run_erp_ci`（ACCEPT）调用
    - `routers/ci.py` 103 行 `POST /ci/accept/{run_id}`（REVIEW → 发布）
  - 测试：`tests/test_strategy_runtime.py` 5 处，都显式传 `path=` 临时文件，保留不改；`tests/test_strategy_pipeline.py` 原来打桩的 4 处随旧测试删除
  - 另一个写 `strategy_runtime.json` 的函数是 `record_ci_outcome`（REJECT / INSUFFICIENT_EVIDENCE 写 lifecycle）：0a-1 不改，0a-2 移到 `data_lake/`。两者共用的写文件函数 `_atomic_write_config` 没有别的调用方
  - 手动脚本都不调用发布函数，也不写 `strategy_runtime.json`：
    - `run_optimizer.py`：写 `aiae_mr_optimization_results.json`、`artifacts/aiae_optimizer_report.md`
    - `mr_auto_optimize.py`（根目录转发）→ `strategies/mr_auto_optimize.py` → `strategies/mr_per_regime_optimizer.py`：写 `mr_per_regime_params.json` 和 `mr_optimize_history.jsonl`
    - `strategies/erp_backtest_optimizer.py`：写 `erp_optimization_results.json`（流水线调用时 `persist_results=False`）
    - `sync_and_run.py`：只同步行情、跑动量回测
    - 这几个都是旧产物文件，生产只读 `strategy_runtime.json`（`config.py` 134 行注释）；`run_erp_ci` 读 `erp_optimization_results.json` 只当现任基准（ERP 停用中）
  - 只调流水线、不直接调发布函数：`main.py` 月度回调、`routers/ci.py` `/ci/run`、`scratch/mr_ci_dry_run.py`（`dry_run=True`，`scratch/` 不入库）、回测页 `triggerCI` / `acceptCIRun`（0b 起入口隐藏）。`_dev_tools/`、`strategies/_archived/`、根目录测试脚本里都没有
- 改动（8 个文件 + 新增 1 个测试；各文件原有换行 CRLF / LF 不变）：
  - `services/strategy_pipeline.py`：
    - 删除 `_publish_accepted_run` 和发布函数的 import；ACCEPT / REVALIDATED / REVIEW → `approval_status=PENDING`，`diff_summary` 末尾加"待人工批准（批准后经仓库提交生效）"；其余 → NOT_APPLICABLE
    - `run_full_ci` / `run_mr_ci` / `run_erp_ci` 加关键字参数 `trigger`；`resolve_trigger` 规范来源（scheduler / api / direct，其他值报错），同一次调用共用 `batch_id`；没传 trigger 记为 direct，打 WARNING"CI 直接调用（非定时 / 非接口）"，记主机名、pid、argv、线程名和流水线之外最近的调用位置（文件:行号 函数名）
    - 新增 `scheduler_trigger(job_id, schedule)`：任务名、标签、应运行时间（`job_runs.previous_fire`）
    - 落库补全：MR 缺 `REGIME_PERIODS` / 优化器返回空 → SKIPPED（原因写在 `diff_summary`）；ERP 停用 → DISABLED；ERP 优化器返回空 → ERROR；`run_full_ci` 的 MR / ERP 阶段整体出错 → 各写一条 ERROR（regime 为空）
    - MR 的 `validation` 加 `schema_version: 1`；`run_full_ci` 与 `run_erp_ci` 开头调 `init_db`（幂等，保证新列在、ERROR / DISABLED 能落库）；汇总加 `pending_approval`
    - 判断（本会话）：V5 自检的异常不写 `ci_runs`（它不是策略 CI，0a-5 拆成独立任务，由任务运行记录兜住）
  - `services/strategy_params.py`：`publish_ci_parameters(ci_run, *, path)`，path 必填，不传报 TypeError；函数体不变
  - `services/db/connection.py`：新增 `migrate_ci_runs_round0()`，加 8 列（`trigger_source`、`trigger_detail`、`batch_id`、`reason`、`approval_status`、`approved_at`、`approval_detail`、`validation`），做法同 `migrate_decision_log_v2`，在 `init_db` 末尾调用；`services/db/__init__.py` 导出
  - `services/db/ci.py`：`save_ci_run` 写新列（JSON 列为空时存 NULL）；`get_ci_history` 解码新的 JSON 列，并加 `trigger_source_label`（定时任务 / 接口 / 直接调用；空 = "未记录（第 0 轮前）"）。旧记录不回填
  - `routers/ci.py`：
    - `/ci/run`：`reason` 必填，去首尾空格后 2–200 字，否则 422。来源记 `api`：client_host、X-Forwarded-For、User-Agent、Origin、Referer、X-AC-Caller（各截断 200 字）、strategy、regime、reason，加认证标记 `auth`（配了令牌 = ok，没配 = not_required）；不读取任何令牌值
    - `/ci/accept`：鉴权由中间件在前（无令牌 401），通过后一律 409，不查库、不发布、不改记录；去掉发布函数 import
  - `main.py`：月度回调改为 `run_full_ci(trigger=scheduler_trigger("strategy_ci_monthly", 该任务的调度规则))`
- 测试：
  - 新增 `tests/test_round0_ci.py` 26 条：不联网；运行时配置用临时副本（重定向 `RUNTIME_CONFIG_PATH`，真实文件只读、结束时核对字节），SQLite 用每条测试自己的临时库；发布函数只做 spy（包住真函数），不打桩
  - 对改前代码 25 条失败、1 条通过（`ERP_CI_AUTO_OPTIMIZE is False` 锁定测试，改前就成立）。另验证：去掉 trigger 参数后，改前代码会把临时副本改写，"运行时配置字节不变"这条断言确实失败
  - 旧测试 → 新测试（`tests/test_strategy_pipeline.py` → `tests/test_round0_ci.py`）：
    - `TestAcceptedRunPublication.test_accept_remains_accept_only_after_successful_publish` → `test_mr_pass_is_pending_and_runtime_bytes_unchanged[ACCEPT_CHALLENGER-ACCEPT]`
    - `TestAcceptedRunPublication.test_revalidated_incumbent_is_published` → `test_mr_pass_is_pending_and_runtime_bytes_unchanged[REVALIDATE_INCUMBENT-REVALIDATED]`
    - `TestAcceptedRunPublication.test_review_is_not_published` → `test_erp_pass_is_pending_even_if_auto_optimize_turned_back_on[0.95-REVIEW]`（另加 `[1.2-ACCEPT]`）
    - `TestAcceptedRunPublication.test_publish_failure_changes_accept_to_error`：发布已不存在，不会再有"发布失败改 ERROR" → `test_pipeline_and_router_do_not_reference_publish_function` + `test_publish_requires_explicit_path`
    - `TestMrDryRun.test_dry_run_neither_publishes_nor_persists`：同名保留，原来给 `_publish_accepted_run` 和 `save_ci_run` 打桩，改为 spy（包住真函数）断言发布函数、`record_ci_outcome`、`save_ci_run` 都没被调用，且流水线模块里没有发布函数
    - `TestMrDryRun.test_formal_run_initializes_ci_schema_before_optimization`、`TestQualityGate`：不变
  - 其余新测试：REJECT / INSUFFICIENT_EVIDENCE 为 NOT_APPLICABLE；SKIPPED ×2、DISABLED、ERP 空结果 ERROR、`run_full_ci` 阶段出错 ERROR 都落库；direct 来源带调用位置并打 WARNING；`run_full_ci` 四条记录共用 batch_id；`scheduler_trigger` 应运行时间；`main.py` 回调传 scheduler（源码契约）；未知来源报错；`/ci/run` 缺 reason / 太短 / 太长 422 且不运行；`/ci/run` 来源字段齐全且不含令牌；`/ci/accept` 无令牌 401、有令牌 409 且不发布不查库；旧表迁移（幂等）与旧记录显示"未记录（第 0 轮前）"；新字段读写往返
  - 云端（Python 3.12，依赖按 requirements.txt）：云端已有的测试文件改前 481 passed / 2 failed，改后 503 passed / 2 failed（+26 新、−4 旧），失败的 2 条相同，都是云端没有 Windows 启动脚本（`test_windows_launcher.py`），与本改动无关；`engines/production_check.py --code-only` 10/10 通过。全量 pytest 由一键推送在本机跑
- 5 项核对（静态）：执行目标、合规、跟踪止盈、买入门控、当前仓位的计算都不读 `ci_runs`、不调流水线和 CI 路由；参数读取（`get_mr_params` / `get_erp_params`）和 lifecycle 读取（`get_mr_lifecycle`）没改，`record_ci_outcome` 没改，所以 MR 信号与开仓权限不变。经 18000 的读数在组末部署前后各做一次（用导入后的数据）
- 部署：不单独部署，会话一组末与 0a-2 一起部署（部署前先问用户）。部署后启动时 `init_db` 自动给服务器 `ci_runs` 加列，旧记录不变
- 推送：11-05 09:13 美中（push-20261105-091337，提交 `4ed3cb8`；pytest 2194 passed / 1 skipped，前端 36/36，production_check 通过；NEWS `9988a29`）。推送前检查列出 3 份文档"不随本次提交"，用户确认后留在本机，随 0a-2 提交

## 第 0 轮 0a-2 · MR lifecycle 自动记录移到 data_lake（2026-11-05，行为提交；方案见 `docs/ROUND0_CI_EVALUATE_ONLY_PLAN.md` 3.3）
- 开工前（09:2x 美中，只读；没有调用 `/ci/*`）：0a-1 已推送（`4ed3cb8`）。方案 3.3 与现状一致：
  - 读取方都经过 `get_mr_lifecycle` / `get_all_mr_lifecycle`：MR 引擎、`decision_policy.decorate_signal`、手动 MR 计划、全策略聚合、参数接口、审计页
  - 审计页 `_regime_integrity` 直接读运行时配置文件，但只看参数完整性，不读 lifecycle
  - 写入方只有 `record_ci_outcome`，调用方只有流水线
- 改动（3 个文件 + 新增 1 个测试；换行不变）：
  - `services/strategy_params.py`：
    - 新文件 `data_lake/strategy_state/mr_lifecycle.json`，每个状态一条：status、validated_at、data_through、validation_run_id、next_validate_after、params_revision、written_at、trigger_source
    - `record_ci_outcome`：改写这个文件（原子替换，保留其他状态），不再写运行时配置。params_revision 取当前运行时 revision，trigger_source 取 0a-1 起的记录来源。只接受 REJECT / INSUFFICIENT_EVIDENCE
    - 写文件这一层再拦一次：status 不是 rejected / insufficient_evidence（包括 validated）直接报错；现有文件损坏时拒绝覆盖，保留现场
    - `get_mr_lifecycle`：以运行时配置为基础；条目要同时满足 params_revision 等于当前 revision、validated_at 比基础记录新，才用它；之后照旧按 next_validate_after 判过期；返回加 `lifecycle_source`（runtime / data_lake）
    - 文件损坏 → fail-closed：三态一律 stale、不许开仓（reason `lifecycle_state_unreadable`，`lifecycle_source` 为 `data_lake_error`），不退回基础记录。损坏的判定见方案 3.3 实施补充
    - 读取按文件修改时间缓存，写入后清缓存
    - 至此服务器进程内写 `strategy_runtime.json` 的只剩发布函数，而它在服务器进程内没有调用方
    - 判断（本会话）：损坏时打 WARNING（每种错误一次），不用 ERROR。任务运行记录会把线程里的 ERROR 日志算作任务失败，文件一坏，所有用到 MR 的定时任务都会一起报失败；而审计页 MR 生命周期会显示 stale（40 分，判失败），足以发现
  - `services/strategy_pipeline.py`：一行日志标明"(data_lake)"，模块说明加 0a-2 一句
  - `tests/conftest.py`：`_STATE_REDIRECTS` 加 `services.strategy_params.MR_LIFECYCLE_STATE_PATH` → 每个测试的临时文件。默认不存在，与部署时服务器的状态一致；只重定向，写入守卫不变
- 测试：新增 `tests/test_round0_mr_lifecycle.py` 25 条，对 0a-1 代码全部失败，对改后代码通过：
  - 状态文件由 conftest 重定向；默认路径在 `data_lake/strategy_state/`
  - REJECT / INSUFFICIENT_EVIDENCE 写进 data_lake，运行时配置字节不变；条目字段齐全，读回为 data_lake 来源、不许开仓
  - ACCEPT / REVALIDATED / REVIEW / ERROR / SKIPPED / validated 一律报错、不写文件；写文件层拒绝 validated
  - 多个状态互不覆盖；现有文件损坏时拒绝覆盖
  - 源码契约：写运行时配置的 `_atomic_write_config` 只剩发布函数调用
  - 文件不存在时：三态、两个时点（11-05、11-20），与改前算法逐字段相同
  - revision 不一致的条目、比基础记录旧的条目都被忽略；同版本、更新的条目生效，过了复验期照旧变 stale
  - 运行时为 validated（允许开仓）时，同版本、更新的 rejected 条目会关掉开仓（自动只会更严）
  - 5 种损坏（JSON 坏、结构错、缺字段、validated 条目、未知版本）：即使运行时基础记录是 validated，三态也全部 stale、不许开仓，引擎要读的字段仍在
  - 流水线 REJECT：记到 data_lake（run_id、来源、data_through 正确），运行时配置不变
  - 云端已有的测试文件：改前 503 passed / 2 failed，改后 528 passed / 2 failed，失败的 2 条相同（云端没有 Windows 启动脚本）；`production_check --code-only` 10/10。全量 pytest 由一键推送在本机跑
- 5 项核对（静态）：执行目标、合规、跟踪止盈、买入门控、当前仓位都不读 MR lifecycle（`compliance_gate` 只在注释里提到手动 MR 计划）。部署时服务器上没有这个文件（`data_lake/` 是持久卷，仓库不带它），lifecycle 与现在完全相同：BEAR stale（复验期 10-28 已过），RANGE / BULL insufficient_evidence（复验期到 11-13 23:46 北京，之后照旧变 stale）。MR 信号和开仓权限不变
- 登记 0a-6：审计页"均值回归"行的来源说明还写"strategy_runtime.json runtime lifecycle"，改为按 `lifecycle_source` 显示（已记入方案 3.7）
- 附带提交：上一会话写好、未推送的 3 份文档（`ACCOUNT_AUTHORITY_AND_RISK_REFRESH_PLAN.md`、`DECISION_HUB_VISUAL_1B_1C_PLAN.md` 12.6 回撤【高】、`SITE_SLIMMING_ROUNDS.md` 第 2 轮下线清单）。0a-1 推送时被推送前检查列为"不随本次提交"，用户确认后留在本机；同一会话对实施日志和第 0 轮方案的改动已随 0a-1 提交
- 部署：会话一组末与 0a-1 一起部署（部署前先问用户）
- 推送：11-05 09:25 美中（push-20261105-092536，提交 `38149f7`；pytest 2219 passed / 1 skipped，前端 36/36，production_check 通过；NEWS `0e52d13`）。3 份文档随本提交推送，没有文件留在本机

## 第 0 轮会话一组末 · 交割单导入、回撤核对、0a-1 + 0a-2 部署与复核（2026-11-05）
- 交割单导入（规则 8：改变服务器状态，用户事先告知 09:33 美中，由用户在服务器页面执行）：
  - 23:34:29 北京（09:34 美中）`20261104交割单查询.txt`：解析 31 条，新增 0、重复 31，疑似重复 0、冲突 0（成交日期 10-09～11-03）
  - 23:34:51 北京 `20261105交割单查询.txt`：解析 54 条，新增 0、重复 54，疑似重复 0、冲突 0（成交日期 09-07～11-03）
  - 事实：两份文件今天已导入过（01:55、16:28 北京），内容都只到 11-03。台账不变：63 笔，09-02～11-03。**11-04 / 11-05 的成交仍未进入台账**
  - 推断（未核实）：导出时查询截止日是 11-03，或券商交割单要结算后才出最近两天的记录。补导不需要部署，用户下次导出时留意日期范围
  - 导入接口照例重算风险状态：`computed_at` 11-05 23:34:52 北京（持仓截至 11-05 15:00 对账单）
  - 本会话只经 18000 读 `GET /api/v1/portfolio/trades` 的导入记录与条数，没有读取或记录文件内容
- 回撤一致性核对（只读，结果只记日志，不改代码）：**一致**
  - 执行列（风险状态缓存，`/portfolio/vol-budget` 回撤行）：−26.36%，三档，上限 25%，状态计算于 23:34
  - 跟踪止盈面板（`/portfolio/trailing-stops` 现算）：−26.36%，三档
  - 与 11-05 19:10 的 26.1% / 26.4% 相比：重算后缓存与现算对上，符合当时的推断（19:10 缓存算时生益电子还没有日线，之后补到）。台账只到 11-03 的缺口还在，两边都仍是近似值；修复照旧放在第 0 轮之后（`docs/DECISION_HUB_VISUAL_1B_1C_PLAN.md` 12.6 已补记）
- 部署前 5 项基线（导入后，23:3x 北京经 18000 只读；没有调用 `/ci/*`）：
  - 执行目标 25.0%：回撤刹车最严；AIAE 矩阵 60%、尾部刹车后 60%、组合波动预算 65.2%
  - 合规 blocked：2 条硬阻断（主题集中度、仓位超限检查），1 条警告（组合波动预算）
  - 跟踪止盈：已触发 1、正常持有 14
  - 下单权限关闭（风险复核）
  - 当前仓位 99%
  - 与 11-05 22:07–22:15 北京部署后复核相同
- 部署（规则 8，用户执行）：
  - 部署前核对（23:3x 北京）：对照 `main.py` 全部定时规则，23:40～00:20 没有定时任务（下一个是周五 06:30 美股 AIAE）；只有按间隔循环的行情轮询、告警扫描、事件监控、看门狗，重启后接着跑
  - 用户同意后执行 `cd /root/quant_dashboard/quant_dashboard && bash update.sh`，11-05 23:40:03 北京完成（耗时 23s，构建 5s），代码 `38149f7`，一并带上 0a-1 `4ed3cb8`
- 部署后复核（23:41–23:44 北京，经 18000 只读）：
  - 5 项与部署前相同：执行目标 25%（回撤 −26.36%、三档）；合规 2 条硬阻断 + 组合波动预算警告（预热约 10 秒后出结论）；跟踪止盈已触发 1 / 正常持有 14；下单权限关闭；当前仓位 99%。风险状态重启后仍为 23:34:52 那一份（持久化文件）
  - MR lifecycle 与部署前相同，三态都是 `lifecycle_source=runtime`（服务器上还没有 data_lake 状态文件）：BEAR stale（configured rejected，复验期 10-28 已过）；RANGE / BULL insufficient_evidence（复验期 11-13 23:46 北京），都不许开仓。运行时配置 revision 11
  - 审计页 A 区：仍显示"已暂停: 策略 CI 每月1日"；均值回归行"三态生命周期 0/3 状态有效"，与部署前一致
  - `ci_runs` 新列（用户 09:41 美中在服务器执行只读命令，`mode=ro`）：表结构已含 `trigger_source`、`trigger_detail`、`batch_id`、`reason`、`approval_status`、`approved_at`、`approval_detail`、`validation` 共 8 列；现有 4 条旧记录 `trigger_source` 都为空（读作"未记录（第 0 轮前）"）。方案 3.9（0c）的第一个前提已满足
- 会话一完成。下一步：会话二（0a-3 批准流程、0a-4 写操作日志）

## 第 0 轮 0a-3 · 批准流程 A：只记录批准、返回参数补丁与审阅摘要（2026-11-05，行为提交；方案见 `docs/ROUND0_CI_EVALUATE_ONLY_PLAN.md` 3.4）
- 开工前（11-05 09:5x–10:1x 美中 = 23:5x–00:1x 北京，只读；没有调用任何 `/ci/*`，没有改服务器状态）：
  - 日志末尾没有比「会话一组末」更新的未收尾事项；`HEAD` 为 `18c97db`（会话一组末文档），工作区干净（用户 09:59 美中执行 `git log` / `git status` / `git archive`，云端从 archive 开工）
  - 0a-1（`4ed3cb8`）、0a-2（`38149f7`）已于 11-05 23:40:03 北京部署；0b 随 `ad0989d` 已部署
  - 基线（11-06 00:0x 北京，经 18000 只读）：执行目标 25%（回撤刹车三档）；合规 blocked，2 条硬阻断（主题集中度、仓位超限检查）+ 组合波动预算警告；跟踪止盈 RED 1 / GREEN 14；下单权限关闭；当前仓位 99%（持仓截至 11-05 15:00 对账单 · 价格 11-05 收盘；风险状态计算于 11-05 23:34:52）。与 11-05 23:41 部署后复核相同。审计页 A 区仍显示"已暂停: 策略 CI 每月1日"
    - 事实：刚打开决策中枢时显示过一次"执行目标不可用 · 缓存或断路器降级"，是 SWR 缓存过期被撤回（`routers/decision.py` 的 `invalidate_cached_hub`）；约 40 秒后后台重算完成（`_cache.stale=false`），读数恢复正常
  - 方案核对：3.4 无行号；3.5 写的 ApiKeyMiddleware 在 414 行，现为 `main.py` 416 行。与现状不符的 4 处先报告，用户 10:1x 美中逐条选择（都选了推荐项）：
    1. 补丁要求 `published_by="manual:ci:<run_id>"`，且与 `publish_ci_parameters` 写出结果逐字段一致；但发布函数写 `ci:<run_id>`，时间字段都取当下 → 改为共用纯函数并注入时间（`now` = 批准时间），发布函数改写 `manual:ci:`，补丁带基准 revision
    2. "已生效"按字面会把运行时 lifecycle 里 10-14 那几次 REJECT / INSUFFICIENT_EVIDENCE 的 run_id 显示成已生效 → 加条件：lifecycle `status=validated`，且记录是 ACCEPT / REVALIDATED
    3. "已被取代"只算更新的已评估运行（ERROR / SKIPPED / DISABLED 不算）；已被取代、已过期的 PENDING 批准接口也拒绝（409）
    4. 写日志的 `auth` 由 ApiKeyMiddleware 在 `request.state` 写标记（另加 `unconfigured` 对应生产模式未配令牌的 503），只加标记、认证行为不变（0a-4 实施）
  - ERP（会话判断，提示词授权二选一）：`_apply_ci_update` 有 ERP 分支，但不检查状态与验证；`run_erp_ci` 从不写 `validation`；`ERP_CI_AUTO_OPTIMIZE=False`。选**对 ERP 拒绝批准**（409 `strategy_not_approvable`，写明原因）
- 改动（4 个文件 + 改 1 个测试 + 新增 1 个测试；换行不变）：
  - `services/strategy_params.py`：`_apply_ci_update` 加可选 `now`；新增 `compute_ci_update`（纯函数，深拷贝上算出发布后的完整配置）、`build_ci_patch`（补丁 `ci-param-patch-v1`）、`apply_ci_patch`（套补丁，基准 revision 不同报错）；`publish_ci_parameters` 改调 `compute_ci_update`，`published_by` 改为 `manual:ci:<run_id>`、`published_at` 带时区，新增可选 `now`、`expected_revision`（不一致报错、不写）。`_atomic_write_config` 的调用方仍只有发布函数
  - `services/db/ci.py`：`get_ci_run` / `get_ci_run_state`（单条 + 现算状态）、`approve_ci_run`（条件更新，只改这一条的三列、仅当仍是 PENDING）；`get_ci_history` 每条加现算显示状态（`approval_display` 等 5 个字段，原字段不变；只对 PENDING 查"已被取代"）
  - `services/db/__init__.py`：导出上面 3 个函数
  - `routers/ci.py`：`POST /ci/accept/{run_id}` 按方案 3.4 + 实施补充重做（400 / 404 / 409 的原因码见方案）；来源字段抽成 `_request_source`，`/ci/run` 与批准共用（`/ci/run` 记录内容不变）；`build_review` 生成审阅摘要。路由不 import 发布函数、不写任何文件
  - `tests/test_round0_ci.py`：`test_accept_needs_token_then_409_without_publishing` → `test_accept_needs_token_and_never_publishes`（无令牌 401 不变；有令牌缺请求体由 409 改为 400；仍断言不查库、不发布）。"批准后的行为"由新测试文件接替
- 测试：新增 `tests/test_round0_ci_accept.py` 35 条，不联网；运行时配置用临时副本（真实文件只读、结束时核对字节），SQLite 用每条测试自己的临时库，发布函数只做 spy
  - 覆盖：9 种请求体不合规 → 400 且记录不变；note 2 字 / 200 字边界通过；不存在 → 404；无令牌 401、错令牌 403 且记录不变；NOT_APPLICABLE / 空 / APPROVED → 409 `not_pending`；重复批准 409 且第一次批准的字段不变；validation 为空 / `{}` / 缺 schema_version / 版本 2 → 409；ERP REVIEW / ACCEPT → 409；状态与验证不符 → `patch_invalid`；已被取代（更新的 REJECT 算、更新的 ERROR 不算）、超过 35 天 → 409；批准成功只改这一条的三列，approved_at 为 +08:00，来源字段齐全、UA 截断 200，令牌不进库、不进响应；批准前后运行时配置字节不变、发布函数未被调用；源码契约（路由里没有发布函数、`_atomic_write_config`、`open(`、`json.dump(` 等）；补丁内容（改的项、未变的项不进补丁、其他状态不动、`published_run_id` 为 add）；**补丁套到基准配置 == 用 `publish_ci_parameters(now=补丁 now, expected_revision=基准)` 写临时文件的结果，dict 与 JSON 文本都相等**；发布函数 revision 不符报错不写、无时区的 now 报错；纯函数不改输入、不写文件；审阅摘要字段齐全、未变项标"不变"、REVALIDATED 全部"不变"；显示状态 7 种取值、rejected 的 run_id 不算已生效、34 / 36 天边界、不传配置时读运行时配置
  - 对 0a-2 代码：33 条失败、2 条通过（无令牌 401、路由源码契约，0a-1 起就成立）
  - 云端（Python 3.12，依赖按 requirements.txt，`TUSHARE_TOKEN` / `FRED_API_KEY` 用 CI 同款假值）：改前全量 2217 passed / 2 failed，改后 2252 passed / 2 failed，失败的 2 条相同（`test_windows_launcher`：zip 解压后中文文件名乱码，与改动无关）；`production_check --code-only` 10/10。全量 pytest 与前端测试由一键推送在本机跑
- 5 项核对（静态）：执行目标、合规、跟踪止盈、买入门控、当前仓位都不读 `ci_runs`、不调批准接口；参数读取与 lifecycle 读取没改；批准不写运行时配置。部署前后经 18000 各做一次（组末）
- 部署：不单独部署，会话二组末与 0a-4 一起部署（部署前先问用户）。预期部署后服务器 `ci_runs` 仍是原有 4 条、approval_status 都为空（部署后请用户只读核对）；目前没有 PENDING 记录，批准流程只靠测试验证
- 推送：11-05 10:20 美中（push-20261105-102049，提交 `8ecda90`；pytest 2254 passed / 1 skipped，前端 36/36，production_check 通过；NEWS `5acfe9a`）

## 第 0 轮 0a-4 · 服务器写操作日志（2026-11-05，行为提交；方案见 `docs/ROUND0_CI_EVALUATE_ONLY_PLAN.md` 3.5）
- 开工前核实（只读）：中间件顺序、导入类接口路径、uvicorn worker 数、ERROR 日志是否被计数，结果见方案 3.5 实施补充，都与方案一致或不影响设计；`auth` 字段的取法由用户 10:1x 美中确认（认证中间件写标记，加 unconfigured）
- 改动（7 个文件 + 新增 2 个；换行不变）：
  - 新增 `services/write_log.py`：纯 ASGI 中间件 `WriteLogMiddleware`，以及 `build_entry`、`append_entry`（加锁整行追加；超过 20 MB 只追加一次截断标记并打 WARNING）、`record`（失败只打 ERROR、计数，不影响请求）、`status()`（给 0a-6）、`attach` / `finish` / `file_name`（接口附加安全摘要）
  - `main.py`：在 `ApiKeyMiddleware` 之后注册（= 认证外层），加注释写明外 → 内的顺序
  - `services/auth_middleware.py`：每个分支在 `request.state.auth_result` 写认证结果标记，认证行为不变
  - `routers/portfolio.py`（`/portfolio/import`）、`routers/trailing.py`（`/trades/import`、`/trades/scan`）、`routers/ci.py`（`/ci/run`、`/ci/accept`）：附加安全摘要。导入接口的函数体第一句仍是 `require_authoritative`；`request` 参数放在最后、默认 None
  - `services/trade_import.py`：`scan_import_folder` 的文件条目加 `bytes`、`parsed` 两个计数（只加字段）
  - `tests/conftest.py`：新增 autouse fixture `_isolated_write_log`，把 `write_log.WRITE_LOG_DIR` 指到每个测试的临时目录；只重定向，真实数据写入守卫不变
- 测试：新增 `tests/test_round0_write_log.py` 20 条，不联网
  - 覆盖：`main.py` 的注册顺序（AST 读出 CORS → ApiKey → WriteLog → GZip），按此顺序 401 记得到、反过来记不到；401 = missing、403 = invalid、200 = ok，被拒时处理函数没执行；unconfigured（503）与 not_required；带唯一令牌和 Bearer 的请求后日志里没有这两个值，各字段齐全，`ts_bj` 为 +08:00、`ts_utc` 为 +00:00，UA 截断 200；请求体里的唯一标记和键名都不进日志，只有 content_type / content_length；5 个敏感 query 键连键名都不记，只记 `foo`、`bar` 和略去的个数；GET / HEAD / OPTIONS 和非 /api/ 的 POST 不记，PUT / PATCH / DELETE 记；未处理异常记 500；按北京时间分月（UTC 11-30 16:30 → 12 月文件）；超过上限只追加一条截断标记、WARNING 一次，"重启"后也不追加第二条；写入失败时请求照常 200，`status()` 计数、ERROR 一次；每个请求一整行 JSON
  - 接口摘要：`/portfolio/import` 上传含唯一标记的 GBK 文件（文件名带 Windows 路径），日志只有 file_name（去掉路径）/ bytes / rows / result，没有标记和证券名；`/trades/import` 成功与 `TradeImportError` 各一条（rejected 带错误码）；`/trades/scan` 每个文件的摘要；`scan_import_folder` 真实运行时带 bytes；`/ci/run` 的 batch_id 与传给流水线的一致；`/ci/accept` 被拒（400）也记原因码；detail 清洗；conftest 的重定向确实生效
  - 写测试时发现并修正：截断判断起初按带空格的 `"truncated": true` 找，而日志用紧凑 JSON，导致重复追加标记；改为解析最后一行 JSON
  - 对 0a-3 代码：模块不存在，整个文件收集失败（20 条都不通过）；只放入 `write_log.py`、不接线时 17 条失败、3 条通过（分月、清洗、conftest 重定向，都是模块自身的纯函数）
  - 首次全量时 26 条旧测试失败：`test_valuation_time`、`test_account_authority`、`test_ledger_export_coverage` 直接按位置调用路由函数，或要求函数体第一句是 `require_authoritative`。改为 `request` 参数放最后、默认 None，`require_authoritative` 仍是第一句，旧测试一条没改
  - 云端：全量 2272 passed / 2 failed（+20 新；失败的 2 条仍是 `test_windows_launcher`），`production_check --code-only` 10/10。全量 pytest 与前端测试由一键推送在本机跑
- 5 项核对（静态）：中间件只观察、不改请求和响应；导入接口只多了摘要，解析、写入、重算风险状态的逻辑没改；执行目标、合规、跟踪止盈、买入门控、当前仓位都不读写操作日志
- 观察（只读，11-06 00:3x 北京经 18000）：AIAE 执行层 11-06 的例行周评估**已经写入**前向记录（`/decision/exec-vs-actual` 的 events：2026-11-06 weekly，目标 25，实际 99，风险事件 drawdown_brake；决策中枢 next_eval_date 为 11-13）
  - 事实：周评估在周五第一次算决策中枢时触发（`services/aiae_execution.is_eval_due`）
  - 推断（未核实）：触发者可能是本会话 00:01 北京经 18000 的只读基线请求（GET `/decision/hub` 触发了重算），也可能是同一时段的后台任务。核实方法（只读）：`grep '^2026-11-06' /root/quant_dashboard/quant_dashboard/data_lake/aiae_exec_forward_log.csv` 看 `recorded_at`
  - 内容与 11-05 收盘数据一致（执行目标 25%，受回撤刹车约束），不影响 5 项读数
- 部署：会话二组末与 0a-3 一起部署（部署前先问用户）
- 推送：11-05 10:34 美中（push-20261105-103418，提交 `acb9a33`；pytest 2274 passed / 1 skipped，前端 36/36，production_check 通过；NEWS `c09f8b6`）

## 第 0 轮会话二组末 · 0a-3 + 0a-4 部署与复核（2026-11-05 美中 / 11-06 北京）
- 部署前核对（00:4x 北京，经 18000 只读；没有调用 `/ci/*`）：
  - 执行目标 25%（回撤刹车约束）；合规 blocked，2 条硬阻断（主题集中度、仓位超限检查）+ 组合波动预算警告；跟踪止盈 RED 1 / GREEN 14；下单权限关闭；当前仓位 99%（持仓截至 11-05 15:00 对账单 · 价格 11-05 收盘；风险状态 23:34:52）
  - 审计页 A 区仍显示"已暂停: 策略 CI 每月1日"。与开工基线相同
- 部署窗口：对照 `main.py` 全部定时规则，11-06（周五）最早的定时任务是 06:30 美股 AIAE，其后 08:30 早间预热、08:40 成分检查、09:00 AAII。建议在 05:30 北京前完成，期间只有按间隔循环的任务；月度 CI 暂停中，下次在 12-01
- 部署（规则 8，用户执行，事先征得同意）：`cd /root/quant_dashboard/quant_dashboard && bash update.sh`，11-06 00:38:37 北京完成（耗时 22s，构建 5s），代码 `acb9a33`，一并带上 0a-3 `8ecda90`
- 部署后复核（00:39–00:48 北京）：
  - 5 项经 18000 只读核对，与部署前相同：执行目标 25%；合规 2 条硬阻断 + 波动预算警告；RED 1 / GREEN 14；下单权限关闭；当前仓位 99%（风险状态仍为 23:34:52 那一份，持久化文件）。审计页 A 区仍显示"已暂停: 策略 CI 每月1日"
  - 0a-3（用户在服务器执行只读命令）：
    - 运行时配置 revision 为 11
    - `ci_runs` 仍是原有 4 条，`approval_status` 都为空：`8b6303a7-eee` MR BEAR REJECT、`0212b8b6-36e` MR RANGE INSUFFICIENT_EVIDENCE、`79840525-05f` MR BULL INSUFFICIENT_EVIDENCE、`f006cc2d-ce1` MR BEAR REJECT
    - 事实：服务器主机没装 `sqlite3`。方案 3.4 的事后核对命令改为 `docker exec quant_dashboard_app python -c ...`，在容器里用 `mode=ro` 只读打开（已在云端用临时库验证可用）；同时注明 curl 模板要用到主机上的 `python3`，这一点尚未核实
    - 目前没有 PENDING 记录，批准流程只靠测试验证；第一次真实使用要等 0c 恢复月度 CI 之后
  - 0a-4（规则 8：用户 10:4x 美中事先得知，由用户在服务器执行）：
    - 00:41:05 北京，主机上 `curl -X POST -H 'X-AC-Caller: deploy-check-0a4' http://127.0.0.1:8000/api/v1/system/auth_check`，不带令牌，返回 401。`auth_check` 是认证探针，不读写数据；被认证中间件拦下，处理函数没有执行
    - `tail` 当月日志 `data_lake/audit/write_log-2026-11.jsonl`：只有这一条。`status=401`、`auth=missing`、`caller=deploy-check-0a4`、`user_agent=curl/8.5.0`，`content_type` / `content_length` / `detail` 为空，没有令牌，也没有请求体
    - 这次 POST 让服务器新建了上述日志文件，写下第一条记录（改变服务器状态，已在此记录）
    - 事实：主机上 curl `127.0.0.1:8000` 的 `client_host` 是 `172.17.0.1`（Docker 网关）
    - 推断（未核实）：经 SSH 隧道的请求也走端口映射，`client_host` 也应是 `172.17.0.1`，所以方案 3.2 推断的"隧道与主机 curl 可凭客户端 IP 区分"大概不成立；能可靠区分的是 `caller`（`X-AC-Caller`）。0a-6 显示来源时以 caller 为主
- 11-06 周评估触发者（用户 10:48 美中执行 `grep '^2026-11-06' data_lake/aiae_exec_forward_log.csv`，只读）：
  - 事实：`recorded_at` 为 `2026-11-06T00:01:23`（容器本地时间）。本会话打开决策中枢做基线时，第一次取到的是过期缓存，SWR 在后台重算，重算结果的 asof 为 16:01:24 UTC（= 00:01:24 北京），与 `recorded_at` 差 1 秒
  - 推断（时间对得上，可信度高）：这次周评估是本会话 00:0x 北京经 18000 的只读基线（GET `/decision/hub`）触发的
  - 记录内容：weekly，AIAE 上限 60.0，波动预算 65.15，回撤上限 25.0，有效上限 25.0，目标 25.0，实际 99.0，差 74.0，reduce，趋势 bearish，风险事件 drawdown_brake
  - 待用户决定（登记，不在第 0 轮处理）：例行周评估在"周五第一次算决策中枢"时触发，所以周五 00:00 之后任何一次读取（包括只读的页面访问）都会让评估用周四收盘数据完成。这一次目标受回撤刹车约束（25%），换个时点评估结果也一样；但是否应把周评估固定在周五收盘后的某个定时任务里，需要另行评估
- 会话二完成。下一步：会话三（0a-5 V5 自检拆分、0a-6 审计页 A 区）
