# JCS 定位决策：宏观环境读数（2026-11-01）

> 状态：A（定位脱钩与口径修正）、B（信息结构与视觉）已实现，模型版本 `jcs-26.0-macro-env`，历史序列断点 `MODEL_EPOCH = 2026-11-02`。
> 决策方式：用户确认"JCS = 宏观环境读数"；4 个实施选择委托给 Claude 按科学原则决定（见第 3 节）。

## 1. 定位（用户确认，不得推翻）

- JCS 只描述宏观环境（因子方向是否清晰、数据是否完整），**不输出仓位、不涉及下单权限、不使用操作语言**。
- 可以包含 AIAE、ERP、VIX、GOLD 等宏观/背景因子。
- 执行区不得引用 JCS 的分数或等级作为执行依据；执行区唯一仓位数字 = AIAE 执行目标（docs/AIAE_EXECUTION_RULES.md）。

## 2. 审计结论（摘要）

| # | 问题 | 结论 |
|---|---|---|
| 1 | 执行区"中评分"与 JCS"低评分"不一致 | 已确认：`generate_action_plan` 默认分支写死 `confidence:"medium"`；模型参考仓位 = AIAE 上限 × JCS 平滑系数；风控有"JCS<40"硬阻断；多资产有"JCS<40"闸门；路径生成器按 JCS 等级限制加仓 |
| 2 | MR 是策略信号却在 JCS 计权 17.5% | 已确认，并进入核心共识与 2 条冲突规则 |
| 3 | 分级与脚注含操作语言 | 已确认（"观望"、"评分达标不代表可下单"、"冷配加仓/过热减仓"、冲突建议"保持防御/降低仓位"） |
| 4 | 方向网格放在决策卡内 | 已确认；网格与冲突列表是 JCS 输入，应归入 JCS 一侧 |
| 5 | 执行区 4 个仓位数字；回撤刹车 25% 与"降至 63%"矛盾 | 已确认：决策中枢读 AIAE 矩阵上限 63，而有效上限 = AIAE ∧ 市场刹车 ∧ 波动预算 ∧ 回撤刹车；执行层目标只在 `/portfolio/vol-budget` 输出 |
| 5a | 回撤刹车减仓豁免失效 | 已确认：规则只认 `sell/reduce`，上游传 `decrease` |
| 6 | VIX 待核验仍计入中性/距离分/冲突 | 已确认；根因是上游 VIX 卡片无观测日期（推测，需看实时数据） |
| 7 | BOND 已中性化仍计 5% 覆盖与中性 | 已确认 |

## 3. 委托决策与理由

1. **MR 移出 JCS，剩余权重按 V25.3 原权重等比例归一**（AIAE/ERP/VIX/GOLD = .325/.225/.175/.05 ÷ .775 ≈ 41.9/29.0/22.6/6.5%）。
   理由：结构性移出不是数据缺失，"缺失不重新分配"规则不适用；等比例归一不引入新的主观权重。
2. **BOND 移出 JCS**（读数保留在页面，作背景）。
   理由：方向已固定中性，继续计权只会机械抬高"中性"占比与数据健康，不携带信息。此项修订了同日"数据健康计分不变"的做法。
3. **基础分"单因子全一致"跳变：本轮不改公式，只披露**。
   理由：改公式等于换模型，应走预注册；JCS 已不进入执行，跳变只影响读数解读。"全一致"计分改为按参与因子数等比例（4 个因子全有方向且一致 = 60），与原 6 维的设计意图一致。
4. **方向网格与冲突列表移到 JCS 一侧**；右侧只保留执行（执行目标、分区、约束原因、风控、权限）。
5. **分级名称用"清晰 / 一般 / 模糊"，不用"偏强/偏弱"**。
   理由：JCS 衡量的是因子一致性与数据完整度，一致看空也会得高分；"偏强/偏弱"容易被读成多空强弱。

## 4. 改前 / 改后（同一快照：AIAE R3、ERP 65、VIX 19.4 无观测日期、MR BEAR、GOLD 缺失、BOND +6）

| 项目 | 改前 (jcs-25.3.2) | 改后 (jcs-26.0) | 差异原因 |
|---|---|---|---|
| JCS | 27.1 低评分 | 51.7 一般 | 见下三行 |
| 基础分 | 11.6 / 60（ERP 看多 vs MR 看空 → 混合分支） | 37.5 / 60（只剩 ERP 有方向 → "全一致"分支 30 + 1×30/4） | MR 移出；主要来自单因子跳变（第 3 节第 3 条） |
| 数据健康 | 15.5（覆盖 77.5%） | 14.2（覆盖 71.0%） | BOND 移出、VIX 待核验不计、权重归一 |
| 距离加分 | +0.56（VIX 19.4） | 0 | VIX 待核验按未知 |
| 方向分布 | 多 22.5 / 空 17.5 / 中 55 / 未知 5 | 多 29.0 / 空 0 / 中 41.9 / 未知 29.0 | MR、BOND 移出；VIX 由"中性"改为"未知" |
| 执行状态 | 风险阻断 | 风险阻断（不变） | 阻断规则（主题集中度、仓位超限）均与 JCS 无关 |
| 执行区仓位数字 | 模型参考 38%、硬上限 63%、刹车 25%、当前 96% | 执行目标 25%（当前 96.3%，高于目标 71.3pp），约束原因"组合回撤刹车" | 改用执行层的有效上限；38% 原为 63×JCS 系数 |
| 回撤刹车阻断 | 阻断（减仓也被判阻断） | 减仓方向不再阻断；刹车 25% 作为执行目标的约束原因展示 | 修复 `decrease` 词表 |

分数从"低"变为"一般"**不代表宏观环境变好**，主要是 MR 移出后只剩一个有方向的因子所致。

## 5. 改动清单（A）

- `dashboard_modules/decision/jcs.py`：宏观 4 因子；待核验因子按未知；MR/BOND 标记 excluded；`role=macro_environment_reading`、`used_for_execution=False`；分级标签；`MODEL_EPOCH`。
- `dashboard_modules/decision/quality.py`：`CORE_ENGINES=(aiae, erp, vix)`；`EXCLUDED_ENGINES`；`macro_snapshot()`。
- `dashboard_modules/decision/conflicts.py`：移除 2 条 MR 规则；缺失/待核验读数不触发；文案改为环境描述。
- `dashboard_modules/decision/action_plan.py`：执行候选只来自 AIAE 执行层（分区、目标、约束列表）。
- `dashboard_modules/decision/controls.py`：`resolve_action_plan(snapshot, candidate, compliance, mode)`，不读 JCS；时效只核验 AIAE；输出 `execution_target` 唯一仓位数字，删除 `model_position_target/position_cap`；契约 `decision-controls-v2`。
- `dashboard_modules/decision_engine.py`：中枢复用执行层；风控上下文不含 JCS；冲突用宏观口径。
- `services/aiae_execution.py`：`current_view_and_execution()`（与 `/portfolio/vol-budget` 共用）；`routers/portfolio.py` 改为调用它。
- `engines/compliance_engine.py`：删除 JCS 门槛（10→9 条）；回撤刹车识别 `decrease`；仓位超限不再给第二个目标/节奏。
- `engines/multi_asset_engine.py` / `services/multi_asset_policy.py`：删除 JCS 闸门；权益方向改用固定权重（含 MR），v2.3；`routers/decision.py` 缓存键 v4、参数对比改用生产公式。
- `position_path.py`、`alert_monitor.py`、`drift_monitor.py`（只用新版本记录）、`narrative_engine.py`、`jcs_accuracy.py`（评价版本 v2）：去除 JCS 执行含义。
- 前端：`decision.html` 左右栏重组；`hub_core.js` 执行区只显示执行目标；方向网格只含宏观因子并注明未计入项；`global_analytics.js` 脚注；`multi_asset.js` 文案；新增 `static/css/jcs_macro.css`（布局）。
- 测试：更新 7 个 Python、2 个 JS 测试；新增"执行结论与 JCS 无关"（3 组宏观读数）、"无规则 / 单条 / 多条触发只出现一个仓位数字"、"执行层失败不替代数字"、"BOND 移出"、"JCS 不作多资产闸门"等用例。

## 6. 未解决 / 待办

- VIX 观测日期缺失的根因在宏观数据源（`fetch_macro` 的 VIX 卡片），需另开一项。
- JCS V26.0 无样本外验证；历史 JCS 序列在 2026-11-02 断点，漂移监控只用断点后记录。
- 日报 (`report_generator.py`) 仍用"JCS 置信度"措辞，属报告模块，未在本轮修改。
- 信息结构与视觉（第 8–15 条）已在 B 部分完成（见实施日志）；页面其他卡片仍使用旧 glass-decision 毛玻璃样式，未在本轮统一。
- 同页其他模块（AIAE 仓位管控、分批路径、AI 叙事、全球温度）仍有 emoji，不属 JCS 模块。
