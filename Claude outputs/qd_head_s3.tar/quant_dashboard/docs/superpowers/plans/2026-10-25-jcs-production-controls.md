# JCS production controls — 2026-10-25

Scope: repair the decision hub and its manual execution-record boundary. Preserve
the existing personal_analysis mode and all pre-existing multi-asset changes.
No broker submission, deployment, portfolio mutation, or live validation writes.

1. Reproduce contradictory position guidance, missing-signal health inflation,
   and compliance exceptions passing hard checks with isolated regression tests.
2. Make the server resolve strategy, data, risk, validation and permissions into
   one final action contract. Actual position is not the model suggestion.
3. Publish six-engine coverage, explicit unknown states, score contributions,
   version and non-probability semantics. Keep the existing signal model;
   do not promote its shadow model without historical evidence.
4. Separate observation time from cache refresh time and expose decay assumptions.
5. Bind historical validation to the exact model fingerprint. Missing or invalid
   evidence cannot authorize orders. Exercise the local mathematical properties;
   report statistical evidence as insufficient if no eligible replay exists.
6. Verify manual order-record input, replay and fill behavior using temporary
   SQLite databases. Existing record endpoints are not a brokerage gateway.
7. Run focused Python and JavaScript behavioral tests, relevant regressions and
   diff checks. Deliver the validation results and remaining external gates.

Rollback: revert only the files/hunks introduced by this task; leave the initial
dirty working tree intact. No runtime configuration is switched to legacy.
