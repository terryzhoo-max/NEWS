# AIAE 仓位管控优化计划

> 起始日期: 2026-10-30 · 原则: 先修数据, 再改模型; 一次会话一个阶段

## 诊断摘要 (2026-10-30)

| # | 问题 | 阶段 |
|---|---|---|
| 1 | 仓位矩阵用原始 ERP (6.09%), 未用 v4 利率正常化值 (5.24%), 低利率下结构性偏多约 5pp | P0 ✅ |
| 2 | 基金仓位无护栏: 10-29 同花顺返回 60.0 (前值 82.23) 被直接采纳, AIAE_V1 一夜 22.4→19.7 | P0 ✅ |
| 3 | 月度历史混用口径: 2026-03~05 为 V1 估算回填 (22.1~22.3, R2), 06 起为 AIAE_简 (25~27, R3); 08 缺失 | P0 ✅ (脚本待本机执行) |
| 4 | 展示与逻辑不一致: REGIMES 文案、"每周减5%/3天清仓"未实现 | P1 |
| 5 | ERP 重复计入 3~4 处 (矩阵行 / run-all 权重 / ERP 子策略 / ERP v4 自身), 且与 AIAE 同受价格驱动 | P1 |
| 6 | 样本内调参: 137 个月 ≈ 2 个周期, V5 Sharpe 0.33 ≈ t 值 1.1, 不显著 | P2 |
| 7 | 结构性漂移: 注册制扩容 + M2/GDP 上升; 总市值含大量非流通股 | P2 |
| 8 | 输出是名义仓位, 未换算持仓 β (只适用于沪深300 类大盘仓位) | P1 |

## P0 实施记录 (2026-10-30)

改动:
- `engines/aiae_engine.py`
  - `_get_erp_value()` 改为 v4 口径 ERP_adj = E/P − max(10Y, 2.5%); 优先取引擎快照 `allocation_v4.erp_adj`,
    其次用快照 E/P 与 10Y 现算, 最后才用原始值并告警 `erp_basis_unadjusted`。
    缓存 `aiae_erp_latest.json` 增加 `erp_raw` / `basis` 字段; 报告 `position` 增加 `erp_raw` / `erp_basis`。
  - 基金仓位护栏: 区间 [65, 98]; 自动来源单次变化 > 5pt 拒收 (人工录入只查区间);
    加载时文件当前值越界 → 回退到 history 中最近一条合格值 (只读, 不改写文件)。
  - 月度历史 JSON 条目增加 `basis` 字段, 标明 `aiae_v1` 字段实际存的口径。
- `engines/aiae_params.py`: 新增 `FUND_POS_VALID_MIN/MAX`、`FUND_POS_MAX_AUTO_JUMP`。
- `services/aiae_scheduler.py`: 护栏统一交给引擎; 被拒收时返回 `status=rejected` 而不是 `success`。
- `_dev_tools/rebuild_aiae_monthly.py`: 用月末真实数据 (daily_basic 总市值 / 当时已公布 M2) 重算被污染或缺失的月份;
  只接受实测数据, 任一为估算值即跳过; 默认只预览, `--apply` 前自动备份 SQLite 与 JSON。
- `tests/test_aiae_p0_data_fixes.py`: 14 个回归用例。

当日效果 (2026-10-30 数据):
- 矩阵行 erp_gt6 → erp_4_6, AIAE 仓位上限 69% → 64% (ERP v4 独立目标 65%)
- 基金仓位 60.0 → 回退 82.23 (10-28), AIAE_V1 19.59 → 22.16

验证: 新增 14 例 + 既有 test_aiae_engine / test_aiae_scientific_validation / test_erp_allocation_v4 /
test_erp_v4_forward_log 共 114 例, 改动前后均通过 (离线环境, tushare 打桩)。
test_aiae_health_safety / test_aiae_warmup_context 依赖完整项目, 需在本机运行。

待办 (本机执行):
1. `python -m pytest tests/test_aiae_p0_data_fixes.py tests/test_aiae_health_safety.py tests/test_aiae_warmup_context.py`
2. `python _dev_tools/rebuild_aiae_monthly.py` 预览 → 核对 → `--apply`
3. 重启服务, 确认看板 ERP 显示 5.24% (原始 6.09%)、仓位上限 64%

P0 本机验证 (2026-10-30): 32 例本机测试通过; 月度历史已按月末实测重建 (03 26.0 / 04 27.11 / 05 27.2 / 08 27.02,
全部 R3, 6 月"R2→R3"确认为口径切换假信号); 重启后 ERP 缓存为 v4_adj 5.24%, 基金仓位 82.23%。
同花顺接口复核: 该序列一年内约 17 次跳到 51~61% 并在 1~3 天内恢复 (对方数据错误), 护栏 10-30 07:42 已拦截。
可选改进: 从 fundPosList 中取最近一个通过护栏的点; 标记 06-15/06-16 两条历史错误值。

## P1-a 实施记录 (2026-10-30): β 调整后敞口 (只读读数)

- 新增 `services/aiae_beta_exposure.py`: 纯函数 `build_beta_exposure(portfolio, aiae_ctx)`
  - 有效 β 敞口 = Σ 持仓权重(占总资产) × β_沪深300; β 复用 `portfolio_vol` (250 日回归, 行情不足用同类中位数)
  - β 预算 = AIAE 矩阵上限 (base_cap, 不含市场刹车); 差额分档与 `portfolio_vol._verdict` 一致 (±5 / 10pp)
  - `binding=False`: 不改变决策页有效上限与结论, 不生成交易指令; AIAE 锁定或无持仓时 fail-closed (status=insufficient)
  - 组合 β < 1 时折算出的名义仓位可能高于上限, 但上限本身不放宽
- `routers/aiae.py`: 新增 `GET /api/v1/aiae/beta_exposure` (与 /aiae/report 共用 SWR 缓存; 组合风险用 compute_from_store 指纹缓存)
- `static/js/strategy_aiae.js`: 「关键偏差指标」下方新增「β 调整后敞口」卡片, 独立加载不阻塞其他卡片; `strategy.html` 脚本版本 203→204
- `tests/test_aiae_beta_exposure.py`: 14 例

观察期: 先记录读数, 积累 4~8 周后再决定是否把 β 敞口纳入 `build_decision_view` 的约束 (届时需要先写明规则再启用)。

P1-a 本机读数 (2026-10-30): 名义 96% × 组合 β 2.03 = 有效 β 敞口 195%, 预算 64%, 差额 +130pp。
同日组合波动预算: 结构波动 45.4%, 目标 30% → 最大权益仓位 66%; 有效下注数 1.41, 平均相关 0.60。

## 框架选择 (2026-10-30 决定)

约束口径维持「AIAE 名义上限 ∧ 组合波动预算 (30%)」取最严 (现行瀑布); β 敞口只作诊断读数, 不作为约束。
理由: β 预算把按宽基标定的上限再按 β 折算, 与投资者确认的 30% 波动偏好不一致 (相当于约 11% 波动),
且只计系统性风险、不计集中度; 波动预算用完整协方差, 已同时反映 β、相关与集中度。

## P1-b 实施记录 (2026-10-30): ERP 去重复计数

> **2026-10-30 10:35 修正 (部分回退)**: 关闭开关推翻了投资者当日已做的决定 —— 首页市场温度与 AIAE 策略权重的
> ERP 评分改用 v4 分档仓位 (tests/test_market_temp_erp_v4.py 锁定), 导致该测试 5 例失败、CI #26–#30 失败。
> 已恢复 `RUN_ALL_ERP_TIER_ENABLED = True`; 只保留真正的修正: run-all 路由的 ERP 评分由旧综合分改为 v4 分档
> (响应新增 `erp_score_source`)。"ERP 在 AIAE 矩阵行与权重分档中是否重复计数"转入 P3, 由投资者决定。
> 教训: 改动共享参数前先全量跑测试 (`python -m pytest tests/`), 并检查当日其他会话的决定。

- `aiae_params.RUN_ALL_ERP_TIER_ENABLED = False`: run-all 联合权重一律取 neutral 行, 仓位地板不再按 ERP ±5/−10 调整
  (原来按 ERP 旧综合分选行, 该分数在 Step3 验证中无预测力; ERP 已通过 v4 正常化值决定 AIAE 矩阵行)
- `get_run_all_weights(..., use_erp_tier=None)`: None 读开关; 显式 True 可恢复旧行为 (单测保留)
- `routers/strategy.py`: AIAE 策略响应新增 `erp_tier_mode` (`disabled_dedup` / `erp_score`), 避免把 neutral 误读为 ERP 观点
- 未改: 子策略里的「ERP 择时」配额 (它是一个独立策略 sleeve, 不是仓位上限的再加权), 留待 P2 评估

## P1-c 实施记录 (2026-10-30): 执行层

见 docs/AIAE_EXECUTION_RULES.md §7。P1 全部完成; 12 周后按 §4 评估执行层。

## P2-1 实施记录 (2026-10-30): 基金仓位抓取改进

- `services/aiae_scheduler.py`: 同花顺接口返回整段日频序列; 新增 `pick_latest_valid()` 对比当前值更新的点按日期逐点过护栏
  (与上一个已接受值比较, 链式), 采用最后一个合格点; 漏跑多日时按日期依次写入中间合格点; 被拒的点连同原始值写日志,
  全部不合格时返回 status=rejected 及 skipped 明细
- `engines/aiae_engine.py`: 加载回退时跳过 history 中标记 invalid 的点
- `data_lake/aiae_fund_position.json` (本机数据, 不入 git): 当前值 60.0 → 82.23 (10-28), 原值记在 rejected_value;
  history 中 5 条标记 invalid 并注明原因: 06-15 57.07 / 06-16 56.96 / 10-29 60.0 (同花顺异常点),
  10-16 96.7 (乐咕口径), 05-15 95.67 (疑似乐咕口径); 原记录不删除
- `tests/test_aiae_fund_position_series.py`: 9 例 (用 10 月实测序列)

## P2-2 (2026-10-30): AIAE v6 研究 · 已预登记, 待本机运行

- 预登记: docs/AIAE_V6_PREREGISTRATION.md (候选 V6-A 扩展分位阈值 / V6-B 零参数等权加性; 判定规则事先写定)
- 脚本: strategies/aiae_v6_research.py (只读) → docs/AIAE_V6_RESEARCH_RESULTS.md + data_lake/aiae_v6_research.json
- 测试: tests/test_aiae_v6_research.py 9 例 (V5 复现与线上引擎逐点一致、无后视、收益时点、判定规则)

### P2-2 结果与决定 (2026-10-30, 本机运行; 信号数据已更新至 2026-10, 评估 2017-02 ~ 2026-10, 117 个月)

| 方案 | Sharpe | 最大回撤 | Calmar | 年化换手 | 平均仓位 | P(优于V5) |
|---|---|---|---|---|---|---|
| V5 | 0.343 | −18.3% | 0.179 | 0.648 | 55% | — |
| V6-A | 0.320 | −17.5% | 0.166 | 0.722 | 50% | 0.182 |
| V6-B | 0.298 | −18.4% | 0.145 | 0.651 | 50% | 0.144 |
| ERP-only | 0.252 | −25.6% | 0.098 | 0.549 | 63% | 0.115 |
| AIAE-only | 0.357 | −14.3% | 0.194 | 0.739 | 36% | — |

- R1 (预登记规则): V6-A 与 V6-B 均不劣于 V5, 按 Calmar 选 **V6-A → 替换 V5**。V5 的 Sharpe 优势稳定但仅约 0.02,
  与其样本内阈值的后视优势量级相当; V6-A 无后视, 不会因结构漂移失效。118 个月中仅 26 个月两者仓位相差 ≥10pp。
- R2: AIAE 相对 ERP-only 有可测增量。
- 非预登记观察 (不据此决策): AIAE-only 风险调整表现最好, 加入原始 ERP 未改善。作为下一项研究的假设,
  须单独预登记 (并改用 v4 正常化 ERP) 后再检验。
- 下一步 P2-3: 线上实现 V6-A (扩展分位阈值, 读月度历史), 参数冻结 + 哈希 + 前向记录; V5 保留为对照读数 12 周。

## P2-3 实施记录 (2026-10-30): 线上 V6-A + V5 对照

- `engines/aiae_params.py`: V6_ENABLED / V6_PARAMS (v6a-1.0: P10/30/70/90, ≥36 个月, 迟滞 0.5, 缓冲上限 0.8) + V6_PARAM_HASH
  853b2436c2a969e5; `get_live_cn_thresholds()` 只读当月阈值文件; VERSION 5.2 → 6.0
- `engines/aiae_engine.py`:
  - `v6_thresholds_from_values()` 纯函数, 与研究脚本同一算法 (单测逐点核对)
  - 月末历史: aiae_true_history.parquet 优先, 其后月份用 SQLite 月度行补齐 (只取月末重建 / 实测行), 当月排除; 每日缓存
  - 分档与矩阵插值改用当月阈值; 机制 (迟滞 / 矩阵 / ERP 分行) 不变; 不可用时回退 V5 并告警 `v6_fallback_v5`
  - 报告新增 `current.v6` (阈值、缓冲、历史区间、哈希) 与 `current.v5_shadow` (V5 档位与仓位, 不参与决策)
  - 前向记录 data_lake/aiae_v6_forward_log.csv (每交易日一行, V6 vs V5); 阈值文件 data_lake/aiae_v6_thresholds.json
- 消费方: `services/aiae_normalizer.py` (跨市场温度) 与 `engines/drift_monitor.py` 改读当月阈值; 首页 / 决策页 / 前端本就读报告的 regime_thresholds
- 测试: `tests/test_aiae_v6_live.py` 9 例; `test_v5_report_payload_alignment` 显式关闭 V6 (该用例专测 V5)
- 运维 (2026-10-30 自动化): 服务每月 1 日 03:00 (北京时间) 自动执行 `refresh_last_completed_month()` —
  重建上一个完整月份并补齐缺口; 新数据含降级值或构建失败时保留原记录。手动等价命令:
  `python engines/aiae_data_builder.py --refresh-last`。命令行默认截止月改为上一个完整月份 (避免写入不完整的当月)
- 测试: `tests/test_decision_journal.py` 的"今天"改为调用时按北京时间取, 修复跨北京午夜的偶发失败
- 12 周后 (约 2027-01-22) 用 aiae_v6_forward_log.csv 复核 V6 与 V5 的分歧次数与方向

## 实盘监控面板 P0 实施记录 (2026-10-31): 修正错误数字

- 决策桌规模: 原取下拉框情景规模 (默认 5000 万 → 显示 1645 万, 为真实总资产 12.6 倍) → 改为 真实总资产 × (实际 − 执行目标),
  10-30 持仓: 95.9% → 25%, 需卖出约 92.6 万; 下拉框删除
- 成本模型: 原 `0.1×√(参与率)` (隐含日波动 10%) + 固定 ADV 25 亿 → 新增 `services/trade_cost.py`:
  显性 = 佣金 (万 2.5, 每笔最低 5 元) + 印花税 0.05% (仅股票卖出) + 过户费 0.001% (仅股票);
  隐性 = 半价差 (0.5 tick/价格) + 0.7×σ日×√(日成交额/ADV20); 行情缺失时隐性记为未知并提示, 不臆造
  10-30 持仓显性成本约 557 元 (6 bps); 原面板显示 135,905 元
- 偏差主口径: 实际 − 执行层目标 (分区同执行规则: >10 降仓 / 5–10 暂停 / ≤−15 可加仓), 并列 AIAE 建议 / 有效上限 / 执行目标;
  健康度评分仍按 AIAE 建议 (P1 改为限额监控, 规则草案见 docs/AIAE_MONITOR_LIMITS.md, 待确认)
- 后端 TCA (`engines/slippage_engine.py`): 印花税 0.1% → 0.05% 且基金/ETF 免征 (2023-08-28 起); 过户费 0.002% → 0.001% (2022-04-29 起)
- 测试: tests/test_trade_cost.py (费用 / 冲击公式 / 缺数据 / 等比分摊 / 执行层分区)

## 实盘监控面板 P1 实施记录 (2026-10-31): 健康度 → 限额监控

- 规则: docs/AIAE_MONITOR_LIMITS.md (limits-1.0)。L1 仓位−执行目标 / L2 单票 / L3 主题 (复用决策页规则) / L5 持仓新鲜度 计入等级;
  L4 β 观察。任一红 → D, 有黄 → C, 无数据项 → 最高 B; 不再加权平均 (越限不可被抵消)
- 质量分 (仪表盘, 仅参考): 分散度 N_eff / 主题分散 / 执行纪律 / 数据质量; 删除配额对齐 (按持仓只数) 与 ETF 占比计分, 无数据不给默认分
- 面板: 「六维评分雷达」→「限额监控」红黄绿列表; β 卡片加载后填入 L4 行
- 兼容: health_score 仍含 score/grade/breakdown (breakdown 键改为质量分项); aiae_engine 报告的 deviation_health 同步为新结构
- 测试: tests/test_aiae_monitor_limits.py (12 项); test_position_deviation_freshness 两处断言改为新口径

## 待办与决定 (2026-10-30 11:16)

| 待办 | 决定 | 时间 |
|---|---|---|
| 决策日志测试跨北京午夜偶发失败 | 已修复 (调用时取北京日期) | 2026-10-30 推送 |
| P3: ERP 在 AIAE 矩阵与权重中的角色 / "只用 AIAE"观察 | 批准做一项预登记研究: AIAE-only vs V6-A×v4 正常化 ERP 矩阵 (现行) vs v4 ERP-only; 沿用"不劣"判定 (Sharpe ≥ 现行−0.05, 回撤不差 2pp 以上, 换手 ≤1.2 倍); 不劣才考虑把 ERP 移出矩阵, 否则维持现状并存档 | 约 2026-12-11 (V6-A 上线第 6 周) |
| 阿里云服务器迁移到新 git 历史 | ✅ 2026-10-30 核实: 服务器早已在新历史 (0ca94c0 起, SSH 部署密钥 github-alphacore), update.sh 可直接使用。当日部署 2dab392 成功 (备份 /root/backups/pre-migration-20261031-0026.tar.gz); 容器内构建月末历史 153 个月、补写月度历史 7 个月; V6-A 阈值与本机一致 | 已完成 |
| V6-A / 执行层 12 周复核 | 用 aiae_v6_forward_log.csv 与 aiae_exec_forward_log.csv | 约 2027-01-22 |

## 服务器部署记录 (2026-10-30)

- 部署: `cd /root/quant_dashboard/quant_dashboard && bash update.sh` (先构建后切换, 健康检查失败自动回滚)
- 首次部署后需在容器内补数据 (data_lake 不入 git, 服务器独立维护):
  `docker exec quant_dashboard_app python engines/aiae_data_builder.py` → `docker exec quant_dashboard_app python _dev_tools/rebuild_aiae_monthly.py [--apply]`
- 已知问题: (1) ✅ 已修 (2026-10-30): V6 阈值"不可用" (None) 不再进当日缓存, 补齐历史后下一次请求即恢复 V6, 无需重启
  (test_aiae_v6_live::test_failed_result_not_cached_success_cached);
  (2) ✅ 已修 (2026-10-30): backup.sh 改用 CODE_DIR=/root/quant_dashboard/quant_dashboard (data_lake / db / .env / compose),
  git 仍在仓库根; 找不到 alphacore.db 时直接报错退出; 用法 `bash /root/quant_dashboard/quant_dashboard/backup.sh`,
  cron 需手动登记 (示例 `30 4 * * * bash /root/quant_dashboard/quant_dashboard/backup.sh >> /root/backups/backup.log 2>&1`);
  (3) docker-compose 把 8000 端口直接映射到公网 (无 HTTPS / 认证代理), 数据含持仓与交易 → 建议限制访问
- 本机与服务器各自运行定时任务, data_lake 状态各自独立 (前向日志、基金仓位等不同步)

## 后续阶段

- **P1**: 去掉 ERP 重复计数 (子策略/run-all 权重不再看 ERP); REGIMES 文案按实际矩阵生成; 执行层复用 ERP v4 规则
  (每周五评估、偏离 ≥15pp 才调仓、降仓立即/加仓分批); 看板接入 β 调整后敞口 (目标 β 预算 / 当前有效敞口 / 差额)。
- **P2**: AIAE v6 —— 扩展窗口分位分档 + 少参数加性打分替代 4×5 矩阵; 流通市值口径影子指标并行记录;
  参照 ERP v4 做参数冻结、预注册与前向日志, 事先写明 12 个月后的评估标准 (对比固定 65% 沪深300)。
