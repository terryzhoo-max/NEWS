# JCS 决策面板修复与有限范围验收

日期：2026-10-25（America/Chicago）。代码分支：`codex/jcs-production-controls`。

本次按“统一最终建议与权限 → 数据及评分口径 → 模型和订单链路验证”实施。
保留现有 personal_analysis 配置及任务开始前的多资产改动。未部署、未连接券商、未发送交易、未修改实际持仓；测试数据库均为临时 SQLite。

**最终行为**

- 服务端以同一次账户估值确定实际敞口、策略候选方向及风控上下文；不再拿模型建议仓位充当实际仓位。
- 最终建议由统一控制函数生成。风险阻断优先，数据或风控不可用时暂停决策；模型参考与获批执行目标分开。
- 当前没有已验收的订单释放通道，因此 create_order、increase、decrease、auto_execute 均为 false。卖出也不默认获得风险减免权限。
- 仓位差额仅描述百分点，不再向“持仓观望”追加独立的加减仓指令。风险被阻断时，分批调仓路径也停止生成。
- 旧缓存、过期缓存和断路器降级撤回旧行动建议，顶层和行动卡权限同时撤销；历史评分明确标识。
- 硬性规则异常、限额不可用、无效持仓权重、VIX 缺失及实际敞口未知均不能被解释为校验通过。

**数据与评分**

- 保留现有主评分方法及 32.5/22.5/17.5/17.5/5/5 配置权重；不提升 V26 影子模型。
- 修复 optional signal 名称与权重键不匹配造成的漏扣分。健康分改为 `max(0, 20 × 有效权重覆盖率 − 2 × 降级项数量)`；这是明确的操作口径，并非经收益验证的新预测模型。
- 黄金、债券缺失且核心数据有效时：有效项 4/6、有效权重 90%、健康分 18/20；缺失权重不重新分配。附件示例的评分相应约为 53.6，而非 55.6。
- ERP 的 0 分保留为有效偏空输入；布尔值、非有限数和越界值归为无效。兼容旧 API 的 directions 仍保留中性占位，新消费端以 signal_states 的状态和 direction=null 区分未知。
- 分别披露看多、看空、中性和未知权重。无冲突只表示已到位输入未触发冲突规则，不表示多引擎共识。
- 输出基础分、健康分、共识分、冲突扣分、完整合成公式、模型版本和分级区间。JCS 明确为非概率启发式评分，不能解释成胜率。
- 原有 ERP、VIX、黄金及债券方向映射继续作为待验证的研究假设；本次不宣称它们是相同预测期限下的独立股票方向信号。

**时间口径**

删除用全局 last_update 刷新四个来源年龄的逻辑，分别传递原始观测时间和接收时间。
日期精度不能变成“0 分钟新鲜”：只有日期时显示日频、日历年龄，分钟年龄与可靠性留空；缺失时区和未来时间同样不能显示新鲜。
半衰期沿用 AIAE 360、ERP 72、VIX 24、MR 48 小时，并明确属于启发式时效折扣。折扣触发复核不代表已经统计证明信号失效。
上游没有提供观测时间的来源继续显示待核验，不用抓取时刻补造观测时间。

**模型验证结果**

离线验证器 `_dev_tools/validate_jcs_production.py` 遍历 8,000 组组合，验证有限性、评分范围、分项复算、分级、方向权重合计和未知状态。
这属于数学与软件属性验证，不证明投资收益、预测准确率或概率校准。

真实本地历史库只读盘点得到旧版决策记录 4 条，日期跨度 2026-06-09 至 2026-10-23；没有绑定修复版指纹的历史证据。不能用旧分数回填并宣称新版已经通过样本外验证。
统计结论为 `insufficient_evidence`，订单准备状态为 false。详见同目录 `jcs-validation-2026-10-25.json`。

新增 append-only 的 decision_evidence 表，保存输入快照、完整评分结果、模型指纹和 UTC 记录时间；同样输入与模型的重复记录不覆盖历史。日终任务会记录新证据，旧数据不被重新标记为新版数据。
验证关联必须同时匹配模型指纹、有效期、审阅人、run_id、实际报告文件及其 SHA-256；一组勾选项不能自行证明验证通过。验证报告也不授予交易权限。

**订单记录链路**

现有 `/slippage/orders` 是本地执行记录接口，不是券商报单网关。本次明确此边界：

- 未提供成交信息的执行意图返回 HTTP 403，禁止借记录接口释放新订单。
- 成交价、数量必须成对提供并通过正数及有限性检查，方向限定 buy/sell；非法请求不写入数据库。
- 已成交登记要求 idempotency_key。完全相同的重试返回同一记录，不同内容复用同一键返回 HTTP 409。
- SQLite 写事务保证同一幂等请求的并发写入只产生一条记录。归因失败不撤销已成功保存的记录，也不将其误报为登记失败。
- 已成交记录不能通过重复 fill 静默改价或改量；完全相同的 fill 为幂等重放。
- 个人分析模式下，直接调用旧 `/portfolio/trade` 也返回 HTTP 403，不改写持仓。legacy 配置本身也不能绕开当前服务端订单权限。
- 页面中的“风险规则通过”不再表示法规合规认证或交易许可。

API 兼容变化：成交登记调用者须提供稳定的 idempotency_key；旧的 pending 指令创建已关闭；已成交记录的冲突修改需要单独的审计更正流程，本次不提供静默覆盖。
新表由现有 init_db 启动建表流程创建；本次没有对真实库执行迁移。

**软件验收与剩余门槛**

回归覆盖风险优先级、实际账户口径、缺失及异常输入、缓存撤回、时间精度、评分复算、API 拒绝路径、SQLite 并发幂等、成交重放和证据存档；同时回归现有多资产、人工计划和投资组合模块。
JavaScript 行为测试覆盖未知信号、参考仓位、评分覆盖率、时间显示及禁止执行的路径。
最终结果：12 个相关 Python 测试文件合计 **274 项通过**；3 组 JavaScript 行为测试通过；新文件完整 Ruff 检查、相关模块语法及未定义变量检查通过；任务文件 diff 空白检查通过。

可复跑命令（项目根目录）：

```powershell
python -m pytest tests/test_jcs_production_controls.py tests/test_jcs_order_contract.py tests/test_decision_engine.py tests/test_decision_scientific_validation.py tests/test_compliance_engine.py tests/test_multi_asset_allocation.py tests/test_multi_asset_api.py tests/test_source_freshness.py tests/test_manual_decisions.py tests/test_portfolio_engine.py tests/test_deployment_readiness.py tests/test_production_check.py -q --tb=short
node tests/test_jcs_frontend.cjs
node tests/test_multi_asset_frontend.cjs
node tests/test_personal_analysis_frontend.cjs
python _dev_tools/validate_jcs_production.py --output docs/audits/jcs-validation-2026-10-25.json
```

以上为相关回归与隔离接口验收，未执行需要网络的全量行情抓取测试，也未完成真实浏览器的像素、读屏与跨设备验收。

尚未通过的生产门槛：当前版本具备时间顺序与历史发布版本约束的样本外回放；成本、滑点、极端行情和预测期限验证；真实账户权限、实时行情、在途订单预占、撤改单及券商回执闭环。
这些证据缺失时，当前实现保持研究与风险复核用途。没有以本地测试替代统计验证或真实交易通道验收。
