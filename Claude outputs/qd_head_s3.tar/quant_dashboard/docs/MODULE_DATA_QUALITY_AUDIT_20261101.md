# 全模块数据质量审计 (2026-11-01)

> 只读审计, 未改代码。由独立审查助手完成, 主会话抽查确认 #1 (缓存键冲突) 与 #3/#10 (策略路由接受 fallback) 属实。#4 (港/日 M2 序列停更) 未联网核实, 修复前需先在 FRED 确认最后观测日。
> 背景: 海外 ERP P0–P4 审计中发现的问题类型 (合成数据 / 估算值过期 / 降级值伪装成信号 / 开关未生效 / 滞后数据 / 缓存键冲突), 在其余 30 个引擎中排查。

## 修复进度

| 项 | 状态 | 说明 |
|---|---|---|
| #1 #2 #25 缓存键冲突 | **已修复并部署 (2026-11-01)** | `services/fred_guard.py`: `fred_get_series` 新增 `start` 参数。缓存起点不够早视为未命中并重新获取; 写缓存时与旧缓存合并 (只会变长); 返回值截取到调用方窗口; 并发去重按 (序列, 起始日) 区分; 覆盖容差随数据频率放宽 (季频/月频不会反复重取)。全部 25 个调用点已补 `start=` (取自各自的 `observation_start`)。测试 `tests/test_fred_guard_window.py`。 |
| #3 #10 策略路由接受降级报告 | **已修复并部署 (2026-11-01)** | `routers/strategy.py`: ERP / AIAE 报告为 fallback, 或 AIAE `decision_locked` 为 True 时, 返回 `status=unavailable` 与空信号列表, run-all 汇总记入 degraded_strategies。测试 `tests/test_strategy_fail_closed.py`。 |
| #4 港/日 M2 序列停更 | **已修复并部署 (2026-11-01)** | FRED `MYAGM2CNM189N` 停于 2019-08、`MYAGM2JPM189N` 停于 2017-02, 本机从未写出 M2 缓存, 港/日 AIAE 一直用硬编码 315 万亿元 / 1,250 兆円。新增 `services/m2_sources.py`: 中国 M2 复用 A 股 AIAE 的 tushare cn_m (2026-09 为 359.6 万亿元), 汇率改用 ECB 参考价缓存 (原写死 7.25, 现约 6.65); 日本 M2 改用日本银行 API (db=MD02, code=MAM1NAM2M2MO, 2026-09 为 1,295.6 兆円)。返回值带 month / source / is_stale (超过 3 个月) / is_fallback。影响估算: 港股 AIAE 约 16.6→15.2 (III 档不变), 日股约 25.6→24.9 (IV 档不变)。港股历史锚点 (2022-10 比值 0.08) 按当期真实 M2 校准, 与新口径一致。测试 `tests/test_m2_sources.py`。 |
| #5 V6 历史含降级月份 | **已修复并部署 (2026-11-01)** | `aiae_engine._v6_monthly_values` 排除市值或 M2 为降级值的月份 (融资降级不影响 AIAE_简, 保留); `aiae_data_builder.build` 不再写入这类月份。本机诊断 (`_dev_tools/check_aiae_v6_history.py`): 154 个月中仅 2026-05 一个月市值降级, 排除后由 SQLite 月度实测行补齐, 样本仍 154 个月, **阈值不变** [21.73, 23.83, 26.25, 28.13] / 缓冲 0.8。审查报告"2014–2016 严重扭曲"不成立: 114 个 medium 月份仅基金仓位为估算, 不影响 AIAE_简。 |
| #7 双项降级未锁定 | **已修复并部署 (2026-11-01)** | `decision_locked = 质量分 <= 50 or 市值/M2 任一为兜底值` (原为 < 50)。正常数据下无影响。测试 `tests/test_aiae_audit_5_7.py`。 |
| #6 #13 海外 AIAE 无质量评分 | **已修复并部署 (2026-11-01)** | 新增 `services/aiae_quality.py` (规则同 A 股: 每项兜底扣 25、过期扣 10; 质量分 ≤ 50 或市值/M2 兜底即锁定)。美股输入: 市值/M2/融资; 日股: 加外资流向; 港股: 市值/M2/南向资金/AH 溢价; ERP 读取失败另扣 25。报告新增 `data_quality_score` / `decision_locked` / `data_warnings`; `/aiae/global` 返回 `locked_regions`。 |
| #8 利率 EMA 随请求次数漂移 | **已修复并部署 (2026-11-01)** | `rates_strategy_engine._smooth_composite` 按数据日推进: 同一数据日多次调用都以前一数据日的平滑值为基准, 结果不变; 换日才推进一次 (状态 ema_anchor / ema_today / ema_date 存入历史文件, 兼容旧 prev_smooth_score)。`quality.usable=False` 时 `decision_locked=True`, signal 标注 locked。 |
| #9 海外 AIAE 月度斜率 | **已修复并部署 (2026-11-01)** | 新增 `services/monthly_value_store.py`: 按自然月保存每月最后读数, 上月值 = 早于当前月份的最近一个月 (兼容旧文件格式)。港股改为从完整历史 JSONL 取上个自然月, 删除 2024-09 快照冷启动兜底 (无上月值时斜率记持平)。测试 `tests/test_audit_6_8_9_13.py`。 |
| #11 红利 TTM 分红保底值 | **已修复并部署 (2026-11-01)** | `dividend_trend_engine`: 接口成功、近 365 天无实施分红但有更早记录时记 0 (真实值); 数据源完全没有该基金分红记录时 (实测 Tushare 无 512890 / 159201 任何记录, 旧代码先用静态表, 改后一度误记为 0) 用静态保底值并标记, 标记随缓存保存; 接口失败也用静态保底值, 标记 `yield_is_fallback`, 不写 24h 磁盘缓存, 1 小时后重试; 股息率为保底值 (含 >15% 异常回退) 时不启用 >6% 股息托底。信号结果新增 `yield_is_fallback`。 |
| #14 动量 VIX 默认 20 | **已修复并部署 (2026-11-01)** | `fetch_vix` 全部失败返回 None (原为 20.0); L2 按 VIX 25-30 档 50% 保守处理, 新增 `layer2_status=unavailable`; 页面显示"— / VIX 不可用 · 按保守档"。测试 `tests/test_audit_11_14.py`。 |
| #15 日内盈亏昨收错位 | **已修复 (2026-11-01, 待部署)** | `portfolio_engine._aligned_prev_close`: 昨收按现价所属日期对齐 (Tushare 价 → 最后一根之前; 券商当日价 → 今天之前的最后一根); 现价为成本价或取不到昨收时该持仓 daily_pnl=null, 不计入合计, 返回 `missing_prev_close` 与 status=partial/unavailable, 不再用成本价顶替。核查发现目前没有页面加载 intraday_pnl.js (仅 `/api/v1/portfolio/intraday-pnl` 接口输出), 实际影响小于审查报告估计。测试 `tests/test_audit_15_intraday.py`。 |
| 其余 | 未处理 | 见下表 |

### 本轮新发现 (2026-11-01)

| # | 严重度 | 位置 | 问题 | 建议 |
|---|---|---|---|---|
| 26 | 中 | `/api/v1/aiae_global/report` global_comparison | 接口按四地平均温度给出"全局权益总仓位"和"X 相对超配优先 / Y 谨慎配置", 与"AIAE 执行目标是唯一仓位数字"的原则冲突 (更正: 国债/海外页海外 AIAE 标签仍展示总仓位条, 2026-11-01 已一并移除, 见 ERP_GLOBAL_OPTIMIZATION_PLAN.md 末节) | **已修复并部署 (2026-11-01)**: global_position 标记 deprecated (字段保留, 向后兼容), 新增 allocation_deprecated; recommendation 改为只陈述相对温度、不给配置方向。测试 `tests/test_aiae_global_deprecated.py` |
| 27 | 中 | aiae_us/jp/hk_engine `_get_*_erp_value` | 海外 AIAE 仓位矩阵读取的是旧估算 ERP (如美股 −1.41), 而不是 ERP v2 (实际利率口径) | 待美股 v2 影子期 (~2027-01-24) 结束后统一切换; 在此之前海外 AIAE 仅背景参考 |

## (a) 问题汇总（按严重度排序）

| # | 严重度 | 位置 | 类 | 用户看到的后果 | 最小修复 |
|---|---|---|---|---|---|
| 1 | 高 | gold_signal_engine.py:103-105（lookback 365 天，:289）vs rates_strategy_engine.py:371-373（5 年） | 6 | DGS10/DFII10 磁盘缓存只按 series_id 区分；黄金引擎先拉数据的话，利率引擎 6 小时内拿到的只有 1 年数据，再写进 rates_dgs10.parquet。页面标着“5年分位/均值/σ”，实际按 1 年算，D1 评分和买卖区间线都不对（span≥183 天的校验能通过）。erp_us/erp_hk 的 DGS10 也会被同样截短 | 缓存键里加上 observation_start；或者统一拉最长窗口、调用方自己截取 |
| 2 | 高 | momentum_rotation_engine.py:263-266（VIXCLS 10 天） vs erp_us_engine.py:333（5 年） | 6 | 实时 VIX 缓存过期时，动量引擎会把只有约 7 行的 VIX 写进共享缓存；美股 ERP 拿到后覆盖 erp_us_vix.parquet，VIX 分位/波动维度用 7 个点算 | 同 #1；动量引擎改用长窗口拉取 |
| 3 | 高 | aiae_engine.py:1949-1961 + routers/strategy.py:337 | 3 | 引擎异常时 `_fallback_report` 返回 Ⅲ档、仓位 55% 的固定值；路由接受 `status=="fallback"`，照常调用 generate_etf_signals，以 `status:"success"` 返回 ETF 买/卖信号，也不检查 decision_locked | 路由遇到 fallback 或 decision_locked 时返回 unavailable，signals 置空 |
| 4 | 高 | aiae_hk_engine.py:569-580；aiae_jp_engine.py:308-339 | 2/5 | MYAGM2CNM189N、MYAGM2JPM189N 是 IMF 的 M2 序列，FRED 上大概率早已停更（需人工确认）。180 天窗口取不到数据，就长期落到旧缓存或硬编码（315 万亿 RMB、1250 兆円，标注 "2026-02"）；港股还写死 7.25 换算（:119 注释说已替换，这里漏改）。结果港/日 AIAE 的分母实际是常数，报告状态却是 success | 换成在更新的 M2 数据源；按观测月份判断新鲜度，过期就标为不可用；换汇用 `_load_usd_cny()` |
| 5 | 中高 | aiae_data_builder.py:486-505、376-389；aiae_engine.py:1305 | 1/3 | 月末历史重建时，取不到的月份用常数补（市值 95 万亿/M2 330/融资 1.85）或按“历史均值”插值，然后写进 aiae_true_history.parquet；V6-A 的实盘分档阈值读这份 aiae_simple 时，不过滤 data_quality=low 的月份，2014-2016 年的值会被严重扭曲 | 降级月份不写入（或写 NaN）；V6 读取时过滤 low 和 is_fallback |
| 6 | 中高 | aiae_us_engine.py:335-345、848-851、785-794 | 2/3 | Wilshire 全部失败时用硬编码 68T 美元（trade_date 写成今天），ERP 失败时用 2.0%；generate_report 不看 is_fallback，照样以 success 输出档位、仓位和交叉验证 | 加数据质量扣分和 decision_locked（与 A 股一致） |
| 7 | 中 | aiae_engine.py:676-683、707-712、769-773、1734 | 2/3 | A 股市值、M2（"202603" 330 万亿）、融资都有硬编码兜底，每项只扣 25 分；两项同时降级是 50 分，而锁定条件是 `< 50`，不会锁，用户看到的是基于两项假数据的“可执行”仓位 | 改成 `<= 50`，或者任意一项 L3 降级就锁定 |
| 8 | 中 | rates_strategy_engine.py:328-337、1297、1321 | 4/3 | EMA 每调用一次 generate_report 就更新一次（SWR 1 小时、warmup、decision 路由都会触发），平滑程度取决于请求次数；ERP 那边同类 EMA 已经关了（O8_ENABLED=False），利率这边没有开关。数据源缺失的维度按 50 分计入，quality.usable=False 时 signal 和 trade_rules 仍然输出 | EMA 按交易日只更新一次（用 last_date 判断）；usable=False 时不出信号 |
| 9 | 中 | aiae_us_engine.py:862-865；aiae_jp_engine.py:745-748；aiae_hk_engine.py:1078-1082 | 4 | 所谓“上月 AIAE”每次调用都被覆盖，月度斜率变成了相邻两次调用的差值，加速信号基本不会触发；港股冷启动时拿 2024-09 的快照 18.5 当前值，会产生虚假的“加速下行” | 按月份存储，只跟上个自然月比 |
| 10 | 中 | erp_timing_engine.py:1100-1105 + routers/strategy.py:269 | 3 | ERP 降级时返回 ERP 4.0%、分位 50%、50 分；策略路由接受 fallback，给整个 ETF 池生成 hold 信号，erp_abs/erp_pct 显示的是假值 | 遇到 fallback 时返回 unavailable |
| 11 | 中 | dividend_trend_engine.py:122-131、194-215、352、403 | 2 | 分红接口失败，或 365 天内没有分红（`v is None`）时，用每份分红的静态表，并写进 24 小时磁盘缓存，像新拉到的数据一样。股息率>6% 会触发 yield_floor，从而压住卖出信号、放行趋势下方的买入 | 降级时打上 is_fallback 标记，不缓存；无分红记 0；降级时关闭 yield_floor |
| 12 | 中 | aiae_jp_engine.py:219-221、286-293 | 2 | 日股市值用 N225÷14.0×0.27 的固定比例估算（topix_index 用的又是 14.3，前后不一致），兜底值 870 兆円的日期写成今天 | 换真实 TOPIX 市值数据；兜底值保留原始日期 |
| 13 | 中 | aiae_hk_engine.py:549-555、979-988、1062-1066 | 3 | 市值兜底 33.6T、ERP 兜底 6.0%（交叉验证可能直接给出“强买入”），南向资金默认 350、AH 溢价默认 135，都不进质量评分 | 同 #6 |
| 14 | 中 | momentum_rotation_engine.py:289-290、370-377 | 3 | VIX 全部取不到时默认 20，L2 仓位上限给到 85%（不限制），页面显示的 layer2_vix=20.0 看起来像真实读数 | 返回 None，L2 按保守档处理并标注“VIX 不可用” |
| 15 | 中低 | portfolio_engine.py:562-573 | 5 | “日内盈亏”的昨收固定取 close[-2]；导入当天用券商价时，相当于跨两天的涨跌；取不到时退回成本价，日盈亏就变成了累计盈亏 | 按 trade_date 对齐昨收；没有就返回 None |
| 16 | 低 | compliance_engine.py:156-158 | 3 | snapshot 里没有 decision_locked 或 regime 时默认 R3 放行，等于缺数据时放行 | 缺字段就阻断 |
| 17 | 低 | brinson_engine.py:51-58、110 | 2 | 基准权重接口失败时用 2025Q4 的静态行业权重，输出里没有标注 | 返回 benchmark_source 字段 |
| 18 | 低 | rates_strategy_engine.py:835-842 | 3 | 10Y 为空时用硬编码分位数（实际上前面会先抛错，基本走不到） | 改为抛错 |
| 19 | 低 | dual_momentum_engine.py:177、465 | 2 | 用 9 个月收益和年化 Shibor 直接比较，没按期限折算；Shibor 取不到时默认 1.5% | 把利率按 189/252 折算；默认值打标记 |
| 20 | 低 | aiae_hk_engine.py:191、960-972 | 2 | 图表的 current 用的是硬编码的 "2026-04-06 当前状态(估)" 14.0 | 改用实时值 |
| 21 | 低 | aiae_us_engine.py:401-406 | 5 | 融资余额用季度 Z.1 序列（BOGZ1FL663067003Q），滞后约一个季度，但当作当前值使用 | 显示观测日期 |
| 22 | 低 | cross_market_alert.py:62-65 | 2/3 | 某市场缺数据时默认 R3；“历史上 45% 传导概率”是没有出处的常数 | 缺数据就跳过该规则；文案改成“经验系数” |
| 23 | 低 | hf_proxy_engine.py:456-475 | 5 | 距 M2 发布的天数按每月 12 号推算，不看实际 M2 月份 | 改读 aiae_m2.json 的 month 字段 |
| 24 | 低 | news_intelligence.py:381 | 5 | 事件日期一律记为今天，不是新闻的原始日期 | 用新闻自带的日期 |
| 25 | 低 | aiae_jp_engine.py:210（NIKKEI225 30 天） vs erp_jp | 6 | 同一 key 的窗口冲突；erp_jp 会累积合并历史，影响较小 | 同 #1 |

## (b) 优先修复的 3 项

1. **fred_guard 缓存键冲突（#1、#2、#25）**：改一处就能修好利率、美股 ERP、港股 ERP 三个引擎的分位窗口，而且这个问题不报错、不留痕迹，“5年分位”的标签让错误的数看起来很可信。
2. **策略路由接受 fallback 报告（#3、#10）**：这是唯一一处把明显的降级假值直接变成 ETF 买/卖清单、还以 `success` 返回的地方，风险最直接。
3. **港/日 M2 序列疑似停更（#4）+ 海外 AIAE 不看 is_fallback（#6、#13）**：一旦确认停更，港/日 AIAE 的档位就长期由常数决定，状态却显示 success。建议先手动查一下这两个序列在 FRED 上的最后观测日。

## (c) 检查过、没发现问题的部分

- aiae_engine 插值种子：已用 is_seed 过滤，不进入斜率计算和图表（:1290、:1395）。
- aiae_engine `_fallback_report` 本身已设 data_quality_score=0、decision_locked=True（问题出在消费方）。
- aiae_engine 读 ERP 时只认 status=="success"，过期缓存会触发后台重算并扣分。
- aiae_params：V5/V6/RUN_ALL_ERP_TIER 开关在 aiae_engine 和路由里都有读取。
- erp_timing_engine：O7/O8/O10/O11/O12/O15 开关都生效；10Y 只做有限 ffill，不再 bfill；D2 分位用滚动尾部窗口。
- gold_signal_engine：有新鲜度判断，数据不可用时主动不出信号，覆盖率不足时 gold_signal=None。
- multi_asset_engine：缓存年龄和 decision_locked 都会拦截。
- mean_reversion_engine：识别 regime 出错时 allow_new_entries=False；ATR 用前复权价。
- dual_momentum_engine：SMA、DUAL_CONFIRM、CORR_DEDUP 开关都生效。
- portfolio_engine.get_nav_history：已明确标注为“当前持仓模拟”口径，不再前向填充收益率。
- slippage_engine：bootstrap 回填的记录不计入统计。
- rebalance_engine、position_deviation_engine：decision_locked 时不出单。
- factor_analyzer：基本面因子用 merge_asof(backward) 按公告日对齐，没有前视。
- audit_engine：random.sample 只用于抽样检查文件，不产生数据。
- industry_engine：is_synthetic=False，日期取自真实数据。
- hf_calibration、factor_trend_engine 里的 mock 数据只在 `__main__` 自测中使用。
- drift_monitor、optimizer_engine：缺 regime 时默认 R3，对应的超额收益观点为 0，不会注入偏向；VIX 默认 20 也只是不压仓（影响低）。
