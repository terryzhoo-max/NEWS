#!/bin/bash
# ============================================================
#  AlphaCore 定时备份脚本 v1.0
#  备份内容: data_lake + Redis + .env + 代码快照
#  保留策略: 最近 30 天
#  
#  用法:
#    手动执行: bash /root/quant_dashboard/quant_dashboard/backup.sh
#    定时执行: 需自行在 crontab 注册, 例如每天 04:30:
#      30 4 * * * bash /root/quant_dashboard/quant_dashboard/backup.sh >> /root/backups/backup.log 2>&1
#
#  2026-10-30 路径修正: 10-27 起应用位于仓库子目录 quant_dashboard/, 数据/主库/.env/compose 都在
#    CODE_DIR 下; 旧脚本仍指向仓库根, 导致 data_lake 备份成仓库根的行情缓存、SQLite 工具路径错误而整体中止。
# ============================================================

set -e

# ── 配置 ──
APP_DIR="/root/quant_dashboard"                 # Git 仓库根
CODE_DIR="${APP_DIR}/quant_dashboard"           # 应用目录 (data_lake / .env / docker-compose.yml)
BACKUP_DIR="/root/backups/quant_dashboard"
KEEP_DAYS="${KEEP_DAYS:-30}"          # 2026-11-03: 允许 crontab 传入 (当前 crontab 为 365); 原写死 30 覆盖了传入值
DATE=$(date +%Y%m%d_%H%M%S)
BACKUP_NAME="alphacore_${DATE}"
BACKUP_PATH="${BACKUP_DIR}/${BACKUP_NAME}"

# ── 路径自检: 找不到主库就失败, 不允许"备份成功但没备到数据" ──
if [ ! -f "${CODE_DIR}/data_lake/db/alphacore.db" ]; then
    echo "❌ 未找到主库 ${CODE_DIR}/data_lake/db/alphacore.db, 路径可能已变化, 中止备份"
    exit 1
fi

# ── 创建备份目录 ──
mkdir -p "${BACKUP_PATH}"

echo ""
echo "╔══════════════════════════════════════════════╗"
echo "║   AlphaCore 备份 · ${DATE}          ║"
echo "╚══════════════════════════════════════════════╝"
echo ""

# ── 1. 备份 data_lake (Parquet 缓存) ──
if [ -d "${CODE_DIR}/data_lake" ]; then
    echo "⏳ [1/4] 备份 data_lake..."
    cp -r "${CODE_DIR}/data_lake" "${BACKUP_PATH}/data_lake"
    # F5: 运行中的 SQLite 直接复制可能不一致; 删除原始副本, 以下方一致性快照为准
    rm -f "${BACKUP_PATH}/data_lake/db/"alphacore.db* "${BACKUP_PATH}/data_lake/"analysis_decisions.db*
    DL_SIZE=$(du -sh "${BACKUP_PATH}/data_lake" | awk '{print $1}')
    echo "✅ data_lake: ${DL_SIZE}"
else
    echo "⚠️  data_lake 目录不存在, 跳过"
fi

# ── 1b. F5: SQLite 一致性快照 + 独立恢复演练 (主库 + 人工决策库) ──
echo "⏳ [1b] SQLite 在线备份与恢复校验..."
if ALPHACORE_DB_DIR="${CODE_DIR}/data_lake/db" python3 "${CODE_DIR}/_dev_tools/db_backup.py" backup --out "${BACKUP_PATH}/sqlite" \
   && python3 "${CODE_DIR}/_dev_tools/db_backup.py" verify --dir "${BACKUP_PATH}/sqlite"; then
    echo "✅ SQLite 快照已通过恢复演练"
else
    echo "❌ SQLite 快照或恢复校验失败, 本次备份标记为失败"
    echo "FAILED" > "${BACKUP_PATH}/SQLITE_BACKUP_FAILED"
    exit 1
fi

# ── 2. 备份 Redis 数据 ──
echo "⏳ [2/4] 备份 Redis..."
if docker ps | grep -q alphacore_redis; then
    # 触发 Redis BGSAVE 确保数据落盘
    docker exec alphacore_redis redis-cli BGSAVE > /dev/null 2>&1
    sleep 2
    # 复制 RDB 快照
    docker cp alphacore_redis:/data/dump.rdb "${BACKUP_PATH}/redis_dump.rdb" 2>/dev/null && \
        echo "✅ Redis RDB 快照已保存" || \
        echo "⚠️  Redis RDB 文件不存在 (可能未触发过持久化)"
    # 复制 AOF 文件
    docker cp alphacore_redis:/data/appendonly.aof "${BACKUP_PATH}/redis_appendonly.aof" 2>/dev/null && \
        echo "✅ Redis AOF 日志已保存" || \
        echo "⚠️  Redis AOF 文件不存在"
else
    echo "⚠️  Redis 容器未运行, 跳过"
fi

# ── 3. 备份关键配置 ──
echo "⏳ [3/4] 备份配置文件..."
cp "${CODE_DIR}/.env" "${BACKUP_PATH}/.env" 2>/dev/null && \
    echo "✅ .env 已保存" || echo "⚠️  .env 不存在"
cp "${CODE_DIR}/docker-compose.yml" "${BACKUP_PATH}/docker-compose.yml"
cp "${CODE_DIR}/Dockerfile" "${BACKUP_PATH}/Dockerfile"

# 记录当前 Git 版本号 (方便追溯)
cd "${APP_DIR}"
git rev-parse HEAD > "${BACKUP_PATH}/git_commit.txt" 2>/dev/null
git log -1 --format="%h %s (%ci)" >> "${BACKUP_PATH}/git_commit.txt" 2>/dev/null
echo "✅ Git commit: $(cat ${BACKUP_PATH}/git_commit.txt | head -1)"

# 记录系统状态快照
docker ps --format "{{.Names}}\t{{.Status}}\t{{.Image}}" > "${BACKUP_PATH}/docker_status.txt"
curl -s http://localhost:8000/health > "${BACKUP_PATH}/health_snapshot.json" 2>/dev/null || echo "{}" > "${BACKUP_PATH}/health_snapshot.json"
echo "✅ 系统状态快照已保存"

# ── 4. 压缩打包 ──
echo "⏳ [4/4] 压缩打包..."
cd "${BACKUP_DIR}"
tar -czf "${BACKUP_NAME}.tar.gz" "${BACKUP_NAME}/"
rm -rf "${BACKUP_PATH}"
ARCHIVE_SIZE=$(du -sh "${BACKUP_NAME}.tar.gz" | awk '{print $1}')
echo "✅ 压缩完成: ${BACKUP_NAME}.tar.gz (${ARCHIVE_SIZE})"

# ── 5. 清理过期备份 ──
echo ""
echo "⏳ 清理 ${KEEP_DAYS} 天前的备份..."
DELETED=$(find "${BACKUP_DIR}" -name "alphacore_*.tar.gz" -mtime +${KEEP_DAYS} -print -delete | wc -l)
if [ "${DELETED}" -gt 0 ]; then
    echo "🗑️  已清理 ${DELETED} 个过期备份"
else
    echo "✅ 无过期备份需清理"
fi

# ── 统计 ──
TOTAL_BACKUPS=$(ls -1 "${BACKUP_DIR}"/alphacore_*.tar.gz 2>/dev/null | wc -l)
TOTAL_SIZE=$(du -sh "${BACKUP_DIR}" | awk '{print $1}')

echo ""
echo "════════════════ 备份完成 ════════════════"
echo "  📦 文件: ${BACKUP_DIR}/${BACKUP_NAME}.tar.gz"
echo "  📊 大小: ${ARCHIVE_SIZE}"
echo "  📁 累计: ${TOTAL_BACKUPS} 个备份, 共 ${TOTAL_SIZE}"
echo "  🕐 保留: 最近 ${KEEP_DAYS} 天"
echo "═══════════════════════════════════════════"
echo ""
