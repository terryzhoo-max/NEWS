// ============================================================
// alphacore_utils.js — AlphaCore 共享工具库 (Phase 2)
// 被 strategy.html + treasury.html 共同引用
// 在 echarts.min.js 之后、页面 JS 之前加载
// ============================================================
(function() {
    'use strict';
    var AC = window.AlphaCore = window.AC = {};

    // ── DOM 工具函数 ──
    AC.setText = function(id, v) {
        var el = document.getElementById(id);
        if (el) el.textContent = v;
    };

    AC.setColor = function(id, c) {
        var el = document.getElementById(id);
        if (el) el.style.color = c;
    };

    AC.setHTML = function(id, html) {
        var el = document.getElementById(id);
        if (el) el.innerHTML = html;
    };

    // ── 实时时钟 ──
    AC.startClock = function(elementId) {
        elementId = elementId || 'st-time';
        function tick() {
            var now = new Date();
            var pad = function(n) { return n.toString().padStart(2, '0'); };
            var el = document.getElementById(elementId);
            if (el) el.textContent = now.getFullYear() + '-' + pad(now.getMonth()+1) + '-' + pad(now.getDate()) + ' ' + pad(now.getHours()) + ':' + pad(now.getMinutes()) + ':' + pad(now.getSeconds());
        }
        tick();
        setInterval(tick, 1000);
    };

    // ── 导航高亮 ──
    AC.initNavigation = function() {
        var navItems = document.querySelectorAll('.nav-item');
        navItems.forEach(function(item) {
            item.addEventListener('click', function(e) {
                var href = item.getAttribute('href');
                if (!href || href === '#') e.preventDefault();
                navItems.forEach(function(nav) { nav.classList.remove('active'); });
                item.classList.add('active');
            });
        });
    };

    // ── Tab 切换系统 ──
    AC.initTabSystem = function(onTabSwitch) {
        var tabs = document.querySelectorAll('.st-tab');
        var reports = document.querySelectorAll('.st-report');
        console.log('[AC] initTabSystem: found', tabs.length, 'tabs,', reports.length, 'reports');
        tabs.forEach(function(tab) {
            tab.addEventListener('click', function() {
                var targetId = tab.dataset.report;
                tabs.forEach(function(t) { t.classList.remove('active'); t.setAttribute('aria-selected', 'false'); });
                reports.forEach(function(r) { r.classList.remove('active'); });
                tab.classList.add('active');
                tab.setAttribute('aria-selected', 'true');
                var target = document.getElementById(targetId);
                if (target) {
                    target.classList.add('active');
                } else {
                    console.error('[AC] Tab target not found:', targetId);
                }
                var dash = document.querySelector('.dashboard');
                if (dash) dash.scrollTo({ top: 0, behavior: 'smooth' });
                if (typeof onTabSwitch === 'function') onTabSwitch(targetId);
            });
        });
    };

    // ── ECharts 统一 Resize 注册中心 ──
    AC._charts = new Set();

    AC.registerChart = function(chartInstance) {
        if (chartInstance) AC._charts.add(chartInstance);
        return chartInstance;
    };

    AC.disposeChart = function(chartInstance) {
        if (chartInstance) {
            AC._charts.delete(chartInstance);
            try { chartInstance.dispose(); } catch(e) {}
        }
        return null;
    };

    // 全局唯一 resize listener（200ms 防抖）
    var _resizeTimer = null;
    window.addEventListener('resize', function() {
        clearTimeout(_resizeTimer);
        _resizeTimer = setTimeout(function() {
            AC._charts.forEach(function(c) {
                try {
                    if (c && typeof c.resize === 'function' && !c.isDisposed()) {
                        c.resize();
                    } else if (c && c.isDisposed && c.isDisposed()) {
                        AC._charts.delete(c);
                    }
                } catch(e) {}
            });
        }, 200);
    });

    // ── 安全通信封装 (Batch 6.1, V17.3: GET免认证) ──
    AC.secureFetch = async function(url, options = {}) {
        const method = (options.method || 'GET').toUpperCase();
        const isReadOnly = (method === 'GET' || method === 'HEAD');

        options.headers = options.headers || {};

        // GET/HEAD 请求免认证 (与后端 auth_middleware 一致)
        // 仅 POST/PUT/DELETE 需要 API Key
        if (!isReadOnly) {
            let apiKey = localStorage.getItem('alphacore_api_key');
            if (!apiKey) {
                apiKey = AC._promptKey("⚠️ 安全拦截：请输入您的系统 API Key (X-API-Key) 以继续该操作：");
                if (apiKey === undefined) {          // 不支持弹窗 (内置浏览器): 用页面底部输入框
                    if (AC.showKeyInput) AC.showKeyInput();
                    const err = new Error("请在页面底部输入访问令牌后重试。");
                    err.isCancelled = true;
                    try { alert(err.message); } catch (e) {}
                    throw err;
                }
                if (!apiKey) {
                    const err = new Error("未提供验证凭据，操作已取消。");
                    err.isCancelled = true;
                    alert(err.message);
                    throw err;
                }
                localStorage.setItem('alphacore_api_key', apiKey);
            }
            options.headers['X-API-Key'] = apiKey;
        }

        if (options.body && typeof options.body === 'string' && !options.headers['Content-Type']) {
            options.headers['Content-Type'] = 'application/json';
        }

        const res = await fetch(url, options);

        if (res.status === 401 || res.status === 403) {
            // 2026-11-04: 只有认证中间件的拒绝 (401, 或 403 且 status=forbidden/unauthorized) 才清除令牌;
            // 接口自身的业务拒绝 (如非权威环境 NON_AUTHORITATIVE、清零停用) 原样返回, 由调用方按 detail 显示
            let bodyJson = null;
            try { bodyJson = await res.clone().json(); } catch (e) {}
            const authFailure = res.status === 401 ||
                (bodyJson && (bodyJson.status === 'forbidden' || bodyJson.status === 'unauthorized'));
            if (!authFailure) return res;
            // 2026-11-04 读取鉴权: 读取的认证失败由 fetch 包装统一处理 (每页只弹一次输入框), 这里原样返回
            if (isReadOnly) return res;
            localStorage.removeItem('alphacore_api_key');
            let errMsg = "API Key 无效或已过期，请重新操作。";
            try {
                const errJson = await res.json();
                if (errJson.message) errMsg = errJson.message;
            } catch (e) {}
            alert("🔒 安全拦截: " + errMsg);
            const err = new Error(errMsg);
            err.status = res.status;
            throw err;
        }

        // R5: Pydantic 422 验证错误 — 解析 {detail: [{loc, msg, type}]} 格式
        if (res.status === 422) {
            let errMsg = "请求参数验证失败";
            try {
                const errJson = await res.json();
                if (errJson.detail && Array.isArray(errJson.detail)) {
                    const msgs = errJson.detail.map(d => {
                        const field = (d.loc || []).slice(1).join('.');
                        return field ? `${field}: ${d.msg}` : d.msg;
                    });
                    errMsg = "参数验证失败:\n" + msgs.join("\n");
                }
            } catch (e) {}
            alert("⚠️ " + errMsg);
            const err = new Error(errMsg);
            err.status = 422;
            err.isValidation = true;
            throw err;
        }

        return res;
    };

    // ── 读取鉴权 (2026-11-04, docs/ACCOUNT_AUTHORITY_AND_RISK_REFRESH_PLAN.md 1.4 续) ──
    // 后端 /api/ 读取也要 X-API-Key (与写入同一个令牌, 存 localStorage alphacore_api_key, 按网址分开存:
    // localhost:8000 与 localhost:18000 各输一次)。包装 window.fetch: 同源 /api/ 请求自动带令牌
    // (调用方已带的不覆盖; 跨域请求不带)。读取遇到认证失败 (401, 或 403 且 status=forbidden/unauthorized):
    // 403 先清除旧令牌; 每个页面只弹一次输入框, 输入后刷新页面; 取消则显示提示条, 不再反复弹窗。
    AC.API_KEY_STORAGE = 'alphacore_api_key';
    AC.READ_AUTH_PROMPT = '🔒 读取数据需要访问令牌 (X-API-Key)。\n请输入本网址对应的令牌 (服务器 18000 与本机 8000 不同)：';
    AC.READ_AUTH_HINT = '🔒 数据接口需要访问令牌，页面数据未加载。';
    var _nativeFetch = window.fetch;
    var _readAuthPrompted = false;      // 已弹过输入框 (每页一次)
    var _readAuthScheduled = false;     // 已安排弹窗 (并发失败的请求只安排一次)

    function _getKey() {
        try { return localStorage.getItem(AC.API_KEY_STORAGE) || ''; } catch (e) { return ''; }
    }

    function _sameOriginApi(url) {
        try {
            var base = (window.location && window.location.href) || 'http://localhost/';
            var u = new URL(url, base);
            var origin = (window.location && window.location.origin) || new URL(base).origin;
            return u.origin === origin && u.pathname.indexOf('/api/') === 0;
        } catch (e) { return false; }
    }

    function _hasHeader(headers, name) {
        if (!headers) return false;
        if (typeof headers.has === 'function') return headers.has(name);
        var lower = name.toLowerCase();
        if (Array.isArray(headers)) return headers.some(function(h) { return h && String(h[0]).toLowerCase() === lower; });
        return Object.keys(headers).some(function(k) { return k.toLowerCase() === lower; });
    }

    function _withKey(headers, key) {
        if (headers && typeof headers.set === 'function') { headers.set('X-API-Key', key); return headers; }
        if (Array.isArray(headers)) return headers.concat([['X-API-Key', key]]);
        var out = {};
        Object.keys(headers || {}).forEach(function(k) { out[k] = headers[k]; });
        out['X-API-Key'] = key;
        return out;
    }

    // 2026-11-04: 内置浏览器等环境不支持 prompt() (直接抛错) → 页面底部提示条自带输入框, 不依赖弹窗
    AC._promptKey = function(msg) {
        try { return prompt(msg); } catch (e) { return undefined; }    // undefined = 不支持弹窗
    };

    function _saveKeyAndReload(key) {
        key = key ? String(key).trim() : '';
        if (!key) return false;
        try { localStorage.setItem(AC.API_KEY_STORAGE, key); } catch (e) {}
        try { window.location.reload(); } catch (e) {}
        return true;
    }

    function _showReadAuthHint() {
        try {
            if (!document.body || document.getElementById('ac-read-auth-hint')) return;
            var bar = document.createElement('div');
            bar.id = 'ac-read-auth-hint';
            bar.setAttribute('role', 'alert');
            bar.style.cssText = 'position:fixed;left:0;right:0;bottom:0;z-index:99999;padding:10px 16px;flex-wrap:wrap;' +
                'background:#3b1d2e;color:#fde2ef;font-size:13px;display:flex;gap:12px;align-items:center;justify-content:center;';
            var t = document.createElement('span');
            t.textContent = AC.READ_AUTH_HINT;
            var input = document.createElement('input');
            input.type = 'password';
            input.id = 'ac-read-auth-input';
            input.setAttribute('autocomplete', 'current-password');
            input.setAttribute('aria-label', '访问令牌');
            input.placeholder = '访问令牌 (X-API-Key)';
            input.style.cssText = 'padding:4px 8px;border-radius:6px;border:1px solid #fde2ef;background:#1f1020;color:inherit;min-width:220px;';
            var b = document.createElement('button');
            b.type = 'button';
            b.textContent = '保存并刷新';
            b.style.cssText = 'padding:4px 12px;border-radius:6px;border:1px solid #fde2ef;background:transparent;color:inherit;cursor:pointer;';
            var submit = function() { if (!_saveKeyAndReload(input.value)) { try { input.focus(); } catch (e) {} } };
            b.addEventListener('click', submit);
            input.addEventListener('keydown', function(e) { if (e && e.key === 'Enter') submit(); });
            bar.appendChild(t); bar.appendChild(input); bar.appendChild(b);
            document.body.appendChild(bar);
            try { input.focus(); } catch (e) {}
        } catch (e) {}
    }
    AC.showKeyInput = _showReadAuthHint;

    function _askReadKey() {
        if (_readAuthPrompted) return false;
        _readAuthPrompted = true;
        var key = AC._promptKey(AC.READ_AUTH_PROMPT);
        if (_saveKeyAndReload(key)) return true;
        _showReadAuthHint();        // 取消、留空或不支持弹窗 → 页面底部输入框
        return false;
    }

    AC._handleReadAuthFailure = async function(res) {
        var body = null;
        try { body = await res.clone().json(); } catch (e) {}
        var status = body && body.status;
        var authFailure = res.status === 401 || status === 'forbidden' || status === 'unauthorized';
        if (!authFailure) return false;
        if (res.status === 403) { try { localStorage.removeItem(AC.API_KEY_STORAGE); } catch (e) {} }
        if (_readAuthScheduled || _readAuthPrompted) return true;
        _readAuthScheduled = true;
        setTimeout(function() { _askReadKey(); }, 0);
        return true;
    };

    if (typeof _nativeFetch === 'function' && !_nativeFetch.__acWrapped) {
        var wrapped = function(input, init) {
            var isReq = (typeof Request !== 'undefined') && (input instanceof Request);
            var url = isReq ? input.url : String(input);
            if (!_sameOriginApi(url)) return _nativeFetch.call(window, input, init);
            var method = String((init && init.method) || (isReq && input.method) || 'GET').toUpperCase();
            var key = _getKey();
            if (key) {
                var current = (init && init.headers) || (isReq ? input.headers : null);
                if (!_hasHeader(current, 'X-API-Key')) {
                    init = Object.assign({}, init || {}, { headers: _withKey(isReq && !(init && init.headers) ? new Headers(input.headers) : current, key) });
                }
            }
            var p = _nativeFetch.call(window, input, init);
            if (method !== 'GET' && method !== 'HEAD') return p;
            return p.then(function(res) {
                if (res && (res.status === 401 || res.status === 403)) {
                    return AC._handleReadAuthFailure(res).then(function() { return res; }, function() { return res; });
                }
                return res;
            });
        };
        wrapped.__acWrapped = true;
        window.fetch = wrapped;
    }

    // ── 接口错误文字 (2026-11-04): detail 可能是字符串 / {code, message} / Pydantic 数组 ──
    AC.errorText = function(j) {
        if (!j) return '';
        var d = j.detail;
        if (d && typeof d === 'object' && !Array.isArray(d)) return String(d.message || d.code || '');
        if (Array.isArray(d)) return d.map(function(x) { return x && x.msg ? x.msg : String(x); }).join('; ');
        return String(d || j.message || '');
    };

    // ── 账户数据权威环境 (2026-11-04, docs/ACCOUNT_AUTHORITY_AND_RISK_REFRESH_PLAN.md 1.3 续) ──
    // 服务器 (ACCOUNT_AUTHORITY=server) 为权威; 本机非权威: 导入 / 清零 / 账户写入按钮禁用。
    // 读取失败 → 状态未知, 按非权威处理 (不默认为权威)。后端同样拒绝, 前端只是提前说明。
    AC.NON_AUTH_IMPORT_TEXT = '本环境非权威（本机开发），请在服务器导入（localhost:18000）';
    AC.NON_AUTH_WRITE_TEXT = '本环境非权威（本机开发），账户数据只在服务器写入（localhost:18000）';
    AC.AUTH_UNKNOWN_TEXT = '权威状态未知，暂停账户写入（刷新页面重试）';
    var _authorityPromise = null;
    AC.authority = function(force) {
        if (_authorityPromise && !force) return _authorityPromise;
        var unknown = { authority: 'unknown', authoritative: false, unknown: true, label: '未知' };
        _authorityPromise = fetch('/api/v1/system/authority', { cache: 'no-store' })
            .then(function(r) { return r.ok ? r.json() : null; })
            .then(function(j) {
                var d = j && j.data;
                return (d && typeof d.authoritative === 'boolean') ? d : unknown;
            })
            .catch(function() { return unknown; });
        return _authorityPromise;
    };
    AC.accountWriteBlockedText = function(info, kind) {
        if (info && info.authoritative === true) return '';
        if (!info || info.unknown) return AC.AUTH_UNKNOWN_TEXT;
        return kind === 'import' ? AC.NON_AUTH_IMPORT_TEXT : AC.NON_AUTH_WRITE_TEXT;
    };
    // 把 root 内 [data-ac-account-write] 元素禁用并写明原因 (data-ac-account-write="import" 用导入文案)
    AC.lockAccountWrites = function(root, info) {
        if (!root || !root.querySelectorAll || (info && info.authoritative === true)) return 0;
        var n = 0;
        root.querySelectorAll('[data-ac-account-write]').forEach(function(el) {
            var text = AC.accountWriteBlockedText(info, el.getAttribute('data-ac-account-write'));
            el.disabled = true;
            el.setAttribute('aria-disabled', 'true');
            el.classList.add('ac-write-locked');
            el.title = text;
            n++;
        });
        return n;
    };

})();

// ═══════════════════════════════════════════════════
// Visual Excellence V2.0 — 全局侧边栏收缩系统
// 自动应用到所有引入 alphacore_utils.js 的页面
// ═══════════════════════════════════════════════════
document.addEventListener('DOMContentLoaded', function() {
    var sidebar = document.querySelector('.sidebar');
    var toggleBtn = document.getElementById('sidebar-toggle');
    if (!sidebar || !toggleBtn) return;

    // 从 localStorage 恢复状态
    if (localStorage.getItem('alphacore_sidebar_collapsed') === 'true') {
        sidebar.classList.add('collapsed');
    }

    toggleBtn.addEventListener('click', function() {
        sidebar.classList.toggle('collapsed');
        localStorage.setItem('alphacore_sidebar_collapsed', sidebar.classList.contains('collapsed'));
        // 延迟通知 ECharts 重新 resize
        setTimeout(function() {
            if (window.AC && AC._charts) {
                AC._charts.forEach(function(c) {
                    try { if (c && !c.isDisposed()) c.resize(); } catch(e) {}
                });
            }
        }, 400);
    });
});
