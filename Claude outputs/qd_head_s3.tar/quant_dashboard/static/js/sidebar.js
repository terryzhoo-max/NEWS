/**
 * AlphaCore · 统一导航栏组件 (V27.0 P1-E)
 * ==========================================
 * 消灭 10+ 页面重复侧边栏代码，单一来源管理。
 * 2026-11-02: 导航与手机底栏图标由 emoji 改为单色线性 SVG (currentColor); 个股深研徽章去掉内联颜色。
 * 2026-11-05: 第 0 轮 0b 去掉侧栏底部的头像块 (第三方外链头像图片与占位头衔文字)。
 * 
 * 使用方式:
 *   <aside class="sidebar" id="ac-sidebar"></aside>
 *   <script src="./static/js/sidebar.js?v=1"></script>
 * 
 * 自动功能:
 *   - 根据当前 URL 自动高亮 active 导航项
 *   - 侧边栏收缩/展开 toggle
 *   - 个股深研子菜单折叠
 */

(function () {
    'use strict';

    // ── 导航数据结构 ──
    const NAV_CONFIG = [
        {
            group: '情 报 中 心',
            items: [
                { href: './index.html',    icon: 'dashboard', label: '量化总览' },
                { href: './factor.html',   icon: 'chart', label: '因子分析' },
                { href: './industry.html', icon: 'industry', label: '产业追踪' },
            ]
        },
        {
            group: '策 略 实 验 室',
            items: [
                { href: './strategy.html',  icon: 'sliders', label: '策略中心' },
                { href: './backtest.html',  icon: 'backtest', label: '量化回测', badge: 'Beta' },
                { href: './treasury.html',  icon: 'globe', label: '海外策略' },
            ]
        },
        {
            group: '科 学 决 策',
            items: [
                { href: './decision.html', icon: 'target', label: '决策中枢' },
                { href: './report.html',   icon: 'doc', label: '投委会简报', badge: 'PDF' },
            ]
        },
        {
            group: '研 究 审 计',
            items: [
                { href: './audit.html', icon: 'audit', label: '深度审计' },
            ],
            subMenu: {
                parentIcon: 'folder',
                parentLabel: '个股深研',
                items: [
                    { href: './smic_audit.html', label: '中芯国际' },
                    { href: './zijin_audit.html', label: '紫金矿业' },
                    { href: './byd_audit.html', label: '比亚迪' },
                    { href: './eastmoney_audit.html', label: '东方财富' },
                    { href: './fii_audit.html', label: '工业富联' },
                    { href: './wus_audit.html', label: '沪电股份' },
                    { href: './scc_audit.html', label: '深南电路' },
                ]
            }
        },
        {
            group: '账 户 管 理',
            items: [
                { href: './portfolio.html', icon: 'briefcase', label: '投资组合' },
            ]
        }
    ];

    // ── 导航图标 (2026-11-02: 全站去 emoji) ──
    // 单色线性 SVG, stroke = currentColor (颜色跟随导航文字/激活态, 不另设颜色)
    const ICON_PATHS = {
        dashboard: '<rect x="3" y="3" width="7" height="9" rx="1"/><rect x="14" y="3" width="7" height="5" rx="1"/><rect x="14" y="12" width="7" height="9" rx="1"/><rect x="3" y="16" width="7" height="5" rx="1"/>',
        chart:     '<path d="M3 3v18h18"/><path d="M7 15l4-4 3 3 5-6"/>',
        industry:  '<path d="M3 21V10l6 4V10l6 4V6l6 4v11z"/><path d="M3 21h18"/>',
        sliders:   '<path d="M4 6h10M18 6h2M4 12h4M12 12h8M4 18h12M20 18h0"/><circle cx="16" cy="6" r="2"/><circle cx="10" cy="12" r="2"/><circle cx="18" cy="18" r="2"/>',
        backtest:  '<path d="M3 12a9 9 0 1 0 3-6.7"/><path d="M3 4v5h5"/><path d="M12 7v5l3 2"/>',
        globe:     '<circle cx="12" cy="12" r="9"/><path d="M3 12h18"/><path d="M12 3a14 14 0 0 1 0 18a14 14 0 0 1 0-18"/>',
        target:    '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1"/>',
        doc:       '<path d="M14 3H6a1 1 0 0 0-1 1v16a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1V8z"/><path d="M14 3v5h5"/><path d="M9 13h6M9 17h6"/>',
        audit:     '<path d="M12 3l8 3v6c0 4.5-3.4 8.3-8 9c-4.6-.7-8-4.5-8-9V6z"/><path d="M8.5 12l2.5 2.5l4.5-5"/>',
        folder:    '<path d="M3 7a1 1 0 0 1 1-1h5l2 2h9a1 1 0 0 1 1 1v9a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1z"/>',
        briefcase: '<rect x="3" y="7" width="18" height="13" rx="1"/><path d="M8 7V5a1 1 0 0 1 1-1h6a1 1 0 0 1 1 1v2"/><path d="M3 13h18"/>',
        chevronRight: '<path d="M9 6l6 6l-6 6"/>',
        chevronLeft:  '<path d="M15 6l-6 6l6 6"/>',
        dot:       '<circle cx="12" cy="12" r="2.2" fill="currentColor" stroke="none"/>',
    };
    function iconSvg(key) {
        const p = ICON_PATHS[key];
        if (!p) return '';
        return `<svg class="ac-nav-svg" viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${p}</svg>`;
    }

    // ── 当前页面匹配 ──
    function getCurrentPage() {
        const path = window.location.pathname;
        const filename = path.substring(path.lastIndexOf('/') + 1) || 'index.html';
        return './' + filename;
    }

    // ── 渲染导航 HTML ──
    function renderSidebar() {
        const currentPage = getCurrentPage();
        const isSubPage = NAV_CONFIG.some(g => 
            g.subMenu && g.subMenu.items.some(i => i.href === currentPage)
        );

        let html = '';

        // Logo
        html += '<div class="logo"><div class="logo-icon"></div><h1>AlphaCore</h1></div>';

        // Nav menu
        html += '<nav class="nav-menu">';

        for (const group of NAV_CONFIG) {
            html += `<div class="nav-group-title">${group.group}</div>`;

            for (const item of group.items) {
                const isActive = item.href === currentPage ? ' active' : '';
                const tooltip = item.label;
                html += `<a href="${item.href}" class="nav-item${isActive}" data-tooltip="${tooltip}">`;
                html += `<span class="icon">${iconSvg(item.icon)}</span>`;
                html += `<span>${item.label}</span>`;
                if (item.badge) {
                    html += `<span class="badge-beta">${item.badge}</span>`;
                }
                html += '</a>';
            }

            // Sub-menu (个股深研)
            if (group.subMenu) {
                const sub = group.subMenu;
                const subOpen = isSubPage ? ' open' : '';
                html += `<div class="nav-parent${subOpen}" onclick="this.classList.toggle('open');this.nextElementSibling.classList.toggle('open')">`;
                html += `<span class="icon">${iconSvg(sub.parentIcon)}</span>`;
                html += `<span>${sub.parentLabel}</span>`;
                html += `<span class="nav-arrow">${iconSvg('chevronRight')}</span></div>`;
                html += `<div class="nav-sub-group${subOpen}">`;

                for (const si of sub.items) {
                    const siActive = si.href === currentPage ? ' active' : '';
                    html += `<a href="${si.href}" class="nav-item${siActive}">`;
                    html += `<span class="icon">${iconSvg('dot')}</span>`;
                    html += `<span>${si.label}</span>`;
                    html += '<span class="badge-beta">DEEP</span>';
                    html += '</a>';
                }

                html += '</div>';
            }
        }

        html += '</nav>';

        // Sidebar toggle
        html += '<button class="sidebar-toggle" id="sidebar-toggle" title="收缩/展开">';
        html += `<i class="toggle-icon">${iconSvg('chevronLeft')}</i><span class="toggle-text">收起导航</span></button>`;

        return html;
    }

    // ── 初始化侧边栏 toggle 行为 ──
    function initToggle() {
        const toggle = document.getElementById('sidebar-toggle');
        if (!toggle) return;

        const sidebar = toggle.closest('.sidebar') || document.querySelector('.sidebar');
        if (!sidebar) return;

        // 恢复收缩状态
        const collapsed = localStorage.getItem('ac-sidebar-collapsed') === 'true';
        if (collapsed) {
            sidebar.classList.add('collapsed');
        }

        toggle.addEventListener('click', function () {
            sidebar.classList.toggle('collapsed');
            const isCollapsed = sidebar.classList.contains('collapsed');
            localStorage.setItem('ac-sidebar-collapsed', isCollapsed);
        });
    }

    // ── 动态加载全局模块 (V27.0: 侧边栏作为全局组件分发中心) ──
    function loadGlobalModules() {
        // JS 模块
        const scripts = [
            './static/js/ai_assistant.js?v=2',
        ];
        for (const src of scripts) {
            if (!document.querySelector(`script[src="${src}"]`)) {
                const s = document.createElement('script');
                s.src = src;
                s.defer = true;
                document.body.appendChild(s);
            }
        }
        // CSS 模块 (移动端响应式)
        const styles = [
            './static/css/mobile.css?v=3',
            './static/css/sidebar.css?v=1',
        ];
        for (const href of styles) {
            if (!document.querySelector(`link[href="${href}"]`)) {
                const l = document.createElement('link');
                l.rel = 'stylesheet';
                l.href = href;
                document.head.appendChild(l);
            }
        }
    }

    // ── 移动端底部导航 (V27.0 P2-C) ──
    function injectMobileNav() {
        if (document.getElementById('ac-mobile-nav')) return;
        const currentPage = getCurrentPage();
        const tabs = [
            { href: './index.html',     icon: 'dashboard', label: '总览' },
            { href: './decision.html',  icon: 'target', label: '决策' },
            { href: './strategy.html',  icon: 'sliders', label: '策略' },
            { href: './portfolio.html', icon: 'briefcase', label: '组合' },
            { href: './report.html',    icon: 'doc', label: '简报' },
        ];
        const nav = document.createElement('nav');
        nav.id = 'ac-mobile-nav';
        // 先隐藏: mobile.css 是动态加载的, 样式到达前桌面端会闪现一排未样式链接;
        // 手机端由 mobile.css 的 display:flex !important 覆盖显示
        nav.style.display = 'none';
        nav.innerHTML = tabs.map(t => {
            const active = t.href === currentPage ? ' active' : '';
            return `<a href="${t.href}" class="${active}"><span class="mn-icon">${iconSvg(t.icon)}</span>${t.label}</a>`;
        }).join('');
        document.body.appendChild(nav);
    }

    // ── 挂载 ──
    function mount() {
        const container = document.querySelector('.sidebar') || document.getElementById('ac-sidebar');
        if (!container) return;

        container.innerHTML = renderSidebar();
        initToggle();
        loadGlobalModules();
        injectMobileNav();
    }

    // DOM ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', mount);
    } else {
        mount();
    }
})();
