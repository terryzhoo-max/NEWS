// 2026-11-02 仓位口径统一: "持仓截至 MM-DD HH:MM 对账单 · 价格 MM-DD 收盘" (与 services/account_exposure.label 一致)
// 2026-11-04: 时点 = 对账单日期 + 估值时点; 估值时点未知写明, 不再用导入时间 (imported_at) 冒充
function positionAsOfLabel(data) {
    const parts = [];
    const d = String((data && data.statement_date) || '');
    const t = String((data && data.valuation_time) || '').trim();
    if (d.length >= 10 && /^\d{2}:\d{2}/.test(t)) parts.push(`持仓截至 ${d.slice(5, 10)} ${t.slice(0, 5)} 对账单`);
    else if (d.length >= 10) parts.push(`持仓截至 ${d.slice(5, 10)} 对账单（估值时点未知）`);
    const dates = ((data && data.positions) || []).map(p => String(p.price_as_of || '').replace(/-/g, '')).filter(d => d.length >= 8).sort();
    const p = dates.length ? dates[dates.length - 1] : '';
    if (p) parts.push(`价格 ${p.slice(4, 6)}-${p.slice(6, 8)} 收盘`);
    return parts.join(' · ');
}

/**
 * AlphaCore Portfolio Manager V2.0 — Institutional Grade
 * =====================================================
 * - 集成全新 API: valuation / risk / nav / history
 * - Toast 通知系统 (替代 alert)
 * - 增强持仓表格 (仓位占比进度条)
 * - 风险 Gauge 三联仪表盘
 * - 净值走势对比图
 * - 交易记录面板
 * - 交易预估实时计算
 * - V26.0: 跨页持仓变更广播 (BroadcastChannel)
 */

// V26.0: 跨 Tab 持仓变更通知 (decision hub 自动刷新调仓路径)
function _broadcastPortfolioChange(action, detail) {
    const msg = { type: 'portfolio_updated', action, ts: Date.now(), ...detail };
    try {
        const bc = new BroadcastChannel('alphacore_portfolio');
        bc.postMessage(msg);
        bc.close();
    } catch(e) {
        // 降级: localStorage storage 事件 (跨 Tab 同样可触发)
        localStorage.setItem('_ac_portfolio_ts', Date.now().toString());
    }
}

// 2026-11-04 视觉轮: 涨跌语义类 (红涨绿跌, 0 为中性); 只用于实际涨跌与盈亏
function pnlClass(v) {
    const n = Number(v);
    if (v == null || !Number.isFinite(n) || n === 0) return 'ac-flat';
    return n > 0 ? 'ac-up' : 'ac-down';
}
// 接口文案中的 emoji 前端不显示 (不改接口)
function stripEmoji(s) {
    return String(s == null ? '' : s)
        .replace(/[\u{1F000}-\u{1FAFF}\u{2600}-\u{27BF}\u{2B00}-\u{2BFF}\u{FE0F}\u{200D}]/gu, '')
        .replace(/\s{2,}/g, ' ').trim();
}

// 2026-11-03 组合页精简 P4: 模块开关 (static/js/portfolio_modules.js); 开关脚本缺失时全部按开启处理
// 2026-11-04: 开关脚本缺失时可选模块按关闭处理 (与 portfolio_modules.js 读不到开关时一致)
function pmOn(key) { return !!window.PfModules && window.PfModules.on(key); }
function pmReady() { return (window.PfModules && window.PfModules.ready) || Promise.resolve(); }

document.addEventListener('DOMContentLoaded', function () {
    const tradeModal = document.getElementById('trade-modal');
    const openTradeBtn = document.getElementById('open-trade-btn');
    const closeTradeBtn = document.getElementById('close-modal');
    const buyBtn = document.getElementById('buy-btn');
    const sellBtn = document.getElementById('sell-btn');
    const tradePrice = document.getElementById('trade-price');
    const tradeAmount = document.getElementById('trade-amount');
    const tradeEst = document.getElementById('trade-est');

    let charts = { sector: null, nav: null, sparkline: null };

    const COLOR_PALETTE = [
        '#6366f1', '#3b82f6', '#10b981', '#f59e0b',
        '#ef4444', '#ec4899', '#06b6d4', '#8b5cf6'
    ];

    // ════════════════════════════════════
    //  合规徽章 / 告警条 (2026-11-03 组合页精简 P1)
    //  唯一来源: 合规引擎 (/decision/compliance-check, 见 static/js/portfolio_compliance.js)。
    //  原 PfAlerts 12 条前端阈值规则已删除: 本页不做任何风险判定。
    // ════════════════════════════════════
    if (window.PfCompliance) window.PfCompliance.load();

    // ════════════════════════════════════
    //  Toast 通知系统
    // ════════════════════════════════════

    function showToast(message, type = 'success', duration = 3500) {
        const container = document.getElementById('toast-container');
        const toast = document.createElement('div');
        toast.className = `pf-toast pf-toast-${type}`;

        // 2026-11-04 视觉轮: 文字标签替代图标; 文案按纯文本写入 (接口文案过滤 emoji)
        const labels = { success: '完成', error: '失败', info: '提示', warning: '注意' };
        const tag = document.createElement('span');
        tag.className = 'pf-toast-icon';
        tag.textContent = labels[type] || '提示';
        const msg = document.createElement('span');
        msg.className = 'pf-toast-msg';
        msg.textContent = stripEmoji(message);
        toast.append(tag, msg);
        container.appendChild(toast);

        requestAnimationFrame(() => toast.classList.add('pf-toast-show'));

        setTimeout(() => {
            toast.classList.remove('pf-toast-show');
            toast.classList.add('pf-toast-hide');
            setTimeout(() => toast.remove(), 400);
        }, duration);
    }

    // ════════════════════════════════════
    //  交易预估实时计算
    // ════════════════════════════════════

    function updateTradeEstimate() {
        const p = parseFloat(tradePrice.value) || 0;
        const a = parseInt(tradeAmount.value) || 0;
        const total = p * a;
        tradeEst.textContent = '¥ ' + total.toLocaleString(undefined, { minimumFractionDigits: 2 });
    }

    tradePrice.addEventListener('input', updateTradeEstimate);
    tradeAmount.addEventListener('input', updateTradeEstimate);

    // ════════════════════════════════════
    //  Chart 初始化
    // ════════════════════════════════════

    function initCharts() {
        const sectorEl = document.getElementById('sector-pie-chart');
        const navEl = document.getElementById('nav-chart');
        const sparkEl = document.getElementById('pf-sparkline');

        if (sectorEl && !charts.sector) charts.sector = AC.registerChart(echarts.init(sectorEl));
        if (navEl && !charts.nav) charts.nav = AC.registerChart(echarts.init(navEl));
        if (sparkEl && !charts.sparkline) charts.sparkline = AC.registerChart(echarts.init(sparkEl));
    }

    // ════════════════════════════════════
    //  数据加载: 估值
    // ════════════════════════════════════

    async function loadPortfolio() {
        try {
            const res = await fetch('/api/v1/portfolio/valuation');
            const result = await res.json();
            if (result.status === 'success') {
                renderValuation(result.data);
                if (window.PfKpis) window.PfKpis.load();   // 账户收益 / 组合波动 / 当前回撤 / 风险贡献 (唯一来源)
                if (window.PfKpis) window.PfKpis.loadExecTarget();   // 执行目标: 决策中枢同一接口 (/decision/hub), 只读
                loadTrailing();                                       // 跟踪止盈状态: 决策中枢同一接口, 只读
                // 2026-11-03 组合页精简 P4: 关闭的模块不发请求 (config/portfolio_modules.json)
                pmReady().then(() => {
                    if (pmOn('sector_pie')) loadRisk();
                    if (pmOn('nav_sim') || pmOn('hero_sparkline')) loadNavCurve();
                });
                loadHistory();
            }
        } catch (err) {
            console.error("Failed to load portfolio:", err);
            showToast('组合数据加载失败', 'error');
        }
    }

    function renderValuation(data) {
        // 2026-11-04 视觉轮 V2: 总资产为唯一大数字 (中性色); 金额千分位; KPI 来源行直接可见
        const yuan = v => '¥ ' + Number(v || 0).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
        document.getElementById('port-cash').textContent = yuan(data.cash);
        document.getElementById('port-mv').textContent = yuan(data.market_value);
        document.getElementById('nav-val').textContent = yuan(data.total_asset);
        document.getElementById('pos-count').textContent = data.position_count || data.positions.length || 0;

        const cashWeight = data.cash_weight != null ? data.cash_weight : (data.total_asset > 0 ? (data.cash / data.total_asset * 100) : 0);
        document.getElementById('cash-weight').textContent = cashWeight.toFixed(1);

        // 当前仓位 (2026-11-03 组合页精简 P2): 只读后端 account_exposure (全站唯一口径, 与决策中枢 / 合规同一函数),
        // 前端不再自算逆回购与分母; 不可用时显示 "--", 不用其他数字替代。
        const exp = data.account_exposure || null;
        const expOk = !!(exp && exp.status === 'ok' && typeof exp.pct === 'number' && Number.isFinite(exp.pct));
        const tpwEl = document.getElementById('total-position-weight');
        tpwEl.textContent = expOk ? Number(exp.pct).toFixed(1) : '--';
        tpwEl.title = expOk ? `口径：${exp.basis || '持仓市值(不含逆回购) / (持仓市值 + 现金)'}（与决策中枢、合规同一来源）`
                            : '当前仓位不可用（统一口径计算失败）';
        const asofEl = document.getElementById('pf-pos-asof');
        if (asofEl) asofEl.textContent = expOk ? (exp.label || positionAsOfLabel(data)) : '';

        // 2026-11-03 组合页精简 P3: 原「建仓以来 ROI」(持仓成本口径) 已删除; 账户收益见 static/js/portfolio_kpis.js

        // KPI 来源与时间行 (持仓市值 / 现金)
        if (window.PfView) {
            const src = window.PfView.kpiSources(data);
            const mvSub = document.getElementById('port-mv-sub'), cashSub = document.getElementById('port-cash-sub');
            if (mvSub) mvSub.textContent = src.mv;
            if (cashSub) cashSub.textContent = src.cash;
        }

        document.getElementById('pf-total-positions').textContent = (data.position_count || data.positions.length) + ' 只持仓';

        renderPositionsTable(data.positions);

        // 数据质量提示 (非风险判定; 风险结论只来自合规引擎)
        if (window.PfCompliance) window.PfCompliance.setDataNotes(window.PfCompliance.dataQualityNotes(data));
    }

    // 2026-11-04 视觉轮 V2: 持仓表由 static/js/portfolio_view.js 渲染 (按市值降序、类型标签、ETF 价格 3 位、
    // 中性占比条以最大持仓为满格、红涨绿跌、成本价兜底 warn 标签、名称与行业转义)
    // 跟踪止盈状态 (只读, 决策中枢同一接口): undefined = 加载中, null = 读取失败, {code: status}
    let lastPositions = [], trailState;
    function renderPositionsTable(positions) {
        lastPositions = positions || [];
        const body = document.getElementById('positions-body');
        body.innerHTML = window.PfView ? window.PfView.positionsBodyHtml(lastPositions, trailState)
            : '<tr><td colspan="9" class="pf-table-empty">持仓表组件未加载</td></tr>';
        // 手机 375: 卡片列表 (CSS 按宽度切换, 不横向滚动)
        const cards = document.getElementById('positions-cards');
        if (cards && window.PfView) cards.innerHTML = window.PfView.positionCardsHtml(lastPositions, trailState);
    }

    async function loadTrailing() {
        try {
            const r = await fetch('/api/v1/portfolio/trailing-stops');
            trailState = r.ok && window.PfView ? window.PfView.trailMap(await r.json()) : null;
        } catch (e) { trailState = null; }
        renderPositionsTable(lastPositions);
    }

    // ════════════════════════════════════
    //  数据加载: 风险
    // ════════════════════════════════════

    async function loadRisk() {
        try {
            const res = await fetch('/api/v1/portfolio/risk');
            const result = await res.json();
            if (result.status === 'success' && result.data.status !== 'empty') {
                renderRiskCharts(result.data);
                if (result.data.skipped_codes && result.data.skipped_codes.length > 0) {
                    console.info('Risk: ' + result.data.skipped_codes.length + ' 只缺行情数据已跳过');
                }
            }
        } catch (err) {
            console.error('Failed to load risk metrics:', err);
            showToast('风控数据加载失败: ' + err.message, 'warning');
        }
    }

    function renderRiskCharts(risk) {
        initCharts();

        // 2026-11-03 组合页精简 P3: 120D 波动 / 夏普 / 最大回撤与 MCTR 已删除 (当前持仓回溯, 与合规口径冲突);
        // 改读组合波动预算与回撤刹车 (static/js/portfolio_kpis.js)。本函数只剩行业饼图 (P4 隐藏)。

        // ── Sector Pie Chart ──
        const pieData = risk.industry_exposure || risk.details.map(d => ({ name: d.name, value: d.weight }));

        charts.sector.setOption({
            backgroundColor: 'transparent',
            tooltip: {
                trigger: 'item',
                backgroundColor: 'rgba(15, 23, 42, 0.95)',
                borderColor: 'rgba(255,255,255,0.08)',
                textStyle: { color: '#f8fafc', fontSize: 12 },
                formatter: '{b}: {c}%'
            },
            legend: {
                orient: 'vertical',
                right: '5%',
                top: 'middle',
                textStyle: { color: '#94a3b8', fontSize: 12 },
                icon: 'circle',
                itemWidth: 10,
                itemGap: 14
            },
            color: COLOR_PALETTE,
            series: [{
                type: 'pie',
                radius: ['52%', '82%'],
                center: ['38%', '50%'],
                avoidLabelOverlap: false,
                itemStyle: {
                    borderRadius: 8,
                    borderColor: 'rgba(15, 23, 42, 0.6)',
                    borderWidth: 3
                },
                label: { show: false },
                emphasis: {
                    label: {
                        show: true,
                        fontSize: 16,
                        fontWeight: 'bold',
                        color: '#fff',
                        formatter: '{b}\n{d}%'
                    },
                    scaleSize: 8
                },
                labelLine: { show: false },
                data: pieData,
                animationType: 'scale',
                animationDuration: 1200,
                animationEasing: 'elasticOut'
            }]
        });
    }



    // ════════════════════════════════════
    //  净值曲线
    // ════════════════════════════════════

    async function loadNavCurve() {
        try {
            const res = await fetch('/api/v1/portfolio/nav');
            const result = await res.json();
            if (result.status === 'success' && result.data.status === 'ok') {
                renderNavChart(result.data);
            }
        } catch (err) {
            console.error('Failed to load NAV:', err);
            showToast('净值曲线加载失败: ' + err.message, 'warning');
        }
    }

    function renderNavChart(navData) {
        initCharts();

        // 数据覆盖率标签
        const covEl = document.getElementById('nav-coverage');
        if (covEl && navData.available_count != null) {
            const avail = navData.available_count;
            const total = navData.total_count || avail;
            const skipped = total - avail;
            covEl.style.display = '';
            const miss = Number(navData.missing_return_cells || 0);
            const basisNote = navData.return_basis_label || navData.label || '当前持仓历史模拟（非真实历史业绩）';
            if (skipped > 0) {
                covEl.textContent = `${avail}/${total} 只覆盖`;
                covEl.style.color = '#fbbf24';
                covEl.title = `${skipped} 只标的缺行情数据，未参与净值模拟`;
            } else {
                covEl.textContent = `${avail} 只全覆盖`;
                covEl.style.color = '';
                covEl.title = '';
            }
            if (miss > 0) {
                covEl.textContent += ` · 缺失 ${miss} 个日收益按 0 计`;
                covEl.style.color = '#fbbf24';
            }
            covEl.title = (covEl.title ? covEl.title + '\n' : '') + '口径: ' + basisNote;
        }

        const series = [{
            name: '组合净值',
            type: 'line',
            data: navData.nav,
            smooth: true,
            showSymbol: false,
            lineStyle: { width: 2.5, color: '#6366f1' },
            areaStyle: {
                color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
                    { offset: 0, color: 'rgba(99, 102, 241, 0.25)' },
                    { offset: 1, color: 'rgba(99, 102, 241, 0.02)' }
                ])
            }
        }];

        if (navData.benchmark && navData.benchmark.length > 0) {
            series.push({
                name: navData.benchmark_name || '沪深300',
                type: 'line',
                data: navData.benchmark,
                smooth: true,
                showSymbol: false,
                lineStyle: { width: 1.5, color: '#64748b', type: 'dashed' },
                areaStyle: null
            });
        }

        charts.nav.setOption({
            backgroundColor: 'transparent',
            tooltip: {
                trigger: 'axis',
                backgroundColor: 'rgba(15, 23, 42, 0.95)',
                borderColor: 'rgba(255,255,255,0.08)',
                textStyle: { color: '#f8fafc', fontSize: 12 },
                formatter: function(params) {
                    let html = `<strong>${params[0].axisValue}</strong>`;
                    let navVal = null, benchVal = null;
                    params.forEach(p => {
                        const marker = `<span style="display:inline-block;width:8px;height:8px;border-radius:50%;background:${p.color};margin-right:4px;"></span>`;
                        html += `<br>${marker}${p.seriesName}: ${p.value.toFixed(4)}`;
                        if (p.seriesName === '组合净值') navVal = p.value;
                        else benchVal = p.value;
                    });
                    if (navVal !== null && benchVal !== null) {
                        const alpha = ((navVal - benchVal) * 100).toFixed(2);
                        const alphaColor = alpha >= 0 ? '#10b981' : '#ef4444';
                        html += `<br><span style="color:${alphaColor};font-weight:700;">Alpha: ${alpha >= 0 ? '+' : ''}${alpha}%</span>`;
                    }
                    return html;
                }
            },
            legend: {
                right: '5%', top: '2%',
                textStyle: { color: '#94a3b8', fontSize: 11 },
                icon: 'roundRect', itemWidth: 14
            },
            grid: { left: '3%', right: '4%', bottom: '3%', top: '14%', containLabel: true },
            xAxis: {
                type: 'category',
                data: navData.dates,
                axisLabel: {
                    color: '#64748b', fontSize: 10, fontFamily: 'Outfit',
                    formatter: val => val.slice(5) // MM-DD
                },
                axisLine: { lineStyle: { color: 'rgba(255,255,255,0.05)' } },
                splitLine: { show: false }
            },
            yAxis: {
                type: 'value',
                axisLabel: { color: '#64748b', fontSize: 10, fontFamily: 'Outfit', formatter: v => v.toFixed(2) },
                splitLine: { lineStyle: { color: 'rgba(255,255,255,0.03)' } }
            },
            series: series,
            animationDuration: 1200,
            animationEasing: 'cubicOut'
        });

        // Sparkline in Hero
        if (charts.sparkline && navData.nav.length > 0) {
            charts.sparkline.setOption({
                backgroundColor: 'transparent',
                grid: { left: 0, right: 0, top: 0, bottom: 0 },
                xAxis: { type: 'category', show: false, data: navData.dates },
                yAxis: { type: 'value', show: false, min: 'dataMin', max: 'dataMax' },
                series: [{
                    type: 'line', data: navData.nav, smooth: true, showSymbol: false,
                    lineStyle: { width: 2, color: '#6366f1' },
                    areaStyle: {
                        color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
                            { offset: 0, color: 'rgba(99,102,241,0.3)' },
                            { offset: 1, color: 'rgba(99,102,241,0)' }
                        ])
                    }
                }],
                animation: true, animationDuration: 800
            });
        }
    }

    // ════════════════════════════════════
    //  交易记录
    // ════════════════════════════════════

    // 2026-11-03 组合页精简 P4: 成交记录改读成交台账 (/portfolio/trades, 导入的交割单 / 历史成交);
    // 原 /portfolio/history 为系统操作日志 (导入 / 清零事件), 标题与内容不符。
    async function loadHistory() {
        try {
            const res = await fetch('/api/v1/portfolio/trades?limit=50');
            const result = await res.json();
            if (result.status === 'success') renderHistory(result.data || {});
            else renderHistory(null);
        } catch (err) {
            console.error("Failed to load trades:", err);
            renderHistory(null);
        }
    }

    function renderHistory(data) {
        const container = document.getElementById('trade-history-list');
        const countEl = document.getElementById('trade-ledger-count');
        if (!data) {
            container.innerHTML = '<div class="pf-history-empty">成交台账读取失败</div>';
            if (countEl) countEl.textContent = '';
            return;
        }
        const trades = data.trades || [];
        if (countEl) countEl.textContent = `共 ${data.count != null ? data.count : trades.length} 笔`;
        if (!trades.length) {
            container.innerHTML = '<div class="pf-history-empty">成交台账为空（在服务器导入交割单 / 历史成交）</div>';
            return;
        }
        // 2026-11-04 视觉轮 V3: 成交记录按持仓表规范 (表格、数字右对齐、千分位、ETF 价格 3 位);
        // 买入 / 卖出用中性描边文字标签 (不用红买绿卖, 避免与盈亏色混用)
        const V = window.PfView;
        const esc = V ? V.esc : (v => String(v == null ? '' : v));
        const fmt = (v, d = 2) => (typeof v === 'number' && isFinite(v)) ? v.toLocaleString('en-US', { minimumFractionDigits: d, maximumFractionDigits: d }) : '--';
        const SIDE = { buy: '买入', sell: '卖出' };
        const rows = trades.map(t => {
            const side = SIDE[t.side] || esc(t.side || t.kind || '--');
            const code = t.ts_code || t.code;
            return `<tr>
                <td class="pf-mono">${esc(t.date)}${t.time ? ` <span class="pf-dim">${esc(t.time)}</span>` : ''}</td>
                <td><span class="ac-tag pf-side-tag">${side}</span></td>
                <td><span class="pf-name-cell">${esc(t.name || code)}</span> <span class="pf-code-ext">${esc(code)}</span></td>
                <td class="num pf-mono">${typeof t.qty === 'number' ? t.qty.toLocaleString('en-US') : esc(t.qty == null ? '--' : t.qty)}</td>
                <td class="num pf-mono">${V ? V.priceText(t.price, code) : fmt(t.price, 3)}</td>
                <td class="num pf-mono">${fmt(t.amount)}</td>
                <td class="num pf-mono pf-dim">${t.fees != null ? fmt(t.fees) : '--'}</td>
            </tr>`;
        }).join('');
        container.innerHTML = `<div class="pf-table-wrap"><table class="pf-table pf-trades-table"><thead><tr><th>日期</th><th>方向</th><th>名称 / 代码</th>
            <th class="num">数量</th><th class="num">价格</th><th class="num">金额</th><th class="num">费用</th></tr></thead><tbody>${rows}</tbody></table></div>`;
    }

    // ════════════════════════════════════
    //  交易执行
    // ════════════════════════════════════

    async function doTrade(action) {
        const payload = {
            ts_code: document.getElementById('trade-code').value.trim(),
            name: document.getElementById('trade-name').value.trim(),
            amount: parseInt(tradeAmount.value),
            price: parseFloat(tradePrice.value),
            action: action
        };

        if (!payload.ts_code) {
            showToast('请输入证券代码', 'warning');
            return;
        }
        if (isNaN(payload.amount) || payload.amount <= 0) {
            showToast('请输入有效的数量', 'warning');
            return;
        }
        if (isNaN(payload.price) || payload.price <= 0) {
            showToast('请输入有效的价格', 'warning');
            return;
        }

        try {
            const res = await AC.secureFetch('/api/v1/portfolio/trade', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(payload)
            });
            const result = await res.json();

            if (result.status === 'success') {
                tradeModal.style.display = 'none';
                showToast(`${action === 'buy' ? '买入' : '卖出'} ${payload.name || payload.ts_code} 成功`, 'success');
                loadPortfolio();
                _broadcastPortfolioChange('trade', { code: payload.ts_code, side: action });
            } else {
                showToast('交易失败: ' + result.message, 'error');
            }
        } catch (err) {
            showToast('网络错误，请重试', 'error');
        }
    }

    // ════════════════════════════════════
    //  TXT 持仓导入系统
    // ════════════════════════════════════

    const importBtn = document.getElementById('import-btn');
    const importFileInput = document.getElementById('import-file-input');
    const importModal = document.getElementById('import-modal');
    const importDropzone = document.getElementById('import-dropzone');
    const importPreview = document.getElementById('import-preview');
    const importSummary = document.getElementById('import-summary');
    const importPreviewBody = document.getElementById('import-preview-body');
    const importConfirmBtn = document.getElementById('import-confirm-btn');
    const importCloseBtn = document.getElementById('import-close-btn');
    const importWarning = document.getElementById('import-warning');

    let pendingImportFile = null;
    // 2026-11-04 (2b): 估值时点必填、无默认值 (收盘后导出填 15:00, 盘中导出填实际时间)
    const importValZone = document.getElementById('import-valtime-zone');
    const importValInput = document.getElementById('import-valuation-time');
    const importStmtDate = document.getElementById('import-statement-date');
    const VALTIME_RE = /^([01]\d|2[0-3]):[0-5]\d$/;
    function importValuationTime() {
        const v = String((importValInput && importValInput.value) || '').trim().slice(0, 5);
        return VALTIME_RE.test(v) ? v : null;
    }
    function syncImportConfirm() {
        importConfirmBtn.disabled = !pendingImportFile || !importValuationTime();
        importConfirmBtn.title = importValuationTime() ? '' : '请先填写估值时点';
    }
    function markValtimePick() {
        const v = importValuationTime();
        document.querySelectorAll('.pf-valtime-pick').forEach(b => b.classList.toggle('active', b.dataset.valtime === v));
    }
    if (importValInput) importValInput.addEventListener('input', () => { syncImportConfirm(); markValtimePick(); });
    if (importValInput) importValInput.addEventListener('change', () => { syncImportConfirm(); markValtimePick(); });
    // 常用时点快捷填写: 只在点击时填入 (仍无默认值)
    document.querySelectorAll('.pf-valtime-pick').forEach(b => b.addEventListener('click', () => {
        if (!importValInput) return;
        importValInput.value = b.dataset.valtime;
        syncImportConfirm(); markValtimePick();
    }));

    // 证券代码自动补全后缀 (客户端镜像)
    function autoSuffix(code) {
        code = code.trim();
        if (code.includes('.')) return code;
        if (code.length === 5) return code + '.HK';
        if (code.length === 6) {
            const p3 = code.substring(0, 3);
            if (p3 === '159') return code + '.SZ';
            if (['510','511','512','513','515','516','518','560','561','562','563','588'].includes(p3)) return code + '.SH';
            if (['000','001','002','003','300','301'].includes(p3)) return code + '.SZ';
            if (code[0] === '6') return code + '.SH';
            if (['688','689'].includes(p3)) return code + '.SH';
        }
        return code + '.SZ';
    }

    // 打开导入弹窗
    importBtn.onclick = () => {
        if (importBtn.disabled) return;   // 2026-11-04: 非权威环境已禁用
        // 重置状态
        pendingImportFile = null;
        importPreview.style.display = 'none';
        importConfirmBtn.style.display = 'none';
        importWarning.style.display = 'none';
        if (importValZone) importValZone.style.display = 'none';
        if (importValInput) importValInput.value = '';          // 无默认值
        document.querySelectorAll('.pf-valtime-pick').forEach(b => b.classList.remove('active'));
        if (importStmtDate) importStmtDate.textContent = '';
        importDropzone.style.display = 'flex';
        importPreviewBody.innerHTML = '';
        importFileInput.value = '';
        importModal.style.display = 'flex';
    };

    // 关闭导入弹窗
    importCloseBtn.onclick = () => importModal.style.display = 'none';
    importModal.addEventListener('click', (e) => {
        if (e.target === importModal) importModal.style.display = 'none';
    });

    // 点击拖放区 → 触发文件选择
    importDropzone.onclick = () => importFileInput.click();

    // 拖放支持
    importDropzone.addEventListener('dragover', (e) => {
        e.preventDefault();
        e.stopPropagation();
        importDropzone.classList.add('pf-dropzone-hover');
    });

    importDropzone.addEventListener('dragleave', (e) => {
        e.preventDefault();
        importDropzone.classList.remove('pf-dropzone-hover');
    });

    importDropzone.addEventListener('drop', (e) => {
        e.preventDefault();
        e.stopPropagation();
        importDropzone.classList.remove('pf-dropzone-hover');
        if (e.dataTransfer.files.length > 0) {
            handleImportFile(e.dataTransfer.files[0]);
        }
    });

    // 文件选择回调
    importFileInput.onchange = (e) => {
        if (e.target.files.length > 0) {
            handleImportFile(e.target.files[0]);
        }
    };

    // 客户端预解析 TXT
    function handleImportFile(file) {
        if (!file) return;
        pendingImportFile = file;

        const reader = new FileReader();
        reader.onload = function (e) {
            const text = e.target.result;
            parseAndPreview(text);
        };
        // 尝试用 GBK 读取 (浏览器默认支持)
        reader.readAsText(file, 'GBK');
    }

    function parseAndPreview(text) {
        const lines = text.split(/\r?\n/).filter(l => l.trim());
        const positions = [];
        let cash = 0;
        let totalAsset = 0;

        // 解析第一行汇总 (V24.1: 对齐后端, 优先提取「余额」含冻结资金)
        let cashAvailable = 0;
        if (lines.length > 0) {
            const balanceMatch = lines[0].match(/余额[:：\s]*([0-9,.]+)/);
            const availMatch = lines[0].match(/可用[:：\s]*([0-9,.]+)/);
            const assetMatch = lines[0].match(/资产[:：\s]*([0-9,.]+)/);
            if (balanceMatch) cash = parseFloat(balanceMatch[1].replace(/,/g, ''));
            else if (availMatch) cash = parseFloat(availMatch[1].replace(/,/g, ''));
            if (availMatch) cashAvailable = parseFloat(availMatch[1].replace(/,/g, ''));
            if (assetMatch) totalAsset = parseFloat(assetMatch[1].replace(/,/g, ''));
        }

        // 找列头行
        let headerIdx = -1;
        for (let i = 0; i < lines.length; i++) {
            if (lines[i].includes('证券代码')) { headerIdx = i; break; }
        }

        if (headerIdx < 0) {
            showToast('未检测到有效的列头行（需含"证券代码"关键字）', 'error');
            return;
        }

        // 解析列头
        const headerParts = lines[headerIdx].split(/\s+/).filter(Boolean);
        const colMap = {};
        const targets = {
            '证券代码': 'code', '证券名称': 'name', '证券数量': 'amount',
            '库存数量': 'amount_alt', '买入均价': 'cost', '参考成本价': 'cost_alt',
            '当前价': 'price', '最新市值': 'mv'
        };
        headerParts.forEach((h, i) => {
            for (const [key, field] of Object.entries(targets)) {
                if (h.includes(key)) { colMap[field] = i; break; }
            }
        });

        // 解析数据行
        for (let i = headerIdx + 1; i < lines.length; i++) {
            const parts = lines[i].split(/\s+/).filter(Boolean);
            if (parts.length < 4 || parts[0].includes('--') || parts[0].includes('合计')) continue;

            const rawCode = parts[colMap.code ?? 0];
            if (!rawCode || !/\d/.test(rawCode)) continue;

            const tsCode = autoSuffix(rawCode);
            const name = parts[colMap.name ?? 1] || '';
            const amtIdx = colMap.amount ?? colMap.amount_alt ?? 2;
            const amount = parseInt(parseFloat((parts[amtIdx] || '0').replace(/,/g, '')));
            if (amount <= 0) continue;

            const costIdx = colMap.cost ?? colMap.cost_alt ?? 5;
            let cost = Math.abs(parseFloat((parts[costIdx] || '0').replace(/,/g, '')));
            const priceIdx = colMap.price ?? 9;
            const price = parseFloat((parts[priceIdx] || '0').replace(/,/g, ''));

            if (cost <= 0) cost = price > 0 ? price : 1;

            positions.push({ tsCode, rawCode, name, amount, cost, price });
        }

        if (positions.length === 0) {
            showToast('未解析到有效持仓数据，请检查文件格式', 'error');
            return;
        }

        // 渲染预览
        importDropzone.style.display = 'none';
        importPreview.style.display = 'block';
        importConfirmBtn.style.display = 'block';
        importWarning.style.display = 'block';
        if (importValZone) importValZone.style.display = 'block';
        if (importStmtDate) {
            const m = String((pendingImportFile && pendingImportFile.name) || '').match(/(20\d{2})(\d{2})(\d{2})/);
            importStmtDate.textContent = m ? `对账单日期 ${m[1]}-${m[2]}-${m[3]}（取自文件名）`
                                           : '文件名无日期（YYYYMMDD）：将不记录历史快照，持仓时点未知';
        }
        syncImportConfirm();

        const totalMV = positions.reduce((s, p) => s + p.amount * p.price, 0);
        const frozenNote = (cashAvailable > 0 && cash > cashAvailable)
            ? `<span class="pf-import-stat-sub" title="可用 ¥${cashAvailable.toLocaleString(undefined,{minimumFractionDigits:2})}，差额为逆回购 / 冻结资金">（可用 ¥${cashAvailable.toLocaleString(undefined,{minimumFractionDigits:0})}）</span>`
            : '';
        importSummary.innerHTML = `
            <div class="pf-import-stats">
                <span class="pf-import-stat">
                    <span class="pf-import-stat-label">检测到</span>
                    <span class="pf-import-stat-value">${positions.length}</span>
                    <span class="pf-import-stat-label">只持仓</span>
                </span>
                <span class="pf-import-stat">
                    <span class="pf-import-stat-label">账户余额</span>
                    <span class="pf-import-stat-value">¥${cash.toLocaleString(undefined, { minimumFractionDigits: 2 })}${frozenNote}</span>
                </span>
                <span class="pf-import-stat">
                    <span class="pf-import-stat-label">持仓市值</span>
                    <span class="pf-import-stat-value">¥${totalMV.toLocaleString(undefined, { minimumFractionDigits: 2 })}</span>
                </span>
                <span class="pf-import-stat">
                    <span class="pf-import-stat-label">总资产</span>
                    <span class="pf-import-stat-value">¥${totalAsset.toLocaleString(undefined, { minimumFractionDigits: 2 })}</span>
                </span>
            </div>
        `;

        importPreviewBody.innerHTML = positions.map(p => {
            const pxCls = pnlClass(p.price - p.cost);   // 现价相对成本: 红涨绿跌, 相等中性
            return `<tr>
                <td>
                    <div class="pf-code-cell">
                        <span class="pf-code-num">${p.rawCode}</span>
                        <span class="pf-code-ext">${p.tsCode.includes('.') ? '.' + p.tsCode.split('.')[1] : ''}</span>
                    </div>
                </td>
                <td class="pf-name-cell">${p.name}</td>
                <td class="pf-mono">${p.amount.toLocaleString()}</td>
                <td class="pf-mono pf-dim">¥${p.cost.toFixed(3)}</td>
                <td class="pf-mono ${pxCls}">¥${p.price.toFixed(3)}</td>
            </tr>`;
        }).join('');
    }

    // 确认导入 → 上传到后端
    importConfirmBtn.onclick = async () => {
        if (!pendingImportFile) {
            showToast('请先选择文件', 'warning');
            return;
        }
        const valuationTime = importValuationTime();
        if (!valuationTime) {
            showToast('请填写估值时点：收盘后导出填 15:00，盘中导出填实际时间', 'warning', 5000);
            if (importValInput) importValInput.focus();
            return;
        }

        importConfirmBtn.disabled = true;
        importConfirmBtn.textContent = '导入中…';

        try {
            const formData = new FormData();
            formData.append('file', pendingImportFile);
            formData.append('valuation_time', valuationTime);

            const res = await AC.secureFetch('/api/v1/portfolio/import', {
                method: 'POST',
                body: formData
            });
            const result = await res.json();

            if (result.status === 'success' && result.data.success) {
                importModal.style.display = 'none';
                showToast(`成功导入 ${result.data.imported} 只持仓，可用资金 ¥${result.data.cash.toLocaleString()}`, 'success', 5000);

                if (result.data.errors && result.data.errors.length > 0) {
                    setTimeout(() => {
                        showToast(`${result.data.errors.length} 条解析警告`, 'warning');
                    }, 1000);
                }

                // 刷新全部数据
                loadPortfolio();
                _broadcastPortfolioChange('import', { count: result.data.imported });

                // 2026-11-03 组合页精简 P4: 删除导入后的调仓路径提示 (其目标取 AIAE 矩阵上限, 不是执行目标)
            } else {
                const errMsg = result.data?.errors?.join('; ') || result.message
                    || (window.AC && AC.errorText ? AC.errorText(result) : '') || '未知错误';
                showToast('导入失败: ' + errMsg, 'error', 6000);
            }
        } catch (err) {
            showToast('网络错误，请重试: ' + err.message, 'error');
        } finally {
            importConfirmBtn.disabled = false;
            importConfirmBtn.textContent = '确认导入';
        }
    };

    // ════════════════════════════════════
    //  清零组合功能
    // ════════════════════════════════════

    const resetBtn = document.getElementById('reset-btn');
    const resetModal = document.getElementById('reset-modal');
    const resetCloseBtn = document.getElementById('reset-close-btn');
    const resetExecBtn = document.getElementById('reset-exec-btn');
    const resetConfirmInput = document.getElementById('reset-confirm-input');
    const resetSummary = document.getElementById('reset-summary');

    // 打开弹窗: 展示当前持仓概要
    resetBtn.onclick = async () => {
        try {
            const res = await fetch('/api/v1/portfolio/valuation');
            const result = await res.json();
            if (result.status === 'success') {
                const d = result.data;
                resetSummary.innerHTML = `
                    <div class="pf-reset-stats">
                        <div class="pf-reset-stat-row">
                            <span class="pf-reset-stat-label">当前持仓</span>
                            <span class="pf-reset-stat-value">${d.position_count || 0} 只</span>
                        </div>
                        <div class="pf-reset-stat-row">
                            <span class="pf-reset-stat-label">持仓市值</span>
                            <span class="pf-reset-stat-value pf-danger">¥${(d.market_value||0).toLocaleString(undefined,{minimumFractionDigits:2})}</span>
                        </div>
                        <div class="pf-reset-stat-row">
                            <span class="pf-reset-stat-label">可用现金</span>
                            <span class="pf-reset-stat-value pf-gold">¥${(d.cash||0).toLocaleString(undefined,{minimumFractionDigits:2})}</span>
                        </div>
                        <div class="pf-reset-stat-row">
                            <span class="pf-reset-stat-label">总资产</span>
                            <span class="pf-reset-stat-value" style="color:#ef4444;">¥${(d.total_asset||0).toLocaleString(undefined,{minimumFractionDigits:2})}</span>
                        </div>
                    </div>`;
            } else {
                resetSummary.innerHTML = '<div style="color:#64748b;text-align:center;padding:20px;">无法加载当前组合数据</div>';
            }
        } catch(e) {
            resetSummary.innerHTML = '<div style="color:#64748b;text-align:center;padding:20px;">数据加载失败</div>';
        }

        resetConfirmInput.value = '';
        resetExecBtn.disabled = true;
        resetModal.style.display = 'flex';
        setTimeout(() => resetConfirmInput.focus(), 100);
    };

    // 2026-11-03 组合页精简 P0: 强确认 = 输入当前总资产 (服务端再核对一次, 相差 > ¥1 拒绝)
    function resetConfirmValue() {
        const v = parseFloat(String(resetConfirmInput.value || '').replace(/[,¥\s]/g, ''));
        return Number.isFinite(v) && v >= 0 ? v : null;
    }
    resetConfirmInput.addEventListener('input', () => {
        resetExecBtn.disabled = resetConfirmValue() === null;
    });

    // 执行清零
    resetExecBtn.onclick = async () => {
        const confirmTotal = resetConfirmValue();
        if (confirmTotal === null) return;

        resetExecBtn.disabled = true;
        resetExecBtn.textContent = '⏳ 清零中...';
        try {
            const res = await AC.secureFetch('/api/v1/portfolio/reset', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ confirm_total_asset: confirmTotal })
            });
            const result = await res.json();
            if (result.status === 'success') {
                resetModal.style.display = 'none';
                showToast(`组合已清零: 共清除 ${result.data.cleared_positions} 只持仓，备份已保存`, 'success', 5000);
                loadPortfolio();
                _broadcastPortfolioChange('reset', { cleared: result.data.cleared_positions });
            } else {
                showToast('清零未执行: ' + (result.message || (window.AC && AC.errorText ? AC.errorText(result) : result.detail) || '未知错误'), 'error', 6000);
            }
        } catch(e) {
            showToast('网络错误: ' + e.message, 'error');
        } finally {
            resetExecBtn.disabled = false;
            resetExecBtn.textContent = '🗑️ 确认清零';
        }
    };

    // 关闭弹窗
    resetCloseBtn.onclick = () => resetModal.style.display = 'none';
    resetModal.addEventListener('click', (e) => {
        if (e.target === resetModal) resetModal.style.display = 'none';
    });

    // ════════════════════════════════════
    //  同步行情数据
    // ════════════════════════════════════

    const syncBtn = document.getElementById('sync-btn');

    syncBtn.onclick = async () => {
        syncBtn.disabled = true;
        syncBtn.textContent = '同步中…';
        syncBtn.classList.add('btn-sync-loading');

        showToast('正在从 Tushare 拉取最新行情数据...', 'info', 4000);

        try {
            const res = await AC.secureFetch('/api/v1/portfolio/sync', { method: 'POST' });
            const result = await res.json();

            if (result.status === 'success' && result.data.success) {
                const d = result.data;
                showToast(
                    stripEmoji(d.message) +
                    (d.failed > 0 ? ` · ${d.failed} 只失败` : '') +
                    (d.freshness?.daily_latest ? ` · 最新: ${d.freshness.daily_latest}` : ''),
                    d.failed > 0 ? 'warning' : 'success',
                    5000
                );
                // 刷新全部数据
                loadPortfolio();
                // 同步后延时重载风控/净值 (行情补齐后图表可能更完整)
                setTimeout(() => {
                    if (pmOn('sector_pie')) loadRisk();
                    if (pmOn('nav_sim') || pmOn('hero_sparkline')) loadNavCurve();
                }, 2500);
            } else {
                showToast('同步失败: ' + (result.message || '未知错误'), 'error');
            }
        } catch (err) {
            showToast('网络错误: ' + err.message, 'error');
        } finally {
            syncBtn.disabled = false;
            syncBtn.textContent = '同步数据';
            syncBtn.classList.remove('btn-sync-loading');
        }
    };

    // ════════════════════════════════════
    //  事件绑定
    // ════════════════════════════════════

    window.quickTrade = (code, name) => {
        document.getElementById('trade-code').value = code;
        document.getElementById('trade-name').value = name;
        tradeAmount.value = '';
        tradePrice.value = '';
        tradeEst.textContent = '¥ 0.00';
        tradeModal.style.display = 'flex';
    };

    openTradeBtn.onclick = () => {
        document.getElementById('trade-code').value = '';
        document.getElementById('trade-name').value = '';
        tradeAmount.value = '';
        tradePrice.value = '';
        tradeEst.textContent = '¥ 0.00';
        tradeModal.style.display = 'flex';
    };

    closeTradeBtn.onclick = () => tradeModal.style.display = 'none';
    buyBtn.onclick = () => doTrade('buy');
    sellBtn.onclick = () => doTrade('sell');

    // 弹窗外部点击关闭
    tradeModal.addEventListener('click', (e) => {
        if (e.target === tradeModal) tradeModal.style.display = 'none';
    });

    // ESC 关闭弹窗
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') {
            if (tradeModal.style.display === 'flex') tradeModal.style.display = 'none';
            if (importModal.style.display === 'flex') importModal.style.display = 'none';
            if (resetModal.style.display === 'flex') resetModal.style.display = 'none';
        }
    });

    // resize 由 AC (alphacore_utils.js) 统一管理

    // ════════════════════════════════════
    //  启动
    // ════════════════════════════════════

    loadPortfolio();

    // 2026-11-04 权威环境 1b: 非权威 (本机) / 状态未知 → 导入、清零、交易按钮禁用并写明"请在服务器导入"
    // (后端同样拒绝; 这里只是提前说明, 不改任何数字)
    if (window.AC && typeof AC.authority === 'function') {
        AC.authority().then((info) => {
            const text = AC.accountWriteBlockedText(info, 'import');
            if (!text) return;
            AC.lockAccountWrites(document.querySelector('.topbar .actions'), info);
            const note = document.getElementById('pf-authority-note');
            if (note) {
                note.textContent = info && info.unknown ? '权威状态未知' : '请在服务器导入';
                note.title = text;
                note.hidden = false;
            }
        });
    }

    // ════════════════════════════════════
    //  通用折叠面板系统 (V24.1)
    // ════════════════════════════════════

    document.querySelectorAll('.pf-collapsible-header[data-toggle]').forEach(header => {
        header.addEventListener('click', (e) => {
            // 不拦截 select/button 点击
            if (e.target.closest('select, button')) return;
            const bodyId = header.getAttribute('data-toggle');
            const body = document.getElementById(bodyId);
            const arrow = header.querySelector('.pf-collapse-arrow');
            const panel = header.closest('.glass-panel');
            if (!body) return;

            const isExpanded = body.classList.contains('pf-expanded');
            body.classList.toggle('pf-expanded', !isExpanded);
            if (arrow) arrow.classList.toggle('pf-arrow-open', !isExpanded);
            if (panel) panel.classList.toggle('pf-panel-collapsed', isExpanded);

            // 展开时触发 echarts resize (图表在 display:none 时尺寸为 0)
            if (!isExpanded) {
                setTimeout(() => {
                    body.querySelectorAll('[id$="-chart"]').forEach(el => {
                        const chart = echarts.getInstanceByDom(el);
                        if (chart) chart.resize();
                    });
                }, 420);
            }
        });
    });

    // 2026-11-04 视觉轮 V3: 手机端 (≤ 768px) 穿透区默认折叠, 桌面保持展开; 合规判定行在折叠区外始终可见
    (function collapseLookthroughOnPhone() {
        const body = document.getElementById('lookthrough-body');
        if (!body || !window.matchMedia || !window.matchMedia('(max-width: 768px)').matches) return;
        body.classList.remove('pf-expanded');
        const header = document.querySelector('[data-toggle="lookthrough-body"]');
        const arrow = header && header.querySelector('.pf-collapse-arrow');
        if (arrow) arrow.classList.remove('pf-arrow-open');
        const panel = body.closest('.glass-panel');
        if (panel) panel.classList.add('pf-panel-collapsed');
    })();

    // 交易记录折叠/展开 (保留旧逻辑, 使用 display:none 而非 max-height)
    const historyToggle = document.getElementById('history-toggle');
    const historyList = document.getElementById('trade-history-list');
    const historyArrow = document.getElementById('history-arrow');
    if (historyToggle) {
        historyToggle.addEventListener('click', () => {
            const isHidden = historyList.style.display === 'none';
            historyList.style.display = isHidden ? 'block' : 'none';
            historyArrow.classList.toggle('pf-arrow-open', isHidden);
        });
    }

    // ════════════════════════════════════
    //  ZONE 6: OMS 滑点归因面板 V2
    // ════════════════════════════════════

    let slipCharts = { trend: null, attr: null, gauge: null };
    let _slipAllOrders = [];

    function initSlippageCharts() {
        const trendEl = document.getElementById('slip-trend-chart');
        const attrEl = document.getElementById('slip-attr-chart');
        const gaugeEl = document.getElementById('slip-eqs-gauge');
        if (trendEl && !slipCharts.trend) slipCharts.trend = AC.registerChart(echarts.init(trendEl));
        if (attrEl && !slipCharts.attr) slipCharts.attr = AC.registerChart(echarts.init(attrEl));
        if (gaugeEl && !slipCharts.gauge) slipCharts.gauge = AC.registerChart(echarts.init(gaugeEl));
    }

    async function loadSlippagePanel() {
        try {
            const [eqsRes, summRes, histRes, attrRes, diagRes, ordRes] = await Promise.all([
                fetch('/api/v1/slippage/quality').then(r => r.json()),
                fetch('/api/v1/slippage/summary').then(r => r.json()),
                fetch('/api/v1/slippage/history?days=30').then(r => r.json()),
                fetch('/api/v1/slippage/attribution').then(r => r.json()),
                fetch('/api/v1/slippage/diagnose').then(r => r.json()),
                fetch('/api/v1/slippage/orders?days=90').then(r => r.json()),
            ]);
            if (eqsRes.status === 'success') { renderSlipEQS(eqsRes.data); }
            if (summRes.status === 'success') renderSlipSummary(summRes.data);
            if (histRes.status === 'success') renderSlipTrend(histRes.data);
            if (attrRes.status === 'success') renderSlipAttribution(attrRes.data);
            if (diagRes.status === 'success') renderSlipDiagnosis(diagRes.data);
            if (ordRes.status === 'success') renderSlipOrders(ordRes.data);
        } catch (err) {
            console.warn('Slippage panel load failed:', err);
        }
    }

    // ── EQS Gauge ──
    function renderSlipEQS(eqs) {
        initSlippageCharts();
        const avgEl = document.getElementById('slip-avg-bps');
        const trendEl = document.getElementById('slip-trend-label');
        const baselineNote = eqs.baseline_count > 0 ? ` (${eqs.baseline_count} 基线)` : '';
        const orderTotal = (eqs.order_count || 0) + (eqs.baseline_count || 0);
        document.getElementById('slip-order-count').textContent = `${orderTotal} 笔订单`;

        if (!eqs.has_data) {
            avgEl.innerHTML = '-- <small>bps</small>';
            trendEl.textContent = '待实盘数据' + baselineNote;
            trendEl.style.color = '#64748b';
            if (slipCharts.gauge) renderEQSGauge(0, '--', false);
            return;
        }
        avgEl.innerHTML = `${eqs.avg_slippage_bps.toFixed(1)} <small>bps</small>`;
        const tl = { improving: '📉 改善', deteriorating: '📈 恶化', stable: '➡️ 稳定', no_data: '--' };
        trendEl.textContent = tl[eqs.trend] || '--';
        trendEl.style.color = eqs.trend === 'improving' ? '#10b981' : eqs.trend === 'deteriorating' ? '#ef4444' : '#64748b';
        if (slipCharts.gauge) renderEQSGauge(eqs.score, eqs.grade, true);
        if (eqs.top_leakers && eqs.top_leakers.length > 0) renderTopLeakers(eqs.top_leakers);
    }

    function renderEQSGauge(score, grade, hasData) {
        const color = score >= 90 ? '#10b981' : score >= 80 ? '#34d399' : score >= 65 ? '#3b82f6' : score >= 50 ? '#f59e0b' : '#ef4444';
        slipCharts.gauge.setOption({
            backgroundColor: 'transparent',
            series: [{
                type: 'gauge', startAngle: 200, endAngle: -20,
                min: 0, max: 100, radius: '95%', center: ['50%', '60%'],
                progress: { show: true, width: 10, itemStyle: { color: hasData ? color : '#334155' } },
                axisLine: { lineStyle: { width: 10, color: [[1, 'rgba(255,255,255,0.04)']] } },
                axisTick: { show: false }, splitLine: { show: false },
                axisLabel: { show: false },
                pointer: { show: false },
                title: { show: true, offsetCenter: [0, '30%'], fontSize: 11, color: hasData ? color : '#475569', fontWeight: 700 },
                detail: {
                    offsetCenter: [0, '-10%'], fontSize: 26, fontWeight: 800,
                    fontFamily: 'Outfit', color: hasData ? '#e2e8f0' : '#475569',
                    formatter: hasData ? '{value}' : '--',
                },
                data: [{ value: hasData ? score : 0, name: hasData ? grade : '待实盘' }],
                animationDuration: 1200, animationEasingUpdate: 'cubicOut',
            }],
        });
    }

    // ── Top Leakers ──
    function renderTopLeakers(leakers) {
        const section = document.getElementById('slip-leakers-section');
        const container = document.getElementById('slip-leakers-bars');
        if (!leakers || leakers.length === 0) { section.style.display = 'none'; return; }
        section.style.display = '';
        const maxCost = Math.max(...leakers.map(l => l.total_cost), 1);
        container.innerHTML = leakers.map(l => {
            const pct = Math.min(100, (l.total_cost / maxCost) * 100);
            return '<div class="slip-leaker-item">' +
                '<div class="slip-leaker-name">' + l.name + ' <small>' + l.ts_code + '</small></div>' +
                '<div class="slip-leaker-bar-wrap"><div class="slip-leaker-bar" style="width:' + pct + '%"></div></div>' +
                '<div class="slip-leaker-bps">' + l.avg_slip_bps + 'bps</div>' +
                '<div class="slip-leaker-cost">¥' + l.total_cost.toLocaleString() + '</div>' +
            '</div>';
        }).join('');
    }

    function renderSlipSummary(stats) {
        const p30 = stats.period_30d || {};
        document.getElementById('slip-total-cost').textContent = '¥ ' + (p30.total_cost || 0).toLocaleString(undefined, {minimumFractionDigits: 2});
        document.getElementById('slip-lifetime-cost').textContent = '历史累计 ¥ ' + ((stats.lifetime && stats.lifetime.total_cost) || 0).toLocaleString(undefined, {minimumFractionDigits: 2});
    }

    // ── Trend Chart + Empty State ──
    function renderSlipTrend(history) {
        initSlippageCharts();
        const emptyEl = document.getElementById('slip-trend-empty');
        if (!history || history.length === 0) {
            if (emptyEl) emptyEl.classList.remove('hidden');
            return;
        }
        if (emptyEl) emptyEl.classList.add('hidden');
        if (!slipCharts.trend) return;
        slipCharts.trend.setOption({
            backgroundColor: 'transparent',
            tooltip: { trigger: 'axis', backgroundColor: 'rgba(15,23,42,0.95)', borderColor: 'rgba(255,255,255,0.08)', textStyle: { color: '#f8fafc', fontSize: 12 } },
            legend: { right: '5%', top: '2%', textStyle: { color: '#94a3b8', fontSize: 11 } },
            grid: { left: '3%', right: '8%', bottom: '3%', top: '18%', containLabel: true },
            xAxis: { type: 'category', data: history.map(function(h) { return h.date.slice(5); }), axisLabel: { color: '#64748b', fontSize: 10 }, axisLine: { lineStyle: { color: 'rgba(255,255,255,0.05)' } } },
            yAxis: [
                { type: 'value', name: 'bps', axisLabel: { color: '#64748b', fontSize: 10 }, splitLine: { lineStyle: { color: 'rgba(255,255,255,0.03)' } } },
                { type: 'value', name: '¥', axisLabel: { color: '#64748b', fontSize: 10 }, splitLine: { show: false } }
            ],
            series: [{
                name: '滑点(bps)', type: 'line', data: history.map(function(h) { return h.avg_slippage_bps || 0; }),
                smooth: true, showSymbol: false, lineStyle: { width: 2.5, color: '#f59e0b' },
                areaStyle: { color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [{offset: 0, color: 'rgba(245,158,11,0.2)'}, {offset: 1, color: 'rgba(245,158,11,0.02)'}]) }
            }, {
                name: '损耗(¥)', type: 'bar', yAxisIndex: 1, data: history.map(function(h) { return h.total_slippage_cny || 0; }),
                itemStyle: { color: 'rgba(239,68,68,0.3)', borderRadius: [4, 4, 0, 0] }, barMaxWidth: 16
            }],
            animationDuration: 1000,
        });
    }

    // ── Attribution Pie + Empty State ──
    function renderSlipAttribution(attr) {
        initSlippageCharts();
        const emptyEl = document.getElementById('slip-attr-empty');
        if (!attr.has_data) { if (emptyEl) emptyEl.classList.remove('hidden'); return; }
        if (emptyEl) emptyEl.classList.add('hidden');

        const mc = document.getElementById('slip-main-cause');
        const dt = document.getElementById('slip-cause-detail');
        if (attr.overnight_gap_pct > attr.intraday_drift_pct) {
            mc.textContent = '隔夜缺口';
            dt.textContent = '占比 ' + attr.overnight_gap_pct.toFixed(0) + '% · ' + attr.avg_overnight_bps.toFixed(1) + 'bps';
        } else {
            mc.textContent = '日内漂移';
            dt.textContent = '占比 ' + attr.intraday_drift_pct.toFixed(0) + '% · ' + attr.avg_intraday_bps.toFixed(1) + 'bps';
        }
        if (!slipCharts.attr) return;
        slipCharts.attr.setOption({
            backgroundColor: 'transparent',
            tooltip: { trigger: 'item', backgroundColor: 'rgba(15,23,42,0.95)', borderColor: 'rgba(255,255,255,0.08)', textStyle: { color: '#f8fafc', fontSize: 12 } },
            legend: { bottom: '5%', textStyle: { color: '#94a3b8', fontSize: 11 } },
            series: [{
                type: 'pie', radius: ['45%', '75%'], center: ['50%', '42%'], avoidLabelOverlap: false,
                itemStyle: { borderRadius: 8, borderColor: 'rgba(15,23,42,0.6)', borderWidth: 3 },
                label: { show: true, formatter: '{b}\n{d}%', color: '#cbd5e1', fontSize: 12 },
                data: [
                    { value: attr.overnight_gap_pct, name: '隔夜缺口', itemStyle: { color: '#f59e0b' } },
                    { value: attr.intraday_drift_pct, name: '日内漂移', itemStyle: { color: '#ef4444' } }
                ],
                animationType: 'scale', animationDuration: 1200
            }],
        });
    }

    function renderSlipDiagnosis(findings) {
        const c = document.getElementById('slip-diag-cards');
        if (!findings || findings.length === 0) {
            c.innerHTML = '<div class="slip-diag-placeholder">暂无诊断结果</div>';
            return;
        }
        var icons = { warning: '⚠️', positive: '✅', info: 'ℹ️' };
        c.innerHTML = findings.map(function(f) {
            var cls = f.severity === 'warning' ? 'diag-warning' : f.severity === 'positive' ? 'diag-positive' : 'diag-info';
            return '<div class="slip-diag-card ' + cls + '">' +
                '<div class="slip-diag-title">' + (icons[f.severity] || '') + ' ' + f.title + '</div>' +
                '<div class="slip-diag-detail">' + f.detail + '</div></div>';
        }).join('');
    }

    // ── Orders Table with source badges + pagination ──
    function renderSlipOrders(orders) {
        _slipAllOrders = orders || [];
        _renderOrderPage(false);
    }

    function _renderOrderPage(showAll) {
        var body = document.getElementById('slip-orders-body');
        var moreWrap = document.getElementById('slip-show-more-wrap');
        var moreBtn = document.getElementById('slip-show-more-btn');
        if (!_slipAllOrders.length) {
            body.innerHTML = '<tr><td colspan="10" class="pf-table-empty">暂无执行记录 — 点击 Bootstrap 回填历史数据</td></tr>';
            if (moreWrap) moreWrap.style.display = 'none';
            return;
        }
        var display = showAll ? _slipAllOrders : _slipAllOrders.slice(0, 20);
        body.innerHTML = display.map(function(o) {
            var sl = o.side === 'buy' ? 'slip-side-buy' : 'slip-side-sell';
            var sd = o.side === 'buy' ? '买入' : o.side === 'sell' ? '卖出' : o.side;
            var bps = o.total_slippage_bps;
            var bc = bps > 0 ? 'slip-bps-positive' : bps < 0 ? 'slip-bps-negative' : 'slip-bps-zero';
            var src = o.exec_source === 'bootstrap' ? '<span class="slip-src-badge slip-src-baseline">BASELINE</span>'
                : o.exec_source === 'broker_import' ? '<span class="slip-src-badge slip-src-import">IMPORT</span>'
                : '<span class="slip-src-badge slip-src-live">LIVE</span>';
            var st = o.status === 'filled' ? '<span class="slip-status-filled">已成交</span>' : '<span class="slip-status-pending">待执行</span>';
            return '<tr>' +
                '<td class="pf-mono" style="font-size:0.82rem">' + (o.order_date || '--') + '</td>' +
                '<td><span style="font-weight:600">' + (o.name || '') + '</span> <span style="color:#475569;font-size:0.72rem">' + o.ts_code + '</span></td>' +
                '<td class="' + sl + '">' + sd + '</td>' +
                '<td class="pf-mono">' + (o.decision_price ? '¥' + o.decision_price.toFixed(3) : '--') + '</td>' +
                '<td class="pf-mono">' + (o.exec_price ? '¥' + o.exec_price.toFixed(3) : '--') + '</td>' +
                '<td class="pf-mono">' + (o.exec_amount ? o.exec_amount.toLocaleString() : '--') + '</td>' +
                '<td class="' + bc + '">' + (bps != null ? bps.toFixed(1) : '--') + '</td>' +
                '<td class="pf-mono" style="color:#f59e0b">' + (o.total_slippage_cny != null ? '¥' + Math.abs(o.total_slippage_cny).toFixed(2) : '--') + '</td>' +
                '<td>' + src + '</td>' +
                '<td>' + st + '</td></tr>';
        }).join('');

        if (_slipAllOrders.length > 20 && !showAll) {
            if (moreWrap) moreWrap.style.display = '';
            if (moreBtn) moreBtn.textContent = '展开全部 ' + _slipAllOrders.length + ' 笔';
        } else {
            if (moreWrap) moreWrap.style.display = 'none';
        }
    }

    // Show more button
    var showMoreBtn = document.getElementById('slip-show-more-btn');
    if (showMoreBtn) showMoreBtn.onclick = function() { _renderOrderPage(true); };

    // Refresh button
    var refreshBtn = document.getElementById('slip-refresh-btn');
    if (refreshBtn) {
        refreshBtn.onclick = function() {
            refreshBtn.classList.add('spinning');
            loadSlippagePanel().finally(function() { setTimeout(function() { refreshBtn.classList.remove('spinning'); }, 500); });
        };
    }

    // Bootstrap button
    var bootstrapBtn = document.getElementById('slippage-bootstrap-btn');
    if (bootstrapBtn) {
        bootstrapBtn.onclick = async function() {
            bootstrapBtn.disabled = true;
            bootstrapBtn.textContent = '⏳ 回填中...';
            try {
                var res = await AC.secureFetch('/api/v1/slippage/bootstrap', { method: 'POST' });
                var result = await res.json();
                if (result.status === 'success') {
                    showToast('Bootstrap: ' + (result.data.created || 0) + ' 笔回填, ' + (result.data.daily_summaries || 0) + ' 日汇总', 'success');
                    loadSlippagePanel();
                } else {
                    showToast((result.data && result.data.message) || 'Bootstrap 跳过', 'info');
                }
            } catch (err) { showToast('Bootstrap 失败', 'error'); }
            bootstrapBtn.disabled = false;
            bootstrapBtn.textContent = '📥 Bootstrap';
        };
    }

    pmReady().then(() => { if (pmOn('slippage')) setTimeout(loadSlippagePanel, 1500); });
});


// ════════════════════════════════════════════════
//  V24.0: Brinson-Fachler 收益归因面板
// ════════════════════════════════════════════════

(function () {
    let brinsonWaterfall = null;
    let brinsonSector = null;

    function fmtPct(v) {
        if (v == null || isNaN(v)) return '--';
        const sign = v >= 0 ? '+' : '';
        return sign + v.toFixed(2) + '%';
    }
    function pctColor(v) { return v > 0 ? '#10b981' : v < 0 ? '#ef4444' : '#94a3b8'; }

    async function loadBrinson() {
        const period = document.getElementById('brinson-period')?.value || 20;
        try {
            const res = await fetch(`/api/v1/portfolio/brinson?days=${period}`);
            const result = await res.json();
            if (result.status === 'success' && result.data?.status === 'success') {
                renderBrinson(result.data);
            } else {
                console.warn('Brinson:', result.data?.error || result.message);
            }
        } catch (err) {
            console.error('Brinson load error:', err);
        }
    }

    function renderBrinson(d) {
        // KPI
        const portEl = document.getElementById('brinson-port-ret');
        const benchEl = document.getElementById('brinson-bench-ret');
        const alphaEl = document.getElementById('brinson-alpha');
        const allocEl = document.getElementById('brinson-alloc');
        const selectEl = document.getElementById('brinson-select');
        const interEl = document.getElementById('brinson-interact');
        const periodLabel = document.getElementById('brinson-period-label');
        const alphaLabel = document.getElementById('brinson-alpha-label');

        if (portEl) { portEl.textContent = fmtPct(d.portfolio_return); portEl.style.color = pctColor(d.portfolio_return); }
        if (benchEl) { benchEl.textContent = fmtPct(d.benchmark_return); }
        if (alphaEl) { alphaEl.textContent = fmtPct(d.excess_return); alphaEl.style.color = pctColor(d.excess_return); }
        if (allocEl) { allocEl.textContent = fmtPct(d.effects.allocation); allocEl.style.color = pctColor(d.effects.allocation); }
        if (selectEl) { selectEl.textContent = fmtPct(d.effects.selection); selectEl.style.color = pctColor(d.effects.selection); }
        if (interEl) { interEl.textContent = fmtPct(d.effects.interaction); interEl.style.color = pctColor(d.effects.interaction); }
        if (periodLabel) { periodLabel.textContent = `近${d.period_days}日`; }
        if (alphaLabel) {
            const desc = d.excess_return >= 0 ? '跑赢基准' : '跑输基准';
            alphaLabel.textContent = desc;
            alphaLabel.style.color = pctColor(d.excess_return);
        }

        renderWaterfall(d);
        renderSectorChart(d);
        renderSectorTable(d);
    }

    function renderWaterfall(d) {
        const el = document.getElementById('brinson-waterfall-chart');
        if (!el) return;
        if (!brinsonWaterfall) brinsonWaterfall = AC.registerChart(echarts.init(el));

        const e = d.effects;
        const cats = ['基准收益', '配置效应', '选股效应', '交互效应', '组合收益'];
        const benchVal = d.benchmark_return;

        // 瀑布图: 用堆叠 bar 模拟
        const transparent = [0, benchVal, benchVal + e.allocation, benchVal + e.allocation + e.selection, 0];
        const values = [benchVal, e.allocation, e.selection, e.interaction, d.portfolio_return];

        brinsonWaterfall.setOption({
            backgroundColor: 'transparent',
            tooltip: {
                trigger: 'axis', axisPointer: { type: 'shadow' },
                backgroundColor: 'rgba(15, 23, 42, 0.95)',
                borderColor: 'rgba(255,255,255,0.08)',
                textStyle: { color: '#f8fafc', fontSize: 12 },
                formatter: p => `<strong>${p[0].axisValue}</strong><br/>贡献: ${p[1]?.value >= 0 ? '+' : ''}${(p[1]?.value || 0).toFixed(3)}%`
            },
            grid: { left: '3%', right: '5%', bottom: '5%', top: '8%', containLabel: true },
            xAxis: {
                type: 'category', data: cats,
                axisLabel: { color: '#cbd5e1', fontSize: 12 },
                axisLine: { lineStyle: { color: 'rgba(255,255,255,0.06)' } }
            },
            yAxis: {
                type: 'value',
                axisLabel: { color: '#64748b', fontSize: 11, fontFamily: 'Outfit', formatter: v => v.toFixed(1) + '%' },
                splitLine: { lineStyle: { color: 'rgba(255,255,255,0.03)' } }
            },
            series: [
                {
                    name: 'base', type: 'bar', stack: 'w', data: transparent.map(v => Math.max(0, v)),
                    itemStyle: { color: 'transparent' }, emphasis: { itemStyle: { color: 'transparent' } }
                },
                {
                    name: '贡献', type: 'bar', stack: 'w', data: values,
                    itemStyle: {
                        color: p => {
                            if (p.dataIndex === 0 || p.dataIndex === 4) return 'rgba(99,102,241,0.8)';
                            return p.value >= 0 ? 'rgba(16,185,129,0.8)' : 'rgba(239,68,68,0.8)';
                        },
                        borderRadius: [4, 4, 0, 0]
                    },
                    barMaxWidth: 48,
                    label: {
                        show: true, position: 'top',
                        formatter: p => (p.value >= 0 ? '+' : '') + p.value.toFixed(2) + '%',
                        color: '#e2e8f0', fontSize: 11, fontFamily: 'Outfit'
                    }
                }
            ],
            animationDuration: 1000, animationEasing: 'cubicOut'
        });
    }

    function renderSectorChart(d) {
        const el = document.getElementById('brinson-sector-chart');
        if (!el) return;
        if (!brinsonSector) brinsonSector = AC.registerChart(echarts.init(el));

        // Top 10 sectors by absolute total_effect
        const sectors = d.sector_detail.slice(0, 10).reverse();

        brinsonSector.setOption({
            backgroundColor: 'transparent',
            tooltip: {
                trigger: 'axis', axisPointer: { type: 'shadow' },
                backgroundColor: 'rgba(15, 23, 42, 0.95)',
                borderColor: 'rgba(255,255,255,0.08)',
                textStyle: { color: '#f8fafc', fontSize: 12 },
                formatter: p => {
                    const s = sectors[p[0].dataIndex];
                    return `<strong>${s.sector}</strong><br/>
                        组合权重: ${s.portfolio_weight}%<br/>
                        基准权重: ${s.benchmark_weight}%<br/>
                        超配: ${s.weight_diff > 0 ? '+' : ''}${s.weight_diff}pp<br/>
                        总效应: ${s.total_effect > 0 ? '+' : ''}${s.total_effect}%`;
                }
            },
            grid: { left: '3%', right: '8%', bottom: '5%', top: '5%', containLabel: true },
            xAxis: {
                type: 'value',
                axisLabel: { color: '#64748b', fontFamily: 'Outfit', fontSize: 11, formatter: v => v.toFixed(2) + '%' },
                splitLine: { lineStyle: { color: 'rgba(255,255,255,0.03)' } }
            },
            yAxis: {
                type: 'category', data: sectors.map(s => s.sector),
                axisLabel: { color: '#cbd5e1', fontWeight: 500, fontSize: 12 },
                axisLine: { lineStyle: { color: 'rgba(255,255,255,0.06)' } }
            },
            series: [{
                name: '总效应', type: 'bar',
                data: sectors.map(s => s.total_effect),
                itemStyle: {
                    color: p => p.value >= 0 ? 'rgba(16,185,129,0.8)' : 'rgba(239,68,68,0.75)',
                    borderRadius: [0, 6, 6, 0]
                },
                barMaxWidth: 18,
                label: {
                    show: true, position: 'right',
                    formatter: p => (p.value >= 0 ? '+' : '') + p.value.toFixed(3) + '%',
                    color: '#94a3b8', fontSize: 10, fontFamily: 'Outfit'
                }
            }],
            animationDuration: 1000, animationEasing: 'cubicOut'
        });
    }

    // 板块归因明细: 持仓板块全部显示, 纯基准板块默认折叠
    let _sectorExpanded = false;

    function renderSectorTable(d) {
        const body = document.getElementById('brinson-sector-body');
        if (!body) return;

        if (!d.sector_detail || d.sector_detail.length === 0) {
            body.innerHTML = '<tr><td colspan="11" class="pf-table-empty">无板块归因数据</td></tr>';
            _hideSectorToggle();
            return;
        }

        _sectorExpanded = false;

        // F3: 阈值与后端精度对齐 (后端 round(wp*100, 2) 最小非零=0.01%)
        const HOLD_THRESHOLD = 0.005;

        // 分离持仓板块 vs 纯基准板块
        const holdingSectors = d.sector_detail.filter(s => s.portfolio_weight > HOLD_THRESHOLD);
        const benchOnlySectors = d.sector_detail.filter(s => s.portfolio_weight <= HOLD_THRESHOLD);

        holdingSectors.sort((a, b) => Math.abs(b.total_effect) - Math.abs(a.total_effect));
        benchOnlySectors.sort((a, b) => Math.abs(b.total_effect) - Math.abs(a.total_effect));

        const allSorted = [...holdingSectors, ...benchOnlySectors];

        const rowsHtml = allSorted.map((s, i) => {
            const wdClass = s.weight_diff > 0 ? 'pf-up' : s.weight_diff < 0 ? 'pf-danger' : '';
            const teClass = s.total_effect > 0 ? 'pf-up' : s.total_effect < 0 ? 'pf-danger' : '';
            const isBenchOnly = s.portfolio_weight <= HOLD_THRESHOLD;
            const isCollapsed = isBenchOnly;
            const rowCls = isCollapsed ? ' class="brinson-collapsed-row"' : '';
            const hasHolding = s.portfolio_weight > HOLD_THRESHOLD;

            const interactionEffect = s.interaction_effect !== undefined
                ? s.interaction_effect
                : (s.total_effect - s.allocation_effect - s.selection_effect);

            // F2: 非基准板块(wb=0)的配置效应添加 tooltip
            const isNonBench = s.benchmark_weight <= 0.05 && hasHolding;
            const allocTooltip = isNonBench
                ? ` title="非基准板块: 配置+交互合计 = ${(s.allocation_effect + interactionEffect).toFixed(3)}% (板块全部贡献)"`
                : '';
            const allocCell = `<td class="pf-mono"${allocTooltip} style="color:${pctColor(s.allocation_effect)}">${s.allocation_effect.toFixed(3)}%</td>`;

            const selectCell = hasHolding
                ? `<td class="pf-mono" style="color:${pctColor(s.selection_effect)}">${s.selection_effect.toFixed(3)}%</td>`
                : `<td class="pf-mono pf-dim" style="opacity:0.4">—</td>`;

            const interactCell = hasHolding
                ? `<td class="pf-mono" style="color:${pctColor(interactionEffect)}">${interactionEffect.toFixed(3)}%</td>`
                : `<td class="pf-mono pf-dim" style="opacity:0.4">—</td>`;

            // F5: 基准收益 + 板块超额
            const benchReturn = s.benchmark_return !== undefined ? s.benchmark_return : 0;
            const returnDiff = s.return_diff !== undefined ? s.return_diff : (s.portfolio_return - benchReturn);
            const benchReturnCell = `<td class="pf-mono pf-dim">${fmtPct(benchReturn)}</td>`;
            const returnDiffCell = hasHolding
                ? `<td class="pf-mono" style="color:${pctColor(returnDiff)};font-weight:600">${fmtPct(returnDiff)}</td>`
                : `<td class="pf-mono pf-dim" style="opacity:0.4">—</td>`;

            const nameStyle = isBenchOnly ? 'color:#64748b;font-weight:400' : '';

            return `<tr${rowCls}>
                <td><span class="brinson-row-idx">${i + 1}</span><strong style="${nameStyle}">${s.sector}</strong></td>
                <td class="pf-mono">${s.portfolio_weight.toFixed(1)}%</td>
                <td class="pf-mono pf-dim">${s.benchmark_weight.toFixed(1)}%</td>
                <td class="pf-mono ${wdClass}">${s.weight_diff > 0 ? '+' : ''}${s.weight_diff.toFixed(1)}pp</td>
                <td class="pf-mono" style="color:${pctColor(s.portfolio_return)}">${hasHolding ? fmtPct(s.portfolio_return) : '<span style="opacity:0.4">—</span>'}</td>
                ${benchReturnCell}
                ${returnDiffCell}
                ${allocCell}
                ${selectCell}
                ${interactCell}
                <td class="pf-mono ${teClass}" style="font-weight:600">${s.total_effect > 0 ? '+' : ''}${s.total_effect.toFixed(3)}%</td>
            </tr>`;
        }).join('');

        // F4: 汇总行 — BHB 加法恒等式验证
        const eff = d.effects || {};
        const sumAlloc = eff.allocation || 0;
        const sumSelect = eff.selection || 0;
        const sumInteract = eff.interaction || 0;
        const sumTotal = eff.total || (sumAlloc + sumSelect + sumInteract);
        const excess = d.excess_return || 0;

        // 检查闭合: Σ效应 ≈ 超额
        const residual = Math.abs(sumTotal - excess);
        const closureOk = residual < 0.05;
        const closureIcon = closureOk ? '✓' : '≈';
        const closureColor = closureOk ? '#10b981' : '#f59e0b';

        const summaryRow = `<tr class="brinson-summary-row">
            <td colspan="7" style="text-align:right;font-weight:700;color:#94a3b8;font-size:0.78rem;padding-right:12px;">
                Σ 合计 <span style="font-size:0.65rem;color:${closureColor};margin-left:4px;" title="Σ效应 ${closureOk ? '=' : '≈'} 超额收益 (残差 ${residual.toFixed(3)}%)">${closureIcon} ${closureOk ? '闭合' : '残差 ' + residual.toFixed(3) + '%'}</span>
            </td>
            <td class="pf-mono" style="color:${pctColor(sumAlloc)};font-weight:700">${sumAlloc > 0 ? '+' : ''}${sumAlloc.toFixed(3)}%</td>
            <td class="pf-mono" style="color:${pctColor(sumSelect)};font-weight:700">${sumSelect > 0 ? '+' : ''}${sumSelect.toFixed(3)}%</td>
            <td class="pf-mono" style="color:${pctColor(sumInteract)};font-weight:700">${sumInteract > 0 ? '+' : ''}${sumInteract.toFixed(3)}%</td>
            <td class="pf-mono" style="font-weight:800;font-size:0.88rem;color:${pctColor(sumTotal)}">${sumTotal > 0 ? '+' : ''}${sumTotal.toFixed(3)}%</td>
        </tr>`;

        body.innerHTML = rowsHtml + summaryRow;

        // 折叠控制
        const toggleWrap = document.getElementById('brinson-sector-toggle-wrap');
        if (benchOnlySectors.length > 0 && toggleWrap) {
            toggleWrap.style.display = '';
            const btn = document.getElementById('brinson-sector-toggle-btn');
            if (btn) btn.innerHTML = `<span class="brinson-toggle-icon">▼</span> 展开 ${benchOnlySectors.length} 个基准板块 (未持仓)`;
        } else {
            _hideSectorToggle();
        }
    }

    function _hideSectorToggle() {
        const wrap = document.getElementById('brinson-sector-toggle-wrap');
        if (wrap) wrap.style.display = 'none';
    }

    function _toggleSectorRows() {
        _sectorExpanded = !_sectorExpanded;
        const rows = document.querySelectorAll('.brinson-collapsed-row');
        const btn = document.getElementById('brinson-sector-toggle-btn');
        rows.forEach(r => r.style.display = _sectorExpanded ? 'table-row' : 'none');
        if (btn) {
            const count = rows.length;
            btn.innerHTML = _sectorExpanded
                ? '<span class="brinson-toggle-icon brinson-toggle-open">▲</span> 收起基准板块'
                : `<span class="brinson-toggle-icon">▼</span> 展开 ${count} 个基准板块 (未持仓)`;

        }
    }

    // 初始化折叠行隐藏 (MutationObserver 不需要, renderSectorTable 调用后 DOM 已就绪)
    // 绑定按钮事件 (按钮在 HTML 中静态存在)
    document.addEventListener('DOMContentLoaded', () => {
        const btn = document.getElementById('brinson-sector-toggle-btn');
        if (btn) btn.addEventListener('click', _toggleSectorRows);
    });
    // 也立即尝试绑定（DOMContentLoaded 可能已触发）
    const _stBtn = document.getElementById('brinson-sector-toggle-btn');
    if (_stBtn) _stBtn.addEventListener('click', _toggleSectorRows);

    // Bind events
    const refreshBtn = document.getElementById('brinson-refresh-btn');
    if (refreshBtn) {
        refreshBtn.onclick = () => {
            refreshBtn.classList.add('spinning');
            loadBrinson().finally(() => setTimeout(() => refreshBtn.classList.remove('spinning'), 500));
        };
    }

    const periodSelect = document.getElementById('brinson-period');
    if (periodSelect) {
        periodSelect.onchange = () => loadBrinson();
    }

    // Auto-load after portfolio data
    pmReady().then(() => { if (pmOn('brinson')) setTimeout(loadBrinson, 2500); });

    // Resize
    window.addEventListener('resize', () => {
        if (brinsonWaterfall) brinsonWaterfall.resize();
        if (brinsonSector) brinsonSector.resize();
    });
})();


// ════════════════════════════════════════════════
//  V24.0: 多因子风险归因面板
// ════════════════════════════════════════════════

(function () {
    let factorRadar = null;
    let factorContrib = null;

    function fmtPct(v) {
        if (v == null || isNaN(v)) return '--';
        return (v >= 0 ? '+' : '') + v.toFixed(2) + '%';
    }
    function pctColor(v) { return v > 0 ? '#10b981' : v < 0 ? '#ef4444' : '#94a3b8'; }

    // Heatmap color: 0 → blue, 0.5 → neutral, 1 → green
    function heatColor(v) {
        if (v > 0.7) return 'rgba(16,185,129,0.25)';
        if (v > 0.5) return 'rgba(16,185,129,0.1)';
        if (v < 0.3) return 'rgba(239,68,68,0.2)';
        if (v < 0.5) return 'rgba(239,68,68,0.08)';
        return 'transparent';
    }
    function scoreLabel(v) {
        if (v >= 0.8) return '极高';
        if (v >= 0.6) return '偏高';
        if (v >= 0.4) return '中性';
        if (v >= 0.2) return '偏低';
        return '极低';
    }

    async function loadFactorAttr() {
        const period = document.getElementById('factor-period')?.value || 60;
        try {
            const res = await fetch(`/api/v1/portfolio/factor-attribution?days=${period}`);
            const result = await res.json();
            if (result.status === 'success' && result.data?.status === 'success') {
                renderFactorAttr(result.data);
            } else {
                console.warn('FactorAttr:', result.data?.error || result.message);
            }
        } catch (err) {
            console.error('FactorAttr load error:', err);
        }
    }

    function renderFactorAttr(d) {
        // KPI
        const r2El = document.getElementById('factor-r2');
        const r2Label = document.getElementById('factor-r2-label');
        const alphaEl = document.getElementById('factor-alpha');
        const alphaLabel = document.getElementById('factor-alpha-label');
        const sysEl = document.getElementById('factor-systematic');
        const betaEl = document.getElementById('factor-beta');

        if (r2El) {
            r2El.textContent = d.regression.r_squared_pct + '%';
            r2El.style.color = d.regression.r_squared > 0.6 ? '#10b981' : d.regression.r_squared > 0.3 ? '#f59e0b' : '#ef4444';
        }
        if (r2Label) {
            const q = d.regression.r_squared > 0.7 ? '高解释力' : d.regression.r_squared > 0.4 ? '中等解释力' : '低解释力';
            r2Label.textContent = q + ' · ' + d.lookback_days + '日窗口';
        }
        if (alphaEl) {
            alphaEl.textContent = fmtPct(d.regression.alpha_annual);
            alphaEl.style.color = pctColor(d.regression.alpha_annual);
        }
        if (alphaLabel) {
            alphaLabel.textContent = `日均 ${d.regression.alpha_daily} bps`;
        }
        if (sysEl) {
            sysEl.textContent = d.portfolio_decomposition.systematic_pct + '%';
            sysEl.style.color = d.portfolio_decomposition.systematic_pct > 70 ? '#ef4444' : '#10b981';
        }
        if (betaEl) {
            const mktFactor = d.factors.find(f => f.name === 'market');
            if (mktFactor) {
                betaEl.textContent = mktFactor.beta.toFixed(3);
                betaEl.style.color = mktFactor.beta > 1.1 ? '#ef4444' : mktFactor.beta < 0.8 ? '#3b82f6' : '#6366f1';
            }
        }

        renderRadar(d);
        renderContrib(d);
        renderStockTable(d);
    }

    function renderRadar(d) {
        const el = document.getElementById('factor-radar-chart');
        if (!el) return;
        if (!factorRadar) factorRadar = AC.registerChart(echarts.init(el));

        const factors = d.factors;
        // 统一 max=2.0, 保证各因子轴刻度一致且低暴露因子仍可见
        const indicators = factors.map(f => ({
            name: f.icon + ' ' + f.cn,
            max: 2.0,
        }));
        const values = factors.map(f => Math.abs(f.beta));

        factorRadar.setOption({
            backgroundColor: 'transparent',
            tooltip: {
                backgroundColor: 'rgba(15, 23, 42, 0.95)',
                borderColor: 'rgba(255,255,255,0.08)',
                textStyle: { color: '#f8fafc', fontSize: 12 },
            },
            radar: {
                indicator: indicators,
                shape: 'polygon',
                radius: '65%',
                axisName: { color: '#cbd5e1', fontSize: 12 },
                axisLine: { lineStyle: { color: 'rgba(255,255,255,0.08)' } },
                splitLine: { lineStyle: { color: 'rgba(255,255,255,0.05)' } },
                splitArea: { areaStyle: { color: ['rgba(99,102,241,0.02)', 'rgba(99,102,241,0.05)'] } },
            },
            series: [{
                type: 'radar',
                data: [{
                    value: values,
                    name: 'Factor Beta',
                    areaStyle: { color: 'rgba(99,102,241,0.2)' },
                    lineStyle: { color: '#6366f1', width: 2 },
                    itemStyle: { color: '#6366f1' },
                    symbol: 'circle', symbolSize: 6,
                }],
                tooltip: {
                    formatter: p => {
                        let html = '<strong>因子载荷 (|β|)</strong>';
                        factors.forEach((f, i) => {
                            html += `<br/>${f.icon} ${f.cn}: ${f.beta.toFixed(4)} (${f.exposure_level === 'high' ? '⚠️高暴露' : f.exposure_level === 'low' ? '✅低暴露' : '中性'})`;
                        });
                        return html;
                    }
                }
            }],
            animationDuration: 1200, animationEasing: 'elasticOut'
        });
    }

    function renderContrib(d) {
        const el = document.getElementById('factor-contrib-chart');
        if (!el) return;
        if (!factorContrib) factorContrib = AC.registerChart(echarts.init(el));

        const factors = [...d.factors].reverse();

        factorContrib.setOption({
            backgroundColor: 'transparent',
            tooltip: {
                trigger: 'axis', axisPointer: { type: 'shadow' },
                backgroundColor: 'rgba(15, 23, 42, 0.95)',
                borderColor: 'rgba(255,255,255,0.08)',
                textStyle: { color: '#f8fafc', fontSize: 12 },
                formatter: p => {
                    const f = factors[p[0].dataIndex];
                    return `<strong>${f.icon} ${f.cn}</strong><br/>
                        Beta: ${f.beta.toFixed(4)}<br/>
                        因子年化收益: ${f.factor_return}%<br/>
                        期间贡献: ${f.contribution > 0 ? '+' : ''}${f.contribution}%<br/>
                        暴露等级: ${f.exposure_level === 'high' ? '⚠️高' : f.exposure_level === 'low' ? '✅低' : '中性'}`;
                }
            },
            grid: { left: '3%', right: '10%', bottom: '5%', top: '5%', containLabel: true },
            xAxis: {
                type: 'value',
                axisLabel: { color: '#64748b', fontFamily: 'Outfit', fontSize: 11, formatter: v => v.toFixed(2) + '%' },
                splitLine: { lineStyle: { color: 'rgba(255,255,255,0.03)' } }
            },
            yAxis: {
                type: 'category', data: factors.map(f => f.icon + ' ' + f.cn),
                axisLabel: { color: '#cbd5e1', fontWeight: 500, fontSize: 12 },
                axisLine: { lineStyle: { color: 'rgba(255,255,255,0.06)' } }
            },
            series: [{
                name: '贡献', type: 'bar',
                data: factors.map(f => f.contribution),
                itemStyle: {
                    // 方向色: 绿正红负, 不用因子品牌色 (品牌色保留给雷达图)
                    color: p => p.value >= 0 ? 'rgba(16,185,129,0.8)' : 'rgba(239,68,68,0.75)',
                    borderRadius: [0, 6, 6, 0]
                },
                barMaxWidth: 22,
                label: {
                    show: true, position: 'right',
                    formatter: p => (p.value >= 0 ? '+' : '') + p.value.toFixed(3) + '%',
                    color: '#94a3b8', fontSize: 10, fontFamily: 'Outfit'
                }
            }],
            animationDuration: 1000, animationEasing: 'cubicOut'
        });
    }

    function renderStockTable(d) {
        const body = document.getElementById('factor-stock-body');
        if (!body) return;

        if (!d.stock_exposures || d.stock_exposures.length === 0) {
            body.innerHTML = '<tr><td colspan="6" class="pf-table-empty">无个股因子数据</td></tr>';
            return;
        }

        body.innerHTML = d.stock_exposures.map(s => {
            return `<tr>
                <td><strong>${s.name}</strong> <span class="pf-dim" style="font-size:0.72rem">${s.ts_code}</span></td>
                <td class="pf-mono">${s.weight.toFixed(1)}%</td>
                <td><span class="pf-sector-tag">${s.industry}</span></td>
                <td class="pf-mono" style="background:${heatColor(s.momentum)}">${scoreLabel(s.momentum)} <small style="opacity:0.6">${(s.momentum * 100).toFixed(0)}%</small></td>
                <td class="pf-mono" style="background:${heatColor(1 - s.volatility)}" title="低波偏好: 越高表示该标的波动率越低">${scoreLabel(1 - s.volatility)} <small style="opacity:0.6">${((1 - s.volatility) * 100).toFixed(0)}%</small></td>
                <td class="pf-mono" style="background:${heatColor(s.quality)}">${scoreLabel(s.quality)} <small style="opacity:0.6">${(s.quality * 100).toFixed(0)}%</small></td>
            </tr>`;
        }).join('');
    }

    // Bind events
    const refreshBtn = document.getElementById('factor-refresh-btn');
    if (refreshBtn) {
        refreshBtn.onclick = () => {
            refreshBtn.classList.add('spinning');
            loadFactorAttr().finally(() => setTimeout(() => refreshBtn.classList.remove('spinning'), 500));
        };
    }

    const periodSelect = document.getElementById('factor-period');
    if (periodSelect) {
        periodSelect.onchange = () => loadFactorAttr();
    }

    // Auto-load after Brinson
    pmReady().then(() => { if (pmOn('factor')) setTimeout(loadFactorAttr, 3500); });

    // Resize
    window.addEventListener('resize', () => {
        if (factorRadar) factorRadar.resize();
        if (factorContrib) factorContrib.resize();
    });
})();
