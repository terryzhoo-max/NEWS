/**
 * 组合页持仓表展示 (2026-11-04 视觉轮 V2, docs/PORTFOLIO_SLIMMING_PLAN.md 10.3 / 10.5)
 * ============================================================================
 * 纯展示函数, 只读 /portfolio/valuation 已有字段, 不改任何数字:
 *   - 默认按市值降序 (只改显示顺序)
 *   - 类型标签 ETF / 科创 / 创业 / 主板 / 北交 (接口无类型字段, 按代码前缀判断, 规则见 10.5)
 *   - 价格精度: ETF 成本价 / 现价 3 位, 其余 2 位
 *   - 仓位占比条: 中性色, 以最大持仓为满格; weight 缺失显示 "--"
 *   - 浮动盈亏: 金额与百分比同色, 红涨绿跌, 0 中性 (不整行着色)
 *   - 价格来源: 成本价兜底 = warn 标签 (市值与盈亏不真实); 券商 / 收盘价 = info 小字 (2026-11-04 起显示中文)
 */
(function (root) {
    'use strict';

    function esc(s) {
        return String(s == null ? '' : s).replace(/[&<>"']/g, c => (
            { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
    }
    const num = v => (typeof v === 'number' && Number.isFinite(v) ? v : null);

    /** 代码 → 类型标签 (展示用)。 */
    function instrumentType(tsCode) {
        const [code = '', ex = ''] = String(tsCode || '').toUpperCase().split('.');
        if (!/^\d{6}$/.test(code)) return null;
        if ((ex === 'SH' && code[0] === '5') || (ex === 'SZ' && /^1[56]/.test(code))) return 'ETF';
        if (ex === 'BJ' || /^(4|8|920)/.test(code)) return '北交';
        if (/^68[89]/.test(code)) return '科创';
        if (/^30[01]/.test(code)) return '创业';
        if (/^(60[0135]|00[0-3])/.test(code)) return '主板';
        return null;
    }
    const isEtf = tsCode => instrumentType(tsCode) === 'ETF';
    /** 价格文本: ETF 3 位, 其余 2 位; 缺失 "--"。 */
    function priceText(v, tsCode) {
        const n = num(v);
        return n === null ? '--' : n.toFixed(isEtf(tsCode) ? 3 : 2);
    }
    const money = v => (num(v) === null ? '--' : v.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 }));
    const signed = (v, s) => `${v > 0 ? '+' : ''}${s}`;

    /** 涨跌语义类: 正 → ac-up (红), 负 → ac-down (绿), 0 / 缺失 → ac-flat。 */
    function pnlClass(v) {
        const n = num(Number(v));
        if (v == null || n === null || n === 0) return 'ac-flat';
        return n > 0 ? 'ac-up' : 'ac-down';
    }

    /** 按市值降序 (不改原数组)。 */
    function sortByMarketValue(positions) {
        return (positions || []).slice().sort((a, b) => (num(b.market_value) ?? -Infinity) - (num(a.market_value) ?? -Infinity));
    }
    /** 占比条比例尺: 以最大持仓为满格。 */
    function maxWeight(positions) {
        return (positions || []).reduce((m, p) => Math.max(m, num(p.weight) ?? 0), 0);
    }
    function barWidth(weight, maxW) {
        const w = num(weight);
        if (w === null || !(maxW > 0)) return null;
        return Math.max(0, Math.min(100, w / maxW * 100));
    }

    const SRC = {
        cost: '<span class="ac-tag ac-tag-warn pf-src-cost" title="现价缺失，以成本价兜底：市值与盈亏不真实">成本价兜底</span>',
        broker: '<span class="pf-src-tag" title="导入当日券商报价">券商</span>',
        tushare: '<span class="pf-src-tag" title="Tushare 收盘价">收盘价</span>',
    };
    function sourceTag(src) { return SRC[src] || SRC.tushare; }

    function weightCell(p, maxW) {
        const w = num(p.weight);
        if (w === null) return '<td class="num pf-weight-td"><span class="pf-weight-num">--</span></td>';
        const width = barWidth(w, maxW);
        return `<td class="num pf-weight-td"><div class="pf-weight-cell"><span class="pf-weight-num">${w.toFixed(1)}%</span>` +
            `<div class="pf-weight-bar"><div class="pf-weight-fill" style="width:${width.toFixed(1)}%"></div></div></div></td>`;
    }

    // ── 跟踪止盈状态 (2026-11-04 复核后加, 只读) ──
    // 读决策中枢跟踪止盈面板同一接口 /api/v1/portfolio/trailing-stops 的 positions[].status, 前端不判定。
    // 只写状态, 不写操作 ("卖出 / 止盈"等留给决策中枢); 止损已触发是真实的禁止状态 → 阻断实底 + 文字。
    // 点击跳决策中枢跟踪止盈面板 (唯一止损执行入口)。
    const TRAIL = {
        RED:     { cls: 'ac-tag ac-tag-block',  text: '止损已触发' },
        LEGACY:  { cls: 'ac-tag ac-tag-legacy', text: '遗留越线' },
        YELLOW:  { cls: 'ac-tag ac-tag-warn',   text: '临近止损线' },
        ACTION:  { cls: 'ac-tag ac-tag-info',   text: '到达止盈档' },
        GREEN:   { cls: 'pf-trail-ok',          text: '正常' },
        NO_DATA: { cls: 'pf-trail-na',          text: '无行情' },
    };
    const TRAIL_HREF = 'decision.html#trailing-stop-panel';
    /** trail: undefined = 加载中; null = 读取失败; {code: status} = 读到。 */
    function trailHtml(tsCode, trail) {
        if (trail === undefined) return '<span class="pf-trail-na">…</span>';
        if (trail === null) return '<span class="pf-trail-na" title="跟踪止盈读取失败，以决策中枢为准">--</span>';
        const s = trail[tsCode];
        const m = TRAIL[s];
        if (!m) return '<span class="pf-trail-na" title="跟踪止盈无此持仓">--</span>';
        return `<a class="pf-trail-link" href="${TRAIL_HREF}" title="跟踪止盈：${esc(s)}，在决策中枢查看"><span class="${m.cls}">${m.text}</span></a>`;
    }
    const isAlertTrail = (tsCode, trail) => !!(trail && ['RED', 'LEGACY', 'YELLOW', 'ACTION'].includes(trail[tsCode]));

    /** 一行持仓 (桌面表格)。 */
    function positionRowHtml(p, maxW, trail) {
        const [code, ex = ''] = String(p.ts_code || '').split('.');
        const type = instrumentType(p.ts_code);
        const cls = pnlClass(p.pnl);
        const pnl = num(p.pnl), pct = num(p.pnl_pct);
        return `<tr data-code="${esc(p.ts_code)}">
            <td><div class="pf-code-cell"><span class="pf-code-num">${esc(code)}</span><span class="pf-code-ext">.${esc(ex)}</span></div></td>
            <td><div class="pf-name-cell">${esc(p.name)}${type ? ` <span class="pf-type-tag">${type}</span>` : ''}</div>
                <span class="pf-sector-tag">${esc(p.industry || '行业未知')}</span></td>
            <td class="num pf-mono">${num(p.amount) === null ? '--' : p.amount.toLocaleString('en-US')}</td>
            <td class="num pf-mono pf-dim">${priceText(p.cost, p.ts_code)}</td>
            <td class="num pf-mono">${priceText(p.price, p.ts_code)}${sourceTag(p.price_source)}</td>
            <td class="num pf-mono">${money(p.market_value)}</td>
            ${weightCell(p, maxW)}
            <td class="num pf-pnl-cell ${cls}"><span class="pf-pnl-val">${pnl === null ? '--' : signed(pnl, money(pnl))}</span>` +
            `<span class="pf-pnl-pct">${pct === null ? '--' : signed(pct, `${pct.toFixed(2)}%`)}</span></td>
            <td class="pf-trail-td">${trailHtml(p.ts_code, trail)}</td>
        </tr>`;
    }

    /** 持仓表 tbody (按市值降序)。 */
    function positionsBodyHtml(positions, trail) {
        const rows = sortByMarketValue(positions);
        if (!rows.length) return '<tr><td colspan="9" class="pf-table-empty">当前无持仓</td></tr>';
        const maxW = maxWeight(rows);
        return rows.map(p => positionRowHtml(p, maxW, trail)).join('');
    }

    /** KPI 来源行: 持仓市值 / 现金。 */
    function kpiSources(data) {
        const d = data || {};
        const dates = (d.positions || []).map(p => String(p.price_as_of || '').replace(/-/g, '')).filter(x => x.length >= 8).sort();
        const px = dates.length ? dates[dates.length - 1] : '';
        const stmt = String(d.statement_date || '');
        return {
            mv: px ? `价格 ${px.slice(4, 6)}-${px.slice(6, 8)} 收盘` : '价格日期未知',
            cash: `${stmt.length >= 10 ? `对账单 ${stmt.slice(5, 10)}` : '对账单日期未知'}${d.cash_basis ? ` · ${d.cash_basis}` : ''}`,
        };
    }

    // ── 手机 375 卡片列表 (2026-11-04 视觉轮 V3) ──
    // 小仓位合并阈值: 展示用，非风险阈值 (只决定手机卡片是否收进"其余 N 只"; 桌面不合并)。
    // 成本价兜底的持仓不参与合并 (warn 标签须始终可见); weight 缺失的持仓不参与合并。
    const MOBILE_GROUP_BELOW_PCT = 2;

    function splitForMobile(positions, trail) {
        const rows = sortByMarketValue(positions);
        const main = [], small = [];
        rows.forEach(p => {
            const w = num(p.weight);
            // 成本价兜底、跟踪止盈非正常 (止损已触发 / 临近等) 的持仓不参与合并, 标签须始终可见
            if (w !== null && w < MOBILE_GROUP_BELOW_PCT && p.price_source !== 'cost' && !isAlertTrail(p.ts_code, trail)) small.push(p); else main.push(p);
        });
        // 只有 1 只时不合并 (合并不省空间)
        return small.length >= 2 ? { main, small } : { main: rows, small: [] };
    }

    function positionCardHtml(p, maxW, trail) {
        const [code, ex = ''] = String(p.ts_code || '').split('.');
        const type = instrumentType(p.ts_code);
        const w = num(p.weight), pct = num(p.pnl_pct), pnl = num(p.pnl);
        const width = barWidth(w, maxW);
        return `<details class="pf-card" data-code="${esc(p.ts_code)}"><summary>
            <span class="pf-card-name"><b>${esc(p.name)}</b> <span class="pf-code-ext">${esc(code)}.${esc(ex)}</span>${type ? ` <span class="pf-type-tag">${type}</span>` : ''}${p.price_source === 'cost' ? ` ${SRC.cost}` : ''}${isAlertTrail(p.ts_code, trail) ? ` ${trailHtml(p.ts_code, trail)}` : ''}</span>
            <span class="pf-card-mv num">${money(p.market_value)}<small>${w === null ? '--' : `${w.toFixed(1)}%`}</small>` +
            `${width === null ? '' : `<span class="pf-weight-bar"><span class="pf-weight-fill" style="width:${width.toFixed(1)}%"></span></span>`}</span>
            <span class="pf-card-pnl num ${pnlClass(p.pnl)}">${pct === null ? '--' : signed(pct, `${pct.toFixed(2)}%`)}</span>
        </summary><dl class="pf-card-more">
            <dt>行业</dt><dd>${esc(p.industry || '行业未知')}</dd>
            <dt>数量</dt><dd class="num">${num(p.amount) === null ? '--' : p.amount.toLocaleString('en-US')}</dd>
            <dt>成本价</dt><dd class="num">${priceText(p.cost, p.ts_code)}</dd>
            <dt>现价</dt><dd class="num">${priceText(p.price, p.ts_code)}${sourceTag(p.price_source)}</dd>
            <dt>浮动盈亏</dt><dd class="num ${pnlClass(p.pnl)}">${pnl === null ? '--' : signed(pnl, money(pnl))}</dd>
            <dt>跟踪止盈</dt><dd>${trailHtml(p.ts_code, trail)}</dd>
        </dl></details>`;
    }

    /** 手机卡片列表: 名称 + 代码 + 类型 / 市值 + 占比 / 盈亏%; 点开看其余字段; 小仓位合并为"其余 N 只 · 合计 x%" (默认收起)。 */
    function positionCardsHtml(positions, trail) {
        const all = sortByMarketValue(positions);
        if (!all.length) return '<div class="pf-table-empty">当前无持仓</div>';
        const maxW = maxWeight(all);
        const { main, small } = splitForMobile(all, trail);
        const total = small.reduce((s, p) => s + (num(p.weight) || 0), 0);
        return main.map(p => positionCardHtml(p, maxW, trail)).join('') + (small.length
            ? `<details class="pf-card-group"><summary>其余 ${small.length} 只 · 合计 ${total.toFixed(1)}%<small>（各不到 ${MOBILE_GROUP_BELOW_PCT}%，展示合并）</small></summary>` +
              small.map(p => positionCardHtml(p, maxW, trail)).join('') + '</details>'
            : '');
    }

    /** /portfolio/trailing-stops 响应 → {ts_code: status}; 不可用 null。 */
    function trailMap(resp) {
        const d = resp && (resp.data || resp);
        if (!d || !Array.isArray(d.positions)) return null;
        const m = {};
        d.positions.forEach(p => { if (p && p.ts_code && p.status) m[p.ts_code] = p.status; });
        return m;
    }

    root.PfView = { esc, instrumentType, isEtf, priceText, pnlClass, sortByMarketValue, maxWeight, barWidth,
                    positionRowHtml, positionsBodyHtml, positionCardsHtml, splitForMobile, kpiSources, money,
                    trailHtml, trailMap, TRAIL,
                    MOBILE_GROUP_BELOW_PCT };
})(typeof window !== 'undefined' ? window : globalThis);
