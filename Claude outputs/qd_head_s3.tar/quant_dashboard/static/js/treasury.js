// ============================================================
// treasury.js — 海外策略终端 JS 模块
// 海外ERP择时 + 利率择时V1.5 + 海外AIAE仓位管控
// ============================================================

// ── 页面基础功能: Tab切换 + 导航高亮 + 实时时钟 (Phase 2: 统一由 AlphaCore 工具库驱动) ──
(function _initTreasuryUI() {
    function setup() {
        AC.initNavigation();
        AC.startClock();
        AC.initTabSystem();
    }
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', setup);
    } else {
        setup();
    }
})();

// 🌐 海外ERP择时 V2.0 — 渲染引擎 (升级版)
// ============================================================
let _globalERPData = null;
let _usGaugeChart = null, _jpGaugeChart = null, _hkGaugeChart = null;
let _usErpChart = null, _jpErpChart = null, _hkErpChart = null;

// ====== 2026-11-01: 海外 ERP 只作估值背景 (口径与首页"全球权益脉搏"一致) ======
// 四地利率口径不同 (名义含通胀预期, 实际不含), ERP 绝对值不可横比; 不出仓位、不排名。
const ERP_RATE_LABEL = { cn: '名义 10Y', us: '实际 10Y', jp: '名义 JGB 10Y', hk: '美国实际 10Y' };
const ERP_NEUTRAL = '#e2e8f0';
const ERP_MUTED = '#94a3b8';

// 地区面板读数: 优先真实口径 (美股 valuation_v2 / 日港 valuation_real), 否则回退旧估算并标注
function erpBackgroundView(region, report) {
    const snap = (report && report.current_snapshot) || {};
    const q = snap.data_quality || {};
    const v = snap.valuation_v2 || snap.valuation_real || null;
    const unavailable = !report || report.status === 'fallback';
    let erp = null, pe = null, rate = null;
    if (v) {
        erp = v.erp; pe = v.pe_ttm != null ? v.pe_ttm : v.pe;
        rate = v.real_rate != null ? v.real_rate : (v.rate != null ? v.rate : v.jgb10y);
    } else if (!unavailable) {
        erp = snap.erp_value; pe = snap.pe_ttm;
        rate = region === 'hk' ? (snap.blended_rf || snap.yield_10y) : snap.yield_10y;
    }
    let badge;
    if (unavailable) badge = '数据不可用';
    else if (region === 'us' && v && v.tier_cn) {
        badge = v.tier_cn + (v.pct != null ? ' · ' + Math.round(v.pct) + '分位' : '') + ' · 影子期';
        if (v.gate && v.gate.external_risk_warning) badge += ' · 警示';
    } else badge = q.grade_cn || (v ? '真实读数' : '仅读数 (旧估算)');
    const tip = [q.eps_source_cn, q.rate_basis, q.note].concat((v && v.gate && v.gate.reasons) || []).filter(Boolean).join(' · ');
    return { erp, pe, rate, badge, tip, real: !!v, unavailable,
             pct: (region === 'us' && v && v.pct != null) ? v.pct : null,
             synthetic: !!q.history_synthetic, quality: q };
}

// 比较面板单元: 数据等级 / 档位 (与首页 renderers.js 规则一致)
function erpComparisonBadge(region, d) {
    if (!d || d.status === 'fallback') return '数据不可用';
    const q = d.data_quality || {};
    if (region === 'us' && d.tier_cn) {
        let t = d.tier_cn + ' · 影子期';
        if (d.risk_warning) t += ' · 警示';
        return t;
    }
    return q.grade_cn || '仅读数';
}

async function loadGlobalERP() {
    const btn = document.getElementById('global-erp-refresh');
    if (btn) { btn.disabled = true; btn.innerHTML = '⏳ 加载中...'; }
    try {
        // P2-1: 12s超时 + 1次自动重试
        let resp;
        try {
            resp = await fetch('/api/v1/strategy/erp-global', { signal: AbortSignal.timeout(12000) });
        } catch (e1) {
            if (e1.name === 'TimeoutError' || e1.name === 'AbortError') {
                console.warn('[Global ERP] 首次请求超时, 自动重试...');
                resp = await fetch('/api/v1/strategy/erp-global', { signal: AbortSignal.timeout(15000) });
            } else { throw e1; }
        }
        const json = await resp.json();
        if (json.status === 'success') {
            _globalERPData = json;
            renderRegionPanel('us', json.us, '#3b82f6');
            renderRegionPanel('jp', json.jp, '#dc2626');
            // HK panel (use hk_hsi as primary)
            if (json.hk_hsi) {
                renderRegionPanel('hk', json.hk_hsi, '#a855f7');
            }
            renderGlobalAlerts('us', json.us);
            renderGlobalAlerts('jp', json.jp);
            if (json.hk_hsi) {
                renderGlobalAlerts('hk', json.hk_hsi);
            }
            renderGlobalComparison(json.global_comparison);
            renderGlobalEncyclopedia(json.us, json.jp, json.hk_hsi);
            if (json.us && json.us.chart) renderRegionChart('us', json.us.chart, '#3b82f6');
            if (json.jp && json.jp.chart) renderRegionChart('jp', json.jp.chart, '#dc2626');
            if (json.hk_hsi && json.hk_hsi.chart) renderRegionChart('hk', json.hk_hsi.chart, '#a855f7');
            const t = document.getElementById('global-erp-update-time');
            if (t) t.textContent = '更新: ' + new Date().toLocaleTimeString('zh-CN');
        } else {
            console.error('[Global ERP] Error:', json.message);
        }
    } catch (e) { console.error('[Global ERP] Fetch failed:', e); }
    if (btn) { btn.disabled = false; btn.innerHTML = '🔄 刷新全球数据'; }
}

// ---- 警示横幅 ----
function renderGlobalAlerts(region, data) {
    if (!data) return;
    const alerts = data.alerts || [];
    const el = document.getElementById('global-alert-' + region);
    if (!el) return;
    // 2026-11-01: 只保留风险提示; "机会"类来自旧综合分的买入判断, 不再展示
    const danger = alerts.filter(a => a.level === 'danger');
    if (!danger.length) { el.style.display = 'none'; return; }
    el.style.display = 'block';
    const flag = region === 'us' ? '🇺🇸' : region === 'jp' ? '🇯🇵' : '🇭🇰';
    el.innerHTML = danger.map(a => {
        const bg = a.level === 'danger' ? 'rgba(239,68,68,0.08)' : 'rgba(16,185,129,0.08)';
        const bc = a.level === 'danger' ? 'rgba(239,68,68,0.3)' : 'rgba(16,185,129,0.3)';
        const pulse = a.pulse ? 'animation:pulse-glow 2s infinite;' : '';
        return '<div style="padding:7px 14px;border:1px solid '+bc+';background:'+bg+';border-radius:8px;font-size:0.72rem;color:#e2e8f0;'+pulse+'">' +
            flag + ' ' + a.icon + ' ' + a.text + '</div>';
    }).join('');
}

// ---- 信号色带 V2.0 ----
function renderSignalLevelBar(elId, currentKey) {
    const el = document.getElementById(elId);
    if (!el) return;
    const levels = [
        {k:'strong_buy',c:'#10b981',l:'SB'},{k:'buy',c:'#34d399',l:'B'},{k:'hold',c:'#3b82f6',l:'H'},
        {k:'reduce',c:'#f59e0b',l:'R'},{k:'underweight',c:'#f97316',l:'UW'},{k:'cash',c:'#ef4444',l:'C'}
    ];
    el.innerHTML = levels.map(lv => {
        const active = lv.k === currentKey;
        return '<div style="width:18px;height:10px;border-radius:3px;background:' + lv.c + (active ? '' : '22') + ';' +
            (active ? 'box-shadow:0 0 8px '+lv.c+';transform:scaleY(1.4);' : '') + '" title="'+lv.l+'"></div>';
    }).join('');
}

// ---- 仪表盘 V2.0 (放大+渐变弧线 + P1-3 dispose检查) ----
function renderMiniGauge(elId, score, color) {
    const el = document.getElementById(elId);
    if (!el) return;
    // P1-3: 复用已有实例，避免内存泄漏
    let chart = echarts.getInstanceByDom(el);
    if (!chart) chart = AC.registerChart(echarts.init(el));
    if (elId.startsWith('us')) _usGaugeChart = chart;
    else if (elId.startsWith('jp')) _jpGaugeChart = chart;
    else if (elId.startsWith('hk')) _hkGaugeChart = chart;
    chart.setOption({
        series: [{
            type: 'gauge', startAngle: 200, endAngle: -20, min: 0, max: 100,
            pointer: { show: true, length: '60%', width: 4, itemStyle: { color: color } },
            axisLine: { lineStyle: { width: 12, color: [[0.25,'#ef4444'],[0.45,'#f59e0b'],[0.65,'#3b82f6'],[0.85,'#34d399'],[1,'#10b981']] } },
            axisTick: { show: false }, splitLine: { show: false }, axisLabel: { show: false },
            detail: { show: true, offsetCenter: [0, '70%'], fontSize: 11, color: '#94a3b8',
                formatter: v => v.toFixed(0) + '分' },
            data: [{ value: score }]
        }]
    });
}

// ---- 主面板渲染 V2.0 ----
function renderRegionPanel(region, data, accentColor) {
    if (!data) return;
    const snap = data.current_snapshot || {};
    const sig = data.signal || {};
    const dims = data.dimensions || {};
    const trade = data.trade_rules || {};

    const setT = (id, v) => { const el = document.getElementById(id); if (el) el.textContent = v; };
    const setC = (id, c) => { const el = document.getElementById(id); if (el) el.style.color = c; };

    // 2026-11-01: 读数改用真实口径 (与比较面板一致); 不再展示仓位 / 信号等级 / ETF / 止盈止损 / 综合分仪表盘
    const bg = erpBackgroundView(region, data);
    const fmtPct = (x, nd = 2) => (x == null || isNaN(x)) ? '--' : Number(x).toFixed(nd) + '%';
    setT(region+'-val-erp', fmtPct(bg.erp));
    setC(region+'-val-erp', ERP_NEUTRAL);
    const heroCard = document.getElementById(region+'-hero-card');
    if (heroCard) { heroCard.style.borderColor = 'rgba(100,116,139,0.25)'; heroCard.style.boxShadow = 'none'; heroCard.title = bg.tip; }

    // Aux metrics
    setT(region+'-val-pe', bg.pe ? Number(bg.pe).toFixed(1) + 'x' : '--');
    setT(region+'-val-yield', fmtPct(bg.rate));
    setT(region+'-sub-pe', (bg.pe ? 'E/Y ' + (100 / bg.pe).toFixed(1) + '% · ' : '') + bg.badge);
    if (!bg.real) setT(region+'-sub-yield', '旧估算口径');

    if (region === 'us') {
        const vix = (dims.vix||{}).vix_info || {};
        const fed = (dims.fed_liquidity||{}).fed_info || {};
        const crd = (dims.credit_spread||{}).credit_info || {};
        setT('us-val-vix', (vix.current||0).toFixed(1));
        setC('us-val-vix', (vix.current||0)>=30?'#ef4444':(vix.current||0)>=20?'#f59e0b':'#10b981');
        setT('us-sub-vix', vix.regime==='extreme_panic'?'极端恐慌':vix.regime==='high_fear'?'高恐慌':vix.regime==='elevated_high'?'明显偏高':vix.regime==='elevated'?'偏高':vix.regime==='mild_elevated'?'略偏高':vix.regime==='normal'?'正常':vix.regime==='complacent'?'偏低':'--');
        setT('us-val-rate', (fed.current||0).toFixed(2)+'%');
        setC('us-val-rate', fed.direction==='easing'?'#10b981':'#f59e0b');
        setT('us-sub-rate', fed.direction==='easing'?'宽松':'紧缩');
        setT('us-val-credit', (crd.spread||0).toFixed(1)+'%');
        setC('us-val-credit', (crd.spread||0)<=3?'#10b981':(crd.spread||0)<=5?'#f59e0b':'#ef4444');
        setT('us-sub-credit', (crd.raw_bps||0)+'bps '+(crd.trend==='tightening'?'收窄':'走阔'));
    } else if (region === 'jp') {
        const yen = (dims.yen_trend||{}).yen_info || {};
        const vol = (dims.volatility||{}).vol_info || {};
        const rate = (dims.rate_env||{}).rate_info || {};
        setT('jp-val-yen', (yen.current||0).toFixed(1));
        setC('jp-val-yen', (yen.current||0)>155?'#ef4444':(yen.current||0)>145?'#f59e0b':'#10b981');
        setT('jp-sub-yen', yen.direction==='weakening'?'日元贬值':'日元升值');
        setT('jp-val-vol', (vol.current||0).toFixed(1)+'%');
        setC('jp-val-vol', vol.regime==='extreme_panic'?'#ef4444':vol.regime==='high'?'#f59e0b':'#10b981');
        setT('jp-sub-vol', vol.pct?(vol.pct.toFixed(0)+'%分位'):'--');
        setT('jp-val-rate', (rate.jgb_now||0).toFixed(3)+'%');
        setC('jp-val-rate', rate.jgb_direction==='rising'?'#ef4444':'#10b981');
        setT('jp-sub-rate', rate.jgb_direction==='rising'?'上行(收紧)':rate.jgb_direction==='falling'?'下行(宽松)':'稳定');
    } else if (region === 'hk') {
        const sb = (dims.southbound||{}).sb_info || {};
        const vol = (dims.vhsi||{}).vol_info || {};
        const rspread = (dims.rate_spread||{}).spread_info || {};
        const sbWeekly = sb.weekly||0;
        setT('hk-val-sb', (sbWeekly>=0?'+':'')+sbWeekly.toFixed(0)+'亿');
        setC('hk-val-sb', sbWeekly>0?'#10b981':'#ef4444');
        setT('hk-sub-sb', sb.direction==='inflow'?'净流入':'净流出');
        setT('hk-val-vol', (vol.current||0).toFixed(1)+'%');
        setC('hk-val-vol', vol.regime==='extreme_panic'?'#ef4444':vol.regime==='high'?'#f59e0b':'#10b981');
        setT('hk-sub-vol', vol.pct?(vol.pct.toFixed(0)+'%分位'):'--');
        const spread = rspread.spread||0;
        setT('hk-val-spread', (spread>=0?'+':'')+spread.toFixed(1)+'%');
        setC('hk-val-spread', spread>2.5?'#ef4444':spread>1.5?'#f59e0b':'#10b981');
        setT('hk-sub-spread', rspread.trend==='widening'?'走阔↑':rspread.trend==='narrowing'?'收窄↓':'稳定');
    }

    // 读数横幅: 美股显示 v2 历史分位与档位 (影子期, 不执行); 日港仅读数
    const banner = document.getElementById(region+'-signal-banner');
    if (banner) { banner.style.background = 'rgba(100,116,139,0.08)'; banner.style.borderColor = 'rgba(100,116,139,0.2)'; }
    const scoreEl = document.getElementById(region+'-composite-score');
    if (scoreEl) scoreEl.innerHTML = bg.pct != null ? Math.round(bg.pct) + '<span style="font-size:0.42em;margin-left:2px;">分位</span>' : '—';
    setC(region+'-composite-score', ERP_MUTED);
    const sigLabel = document.getElementById(region+'-signal-label');
    if (sigLabel) { sigLabel.textContent = bg.badge; sigLabel.style.color = ERP_NEUTRAL; sigLabel.title = bg.tip; }
    setT(region+'-signal-pos', bg.pct != null ? '自身历史分位 (Shiller 长历史, 扩展窗口) · 估值背景, 不作仓位依据'
                                             : '估值背景 · 无可靠历史, 不显示分位与档位');
    const lvl = document.getElementById(region+'-signal-level-bar');
    if (lvl) lvl.innerHTML = '';
    const badge = document.getElementById(region+'-signal-badge');
    if (badge) {
        badge.textContent = bg.badge;
        badge.style.background = 'rgba(100,116,139,0.15)';
        badge.style.color = ERP_MUTED;
        badge.style.border = '1px solid rgba(100,116,139,0.3)';
        badge.title = bg.tip;
    }
    const resEl = document.getElementById('global-resonance-'+region);
    if (resEl) resEl.style.display = 'none';

    // 港股历史 PE 为估算 / 合成时不展示走势
    if (region === 'hk' && bg.synthetic) {
        const chartEl = document.getElementById('hk-erp-chart');
        if (chartEl) chartEl.style.display = 'none';
        setT('hk-chart-note', '港股历史 PE 为估算 / 合成数据, 不展示 ERP 走势');
    }

    // 五维评分条 V2.0 (增强版)
    const barsEl = document.getElementById(region+'-dim-bars');
    if (barsEl) {
        barsEl.innerHTML = Object.keys(dims).map(k => {
            const d = dims[k]; const s = d.score||0;
            const w = d.weight?(d.weight*100).toFixed(0)+'%':'';
            const bc = s>=70?'#10b981':s>=40?'#f59e0b':'#ef4444';
            return '<div class="erp-dim-row">' +
                '<span class="erp-dim-label">'+(d.label||k)+' <span class="erp-dim-weight">'+w+'</span></span>' +
                '<div class="erp-dim-track"><div class="erp-dim-fill" style="width:'+s+'%;background:linear-gradient(90deg,'+bc+'cc,'+bc+');"></div></div>' +
                '<span class="erp-dim-score" style="color:'+bc+';">'+s.toFixed(0)+'</span></div>';
        }).join('');
    }

    // 诊断卡片 V2.0 (2列)
    const diagEl = document.getElementById(region+'-diagnosis');
    if (diagEl && data.diagnosis) {
        const typeMap = {
            success: {bg:'rgba(16,185,129,0.06)',border:'#10b981',icon:'✅'},
            info: {bg:'rgba(59,130,246,0.06)',border:'#3b82f6',icon:'ℹ️'},
            warning: {bg:'rgba(245,158,11,0.06)',border:'#f59e0b',icon:'⚠️'},
            danger: {bg:'rgba(239,68,68,0.06)',border:'#ef4444',icon:'🔴'}
        };
        diagEl.innerHTML = data.diagnosis.map(c => {
            const st = typeMap[c.type]||typeMap.info;
            return '<div style="background:'+st.bg+';border:1px solid '+st.border+'33;border-left:3px solid '+st.border+';border-radius:8px;padding:10px 12px;">' +
                '<div style="font-size:0.68rem;font-weight:700;color:'+st.border+';margin-bottom:4px;">'+st.icon+' '+c.title+'</div>' +
                '<div style="font-size:0.6rem;color:#cbd5e1;line-height:1.5;">'+c.text+'</div></div>';
        }).join('');
    }
}

// ---- 规则百科 ----
function renderGlobalEncyclopedia(usData, jpData, hkData) {
    const el = document.getElementById('global-encyclopedia-body');
    if (!el) return;
    const usEnc = (usData||{}).encyclopedia || {};
    const jpEnc = (jpData||{}).encyclopedia || {};
    const hkEnc = (hkData||{}).encyclopedia || {};
    let html = '<div><h4 style="margin:0 0 8px;font-size:0.8rem;color:#60a5fa;">🇺🇸 美股五维指标</h4>';
    for (const [k,v] of Object.entries(usEnc)) {
        html += '<div style="background:rgba(59,130,246,0.04);border:1px solid rgba(59,130,246,0.15);border-radius:6px;padding:8px;margin-bottom:6px;">' +
            '<div style="font-size:0.72rem;font-weight:600;color:#60a5fa;margin-bottom:3px;">'+v.title+'</div>' +
            '<div style="font-size:0.62rem;color:#cbd5e1;line-height:1.5;">' +
            '<b style="color:#94a3b8;">是什么:</b> '+v.what+'<br>' +
            '<b style="color:#94a3b8;">为什么:</b> '+v.why+'<br>' +
            '<b style="color:#f59e0b;">⚠️ 警示:</b> <span style="color:#f59e0b;">'+v.alert+'</span>' +
            (v.history ? '<br><b style="color:#94a3b8;">📊 历史:</b> '+v.history : '') +
            '</div></div>';
    }
    html += '</div><div><h4 style="margin:0 0 8px;font-size:0.8rem;color:#f87171;">🇯🇵 日本五维指标</h4>';
    for (const [k,v] of Object.entries(jpEnc)) {
        html += '<div style="background:rgba(220,38,38,0.04);border:1px solid rgba(220,38,38,0.15);border-radius:6px;padding:8px;margin-bottom:6px;">' +
            '<div style="font-size:0.72rem;font-weight:600;color:#f87171;margin-bottom:3px;">'+v.title+'</div>' +
            '<div style="font-size:0.62rem;color:#cbd5e1;line-height:1.5;">' +
            '<b style="color:#94a3b8;">是什么:</b> '+v.what+'<br>' +
            '<b style="color:#94a3b8;">为什么:</b> '+v.why+'<br>' +
            '<b style="color:#f59e0b;">⚠️ 警示:</b> <span style="color:#f59e0b;">'+v.alert+'</span>' +
            '</div></div>';
    }
    html += '</div>';
    // HK Encyclopedia
    if (Object.keys(hkEnc).length > 0) {
        html += '<div style="grid-column:1/-1;"><h4 style="margin:0 0 8px;font-size:0.8rem;color:#c084fc;">🇭🇰 港股五维指标</h4><div style="display:grid;grid-template-columns:1fr 1fr;gap:6px;">';
        for (const [k,v] of Object.entries(hkEnc)) {
            html += '<div style="background:rgba(168,85,247,0.04);border:1px solid rgba(168,85,247,0.15);border-radius:6px;padding:8px;">' +
                '<div style="font-size:0.72rem;font-weight:600;color:#c084fc;margin-bottom:3px;">'+v.title+'</div>' +
                '<div style="font-size:0.62rem;color:#cbd5e1;line-height:1.5;">' +
                '<b style="color:#94a3b8;">是什么:</b> '+v.what+'<br>' +
                '<b style="color:#94a3b8;">为什么:</b> '+v.why+'<br>' +
                '<b style="color:#f59e0b;">⚠️ 警示:</b> <span style="color:#f59e0b;">'+v.alert+'</span>' +
                '</div></div>';
        }
        html += '</div></div>';
    }
    el.innerHTML = html;
}

// ---- 三地对比 V2.0 (含皇冠动画) ----
function renderGlobalComparison(gc) {
    // 2026-11-01: 只展示带口径的读数与"自身历史分位"; 不排名、不给配比、不给总仓位 (后端相关字段已标 deprecated)
    if (!gc) return;
    const setT = (id,v) => { const el=document.getElementById(id); if(el) el.textContent=v; };
    const setH = (id,v) => { const el=document.getElementById(id); if(el) el.innerHTML=v; };
    const setCS = (id,c) => { const el=document.getElementById(id); if(el) el.style.color=c; };
    const f2 = x => (x == null || isNaN(x)) ? '--' : Number(x).toFixed(2) + '%';
    ['cn','us','jp','hk'].forEach(r => {
        const d = gc[r] || {};
        const q = d.data_quality || {};
        const na = d.status === 'fallback';
        const badgeTxt = erpComparisonBadge(r, d);
        const tip = [q.eps_source_cn, q.rate_basis || ERP_RATE_LABEL[r], q.note, d.pct_basis].filter(Boolean).join(' · ');

        setT('global-'+r+'-erp', na ? '--' : f2(d.erp));
        setCS('global-'+r+'-erp', ERP_NEUTRAL);
        setT('global-'+r+'-score', '利率口径: ' + ERP_RATE_LABEL[r]);
        const sigEl = document.getElementById('global-'+r+'-signal');
        if (sigEl) { sigEl.textContent = badgeTxt; sigEl.style.color = ERP_MUTED; sigEl.title = tip; }

        setT('gm-'+r+'-pe', na || !d.pe ? '--' : Number(d.pe).toFixed(1) + 'x' + (q.grade_cn === '仅读数' ? ' (估)' : ''));
        setH('gm-'+r+'-yield', na ? '--' : f2(d.yield) + '<br><span style="font-size:0.62rem;color:#64748b;">' + ERP_RATE_LABEL[r] + '</span>');
        setT('gm-'+r+'-erp', na ? '--' : f2(d.erp));
        setCS('gm-'+r+'-erp', ERP_NEUTRAL);
        setT('gm-'+r+'-score', (!na && d.erp_pct != null) ? Math.round(d.erp_pct) + '分位' : '—');
        setCS('gm-'+r+'-score', ERP_NEUTRAL);
        const scoreCell = document.getElementById('gm-'+r+'-score');
        if (scoreCell) scoreCell.title = d.pct_basis || (r === 'us' ? 'Shiller 长历史扩展窗口分位 (影子期)' : '无可靠历史, 不显示分位');
        const sigCell = document.getElementById('gm-'+r+'-signal');
        if (sigCell) { sigCell.textContent = badgeTxt; sigCell.style.color = ERP_MUTED; sigCell.title = tip; }

        const card = document.getElementById('global-'+r+'-card');
        if (card) { card.classList.remove('winner'); card.style.boxShadow = 'none'; card.style.borderColor = 'rgba(100,116,139,0.25)'; }
        const crown = document.getElementById('global-'+r+'-crown');
        if (crown) { crown.style.display = 'none'; crown.innerHTML = ''; }
    });

    const advEl = document.getElementById('global-advice');
    if (advEl) {
        advEl.textContent = 'ⓘ ' + (gc.role_note || '外部估值背景, 不作仓位依据; 仓位以 AIAE 执行目标为准') +
            '。四地利率口径不同 (名义 / 实际), ERP 绝对值不可横向比较, 只看各自历史位置。';
        advEl.style.color = ERP_MUTED;
        advEl.style.background = 'rgba(100,116,139,0.08)';
        advEl.style.fontWeight = '500';
    }
}

// ---- ERP走势图 V2.0 (含买卖区间阴影) ----
function renderRegionChart(region, chart, color) {
    if (!chart || chart.status !== 'success') return;
    const el = document.getElementById(region+'-erp-chart');
    if (!el) return;
    // 2026-11-01: 后端给出真实口径月度历史 (basis=real) 时, 走势与上方读数同口径
    if (chart.basis === 'real') {
        el.style.display = '';
        const note = document.getElementById(region+'-chart-note');
        if (note) note.textContent = 'ERP 走势 · ' + (chart.basis_note || '真实口径') + ' · 与上方读数同口径' +
            (chart.stats && chart.stats.start ? ' (' + chart.stats.start + ' 起)' : '');
    }
    let instance = echarts.getInstanceByDom(el);
    if (!instance) {
        instance = AC.registerChart(echarts.init(el));
    }
    if (region === 'us') _usErpChart = instance;
    else if (region === 'jp') _jpErpChart = instance;
    else if (region === 'hk') _hkErpChart = instance;
    instance.setOption({
        backgroundColor: 'transparent',
        grid: { top: 30, right: 12, bottom: 30, left: 40 },
        tooltip: { trigger:'axis', backgroundColor:'rgba(15,23,42,0.95)', borderColor:color+'44',
            textStyle:{color:'#e2e8f0',fontSize:11},
            formatter: p => { if (!p.length) return ''; let s='<b>'+p[0].axisValue+'</b><br/>'; p.forEach(i=>s+='<span style="color:'+i.color+'">●</span> '+i.seriesName+': <b>'+i.value+'%</b><br/>'); return s; }
        },
        xAxis: { type:'category', data:chart.dates, axisLabel:{color:'#64748b',fontSize:9,formatter:v=>v.substring(2,7)}, axisLine:{lineStyle:{color:'#334155'}} },
        yAxis: { type:'value', axisLabel:{color:'#64748b',fontSize:10,formatter:'{value}%'}, splitLine:{lineStyle:{color:'#1e293b'}} },
        series: [
            { name:'ERP', type:'line', data:chart.erp, smooth:true,
              lineStyle:{color:color,width:2.5},
              areaStyle:{color:{type:'linear',x:0,y:0,x2:0,y2:1,colorStops:[{offset:0,color:color+'44'},{offset:1,color:color+'05'}]}},
              itemStyle:{color:color}, symbol:'none' },
        ]
    });
}

// Tab切换钩子

// ====== 机构级·标签切换强制刷新与数据完整性校验引擎 ======
(function() {
    // 动态在页面右下角创建极其精美的“机构审计验证 HUD”
    const hudId = 'ac-audit-hud';
    let hud = document.getElementById(hudId);
    if (!hud) {
        hud = document.createElement('div');
        hud.id = hudId;
        hud.style.cssText = `
            position: fixed;
            bottom: 24px;
            right: 24px;
            z-index: 10000;
            background: rgba(10, 15, 30, 0.88);
            backdrop-filter: blur(16px);
            -webkit-backdrop-filter: blur(16px);
            border: 1px solid rgba(59, 130, 246, 0.2);
            border-radius: 12px;
            padding: 16px 20px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.5), inset 0 1px 0 rgba(255,255,255,0.03);
            color: #f1f5f9;
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
            width: 320px;
            transform: translateY(150%);
            transition: transform 0.4s cubic-bezier(0.16, 1, 0.3, 1);
            pointer-events: none;
        `;
        document.body.appendChild(hud);
    }

    let hideTimer = null;

    function showAuditHUD(status, title, message, latency = null) {
        let borderCol = 'rgba(59, 130, 246, 0.25)';
        let titleCol = '#3b82f6';
        let icon = '🔄';

        if (status === 'loading') {
            borderCol = 'rgba(59, 130, 246, 0.25)';
            titleCol = '#3b82f6';
            icon = '⚙️';
        } else if (status === 'success') {
            borderCol = 'rgba(34, 197, 94, 0.25)';
            titleCol = '#22c55e';
            icon = '🛡️';
        } else if (status === 'error') {
            borderCol = 'rgba(239, 68, 68, 0.25)';
            titleCol = '#ef4444';
            icon = '⚠️';
        }

        hud.style.borderColor = borderCol;
        
        let latencyHTML = latency ? `<span style="font-family:'JetBrains Mono', monospace; font-size: 10px; padding: 2px 6px; border-radius: 4px; background: rgba(255,255,255,0.05); color: #94a3b8; float: right; margin-top: 2px;">Latency: ${latency}ms</span>` : '';

        hud.innerHTML = `
            <div style="display: flex; align-items: flex-start; gap: 12px;">
                <div style="font-size: 20px; margin-top: 2px; display: inline-block; height: 24px; animation: ${status === 'loading' ? 'ac-spin 1.5s linear infinite' : 'none'};">${icon}</div>
                <div style="flex: 1;">
                    <div style="font-size: 13px; font-weight: 700; color: ${titleCol}; margin-bottom: 4px; display: flex; justify-content: space-between; align-items: center; width: 100%;">
                        <span>${title}</span>
                        ${latencyHTML}
                    </div>
                    <div style="font-size: 11px; color: #94a3b8; line-height: 1.5;">${message}</div>
                </div>
            </div>
            <style>
                @keyframes ac-spin { to { transform: rotate(360deg); } }
            </style>
        `;
        hud.style.transform = 'translateY(0)';

        if (hideTimer) clearTimeout(hideTimer);
        if (status !== 'loading') {
            hideTimer = setTimeout(() => {
                hud.style.transform = 'translateY(150%)';
            }, 4000);
        }
    }

    document.querySelectorAll('.st-tab').forEach(tab => {
        tab.addEventListener('click', function() {
            const reportName = this.textContent.trim().replace(/[^\u4e00-\u9fa5a-zA-Z0-9_.\-]/g, '') || this.textContent.trim();
            const reportId = this.dataset.report;
            const startTime = performance.now();

            showAuditHUD('loading', 'AlphaCore 审计校验中', `正在强制拉取最新数据，重新计算并校验 ${reportName} 的策略决策...`);

            if (reportId === 'st-aiae-global') {
                loadGlobalAIAE(true).then(() => {
                    const latency = Math.round(performance.now() - startTime);
                    if (_globalAIAEData && _globalAIAEData.status === 'success') {
                        showAuditHUD('success', 'AIAE 仓位数据已验证', '✓ 四地证券化率、融资热度与偏股基金仓位指标已完成高频更新，通过数据一致性校验。', latency);
                    } else {
                        showAuditHUD('error', 'AIAE 数据校验未通过', '⚠️ 警告：海外 AIAE 仓位数据源存在滞后或请求失败，请启动风控防御性持仓。', latency);
                    }
                }).catch(err => {
                    const latency = Math.round(performance.now() - startTime);
                    showAuditHUD('error', '强制刷新失败', `网络或引擎计算错误: ${err.message}`, latency);
                });
            }
            else if (reportId === 'st-erp-global') {
                loadGlobalERP().then(() => {
                    const latency = Math.round(performance.now() - startTime);
                    if (_globalERPData && _globalERPData.status === 'success') {
                        showAuditHUD('success', 'ERP 择时信号已验证', '✓ 全球三地 ERP 估值水平与波动率环境成功触发重算，模型置信度及配额比例已确认。', latency);
                    } else {
                        showAuditHUD('error', 'ERP 数据校验异常', '⚠️ 警告：全球 ERP 引擎返回的数据项可能不完整，部分日元/恒指底层接口出现拥堵。', latency);
                    }
                }).catch(err => {
                    const latency = Math.round(performance.now() - startTime);
                    showAuditHUD('error', '强制刷新失败', `网络或引擎计算错误: ${err.message}`, latency);
                });
            }
            else if (reportId === 'st-rates-strategy') {
                loadRatesStrategy().then(() => {
                    const latency = Math.round(performance.now() - startTime);
                    if (_ratesData) {
                        showAuditHUD('success', '利率数据已更新', '美债收益率、实际利率与通胀预期数据已刷新。利率信号样本外验证未通过 (2026-11-01)，仅作背景，不驱动仓位。', latency);
                    } else {
                        showAuditHUD('error', '利率数据加载失败', 'FRED 利率数据未能加载，页面数值可能不完整。', latency);
                    }
                }).catch(err => {
                    const latency = Math.round(performance.now() - startTime);
                    showAuditHUD('error', '强制刷新失败', `网络或引擎计算错误: ${err.message}`, latency);
                });
            }
        });
    });
})();


// 🏦 利率择时引擎 V1.5 — JS渲染
// ═══════════════════════════════════════════════
let _ratesData = null;
let _ratesGaugeChart = null;
let _ratesMainChart = null;

async function loadRatesStrategy() {
    const btn = document.getElementById('rates-refresh-btn');
    if (btn) { btn.disabled = true; btn.innerHTML = '⏳ 加载中...'; }
    try {
        // P2-1: 12s超时 + 1次自动重试
        let resp;
        try {
            resp = await fetch('/api/v1/strategy/rates', { signal: AbortSignal.timeout(12000) });
        } catch (e1) {
            if (e1.name === 'TimeoutError' || e1.name === 'AbortError') {
                console.warn('[Rates] 首次请求超时, 自动重试...');
                resp = await fetch('/api/v1/strategy/rates', { signal: AbortSignal.timeout(15000) });
            } else { throw e1; }
        }
        const json = await resp.json();
        if (json.status === 'success' && json.data) {
            _ratesData = json.data;
            renderRatesPanel(json.data);
            const t = document.getElementById('rates-update-time');
            if (t) t.textContent = '更新: ' + new Date().toLocaleTimeString('zh-CN');
        } else {
            console.error('[Rates] Error:', json.message || json);
            _ratesShowError(json.message || '数据返回异常');
        }
    } catch (e) {
        console.error('[Rates] Fetch failed:', e);
        _ratesShowError(e.message || '网络连接失败');
    }
    if (btn) { btn.disabled = false; btn.innerHTML = '🔄 刷新利率数据'; }
}

function _ratesShowError(msg) {
    const zone = document.getElementById('rates-decision-zone');
    if (zone) {
        zone.style.display = 'block';
        zone.innerHTML = '<div style="text-align:center;padding:24px;color:#ef4444;font-size:0.82rem;">' +
            '❌ 利率数据加载失败: ' + msg +
            '<br><span style="font-size:0.65rem;color:#64748b;margin-top:6px;display:inline-block;">请检查 FRED API 连接或稍后重试</span></div>';
    }
}

function renderRatesPanel(data) {
    if (!data) return;
    const snap = data.current_snapshot || {};
    const dims = data.dimensions || {};
    const signal = data.signal || {};
    const trade = data.trade_rules || {};
    const trSig = trade.signal || signal;

    const setT = (id, v) => { const el = document.getElementById(id); if (el) el.textContent = v; };
    const setC = (id, c) => { const el = document.getElementById(id); if (el) el.style.color = c; };

    const rcn = snap.regime_cn || {};

    // === Regime Badge (Hero) ===
    const regBadge = document.getElementById('rates-regime-badge');
    if (regBadge && data.buy_sell_zones) {
        const bsz = data.buy_sell_zones;
        regBadge.textContent = (bsz.regime_label || '') + ' · 仅背景';
        regBadge.style.background = 'rgba(148,163,184,0.10)';   // V1.9: 中性, 不再借用结论色
        regBadge.style.color = '#cbd5e1';
        regBadge.style.border = '1px solid rgba(148,163,184,0.25)';
    }

    // === ZONE 1: 快照卡片 (中文Regime + alert hint) ===
    setT('rates-val-10y', (snap.yield_10y||0).toFixed(2) + '%');
    setC('rates-val-10y', '#e2e8f0');  // V1.9: 水平类读数中性色
    const ylInfo = (dims.yield_level||{}).yield_info || {};
    setT('rates-sub-10y', (rcn.yield_level||'--') + ' | 分位'+(ylInfo.pct||0).toFixed(0)+'%');

    setT('rates-val-2y', (snap.yield_2y||0).toFixed(2) + '%');
    setC('rates-val-2y', '#e2e8f0');
    setT('rates-sub-2y', '短端 | Fed映射');

    const spreadBps = snap.spread_bps || 0;
    setT('rates-val-spread', (spreadBps >= 0 ? '+' : '') + spreadBps.toFixed(0) + 'bps');
    setC('rates-val-spread', '#e2e8f0');
    setT('rates-sub-spread', (rcn.curve||'--'));

    setT('rates-val-real', (snap.real_yield||0).toFixed(2) + '%');
    setC('rates-val-real', '#e2e8f0');
    setT('rates-sub-real', (rcn.real_yield||'--'));

    const momInfo = (dims.yield_momentum||{}).momentum_info || {};
    const chg3m = momInfo.chg_3m_bps || 0;
    setT('rates-val-momentum', (chg3m >= 0 ? '+' : '') + chg3m.toFixed(0) + 'bps');
    setC('rates-val-momentum', chg3m > 0 ? '#ef4444' : chg3m < 0 ? '#10b981' : '#e2e8f0');  // 红涨绿跌
    setT('rates-sub-momentum', (rcn.momentum||'--'));

    setT('rates-val-bei', (snap.breakeven||0).toFixed(2) + '%');
    setC('rates-val-bei', '#e2e8f0');
    setT('rates-sub-bei', '通胀预期');

    // Alert hints
    const hints = data.alert_hints || {};
    setT('rates-hint-10y', hints.yield_10y || '');
    setT('rates-hint-2y', hints.yield_2y || '');
    setT('rates-hint-spread', hints.spread || '');
    setT('rates-hint-real', hints.real_yield || '');
    setT('rates-hint-momentum', hints.momentum || '');
    setT('rates-hint-bei', hints.bei || '');

    // === V1.9: 五维评分 · 验证结果 (替代原久期倾向/止盈/逆向规则) ===
    renderRatesScoreNote(signal);

    // === ZONE 2: 信号badge ===
    const badge = document.getElementById('rates-signal-badge');
    if (badge) {
        badge.textContent = (trSig.emoji||'') + ' ' + (trSig.label||'');
        badge.style.background = (trSig.color||'#94a3b8') + '22';
        badge.style.color = trSig.color||'#94a3b8';
        badge.style.border = '1px solid '+(trSig.color||'#94a3b8')+'44';
    }

    // ETF
    const etfEl = document.getElementById('rates-etf-advice');
    if (etfEl && trade.etf_advice) {
        etfEl.innerHTML = trade.etf_advice.map(e =>
            '<div style="display:flex;justify-content:space-between;padding:2px 0;border-bottom:1px solid rgba(100,116,139,0.1);"><span>'+(e.etf?e.etf.name:'')+'</span><span style="color:#fbbf24;font-weight:600;">'+e.ratio+'</span></div>'
        ).join('');
    }

    // 止盈 (动态高亮)
    const tpEl = document.getElementById('rates-take-profit');
    if (tpEl && trade.take_profit) {
        tpEl.innerHTML = trade.take_profit.map(r => {
            const triggered = r.triggered;
            const bg = triggered ? 'background:rgba(16,185,129,0.12);border-left:2px solid #10b981;padding-left:6px;border-radius:3px;' : '';
            const tag = triggered && r.current ? ' <span style="color:#f59e0b;font-size:0.6rem;">[✅'+r.current+']</span>' : '';
            return '<div style="padding:3px 0;margin-bottom:3px;'+bg+'"><span style="color:#10b981;">▸</span> '+r.trigger+' → <b>'+r.action+'</b>'+tag+'</div>';
        }).join('');
    }

    // 止损 (动态高亮)
    const slEl = document.getElementById('rates-stop-loss');
    if (slEl && trade.stop_loss) {
        slEl.innerHTML = trade.stop_loss.map(r => {
            const triggered = r.triggered;
            const trigColor = r.color || '#f59e0b';
            const bg = triggered ? 'background:rgba('+(trigColor==='#10b981'?'16,185,129':'239,68,68')+',0.12);border-left:2px solid '+trigColor+';padding-left:6px;border-radius:3px;' : '';
            const tag = triggered && r.current ? ' <span style="color:#f59e0b;font-size:0.6rem;">[✅'+r.current+']</span>' : '';
            return '<div style="padding:3px 0;margin-bottom:3px;'+bg+'"><span style="color:'+trigColor+';">▸</span> '+r.trigger+' → <b>'+r.action+'</b>'+tag+'</div>';
        }).join('');
    }

    // === 综合得分 + 信号标签 ===
    setT('rates-composite-score', trSig.score || '--');
    setC('rates-composite-score', '#e2e8f0');  // V1.9: 中性
    const sigLabel = document.getElementById('rates-signal-label');
    if (sigLabel) {
        sigLabel.textContent = (trSig.emoji||'')+' '+(trSig.label||'')+' ('+(trSig.position||'')+')';
        sigLabel.style.color = '#94a3b8';
    }

    // 仪表盘
    setTimeout(() => renderRatesGauge(trSig.score||0), 50);

    // 五维评分条 (新增desc行)
    const barsEl = document.getElementById('rates-dim-bars');
    if (barsEl) {
        barsEl.innerHTML = Object.keys(dims).map(k => {
            const d = dims[k]; const s = d.score||0;
            const w = d.weight?(d.weight*100).toFixed(0)+'%':'';
            const bc = '#94a3b8';  // V1.9: 中性, 不暗示好坏
            const desc = d.desc ? '<div style="font-size:0.48rem;color:#64748b;margin-top:1px;line-height:1.2;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;">'+d.desc+'</div>' : '';
            return '<div style="margin-bottom:5px;">' +
                '<div style="display:flex;align-items:center;gap:5px;">' +
                '<span style="font-size:0.6rem;color:#94a3b8;width:62px;text-align:right;flex-shrink:0;">'+d.label+'<span style="color:#475569;font-size:0.5rem;"> '+w+'</span></span>' +
                '<div style="flex:1;height:5px;background:rgba(30,41,59,0.8);border-radius:3px;overflow:hidden;">' +
                '<div style="width:'+s+'%;height:100%;background:'+bc+';border-radius:3px;transition:width 0.6s;"></div></div>' +
                '<span style="font-size:0.6rem;color:'+bc+';width:24px;text-align:right;">'+s.toFixed(0)+'</span></div>'+desc+'</div>';
        }).join('');
    }

    // === ZONE 4: 美债信号条 (V1.7 P0: 不再展示股/债/金比例, 仓位以 AIAE 执行目标为准) ===
    const allocBar = document.getElementById('rates-allocation-bar');
    if (allocBar && typeof trSig.score === 'number') {
        const bs = (typeof trSig.bond_signal === 'number') ? trSig.bond_signal : Math.round((trSig.score - 50) * 2);
        const pos = Math.max(0, Math.min(100, (bs + 100) / 2));
        const col = bs > 25 ? '#10b981' : bs < -25 ? '#ef4444' : '#94a3b8';
        allocBar.innerHTML =
            '<div style="position:relative;flex:1;background:rgba(30,41,59,0.6);">' +
            '<div style="position:absolute;left:50%;top:0;bottom:0;width:1px;background:rgba(148,163,184,0.4);"></div>' +
            '<div style="position:absolute;left:0;width:37.5%;top:0;bottom:0;background:rgba(239,68,68,0.06);"></div>' +
            '<div style="position:absolute;right:0;width:37.5%;top:0;bottom:0;background:rgba(16,185,129,0.06);"></div>' +
            '<div style="position:absolute;left:calc('+pos+'% - 2px);top:4px;bottom:4px;width:4px;border-radius:2px;background:'+col+';"></div>' +
            '</div>';
        setT('rates-alloc-stock', '美债信号 ' + (bs >= 0 ? '+' : '') + bs.toFixed(0) + ' (−100~+100, ±25 以内为中性)');
        setC('rates-alloc-stock', col);
        setT('rates-alloc-bond', '仅背景：样本外验证未通过，多资产美债固定 30%');
        setT('rates-alloc-gold', '黄金看黄金引擎 · 股票看 AIAE');
        setT('rates-alloc-duration', '久期: ' + (trSig.duration || '--'));
    }

    // === 决策汇总区 ===
    renderRatesReturnRef((data.context || {}).expected_return);  // V1.9: 替代原买卖决策区

    // === 图表操作信号条 (V3.1) ===
    renderRatesContextBar(data.context);  // V1.8: 替代原信号清单

    // === 警示 ===
    renderRatesAlerts(data.alerts || []);

    // === 诊断 ===
    renderRatesDiagnosis(data.diagnosis || []);

    // === Tooltips ===
    if (data.card_tooltips) setupRatesTooltips(data.card_tooltips);

    // === 走势图 ===
    if (data.chart) renderRatesChart(data.chart);
}

function renderRatesGauge(score) {
    const el = document.getElementById('rates-gauge-chart');
    if (!el) return;
    let chart = echarts.getInstanceByDom(el);
    if (!chart) {
        chart = AC.registerChart(echarts.init(el));
    }
    _ratesGaugeChart = chart;
    _ratesGaugeChart.setOption({
        series: [{
            type: 'gauge', startAngle: 200, endAngle: -20, min: 0, max: 100,
            pointer: { show: true, length: '55%', width: 3, itemStyle: { color: '#c084fc' } },
            axisLine: { lineStyle: { width: 8, color: [[0.2,'#ef4444'],[0.35,'#f97316'],[0.5,'#f59e0b'],[0.65,'#94a3b8'],[0.8,'#3b82f6'],[1,'#10b981']] } },
            axisTick: { show: false }, splitLine: { show: false }, axisLabel: { show: false },
            detail: { show: false }, data: [{ value: score }]
        }]
    });
}

// V3.0→V3.1: KPI 卡片 6项 — 补充 Z-Score + 当前区间 + 倒挂占比
// ===== V1.8 (2026-11-01): 走势图区只作背景 — 中性配色, 只有"变化方向"用红涨绿跌; 口径与 D1 一致 =====
const RATES_NEUTRAL = '#e2e8f0', RATES_MUTED = '#94a3b8', RATES_DIM = '#64748b';
const RATES_UP = '#ef4444', RATES_DOWN = '#10b981';   // A 股习惯: 上行红 / 下行绿
let _ratesChartView = '5y';

function _ratesChgSpan(bps, unit) {
    if (bps === null || bps === undefined) return '<span style="color:' + RATES_DIM + ';">—</span>';
    const c = bps > 0 ? RATES_UP : (bps < 0 ? RATES_DOWN : RATES_MUTED);
    return '<span style="color:' + c + ';">' + (bps > 0 ? '+' : '') + bps + (unit || 'bps') + '</span>';
}

function renderRatesChartKPIs(stats, view, longStats) {
    const container = document.getElementById('rates-chart-kpis');
    if (!container || !stats) return;
    const use = (view === '20y' && longStats) ? longStats : stats;
    const winLabel = view === '20y' ? '20年' : '5年';
    const dev = (use.current != null && use.mean != null) ? (use.current - use.mean) : null;
    const z = (use.z_score != null) ? use.z_score : null;
    const ctx = (_ratesData && _ratesData.context) || {};
    const curve = ctx.curve || {};
    const curveVal = (curve.spread_bps != null)
        ? ((curve.spread_bps > 0 ? '+' : '') + curve.spread_bps + 'bps · ' + (curve.regime_cn || '—'))
        : '—';
    const zoneLabel = view === '20y'
        ? (use.current_pct >= 75 ? '20年高位' : use.current_pct <= 25 ? '20年低位' : '20年中段')
        : (stats.current_zone_label || '—');
    container.innerHTML = [
        { label: '当前 10Y', value: (use.current != null ? use.current.toFixed(2) : '--') + '%' },
        { label: winLabel + '均值偏离', value: dev === null ? '--' : (dev >= 0 ? '+' : '') + dev.toFixed(2) + 'pp' },
        { label: winLabel + '分位', value: (use.current_pct != null ? use.current_pct.toFixed(1) : '--') + '%' },
        { label: winLabel + ' Z 值', value: z === null ? '--' : (z >= 0 ? '+' : '') + z.toFixed(2) + 'σ' },
        { label: '所处区间', value: zoneLabel },
        { label: '曲线 10Y-2Y', value: curveVal, title: curve.note || '' },
    ].map(k => `<div title="${k.title || ''}" style="flex:1;background:rgba(15,23,42,0.6);border:1px solid rgba(255,255,255,0.06);border-radius:6px;padding:8px 10px;text-align:center;min-width:0;">
        <div style="font-size:0.6rem;color:${RATES_DIM};margin-bottom:3px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${k.label}</div>
        <div style="font-size:0.95rem;font-weight:700;color:${RATES_NEUTRAL};white-space:nowrap;overflow:hidden;text-overflow:ellipsis;font-variant-numeric:tabular-nums;">${k.value}</div>
    </div>`).join('');
}

// V1.8: 逐点区间判定 (纯描述, 无图标)
function getYieldZoneLabel(v, zt) {
    if (!zt) return '—';
    if (v >= zt.high_zone) return '5年高位区 (>P87)';
    if (v >= zt.high_tilt) return '5年偏高区 (P75–P87)';
    if (v <= zt.low_zone)  return '5年低位区 (<P13)';
    if (v <= zt.low_tilt)  return '5年偏低区 (P13–P25)';
    return '5年中性区 (P25–P75)';
}

function setRatesChartView(view) {
    _ratesChartView = view;
    document.querySelectorAll('#rates-chart-view button').forEach(b => {
        const on = b.dataset.view === view;
        b.style.background = on ? 'rgba(148,163,184,0.18)' : 'transparent';
        b.style.color = on ? RATES_NEUTRAL : RATES_DIM;
    });
    if (_ratesData && _ratesData.chart) renderRatesChart(_ratesData.chart);
}

function renderRatesChart(chart) {
    if (!chart || chart.status !== 'success') return;
    const el = document.getElementById('rates-chart');
    if (!el) return;
    let instance = echarts.getInstanceByDom(el);
    if (!instance) {
        instance = AC.registerChart(echarts.init(el));
    }
    _ratesMainChart = instance;
    const longView = chart.long && chart.long.status === 'success' ? chart.long : null;
    const btn20 = document.querySelector('#rates-chart-view button[data-view="20y"]');
    if (btn20) { btn20.disabled = !longView; btn20.style.opacity = longView ? 1 : 0.4; btn20.title = longView ? '' : '20 年数据暂不可用'; }
    const view = (_ratesChartView === '20y' && longView) ? '20y' : '5y';
    const stats = chart.stats || {};
    const lines = chart.lines || {};
    const zt = stats.zone_thresholds || {};

    const titleEl = document.getElementById('rates-chart-title');
    if (titleEl) {
        const yrs = view === '20y' ? longView.years : (stats.date_range_years || '?');
        titleEl.textContent = 'US 10Y Treasury · 近' + yrs + '年 · 历史分位区间 (仅背景，不构成买卖区间)';
    }
    renderRatesChartKPIs(stats, view, longView ? longView.stats : null);

    const dates = view === '20y' ? longView.dates : chart.dates;
    const yields = view === '20y' ? longView.yields_10y : chart.yields_10y;
    const ls = view === '20y' ? longView.stats : null;
    const lineDefs = view === '20y'
        ? [ { y: ls.p75, name: '20年P75 ' + ls.p75 + '%' }, { y: ls.p50, name: '20年P50 ' + ls.p50 + '%' }, { y: ls.p25, name: '20年P25 ' + ls.p25 + '%' } ]
        : [ { y: lines.high_zone, name: 'P87 ' + lines.high_zone + '%' }, { y: lines.high_tilt, name: 'P75 ' + lines.high_tilt + '%' },
            { y: lines.neutral, name: 'P50 ' + lines.neutral + '%' }, { y: lines.low_tilt, name: 'P25 ' + lines.low_tilt + '%' },
            { y: lines.low_zone, name: 'P13 ' + lines.low_zone + '%' } ];
    const markLineData = lineDefs.filter(d => d.y != null).map(d => ({
        yAxis: d.y, name: d.name,
        lineStyle: { color: 'rgba(148,163,184,0.35)', type: d.name.indexOf('P50') >= 0 ? 'solid' : 'dashed', width: 1 },
        label: { color: RATES_DIM, fontSize: 9, position: 'insideEndTop', formatter: d.name }
    }));
    const markAreaData = view === '20y' ? [] : [
        [{ yAxis: lines.high_tilt, itemStyle: { color: 'rgba(148,163,184,0.06)' } }, { yAxis: lines.high_zone }],
        [{ yAxis: lines.high_zone, itemStyle: { color: 'rgba(148,163,184,0.10)' } }, { yAxis: Math.max.apply(null, yields) + 0.5 }],
        [{ yAxis: lines.low_zone, itemStyle: { color: 'rgba(148,163,184,0.06)' } }, { yAxis: lines.low_tilt }],
    ];
    const lastVal = yields[yields.length - 1];
    const series = [
        { name: '10Y Yield', type: 'line', data: yields, smooth: false, symbol: 'none', yAxisIndex: 0, z: 10,
          lineStyle: { color: '#c7d2fe', width: 1.8 }, itemStyle: { color: '#c7d2fe' },
          markArea: { silent: true, data: markAreaData },
          markLine: { silent: true, symbol: 'none', data: markLineData },
          markPoint: { data: [{ coord: [dates[dates.length - 1], lastVal], symbol: 'circle', symbolSize: 7,
                                itemStyle: { color: RATES_NEUTRAL },
                                label: { show: true, position: 'top', distance: 6, formatter: lastVal.toFixed(2) + '%', color: RATES_NEUTRAL, fontSize: 10, fontWeight: 600 } }] } },
    ];
    const hasSpread = view === '5y' && chart.spreads;
    if (hasSpread) {
        series.push({ name: '10Y-2Y利差', type: 'bar', yAxisIndex: 1, barWidth: '60%',
            data: chart.spreads.map(v => v == null ? null : Math.round(v * 100)),
            itemStyle: { color: p => p.data < 0 ? 'rgba(245,158,11,0.35)' : 'rgba(148,163,184,0.25)' } });
    }
    const yAxes = [{ type: 'value', name: '%', position: 'left', scale: true,
        axisLabel: { color: RATES_DIM, fontSize: 9, formatter: '{value}%' },
        splitLine: { lineStyle: { color: 'rgba(100,116,139,0.08)' } }, nameTextStyle: { color: RATES_DIM, fontSize: 9 } }];
    if (hasSpread) yAxes.push({ type: 'value', name: 'bps', position: 'right',
        axisLabel: { color: RATES_DIM, fontSize: 9, formatter: '{value}' }, splitLine: { show: false },
        nameTextStyle: { color: RATES_DIM, fontSize: 9 } });

    _ratesMainChart.setOption({
        backgroundColor: 'transparent', animation: false,
        grid: { top: 30, right: hasSpread ? 56 : 30, bottom: 50, left: 46 },
        legend: { top: 0, textStyle: { color: RATES_MUTED, fontSize: 10 }, itemWidth: 14, itemHeight: 8,
                  data: hasSpread ? ['10Y Yield', '10Y-2Y利差'] : ['10Y Yield'] },
        dataZoom: [ { type: 'inside', start: view === '20y' ? 0 : 60, end: 100 },
                    { type: 'slider', height: 14, bottom: 4, borderColor: 'rgba(255,255,255,0.06)',
                      fillerColor: 'rgba(148,163,184,0.12)', textStyle: { color: RATES_DIM, fontSize: 9 } } ],
        tooltip: { trigger: 'axis', backgroundColor: 'rgba(15,23,42,0.95)', borderColor: '#334155',
            textStyle: { color: RATES_NEUTRAL, fontSize: 11 },
            formatter: function (p) {
                if (!p.length) return '';
                let s = '<div style="color:' + RATES_DIM + ';margin-bottom:4px;">' + p[0].axisValue + '</div>';
                p.forEach(i => {
                    if (i.value == null) return;
                    const v = i.seriesName === '10Y-2Y利差' ? ((i.value > 0 ? '+' : '') + i.value + 'bps') : (Number(i.value).toFixed(2) + '%');
                    s += '<div>' + i.marker + ' ' + i.seriesName + ': <b>' + v + '</b></div>';
                });
                const y = p.find(x => x.seriesName === '10Y Yield');
                if (y && y.value != null && view === '5y') s += '<div style="margin-top:3px;padding-top:3px;border-top:1px solid rgba(255,255,255,0.1);color:' + RATES_MUTED + ';">' + getYieldZoneLabel(y.value, zt) + '</div>';
                return s;
            } },
        xAxis: { type: 'category', data: dates, boundaryGap: false,
                 axisLabel: { color: RATES_DIM, fontSize: 10, formatter: v => v.substring(0, 7) },
                 axisLine: { lineStyle: { color: '#334155' } } },
        yAxis: yAxes, series: series,
    }, true);
}

// V1.9: 评分说明 — 原"美债信号中枢"的久期倾向/止盈/逆向规则基于同一套未通过验证的评分, 已移除
function renderRatesScoreNote(sig) {
    const el = document.getElementById('rates-score-note');
    if (!el) return;
    const score = (sig && typeof sig.score === 'number') ? sig.score : null;
    const bs = (sig && typeof sig.bond_signal === 'number') ? sig.bond_signal : (score === null ? null : Math.round((score - 50) * 2));
    const n = v => `<b style="color:${RATES_NEUTRAL};font-variant-numeric:tabular-nums;">${v}</b>`;
    el.innerHTML =
        `<div>五维综合分 ${n(score === null ? '--' : score)} · 美债信号 ${n(bs === null ? '--' : (bs > 0 ? '+' : '') + bs)} <span style="color:${RATES_DIM};">(−100~+100)</span></div>` +
        `<div style="margin-top:4px;">2026-11-01 预注册验证：这套评分在 2015 年以后的样本外<b style="color:${RATES_NEUTRAL};">没有显著择时能力</b>，已降级为背景。多资产里美债固定 30%，JCS 中美债固定为中性。</div>` +
        `<div style="margin-top:4px;color:${RATES_DIM};">原"久期倾向 / 止盈 / 逆向规则"出自同一套评分，已移除。详见 docs/RATES_V2_VALIDATION_RESULTS.md。</div>`;
}

// V1.9: 长期持有回报参考 (替代原"买卖决策区"条件清单) — 历史分布, 非预测, 不构成买卖建议
function renderRatesReturnRef(ref) {
    const el = document.getElementById('rates-decision-zone');
    if (!el) return;
    el.style.display = 'block';
    el.style.borderColor = 'rgba(148,163,184,0.15)';
    const head = `<div style="display:flex;justify-content:space-between;align-items:baseline;gap:8px;margin-bottom:8px;flex-wrap:wrap;">
        <span style="font-size:0.8rem;color:${RATES_NEUTRAL};font-weight:600;">长期持有回报参考 · 10 年期美债</span>
        <span style="font-size:0.62rem;color:${RATES_DIM};">历史分布参考 · 非预测 · 不构成买卖建议</span></div>`;
    if (!ref) { el.innerHTML = head + `<div style="font-size:0.7rem;color:${RATES_DIM};">数据暂不可用</div>`; return; }
    const ytm = `<div style="font-size:0.72rem;color:${RATES_MUTED};margin-bottom:8px;">当前到期收益率 <b style="color:${RATES_NEUTRAL};">${ref.ytm.toFixed(2)}%</b>，约等于持有至到期的名义年化回报 (美元计价，不计再投资差异)。</div>`;
    if (ref.status !== 'ok') {
        const msg = ref.status === 'not_run'
            ? '参考区间研究尚未运行 (docs/RATES_EXPECTED_RETURN_PREREGISTRATION.md)，暂不显示区间。'
            : '参考区间数据读取失败，暂不显示。';
        el.innerHTML = head + ytm + `<div style="font-size:0.66rem;color:${RATES_DIM};">${msg}</div>`;
        return;
    }
    const rows = (ref.horizons || []).map(h => {
        if (!h.pass) return `<tr><td style="padding:5px 8px;color:${RATES_MUTED};">持有 ${h.years} 年</td><td colspan="3" style="padding:5px 8px;color:${RATES_DIM};">未通过预注册检验，不显示区间</td></tr>`;
        const cov = h.oos_coverage != null ? Math.round(h.oos_coverage * 100) + '%' : '—';
        return `<tr><td style="padding:5px 8px;color:${RATES_MUTED};">持有 ${h.years} 年</td>
            <td style="padding:5px 8px;color:${RATES_NEUTRAL};font-weight:700;">${h.median.toFixed(1)}%</td>
            <td style="padding:5px 8px;color:${RATES_NEUTRAL};">${h.p10.toFixed(1)}% – ${h.p90.toFixed(1)}%${h.extrapolated ? ` <span style="color:#f59e0b;">外推</span>` : ''}</td>
            <td style="padding:5px 8px;color:${RATES_DIM};">${h.n_windows} 个月 · 不重叠约 ${h.n_independent} 个 · 样本外覆盖 ${cov}</td></tr>`;
    }).join('');
    el.innerHTML = head + ytm + `<table style="width:100%;border-collapse:collapse;font-size:0.68rem;font-variant-numeric:tabular-nums;">
        <thead><tr style="color:${RATES_DIM};text-align:left;border-bottom:1px solid rgba(148,163,184,0.15);">
            <th style="padding:4px 8px;font-weight:500;">持有期</th><th style="padding:4px 8px;font-weight:500;">年化中位</th>
            <th style="padding:4px 8px;font-weight:500;">80% 区间</th><th style="padding:4px 8px;font-weight:500;">样本</th></tr></thead>
        <tbody>${rows}</tbody></table>
        <div style="font-size:0.6rem;color:${RATES_DIM};margin-top:6px;line-height:1.5;">按 1962 年以来"起始收益率 → 之后滚动持有 10 年期美债的年化总回报"回归得出；窗口高度重叠，独立样本少，是历史分布而非显著性证明。名义美元回报，不含汇率与 QDII 费用。数据截至 ${ref.data_through || '—'}。${ref.stale ? ` <span style="color:#f59e0b;">研究结果超过一年未更新，请重跑 strategies/rates_expected_return_research.py。</span>` : ''}</div>`;
}

// V1.8: 环境摘要条 — 只陈述事实 (替代原"信号清单"), 各项附数据日期
function renderRatesContextBar(ctx) {
    const el = document.getElementById('rates-chart-action-bar');
    if (!el) return;
    ctx = ctx || {};
    const us = ctx.us10y || {}, real = ctx.real10y || {}, cn = ctx.cn10y, curve = ctx.curve || {};
    const item = (label, html, title) => `<span title="${title || ''}" style="white-space:nowrap;"><span style="color:${RATES_DIM};">${label}</span> ${html}</span>`;
    const sep = `<span style="color:#334155;">|</span>`;
    const v = (x, d) => x == null ? '—' : `<span style="color:${RATES_NEUTRAL};">${x.toFixed(d == null ? 2 : d)}%</span>`;
    const parts1 = [
        item('美国10Y', v(us.value) + ' 1M ' + _ratesChgSpan(us.chg_1m_bps) + ' 3M ' + _ratesChgSpan(us.chg_3m_bps), '数据日 ' + (us.date || '—')),
        item('曲线', `<span style="color:${RATES_NEUTRAL};">${curve.regime_cn || '—'}</span> 3M利差 ` + _ratesChgSpan(curve.spread_chg_3m_bps), curve.note || ''),
    ];
    const cnTxt = cn ? (v(cn.value) + ' 3M ' + _ratesChgSpan(cn.chg_3m_bps) + (cn.stale ? ` <span style="color:#f59e0b;">数据较旧 ${cn.date}</span>` : '')) : '<span style="color:' + RATES_DIM + ';">暂不可用</span>';
    const spreadTxt = ctx.cn_us_spread_bps != null ? `<span style="color:${RATES_NEUTRAL};">${ctx.cn_us_spread_bps > 0 ? '+' : ''}${ctx.cn_us_spread_bps}bps</span>` : '—';
    const parts2 = [
        item('美国实际利率', v(real.value) + (real.pct_5y != null ? ` <span style="color:${RATES_DIM};">5年分位${Math.round(real.pct_5y)}%</span>` : '') + ' 3M ' + _ratesChgSpan(real.chg_3m_bps), '数据日 ' + (real.date || '—') + ' · 全球成长股估值的折现率参考'),
        item('中国10Y', cnTxt, cn ? '数据日 ' + cn.date : ''),
        item('中美利差', spreadTxt, '中国10Y − 美国10Y; 影响人民币与外资流向'),
    ];
    el.innerHTML = `<div style="display:flex;flex-direction:column;gap:5px;padding:8px 12px;background:rgba(15,23,42,0.5);border:1px solid rgba(100,116,139,0.12);border-radius:6px;font-size:0.66rem;font-variant-numeric:tabular-nums;">
        <div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap;"><span style="color:${RATES_MUTED};font-weight:600;">环境摘要</span>${parts1.join(sep)}<span style="flex:1;"></span><span style="color:${RATES_DIM};">仅背景 · 不驱动仓位</span></div>
        <div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap;"><span style="color:${RATES_MUTED};font-weight:600;">A 股视角</span>${parts2.join(sep)}</div>
    </div>`;
}

// V3.1: 图表区操作信号条 — 紧凑版买卖/警示提醒 (用户不用滚回顶部)
function renderRatesChartActionBar(bsz, signal, alerts) {
    const el = document.getElementById('rates-chart-action-bar');
    if (!el || !bsz) return;

    // 提取已满足的条件 (最多显示2条)
    const metBonds = (bsz.bond_buy || []).filter(c => c.met).slice(0, 2);
    const metStocks = (bsz.stock_buy || []).filter(c => c.met).slice(0, 2);
    const metDefense = (bsz.defense || []).filter(c => c.met).slice(0, 2);

    // 条件简写渲染
    const renderMet = (items, color) => items.map(c =>
        `<span style="font-size:0.58rem;color:${color};background:${color}11;padding:1px 5px;border-radius:3px;border:1px solid ${color}22;">✅ ${c.cond} <span style="color:#fbbf24;font-weight:600;">${c.val}</span></span>`
    ).join(' ');

    // 警示信号 (仅触发的)
    const alertHtml = alerts.length > 0
        ? alerts.slice(0, 2).map(a => {
            const c = a.level === 'danger' ? '#ef4444' : a.level === 'opportunity' ? '#10b981' : '#f59e0b';
            return `<span style="font-size:0.58rem;color:${c};background:${c}11;padding:1px 5px;border-radius:3px;border:1px solid ${c}22;">${a.icon} ${a.text.substring(0, 30)}${a.text.length > 30 ? '...' : ''}</span>`;
        }).join(' ')
        : '';

    // 结论 badge
    const cc = bsz.conclusion_color || '#94a3b8';
    const conclusionBadge = `<span style="font-size:0.62rem;font-weight:700;color:${cc};background:${cc}15;padding:2px 10px;border-radius:12px;border:1px solid ${cc}33;white-space:nowrap;">${(signal.emoji||'')} ${signal.label||''} · ${signal.score||'--'} · ${signal.position||''}</span>`;

    el.innerHTML = `<div style="display:flex;align-items:center;gap:6px;padding:8px 12px;background:rgba(15,23,42,0.5);border:1px solid rgba(100,116,139,0.12);border-radius:8px;flex-wrap:wrap;">
        <span style="font-size:0.65rem;color:#c084fc;font-weight:600;flex-shrink:0;">⚡ 信号</span>
        ${bsz.bond_met > 0 ? `<span style="font-size:0.6rem;color:#10b981;flex-shrink:0;">🟢 债${bsz.bond_met}/${bsz.bond_buy.length}</span>` : ''}
        ${renderMet(metBonds, '#10b981')}
        ${bsz.stock_met > 0 ? `<span style="font-size:0.6rem;color:#f97316;flex-shrink:0;">🟠 股${bsz.stock_met}/${bsz.stock_buy.length}</span>` : ''}
        ${renderMet(metStocks, '#f97316')}
        ${bsz.defense_met > 0 ? `<span style="font-size:0.6rem;color:#ef4444;flex-shrink:0;">🔴 冲击${bsz.defense_met}/${bsz.defense.length}</span>` : ''}
        ${renderMet(metDefense, '#ef4444')}
        ${alertHtml ? `<span style="font-size:0.5rem;color:#475569;">│</span> ${alertHtml}` : ''}
        <span style="flex:1;"></span>
        ${conclusionBadge}
    </div>`;
}

function renderRatesAlerts(alerts) {
    const el = document.getElementById('rates-alerts');
    if (!el) return;
    if (!alerts.length) { el.style.display = 'none'; return; }
    el.style.display = 'flex';
    el.innerHTML = alerts.map(a => {
        const bg = a.level==='danger'?'rgba(239,68,68,0.08)':a.level==='opportunity'?'rgba(16,185,129,0.08)':'rgba(245,158,11,0.08)';
        const bc = a.level==='danger'?'rgba(239,68,68,0.3)':a.level==='opportunity'?'rgba(16,185,129,0.3)':'rgba(245,158,11,0.3)';
        const pulse = a.pulse ? 'animation:pulse 2s infinite;' : '';
        return '<div style="padding:6px 14px;border:1px solid '+bc+';background:'+bg+';border-radius:6px;font-size:0.72rem;color:#e2e8f0;'+pulse+'">🏦 '+a.icon+' '+a.text+'</div>';
    }).join('');
}

function renderRatesDiagnosis(diagnosis) {
    // V1.9: 五维各一张卡, 统一中性样式, 只陈述读数 (不再用 ✅/⚠️ 评判)
    const diagEl = document.getElementById('rates-diagnosis');
    if (!diagEl || !diagnosis.length) return;
    diagEl.innerHTML = diagnosis.map(c =>
        '<div style="background:rgba(15,23,42,0.5);border:1px solid rgba(148,163,184,0.15);border-radius:6px;padding:7px 9px;">' +
        '<div style="font-size:0.65rem;font-weight:600;color:#e2e8f0;margin-bottom:2px;">' + c.title + '</div>' +
        '<div style="font-size:0.58rem;color:#94a3b8;line-height:1.4;font-variant-numeric:tabular-nums;">' + c.text + '</div></div>'
    ).join('');
}

function renderRatesEncyclopedia(enc) {
    // V1.5: 百科已改为tooltip模式，此函数保留但不渲染
}

// === V2.1: 买卖决策汇总区 (D1视觉强化 + B1得分构成 + D3响应式 + D4自适应) ===
function renderRatesDecisionZone(bsz) {
    const el = document.getElementById('rates-decision-zone');
    if (!el || !bsz) return;
    el.style.display = 'block';

    const pct = bsz.percentile_stats || {};

    const miniPctBar = (item) => {
        if (!item.pct && item.pct !== 0) return '';
        const p = Math.max(0, Math.min(100, item.pct));
        const barColor = p >= 75 ? '#10b981' : p >= 25 ? '#f59e0b' : '#ef4444';
        return '<div style="width:48px;height:4px;background:rgba(30,41,59,0.8);border-radius:2px;overflow:hidden;flex-shrink:0;" title="5Y分位:'+p.toFixed(0)+'%">' +
            '<div style="width:'+p+'%;height:100%;background:'+barColor+';border-radius:2px;transition:width 0.6s;"></div></div>' +
            '<span style="font-size:0.5rem;color:#64748b;flex-shrink:0;">P'+p.toFixed(0)+'</span>';
    };

    // D1: 已触发条件高亮 + 未触发弱化
    const renderConds = (items, color) => items.map(c => {
        const icon = c.met ? '<span style="color:#10b981;">✅</span>' : '<span style="color:#475569;">❌</span>';
        const valStyle = c.met ? 'color:#fbbf24;font-weight:600;' : 'color:#64748b;';
        const rowBg = c.met ? 'background:rgba(16,185,129,0.06);border-radius:4px;margin:1px -4px;padding:3px 4px;' : 'opacity:0.6;padding:3px 0;';
        return '<div style="display:flex;align-items:center;gap:5px;'+rowBg+'">' +
            icon + '<span style="color:' + (c.met ? '#e2e8f0' : '#64748b') + ';font-size:0.66rem;flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;' + (c.met ? 'font-weight:500;' : '') + '">' + c.cond + '</span>' +
            miniPctBar(c) +
            '<span style="'+valStyle+'font-size:0.63rem;flex-shrink:0;">' + c.val + '</span>' +
            '<span style="font-size:0.52rem;color:#64748b;flex-shrink:0;">' + c.why + '</span></div>';
    }).join('');

    // B1: 得分构成条 (紧凑单行)
    const bd = bsz.score_breakdown || [];
    const breakdownHtml = bd.length > 0
        ? '<div style="margin-top:8px;padding:6px 10px;background:rgba(192,132,252,0.03);border:1px solid rgba(192,132,252,0.1);border-radius:6px;display:flex;align-items:center;gap:6px;flex-wrap:wrap;">' +
          '<span style="font-size:0.6rem;color:#c084fc;font-weight:600;flex-shrink:0;">📊 得分构成</span>' +
          bd.map(d => {
              const barW = Math.max(2, Math.min(100, d.score));
              const barC = d.score >= 65 ? '#10b981' : d.score >= 50 ? '#f59e0b' : d.score >= 35 ? '#f97316' : '#ef4444';
              return '<span style="font-size:0.55rem;color:#94a3b8;display:inline-flex;align-items:center;gap:3px;" title="'+d.dim+': '+d.score+'×'+d.weight+'%='+d.contrib+'">' +
                  d.dim.substring(0,2) + ' ' +
                  '<span style="display:inline-block;width:24px;height:3px;background:rgba(30,41,59,0.8);border-radius:1px;overflow:hidden;vertical-align:middle;">' +
                  '<span style="display:block;width:'+barW+'%;height:100%;background:'+barC+';border-radius:1px;"></span></span> ' +
                  '<span style="color:'+barC+';font-weight:600;">'+d.contrib+'</span></span>';
          }).join('') +
          '<span style="font-size:0.55rem;color:#c084fc;font-weight:600;margin-left:auto;">Σ=' + bd.reduce((a,b) => a+b.contrib, 0).toFixed(1) + '</span>' +
          '</div>'
        : '';

    const pctFooter = pct.current_zone_label
        ? '<div style="margin-top:10px;padding:8px 12px;background:rgba(192,132,252,0.04);border:1px solid rgba(192,132,252,0.12);border-radius:6px;display:flex;align-items:center;gap:10px;flex-wrap:wrap;">' +
          '<span style="font-size:0.62rem;color:#c084fc;font-weight:600;">📐 5Y分位数</span>' +
          '<span style="font-size:0.58rem;color:#64748b;">P25='+pct.p25+'%</span>' +
          '<span style="font-size:0.58rem;color:#64748b;">P50='+pct.p50+'%</span>' +
          '<span style="font-size:0.58rem;color:#64748b;">P75='+pct.p75+'%</span>' +
          '<span style="font-size:0.58rem;color:#64748b;">σ='+pct.std+'</span>' +
          '<span style="font-size:0.62rem;color:'+(pct.current_zone_color||'#94a3b8')+';font-weight:600;margin-left:auto;">当前: '+(pct.current||'--')+'% · '+pct.current_zone_label+' (P'+(pct.current_pct||50).toFixed(0)+')</span>' +
          '</div>'
        : '';

    // D3: 结论badge flex-wrap, 窄屏自动换行
    const cc = bsz.conclusion_color||'#94a3b8';
    el.innerHTML = 
        '<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px;flex-wrap:wrap;gap:6px;">' +
        '<span style="font-size:0.82rem;font-weight:700;color:#c084fc;">📊 买卖决策汇总</span>' +
        '<div style="padding:4px 14px;border-radius:20px;font-size:0.72rem;font-weight:700;background:'+cc+'22;color:'+cc+';border:1px solid '+cc+'44;max-width:100%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">'+bsz.conclusion+'</div></div>' +
        // D4: 用class控制grid响应式
        '<div class="rates-decision-grid" style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:12px;">' +
        // 债券买入区
        '<div style="background:rgba(16,185,129,0.04);border:1px solid rgba(16,185,129,0.15);border-radius:8px;padding:10px;">' +
        '<div style="font-size:0.7rem;font-weight:600;color:#10b981;margin-bottom:6px;">🟢 债券买入区 <span style="font-size:0.6rem;color:#64748b;">'+bsz.bond_met+'/'+bsz.bond_buy.length+'</span></div>' +
        renderConds(bsz.bond_buy, '#10b981') + '</div>' +
        // 股票买入区
        '<div style="background:rgba(249,115,22,0.04);border:1px solid rgba(249,115,22,0.15);border-radius:8px;padding:10px;">' +
        '<div style="font-size:0.7rem;font-weight:600;color:#f97316;margin-bottom:6px;">🟠 低利率条件 <span style="font-size:0.6rem;color:#64748b;">'+bsz.stock_met+'/'+bsz.stock_buy.length+'</span></div>' +
        renderConds(bsz.stock_buy, '#f97316') + '</div>' +
        // 避险区
        '<div style="background:rgba(239,68,68,0.04);border:1px solid rgba(239,68,68,0.15);border-radius:8px;padding:10px;">' +
        '<div style="font-size:0.7rem;font-weight:600;color:#ef4444;margin-bottom:6px;">🔴 利率冲击区 <span style="font-size:0.6rem;color:#64748b;">'+bsz.defense_met+'/'+bsz.defense.length+'</span></div>' +
        renderConds(bsz.defense, '#ef4444') + '</div>' +
        '</div>' +
        breakdownHtml +
        pctFooter;
}

// === V1.5: 卡片Tooltip ===
let _ratesActiveTooltips = null;
function setupRatesTooltips(tips) {
    _ratesActiveTooltips = tips;
    const popup = document.getElementById('rates-tooltip-popup');
    if (!popup) return;
    document.querySelectorAll('.rates-card-tip').forEach(card => {
        card.addEventListener('mouseenter', function(e) {
            const key = this.dataset.tipKey;
            const tip = _ratesActiveTooltips[key];
            if (!tip) return;
            document.getElementById('rates-tip-title').textContent = tip.title || '';
            document.getElementById('rates-tip-desc').textContent = tip.desc || '';
            document.getElementById('rates-tip-logic').textContent = '📐 ' + (tip.logic || '');
            document.getElementById('rates-tip-alert').textContent = tip.alert || '';
            document.getElementById('rates-tip-history').textContent = tip.history ? '📊 ' + tip.history : '';
            const rect = this.getBoundingClientRect();
            popup.style.left = Math.min(rect.left + window.scrollX, window.innerWidth - 300) + 'px';
            popup.style.top = (rect.bottom + window.scrollY + 8) + 'px';
            popup.style.display = 'block';
        });
        card.addEventListener('mouseleave', function() {
            popup.style.display = 'none';
        });
    });
}

// [V3.1] 重复的 renderRatesChart 已删除 (使用 L3432 的V3.0版本)


// Phase 2: resize 已由 alphacore_utils.js 注册中心统一处理


// ====================================================================
//  海外 AIAE 宏观仓位管控模块 V1.1
//  US(蓝) + JP(红) 双面板 | 五档竖卡 | 警示指标 | 三地对比 | 合并操作区
// ====================================================================

let _globalAIAEData = null;
let _globalAIAELoading = false;

async function loadGlobalAIAE(forceRefresh = false) {
    if (_globalAIAELoading) return;
    if (_globalAIAEData && !forceRefresh) {
        renderGlobalAIAE(_globalAIAEData);
        return;
    }

    _globalAIAELoading = true;
    const btn = document.getElementById('gaiae-refresh-btn');
    if (btn) { btn.disabled = true; btn.innerHTML = '⏳ 加载中...'; }

    try {
        const endpoint = forceRefresh ? '/api/v1/aiae_global/refresh' : '/api/v1/aiae_global/report';
        // P2-1: 12s超时 + 1次自动重试
        let resp;
        try {
            resp = await fetch(endpoint, { signal: AbortSignal.timeout(12000) });
        } catch (e1) {
            if (e1.name === 'TimeoutError' || e1.name === 'AbortError') {
                console.warn('[GlobalAIAE] 首次请求超时, 自动重试...');
                resp = await fetch(endpoint, { signal: AbortSignal.timeout(15000) });
            } else { throw e1; }
        }
        const json = await resp.json();
        if (json.status === 'success') {
            _globalAIAEData = json;
            renderGlobalAIAE(json);
            const t = document.getElementById('gaiae-update-time');
            if (t) t.textContent = new Date().toLocaleTimeString('zh-CN');
        } else {
            console.error('[GlobalAIAE] Error:', json.message);
        }
    } catch (e) {
        console.error('[GlobalAIAE] Fetch failed:', e);
    }
    if (btn) { btn.disabled = false; btn.innerHTML = '🔄 刷新'; }
    _globalAIAELoading = false;
}

function renderGlobalAIAE(json) {
    const us = json.us || {};
    const jp = json.jp || {};
    const hk = json.hk || {};
    const gc = json.global_comparison || {};

    // -- Region panels --
    renderGAIAERegionPanel('us', us, '#3b82f6');
    renderGAIAERegionPanel('jp', jp, '#dc2626');
    renderGAIAERegionPanel('hk', hk, '#a855f7');

    // Hero values
    const usV1 = (us.current||{}).aiae_v1 || 0;
    const jpV1 = (jp.current||{}).aiae_v1 || 0;
    const hkV1 = (hk.current||{}).aiae_v1 || 0;
    const usRI = (us.current||{}).regime_info || {};
    const jpRI = (jp.current||{}).regime_info || {};
    const hkRI = (hk.current||{}).regime_info || {};

    // V1.4: 数据源降级检测 — fallback/stale_cache 时显示警告
    function _checkDegraded(reportData) {
        const raw = (reportData||{}).raw_data || {};
        const mkt = raw.mkt || {};
        if (mkt.is_fallback) return { degraded: true, label: '⚠️ 降级', tip: '数据源: 硬编码 (yfinance/FRED失败)', color: '#ef4444' };
        if (mkt.is_stale_cache) return { degraded: true, label: '⚠️ 旧缓存', tip: '数据源: 过期磁盘缓存 (在线源失败)', color: '#f59e0b' };
        const src = mkt.source || '';
        if (src.includes('stooq')) return { degraded: false, label: '', tip: '数据源: Stooq', color: '' };
        return { degraded: false, label: '', tip: '', color: '' };
    }
    const usDeg = _checkDegraded(us);
    const jpDeg = _checkDegraded(jp);
    const hkDeg = _checkDegraded(hk);

    const $usV = document.getElementById('gaiae-us-value');
    const $jpV = document.getElementById('gaiae-jp-value');
    const $hkV = document.getElementById('gaiae-hk-value');
    const $usR = document.getElementById('gaiae-us-regime');
    const $jpR = document.getElementById('gaiae-jp-regime');
    const $hkR = document.getElementById('gaiae-hk-regime');
    if ($usV) $usV.textContent = usV1.toFixed(1) + '%' + (usDeg.degraded ? ' ⚠️' : '');
    if ($jpV) $jpV.textContent = jpV1.toFixed(1) + '%' + (jpDeg.degraded ? ' ⚠️' : '');
    if ($hkV) $hkV.textContent = hkV1.toFixed(1) + '%' + (hkDeg.degraded ? ' ⚠️' : '');
    if ($usR) {
        $usR.innerHTML = (usRI.emoji||'') + ' ' + (usRI.cn||'--') +
            (usDeg.degraded ? ' <span style="font-size:0.5rem;color:'+usDeg.color+';background:'+usDeg.color+'15;padding:1px 5px;border-radius:3px;border:1px solid '+usDeg.color+'33" title="'+usDeg.tip+'">'+usDeg.label+'</span>' : '');
        $usR.style.color = usRI.color||'#94a3b8';
    }
    if ($jpR) {
        $jpR.innerHTML = (jpRI.emoji||'') + ' ' + (jpRI.cn||'--') +
            (jpDeg.degraded ? ' <span style="font-size:0.5rem;color:'+jpDeg.color+';background:'+jpDeg.color+'15;padding:1px 5px;border-radius:3px;border:1px solid '+jpDeg.color+'33" title="'+jpDeg.tip+'">'+jpDeg.label+'</span>' : '');
        $jpR.style.color = jpRI.color||'#94a3b8';
    }
    if ($hkR) {
        $hkR.innerHTML = (hkRI.emoji||'') + ' ' + (hkRI.cn||'--') +
            (hkDeg.degraded ? ' <span style="font-size:0.5rem;color:'+hkDeg.color+';background:'+hkDeg.color+'15;padding:1px 5px;border-radius:3px;border:1px solid '+hkDeg.color+'33" title="'+hkDeg.tip+'">'+hkDeg.label+'</span>' : '');
        $hkR.style.color = hkRI.color||'#94a3b8';
    }

    // Coldest market hero card
    const regionMap = { cn: '🇨🇳 A股', us: '🇺🇸 美股', jp: '🇯🇵 日股', hk: '🇭🇰 港股' };
    const $cold = document.getElementById('gaiae-coldest');
    const $coldL = document.getElementById('gaiae-coldest-label');
    const $coldCard = document.getElementById('gaiae-coldest-card');
    if ($cold) $cold.textContent = regionMap[gc.coldest] || '--';
    if ($coldL) $coldL.textContent = '超配优先 · 远离过热';
    if ($coldCard) $coldCard.classList.add('coldest-glow');

    // Matrices
    renderGAIAEMatrix('us', us);
    renderGAIAEMatrix('jp', jp);
    renderGAIAEMatrix('hk', hk);

    // 4-way comparison
    renderGAIAE3Way(gc);

    // Warning indicators
    renderGAIAEWarnings('us', us);
    renderGAIAEWarnings('jp', jp);
    renderGAIAEWarnings('hk', hk);

    // Consolidated actions
    renderGAIAEActionZone((us.current||{}).regime || 3, (jp.current||{}).regime || 3, (hk.current||{}).regime || 3);

    // Charts
    try { renderGAIAEHistoryChart(us.chart, jp.chart, hk.chart); } catch(e) { console.warn('[GAIAE] chart skip:', e); }
}

function renderGAIAERegionPanel(region, data, color) {
    if (!data || !data.current) return;
    const c = data.current;
    const ri = c.regime_info || {};

    // Gauge
    const max = region === 'us' ? 50 : (region === 'jp' ? 40 : 45);
    const bands = region === 'us'
        ? [[0.30,'#10b981'],[0.40,'#3b82f6'],[0.54,'#eab308'],[0.68,'#f97316'],[1,'#ef4444']]
        : region === 'jp'
        ? [[0.25,'#10b981'],[0.35,'#3b82f6'],[0.50,'#eab308'],[0.70,'#f97316'],[1,'#ef4444']]
        : [[0.18,'#10b981'],[0.31,'#3b82f6'],[0.49,'#eab308'],[0.67,'#f97316'],[1,'#ef4444']];

    try {
        const el = document.getElementById('gaiae-' + region + '-gauge');
        if (el && typeof echarts !== 'undefined') {
            const key = '_gaiae' + region.charAt(0).toUpperCase() + region.slice(1) + 'Gauge';
            if (window[key]) AC.disposeChart(window[key]);
            window[key] = AC.registerChart(echarts.init(el));
            window[key].setOption({
                series: [{
                    type: 'gauge', startAngle: 200, endAngle: -20, min: 0, max: max,
                    pointer: { show: true, length: '55%', width: 4, itemStyle: { color: ri.color || color, shadowColor: (ri.color||color), shadowBlur: 6 }, icon: 'triangle' },
                    anchor: { show: true, size: 8, itemStyle: { color: '#0f172a', borderColor: ri.color||color, borderWidth: 2 } },
                    axisLine: { lineStyle: { width: 12, color: bands } },
                    axisTick: { length: 6, distance: -12, lineStyle: { color: 'auto', width: 1 } },
                    splitLine: { length: 10, distance: -12, lineStyle: { color: 'auto', width: 1.5 } },
                    splitNumber: 5,
                    axisLabel: { distance: -28, color: '#64748b', fontSize: 8 },
                    detail: { show: false },
                    data: [{ value: Math.min(Math.max(c.aiae_v1, 0), max) }],
                    animationDuration: 1200
                }]
            });
        }
    } catch(e) { console.warn('[GAIAE] gauge error:', e); }

    // Gauge labels
    const $gv = document.getElementById('gaiae-' + region + '-gauge-val');
    const $gr = document.getElementById('gaiae-' + region + '-gauge-regime');
    if ($gv) $gv.textContent = c.aiae_v1.toFixed(1) + '%';
    if ($gr) { $gr.textContent = (ri.emoji||'') + ' ' + (ri.cn||'--') + ' · 建议仓位 ' + (data.position||{}).matrix_position + '%'; $gr.style.color = ri.color||'#94a3b8'; }

    // ⑤ Regime cards highlight
    const cardsEl = document.getElementById('gaiae-' + region + '-regime-cards');
    if (cardsEl) {
        cardsEl.querySelectorAll('.gaiae-rc').forEach(card => {
            card.classList.toggle('active', parseInt(card.dataset.regime) === c.regime);
        });
    }

    // Factor cards
    const $core = document.getElementById('gaiae-' + region + '-core');
    if ($core) $core.textContent = (c.aiae_core||0).toFixed(1) + '%';

    if (region === 'us') {
        const $margin = document.getElementById('gaiae-us-margin');
        const $aaii = document.getElementById('gaiae-us-aaii');
        if ($margin) $margin.textContent = (c.margin_heat||0).toFixed(2) + '%';
        if ($aaii) {
            const spread = (c.aaii_sentiment||{}).spread || 0;
            $aaii.textContent = (spread > 0 ? '+' : '') + spread.toFixed(0) + '%';
            $aaii.style.color = spread > 15 ? '#ef4444' : spread < -10 ? '#10b981' : '#e2e8f0';
        }
    } else if (region === 'jp') {
        const $margin = document.getElementById('gaiae-jp-margin');
        const $foreign = document.getElementById('gaiae-jp-foreign');
        if ($margin) $margin.textContent = (c.margin_heat||0).toFixed(2) + '%';
        if ($foreign) {
            const net = (c.foreign_flow||{}).net_buy_billion_jpy || 0;
            $foreign.textContent = (net > 0 ? '+' : '') + (net/100).toFixed(0) + '億円';
            $foreign.style.color = net > 2000 ? '#3b82f6' : net < -2000 ? '#ef4444' : '#e2e8f0';
        }
    } else if (region === 'hk') {
        const $sb = document.getElementById('gaiae-hk-southbound');
        const $ah = document.getElementById('gaiae-hk-ahpremium');
        if ($sb) {
            const sbHeat = c.southbound_heat || 0;
            // sbHeat from engine is already a percentage (e.g. 1.12 = 1.12%)
            $sb.textContent = sbHeat.toFixed(2) + '%';
            $sb.style.color = sbHeat > 1.5 ? '#ef4444' : sbHeat < 0.5 ? '#10b981' : '#e2e8f0';
        }
        if ($ah) {
            const ahVal = typeof c.ah_premium === 'object'
                ? (c.ah_premium.index_value || 135)
                : (typeof c.ah_premium === 'number' ? c.ah_premium : 135);
            $ah.textContent = ahVal.toFixed(0);
            $ah.style.color = ahVal > 145 ? '#10b981' : ahVal < 115 ? '#ef4444' : '#e2e8f0';
        }
    }

    // Signals
    const sigEl = document.getElementById('gaiae-' + region + '-signals');
    if (sigEl && data.signals) {
        sigEl.innerHTML = data.signals.map(s => {
            return '<div class="gaiae-signal-item" style="border-color:' + (s.color||'#f59e0b') + '"><span>' + s.text + '</span></div>';
        }).join('');
    }
}

// ② Warning indicators rendering
function renderGAIAEWarnings(region, data) {
    if (!data || !data.current) return;
    const c = data.current;
    const slope = (data.position||{}).slope || 0;

    if (region === 'us') {
        _setWarnIndicator('gaiae-us-warn-margin', 'gaiae-us-warn-margin-val', 'gaiae-us-warn-margin-bar',
            c.margin_heat || 0, '%', 1.5, 1.0);
        _setWarnIndicator('gaiae-us-warn-slope', 'gaiae-us-warn-slope-val', 'gaiae-us-warn-slope-bar',
            Math.abs(slope), '', 3.0, 1.5, slope);
        const spread = (c.aaii_sentiment||{}).spread || 0;
        _setWarnIndicator('gaiae-us-warn-aaii', 'gaiae-us-warn-aaii-val', 'gaiae-us-warn-aaii-bar',
            spread, '%', 20, 10);
    } else if (region === 'jp') {
        _setWarnIndicator('gaiae-jp-warn-margin', 'gaiae-jp-warn-margin-val', 'gaiae-jp-warn-margin-bar',
            c.margin_heat || 0, '%', 0.6, 0.4);
        _setWarnIndicator('gaiae-jp-warn-slope', 'gaiae-jp-warn-slope-val', 'gaiae-jp-warn-slope-bar',
            Math.abs(slope), '', 2.0, 1.0, slope);
        const foreign = (c.foreign_flow||{}).net_buy_billion_jpy || 0;
        _setWarnIndicator('gaiae-jp-warn-foreign', 'gaiae-jp-warn-foreign-val', 'gaiae-jp-warn-foreign-bar',
            foreign / 100, '億', 30, 15);
    } else if (region === 'hk') {
        // sbHeat is already a percentage from engine (e.g. 1.12 = 1.12%)
        const sbHeat = c.southbound_heat || 0;
        _setWarnIndicator('gaiae-hk-warn-sb', 'gaiae-hk-warn-sb-val', 'gaiae-hk-warn-sb-bar',
            sbHeat, '%', 2.0, 1.0);
        _setWarnIndicator('gaiae-hk-warn-slope', 'gaiae-hk-warn-slope-val', 'gaiae-hk-warn-slope-bar',
            Math.abs(slope), '', 2.5, 1.5, slope);
        const ahPremium = typeof c.ah_premium === 'object'
            ? (c.ah_premium.index_value || 135)
            : (typeof c.ah_premium === 'number' ? c.ah_premium : 135);
        _setWarnIndicator('gaiae-hk-warn-ah', 'gaiae-hk-warn-ah-val', 'gaiae-hk-warn-ah-bar',
            ahPremium, '', 145, 130);
    }
}

function _setWarnIndicator(cardId, valId, barId, value, unit, dangerThreshold, cautionThreshold, displayVal) {
    const card = document.getElementById(cardId);
    const $val = document.getElementById(valId);
    const $bar = document.getElementById(barId);
    if (!card) return;

    const dv = displayVal !== undefined ? displayVal : value;
    const absVal = Math.abs(value);
    const isDanger = absVal >= dangerThreshold;
    const isCaution = absVal >= cautionThreshold && !isDanger;

    card.className = 'gaiae-warn-card ' + (isDanger ? 'warn-danger' : isCaution ? 'warn-caution' : 'warn-ok');
    if ($val) {
        $val.textContent = (typeof dv === 'number' ? (dv > 0 ? '+' : '') + dv.toFixed(2) : dv) + unit;
        $val.style.color = isDanger ? '#ef4444' : isCaution ? '#f59e0b' : '#10b981';
    }
    if ($bar) {
        const pct = Math.min((absVal / dangerThreshold) * 100, 100);
        $bar.style.width = pct + '%';
        $bar.style.background = isDanger ? '#ef4444' : isCaution ? '#f59e0b' : '#10b981';
    }
}

function renderGAIAEMatrix(region, data) {
    if (!data || !data.position) return;
    const pos = data.position;
    const cv = data.cross_validation || {};

    // Cross-validation verdict
    const $cv = document.getElementById('gaiae-' + region + '-cv-verdict');
    if ($cv) {
        const regimeRN = {1:'Ⅰ', 2:'Ⅱ', 3:'Ⅲ', 4:'Ⅳ', 5:'Ⅴ'};
        $cv.innerHTML = '当前: <b style="color:#f59e0b">' + (regimeRN[pos.regime]||pos.regime) + '级</b>' +
            ' × <b style="color:#60a5fa">ERP ' + (pos.erp_value||0).toFixed(1) + '%</b>' +
            ' → 建议仓位 <b style="color:' + (cv.color||'#10b981') + ';font-size:0.85rem">' + pos.matrix_position + '%</b>' +
            ' · <span style="color:' + (cv.color||'#94a3b8') + '">' + (cv.confidence_stars||'') + ' ' + (cv.verdict||'') + '</span>';
    }

    // Highlight active cell
    const table = document.getElementById('gaiae-' + region + '-matrix');
    if (!table) return;

    const erpMap_us = { 'erp_gt5': 0, 'erp_3_5': 1, 'erp_1_3': 2, 'erp_lt1': 3 };
    const erpMap_jp = { 'erp_gt4': 0, 'erp_2_4': 1, 'erp_0_2': 2, 'erp_lt0': 3 };
    const erpMap_hk = { 'erp_gt5': 0, 'erp_3_5': 1, 'erp_1_3': 2, 'erp_lt1': 3 };
    const erpMap = region === 'us' ? erpMap_us : (region === 'jp' ? erpMap_jp : erpMap_hk);
    const rowIdx = erpMap[pos.erp_level] ?? 2;
    const colIdx = Math.min((pos.regime||3) - 1, 4);

    // ── 从 API pos.matrix 动态构建 posValues (消除硬编码) ──
    const erpKeysMap = {
        us: ['erp_gt5', 'erp_3_5', 'erp_1_3', 'erp_lt1'],
        jp: ['erp_gt4', 'erp_2_4', 'erp_0_2', 'erp_lt0'],
        hk: ['erp_gt5', 'erp_3_5', 'erp_1_3', 'erp_lt1']
    };
    const fallbackMatrix = {erp_gt5:[95,85,70,45,20], erp_3_5:[90,80,65,40,15], erp_1_3:[85,70,55,30,10], erp_lt1:[75,60,40,20,5],
                            erp_gt4:[95,85,70,45,20], erp_2_4:[90,80,65,40,15], erp_0_2:[85,70,55,30,10], erp_lt0:[75,60,40,20,5]};
    const mx = pos.matrix || fallbackMatrix;
    const erpKeys = erpKeysMap[region] || erpKeysMap.us;
    const posValues = erpKeys.map(k => mx[k] || fallbackMatrix[k]);

    // Color all cells + dynamic text
    function posColor(v) {
        if (v >= 80) return 'rgba(16,185,129,0.15)';
        if (v >= 60) return 'rgba(52,211,153,0.08)';
        if (v >= 40) return 'rgba(234,179,8,0.08)';
        if (v >= 20) return 'rgba(249,115,22,0.08)';
        return 'rgba(239,68,68,0.1)';
    }
    const rows = table.querySelectorAll('tbody tr');
    rows.forEach((row, ri) => {
        const cells = row.querySelectorAll('td');
        cells.forEach((td, ci) => {
            td.classList.remove('gaiae-cell-active');
            if (ci > 0 && posValues[ri]) {
                const val = posValues[ri][ci - 1];
                td.textContent = val + '%';
                td.style.background = posColor(val);
            }
        });
    });
    if (rows[rowIdx]) {
        const cells = rows[rowIdx].querySelectorAll('td');
        if (cells[colIdx + 1]) cells[colIdx + 1].classList.add('gaiae-cell-active');
    }
}

function renderGAIAE3Way(gc) {
    if (!gc) return;
    const regimeNames = {1: 'Ⅰ极度恐慌', 2: 'Ⅱ低配置区', 3: 'Ⅲ中性均衡', 4: 'Ⅳ偏热区域', 5: 'Ⅴ极度过热'};
    const regimeColors = {1: '#10b981', 2: '#3b82f6', 3: '#eab308', 4: '#f97316', 5: '#ef4444'};

    const $cn = document.getElementById('gaiae-3way-cn');
    const $us = document.getElementById('gaiae-3way-us');
    const $jp = document.getElementById('gaiae-3way-jp');
    const $hk = document.getElementById('gaiae-3way-hk');
    const $cnR = document.getElementById('gaiae-3way-cn-regime');
    const $usR = document.getElementById('gaiae-3way-us-regime');
    const $jpR = document.getElementById('gaiae-3way-jp-regime');
    const $hkR = document.getElementById('gaiae-3way-hk-regime');

    // P1: 卡片显示原始AIAE% + 归一化温度标注
    const tempMap = {cn: gc.cn_temp, us: gc.us_temp, jp: gc.jp_temp, hk: gc.hk_temp};
    function _setAiaeWithTemp($el, val, region) {
        if (!$el) return;
        const t = tempMap[region];
        $el.innerHTML = (val||0).toFixed(1) + '%' +
            (t != null ? '<span style="display:block;font-size:0.55rem;opacity:0.7;font-weight:400;margin-top:1px;">≈' + t.toFixed(0) + '°标准温度</span>' : '');
    }
    _setAiaeWithTemp($cn, gc.cn_aiae, 'cn');
    _setAiaeWithTemp($us, gc.us_aiae, 'us');
    _setAiaeWithTemp($jp, gc.jp_aiae, 'jp');
    _setAiaeWithTemp($hk, gc.hk_aiae, 'hk');
    if ($cnR) { $cnR.textContent = 'A股 ' + (regimeNames[gc.cn_regime]||'Ⅲ中性'); $cnR.style.color = regimeColors[gc.cn_regime]||'#94a3b8'; }
    if ($usR) { $usR.textContent = '美股 ' + (regimeNames[gc.us_regime]||'Ⅲ中性'); $usR.style.color = regimeColors[gc.us_regime]||'#94a3b8'; }
    if ($jpR) { $jpR.textContent = '日股 ' + (regimeNames[gc.jp_regime]||'Ⅲ中性'); $jpR.style.color = regimeColors[gc.jp_regime]||'#94a3b8'; }
    if ($hkR) { $hkR.textContent = '港股 ' + (regimeNames[gc.hk_regime]||'Ⅲ中性'); $hkR.style.color = regimeColors[gc.hk_regime]||'#94a3b8'; }

    // P0: 标准温度条 — 0-100° 统一标尺, 消除跨区域标度差异
    function _renderTempBar(elId, temp) {
        const el = document.getElementById(elId);
        if (!el || temp == null) return;
        const t = Math.max(0, Math.min(100, temp));
        // 色温: 0°=深绿 → 50°=黄 → 100°=深红
        const barColor = t <= 30 ? '#10b981' : t <= 50 ? '#eab308' : t <= 70 ? '#f97316' : '#ef4444';
        el.innerHTML =
            '<div style="display:flex;align-items:center;gap:4px;margin:3px 0;">' +
            '<div style="flex:1;height:4px;background:rgba(30,41,59,0.8);border-radius:2px;overflow:hidden;" title="标准温度 ' + t.toFixed(0) + '°">' +
            '<div style="width:' + t + '%;height:100%;background:' + barColor + ';border-radius:2px;transition:width 0.8s ease;"></div></div>' +
            '<span style="font-size:0.5rem;color:' + barColor + ';font-weight:600;min-width:24px;text-align:right;">' + t.toFixed(0) + '°</span></div>';
    }
    _renderTempBar('gaiae-3way-cn-temp', gc.cn_temp);
    _renderTempBar('gaiae-3way-us-temp', gc.us_temp);
    _renderTempBar('gaiae-3way-jp-temp', gc.jp_temp);
    _renderTempBar('gaiae-3way-hk-temp', gc.hk_temp);

    // Crown + P5: Ⅴ级极端告警脉动
    const coldest = gc.coldest || '';
    const extremeWarnings = (gc.global_position && gc.global_position.extreme_warnings) || [];
    ['cn','us','jp','hk'].forEach(r => {
        const card = document.getElementById('gaiae-3way-card-' + r);
        if (!card) return;
        card.classList.toggle('is-coldest', r === coldest);
        // P5: Ⅴ级市场添加脉动告警边框
        const isExtreme = extremeWarnings.includes(r);
        card.classList.toggle('gaiae-extreme', isExtreme);
        if (isExtreme) {
            card.style.borderColor = '#ef4444';
            card.style.boxShadow = '0 0 12px rgba(239,68,68,0.4)';
            // 添加极端标签（如不存在）
            if (!card.querySelector('.gaiae-extreme-badge')) {
                const badge = document.createElement('div');
                badge.className = 'gaiae-extreme-badge';
                badge.innerHTML = '⚠️ EXTREME';
                badge.style.cssText = 'position:absolute;top:4px;left:6px;font-size:0.5rem;color:#ef4444;font-weight:800;letter-spacing:0.5px;animation:gaiaeExtremePulse 1.5s ease-in-out infinite;';
                card.style.position = 'relative';
                card.appendChild(badge);
            }
        } else {
            card.style.borderColor = '';
            card.style.boxShadow = '';
            const oldBadge = card.querySelector('.gaiae-extreme-badge');
            if (oldBadge) oldBadge.remove();
        }
        // Crown
        const flagEl = card.querySelector('.gaiae-3way-flag');
        if (flagEl && r === coldest && !flagEl.querySelector('.gaiae-3way-crown')) {
            flagEl.innerHTML += ' <span class="gaiae-3way-crown">👑</span>';
        }
    });

    const $rec = document.getElementById('gaiae-recommendation');
    if ($rec) $rec.textContent = '🌍 ' + (gc.recommendation || '加载中...');

}

// ③ Consolidated action zone rendering
function renderGAIAEActionZone(usRegime, jpRegime, hkRegime) {
    // Determine which zone is active
    // Buy: regime 1-2, Hold: regime 3, Sell: regime 4-5
    // Use the "hotter" regime to be conservative
    const maxRegime = Math.max(usRegime, jpRegime, hkRegime || 3);

    const $buy = document.getElementById('gaiae-az-buy');
    const $hold = document.getElementById('gaiae-az-hold');
    const $sell = document.getElementById('gaiae-az-sell');

    if ($buy) {
        $buy.classList.toggle('az-active', maxRegime <= 2);
        $buy.classList.toggle('az-dimmed', maxRegime > 2);
    }
    if ($hold) {
        $hold.classList.toggle('az-active', maxRegime === 3);
        $hold.classList.toggle('az-dimmed', maxRegime !== 3);
    }
    if ($sell) {
        $sell.classList.toggle('az-active', maxRegime >= 4);
        $sell.classList.toggle('az-dimmed', maxRegime < 4);
    }

    // Update action content based on actual regimes
    const _rn = {1:'Ⅰ', 2:'Ⅱ', 3:'Ⅲ', 4:'Ⅳ', 5:'Ⅴ'};
    const usLabel = '🇺🇸 美股 (' + (_rn[usRegime]||usRegime) + '级)';
    const jpLabel = '🇯🇵 日股 (' + (_rn[jpRegime]||jpRegime) + '级)';
    const hkLabel = '🇭🇰 港股 (' + (_rn[hkRegime]||hkRegime) + '级)';
    const buyData = {
        1: { us: ['<b>极低 → 满配进攻</b>', '分3批建仓 SPY/QQQ', '总仓位冲至90-95%'], jp: ['<b>極度悲観 → 全力買い</b>', '3批建仓 1306/1321', '総ポジション90-95%'], hk: ['<b>极度恐慌 → 满配</b>', '分3批建仓 159920/513130', '仓位冲至90-95%'] },
        2: { us: ['<b>标准建仓区</b>', '目标仓位70-85%', 'ERP为正时加大买入'], jp: ['<b>標準建倉区</b>', '目標70-85%', '積極的にETF配分'], hk: ['<b>标准建仓区</b>', '目标70-85%', '南向资金流入验证'] },
        3: { us: ['Ⅲ级不主动加仓', '新增限制5%以内', '等待回调机会'], jp: ['Ⅲ級 加倉なし', '新規5%以内', '押し目待ち'], hk: ['Ⅲ级不加仓', '新增限制5%以内', '等待南向/AH信号'] },
        4: { us: ['<b>Ⅳ级禁止新开仓</b>', '不追涨进攻型标的', '仅保留红利型'], jp: ['<b>Ⅳ級 新規禁止</b>', '攻撃型銘柄撤退', '高配当のみ保有'], hk: ['<b>Ⅳ级禁止新开</b>', '科技ETF逐步撤退', '仅保留红利低波'] },
        5: { us: ['<b>Ⅴ级 绝对禁止买入</b>', '历史级泡沫信号', '任何新仓=与市场对赌'], jp: ['<b>Ⅴ級 絶対禁止</b>', 'バブル警報発令', '新規ポジション厳禁'], hk: ['<b>Ⅴ级 绝对禁止</b>', '2018年1月级泡沫', '任何新仓=接盘'] }
    };
    const holdData = {
        1: { us: ['每批完成后等3-5天', '只在下跌日建仓', '90-95%上限'], jp: ['各批3-5日間隔', '下落日のみ建倉', '90-95%上限'], hk: ['每批等3-5天', '只在下跌日建', '90-95%上限'] },
        2: { us: ['已建仓位坚定持有', '不因短期波动减仓', '观察AIAE方向'], jp: ['既存ポジション堅持', '短期変動で減らさない', 'AIAE方向を観察'], hk: ['仓位坚定持有', '不因波动减仓', '观察南向方向'] },
        3: { us: ['维持50-65%均衡仓位', '到目标价就卖', '宽基+红利为主'], jp: ['50-65%バランス維持', '目標価で売却', 'ETF+高配当中心'], hk: ['维持50-65%均衡', '恒生ETF+红利低波', '关注AH溢价'] },
        4: { us: ['总仓位压缩至25-40%', '进攻型逐步清退', '红利ETF可继续'], jp: ['25-40%へ圧縮', '攻撃型段階的撤退', '高配当ETF継続可'], hk: ['压缩至25-40%', '科技ETF逐步清退', '红利低波可继续'] },
        5: { us: ['仅保留0-15%极低仓', '仅限红利防御型', '现金为王'], jp: ['0-15%極低ポジション', '防御型ETFのみ', 'キャッシュ・イズ・キング'], hk: ['仅保留0-15%', '仅限恒生红利低波', '现金/债券为王'] }
    };
    const sellData = {
        1: { us: ['此档位禁止卖出', '除非触发组合-25%止损', '耐心持有'], jp: ['売却禁止', '組合-25%止損のみ', '忍耐保有'], hk: ['禁止卖出', '除非止损-25%', '耐心持有'] },
        2: { us: ['不主动卖出', '仅止损触发时被动减', '子策略止损: -8%'], jp: ['自発的売却なし', '止損のみ反応', '個別止損: -7%'], hk: ['不主动卖出', '仅止损时被动减', '个股止损: -8%'] },
        3: { us: ['到达止盈目标及时卖', '监控AIAE走向', '接近上档做准备'], jp: ['利確目標で売却', 'AIAE動向監視', '上昇接近で準備'], hk: ['止盈目标及时卖', '监控南向+AIAE', '接近Ⅳ做准备'] },
        4: { us: ['<b>每周减5%总仓位</b>', '优先清退高波动', '3-4周完成减仓'], jp: ['<b>毎週5%ずつ減倉</b>', '高ボラ銘柄から撤退', '3-4週間で完了'], hk: ['<b>每周减5%仓位</b>', '优先清退科技ETF', '3-4周完成'] },
        5: { us: ['<b>3天内完成清仓</b>', '无例外，不抄底', '强制执行，无论盈亏'], jp: ['<b>3日以内に完全撤退</b>', '例外なし・底打ち買い禁止', '損益問わず強制執行'], hk: ['<b>3天内完成清仓</b>', '无例外，不抄底', '强制执行'] }
    };

    const $buyList = document.getElementById('gaiae-az-buy-list');
    const $holdList = document.getElementById('gaiae-az-hold-list');
    const $sellList = document.getElementById('gaiae-az-sell-list');

    function makeList(data, usR, jpR, hkR) {
        const ud = data[usR] || data[3];
        const jd = data[jpR] || data[3];
        const hd = data[hkR] || data[3];
        return '<li class="az-region-label" style="color:#3b82f6">' + usLabel + '</li>' +
            ud.us.map(t => '<li>' + t + '</li>').join('') +
            '<li class="az-region-label" style="color:#dc2626">' + jpLabel + '</li>' +
            jd.jp.map(t => '<li>' + t + '</li>').join('') +
            '<li class="az-region-label" style="color:#a855f7">' + hkLabel + '</li>' +
            hd.hk.map(t => '<li>' + t + '</li>').join('');
    }

    if ($buyList) $buyList.innerHTML = makeList(buyData, usRegime, jpRegime, hkRegime);
    if ($holdList) $holdList.innerHTML = makeList(holdData, usRegime, jpRegime, hkRegime);
    if ($sellList) $sellList.innerHTML = makeList(sellData, usRegime, jpRegime, hkRegime);
}

function renderGAIAEHistoryChart(usChart, jpChart, hkChart) {
    const el = document.getElementById('gaiae-history-chart');
    if (!el || typeof echarts === 'undefined') return;
    if (window._gaiaeHistChart) AC.disposeChart(window._gaiaeHistChart);
    window._gaiaeHistChart = AC.registerChart(echarts.init(el));

    // Use US chart dates as x-axis (it has more data points typically)
    const usDates = usChart ? usChart.dates : [];
    const usValues = usChart ? usChart.values : [];
    const jpDates = jpChart ? jpChart.dates : [];
    const jpValues = jpChart ? jpChart.values : [];
    const hkDates = hkChart ? hkChart.dates : [];
    const hkValues = hkChart ? hkChart.values : [];

    // Merge dates
    const allDates = [...new Set([...usDates, ...jpDates, ...hkDates])].sort();
    const usMap = {}; usDates.forEach((d, i) => usMap[d] = usValues[i]);
    const jpMap = {}; jpDates.forEach((d, i) => jpMap[d] = jpValues[i]);
    const hkMap = {}; hkDates.forEach((d, i) => hkMap[d] = hkValues[i]);

    const usData = allDates.map(d => usMap[d] ?? null);
    const jpData = allDates.map(d => jpMap[d] ?? null);
    const hkData = allDates.map(d => hkMap[d] ?? null);

    // US five-tier mark areas
    const markAreaData = [
        [{ yAxis: 0, itemStyle: { color: 'rgba(16,185,129,0.05)' } }, { yAxis: 15 }],
        [{ yAxis: 15, itemStyle: { color: 'rgba(59,130,246,0.04)' } }, { yAxis: 20 }],
        [{ yAxis: 20, itemStyle: { color: 'rgba(234,179,8,0.04)' } }, { yAxis: 27 }],
        [{ yAxis: 27, itemStyle: { color: 'rgba(249,115,22,0.05)' } }, { yAxis: 34 }],
        [{ yAxis: 34, itemStyle: { color: 'rgba(239,68,68,0.05)' } }, { yAxis: 50 }],
    ];

    window._gaiaeHistChart.setOption({
        backgroundColor: 'transparent',
        tooltip: {
            trigger: 'axis',
            backgroundColor: 'rgba(15,23,42,0.95)',
            borderColor: 'rgba(245,158,11,0.3)',
            textStyle: { color: '#e2e8f0', fontSize: 11 },
        },
        legend: { top: 0, textStyle: { color: '#94a3b8', fontSize: 10 } },
        grid: { left: 50, right: 20, top: 30, bottom: 30 },
        xAxis: {
            type: 'category', data: allDates, boundaryGap: false,
            axisLabel: { color: '#64748b', fontSize: 8, formatter: function(v) { return v.substring(0, 7); } },
            axisLine: { lineStyle: { color: '#334155' } }
        },
        yAxis: {
            type: 'value', min: 0, max: 50,
            axisLabel: { color: '#64748b', fontSize: 8, formatter: function(v) { return v + '%'; } },
            splitLine: { lineStyle: { color: 'rgba(255,255,255,0.04)' } }
        },
        series: [
            {
                name: '🇺🇸 US AIAE', type: 'line', data: usData, smooth: true, connectNulls: true,
                symbol: 'circle', symbolSize: 8,
                lineStyle: { color: '#3b82f6', width: 2.5, shadowColor: 'rgba(59,130,246,0.3)', shadowBlur: 6 },
                itemStyle: { color: '#3b82f6', borderColor: '#0f172a', borderWidth: 2 },
                areaStyle: { color: { type: 'linear', x: 0, y: 0, x2: 0, y2: 1,
                    colorStops: [{ offset: 0, color: 'rgba(59,130,246,0.15)' }, { offset: 1, color: 'rgba(59,130,246,0)' }]
                }},
                label: { show: true, fontSize: 7, color: '#3b82f6', formatter: function(p) { return p.value !== null ? p.value + '%' : ''; }, position: 'top' },
                markArea: { silent: true, data: markAreaData },
            },
            {
                name: '🇯🇵 JP AIAE', type: 'line', data: jpData, smooth: true, connectNulls: true,
                symbol: 'diamond', symbolSize: 8,
                lineStyle: { color: '#dc2626', width: 2.5, shadowColor: 'rgba(220,38,38,0.3)', shadowBlur: 6 },
                itemStyle: { color: '#dc2626', borderColor: '#0f172a', borderWidth: 2 },
                areaStyle: { color: { type: 'linear', x: 0, y: 0, x2: 0, y2: 1,
                    colorStops: [{ offset: 0, color: 'rgba(220,38,38,0.12)' }, { offset: 1, color: 'rgba(220,38,38,0)' }]
                }},
                label: { show: true, fontSize: 7, color: '#dc2626', formatter: function(p) { return p.value !== null ? p.value + '%' : ''; }, position: 'bottom' },
            },
            {
                name: '🇭🇰 HK AIAE', type: 'line', data: hkData, smooth: true, connectNulls: true,
                symbol: 'rect', symbolSize: 7,
                lineStyle: { color: '#a855f7', width: 2.5, shadowColor: 'rgba(168,85,247,0.3)', shadowBlur: 6 },
                itemStyle: { color: '#a855f7', borderColor: '#0f172a', borderWidth: 2 },
                areaStyle: { color: { type: 'linear', x: 0, y: 0, x2: 0, y2: 1,
                    colorStops: [{ offset: 0, color: 'rgba(168,85,247,0.12)' }, { offset: 1, color: 'rgba(168,85,247,0)' }]
                }},
                label: { show: true, fontSize: 7, color: '#a855f7', formatter: function(p) { return p.value !== null ? p.value + '%' : ''; }, position: 'insideTopRight' },
            }
        ]
    });
}

// Phase 2: resize 已由 alphacore_utils.js 注册中心统一处理
