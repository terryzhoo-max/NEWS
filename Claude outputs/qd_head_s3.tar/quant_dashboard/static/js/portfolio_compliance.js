/**
 * 组合页合规徽章与告警条 (2026-11-03 组合页精简 P1, docs/PORTFOLIO_SLIMMING_PLAN.md)
 * =================================================================================
 * 唯一来源: /api/v1/decision/compliance-check (与决策中枢、审计页同一份合规结果)。
 * 本页不设任何风险阈值; 原 PfAlerts 12 条前端规则 (单票 20%、行业 40%、仓位 90%、跑输基准 BLOCK 等) 已删除。
 *
 * 状态:
 *   passed  且有检查项、无阻断/警告      → 合规通过 (唯一会显示通过样式的情况)
 *   warning 且有警告项                  → 合规警告 · N 条
 *   blocked 且有硬阻断项                → 合规阻断 · N 条硬阻断
 *   warming_up                          → 合规加载中 (自动重试)
 *   接口失败 / 状态未知 / 内容自相矛盾    → 合规不可用 (任何异常都不显示通过)
 * 点击徽章跳转决策中枢合规区 (decision.html#compliance-engine-panel)。
 */
(function (root) {
    'use strict';

    const LINK = 'decision.html#compliance-engine-panel';
    const WARM_RETRY_MS = 15000, WARM_RETRY_MAX = 40;      // 预热期最多约 10 分钟
    const FAIL_RETRY_MS = 60000, FAIL_RETRY_MAX = 3;

    function esc(s) {
        return String(s == null ? '' : s).replace(/[&<>"']/g, c => (
            { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
    }

    function hhmm(d) {
        const p = n => String(n).padStart(2, '0');
        return `${p(d.getHours())}:${p(d.getMinutes())}`;
    }

    function names(list) {
        return list.map(r => r.rule_name || r.rule_id || '未命名规则').join('；');
    }

    /** 合规接口结果 → 徽章模型。纯函数, 供测试。 */
    function badgeModel(resp, err) {
        const unavailable = why => ({ state: 'unavailable', cls: 'pf-compliance-unknown',
                                      text: '合规不可用', title: `合规结果不可用：${why}（不代表合规通过）`, items: [] });
        if (err) return unavailable(String((err && err.message) || err).slice(0, 120) || '接口失败');
        if (!resp || typeof resp !== 'object') return unavailable('接口无内容');
        const st = resp.status;
        if (st === 'warming_up') {
            return { state: 'warming', cls: 'pf-compliance-unknown', text: '合规加载中',
                     title: `${resp.summary || '服务启动预热中'}（尚无合规结论）`, items: [] };
        }
        const checks = Array.isArray(resp.checks) ? resp.checks : [];
        const blocks = Array.isArray(resp.blocks) ? resp.blocks : [];
        const warns = Array.isArray(resp.warnings) ? resp.warnings : [];
        const partial = resp.warmup && resp.warmup.phase === 'partial'
            ? '；部分数据缺失（缺失项按阻断处理）' : '';
        const items = blocks.map(r => ({ level: 'block', title: r.rule_name || r.rule_id, detail: r.detail || '' }))
            .concat(warns.map(r => ({ level: 'warn', title: r.rule_name || r.rule_id, detail: r.detail || '' })));
        if (st === 'blocked' && blocks.length) {
            return { state: 'blocked', cls: 'pf-compliance-block', text: `合规阻断 · ${blocks.length} 条硬阻断`,
                     title: `硬阻断：${names(blocks)}${warns.length ? `；警告：${names(warns)}` : ''}${partial}`, items };
        }
        if (st === 'warning' && warns.length && !blocks.length) {
            return { state: 'warning', cls: 'pf-compliance-warn', text: `合规警告 · ${warns.length} 条`,
                     title: `警告：${names(warns)}${partial}`, items };
        }
        if (st === 'passed' && checks.length && !blocks.length && !warns.length && !partial) {
            return { state: 'passed', cls: 'pf-compliance-ok', text: '合规通过',
                     title: `全部 ${checks.length} 条合规规则通过`, items: [] };
        }
        return unavailable(`状态 ${st == null ? '缺失' : st} 与检查明细不一致`);
    }

    // ── 页面渲染 ──
    let model = null, readAt = null, dataNotes = [], last = null;

    function renderBadge() {
        const el = root.document && root.document.getElementById('pf-compliance-dot');
        if (!el || !model) return;
        el.className = `pf-compliance-dot ${model.cls}`;
        el.setAttribute('href', LINK);
        el.setAttribute('data-state', model.state);
        el.title = `${model.title}${readAt ? `｜读取于 ${hhmm(readAt)}` : ''}｜点击查看决策中枢合规区`;
        const t = root.document.getElementById('pf-compliance-text');
        const tm = root.document.getElementById('pf-compliance-time');
        const nt = root.document.getElementById('pf-compliance-note');
        if (t) t.textContent = model.text; else el.textContent = model.text;
        if (tm) tm.textContent = readAt ? `读取于 ${hhmm(readAt)}` : '';
        // 2026-11-04 视觉轮 V2: 不可用时直接写明"不代表通过" (不只在悬浮提示里)
        if (nt) nt.textContent = model.state === 'unavailable' ? '不代表通过' : '';
    }

    function itemHtml(a) {
        const cls = a.level === 'block' ? 'pf-alert-block' : a.level === 'warn' ? 'pf-alert-warn' : 'pf-alert-info';
        const tag = a.level === 'block' ? '硬阻断' : a.level === 'warn' ? '警告' : '数据质量';
        return `<div class="pf-alert-item ${cls}"><span class="pf-alert-icon">${tag}</span>` +
               `<div class="pf-alert-body"><div class="pf-alert-main"><span class="pf-alert-title">${esc(a.title)}</span>` +
               `<span class="pf-alert-detail">${esc(a.detail)}</span></div></div></div>`;
    }

    /** 核心资产区告警条: 合规阻断/警告 (原文) + 数据质量提示。 */
    function renderStrip() {
        const el = root.document && root.document.getElementById('pf-alerts-hero');
        if (!el) return;
        const items = ((model && model.items) || []).concat(dataNotes);
        el.innerHTML = items.length
            ? items.map(itemHtml).join('') + (model && model.items.length
                ? `<div class="pf-alert-source">来源：合规引擎（与决策中枢同一结果）· <a href="${LINK}">查看详情</a></div>` : '')
            : '';
    }

    /** 数据质量提示 (非风险判定): 价格源降级等。 */
    function dataQualityNotes(valuation) {
        const pos = (valuation && valuation.positions) || [];
        const cost = pos.filter(p => p.price_source === 'cost');
        if (!cost.length) return [];
        return [{ level: 'info', title: '价格源降级',
                  detail: `${cost.length} 只标的使用成本价兜底（${cost.slice(0, 3).map(p => p.name).join('、')}），市值可能失真` }];
    }

    function setDataNotes(notes) {
        dataNotes = Array.isArray(notes) ? notes : [];
        renderStrip();
    }

    async function load(attempt) {
        attempt = attempt || 0;
        let resp = null, err = null;
        try {
            const r = await root.fetch('/api/v1/decision/compliance-check');
            if (!r.ok) throw new Error(`HTTP ${r.status}`);
            resp = await r.json();
        } catch (e) {
            err = e;
        }
        model = badgeModel(resp, err);
        // P3: 供穿透区读取合规主题集中度 (同一份结果, 不另请求)
        last = err ? null : resp;
        try { root.dispatchEvent && root.dispatchEvent(new root.CustomEvent('pf:compliance', { detail: last })); } catch (e) { /* 无事件环境 */ }
        readAt = model.state === 'unavailable' || model.state === 'warming' ? null : new Date();
        renderBadge();
        renderStrip();
        if (model.state === 'warming' && attempt < WARM_RETRY_MAX) root.setTimeout(() => load(attempt + 1), WARM_RETRY_MS);
        else if (model.state === 'unavailable' && attempt < FAIL_RETRY_MAX) root.setTimeout(() => load(attempt + 1), FAIL_RETRY_MS);
        return model;
    }

    root.PfCompliance = { badgeModel, dataQualityNotes, setDataNotes, load, LINK, last: () => last };
})(typeof window !== 'undefined' ? window : globalThis);
