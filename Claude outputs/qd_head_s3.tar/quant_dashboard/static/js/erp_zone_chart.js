/* AlphaCore · ERP 估值区间图 (共享模块)
 * 时点一致 (PIT) 五档区间: 区间由后端 engines/erp_zones.py 计算, 与综合评分 D2 同口径。
 * 使用方: strategy.html (strategy_erp.js) / index.html (renderers.js) — 修改此文件即两处同步。
 * 依赖: echarts, AC (alphacore_utils.js)
 */
// V4.1: 时点一致 (PIT) 五档区间渲染 — 区间由后端 erp_zones 计算 (与 D2 同口径, 无后视)
const _ERP_PIT_META = {
    strong:  { label: '🟢 强买区', color: '#10b981' },
    over:    { label: '🔵 超配区', color: '#34d399' },
    neutral: { label: '⚪ 中性区',       color: '#f59e0b' },
    under:   { label: '🟠 低配区', color: '#fb923c' },
    danger:  { label: '🔴 危险区', color: '#ef4444' },
};
const _ERP_BAND_NAME = '估值区间带';

function _erpPitEpisodes(zones, key, mergeGap) {
    const eps = []; let cur = null, gap = 0;
    for (let i = 0; i < zones.length; i++) {
        if (zones[i] === key) {
            if (!cur) cur = { s: i, e: i, n: 0 };
            cur.e = i; cur.n += 1; gap = 0;
        } else if (cur) {
            gap += 1;
            if (gap > mergeGap) { eps.push(cur); cur = null; gap = 0; }
        }
    }
    if (cur) eps.push(cur);
    eps.forEach(ep => { ep.ongoing = ep.e === zones.length - 1; });
    return eps;
}

/**
 * 共享渲染入口 (策略页 strategy_erp.js 与首页 renderers.js 共用, 保证两处显示完全一致)
 * @param chart        /api/v1/strategy/erp-timing 返回的 data.chart (需含 bands/pit)
 * @param signalData   data (用于综合信号与快照)
 * @param prevInstance 之前的 ECharts 实例 (会被销毁)
 * @returns 新的 ECharts 实例
 */
function renderERPZoneChart(chart, signalData, prevInstance) {
    const dom = document.getElementById('erp-history-chart');
    if (!dom || typeof echarts === 'undefined') return prevInstance || null;
    if (prevInstance) AC.disposeChart(prevInstance);
    const inst = AC.registerChart(echarts.init(dom));
    const stats = chart.stats || {}, pit = chart.pit || {}, b = chart.bands;
    const dates = chart.dates || [], erp = chart.erp || [];
    const hasM1 = chart.m1_yoy && chart.m1_yoy.some(v => v != null);
    const diff = (hi, lo) => hi.map((v, i) => (v == null || lo[i] == null) ? null : +(v - lo[i]).toFixed(2));
    const yrs = pit.window_years || 4;

    _erpSetChartTitle('相对估值 · 近' + yrs + '年滚动分位五档（旧版 · 参考）');

    _renderERPChartKPIsPIT(stats, pit, signalData);
    _renderERPChartNotePIT(dom, pit);

    // ERP 曲线按区间分段着色 (强买绿 / 低配橙 / 危险红 / 其余琥珀)
    const pieces = [];
    [['strong', '#10b981'], ['under', '#fb923c'], ['danger', '#ef4444']].forEach(([k, c]) => {
        _erpPitEpisodes(b.zone, k, 0).forEach(ep => pieces.push({ gte: ep.s, lte: Math.min(ep.e + 1, dates.length - 1), color: c }));
    });

    // 纵向色带: 历史危险段 (红) 与强买段 (绿)
    const vBand = (key, rgba, rgbaNow, txt) => _erpPitEpisodes(b.zone, key, 3).map(ep => [
        { xAxis: dates[ep.s], itemStyle: { color: ep.ongoing ? rgbaNow : rgba },
          label: { show: ep.n >= 10 || ep.ongoing, position: 'insideTop', fontSize: 9, color: _ERP_PIT_META[key].color,
                   formatter: ep.ongoing ? '当前' + txt : dates[ep.s].substring(0, 7) } },
        { xAxis: dates[ep.e] }
    ]);
    const dangerAreas = vBand('danger', 'rgba(239,68,68,0.10)', 'rgba(239,68,68,0.22)', '危险');
    const strongAreas = vBand('strong', 'rgba(16,185,129,0.08)', 'rgba(16,185,129,0.20)', '强买');

    const zoneNow = _ERP_PIT_META[pit.current_zone] || { color: '#f59e0b', label: '--' };
    const markPointData = [];
    if (stats.current != null) markPointData.push({
        coord: [dates[dates.length - 1], stats.current], name: '当前', symbol: 'pin', symbolSize: 38,
        itemStyle: { color: zoneNow.color, borderColor: '#0f172a', borderWidth: 1 },
        label: { formatter: stats.current + '%', color: '#fff', fontSize: 10, fontWeight: 700 }
    });
    (stats.extremes || []).forEach(e => markPointData.push({
        coord: [e.date, e.value], name: e.type === 'max' ? '历史最高' : '历史最低',
        symbol: e.type === 'max' ? 'triangle' : 'arrow', symbolSize: 12, symbolRotate: e.type === 'min' ? 180 : 0,
        itemStyle: { color: e.type === 'max' ? '#10b981' : '#ef4444' },
        label: { show: true, formatter: e.value + '%', fontSize: 9, color: e.type === 'max' ? '#10b981' : '#ef4444', position: e.type === 'max' ? 'top' : 'bottom' }
    }));

    const endLbl = (txt, color) => ({ show: true, formatter: txt, color, fontSize: 9, distance: 4 });
    const line = (color, type, width, opacity) => ({ color, type: type || 'solid', width: width || 1, opacity: opacity == null ? 1 : opacity });
    const bandBase = { name: _ERP_BAND_NAME, type: 'line', yAxisIndex: 0, symbol: 'none', silent: true, z: 2,
                       emphasis: { disabled: true }, tooltip: { show: false },
                       labelLayout: { moveOverlap: 'shiftY' } };
    const fmt = v => (v == null ? '--' : v + '%');

    const series = [
        { name: 'ERP', type: 'line', data: erp, yAxisIndex: 0, symbol: 'none', z: 10,
          lineStyle: { width: 2.5, shadowColor: 'rgba(0,0,0,0.35)', shadowBlur: 4 }, itemStyle: { color: '#f59e0b' },
          markPoint: { data: markPointData, animation: true, animationDuration: 600 } },
        // 危险带: 轴底 → 危险线
        Object.assign({}, bandBase, { data: b.danger, lineStyle: line('#ef4444', 'solid', 1.3),
          areaStyle: { origin: 'start', color: 'rgba(239,68,68,0.13)' },
          endLabel: endLbl('危险 ' + fmt(pit.danger_line) + (pit.floor_binding ? ' (绝对下限)' : ' (P20)'), '#ef4444') }),
        // 低配带: 危险线 → 低配线 (堆叠)
        Object.assign({}, bandBase, { data: b.danger, stack: 'erp_under', lineStyle: line('#000', 'solid', 0, 0) }),
        Object.assign({}, bandBase, { data: diff(b.under, b.danger), stack: 'erp_under', lineStyle: line('#fb923c', 'dashed', 1),
          areaStyle: { color: 'rgba(251,146,60,0.10)' }, endLabel: endLbl('低配 ' + fmt(pit.underweight_line) + ' (P40)', '#fb923c') }),
        // 超配带: 超配线 → 强买线 (堆叠)
        Object.assign({}, bandBase, { data: b.over, stack: 'erp_over', lineStyle: line('#34d399', 'dashed', 1, 0.7),
          endLabel: endLbl('超配 ' + fmt(pit.overweight_line) + ' (P60)', '#34d399') }),
        Object.assign({}, bandBase, { data: diff(b.strong, b.over), stack: 'erp_over', lineStyle: line('#000', 'solid', 0, 0),
          areaStyle: { color: 'rgba(52,211,153,0.06)' } }),
        // 强买带: 强买线 → 轴顶
        Object.assign({}, bandBase, { data: b.strong, lineStyle: line('#10b981', 'solid', 1.3),
          areaStyle: { origin: 'end', color: 'rgba(16,185,129,0.12)' },
          endLabel: endLbl('强买 ' + fmt(pit.strong_buy_line) + ' (P80)', '#10b981') }),
        // 长期中枢 (扩展窗口中位数): 危险/强买的第二重确认
        Object.assign({}, bandBase, { data: b.anchor || [], lineStyle: line('#cbd5e1', 'dotted', 1.2, 0.8),
          endLabel: endLbl('中枢 ' + fmt(pit.anchor), '#cbd5e1') }),
        { name: '危险区间', type: 'line', data: [], yAxisIndex: 0, symbol: 'none', itemStyle: { color: '#ef4444' },
          lineStyle: { opacity: 0 }, markArea: { silent: true, data: dangerAreas } },
        { name: '强买区间', type: 'line', data: [], yAxisIndex: 0, symbol: 'none', itemStyle: { color: '#10b981' },
          lineStyle: { opacity: 0 }, markArea: { silent: true, data: strongAreas } },
        { name: 'PE-TTM', type: 'line', data: chart.pe_ttm, yAxisIndex: 1, symbol: 'none',
          lineStyle: { color: '#3b82f6', width: 1.2, type: 'dashed', opacity: 0.8 }, itemStyle: { color: '#3b82f6' } },
        { name: '10Y国债', type: 'line', data: chart.yield_10y, yAxisIndex: 0, symbol: 'none',
          lineStyle: { color: '#94a3b8', width: 1, type: 'dotted' }, itemStyle: { color: '#94a3b8' } },
    ];
    if (hasM1) series.push({ name: 'M1同比', type: 'line', data: chart.m1_yoy, yAxisIndex: 2, symbol: 'none', smooth: true,
        lineStyle: { color: '#a78bfa', width: 1.6 }, itemStyle: { color: '#a78bfa' } });

    const legendData = ['ERP', _ERP_BAND_NAME, '危险区间', '强买区间', 'PE-TTM', '10Y国债'];
    if (hasM1) legendData.push('M1同比');

    inst.setOption({
        tooltip: {
            trigger: 'axis', backgroundColor: 'rgba(15,23,42,0.95)', borderColor: '#334155',
            textStyle: { fontSize: 11, color: '#e2e8f0' },
            formatter: function(params) {
                const i = params[0].dataIndex;
                let r = '<div style="font-size:0.7rem;color:#64748b;margin-bottom:4px;">' + params[0].axisValue + '</div>';
                params.forEach(p => {
                    if (p.value == null || p.seriesName === _ERP_BAND_NAME) return;
                    const unit = p.seriesName === 'PE-TTM' ? 'x' : '%';
                    r += '<div>' + p.marker + ' ' + p.seriesName + ': <b>' + p.value + unit + '</b></div>';
                });
                const z = _ERP_PIT_META[b.zone[i]];
                if (z) {
                    const v = erp[i], dl = b.danger[i];
                    r += '<div style="margin-top:3px;padding-top:3px;border-top:1px solid rgba(255,255,255,0.1);font-size:10px;">' +
                         '<span style="color:' + z.color + ';font-weight:700;">' + z.label + '</span>' +
                         ' <span style="color:#94a3b8;">· 近' + yrs + '年 P' + Math.round(b.pct[i]) + '</span></div>' +
                         '<div style="font-size:10px;color:#64748b;">危险线 ' + dl + '% · 缓冲 ' + (v - dl >= 0 ? '+' : '') + (v - dl).toFixed(2) + 'pp' +
                         (b.anchor && b.anchor[i] != null ? ' · 中枢 ' + b.anchor[i] + '%' : '') + '</div>' +
                         (b.zone[i] === 'under' && v < dl ? '<div style="font-size:10px;color:#fb923c;">跌破P20但高于长期中枢 → 降为低配</div>' : '') +
                         (b.zone[i] === 'over' && v >= b.strong[i] ? '<div style="font-size:10px;color:#34d399;">达P80但低于长期中枢 → 降为超配</div>' : '');
                } else {
                    r += '<div style="margin-top:3px;font-size:10px;color:#64748b;">历史不足1年, 不做区间判定</div>';
                }
                return r;
            }
        },
        legend: { data: legendData, top: 0, textStyle: { color: '#94a3b8', fontSize: 10 }, selected: { '10Y国债': false, 'M1同比': false } },
        toolbox: { right: 8, top: 0, feature: {
            saveAsImage: { title: '保存', pixelRatio: 2, backgroundColor: '#0f172a' }, restore: { title: '重置' } },
            iconStyle: { borderColor: '#64748b' } },
        visualMap: { show: false, seriesIndex: 0, dimension: 0, pieces: pieces, outOfRange: { color: '#f59e0b' } },
        grid: { top: 40, bottom: 55, left: 50, right: 118 },
        dataZoom: [
            { type: 'inside', start: 65, end: 100 },
            { type: 'slider', height: 16, bottom: 4, borderColor: 'rgba(255,255,255,0.06)',
              fillerColor: 'rgba(245,158,11,0.12)', handleStyle: { color: '#f59e0b', borderColor: '#f59e0b' },
              textStyle: { color: '#64748b', fontSize: 9 },
              dataBackground: { lineStyle: { color: '#334155' }, areaStyle: { color: 'rgba(245,158,11,0.05)' } } }
        ],
        xAxis: { type: 'category', data: dates, boundaryGap: false,
            axisLabel: { color: '#64748b', fontSize: 10, formatter: v => v.substring(0, 7) },
            axisLine: { lineStyle: { color: '#334155' } } },
        yAxis: [
            { type: 'value', name: 'ERP %', nameTextStyle: { color: '#64748b', fontSize: 10 },
              min: v => Math.max(0, Math.floor(v.min - 0.3)), max: v => Math.ceil(v.max + 0.3),
              axisLabel: { color: '#64748b', fontSize: 10, formatter: '{value}%' },
              splitLine: { lineStyle: { color: 'rgba(100,116,139,0.08)' } } },
            { type: 'value', name: 'PE-TTM', position: 'right', nameTextStyle: { color: '#3b82f6', fontSize: 10 },
              axisLabel: { color: '#3b82f680', fontSize: 9 }, splitLine: { show: false } },
            hasM1 ? { type: 'value', name: 'M1%', position: 'right', offset: 40, show: false, nameTextStyle: { color: '#a78bfa', fontSize: 10 },
              axisLabel: { color: '#a78bfa', fontSize: 9, formatter: '{value}%' }, splitLine: { show: false } } : null
        ].filter(Boolean),
        series: series
    });
    // M1 默认隐藏: 只有在图例中打开 M1 时才显示第三根纵轴, 避免右侧三轴与区间标签挤在一起
    if (hasM1) inst.on('legendselectchanged', function (e) {
        if (e.name !== 'M1同比') return;
        const on = !!e.selected['M1同比'];
        inst.setOption({ yAxis: [{}, {}, { show: on }], grid: { right: on ? 158 : 118 } });
    });
    return inst;
}

function _renderERPChartNotePIT(dom, pit) {
    let note = document.getElementById('erp-chart-note');
    if (!note) {
        note = document.createElement('div');
        note.id = 'erp-chart-note';
        note.style.cssText = 'margin-top:6px;font-size:0.65rem;line-height:1.5;color:#64748b;';
        dom.parentNode.insertBefore(note, dom.nextSibling);
    }
    const share = pit.zone_share_pct || {};
    note.style.display = '';
    note.textContent = '⚠ 参考视图, 不作仓位依据: 近 4 年滚动分位在 2026-10 验证中样本外 R² 为负 (窗口移动, "便宜"标准随之漂移)。区间口径: 每个时点仅用其前 ' + pit.window_years + ' 年 (' + pit.window_days +
        ' 个交易日) 的 ERP 滚动分位, 无后视, 与综合评分 D2 同口径: ≥P80 强买 / P60–80 超配 / P40–60 中性 / P20–40 低配 / <P20 危险。' +
        '危险/强买需双重确认: 同时低于/高于长期中枢 (自2015年扩展中位数, 当前 ' + pit.anchor + '%), 否则降一档; ' +
        'ERP<' + pit.abs_floor + '% 无条件危险 (长期泡沫的硬约束)。' +
        '样本内时间占比' + (pit.zone_share_since ? ' (' + pit.zone_share_since + ' 起, 仅统计已满' + pit.window_years + '年窗口的交易日)' : '') +
        ': 危险 ' + (share.danger ?? '--') + '% · 低配 ' + (share.under ?? '--') + '% · 强买 ' + (share.strong ?? '--') +
        '%。仓位以 AIAE 执行目标为准。';
}

function _renderERPChartKPIsPIT(stats, pit, signalData) {
    const container = document.getElementById('erp-chart-kpis');
    if (!container) return;
    const signal = (signalData || {}).signal || {};
    const z = _ERP_PIT_META[pit.current_zone] || { label: '--', color: '#94a3b8' };
    const buf = pit.buffer_to_danger_pp, bufU = pit.buffer_to_under_pp;
    const bufColor = buf == null ? '#94a3b8' : (buf < 0 ? '#ef4444' : (buf < 0.5 ? '#fb923c' : '#10b981'));
    const pct = pit.current_pct;
    const v4now = (((signalData || {}).chart || {}).v4 || {}).now || {};
    const v4snap = ((signalData || {}).current_snapshot || {}).allocation_v4 || {};
    const v4t = v4now.target_pct != null ? v4now.target_pct : v4snap.target_position_pct;
    // 2026-11-02 首页口径统一 A3: ERP (含 v4) 只作背景读数, 仓位以 AIAE 执行目标为准
    const sigText = v4t != null ? ('v4 档位（背景）: <b style="color:#14b8c9;">' + v4t + '</b> · 仓位以 AIAE 执行目标为准') :
        (signal.label ? ('综合信号: ' + (signal.emoji || '') + signal.label +
        (signal.score != null ? ' ' + signal.score : '') + (signal.position ? ' · ' + signal.position : '')) : '');
    const card = (label, value, color, sub, flex) => `<div style="flex:${flex || 1};min-width:140px;background:rgba(15,23,42,0.6);border:1px solid ${flex ? color + '55' : 'rgba(255,255,255,0.06)'};border-radius:8px;padding:8px 10px;text-align:center;">
        <div style="font-size:0.65rem;color:#64748b;margin-bottom:3px;">${label}</div>
        <div style="font-size:1.05rem;font-weight:800;color:${color};">${value}</div>
        ${sub ? `<div style="font-size:0.6rem;color:#94a3b8;margin-top:2px;">${sub}</div>` : ''}
    </div>`;
    container.style.display = 'flex';
    container.style.flexWrap = 'wrap';
    container.innerHTML = [
        card('估值区间（参考）', z.label, z.color, ['近' + pit.window_years + '年 P' + (pct != null ? Math.round(pct) : '--') +
             (pit.current_zone_days ? ' · 已持续 ' + pit.current_zone_days + ' 个交易日' : ''), sigText].filter(Boolean).join('<br>'), 1.8),
        card('当前 ERP', (stats.current != null ? stats.current : '--') + '%', z.color),
        card('距危险线', buf == null ? '--' : ((buf >= 0 ? '+' : '') + buf + 'pp'), bufColor,
             '危险线 ' + (pit.danger_line ?? '--') + '%' + (pit.floor_binding ? ' (绝对下限)' : '')),
        card('距低配线', bufU == null ? '--' : ((bufU >= 0 ? '+' : '') + bufU + 'pp'), bufU != null && bufU < 0 ? '#fb923c' : '#94a3b8',
             '低配线 ' + (pit.underweight_line ?? '--') + '%'),
        card('危险区时间占比', ((pit.zone_share_pct || {}).danger ?? '--') + '%', '#ef4444',
             (pit.danger_episodes || []).length + ' 段'),
    ].join('');
}



/* ══════════════════════════════════════════════════════════════════════
 * 2026-11-01 · v4 决策视图 (共享: 策略页 + 首页)
 * 数据全部来自后端 chart.v4 (engines/erp_timing_engine._v4_chart_payload), 前端只展示不计算。
 * 页面结构: [标题] [视图切换] [5 张关键卡片] [走势图] [说明] [买卖区间表]
 * ════════════════════════════════════════════════════════════════════ */
const _ERP_VIEW_KEY = 'erp_chart_view';
const _V4_UP = '#10b981', _V4_DOWN = '#ef4444', _V4_ACCENT = '#14b8c9';
/** 档位相对当前档的颜色 (走势图色带与区间表色块共用): 当前青, 上方 (更便宜) 绿, 下方 (更贵) 红, 越远越淡 */
function _v4RelColor(i, k, alphaScale) {
    const m = alphaScale == null ? 1 : alphaScale;
    if (k < 0) return 'rgba(148,163,184,' + (0.05 * m).toFixed(3) + ')';
    if (i === k) return 'rgba(20,184,201,' + (0.16 * m).toFixed(3) + ')';
    const d = Math.abs(i - k);
    return i > k ? 'rgba(16,185,129,' + ((0.11 - 0.02 * d) * m).toFixed(3) + ')' : 'rgba(239,68,68,' + ((0.10 - 0.015 * d) * m).toFixed(3) + ')';
}
const _V4_TREND_TXT = { bullish: '双均线多头', bearish: '双均线空头', weak: '短期弱势', neutral: '趋势中性', insufficient_data: '趋势数据不足' };
const _ERPV4_NUM = 'font-variant-numeric:tabular-nums;';

function _erpHtml(x) { return String(x == null ? '' : x).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c])); }
function _erpFmtPE(x) { return x == null ? '--' : Number(x).toFixed(2); }
function _erpSigned(x, unit) { return x == null ? '--' : ((x > 0 ? '+' : (x < 0 ? '−' : '')) + Math.abs(x).toFixed(2) + unit); }
function _erpSignedPct(x) { return x == null ? '--' : ((x > 0 ? '+' : (x < 0 ? '−' : '')) + Math.abs(x).toFixed(1) + '%'); }

/** 标题: 首页标题含 icon / pill 子元素, 只替换文本节点; 策略页为纯文本 h3 */
function _erpSetChartTitle(text) {
    const el = document.getElementById('erp-chart-title');
    if (!el) return;
    const tn = Array.from(el.childNodes).filter(n => n.nodeType === Node.TEXT_NODE && n.textContent.trim());
    if (el.children.length && tn.length) tn.forEach((n, k) => { n.textContent = k ? '' : ' ' + text + ' '; });
    else if (el.children.length) el.insertBefore(document.createTextNode(' ' + text + ' '), el.children[1] || null);
    else el.textContent = '📈 ' + text;
}

function _erpChartViewPref() {
    try { return localStorage.getItem(_ERP_VIEW_KEY) || 'v4'; } catch (e) { return 'v4'; }
}

function _erpViewToggle(view, onSwitch) {
    const kpis = document.getElementById('erp-chart-kpis');
    if (!kpis) return;
    let bar = document.getElementById('erp-chart-viewtoggle');
    if (!bar) {
        bar = document.createElement('div');
        bar.id = 'erp-chart-viewtoggle';
        bar.setAttribute('role', 'tablist');
        bar.style.cssText = 'display:flex;gap:4px;margin:0 0 8px;flex-wrap:wrap;';
        kpis.parentElement.insertBefore(bar, kpis);
    }
    const btn = (key, txt) => '<button type="button" role="tab" aria-selected="' + (view === key) + '" data-view="' + key +
        '" style="font-size:0.68rem;padding:3px 10px;border-radius:999px;cursor:pointer;' +
        (view === key ? 'background:rgba(20,184,201,0.18);border:1px solid rgba(20,184,201,0.6);color:#e2e8f0;' :
                        'background:transparent;border:1px solid rgba(148,163,184,0.25);color:#94a3b8;') + '">' + txt + '</button>';
    bar.innerHTML = btn('v4', 'v4 档位（背景 · 前向观察）') + btn('zone', '相对估值（旧版·参考）');
    bar.querySelectorAll('button').forEach(b => b.onclick = () => {
        try { localStorage.setItem(_ERP_VIEW_KEY, b.dataset.view); } catch (e) { /* 存储不可用时只切换本次 */ }
        onSwitch(b.dataset.view);
    });
}

function _erpEnsureAfter(anchor, id, css) {
    let el = document.getElementById(id);
    if (!el) {
        el = document.createElement('div');
        el.id = id;
        if (css) el.style.cssText = css;
        anchor.parentNode.insertBefore(el, anchor.nextSibling);
    }
    return el;
}

/** v4 关键卡片: 当前档位 / 正常化 ERP / 距升档 / 距降档 / 下次评估 */
function _renderV4KPIs(chart) {
    const box = document.getElementById('erp-chart-kpis');
    if (!box) return;
    // 策略页上方已有 v4 决策面板 (同一组数字), 此处不重复; 首页没有面板, 保留 5 张卡片
    if (document.querySelector('.erp-v4-decision-row')) { box.innerHTML = ''; box.style.display = 'none'; return; }
    // 网格自适应: 宽屏 5 列一行; 窄屏 3+2 / 2+2+1, 避免 "4 张 + 1 张独占一行"
    box.style.display = 'grid';
    box.style.gridTemplateColumns = 'repeat(auto-fit, minmax(175px, 1fr))';
    const v = chart.v4, now = v.now || {}, trg = v.triggers || {};
    const card = (lbl, val, sub, accent, flex) =>
        '<div style="min-width:0;padding:8px 10px;border-radius:8px;background:rgba(15,23,42,0.55);' +
        'border:1px solid ' + (accent ? accent + '66' : 'rgba(148,163,184,0.12)') + ';' + _ERPV4_NUM + '">' +
        '<div style="font-size:0.62rem;color:#94a3b8;letter-spacing:0.04em;">' + lbl + '</div>' +
        '<div style="font-size:1.05rem;font-weight:800;color:' + (accent || '#f1f5f9') + ';">' + val + '</div>' +
        '<div style="font-size:0.62rem;color:#94a3b8;line-height:1.45;">' + sub + '</div></div>';
    const tier = v.current_tier_pct, target = now.target_pct;
    const staging = target != null && tier != null && target < tier;
    const up = trg.up, dn = trg.down;
    // 失效即关闭: 后端尚未提供触发数据 (旧后端 / 数据缺失) 时显示 "--", 不能误显示为 "已在最高 / 最低档"
    const known = trg.available === true;
    const yNote = now.guard_on ? ' · 10Y 按 ' + v.y10_floor + '% 计' : '';
    box.innerHTML =
        card('v4 档位（背景读数）', (tier ?? '--') + (staging ? ' → ' + target : ''),
             (staging ? '分批阶段 · ' : '') + '已持续 ' + (v.current_tier_days ?? '--') + ' 个交易日 · 不作仓位依据', _V4_ACCENT, 1.3) +
        card('正常化 ERP', (now.erp_adj != null ? now.erp_adj.toFixed(2) : '--') + '%',
             '原始 ' + (now.erp ?? '--') + '%' + yNote + ' · PE ' + _erpFmtPE(now.pe_ttm)) +
        card('距升档（买入线）', up ? _erpSigned(up.erp_adj_gap_pp, 'pp') : (known ? '已在最高档' : '--'),
             up ? 'PE ≤ ' + _erpFmtPE(up.pe_at_or_below) + '（' + _erpSignedPct(up.pe_change_pct) + '）→ ' + up.position_pct + ' 档' : '—', _V4_UP) +
        card('距降档（卖出线）', dn ? _erpSigned(dn.erp_adj_gap_pp, 'pp') : (known ? '已在最低档' : '--'),
             dn ? 'PE > ' + _erpFmtPE(dn.pe_above) + '（' + _erpSignedPct(dn.pe_change_pct) + '）→ ' + dn.position_pct + ' 档' : '—', _V4_DOWN) +
        card('下次评估', (now.next_eval_date || '--').substring(5) + ' 周五',
             (_V4_TREND_TXT[now.trend] || '--') + '<br>仓位以 AIAE 执行目标为准');
}

/** 买卖区间表 (六档) + 旧版区间对照 (折叠) */
function renderERPLadderTable(chart, anchorEl) {
    const v = chart.v4 || {};
    const rows = (v.ladder || []).slice().reverse();          // 高 ERP (便宜) 在上, 与走势图一致
    const host = _erpEnsureAfter(anchorEl, 'erp-ladder', 'margin-top:12px;');
    if (!rows.length) { host.innerHTML = ''; return; }
    const now = v.now || {};
    const kIdx = (v.ladder || []).findIndex(r => r.relation === 'current');
    const ups = rows.filter(r => r.relation === 'up'), dns = rows.filter(r => r.relation === 'down');
    const nearestUp = ups.length ? ups[ups.length - 1] : null, nearestDn = dns.length ? dns[0] : null;
    const action = r => r.relation === 'current' ? ['当前 · 持有', _V4_ACCENT] :
        r === nearestUp ? ['买入线 · 升档', _V4_UP] : r.relation === 'up' ? ['加仓区', _V4_UP] :
        r === nearestDn ? ['卖出线 · 降档', _V4_DOWN] : (r.erp_adj_min == null ? ['防守区', _V4_DOWN] : ['减仓区', _V4_DOWN]);
    const rng = (lo, hi, unit, rev) => {
        if (lo == null && hi == null) return '--';
        if (lo == null) return (rev ? '> ' : '< ') + hi + unit;
        if (hi == null) return (rev ? '≤ ' : '≥ ') + lo + unit;
        return lo + '–' + hi + unit;
    };
    // 最高档无 PE 下沿 (PE 越低越便宜): "≤ 上沿"; 最低档无 PE 上沿: "> 下沿"
    const peRng = r => r.pe_min == null ? '≤ ' + _erpFmtPE(r.pe_max) : (r.pe_max == null ? '> ' + _erpFmtPE(r.pe_min) :
        _erpFmtPE(r.pe_min) + '–' + _erpFmtPE(r.pe_max));
    const maxShare = Math.max.apply(null, rows.map(r => r.share_pct || 0).concat([1]));
    const th = 'padding:6px 8px;font-weight:600;color:#94a3b8;font-size:0.62rem;text-align:left;border-bottom:1px solid rgba(148,163,184,0.15);';
    const td = 'padding:6px 8px;font-size:0.7rem;color:#cbd5e1;border-bottom:1px solid rgba(148,163,184,0.06);' + _ERPV4_NUM;
    const body = rows.map((r, i) => {
        const [act, c] = action(r);
        const cur = r.relation === 'current';
        const li = rows.length - 1 - i;                          // ladder 原始下标 (0 = 10% 档)
        const seg = _v4RelColor(li, kIdx, 5.5);
        return '<tr style="' + (cur ? 'background:rgba(20,184,201,0.10);' : '') + '">' +
            '<td style="' + td + 'font-weight:800;color:' + (cur ? '#f1f5f9' : '#e2e8f0') + ';"><span style="display:inline-block;width:8px;height:8px;border-radius:2px;background:' + seg + ';margin-right:6px;"></span>' + r.position_pct + '</td>' +
            '<td style="' + td + '">' + rng(r.erp_adj_min, r.erp_adj_max, '%') + '</td>' +
            '<td style="' + td + '">' + peRng(r) + (cur && now.pe_ttm != null ? ' <span style="color:' + _V4_ACCENT + ';font-size:0.62rem;">· 当前 ' + _erpFmtPE(now.pe_ttm) + '</span>' : '') + '</td>' +
            '<td style="' + td + 'color:' + c + ';font-weight:' + (cur || r === nearestUp || r === nearestDn ? 700 : 500) + ';">' + act + '</td>' +
            '<td style="' + td + 'min-width:110px;"><div style="display:flex;align-items:center;gap:6px;"><div style="flex:1;height:6px;border-radius:3px;background:rgba(148,163,184,0.10);overflow:hidden;">' +
            '<div style="width:' + ((r.share_pct || 0) / maxShare * 100).toFixed(0) + '%;height:100%;background:' + seg + ';"></div></div>' +
            '<span style="color:#94a3b8;font-size:0.62rem;min-width:34px;text-align:right;">' + (r.share_pct ?? 0) + '%</span></div></td></tr>';
    }).join('');
    const lg = v.legacy_zones;
    let legacyHtml = '';
    if (lg && Array.isArray(lg.lines)) {
        const L = lg.lines, zoneNow = lg.current_zone;
        const lrow = (ln, i) => {
            const prev = i > 0 ? L[i - 1] : null;
            const erpTxt = ln.erp_min != null ? (prev && prev.erp_min != null ? ln.erp_min + '–' + prev.erp_min + '%' : '≥ ' + ln.erp_min + '%') :
                ('< ' + (prev ? prev.erp_min : '--') + '% 且 < 中枢 ' + lg.anchor + '%');
            const peTxt = ln.pe_max != null ? (prev && prev.pe_max != null ? _erpFmtPE(prev.pe_max) + '–' + _erpFmtPE(ln.pe_max) : '≤ ' + _erpFmtPE(ln.pe_max)) :
                '> ' + _erpFmtPE(lg.anchor_pe);
            const cur = ln.key === zoneNow;
            return '<tr style="' + (cur ? 'background:rgba(148,163,184,0.08);' : '') + '"><td style="' + td + 'color:#94a3b8;">' + _erpHtml(ln.label) + ' <span style="font-size:0.58rem;">(' + _erpHtml(ln.pct) + ')</span>' + (cur ? ' ← 当前' : '') + '</td>' +
                '<td style="' + td + 'color:#94a3b8;">' + erpTxt + '</td><td style="' + td + 'color:#94a3b8;">' + peTxt + '</td></tr>';
        };
        legacyHtml = '<details style="margin-top:8px;"><summary style="cursor:pointer;font-size:0.66rem;color:#94a3b8;">旧版区间对照（近 4 年滚动分位 · 未验证，仅参考）</summary>' +
            '<table style="width:100%;border-collapse:collapse;margin-top:6px;opacity:0.85;"><thead><tr>' +
            '<th style="' + th + '">旧区间</th><th style="' + th + '">原始 ERP</th><th style="' + th + '">对应 PE（10Y ' + lg.y10 + '%）</th></tr></thead><tbody>' +
            L.map(lrow).join('') + '</tbody></table>' +
            '<div style="font-size:0.6rem;color:#64748b;margin-top:4px;line-height:1.5;">旧版线随近 4 年窗口每天浮动；跌破 P20 但仍高于中枢 ' + lg.anchor + '%（PE ≤ ' + _erpFmtPE(lg.anchor_pe) +
            '）时降为低配；ERP < ' + lg.abs_floor + '%（PE > ' + _erpFmtPE(lg.abs_floor_pe) + '）无条件危险。2026-10 验证：4 年分位样本外 R² 为负，不作仓位依据。</div></details>';
    }
    host.innerHTML =
        '<div style="display:flex;align-items:baseline;justify-content:space-between;gap:8px;flex-wrap:wrap;margin-bottom:6px;">' +
        '<div style="font-size:0.75rem;font-weight:700;color:#e2e8f0;">v4 六档 · 估值区间（背景读数）</div>' +
        '<div style="font-size:0.62rem;color:#94a3b8;">PE 按当前 10Y ' + (now.y10 ?? '--') + '%' + (now.guard_on ? '（低于 ' + v.y10_floor + '%，按 ' + v.y10_floor + '% 计）' : '') + ' 换算 · 数据截至 ' + (now.as_of || '--') + '</div></div>' +
        '<div style="overflow-x:auto;"><table style="width:100%;border-collapse:collapse;min-width:520px;"><thead><tr>' +
        '<th style="' + th + '">v4 档位</th><th style="' + th + '">正常化 ERP</th><th style="' + th + '">对应沪深300 PE</th><th style="' + th + '">区间</th><th style="' + th + '">历史占比（交易日）</th>' +
        '</tr></thead><tbody>' + body + '</tbody></table></div>' +
        '<div style="font-size:0.62rem;color:#94a3b8;margin-top:6px;line-height:1.55;">v4 规则 2026-10-30 冻结，前向观察中；档位只作估值背景读数，不作仓位或买卖依据。仓位以 AIAE 执行目标为准，风险以合规引擎为准。10Y 变化时 PE 界线随之移动。</div>' +
        legacyHtml;
}

/** v4 走势图: 档位色带 (按与当前档的关系着色) + 升降档线高亮 + v4 档位阶梯 */
function renderERPV4DecisionChart(chart, prevInstance) {
    const dom = document.getElementById('erp-history-chart');
    if (!dom || typeof echarts === 'undefined') return prevInstance || null;
    if (prevInstance) AC.disposeChart(prevInstance);
    if (dom.clientWidth && dom.clientWidth < 700) dom.style.height = '320px';
    const inst = AC.registerChart(echarts.init(dom));
    const v = chart.v4, now = v.now || {}, trg = v.triggers || {};
    const dates = chart.dates || [], last = dates.length - 1;
    const T = v.thresholds || [], P = v.positions_pct || [];
    const k = (v.ladder || []).findIndex(r => r.relation === 'current');

    _erpSetChartTitle('正常化 ERP · v4 档位与买卖区间（自 ' + (v.history_start || dates[0] || '--').substring(0, 4) + ' 年）');
    _renderV4KPIs(chart);
    const note = _erpEnsureAfter(dom, 'erp-chart-note', 'margin-top:6px;font-size:0.65rem;line-height:1.5;color:#94a3b8;');
    note.style.display = '';
    note.style.color = '#94a3b8';
    note.textContent = '正常化 ERP = E/P − max(10Y, ' + v.y10_floor + '%)。色带：绿 = 高于当前档（买入方向），红 = 低于当前档（卖出方向），青 = 当前档；' +
        '实线为离当前最近的升档 / 降档线。右轴阶梯 = v4 档位（含分批，背景读数）。规则 ' + (v.frozen_on || '--') + ' 冻结，前向观察 ' + ((v.forward || []).length) + ' 天，状态：弱通过。';

    // 色带: 当前档青色, 上方绿色 (越远越淡), 下方红色 (越远越淡)
    const edges = [-50].concat(T, [50]);
    const bandColor = i => _v4RelColor(i, k);
    const bands = P.map((p, i) => [
        { yAxis: edges[i], itemStyle: { color: bandColor(i) },
          label: { show: true, position: 'insideLeft', formatter: p + '%', fontSize: 9,
                   color: i === k ? '#a5f3fc' : 'rgba(148,163,184,0.55)', fontWeight: i === k ? 700 : 400 } },
        { yAxis: edges[i + 1] }
    ]);
    const upTh = trg.up ? trg.up.erp_adj_at_or_above : null, dnTh = trg.down ? trg.down.erp_adj_below : null;
    const thLines = T.map(t => {
        if (t === upTh) return { yAxis: t, lineStyle: { color: _V4_UP, type: 'solid', width: 1.5 },
            label: { formatter: '买入线 ≥' + t + '% → ' + trg.up.position_pct + '%（PE ≤ ' + _erpFmtPE(trg.up.pe_at_or_below) + '）',
                     color: _V4_UP, fontSize: 10, fontWeight: 700, position: 'insideEndTop',
                     backgroundColor: 'rgba(15,23,42,0.85)', padding: [2, 5], borderRadius: 3 } };
        if (t === dnTh) return { yAxis: t, lineStyle: { color: _V4_DOWN, type: 'solid', width: 1.5 },
            label: { formatter: '卖出线 <' + t + '% → ' + trg.down.position_pct + '%（PE > ' + _erpFmtPE(trg.down.pe_above) + '）',
                     color: _V4_DOWN, fontSize: 10, fontWeight: 700, position: 'insideEndBottom',
                     backgroundColor: 'rgba(15,23,42,0.85)', padding: [2, 5], borderRadius: 3 } };
        return { yAxis: t, lineStyle: { color: 'rgba(148,163,184,0.28)', type: 'dashed', width: 1 }, label: { show: false } };
    });
    const frozenIdx = dates.findIndex(d => d >= (v.frozen_on || '9999'));
    if (frozenIdx >= 0) thLines.push({ xAxis: dates[frozenIdx], lineStyle: { color: '#fbbf24', type: 'dashed', width: 1 },
        label: { formatter: '前向起点', color: '#fbbf24', fontSize: 9, position: 'insideEndTop' } });
    const fwd = (v.forward || []).map(f => {
        let j = last;
        while (j > 0 && dates[j] > f.date) j--;
        return [dates[j], f.target];
    });
    const adjNow = (v.erp_adj || [])[last];
    const ax = { color: '#94a3b8', fontSize: 10 };

    inst.setOption({
        tooltip: {
            trigger: 'axis', backgroundColor: 'rgba(15,23,42,0.95)', borderColor: '#334155',
            textStyle: { fontSize: 11, color: '#e2e8f0' },
            formatter: function (ps) {
                const i = ps[0].dataIndex;
                const adj = (v.erp_adj || [])[i], raw = (chart.erp || [])[i], pe = (chart.pe_ttm || [])[i];
                const tp = (v.tier_pct || [])[i];
                // 两位小数恰好落在阈值上、但档位在下方 (如 5.4996 → 5.50 仍属 65% 档): 注明 "略低于", 避免读者误判
                const ti = P.indexOf(tp), edge = ti >= 0 && ti < T.length ? T[ti] : null;
                const atEdge = adj != null && edge != null && adj.toFixed(2) === Number(edge).toFixed(2);
                return '<div style="font-size:0.7rem;color:#94a3b8;margin-bottom:4px;">' + dates[i] + '</div>' +
                    '<div>正常化 ERP: <b>' + (adj != null ? adj.toFixed(2) : '--') + '%</b>' + (atEdge ? '<span style="color:#94a3b8;">（略低于 ' + edge + '%）</span>' : '') + '</div>' +
                    '<div style="color:#94a3b8;">原始 ERP ' + (raw ?? '--') + '%' + ((v.guard_on || [])[i] ? '（10Y 按 ' + v.y10_floor + '% 计）' : '') +
                    ' · PE ' + (pe != null ? Number(pe).toFixed(2) : '--') + '</div>' +
                    '<div>v4 档位 <b>' + ((v.tier_pct || [])[i] ?? '--') + '%</b> · 目标 ' + ((v.target_pct || [])[i] ?? '--') + '%</div>';
            }
        },
        legend: { data: ['正常化 ERP', '原始 ERP', 'v4 档位', '10Y国债'], top: 0, textStyle: { color: '#94a3b8', fontSize: 10 },
                  selected: { '10Y国债': false } },
        toolbox: { right: 8, top: 0, feature: { saveAsImage: { title: '保存', pixelRatio: 2, backgroundColor: '#0f172a' }, restore: { title: '重置' } },
                   iconStyle: { borderColor: '#64748b' } },
        grid: { top: 36, bottom: 55, left: 48, right: 58 },
        dataZoom: [
            { type: 'inside', start: 55, end: 100 },
            { type: 'slider', height: 16, bottom: 4, borderColor: 'rgba(255,255,255,0.06)', fillerColor: 'rgba(20,184,201,0.12)',
              handleStyle: { color: _V4_ACCENT, borderColor: _V4_ACCENT }, textStyle: { color: '#94a3b8', fontSize: 9 } }
        ],
        xAxis: { type: 'category', data: dates, boundaryGap: false,
                 axisLabel: Object.assign({ formatter: d => d.substring(0, 7) }, ax), axisLine: { lineStyle: { color: '#334155' } } },
        yAxis: [
            { type: 'value', name: 'ERP %', nameTextStyle: ax,
              min: x => Math.min(Math.floor(x.min - 0.3), T[0] - 0.5), max: x => Math.max(Math.ceil(x.max + 0.3), T[T.length - 1] + 0.5),
              axisLabel: Object.assign({ formatter: '{value}%' }, ax), splitLine: { show: false } },
            { type: 'value', name: 'v4 档位', position: 'right', min: 0, max: 100, interval: 25, nameTextStyle: ax,
              axisLabel: { color: '#94a3b8', fontSize: 9, formatter: '{value}%' }, splitLine: { show: false } }
        ],
        series: [
            { name: '正常化 ERP', type: 'line', data: v.erp_adj, yAxisIndex: 0, symbol: 'none', z: 10,
              lineStyle: { color: '#f1f5f9', width: 2 }, itemStyle: { color: '#f1f5f9' },
              markArea: { silent: true, data: bands },
              markLine: { silent: true, symbol: 'none', data: thLines },
              markPoint: { data: adjNow == null ? [] : [{ coord: [dates[last], adjNow], symbol: 'circle', symbolSize: 9,
                  itemStyle: { color: '#f1f5f9', borderColor: _V4_ACCENT, borderWidth: 2 },
                  label: { show: true, position: 'left', distance: 8, formatter: adjNow.toFixed(2) + '%', color: '#f1f5f9', fontSize: 11, fontWeight: 700,
                           backgroundColor: 'rgba(15,23,42,0.85)', padding: [2, 4], borderRadius: 3 } }] } },
            { name: '原始 ERP', type: 'line', data: chart.erp, yAxisIndex: 0, symbol: 'none', z: 8,
              lineStyle: { color: '#94a3b8', width: 1, type: 'dashed', opacity: 0.7 }, itemStyle: { color: '#94a3b8' } },
            { name: 'v4 档位', type: 'line', step: 'end', data: v.target_pct, yAxisIndex: 1, symbol: 'none', z: 6,
              lineStyle: { color: _V4_ACCENT, width: 1.1, opacity: 0.55 }, itemStyle: { color: _V4_ACCENT } },
            { name: '10Y国债', type: 'line', data: chart.yield_10y, yAxisIndex: 0, symbol: 'none',
              lineStyle: { color: '#a78bfa', width: 1, type: 'dotted' }, itemStyle: { color: '#a78bfa' } },
            { name: '前向记录', type: 'scatter', data: fwd, yAxisIndex: 1, symbolSize: 7, z: 12,
              itemStyle: { color: '#fbbf24', borderColor: '#0f172a', borderWidth: 1 } }
        ]
    }, true);
    renderERPLadderTable(chart, note);
    return inst;
}

/**
 * 统一入口 (策略页 / 首页): 有 v4 数据时提供 "v4 档位 / 相对估值" 两个视图, 默认 v4;
 * 无 v4 时退回旧区间图。返回新的 ECharts 实例。
 */
function renderERPChartWithToggle(chart, signalData, prevInstance, onInstance) {
    let inst = prevInstance;
    const draw = view => {
        // 切换视图会重建 ECharts 实例: 通过 onInstance 回传给页面, 保证页面持有的引用始终是最新实例
        _erpViewToggle(view, nv => { inst = draw(nv); if (typeof onInstance === 'function') onInstance(inst); });
        if (view === 'v4') return renderERPV4DecisionChart(chart, inst);
        const ladderAnchor = document.getElementById('erp-history-chart');
        const out = renderERPZoneChart(chart, signalData, inst);
        const note = document.getElementById('erp-chart-note') || ladderAnchor;
        renderERPLadderTable(chart, note);
        return out;
    };
    if (!(chart.v4 && Array.isArray(chart.v4.erp_adj))) return renderERPZoneChart(chart, signalData, prevInstance);
    inst = draw(_erpChartViewPref());
    return inst;
}
