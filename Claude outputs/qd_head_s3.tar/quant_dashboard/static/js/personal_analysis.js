/* Personal research view. Confirmations create local plans, never broker orders. */
(function () {
    'use strict';
    const $ = id => document.getElementById(id);
    const escape = value => String(value ?? '—').replace(/[&<>"']/g, c => ({
        '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
    }[c]));
    const actionLabels = { buy: '满足买入条件', hold: '持有观察', sell: '退出提示',
        sell_half: '减仓提示', sell_weak: '弱势退出提示', stop_loss: '止损提示',
        no_entry: '当前无新增候选', error: '当前不可计算' };
    const blockers = { DATA_UNAVAILABLE: '当前行情或参数快照不可用，请重新运行策略',
        ENTRY_CAP_ZERO: '当前市场状态的新增仓位上限为零',
        PORTFOLIO_UNAVAILABLE_OR_STALE: '持仓快照缺失或过期，请更新实际持仓',
        HOLDING_MARK_UNAVAILABLE: '持仓数量或估值信息不完整', ACCOUNT_VALUE_UNAVAILABLE: '账户资产无法核对',
        INSUFFICIENT_CASH: '可用资金不足',
        OBSERVATION_ONLY: '当前仅可观察，证据或信号不满足计划条件', INSUFFICIENT_HOLDINGS: '计划卖出数量超过实际持仓',
        MARKET_SNAPSHOT_CHANGED: '本地行情已更新或缺失，请重新运行策略后核查',
        COMPLIANCE_HARD_BLOCK: '合规硬阻断：当前禁止买入/加仓（卖出不受限）',
        COMPLIANCE_UNAVAILABLE: '合规结论不可用：默认禁止买入/加仓',
        HOLDINGS_STALE: '持仓可能已过时，请先导入对账单' };
    let generation = 0, previewGeneration = 0, activeCode = null, activePreview = null;
    let requestId = null, submitting = false;
    let allSignals = [], currentFilter = 'all', currentQuery = '';
    const exitActions = new Set(['sell', 'sell_half', 'sell_weak', 'stop_loss']);
    const filterLabels = { all: '全部标的', buy: '买入候选', exit: '退出提示', hold: '持有观察', attention: '证据关注', unavailable: '数据异常' };
    const newId = () => {
        const bytes = new Uint8Array(16);
        crypto.getRandomValues(bytes);
        return Array.from(bytes, b => b.toString(16).padStart(2, '0')).join('');
    };
    const apiBase = () => typeof API_URL !== 'undefined' ? API_URL : '';

    async function api(path, options = {}) {
        const controller = new AbortController();
        const timer = setTimeout(() => controller.abort(), 20000);
        try {
            const fetcher = options.method && options.method !== 'GET'
                ? (window.AC?.secureFetch ? window.AC.secureFetch.bind(window.AC) : null) : fetch;
            if (!fetcher) throw new Error('安全通信组件尚未就绪，请刷新页面');
            const response = await fetcher(`${apiBase()}/api/v1/analysis${path}`, { ...options, signal: controller.signal });
            const json = await response.json();
            if (!response.ok || json.status !== 'success') throw new Error((window.AC?.errorText ? window.AC.errorText(json) : json.detail) || json.message || '操作未完成');
            return json.data;
        } finally { clearTimeout(timer); }
    }

    function metric(value, suffix = '') {
        return typeof value === 'number' && Number.isFinite(value) ? `${value.toFixed(2)}${suffix}` : '待核对';
    }

    function referencePrice(value) {
        return typeof value === 'number' && Number.isFinite(value)
            ? value.toLocaleString('zh-CN', { minimumFractionDigits: 3, maximumFractionDigits: 4 }) : '—';
    }

    function formatTime(value) {
        if (!value) return '—';
        const date = new Date(value);
        if (Number.isNaN(date.getTime())) return String(value);
        return date.toLocaleString('zh-CN', {
            year: 'numeric', month: '2-digit', day: '2-digit',
            hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false
        }).replace(/\//g, '-');
    }

    function needsReview(s) {
        return s.evidence?.status !== 'validated' || s.evidence?.freshness === 'stale' || s.evidence?.binding !== 'matched';
    }

    function evidenceTone(evidence) {
        return evidence.status === 'rejected' ? 'danger' : needsReview({ evidence }) ? 'warning' : 'verified';
    }

    function inGroup(s, filter) {
        const available = s.data_status?.status === 'available';
        if (filter === 'buy') return available && s.research_signal === 'buy';
        if (filter === 'exit') return available && exitActions.has(s.research_signal);
        if (filter === 'hold') return available && ['hold', 'no_entry'].includes(s.research_signal);
        if (filter === 'attention') return needsReview(s);
        if (filter === 'unavailable') return !available;
        return true;
    }

    function summarize(signals) {
        return { total: signals.length, available: signals.filter(s => s.data_status?.status === 'available').length,
            buy: signals.filter(s => inGroup(s, 'buy')).length, exit: signals.filter(s => inGroup(s, 'exit')).length,
            hold: signals.filter(s => inGroup(s, 'hold')).length, attention: signals.filter(needsReview).length,
            unavailable: signals.filter(s => inGroup(s, 'unavailable')).length };
    }

    function filterSignals(signals, { query = '', filter = 'all' } = {}) {
        const needle = query.trim().toLocaleLowerCase();
        return signals.filter(s => inGroup(s, filter) && (!needle ||
            `${s.name || ''} ${s.ts_code || s.code || ''}`.toLocaleLowerCase().includes(needle)));
    }

    // 2026-11-04 权威环境 1b: 非权威 (本机) / 状态未知 → 观察 / 不采用 / 确认计划不可写 (后端同样拒绝)
    let writeBlocked = '';
    const blockedAttr = () => writeBlocked ? ` disabled title="${escape(writeBlocked)}"` : '';

    function renderCards(signals) {
        return signals.map(s => {
            const evidence = s.evidence || {};
            const data = s.data_status || {};
            const risk = s.risk_checks || {};
            const code = s.ts_code || s.code || '';
            const reason = (risk.reasons || []).map(r => blockers[r] || '条件待核对').join('；');
            const unavailable = data.status !== 'available';
            const evidenceText = `${evidence.label || '证据待补'}${evidence.freshness === 'stale' ? ' · 已到复验期' : ''}`;
            const score = typeof s.signal_score === 'number' && Number.isFinite(s.signal_score) ? s.signal_score : null;
            const gate = typeof s.score_gate === 'number' && Number.isFinite(s.score_gate) ? s.score_gate : null;
            const scoreTier = score === null ? 'muted' : score >= (gate ?? 68) ? 'high' : score >= 55 ? 'mid' : 'low';
            const scorePct = score !== null ? Math.max(0, Math.min(100, score)) : 0;
            const canPlanAction = ['buy', 'sell', 'sell_half', 'sell_weak', 'stop_loss'].includes(s.research_signal);
            const signalTone = unavailable ? 'muted' : s.research_signal === 'stop_loss' ? 'danger' : exitActions.has(s.research_signal) ? 'exit' : s.research_signal === 'buy' ? 'entry' : 'neutral';
            const regime = s.regime || '待识别';
            const regimeTone = regime === 'BULL' ? 'bull' : regime === 'BEAR' || regime === 'CRASH' ? 'bear' : 'range';
            const price = referencePrice(s.close);
            const factors = [
                typeof s.rsi === 'number' && Number.isFinite(s.rsi) ? `<span class="pa-factor"><i>RSI</i><b>${escape(s.rsi.toFixed(1))}</b></span>` : '',
                typeof s.bias === 'number' && Number.isFinite(s.bias) ? `<span class="pa-factor"><i>乖离</i><b>${escape(`${s.bias > 0 ? '+' : ''}${s.bias.toFixed(1)}%`)}</b></span>` : '',
                typeof s.percent_b === 'number' && Number.isFinite(s.percent_b) ? `<span class="pa-factor"><i>%B</i><b>${escape(s.percent_b.toFixed(2))}</b></span>` : ''
            ].filter(Boolean).join('');
            const actionable = Boolean(s.permissions?.manual_plan && !unavailable);
            return `<article class="pa-card pa-card-${signalTone} ${unavailable ? 'pa-card-unavailable' : ''}" data-signal="${escape(s.research_signal || '')}">
                <div class="pa-identity">
                    <div class="pa-card-heading"><div><strong>${escape(s.name || code)}</strong><div class="pa-symbol"><span class="pa-code">${escape(code)}</span><span class="pa-regime pa-regime-${regimeTone}">${escape(regime)}</span>${s.asset_class ? `<span class="pa-asset-tag">${escape(s.asset_class)}</span>` : ''}</div></div>
                        <div class="pa-score pa-score-${scoreTier}" aria-label="模型评分 ${score ?? '待补'}" style="--pa-score-pct:${scorePct}%"><b>${score ?? '—'}</b><small>模型评分${gate !== null ? ` · 门槛 ${escape(gate)}` : ''}</small></div></div>
                    <div class="pa-price-line"><span class="pa-price-tag">参考价 <b>${escape(price)}</b></span><time>${escape(data.as_of)}</time>${factors ? `<div class="pa-factors" aria-label="均值回归指标">${factors}</div>` : ''}</div>
                </div>
                <div class="pa-signal-cell"><span class="pa-cell-label">参考信号</span>
                    <span class="pa-badge pa-badge-${signalTone} pa-signal-${escape(s.research_signal || 'none')}"><i aria-hidden="true"></i>${escape(unavailable ? '当前不可计算' : (actionLabels[s.research_signal] || '待核对'))}</span>
                </div>
                <div class="pa-evidence-cell"><span class="pa-cell-label">验证证据</span><span class="pa-badge pa-badge-${evidenceTone(evidence)}">${escape(evidenceText)}</span>
                    <details class="pa-evidence-details"><summary>查看依据<span aria-hidden="true">⌄</span></summary><div class="pa-evidence-content"><p>${escape(evidence.detail)}</p>
                        <p>数据截止 <b>${escape(evidence.data_through)}</b></p><p>下次复验 <b>${escape(evidence.next_validate_after?.slice(0, 10))}</b></p>
                        ${evidence.metrics ? `<p>状态交易日 <b>${escape(evidence.metrics.regime_days)}</b> · 交易次数 <b>${escape(evidence.metrics.trades)}</b></p>` : ''}
                        <p>${escape(data.detail)}</p></div></details>
                </div>
                <div class="pa-risk-cell"><span class="pa-cell-label">风险与权限</span><p class="${reason ? 'pa-risk-warning' : ''}">${escape(reason || '待计划数量与持仓核查')}</p>
                    <span class="pa-permission ${actionable ? 'is-actionable' : 'is-observe-only'}">${actionable ? '待本人确认' : '仅供观察'}</span></div>
                <div class="pa-actions"><button type="button" data-pa-action="watch" data-code="${escape(code)}" ${unavailable ? 'disabled' : ''}${blockedAttr()}>加入观察</button>
                    <button type="button" data-pa-action="declined" data-code="${escape(code)}" ${unavailable ? 'disabled' : ''}${blockedAttr()}>本次不采用</button>
                    ${canPlanAction ? `<button type="button" class="pa-plan-action" data-pa-action="preview" data-code="${escape(code)}">${s.permissions?.manual_plan ? '人工计划预览' : '查看计划限制'}<span aria-hidden="true">↗</span></button>` : ''}</div>
            </article>`;
        }).join('');
    }

    function renderView() {
        const summary = summarize(allSignals);
        const visible = filterSignals(allSignals, { query: currentQuery, filter: currentFilter });
        const stats = [
            ['分析标的', summary.total, `${summary.available} 项数据可用`, ''],
            ['买入候选', summary.buy, '规则触发，需独立核查', summary.buy ? 'pa-stat-entry' : ''],
            ['退出提示', summary.exit, '包含减仓与止损参考', summary.exit ? 'pa-stat-exit' : ''],
            ['证据需复核', summary.attention, '查看验证结论与时效', summary.attention ? 'pa-stat-warning' : 'pa-stat-verified']
        ];
        if ($('pa-summary')) $('pa-summary').innerHTML = stats.map(([label, value, note, toneClass]) =>
            `<div class="pa-stat ${toneClass}"><dt>${label}</dt><dd>${value}<span>${note}</span></dd></div>`).join('');
        document.querySelectorAll('[data-pa-filter]').forEach(button => {
            const key = button.dataset.paFilter;
            button.setAttribute('aria-pressed', String(key === currentFilter));
            button.classList.toggle('is-active', key === currentFilter);
            const count = button.querySelector('.pa-filter-count');
            if (count) count.textContent = summary[key === 'all' ? 'total' : key] ?? 0;
        });
        if ($('pa-visible-count')) $('pa-visible-count').textContent = `${visible.length} / ${summary.total} 个标的`;
        $('pa-signals').innerHTML = visible.length ? renderCards(visible) : `<div class="pa-empty"><span class="pa-empty-mark" aria-hidden="true">⌕</span>
            <strong>${allSignals.length ? '没有符合条件的标的' : '等待参考信号'}</strong><p>${allSignals.length ? `尝试其他名称、代码或切换“${escape(filterLabels[currentFilter] || '全部标的')}”筛选。` : '运行上方均值回归或六策略分析后，参考信号会显示在这里。'}</p>
            ${allSignals.length ? '<button type="button" data-pa-reset>清除筛选</button>' : ''}</div>`;
    }

    // 2026-11-02: 买入计划的合规门控结果 (合规引擎按买入方向判定); 逐条列出阻断规则
    function renderCompliance(gate) {
        if (!gate || gate.status === 'not_applicable') return '';
        const blocks = Array.isArray(gate.blocks) ? gate.blocks : [];
        const warns = Array.isArray(gate.warnings) ? gate.warnings : [];
        const label = gate.allowed ? (warns.length ? '通过 · 有警告' : '通过') : (blocks.length ? '硬阻断' : '不可用');
        const tone = gate.allowed ? (warns.length ? 'warning' : 'verified') : 'danger';
        const rows = items => items.map(r => `<li><strong>${escape(r.rule_name)}</strong>：${escape(r.detail)}</li>`).join('');
        return `<section class="pa-check-section pa-compliance"><div class="pa-section-title"><strong>合规门控</strong><span class="pa-badge pa-badge-${tone}">${label}</span></div>
            <p>${escape(gate.summary)}</p>
            ${blocks.length ? `<ul class="pa-blockers">${rows(blocks)}</ul>` : ''}
            ${warns.length ? `<p class="pa-section-note">警告（不阻断）</p><ul class="pa-blockers">${rows(warns)}</ul>` : ''}</section>`;
    }

    // 2026-11-02 项 2: 买入计划的成交后仓位 / 主题取合规门控 (统一口径, 同一分母); 卖出用本地估算
    function renderProjected(result) {
        const pt = result.compliance && result.compliance.post_trade;
        const theme = pt && Array.isArray(pt.themes) && pt.themes.length ? pt.themes[0] : null;
        const head = `<section class="pa-check-section"><div class="pa-section-title"><strong>计划后仓位</strong><span class="pa-section-note">${pt ? '合规门控 · 成交后组合' : '按当前账户快照估算'}</span></div>`;
        if (pt) {
            return `${head}<dl class="pa-exposures"><div><dt>总仓位</dt><dd>${metric(pt.total_pct, '%')}</dd></div><div><dt>单标的</dt><dd>${metric(pt.single_pct, '%')}</dd></div>`
                + `<div><dt>主题${theme ? ` · ${escape(theme.theme)}` : ''}</dt><dd>${theme ? metric(theme.pct, '%') : '不计入'}</dd></div></dl></section>`;
        }
        if (result.projected) {
            return `${head}<dl class="pa-exposures"><div><dt>总仓位</dt><dd>${metric(result.projected.total_pct, '%')}</dd></div><div><dt>单标的</dt><dd>${metric(result.projected.single_pct, '%')}</dd></div></dl></section>`;
        }
        return `${head}<p class="pa-unavailable-note">数量或账户估值尚未通过核查，暂不展示计划后仓位。</p></section>`;
    }

    // 信号动态单笔上限: 只提示, 不拦截 (醒目显示)
    function renderNotices(notices) {
        const list = Array.isArray(notices) ? notices : [];
        if (!list.length) return '';
        return `<div class="pa-check-banner pa-notice is-warning" role="alert"><strong>⚠ 注意（不拦截）</strong><ul class="pa-blockers">${list.map(n => `<li>${escape(n.detail)}</li>`).join('')}</ul></div>`;
    }

    function renderPreview(result) {
        const evidence = result.evidence || {};
        const issues = result.blockers || [];
        return `<div class="pa-preview-overview"><div><span class="pa-cell-label">计划标的</span><strong>${escape(result.name)}</strong><small>${escape(result.code)}</small></div>
            <span class="pa-badge ${result.side === 'sell' ? 'pa-badge-exit' : 'pa-badge-entry'}">${result.side === 'sell' ? '卖出计划' : '买入计划'}</span></div>
            <dl class="pa-preview-metrics"><div><dt>计划数量</dt><dd>${escape(result.amount)}<small>份／股</small></dd></div><div><dt>日线参考价</dt><dd>${escape(referencePrice(result.reference_price))}<small>元／份（股）</small></dd></div>
                <div><dt>估算金额</dt><dd>${metric(result.notional)}<small>元</small></dd></div></dl>
            <div class="pa-snapshot-line"><span>参考日 ${escape(result.reference_as_of)}</span><span>持仓快照 ${escape(result.portfolio_as_of)}</span><span>已持有 ${escape(result.held_amount)} 份／股</span></div>
            <section class="pa-check-section"><div class="pa-section-title"><strong>验证证据</strong><span class="pa-badge pa-badge-${evidenceTone(evidence)}">${escape(evidence.label)}</span></div><p>${escape(evidence.detail)}</p></section>
            ${renderProjected(result)}
            ${renderNotices(result.notices)}
            ${renderCompliance(result.compliance)}
            <div class="pa-check-banner ${result.can_confirm ? 'is-ready' : 'is-blocked'}"><strong>${result.can_confirm ? '核查完成 · 待本人确认' : '当前计划无法确认'}</strong>
                ${issues.length ? `<ul class="pa-blockers">${issues.map(r => `<li>${escape(blockers[r] || '条件待核对')}</li>`).join('')}</ul>` : '<p>确认将记录本次人工计划，成交信息须另行导入核对。</p>'}</div>
            <p class="pa-method-note">${escape(result.note)}</p>`;
    }

    function setStage(stage) {
        document.querySelectorAll('[data-pa-step]').forEach(item => {
            const number = Number(item.dataset.paStep);
            item.classList.toggle('is-current', number === stage);
            item.classList.toggle('is-complete', number < stage);
            if (number === stage) item.setAttribute('aria-current', 'step'); else item.removeAttribute('aria-current');
        });
    }

    async function refreshRecords() {
        let rows;
        try { rows = await api('/records'); }
        catch (error) {
            if ($('pa-records')) $('pa-records').textContent = `记录列表暂未刷新：${error.message}`;
            return;
        }
        if (!$('pa-records')) return;
        if ($('pa-record-count')) $('pa-record-count').textContent = rows.length;
        const recordTone = { planned: 'entry', watch: 'neutral', declined: 'muted', self_directed: 'warning' };
        $('pa-records').innerHTML = rows.length ? rows.map(r => {
            const code = r.code || r.signal?.ts_code || '';
            const statusText = ({ planned: '已记录计划 · 成交另行核对', watch: '已加入观察', declined: '本次未采用', self_directed: '个人自主决定' })[r.status] || '已记录';
            return `<div class="pa-record">
            <strong>${escape(r.name || r.signal?.name || code)}${code ? ` <em>${escape(code)}</em>` : ''}</strong>
            <span class="pa-record-tag pa-record-${recordTone[r.status] || 'neutral'}">${escape(statusText)}</span>
            <small>${escape(formatTime(r.created_at))}${r.amount ? ` · ${escape(r.side === 'sell' ? '卖出' : '买入')} ${escape(r.amount)} 份／股` : ''}</small>
        </div>`;
        }).join('') : '<div class="pa-record-empty">暂无记录。加入观察或确认人工计划后，可在此回顾决策。</div>';
    }

    async function refresh() {
        const token = ++generation;
        if (!$('pa-signals')) return;
        $('pa-refresh').disabled = true;
        $('pa-status').textContent = '正在读取参考信号与证据状态…';
        try {
            const data = await api('/mr');
            if (token !== generation) return;
            allSignals = data.signals || [];
            renderView();
            const dates = [...new Set(allSignals.map(s => s.data_status?.as_of).filter(Boolean))].sort();
            $('pa-status').classList.remove('is-error');
            $('pa-status').textContent = allSignals.length ? `参考数据截至 ${dates.at(-1) || '待补'} · 视图更新 ${new Date().toLocaleTimeString('zh-CN', { hour12: false })}` : data.message;
            await refreshRecords();
        } catch (error) {
            if (token === generation) {
                $('pa-status').classList.add('is-error');
                $('pa-status').textContent = `分析视图读取失败：${error.message}${allSignals.length ? '；当前保留上次视图，请刷新后复核。' : ''}`;
            }
        } finally { if (token === generation) $('pa-refresh').disabled = false; }
    }

    function invalidatePreview() {
        ++previewGeneration;
        activePreview = null;
        requestId = null;
        $('pa-ack').checked = false;
        $('pa-ack').disabled = true;
        $('pa-confirm').disabled = true;
    }

    function openPreview(code) {
        activeCode = code;
        invalidatePreview();
        $('pa-dialog-title').textContent = `${code} · 人工计划预览`;
        $('pa-amount').value = '';
        $('pa-preview-result').innerHTML = '<div class="pa-preview-empty"><strong>先核查，再确认</strong><p>输入数量后，将核对参考时间、验证证据、账户快照及风险限制。</p></div>';
        setStage(1);
        $('pa-dialog').showModal();
        $('pa-amount').focus();
    }

    async function preview() {
        invalidatePreview();
        const token = previewGeneration;
        const amount = Number($('pa-amount').value);
        if (!Number.isSafeInteger(amount) || amount < 1 || amount > 100000000) {
            $('pa-preview-result').textContent = '请输入有效的整数数量'; return;
        }
        $('pa-preview').disabled = true;
        $('pa-preview').textContent = '正在核查…';
        setStage(2);
        $('pa-preview-result').textContent = '正在核查当前快照…';
        try {
            const result = await api(`/mr/${encodeURIComponent(activeCode)}/preview?amount=${amount}`);
            if (token !== previewGeneration || !$('pa-dialog').open) return;
            activePreview = result;
            requestId = newId();
            $('pa-preview-result').innerHTML = renderPreview(result);
            $('pa-ack').disabled = !result.can_confirm;
            setStage(result.can_confirm ? 3 : 2);
        } catch (error) {
            if (token === previewGeneration) $('pa-preview-result').textContent = error.message;
        } finally { $('pa-preview').disabled = false; $('pa-preview').textContent = '核查计划'; }
    }

    async function confirmPlan() {
        if (writeBlocked) { $('pa-preview-result').textContent = writeBlocked; return; }
        if (submitting || !activePreview || !$('pa-ack').checked || !activePreview.can_confirm) return;
        submitting = true;
        $('pa-confirm').disabled = true;
        $('pa-confirm').textContent = '正在记录…';
        $('pa-amount').disabled = true;
        $('pa-preview').disabled = true;
        try {
            const record = await api('/plans', { method: 'POST', body: JSON.stringify({ code: activeCode,
                amount: activePreview.amount, snapshot_id: activePreview.snapshot_id, request_id: requestId, acknowledged: true }) });
            invalidatePreview();
            setStage(3);
            $('pa-preview-result').textContent = `计划已记录（${record.id.slice(0, 8)}），未向券商提交。请在完成实际交易后导入成交记录。`;
            await refreshRecords();
        } catch (error) {
            // Retain the id for a safe retry after a lost response. A snapshot conflict requires a new preview.
            $('pa-preview-result').textContent = `${error.message}；可重新核查计划，或在网络恢复后重试确认。`;
            $('pa-confirm').disabled = !activePreview?.can_confirm || !$('pa-ack').checked;
        } finally {
            submitting = false;
            $('pa-amount').disabled = false;
            $('pa-preview').disabled = false;
            $('pa-confirm').textContent = '确认记录计划';
        }
    }

    function init() {
        if (!$('personal-analysis')) return;
        if (window.AC && typeof window.AC.authority === 'function') {
            window.AC.authority().then(info => {
                writeBlocked = window.AC.accountWriteBlockedText(info, 'write');
                if (writeBlocked) { $('pa-confirm').disabled = true; $('pa-confirm').title = writeBlocked; renderView(); }
            });
        }
        $('pa-refresh').addEventListener('click', refresh);
        $('pa-search')?.addEventListener('input', event => { currentQuery = event.target.value; renderView(); });
        $('pa-filters')?.addEventListener('click', event => {
            const button = event.target.closest('[data-pa-filter]');
            if (!button) return;
            currentFilter = button.dataset.paFilter;
            renderView();
        });
        $('pa-signals').addEventListener('click', async event => {
            if (event.target.closest('[data-pa-reset]')) {
                currentFilter = 'all'; currentQuery = '';
                if ($('pa-search')) { $('pa-search').value = ''; $('pa-search').focus(); }
                renderView(); return;
            }
            const button = event.target.closest('button[data-pa-action]');
            if (!button || button.disabled) return;
            if (button.dataset.paAction === 'preview') { openPreview(button.dataset.code); return; }
            button.disabled = true;
            try {
                await api('/observations', { method: 'POST', body: JSON.stringify({ code: button.dataset.code,
                    request_id: newId(), action: button.dataset.paAction }) });
                $('pa-status').textContent = '观察决定已记录，验证结论与实际持仓保持独立。';
                await refreshRecords();
            } catch (error) { $('pa-status').textContent = error.message; }
            finally { button.disabled = false; }
        });
        $('pa-preview').addEventListener('click', preview);
        $('pa-amount').addEventListener('input', () => {
            const hadPreview = !!activePreview;
            invalidatePreview(); setStage(1);
            if (hadPreview) $('pa-preview-result').innerHTML = '<div class="pa-preview-empty"><strong>数量已更新</strong><p>请重新核查计划，原确认结果已失效。</p></div>';
        });
        $('pa-ack').addEventListener('change', () => { $('pa-confirm').disabled = !!writeBlocked || !activePreview?.can_confirm || !$('pa-ack').checked; });
        $('pa-confirm').addEventListener('click', confirmPlan);
        $('pa-close').addEventListener('click', () => { if (!submitting) $('pa-dialog').close(); });
        $('pa-dialog').addEventListener('cancel', event => { if (submitting) event.preventDefault(); });
        $('pa-dialog').addEventListener('close', () => { invalidatePreview(); activeCode = null; });
        refresh();
    }
    window.PersonalAnalysis = { refresh, renderCards, renderPreview, summarize, filterSignals };
    document.addEventListener('DOMContentLoaded', init);
}());
