/**
 * 组合页核心资产 KPI (2026-11-03 组合页精简 P3, docs/PORTFOLIO_SLIMMING_PLAN.md)
 * ============================================================================
 * 每个数字只读唯一来源, 本页不自算:
 *   账户收益  /api/v1/portfolio/returns?start=2026-10-30   (整账户 TWR, 剔除入出金; 起点规则 10-30 收盘,
 *             用户 2026-11-04 确认: 有真实券商快照, 不用推算值; 起点晚于规则日时写明缺失)
 *   组合波动  /api/v1/portfolio/vol-budget → portfolio.portfolio_vol / target_vol (与合规「组合波动预算」同一计算)
 *   当前回撤  /api/v1/portfolio/vol-budget → waterfall[key=drawdown] (risk_state.drawdown_brake, 与合规 / 执行层同一份)
 *   风险贡献  /api/v1/portfolio/vol-budget → portfolio.positions[].risk_share (替代原 120 日 MCTR)
 * 原"建仓以来 ROI"(持仓成本口径)、120D 波动 / 夏普 / 最大回撤 (当前持仓回溯) 已删除。
 * 2026-11-04 视觉轮 V2 (docs/PORTFOLIO_SLIMMING_PLAN.md 10.2 / 10.3):
 *   - 账户收益按红涨绿跌 (.ac-up / .ac-down); "数据不足"用 .ac-state-partial 小块写明接口 note
 *   - 当前回撤 / 组合波动数字中性; 回撤刹车档位标签与决策中枢跟踪止盈面板同一映射 (第 1 档 warn、第 2 档及以上阻断实底)
 *   - 组合波动只写"目标 x%", 状态标签读合规「组合波动预算」检查项, 前端不比较
 *   - 执行目标行: 读首页执行区同一接口 /api/v1/decision/hub (action_plan.execution_target), 不可用 "--", 不算差额
 */
(function (root) {
    'use strict';

    const RULE_START = '2026-10-30';   // 账户收益起算规则 (收盘快照, 用户 2026-11-04 确认)
    const EXACT = 'chain_linked_exact';

    function esc(s) {
        return String(s == null ? '' : s).replace(/[&<>"']/g, c => (
            { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
    }
    const num = v => (typeof v === 'number' && Number.isFinite(v) ? v : null);
    const md = d => String(d || '').slice(5, 10);
    const pct = (v, d = 1) => `${(v * 100).toFixed(d)}%`;
    const signed = v => `${v > 0 ? '+' : ''}${(v * 100).toFixed(2)}%`;

    /** /portfolio/returns 的 account → {value, sub, title}。 */
    function returnModel(acc) {
        if (!acc || typeof acc !== 'object') return { value: '数据不足', sub: '收益接口不可用', title: '', partial: true, dir: null };
        if (acc.status !== 'ok' || num(acc.twr) === null) {
            return { value: '数据不足', sub: acc.note || acc.status || '不能计算', title: acc.note || '', partial: true, dir: null };
        }
        const parts = [`${md(acc.from)} 收盘 → ${md(acc.to)} 收盘`];
        if (acc.from && acc.from > RULE_START) parts.push(`${md(RULE_START)} 收盘快照缺失，自 ${md(acc.from)} 起`);
        if (acc.twr_method !== EXACT) parts.push('近似');
        const range = Array.isArray(acc.twr_range) && acc.twr_range.length === 2
            ? `区间 ${signed(acc.twr_range[0])} ~ ${signed(acc.twr_range[1])}；` : '';
        const inferred = acc.coverage_inferred_to
            ? `；入出金覆盖末端按交割单导出日推定（至 ${md(acc.coverage_inferred_to)}，文件中该段无记录）` : '';
        return { value: signed(acc.twr), sub: parts.join(' · '), dir: acc.twr > 0 ? 'up' : acc.twr < 0 ? 'down' : 'flat',
                 title: `整账户时间加权收益（含现金，剔除入出金）；${range}${acc.twr_note || ''}${inferred}` };
    }

    /** vol-budget 视图 → 组合波动。 */
    function volModel(view) {
        const p = (view && view.portfolio) || {};
        const v = num(p.portfolio_vol), t = num(p.target_vol);
        if (v === null) return { value: '--', sub: '波动预算不可用', title: '' };
        return { value: pct(v), sub: t === null ? '250 日估计' : `目标 ${pct(t, 0)} · 250 日估计`,
                 title: `${p.method || ''}；与合规「组合波动预算」同一计算${p.as_of ? `；截至 ${p.as_of}` : ''}` };
    }

    /** vol-budget 视图 → 当前回撤 (回撤刹车)。不显示"降至 x%"类仓位数字 (执行目标是唯一仓位数字)。 */
    function drawdownModel(view) {
        const row = ((view && view.waterfall) || []).find(r => r && r.key === 'drawdown');
        if (!row) return { value: '--', sub: '回撤刹车状态不可用', title: '' };
        const dd = num(row.dd);
        const tier = Number.isInteger(row.tier) ? row.tier : null;
        const tierText = tier === null ? '档位未知' : tier === 0 ? '回撤刹车未触发' : `回撤刹车第 ${tier} 档`;
        return { value: dd === null ? '--' : `-${Math.abs(dd * 100).toFixed(1)}%`, sub: tierText,
                 tag: { text: tierText, cls: tierTagClass(tier) }, asof: row.asof || '',
                 title: `风险资产时间加权净值自高水位的当前回撤（与合规、执行层同一份回撤刹车状态）${row.asof ? `；${row.asof}` : ''}` };
    }

    /** 回撤刹车档位 → 状态标签类 (与决策中枢跟踪止盈面板 TIER_CLS ['ok','warm','hot','hot'] 同一映射)。 */
    function tierTagClass(tier) {
        if (!Number.isInteger(tier)) return 'ac-tag-info';
        return tier >= 2 ? 'ac-tag-block' : tier === 1 ? 'ac-tag-warn' : 'ac-tag-pass';
    }

    /** 合规「组合波动预算」检查项 → 状态标签 (只读结果, 前端不比较)。 */
    function volTagModel(compliance) {
        const c = ((compliance && compliance.checks) || []).find(r => r && r.rule_id === 'vol_budget');
        if (!c || typeof c.passed !== 'boolean') return null;
        if (c.passed) return { text: '组合波动预算 · 通过', cls: 'ac-tag-pass', title: c.detail || '' };
        return c.severity === 'hard_block'
            ? { text: '组合波动预算 · 硬阻断', cls: 'ac-tag-block', title: c.detail || '' }
            : { text: '组合波动预算 · 警告', cls: 'ac-tag-warn', title: c.detail || '' };
    }

    /** /decision/hub → 执行目标 (全站唯一仓位数字); 不可用 null。 */
    function execTargetModel(hub) {
        const h = hub && hub.data && hub.data.action_plan ? hub.data : hub;
        const t = num(h && h.action_plan && h.action_plan.execution_target);
        return t === null ? null : t;
    }

    /** vol-budget 视图 → 风险贡献行 (risk_share 降序)。 */
    function riskRows(view) {
        const pos = ((view && view.portfolio) || {}).positions || [];
        return pos.filter(p => num(p.risk_share) !== null)
            .sort((a, b) => b.risk_share - a.risk_share)
            .map(p => ({ name: p.name || p.ts_code, code: p.ts_code, weight: num(p.weight_pct), share: p.risk_share }));
    }

    function riskTableHtml(view) {
        const rows = riskRows(view);
        if (!rows.length) return '<div class="pf-empty">风险贡献不可用（波动预算无持仓数据）</div>';
        const p = (view && view.portfolio) || {};
        // 2026-11-04 视觉轮 V3: 仓位占比 / 风险占比两列并排中性条 (同一比例尺), 便于看出风险占比明显高于仓位占比的持仓; 不加颜色阈值
        const max = Math.max(...rows.map(r => Math.max(r.weight || 0, r.share * 100)), 0.0001);
        const cell = v => (v === null ? '<td class="num">--</td>'
            : `<td class="lt-pair"><span class="lt-bar"><i style="width:${Math.min(100, v / max * 100).toFixed(1)}%"></i></span><span class="num">${v.toFixed(1)}%</span></td>`);
        return `<table class="pf-table lt-table lt-risk-table"><thead><tr><th>标的</th><th>仓位占比（占账户）</th><th>风险占比（风险贡献）</th></tr></thead><tbody>` +
            rows.map(r => `<tr><td class="lt-name">${esc(r.name)}<small> ${esc(r.code)}</small></td>` +
                cell(r.weight) + cell(r.share * 100) + '</tr>').join('') +
            `</tbody></table><p class="lt-note">来源：组合波动预算（${esc(p.method || '250 日等权波动 + 收缩相关矩阵')}${p.as_of ? `，截至 ${esc(p.as_of)}` : ''}），与合规同一计算；各标的合计 100%。</p>`;
    }

    const DIR_CLS = { up: 'ac-up', down: 'ac-down', flat: 'ac-flat' };
    function setCard(prefix, m) {
        const d = root.document;
        const v = d.getElementById(prefix), s = d.getElementById(`${prefix}-sub`);
        if (v) {
            v.textContent = m.value; v.title = m.title || '';
            v.className = `pf-kpi-value${m.dir ? ` ${DIR_CLS[m.dir]}` : ''}`;   // 只有账户收益带涨跌方向
        }
        if (!s) return;
        s.className = m.partial ? 'pf-kpi-sub ac-state-partial' : 'pf-kpi-sub ac-asof';
        if (m.tag) {
            s.innerHTML = `<span class="ac-tag ${m.tag.cls}">${esc(m.tag.text)}</span>${m.asof ? `<span class="pf-kpi-time">${esc(m.asof)}</span>` : ''}`;
        } else {
            s.textContent = m.sub || '';
        }
    }

    function setVolTag(compliance) {
        const el = root.document && root.document.getElementById('port-vol-tag');
        if (!el) return;
        const t = volTagModel(compliance);
        el.innerHTML = t ? `<span class="ac-tag ${t.cls}" title="${esc(t.title)}">${esc(t.text)}</span>` : '';
    }

    async function loadExecTarget() {
        const el = root.document && root.document.getElementById('pf-exec-target');
        let t = null;
        try {
            const r = await root.fetch('/api/v1/decision/hub');
            if (r.ok) t = execTargetModel(await r.json());
        } catch (e) { t = null; }
        if (el) el.textContent = t === null ? '--' : `${Number(t.toFixed(1))}%`;
        return t;
    }

    async function getJson(url) {
        const r = await root.fetch(url);
        if (!r.ok) throw new Error(`HTTP ${r.status}`);
        const j = await r.json();
        return j && j.status === 'success' ? j.data : null;
    }

    async function load() {
        const [ret, vb] = await Promise.all([
            getJson(`/api/v1/portfolio/returns?start=${RULE_START}`).catch(() => null),
            getJson('/api/v1/portfolio/vol-budget').catch(() => null),
        ]);
        setCard('port-return', returnModel(ret && ret.account));
        setCard('port-vol', volModel(vb));
        setCard('port-dd', drawdownModel(vb));
        const rt = root.document.getElementById('pf-risk-contrib');
        if (rt) rt.innerHTML = riskTableHtml(vb);
        const pc = root.PfCompliance;
        setVolTag(pc && pc.last ? pc.last() : null);
        return { ret, vb };
    }

    if (root.addEventListener) root.addEventListener('pf:compliance', e => setVolTag(e.detail));

    root.PfKpis = { returnModel, volModel, drawdownModel, tierTagClass, volTagModel, execTargetModel, loadExecTarget,
                    riskRows, riskTableHtml, load, RULE_START };
})(typeof window !== 'undefined' ? window : globalThis);
