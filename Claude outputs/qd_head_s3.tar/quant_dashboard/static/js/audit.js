/**
 * AlphaCore 深度审计
 * 定位 (2026-11-02): A. 系统可信吗 (四项等权 + 一票否决) / B. 组合是否违反已定风险规则 (只读合规引擎结论, 不打分)
 * 口径: 风控只读合规引擎结果 · 回撤为账户回撤 · 参数证据只评 MR/DIV/MOM/GEM
 * 只读页面: 旧执行器 (自动强平/交易阻断/静音降级/确认弹窗) 已退役; 审计历史需手动"保存审计"或每日定时写入
 * 视觉 (2026-11-02): 颜色全部在 audit.css 的 CSS 变量里, 本文件只输出 class (s-pass/s-warn/s-fail/s-block/s-info)
 */

// A = 系统可信度 (四项等权); B = 组合合规 (合规引擎结论, 不计分、不进 A 的平均)
const MODULE_META = {
    data_freshness:       { label: '数据新鲜度', weight: '25%', part: 'A' },
    engine_runtime:       { label: '引擎运行',   weight: '25%', part: 'A' },
    param_evidence:       { label: '参数证据',   weight: '25%', part: 'A' },
    system_status:        { label: '系统状态',   weight: '25%', part: 'A' },
    portfolio_compliance: { label: '组合合规',   weight: '不计分', part: 'B' },
};
const TRUST_KEYS = Object.keys(MODULE_META).filter(k => MODULE_META[k].part === 'A');

// 状态 → 样式 class (颜色在 CSS 变量里)
const STATUS_CLASS = { pass: 's-pass', warn: 's-warn', fail: 's-fail', info: 's-info' };
const STATUS_TEXT = { pass: '通过', warn: '警告', fail: '失败', info: '读数' };
// B 合规结论: 阻断用独立的阻断色 (s-block), 不可用按失败
const COMPLIANCE_CLASS = { passed: 's-pass', warning: 's-warn', blocked: 's-block', unknown: 's-fail' };
const COMPLIANCE_PANEL = { passed: 'is-pass', warning: 'is-warn', blocked: 'is-block', unknown: 'is-fail' };

let auditData = null;
let activeModule = null;
let _auditRunning = false;  // 防并发调用
let _auditGeneration = 0;   // 防止过期回调

// ═══════════════════════════════════════════════════════
//  初始化
// ═══════════════════════════════════════════════════════
document.addEventListener('DOMContentLoaded', () => { runAudit(); });

function _el(id) { return document.getElementById(id); }
function _setHidden(id, hidden) { const el = _el(id); if (el) el.hidden = hidden; }

async function runAudit() {
    if (_auditRunning) return;
    _auditRunning = true;
    const btn = _el('audit-refresh-btn');
    if (btn) { btn.disabled = true; btn.textContent = '审计中…'; }

    const loading = _el('audit-loading');
    if (loading && loading.dataset.html) loading.innerHTML = loading.dataset.html;
    if (loading && !loading.dataset.html) loading.dataset.html = loading.innerHTML;
    _setHidden('audit-loading', false);
    ['audit-summary', 'trust-section', 'compliance-section', 'trend-section'].forEach(id => _setHidden(id, true));
    const detail = _el('detail-section');
    if (detail) detail.classList.remove('visible');
    activeModule = null;

    try {
        const resp = await fetch('/api/v1/audit');
        if (!resp.ok) {
            const errData = await resp.json().catch(() => ({}));
            throw new Error(errData.message || `服务器错误 (HTTP ${resp.status})`);
        }
        const data = await resp.json();
        if (data.status === 'warming_up') {   // 2026-11-02: 服务启动预热中, 不出审计结论; 15 秒后自动重试
            const pend = ((data.warmup || {}).pending_labels || []).join('、');
            _renderError('数据加载中', 's-info', data.message || '服务启动预热中', pend ? `待完成：${pend}` : '', false);
            setTimeout(() => runAudit(), 15000);
            return;
        }
        if (data.status !== 'ok') {
            showAuditError(data.message || '审计引擎返回异常', data.error || '');
            return;
        }
        auditData = data;
        renderAll(data);
    } catch (e) {
        console.error('审计失败:', e);
        showNetworkError(e.message || '未知错误，请确认服务器已启动');
    } finally {
        _auditRunning = false;
        if (btn) { btn.disabled = false; btn.textContent = '重新审计'; }
    }
}

function _renderError(title, cls, message, detail, withHome) {
    const loading = _el('audit-loading');
    if (!loading) return;
    loading.innerHTML = `
        <div class="au-error">
            <div class="au-error-title ${cls}">${escapeAuditHtml(title)}</div>
            <div class="au-error-msg">${escapeAuditHtml(message)}</div>
            ${detail ? `<div class="au-error-msg">${escapeAuditHtml(detail)}</div>` : ''}
            <div class="au-error-actions">
                <button onclick="runAudit()" class="au-btn">重新审计</button>
                ${withHome ? '<a href="/" class="au-btn">返回首页</a>' : ''}
            </div>
        </div>`;
    loading.hidden = false;
}
// API 级别的错误 (区别于网络中断)
function showAuditError(message, detail) { _renderError('审计引擎异常', 's-warn', message, detail, false); }
function showNetworkError(msg) { _renderError('审计连接中断', 's-fail', msg, '', true); }

// ═══════════════════════════════════════════════════════
//  渲染全部
// ═══════════════════════════════════════════════════════
function renderAll(data) {
    _setHidden('audit-loading', true);
    _setHidden('audit-summary', false);
    _setHidden('trust-section', false);
    _setHidden('compliance-section', false);

    renderHead(data);
    renderTrustPanel(data);
    renderCompliancePanel(data);
    renderModuleCards(data);
    renderComplianceSection(data);

    const gen = ++_auditGeneration;
    setTimeout(() => { if (gen === _auditGeneration) autoExpandWorst(data); }, 0);
    loadTrend(gen);
}

function renderHead(data) {
    const v = _el('audit-version');
    if (v) v.textContent = data.version || '—';
    const t = _el('audit-time');
    if (t) t.textContent = `审计于 ${data.audit_time || '—'} · 耗时 ${data.elapsed_seconds ?? '—'}s`;
}

// ═══════════════════════════════════════════════════════
//  工具
// ═══════════════════════════════════════════════════════
function escapeAuditHtml(value) {
    return String(value ?? '—').replace(/[&<>'"]/g, ch => ({
        '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;',
    }[ch]));
}

function formatAuditNumber(value, digits = 2, percent = false) {
    const num = Number(value);
    if (value === null || value === undefined || !Number.isFinite(num)) return '—';
    return `${(percent ? num * 100 : num).toFixed(digits)}${percent ? '%' : ''}`;
}

// 接口阈值文案用绿/黄/红圆点符号分段 (只作标记, 页面不显示 emoji, 源码用转义写)
const MARK_PASS = '\u{1F7E2}', MARK_WARN = '\u{1F7E1}', MARK_FAIL = '\u{1F534}';
function stripMarks(text) {
    return String(text ?? '').replace(/[\u{1F7E0}-\u{1F7EB}\u{1F534}-\u{1F535}\u{1F6D1}\u{26A0}\u{2705}\u{274C}\u{FE0F}]/gu, '').trim();
}

// ISO 时间 (带时区) → 北京时间; 不带时区的如实显示
function formatSnapshotTime(ts) {
    if (!ts) return '—';
    const hasZone = /[zZ]|[+-]\d{2}:?\d{2}$/.test(ts);
    const d = new Date(ts);
    if (!hasZone || isNaN(d)) return `${ts} (未标时区)`;
    const p = new Intl.DateTimeFormat('zh-CN', {
        timeZone: 'Asia/Shanghai', year: 'numeric', month: '2-digit', day: '2-digit',
        hour: '2-digit', minute: '2-digit', hour12: false,
    }).formatToParts(d).reduce((o, x) => (o[x.type] = x.value, o), {});
    return `${p.year}-${p.month}-${p.day} ${p.hour}:${p.minute} 北京`;
}

function badge(cls, text) { return `<span class="au-badge ${cls}">${escapeAuditHtml(text)}</span>`; }

function moduleStatus(mod) {
    const checks = (mod?.checks || []).filter(c => c.status !== 'info');
    if (checks.some(c => c.status === 'fail')) return 'fail';
    if (checks.some(c => c.status === 'warn')) return 'warn';
    return 'pass';
}

// 否决项规则: 优先读接口 veto_rules (后端常量 engines/audit_engine.VETO_RULES), 缺失时按该项 threshold 文案分段
function vetoRuleFor(v, rules) {
    const r = (rules || []).find(x => x.name === v.name);
    if (r) return r;
    const segs = String(v.threshold || '').split('|').map(s => s.trim());
    const pick = mark => stripMarks(segs.find(s => s.includes(mark)) || '') || null;
    return { pass: pick(MARK_PASS), warn: pick(MARK_WARN), veto: pick(MARK_FAIL) };
}

// ═══════════════════════════════════════════════════════
//  1. A 系统可信度 (首屏左)
// ═══════════════════════════════════════════════════════
function renderTrustPanel(data) {
    const el = _el('trust-panel');
    if (!el) return;
    const trust = data.system_trust || {};
    const score = trust.score ?? 0;
    const vetoed = !!trust.veto?.triggered;
    const status = vetoed ? 'block' : (trust.status || 'fail');
    const badgeCls = vetoed ? 's-block' : (STATUS_CLASS[status] || 's-fail');
    const label = trust.status_label || (vetoed ? '失败 · 一票否决' : '—');
    el.className = `au-panel au-trust${vetoed ? ' is-vetoed' : ''}`;

    const rules = trust.status_rules;
    const rulesTxt = rules ? ` · 分界 ${rules.pass} 可信 / ${rules.warn} 需关注 / ${rules.fail} 不可信` : '';
    const big = vetoed
        ? `<div class="au-big"><span class="au-big-word">否决</span></div>
           <div class="au-veto-avg">四项均分 <span class="mono">${escapeAuditHtml(score)}</span> · 仅供参考，不作判定</div>`
        : `<div class="au-big"><span class="au-big-num">${escapeAuditHtml(score)}</span>
           <span class="au-big-sub">/ 100 · ${escapeAuditHtml(trust.grade || '—')} 级</span></div>`;

    const vetoes = trust.vetoes || [];
    const vetoRows = vetoes.map(v => {
        const rule = vetoRuleFor(v, trust.veto_rules);
        const st = v.status === 'fail' ? 's-block' : (STATUS_CLASS[v.status] || 's-info');
        const txt = v.status === 'fail' ? '否决' : (v.status === 'warn' ? '警告 · 容忍内' : '通过');
        const ruleTxt = [
            rule.pass ? `<span class="r-pass"><b>通过</b> ${escapeAuditHtml(rule.pass)}</span>` : '',
            `<span class="r-warn"><b>警告</b> ${rule.warn ? escapeAuditHtml(rule.warn) : '无容忍区'}</span>`,
            rule.veto ? `<span class="r-veto"><b>否决</b> ${escapeAuditHtml(rule.veto)}</span>` : '',
        ].filter(Boolean).join(' · ');
        return `<div class="au-veto-row ${st}" title="${escapeAuditHtml(v.explanation || '')}">
            <span class="au-veto-name">${escapeAuditHtml(v.name)}</span>
            ${badge(st, txt)}
            <span class="au-veto-detail">${escapeAuditHtml(v.detail)}</span>
            <div class="au-veto-rule">${ruleTxt}</div>
        </div>`;
    }).join('');

    // 否决区状态说明: 不允许出现"否决区有问题、A 仍显示可信"却没有说明
    const tolerated = vetoes.filter(v => v.status === 'warn');
    let note = '';
    if (vetoed) {
        note = `<div class="au-note s-block"><b>一票否决：</b>${escapeAuditHtml(trust.veto.items.join('、'))} 未通过 → A 系统可信度直接判失败；否决项不参与平均，上方四项均分仅供参考。</div>`;
    } else if (tolerated.length) {
        note = `<div class="au-note s-warn"><b>否决项在容忍范围内（警告），未触发否决：</b>${tolerated.map(v => escapeAuditHtml(v.name)).join('、')}。A 仍按四项均分判定为「${escapeAuditHtml(label)}」；越过容忍区即否决（见各项阈值）。</div>`;
    }

    el.innerHTML = `
        <div class="au-panel-head">
            <span class="au-panel-title">A 系统可信度<small>系统可信吗</small></span>
            ${badge(badgeCls, label)}
        </div>
        ${big}
        <div class="au-formula">四项等权平均${rulesTxt}</div>
        <div class="au-veto" id="veto-block">
            <div class="au-veto-head">一票否决项 <small>任一否决 → A 直接判失败 · 否决项不参与平均</small>
                <button class="au-link au-veto-toggle" onclick="document.getElementById('veto-block').classList.toggle('show-rules')">阈值说明</button></div>
            ${vetoRows || '<div class="au-veto-detail">无否决项数据</div>'}
        </div>
        ${note}`;
}

// ═══════════════════════════════════════════════════════
//  2. B 组合合规 (首屏右, 不计分)
// ═══════════════════════════════════════════════════════
function complianceRules(data) {
    return (data.modules?.portfolio_compliance?.checks || []).filter(c => c.source === 'compliance_engine');
}

function renderCompliancePanel(data) {
    const el = _el('comp-panel');
    if (!el) return;
    const pc = data.portfolio_compliance || {};
    const status = pc.status || 'unknown';
    const rules = complianceRules(data);
    const hard = rules.filter(c => c.status === 'fail');
    const soft = rules.filter(c => c.status === 'warn');
    const exempt = rules.filter(c => c.status === 'info');
    const passed = rules.filter(c => c.status === 'pass');
    el.className = `au-panel au-comp ${COMPLIANCE_PANEL[status] || 'is-fail'}`;
    const snap = pc.snapshot || {};

    const issues = [...hard, ...soft].map(c => {
        const cls = c.status === 'fail' ? 's-block' : 's-warn';
        const txt = c.status === 'fail' ? '硬阻断' : '软警告';
        return `<li>${badge(cls, txt)}<span class="n">${escapeAuditHtml(c.name)}</span><span class="d" title="${escapeAuditHtml(c.detail)}">${escapeAuditHtml(c.detail)}</span></li>`;
    }).join('');

    el.innerHTML = `
        <div class="au-panel-head">
            <span class="au-panel-title">B 组合合规<small>合规引擎结论 · 不计分</small></span>
            ${badge(COMPLIANCE_CLASS[status] || 's-fail', pc.status_label || '不可用')}
        </div>
        <div class="au-big"><span class="au-big-word">${escapeAuditHtml(pc.status_label || '不可用')}</span></div>
        <div class="au-comp-counts">${rules.length
            ? `合规引擎 <span class="mono">${rules.length}</span> 条规则 · <span class="mono">${hard.length}</span> 硬阻断 · <span class="mono">${soft.length}</span> 软警告 · <span class="mono">${passed.length}</span> 通过${exempt.length ? ` · <span class="mono">${exempt.length}</span> 减仓豁免` : ''}`
            : '无合规结论'}</div>
        ${issues ? `<ul class="au-comp-list">${issues}</ul>` : ''}
        <div class="au-comp-foot">
            <span>快照 ${escapeAuditHtml(formatSnapshotTime(snap.timestamp))}</span>
            <span>下单权限 ${snap.create_order ? '开放' : '关闭'}</span>
            <button class="au-link" onclick="document.getElementById('compliance-section').scrollIntoView({behavior:'smooth',block:'start'})">规则明细</button>
        </div>`;
}

// ═══════════════════════════════════════════════════════
//  3. A 四项卡片 (一行 4 列)
// ═══════════════════════════════════════════════════════
function renderModuleCards(data) {
    const container = _el('module-cards');
    if (!container) return;
    container.innerHTML = TRUST_KEYS.map(key => {
        const meta = MODULE_META[key];
        const mod = data.modules?.[key];
        if (!mod) return '';
        const checks = mod.checks || [];
        const passC = checks.filter(c => c.status === 'pass').length;
        const warnC = checks.filter(c => c.status === 'warn').length;
        const failC = checks.filter(c => c.status === 'fail').length;
        const st = moduleStatus(mod);
        // 最差项: 先按状态 (失败 > 警告 > 通过), 再按分数
        const rank = { fail: 0, warn: 1, pass: 2 };
        const worst = [...checks].filter(c => c.status !== 'info')
            .sort((a, b) => (rank[a.status] ?? 3) - (rank[b.status] ?? 3) || (a.score ?? 100) - (b.score ?? 100))[0];
        const cb = mod.circuit_breaker;
        const sc = Math.max(0, Math.min(100, Number(mod.score) || 0));
        return `
        <button class="au-card ${st === 'pass' ? '' : STATUS_CLASS[st]}" onclick="toggleDetail('${key}')" id="card-${key}"
            title="${escapeAuditHtml(meta.label)} ${mod.score}/100 · ${passC} 通过 ${warnC} 警告 ${failC} 失败 · 权重 ${meta.weight}">
            <div class="au-card-head"><span>${escapeAuditHtml(meta.label)}</span><span class="grade">${escapeAuditHtml(mod.grade || '—')} 级 · ${meta.weight}</span></div>
            <div class="au-card-score"><span class="mono">${escapeAuditHtml(mod.score)}</span><small>/ 100</small></div>
            <div class="au-bar"><i style="width:${sc}%"></i></div>
            <div class="au-card-counts">
                ${passC ? `<span class="c-pass">${passC} 通过</span>` : '<span>0 通过</span>'}
                ${warnC ? `<span class="c-warn">${warnC} 警告</span>` : ''}
                ${failC ? `<span class="c-fail">${failC} 失败</span>` : ''}
            </div>
            ${worst ? `<div class="au-card-worst ${STATUS_CLASS[worst.status] || ''}">
                <span class="k">最差项</span>
                <span class="au-dot ${STATUS_CLASS[worst.status] || ''}"></span>
                <span class="n">${escapeAuditHtml(worst.name)}</span>
                <span class="mono">${worst.score ?? '—'}</span>
            </div>` : ''}
            ${cb ? `<span class="au-cb-tag" title="原始加权分 ${escapeAuditHtml(cb.original)} → 封顶 ${escapeAuditHtml(cb.cap)}">断路器 · ${escapeAuditHtml(cb.reason)}</span>` : ''}
        </button>`;
    }).join('');
}

// ═══════════════════════════════════════════════════════
//  4. 检查行 (A 明细 / B 规则明细共用)
// ═══════════════════════════════════════════════════════
function renderStrategyHealthSummary(mod) {
    const trace = mod.score_audit;
    if (!trace) return '';
    const expression = (trace.contributions || []).map(c =>
        `${escapeAuditHtml(c.score)}×${formatAuditNumber(Number(c.weight) * 100, 0)}%`
    ).join(' + ');
    const rules = (trace.applied_rules || []).map(r =>
        `<span class="score-rule">${escapeAuditHtml(r.before)} → ${escapeAuditHtml(r.after)}<small>${escapeAuditHtml(r.reason)}</small></span>`
    ).join('');
    return `<section class="strategy-evidence-summary">
        <div class="strategy-diagnosis-boundary">
            <span class="evidence-section-label">诊断边界</span>
            <p>${escapeAuditHtml(mod.diagnosis?.summary)}</p>
            <small>${escapeAuditHtml(mod.diagnosis?.scope)}</small>
        </div>
        <div class="strategy-score-trace">
            <div class="score-trace-heading">
                <span class="evidence-section-label">评分复算轨迹</span>
                <span>权重合计 ${formatAuditNumber(trace.weight_total, 2)}</span>
            </div>
            <div class="score-expression">${expression}</div>
            <div class="score-equation">
                <span>精确值 <strong>${formatAuditNumber(trace.weighted_exact, 2)}</strong></span>
                <span>向下取整 <strong>${escapeAuditHtml(trace.weighted_score)}</strong></span>
                ${rules || `<span>最终 <strong>${escapeAuditHtml(trace.final_score)}</strong></span>`}
            </div>
            <small>参数证据为系统可信度四项之一 · 权重 ${formatAuditNumber(Number(trace.module_weight) * 100, 0)}% · 只评 MR/DIV/MOM/GEM, ERP/AIAE 为背景读数不参与。</small>
        </div>
    </section>`;
}

function renderRiskSummary(mod) {
    const snap = mod.snapshot || {};
    return `<div class="au-source">
        <span class="evidence-section-label">判定来源</span>
        <div>${escapeAuditHtml(mod.diagnosis?.summary)}</div>
        <small>决策中枢快照 ${escapeAuditHtml(formatSnapshotTime(snap.timestamp))} · 下单权限 ${snap.create_order ? '开放' : '关闭'} · ${escapeAuditHtml(mod.diagnosis?.scope)}</small>
    </div>`;
}

function renderCheckDiagnosis(check) {
    const diagnosis = check.diagnosis;
    if (!diagnosis) return '';
    const labels = {
        evidence_missing: '证据缺失', evidence_invalid: '证据不可用',
        evidence_mismatch: '证据不适用', evidence_stale: '证据过期',
        evidence_quality: '证据质量不足', evidence_valid: '证据一致',
    };
    return `<div class="check-diagnosis">
        <div class="diagnosis-heading">
            <span class="diagnosis-category">${escapeAuditHtml(labels[diagnosis.category] || '证据诊断')}</span>
            <span class="diagnosis-confidence">诊断可信度：${escapeAuditHtml(diagnosis.confidence)}</span>
        </div>
        <p>${escapeAuditHtml(diagnosis.summary)}</p>
        <div class="diagnosis-next"><strong>解除／维持条件</strong>${escapeAuditHtml(diagnosis.next_condition)}</div>
    </div>`;
}

function renderErpEvidence(check) {
    const evidence = check.evidence;
    if (!evidence || check.name !== 'ERP择时') return '';
    if (check.evidence_kind === 'live_engine_replay') return renderErpReplayEvidence(evidence);
    const diffs = evidence.parameter_diffs || [];
    const diffRows = diffs.length ? diffs.map(d => `<tr>
        <td>${escapeAuditHtml(d.parameter)}</td>
        <td>${escapeAuditHtml(d.live)}</td>
        <td>${escapeAuditHtml(d.evidence)}</td>
    </tr>`).join('') : '<tr><td colspan="3">实盘参数与证据参数一致</td></tr>';
    const oos = evidence.out_of_sample || {};
    const limitations = (evidence.limitations || []).map(item =>
        `<li>${escapeAuditHtml(item)}</li>`
    ).join('');
    return `<div class="erp-evidence-block">
        <div class="evidence-block-title">原始证据对账 <span>${escapeAuditHtml(evidence.source)}</span></div>
        <div class="evidence-grid">
            <div><span>样本外区间</span><strong>${escapeAuditHtml(evidence.out_sample_period)}</strong></div>
            <div><span>数据截止</span><strong>${escapeAuditHtml(evidence.data_through)}${evidence.data_lag_days !== null && evidence.data_lag_days !== undefined ? ` · ${escapeAuditHtml(evidence.data_lag_days)}天前` : ''}</strong></div>
            <div><span>样本外超额</span><strong>${formatAuditNumber(oos.alpha, 1, true)}</strong></div>
            <div><span>样本外交易</span><strong>${escapeAuditHtml(oos.total_trades)} 笔</strong></div>
            <div><span>策略／基准收益</span><strong>${formatAuditNumber(oos.total_return, 1, true)}／${formatAuditNumber(oos.bench_return, 1, true)}</strong></div>
            <div><span>证据生成</span><strong>${escapeAuditHtml(evidence.generated_at)}</strong></div>
        </div>
        <table class="evidence-diff-table">
            <thead><tr><th>差异参数</th><th>当前实盘</th><th>旧验证证据</th></tr></thead>
            <tbody>${diffRows}</tbody>
        </table>
        ${limitations ? `<ul class="evidence-limitations">${limitations}</ul>` : ''}
        <div class="independent-verification">独立核验边界：${escapeAuditHtml(evidence.independent_verification)}</div>
    </div>`;
}

function renderErpReplayEvidence(evidence) {
    const perf = evidence.historical_performance || {};
    const excess = perf['vs_同仓位固定']?.excess || {};
    const ci = excess.ci90;
    const limits = (evidence.limitations || []).map(item => `<li>${escapeAuditHtml(item)}</li>`).join('');
    return `<div class="erp-evidence-block">
        <div class="evidence-block-title">实盘引擎回放对账 <span>${escapeAuditHtml(evidence.source)}</span></div>
        <div class="evidence-grid">
            <div><span>当前参数哈希</span><strong>${escapeAuditHtml(evidence.parameter_hash)}</strong></div>
            <div><span>证据参数哈希</span><strong>${escapeAuditHtml(evidence.evidence_hash)}</strong></div>
            <div><span>数据截止</span><strong>${escapeAuditHtml(evidence.data_through)}</strong></div>
            <div><span>成交规则</span><strong>${escapeAuditHtml(evidence.execution)}</strong></div>
            <div><span>回顾年化收益／最大回撤</span><strong>${formatAuditNumber(perf.cagr, 1, true)}／${formatAuditNumber(perf.mdd, 1, true)}</strong></div>
            <div><span>回顾调仓次数</span><strong>${escapeAuditHtml(perf.rebalances)}</strong></div>
            <div><span>相对同仓位固定的历史年化超额</span><strong>${formatAuditNumber(excess.ann_mean, 2, true)}</strong></div>
            <div><span>90% 置信区间</span><strong>${Array.isArray(ci) && ci.length === 2 ? `${formatAuditNumber(ci[0], 2, true)} ～ ${formatAuditNumber(ci[1], 2, true)}` : '—'}</strong></div>
        </div>
        <small>${escapeAuditHtml(evidence.strategy)} · ${escapeAuditHtml(evidence.period)}</small>
        ${limits ? `<ul class="evidence-limitations">${limits}</ul>` : ''}
        <div class="independent-verification">验证边界：${escapeAuditHtml(evidence.independent_verification)}</div>
    </div>`;
}

// 阈值文案 "绿 … | 黄 … | 红 …" → 分段, 当前状态所在段高亮 (色点替代 emoji)
function parseThresholdSegments(thresholdStr, status) {
    const active = status === 'pass' ? 's-pass' : (status === 'warn' ? 's-warn' : (status === 'fail' ? 's-fail' : ''));
    return String(thresholdStr).split('|').map(s => s.trim()).filter(Boolean).map(seg => {
        let cls = 's-pass';
        if (seg.includes(MARK_WARN) || seg.includes('黄')) cls = 's-warn';
        if (seg.includes(MARK_FAIL) || seg.includes('红')) cls = 's-fail';
        return `<span class="threshold-seg ${cls}${cls === active ? ' active' : ''}"><span class="au-dot ${cls}"></span>${escapeAuditHtml(stripMarks(seg))}</span>`;
    }).join('');
}

/**
 * 一行检查。kind:
 *  'score'   A 计分项: 状态 + 分数条 + 分数
 *  'rule'    B 合规规则: 状态 (通过/软警告/硬阻断/减仓豁免·只读), 不显示分数
 *  'reading' 只读读数: 不判定、不计分
 */
function renderCheckRow(c, key, idx, kind) {
    let st, txt;
    if (kind === 'reading') { st = 's-info'; txt = '读数'; }
    else if (kind === 'rule') {
        if (c.status === 'fail') { st = 's-block'; txt = '硬阻断'; }
        else if (c.status === 'warn') { st = 's-warn'; txt = '软警告'; }
        else if (c.status === 'info') { st = 's-info'; txt = '豁免·只读'; }
        else { st = 's-pass'; txt = '通过'; }
    } else if (c.status === 'info') { st = 's-info'; txt = '读数'; kind = 'reading'; }
    else { st = STATUS_CLASS[c.status] || 's-fail'; txt = STATUS_TEXT[c.status] || '失败'; }

    const ruleId = `rule-${key}-${idx}`;
    const hasRule = c.explanation || c.threshold || c.action || c.diagnosis || c.evidence;
    const sc = Math.max(0, Math.min(100, Number(c.score) || 0));
    const scoreCols = kind === 'score'
        ? `<div class="check-score-bar"><div class="check-score-fill" style="width:${sc}%"></div></div>
           <span class="check-score-val">${c.score ?? '—'}</span>`
        : '';
    const rowCls = `check-row status-${c.status}${kind === 'score' ? '' : ' no-score'}${kind === 'reading' ? ' row-reading' : ''}`;
    const actionAttr = c.action ? escapeAuditHtml(c.action) : '';
    return `
    <div class="${rowCls}" id="check-${key}-${idx}">
        <span class="check-status">${badge(st, txt)}</span>
        <div class="check-info">
            <div class="check-name">${escapeAuditHtml(c.name)}</div>
            <div class="check-detail">${escapeAuditHtml(c.detail || '')}${c.link ? ` <a class="check-link" href="./${escapeAuditHtml(c.link)}">去处理</a>` : ''}</div>
            ${c.meta ? `<div class="check-meta">${escapeAuditHtml(c.meta)}</div>` : ''}
        </div>
        ${scoreCols}
        ${hasRule ? `<button class="check-expand-btn" id="btn-${ruleId}" onclick="toggleRule(event,'${ruleId}')" title="规则说明">▼</button>` : '<span></span>'}
    </div>
    ${hasRule ? `
    <div class="check-rule-panel" id="${ruleId}">
        ${renderCheckDiagnosis(c)}
        ${renderErpEvidence(c)}
        ${c.explanation ? `<div class="rule-explanation"><span class="rule-label">说明</span>${escapeAuditHtml(c.explanation)}</div>` : ''}
        ${c.threshold ? `<div class="rule-threshold-bar"><span class="rule-label">阈值</span><div class="threshold-segments">${parseThresholdSegments(c.threshold, c.status)}</div></div>` : ''}
        ${c.action ? `<div class="rule-action"><span class="rule-label">处理</span>
            <span class="rule-action-text">${escapeAuditHtml(c.action)}</span>
            <button class="rule-action-copy" data-text="${actionAttr}" onclick="copyAction(event)">复制</button></div>` : ''}
    </div>` : ''}`;
}

// ═══════════════════════════════════════════════════════
//  5. A 明细展开
// ═══════════════════════════════════════════════════════
function toggleDetail(key, noScroll = false) {
    if (MODULE_META[key]?.part === 'B') {   // B 单独成块, 直接定位
        _el('compliance-section')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
        return;
    }
    const section = _el('detail-section');
    document.querySelectorAll('.au-card').forEach(c => c.classList.remove('expanded'));
    if (activeModule === key) { section.classList.remove('visible'); activeModule = null; return; }
    activeModule = key;
    _el(`card-${key}`)?.classList.add('expanded');
    const meta = MODULE_META[key];
    const mod = auditData?.modules?.[key];
    if (!mod) return;
    _el('detail-title').textContent = `A ${meta.label} · ${mod.score}/100 (${mod.grade}级 · 权重 ${meta.weight})` +
        (mod.circuit_breaker ? ` · 断路器 ${mod.circuit_breaker.reason}: ${mod.circuit_breaker.original}→${mod.circuit_breaker.cap}` : '');
    const summary = key === 'param_evidence' ? renderStrategyHealthSummary(mod) : '';
    _el('detail-body').innerHTML = summary + (mod.checks || []).map((c, idx) => renderCheckRow(c, key, idx, 'score')).join('');
    section.classList.add('visible');
    if (!noScroll) section.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
}

function closeDetail() {
    _el('detail-section')?.classList.remove('visible');
    document.querySelectorAll('.au-card').forEach(c => c.classList.remove('expanded'));
    activeModule = null;
}

// ═══════════════════════════════════════════════════════
//  6. B 规则明细 (规则判定 + 只读读数, 不计分)
// ═══════════════════════════════════════════════════════
function renderComplianceSection(data) {
    const body = _el('compliance-body');
    if (!body) return;
    const mod = data.modules?.portfolio_compliance || {};
    const key = 'portfolio_compliance';
    const indexed = (mod.checks || []).map((c, idx) => ({ c, idx }));
    const rules = indexed.filter(x => x.c.source === 'compliance_engine');
    const readings = indexed.filter(x => x.c.source !== 'compliance_engine');
    body.innerHTML = renderRiskSummary(mod) +
        `<div class="au-group-label">合规规则 (${rules.length}) <small>判定来自合规引擎 · 本页不自带阈值</small></div>` +
        (rules.map(x => renderCheckRow(x.c, key, x.idx, 'rule')).join('') || '<div class="check-meta">无合规结论</div>') +
        (readings.length ? `<div class="au-group-label">只读读数 (${readings.length}) <small>不判定 · 不计分 · 供核对</small></div>` +
            readings.map(x => renderCheckRow(x.c, key, x.idx, 'reading')).join('') : '');
}

// ═══════════════════════════════════════════════════════
//  7. 手风琴 / 复制
// ═══════════════════════════════════════════════════════
function toggleRule(event, ruleId) {
    event.stopPropagation();
    const panel = _el(ruleId);
    const btn = _el(`btn-${ruleId}`);
    if (!panel) return;
    const isOpen = panel.classList.contains('open');
    panel.parentElement?.querySelectorAll('.check-rule-panel.open').forEach(p => {
        p.classList.remove('open');
        _el(`btn-${p.id}`)?.classList.remove('open');
    });
    if (!isOpen) {
        panel.classList.add('open');
        if (btn) btn.classList.add('open');
    }
}

function copyAction(event) {
    event.stopPropagation();
    const btn = event.currentTarget;
    navigator.clipboard.writeText(btn.dataset.text || '').then(() => {
        btn.classList.add('copied');
        btn.textContent = '已复制';
        setTimeout(() => { btn.classList.remove('copied'); btn.textContent = '复制'; }, 2000);
    });
}

// 自动展开 A 中最差的一项 (不抢视口)
function autoExpandWorst(data) {
    let worstKey = null, worstScore = 101;
    for (const key of TRUST_KEYS) {
        const mod = data.modules?.[key];
        if (!mod) continue;
        const hasFail = mod.checks?.some(c => c.status === 'fail');
        const eff = (mod.score ?? 0) - (hasFail ? 100 : 0);
        if (eff < worstScore) { worstScore = eff; worstKey = key; }
    }
    if (worstKey && worstScore < 100) toggleDetail(worstKey, true);
}

// ═══════════════════════════════════════════════════════
//  8. 审计趋势 (服务端审计历史; 只取当前口径, 每日一点, 定时记录优先)
//     A 线 = A 系统可信度 (否决日按否决标出); B 条 = 合规引擎结论 (不计分, 只显示状态)
// ═══════════════════════════════════════════════════════
const TRUST_STATUS_TEXT = { pass: '可信', warn: '需关注', fail: '不可信' };
const COMPLIANCE_TEXT = { passed: '通过', warning: '警告', blocked: '阻断', unknown: '不可用' };
const TRIGGER_TEXT = { daily: '定时', manual: '手动' };
let _trendData = null;

async function loadTrend(gen) {
    try {
        const resp = await fetch('/api/v1/audit/trend?days=90');
        const data = await resp.json();
        if (gen !== _auditGeneration) return;
        if (data.status !== 'ok') throw new Error(data.message || '趋势读取失败');
        _trendData = data;
        renderTrend(data);
    } catch (e) {
        console.error('审计趋势读取失败:', e);
        _setHidden('trend-section', false);
        const body = _el('trend-body');
        if (body) body.innerHTML = `<div class="au-trend-empty">审计趋势读取失败：${escapeAuditHtml(e.message)}（接口 /api/v1/audit/trend 需重启服务后可用）</div>`;
    }
}

function trendPointClass(p) {
    if ((p.veto || []).length) return 's-block';
    return STATUS_CLASS[p.trust_status] || 's-info';
}

function renderTrend(data) {
    const section = _el('trend-section');
    const body = _el('trend-body');
    if (!section || !body) return;
    section.hidden = false;
    const pts = data.points || [];
    const excluded = (data.excluded_legacy || 0) + (data.excluded_other_version || 0);
    _el('trend-sub').textContent = `口径 ${data.schema_version} · 近 ${data.days} 天 ${pts.length} 个日期 · 每日一点 (16:45 定时优先, 否则取当天最后一次手动保存)` +
        (excluded ? ` · 已排除旧口径/其他版本 ${excluded} 条` : '');
    if (pts.length < 2) {
        body.innerHTML = `<div class="au-trend-empty">当前口径的服务端记录 ${pts.length} 个日期，至少 2 个日期后显示趋势。记录来源：每个交易日 16:45 定时保存，或页面"保存审计"。打开页面不写历史。</div>` +
            (pts.length ? renderTrendTable(pts) : '');
        return;
    }
    const W = Math.max(300, body.clientWidth - 28), H = 150;
    const L = 30, R = 10, T = 10, B = 22, stripH = 8, stripGap = 18;
    const plotH = H - T - B;
    const x = i => L + (pts.length === 1 ? 0 : i * (W - L - R) / (pts.length - 1));
    const th = data.thresholds || {};
    // 纵轴下限随数据取整到 10 (至少含"需关注"分界下方 10 分), 上限 100; 不截断任何点
    const lo = Math.max(0, Math.floor((Math.min(...pts.map(p => Number(p.a_score) || 0), th.warn ?? 70) - 10) / 10) * 10);
    const y = v => T + plotH * (1 - (Math.max(lo, Math.min(100, Number(v) || 0)) - lo) / (100 - lo));
    const guides = [100, th.pass, th.warn, lo].filter(v => v !== undefined && v !== null).map(v =>
        `<line class="trend-guide${v === th.pass || v === th.warn ? ' is-bound' : ''}" x1="${L}" x2="${W - R}" y1="${y(v)}" y2="${y(v)}"></line>
         <text class="trend-axis" x="${L - 6}" y="${y(v) + 3}" text-anchor="end">${v}</text>`).join('');
    const line = `<polyline class="trend-line" points="${pts.map((p, i) => `${x(i)},${y(p.a_score)}`).join(' ')}"></polyline>`;
    const tip = p => `${p.date} ${TRIGGER_TEXT[p.trigger] || p.trigger || ''} · A ${p.a_score} ${(p.veto || []).length ? '否决: ' + p.veto.join('、') : (TRUST_STATUS_TEXT[p.trust_status] || '')} · B ${COMPLIANCE_TEXT[p.compliance_status] || '—'}`;
    // 否决日用菱形 (形状区分, 不只靠颜色)
    const dots = pts.map((p, i) => {
        const cls = `trend-pt ${trendPointClass(p)}${p.trigger === 'manual' ? ' is-manual' : ''}`;
        const cx = x(i), cy = y(p.a_score), t = `<title>${escapeAuditHtml(tip(p))}</title>`;
        return (p.veto || []).length
            ? `<path class="${cls}" d="M${cx} ${cy - 6}L${cx + 6} ${cy}L${cx} ${cy + 6}L${cx - 6} ${cy}Z">${t}</path>`
            : `<circle class="${cls}" cx="${cx}" cy="${cy}" r="4">${t}</circle>`;
    }).join('');
    const step = Math.max(1, Math.ceil(pts.length / Math.max(2, Math.floor((W - L) / 64))));
    const labels = pts.map((p, i) => (i % step === 0 || i === pts.length - 1)
        ? `<text class="trend-axis" x="${x(i)}" y="${H - 6}" text-anchor="middle">${escapeAuditHtml(p.date.slice(5))}</text>` : '').join('');
    const sy = H + stripGap - 14;
    const cellW = Math.max(4, Math.min(22, (W - L - R) / pts.length - 2));
    const strip = pts.map((p, i) => `<rect class="trend-b ${COMPLIANCE_CLASS[p.compliance_status] || 's-info'}" x="${x(i) - cellW / 2}" y="${sy}" width="${cellW}" height="${stripH}"><title>${escapeAuditHtml(`${p.date} · B 组合合规 ${COMPLIANCE_TEXT[p.compliance_status] || '—'}`)}</title></rect>`).join('');
    body.innerHTML = `
        <div class="au-trend-legend">
            <span><i class="trend-key line"></i>A 系统可信度 (分界 ${th.pass ?? '—'} / ${th.warn ?? '—'})</span>
            <span><span class="au-dot s-pass"></span>可信</span><span><span class="au-dot s-warn"></span>需关注</span>
            <span><span class="au-dot s-fail"></span>不可信</span><span><i class="trend-key diamond"></i>否决</span>
            <span><i class="trend-key hollow"></i>手动保存</span>
            <span><i class="trend-key strip"></i>B 组合合规 (只显示状态, 不计分)</span>
        </div>
        <svg class="au-trend-svg" width="${W}" height="${H + stripGap}" role="img" aria-label="审计趋势">
            ${guides}${line}${dots}${labels}
            <text class="trend-axis" x="${L - 6}" y="${sy + stripH - 1}" text-anchor="end">B</text>${strip}
        </svg>
        ${renderTrendTable(pts.slice(-5).reverse())}`;
}

function renderTrendTable(pts) {
    return `<table class="au-trend-table"><thead><tr><th>日期</th><th>来源</th><th>A 分数</th><th>A 状态</th><th>B 结论</th></tr></thead><tbody>` +
        pts.map(p => `<tr><td class="mono">${escapeAuditHtml(p.date)}</td><td>${escapeAuditHtml(TRIGGER_TEXT[p.trigger] || p.trigger || '—')}</td>
            <td class="mono">${escapeAuditHtml(p.a_score)}</td>
            <td>${(p.veto || []).length ? badge('s-block', '否决') : badge(STATUS_CLASS[p.trust_status] || 's-info', TRUST_STATUS_TEXT[p.trust_status] || '—')}</td>
            <td>${badge(COMPLIANCE_CLASS[p.compliance_status] || 's-info', COMPLIANCE_TEXT[p.compliance_status] || '—')}</td></tr>`).join('') +
        `</tbody></table>`;
}

let _trendResizeTimer = null;
window.addEventListener('resize', () => {
    clearTimeout(_trendResizeTimer);
    _trendResizeTimer = setTimeout(() => { if (_trendData) renderTrend(_trendData); }, 150);
});

// ═══════════════════════════════════════════════════════
//  手动保存审计 (写入审计历史; 打开页面不写)
// ═══════════════════════════════════════════════════════
async function saveAuditSnapshot() {
    const btn = _el('audit-save-btn');
    if (btn) { btn.disabled = true; btn.textContent = '保存中…'; }
    try {
        const resp = await AC.secureFetch('/api/v1/audit/save', { method: 'POST' });
        const data = await resp.json();
        if (btn) btn.textContent = data.status === 'ok' ? `已保存 ${data.audit_time || ''}`
            : (data.status === 'warming_up' ? '预热中，暂不保存' : '保存失败');
        if (data.status === 'ok') loadTrend(_auditGeneration);
    } catch (e) {
        console.error('保存审计失败:', e);
        if (btn) btn.textContent = '保存失败';
    } finally {
        if (btn) setTimeout(() => { btn.disabled = false; btn.textContent = '保存审计'; }, 3000);
    }
}

// 键盘: Esc 收起明细, R 重新审计
document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && activeModule) closeDetail();
    if (e.key === 'r' && !e.ctrlKey && !e.metaKey && !['INPUT', 'TEXTAREA'].includes(e.target.tagName)) runAudit();
});
