/**
 * 组合页模块开关 (2026-11-03 组合页精简 P4)
 * 读取 /api/v1/portfolio/modules (唯一配置: config/portfolio_modules.json)。
 * 关闭的模块: 元素加 .pm-off 隐藏, 各加载函数通过 PfModules.on(key) 跳过请求; 不删代码。
 * 2026-11-04 视觉轮复核后改为"读不到开关时保持隐藏" (fail-closed, 只限本页 8 个可选模块):
 *   这 8 个模块是因为口径误导 / 死入口 / 破坏性操作才关闭的, 开关读不到 (如本机未带令牌、接口异常) 时
 *   不应重新露出。页面上这些元素默认带 .pm-off, 只有接口明确返回 enabled !== false 才去掉。
 *   未列在 SELECTORS 里的模块 (持仓表、穿透等) 不受影响, 始终开启。
 *   后端配置文件缺失 / 损坏时仍按"全部开启"返回 (services/portfolio_modules.py 未改), 那是能读到的明确结果。
 */
(function (root) {
    'use strict';
    // 模块 key → 页面元素
    const SELECTORS = {
        sector_pie: ['#pf-sector-zone', '#pf-alerts-risk'],
        hero_sparkline: ['#pf-sparkline'],
        brinson: ['#pf-brinson-zone'],
        nav_sim: ['#pf-nav-zone'],
        factor: ['#pf-factor-zone'],
        slippage: ['#pf-slippage-zone'],
        trade_entry: ['#open-trade-btn', '#trade-modal'],
        reset_button: ['#reset-btn', '#reset-modal'],
    };
    let modules = null;      // null = 尚未读到或读取失败
    let failed = false;

    function on(key) {
        if (!modules) return !SELECTORS[key];            // 读到之前 / 读取失败: 可选模块一律视为关闭
        const m = modules[key];
        return !(m && m.enabled === false);
    }

    function apply() {
        const doc = root.document;
        Object.keys(SELECTORS).forEach(key => {
            const off = !on(key);
            SELECTORS[key].forEach(sel => doc.querySelectorAll(sel).forEach(el => {
                el.classList.toggle('pm-off', off);
                if (off) el.setAttribute('data-pm-off', key); else el.removeAttribute('data-pm-off');
            }));
        });
    }

    function init(fetchFn) {
        return fetchFn('/api/v1/portfolio/modules')
            .then(r => r.json())
            .then(d => {
                if (d && d.status === 'success' && d.modules && typeof d.modules === 'object') { modules = d.modules; failed = false; }
                else throw new Error((d && (d.detail || d.message || d.status)) || '响应无效');
            })
            .catch(e => {
                failed = true; modules = null;
                if (root.console) root.console.warn('[PM] 模块开关读取失败, 8 个可选模块保持隐藏:', e);
            })
            .then(() => {
                const doc = root.document;
                if (doc && doc.readyState === 'loading') doc.addEventListener('DOMContentLoaded', apply);
                else if (doc) apply();
            });
    }

    const ready = root.fetch ? init(root.fetch.bind(root)) : Promise.resolve();
    root.PfModules = { ready, on, apply, init, SELECTORS, failed: () => failed };
})(typeof window !== 'undefined' ? window : globalThis);
