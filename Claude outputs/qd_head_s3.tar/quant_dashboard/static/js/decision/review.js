/**
 * 2026-11-02 (C6) 复盘标签: 执行目标 vs 实际仓位 + 背景读数验证 (折叠) + 跳转组合页决策复盘
 * 数据: GET /api/v1/decision/exec-vs-actual (执行层前向记录 + 跟踪止盈日终快照), 只读、不计算新口径。
 */
(function () {
    'use strict';
    const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
    const fmt = v => (typeof v === 'number' && isFinite(v)) ? `${v.toFixed(1)}%` : '—';
    let _loadedAt = 0;

    function chartSvg(points) {
        const pts = points.filter(p => p.actual != null || p.target != null);
        if (pts.length < 2) return '<div class="rv-note">记录少于 2 个交易日, 暂不画线, 见下表。</div>';
        const W = 640, H = 180, L = 36, R = 12, T = 10, B = 26;
        const x = i => L + (W - L - R) * (pts.length === 1 ? 0 : i / (pts.length - 1));
        const y = v => T + (H - T - B) * (1 - v / 100);
        const grid = [0, 25, 50, 75, 100].map(v =>
            `<line class="rv-grid" x1="${L}" x2="${W - R}" y1="${y(v)}" y2="${y(v)}"/><text class="rv-axis" x="${L - 6}" y="${y(v) + 3}" text-anchor="end">${v}</text>`).join('');
        // 实际仓位: 折线; 执行目标: 阶梯线 (目标只在评估日/风险事件日变化)
        let actual = '', target = '';
        pts.forEach((p, i) => {
            if (p.actual != null) actual += `${actual ? 'L' : 'M'}${x(i).toFixed(1)},${y(p.actual).toFixed(1)}`;
            if (p.target != null) {
                const prev = i > 0 ? pts[i - 1].target : null;
                target += target ? `L${x(i).toFixed(1)},${y(prev != null ? prev : p.target).toFixed(1)}L${x(i).toFixed(1)},${y(p.target).toFixed(1)}`
                                 : `M${x(i).toFixed(1)},${y(p.target).toFixed(1)}`;
            }
        });
        const labels = pts.map((p, i) => (i === 0 || i === pts.length - 1 || pts.length <= 8)
            ? `<text class="rv-axis" x="${x(i)}" y="${H - 8}" text-anchor="middle">${esc(String(p.date).slice(5))}</text>` : '').join('');
        const dots = pts.map((p, i) => p.actual != null ? `<circle class="rv-dot" cx="${x(i)}" cy="${y(p.actual)}" r="2.5"/>` : '').join('');
        return `<svg class="rv-chart" viewBox="0 0 ${W} ${H}" role="img" aria-label="执行目标与实际仓位走势">
            ${grid}${labels}
            ${target ? `<path class="rv-target" d="${target}"/>` : ''}
            ${actual ? `<path class="rv-actual" d="${actual}"/>` : ''}${dots}
        </svg>
        <div class="rv-legend"><span class="rv-lg rv-lg-target">执行目标</span><span class="rv-lg rv-lg-actual">实际仓位</span></div>`;
    }

    function tableHtml(points) {
        const rows = points.slice().reverse().map(p => `<tr>
            <td>${esc(p.date)}</td><td>${fmt(p.target)}</td><td>${fmt(p.actual)}</td>
            <td>${p.gap == null ? '—' : `${p.gap > 0 ? '+' : ''}${p.gap.toFixed(1)}pp`}</td></tr>`).join('');
        return `<table class="rv-table"><thead><tr><th>日期</th><th>执行目标</th><th>实际仓位</th><th>偏离</th></tr></thead><tbody>${rows}</tbody></table>`;
    }

    function render(d) {
        const el = document.getElementById('review-exec-body');
        if (!el) return;
        if (!d || d.status !== 'success') { el.innerHTML = '<div class="rv-note">执行记录暂不可用</div>'; return; }
        const pts = d.points || [];
        const events = (d.events || []).map(e => `<li>${esc(e.date)} · ${esc(e.trigger === 'bootstrap' ? '执行层上线' : e.trigger === 'risk_event' ? '风险事件下调' : e.trigger || '评估')}
            → 目标 ${fmt(e.target)}${e.risk_events ? `（${esc(e.risk_events.replace('drawdown_brake', '回撤刹车'))}）` : ''}</li>`).join('');
        el.innerHTML = `${chartSvg(pts)}${pts.length ? tableHtml(pts) : '<div class="rv-note">暂无日终快照</div>'}
            ${events ? `<div class="rv-sub">执行目标变更记录</div><ul class="rv-events">${events}</ul>` : ''}
            <div class="rv-note">执行目标：${esc((d.sources || {}).target || '')}；执行层 ${esc(d.exec_since || '—')} 上线，之前的日期没有执行目标（不回填）。
            实际仓位：${esc((d.sources || {}).actual || '')}，与执行区"当前仓位"的分母口径相差约 0.1–0.3pp。</div>`;
    }

    async function loadReview(force) {
        if (!force && _loadedAt && Date.now() - _loadedAt < 300000) return;
        _loadedAt = Date.now();
        try {
            const d = await fetch('/api/v1/decision/exec-vs-actual?days=60', { signal: AbortSignal.timeout(15000) }).then(r => r.json());
            render(d);
        } catch (e) {
            render(null);
        }
        // 背景读数验证 (原风险矩阵中的准确率两块, 已移到本标签折叠区)
        try {
            if (typeof loadAccuracyDashboard === 'function') loadAccuracyDashboard();
            if (typeof AC !== 'undefined' && typeof renderAccuracy === 'function') {
                AC.secureFetch(`${API_BASE}/accuracy`).then(r => r.json()).then(a => { if (a.status === 'success') renderAccuracy(a); }).catch(() => {});
            }
        } catch (_) { /* 准确率不可用不影响复盘主体 */ }
    }

    window.Review = { loadReview, render, chartSvg, tableHtml };
})();
