/**
 * AlphaCore V21.2 · Hub 核心渲染模块
 * ====================================
 * - JCS 环形仪表盘 (Canvas)
 * - 矛盾矩阵渲染
 * - 方向指示器
 * - 情景模拟器卡片
 * - 执行建议卡片
 * - 警示卡片
 * - AIAE 宏观仓位管控仪表
 *
 * 依赖: _getChart, _fmt (from _infra.js)
 */
//  JCS 环形图 (Canvas)
// ═══════════════════════════════════════════════════

function _hubEscape(value) {
    return String(value ?? '').replace(/[&<>"']/g, c => ({'&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'}[c]));
}

// 日期统一 YYYY-MM-DD; 时间标明时区 (带时区的换算为北京时间; 不带时区的如实标注"未标时区")
function _fmtObsDate(value, zoneLabel) {
    if (value == null || value === '') return '未知';
    const text = String(value);
    const ymd = /^\d{8}$/.test(text) ? `${text.slice(0, 4)}-${text.slice(4, 6)}-${text.slice(6, 8)}` : text.slice(0, 10);
    return /^\d{4}-\d{2}-\d{2}$/.test(ymd) ? `${ymd}（${zoneLabel}日期）` : _hubEscape(text);
}

function _fmtDateTime(value) {
    if (value == null || value === '') return '未知';
    const text = String(value);
    const hasZone = /([zZ]|[+-]\d{2}:?\d{2})$/.test(text);
    if (!hasZone) {
        const m = text.match(/^(\d{4}-\d{2}-\d{2})[T ](\d{2}:\d{2})/);
        return m ? `${m[1]} ${m[2]}（未标时区）` : text;
    }
    const d = new Date(text);
    if (isNaN(d)) return text;
    const bj = new Date(d.getTime() + 8 * 3600 * 1000);
    const pad = n => String(n).padStart(2, '0');
    return `${bj.getUTCFullYear()}-${pad(bj.getUTCMonth() + 1)}-${pad(bj.getUTCDate())} ${pad(bj.getUTCHours())}:${pad(bj.getUTCMinutes())}（北京时间）`;
}

function drawJCSRing(score, level) {
    const canvas = document.getElementById('jcs-canvas');
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    const dpr = window.devicePixelRatio || 1;
    const size = 180;
    canvas.width = size * dpr;
    canvas.height = size * dpr;
    canvas.style.width = size + 'px';
    canvas.style.height = size + 'px';
    ctx.setTransform(1, 0, 0, 1, 0, 0);  // V19.3: 防止多次调用 scale 叠加
    ctx.scale(dpr, dpr);

    const cx = size / 2, cy = size / 2, r = 72, lw = 10;
    // 2026-11-01 (B): 环形图用中性色 (红/绿只表示看多/看空); 颜色取 CSS 变量
    const css = getComputedStyle(document.documentElement);
    const varOr = (name, fallback) => (css.getPropertyValue(name) || '').trim() || fallback;
    // 2026-11-03 (1b): 变量统一到 ac_tokens.css (--dc-ring-* / --dc-track)
    const RING = { high: '--dc-ring-high', medium: '--dc-ring-medium', low: '--dc-data-dim' };
    const color = varOr(RING[level] || RING.medium, varOr(RING.medium, '#94a3b8'));
    const track = varOr('--dc-track', 'rgba(148,163,184,0.12)');
    const targetPct = Math.min(score / 100, 1);
    const startAngle = -Math.PI / 2;
    const el = document.getElementById('jcs-value');
    const badge = document.getElementById('jcs-badge');
    if (badge) {
        badge.className = 'jcs-level-badge ' + level;
        const labels = { high: '清晰', medium: '一般', low: '模糊' };  // 宏观信号清晰度, 非强弱/多空, 非操作建议
        badge.textContent = labels[level] || level;
    }
    // A4: 缓动动画
    let current = 0;
    const duration = 800;
    const startTime = performance.now();
    // R5 P1-2: 取消旧动画防止多个 rAF 叠加
    if (drawJCSRing._rafId) cancelAnimationFrame(drawJCSRing._rafId);
    function animate(now) {
        const elapsed = now - startTime;
        const progress = Math.min(elapsed / duration, 1);
        const ease = 1 - Math.pow(1 - progress, 3); // easeOutCubic
        current = targetPct * ease;
        ctx.clearRect(0, 0, size, size);
        // 背景轨道
        ctx.beginPath(); ctx.arc(cx, cy, r, 0, 2 * Math.PI);
        ctx.strokeStyle = track; ctx.lineWidth = lw; ctx.stroke();
        // 进度弧
        const endAngle = startAngle + current * 2 * Math.PI;
        ctx.beginPath(); ctx.arc(cx, cy, r, startAngle, endAngle);
        ctx.strokeStyle = color; ctx.lineWidth = lw; ctx.lineCap = 'butt'; ctx.stroke();
        if (el) el.textContent = (score * ease).toFixed(1);
        if (progress < 1) drawJCSRing._rafId = requestAnimationFrame(animate);
        else drawJCSRing._rafId = null;
    }
    drawJCSRing._rafId = requestAnimationFrame(animate);
}

// ═══════════════════════════════════════════════════
//  矛盾矩阵渲染
// ═══════════════════════════════════════════════════

function renderConflicts(data) {
    const panel = document.getElementById('conflict-list');
    const summary = document.getElementById('conflict-summary');
    if (!panel || !summary) return;
    const cls = data.has_severe ? 'danger' : (data.conflict_count > 0 ? 'warn' : 'ok');
    summary.className = 'conflict-summary ' + cls;
    summary.textContent = data.matrix_summary;
    if (data.conflicts.length === 0) {
        // V20.0: 紧凑无矛盾状态 — 一行徽章替代4行列表
        // 摘要行已显示同一句话, 此处不再重复渲染
        panel.innerHTML = '';
        return;
    }
    panel.innerHTML = data.conflicts.map(c => `
        <div class="conflict-item">
            <div class="conflict-color-band ${c.severity}"></div>
            <div class="conflict-body">
                <div class="conflict-desc">${c.desc}</div>
                <div class="conflict-action">${c.action}</div>
            </div>
        </div>
    `).join('');
}

// ═══════════════════════════════════════════════════
//  方向指示器
// ═══════════════════════════════════════════════════

function renderDirections(directions, snapshot, engineMeta) {
    const grid = document.getElementById('direction-grid');
    if (!grid) return;

    // 宏观因子 (JCS V26.0); 权重以后端 engine_meta 为准, 这里只是降级默认值
    const engines = {
        aiae: { label: 'AIAE', weight: 41.9,
            val: snapshot ? snapshot.aiae_v1 : null,
            fmt: v => v != null ? Number(v).toFixed(1) + '%' : '--' },
        erp:  { label: 'ERP', weight: 29.0,
            val: snapshot ? snapshot.erp_val : null,
            score: snapshot ? snapshot.erp_score : null,
            fmt: v => v != null ? Number(v).toFixed(2) + '%' : '--' },
        vix:  { label: 'VIX', weight: 22.6,
            val: snapshot ? snapshot.vix_val : null,
            fmt: v => v != null ? Number(v).toFixed(1) : '--' },
        gold: { label: 'GOLD', weight: 6.5,
            val: snapshot ? snapshot.gold_signal : null,
            fmt: v => v != null ? (v > 0 ? '+' : '') + Number(v).toFixed(0) : '--' },
    };
    // 已移出 JCS 的读数: 只在网格下方注明, 不进网格
    const excludedFmt = {
        mr: { label: 'MR', fmt: v => v || '--' },
        bond: { label: 'BOND', fmt: v => v != null ? (v > 0 ? '+' : '') + Number(v).toFixed(0) : '--' },
    };
    const excludedVal = { mr: snapshot ? snapshot.mr_regime : null, bond: snapshot ? snapshot.bond_signal : null };

    if (engineMeta) {
        Object.entries(engineMeta).forEach(([key, meta]) => {
            if (engines[key] && meta.weight != null) engines[key].weight = meta.weight;
        });
    }

    const arrows = { '1': '▲', '-1': '▼', '0': '━' };
    const cls = { '1': 'up', '-1': 'down', '0': 'neutral' };
    // 环境描述, 不含操作语言
    const meanings = {
        aiae: { '1': '配置偏冷', '-1': '配置偏热', '0': '中性均衡' },
        erp:  { '1': '估值偏低', '-1': '估值偏高', '0': '估值中性' },
        vix:  { '1': '波动低迷', '-1': '恐慌较高', '0': '波动正常' },
        gold: { '1': '避险偏强', '-1': '风险偏好', '0': '中性' },
    };

    const keys = Object.keys(engines).filter(k => k in (directions || {}) || (engineMeta && engineMeta[k]));
    grid.innerHTML = keys.map(key => {
        const eng = engines[key];
        const state = engineMeta?.[key];
        const dir = (directions || {})[key];
        const unverified = state?.time_unverified === true;
        const hasData = state ? state.status === 'available' : eng.val != null;
        const known = hasData && !unverified;
        const dirStr = known ? String(state?.direction ?? dir) : 'unknown';
        const arrowCls = cls[dirStr] || 'unknown';
        const noDataCls = !known ? ' dir-no-data' : '';
        const meaningText = unverified ? '观测时间待核验 · 不计入'
            : hasData ? ((meanings[key] || {})[dirStr] || '') : '未知 · 不计入';

        let tooltipHtml = '';
        if (key === 'erp' && eng.score != null && known) {
            const scoreTier = eng.score > 55 ? '偏低 ▲' : (eng.score < 35 ? '偏高 ▼' : '中性 ━');
            tooltipHtml = `<div class="dir-tooltip" role="tooltip" id="erp-direction-tooltip">
                <div class="dir-tooltip-title">ERP 判定链路</div>
                <div class="dir-tooltip-row">原始值: ${eng.fmt(eng.val)}</div>
                <div class="dir-tooltip-row">→ 归一化评分: <strong>${Number(eng.score).toFixed(0)}</strong>分</div>
                <div class="dir-tooltip-row">→ 估值判定: <strong>${scoreTier}</strong></div>
                <div class="dir-tooltip-rule">&gt;55分=估值偏低 · 35-55=中性 · &lt;35=估值偏高</div>
            </div>`;
        }
        const weightText = unverified || !hasData ? `${Number(eng.weight).toFixed(1)}% 未计入` : `${Number(eng.weight).toFixed(1)}%`;

        return `
        <div class="direction-item dir-${arrowCls}${noDataCls}"${key === 'erp' && tooltipHtml ? ' tabindex="0" aria-describedby="erp-direction-tooltip"' : ''}>
            <div class="dir-header">
                <span class="direction-label">${eng.label}</span>
                <span class="dir-weight">${weightText}</span>
            </div>
            <div class="dir-center">
                <div class="direction-arrow ${arrowCls}">${arrows[dirStr] || '?'}</div>
                <div class="dir-realval">${hasData ? _hubEscape(eng.fmt(eng.val)) : '--'}${tooltipHtml}</div>
            </div>
            <div class="direction-meaning">${meaningText}</div>
        </div>`;
    }).join('');

    const excludedNote = document.getElementById('direction-excluded');
    if (excludedNote) {
        const parts = Object.entries(excludedFmt)
            .filter(([key]) => !engineMeta || engineMeta[key]?.excluded)
            .map(([key, e]) => `${e.label} ${_hubEscape(e.fmt(excludedVal[key]))}`);
        excludedNote.textContent = parts.length
            ? `未计入 JCS：${parts.join(' · ')}（MR 为策略信号，见策略执行总览；BOND 仅作背景）` : '';
    }
    grid.onkeydown = event => {
        if (event.key === 'Escape') event.target.closest?.('.direction-item')?.classList.add('tooltip-dismissed');
    };
    grid.onfocusout = event => event.target.closest?.('.direction-item')?.classList.remove('tooltip-dismissed');
    grid.onpointerout = event => {
        const card = event.target.closest?.('.direction-item');
        if (card && !card.contains(event.relatedTarget)) card.classList.remove('tooltip-dismissed');
    };
}


// ═══════════════════════════════════════════════════
//  情景模拟器
// ═══════════════════════════════════════════════════

let currentScenarios = {};

function renderScenarioCards(scenarios) {
    currentScenarios = scenarios;
    const grid = document.getElementById('scenario-grid');
    if (!grid) return;

    grid.innerHTML = Object.entries(scenarios).map(([id, s]) => `
        <div class="scenario-card sev-${s.severity}" data-id="${id}" onclick="runSimulation('${id}')">
            <div class="scenario-icon">${s.icon}</div>
            <div class="scenario-name">${s.name}</div>
            <div class="scenario-desc">${s.desc}</div>
            <span class="scenario-badge ${s.severity}">${s.severity === 'extreme' ? '极端' : (s.severity === 'positive' ? '积极' : '高影响')}</span>
        </div>
    `).join('');
}

// ═══════════════════════════════════════════════════
//  V20.0: 内联执行指令渲染 (合并至决策面板)
// ═══════════════════════════════════════════════════

function renderActionPlan(plan) {
    const el = document.getElementById('action-inline');
    if (!el || !plan) return;
    // 2026-11-02 (1a): 今日结论读同一份 action_plan (不另请求)
    try { window.dispatchEvent(new CustomEvent('ac:action-plan', { detail: plan })); } catch (_) { /* 无事件环境 (测试沙箱) */ }
    // 2026-11-01: 执行区只显示 AIAE 执行目标 (唯一仓位数字) 与风控结论; 不显示 JCS 分数/等级
    el.classList.remove('initially-hidden');
    el.style.display = 'block';
    if (el.dataset) el.dataset.state = plan.state || 'unknown';

    const iconEl = document.getElementById('action-icon');
    const labelEl = document.getElementById('action-label');
    const confEl = document.getElementById('action-confidence');
    const reasonEl = document.getElementById('action-reasoning');
    const nextEl = document.getElementById('action-next-val');
    const posEl = document.getElementById('action-pos-val');
    const riskEl = document.getElementById('action-risk');

    if (iconEl) iconEl.textContent = '';
    if (labelEl) labelEl.textContent = plan.action_label || '--';
    if (confEl) {
        const zone = plan.execution_zone_label;
        confEl.textContent = `${zone ? '执行分区：' + zone + ' · ' : ''}无下单权限`;
    }
    if (reasonEl) reasonEl.textContent = plan.reasoning || '';
    if (nextEl) nextEl.textContent = plan.next_check || '--';
    if (posEl) {
        const target = plan.execution_target;
        const current = plan.current_position;
        if (Number.isFinite(target)) {
            const binding = (plan.constraints || []).find(c => c.binding);
            const gap = Number.isFinite(current) ? current - target : null;
            const gapText = gap == null ? '' : `（当前 ${Number(current).toFixed(1)}%，${gap >= 0 ? '高于' : '低于'}目标 ${Math.abs(gap).toFixed(1)}pp）`;
            posEl.textContent = `${Number(target).toFixed(1)}%${gapText}`;
            posEl.title = (binding ? `最严约束：${binding.label}。` : '')
                + (plan.constraints || []).map(c => `${c.label} ${c.value}%${c.binding ? '（生效）' : ''}`).join('；');
        } else {
            posEl.textContent = '执行目标不可用 · 暂停';
            posEl.title = '';
        }
    }
    const bindingEl = document.getElementById('action-binding');
    if (bindingEl) {
        const binding = (plan.constraints || []).find(c => c.binding);
        bindingEl.textContent = binding ? `由「${binding.label}」决定（最严约束）` : '';
    }
    if (riskEl) {
        const detail = Array.isArray(plan.risk_detail) ? plan.risk_detail : (plan.risk_note ? [plan.risk_note] : []);
        riskEl.textContent = detail.join('；');
        riskEl.style.display = detail.length ? '' : 'none';
    }
}

// ═══════════════════════════════════════════════════
//  V17.3 I: 警示卡片渲染
// ═══════════════════════════════════════════════════

function renderAlerts(alerts) {
    const container = document.getElementById('alert-container');
    if (!container) return;
    if (!alerts || alerts.length === 0) {
        container.innerHTML = '';
        return;
    }
    // 2026-11-03 (1b): 不渲染接口给的 emoji 图标; 级别用文字标签 (颜色只作辅助)
    const SEV = { critical: ['ac-tag-block', '严重'], warning: ['ac-tag-warn', '警告'], caution: ['ac-tag-info', '注意'] };
    container.innerHTML = alerts.map(a => `
        <div class="alert-card alert-${a.severity}">
            <div class="alert-header">
                <span class="ac-tag ${(SEV[a.severity] || SEV.caution)[0]}">${(SEV[a.severity] || SEV.caution)[1]}</span>
                <span class="alert-title">${a.title}</span>
            </div>
            <div class="alert-detail">${a.detail}</div>
            <span class="alert-rule">${a.rule}</span>
        </div>
    `).join('');
}

// ═══════════════════════════════════════════════════
//  AIAE 配置热度 · 背景 (2026-11-03 1c: 中性 R1–R5 档位条, 不作执行依据)
//  方案 docs/DECISION_HUB_VISUAL_1B_1C_PLAN.md 第 11 节:
//  - 不显示每档"仓位 x%" (执行目标是全站唯一仓位数字);
//  - 缺数据显示 "--", 不用默认数字顶替 (原 档位 3 / AIAE 22 / 上限 55 / 融资热度 2.0 / 基金仓位 80 / 默认阈值);
//  - 不用红绿 (档位不是涨跌), 超警戒线用警告色 (背景读数不用阻断色)。
// ═══════════════════════════════════════════════════

const _AIAE_TIERS = [
    { r: 1, cn: '极低估值' },
    { r: 2, cn: '低估区' },
    { r: 3, cn: '中性均衡' },
    { r: 4, cn: '偏高区域' },
    { r: 5, cn: '极度过热' },
];

// 数字或 null (null / undefined / '' / NaN 一律视为缺失; 注意 Number(null) === 0)
function _aiaeNum(v) {
    if (v === null || v === undefined || v === '') return null;
    const n = Number(v);
    return Number.isFinite(n) ? n : null;
}

// 档位区间: 只用后端给的 4 个阈值; 缺失时不显示区间 (不用默认阈值)
function _aiaeTierRange(i, t) {
    if (!Array.isArray(t) || t.length < 4 || t.some(x => _aiaeNum(x) === null)) return '';
    const f = x => Number(x).toFixed(2).replace(/\.?0+$/, '');
    return i === 0 ? `<${f(t[0])}%` : i === 4 ? `>${f(t[3])}%` : `${f(t[i - 1])}–${f(t[i])}%`;
}

function _aiaeTierBarHtml(regime, thresholds) {
    return _AIAE_TIERS.map((d, i) => {
        const active = regime === d.r;
        const range = _aiaeTierRange(i, thresholds);
        return `<div class="aiae-tier${active ? ' is-active' : ''}"${active ? ' aria-current="true"' : ''}>`
            + `<span class="aiae-tier-name">R${d.r} ${d.cn}</span>`
            + (range ? `<span class="aiae-tier-range">${_hubEscape(range)}</span>` : '')
            + `</div>`;
    }).join('');
}

const _FUND_SOURCE_LABEL = { ths_api: '同花顺', lg_api: '乐咕（备）', manual_update: '手动录入', initial_seed: '种子值' };

function _aiaeWarnRowsHtml(snapshot) {
    const s = snapshot || {};
    const margin = _aiaeNum(s.margin_heat);
    const slope = _aiaeNum(s.aiae_slope);
    const fund = _aiaeNum(s.fund_position);
    const fpDate = s.fund_position_date ? String(s.fund_position_date) : '';
    const fpSrc = _FUND_SOURCE_LABEL[s.fund_position_source] || '';
    const fpAsof = [fpSrc, fpDate ? `截至 ${fpDate}` : ''].filter(Boolean).join(' · ');
    // 融资热度来源与日期 (融资余额 / 总市值): 引擎降级用缺省值时后端给 null 并标 margin_heat_fallback
    const mhRaw = s.margin_heat_date ? String(s.margin_heat_date) : '';
    const mhDate = /^\d{8}$/.test(mhRaw) ? `${mhRaw.slice(0, 4)}-${mhRaw.slice(4, 6)}-${mhRaw.slice(6)}` : mhRaw;
    const mhAsof = s.margin_heat_fallback ? '数据源降级，不显示缺省值'
        : (margin === null ? '' : ['Tushare 融资余额 / 总市值', mhDate ? `截至 ${mhDate}` : ''].filter(Boolean).join(' · '));
    const rows = [
        { label: '融资热度', asof: mhAsof, val: margin, text: v => v.toFixed(2) + '%',
          warn: v => v >= 3.5, pct: v => v / 5 * 100, th: '警戒线 ≥3.5%' },
        { label: '月环比斜率', asof: '', val: slope, text: v => (v > 0 ? '+' : '') + v.toFixed(2),
          warn: v => Math.abs(v) >= 1.5, pct: v => Math.abs(v) / 3 * 100, th: '警戒线 |±1.5|' },
        { label: '基金仓位', asof: fpAsof, val: fund, text: v => v.toFixed(2) + '%',
          warn: v => v >= 90, pct: v => v, th: '警戒线 ≥90%' },
    ];
    return rows.map(r => {
        const missing = r.val === null;
        const warn = !missing && r.warn(r.val);
        const pct = missing ? 0 : Math.max(0, Math.min(100, r.pct(r.val)));
        const tag = missing ? '<span class="ac-tag ac-tag-info">数据缺失</span>'
            : warn ? '<span class="ac-tag ac-tag-warn">超警戒线</span>'
            : '<span class="ac-tag ac-tag-info">正常</span>';
        return `<div class="aiae-hub-warn-item${warn ? ' is-warn' : ''}${missing ? ' is-missing' : ''}">`
            + `<div class="aiae-hub-warn-label">${r.label}${r.asof ? `<span class="ac-asof">${_hubEscape(r.asof)}</span>` : ''}</div>`
            + `<div class="aiae-hub-warn-val">${missing ? '--' : _hubEscape(r.text(r.val))}</div>`
            + `<div class="aiae-hub-warn-bar">${missing ? '' : `<div class="aiae-hub-warn-bar-fill" style="width:${pct.toFixed(1)}%"></div>`}</div>`
            + `<div class="aiae-hub-warn-status">${tag}<span class="aiae-hub-warn-th">${r.th}</span></div>`
            + `</div>`;
    }).join('');
}

function _aiaeReadoutText(snapshot) {
    const s = snapshot || {};
    const regime = _aiaeNum(s.aiae_regime);
    const tier = _AIAE_TIERS.find(d => d.r === regime);
    const val = _aiaeNum(s.regime_basis_value) ?? _aiaeNum(s.aiae_v1);
    const valText = val === null ? '--' : `${val.toFixed(1)}%`;
    const tierText = tier ? `R${tier.r} ${s.aiae_regime_cn || tier.cn}` : '档位不可用';
    return `AIAE 读数 ${valText}（权益配置热度，非仓位）· ${tierText}`;
}

function renderAIAEHub(snapshot) {
    const panel = document.getElementById('aiae-hub-panel');
    if (!panel) return;
    const s = snapshot || {};
    const regime = _aiaeNum(s.aiae_regime);

    // 数据质量 (缺失按 0 处理: 失败即锁定, 与后端 fail-closed 一致)
    const dqs = _aiaeNum(s.data_quality_score) ?? 0;
    const locked = s.decision_locked !== false;

    panel.classList.remove('initially-hidden');

    let dqEl = document.getElementById('aiae-hub-dq-bar');
    if (!dqEl) {
        dqEl = document.createElement('div');
        dqEl.id = 'aiae-hub-dq-bar';
        panel.insertBefore(dqEl, panel.firstChild);
    }
    const dqWarn = dqs < 80;
    const dqLabel = dqs >= 80 ? '数据充足' : dqs >= 50 ? '部分降级' : '严重降级';
    dqEl.className = 'aiae-dq';
    dqEl.innerHTML = `<span class="aiae-dq-label">数据质量</span>`
        + `<div class="aiae-dq-track"><div class="aiae-dq-fill${dqWarn ? ' is-warn' : ''}" style="width:${Math.max(0, Math.min(100, dqs))}%"></div></div>`
        + `<span class="aiae-dq-val${dqWarn ? ' is-warn' : ''}">${dqs}/100 · ${dqLabel}</span>`;

    let lockEl = document.getElementById('aiae-hub-lock-banner');
    if (!lockEl) {
        lockEl = document.createElement('div');
        lockEl.id = 'aiae-hub-lock-banner';
        panel.insertBefore(lockEl, dqEl.nextSibling);
    }
    if (locked) {
        lockEl.className = 'ac-state-partial aiae-lock';
        lockEl.textContent = 'AIAE 数据质量不足，读数仅供参考';
        lockEl.hidden = false;
    } else {
        lockEl.hidden = true;
    }

    const regimeEl = document.getElementById('aiae-hub-regime');
    if (regimeEl) regimeEl.textContent = _aiaeReadoutText(s);

    const slopeEl = document.getElementById('aiae-hub-slope');
    if (slopeEl) {
        const slope = _aiaeNum(s.aiae_slope);
        const dir = s.aiae_slope_dir;
        const arrow = (dir === 'rising' || dir === 'up') ? '↗' : (dir === 'falling' || dir === 'down') ? '↘' : '→';
        slopeEl.textContent = slope === null ? '月环比斜率 --' : `月环比斜率 ${arrow} ${slope > 0 ? '+' : ''}${slope.toFixed(2)}`;
        slopeEl.classList.toggle('is-warn', slope !== null && Math.abs(slope) >= 1.5);
    }

    const strip = document.getElementById('aiae-hub-regime-strip');
    // 档位区间只用后端下发的阈值 (snapshot.regime_thresholds); 缺失时不显示区间
    if (strip) strip.innerHTML = _aiaeTierBarHtml(regime, snapshot ? snapshot.regime_thresholds : null);

    const warns = document.getElementById('aiae-hub-warnings');
    if (warns) warns.innerHTML = _aiaeWarnRowsHtml(s);
}


// ═══════════════════════════════════════════════════
//  V22.0: 信号时效衰减指示器
//  放射性衰变模型: reliability = 0.5^(age / half_life)
// ═══════════════════════════════════════════════════

function renderSignalDecay(decay) {
    const bars = document.getElementById('signal-decay-bars');
    const panel = document.getElementById('signal-decay');
    if (!bars || !decay) return;
    if (panel) panel.style.display = 'block';

    const engines = ['aiae', 'erp', 'vix'];  // 2026-11-01: 只列 JCS 宏观因子 (MR 已移出 JCS)
    // 新鲜度不是涨跌语义: 用中性色阶 (CSS 变量), 不用红/绿
    const tier = (rel) => rel >= 0.85 ? 'fresh' : rel >= 0.60 ? 'ok' : rel >= 0.30 ? 'aging' : 'stale';
    const tierLabel = { fresh: '新', ok: '可用', aging: '衰减', stale: '陈旧' };

    bars.innerHTML = engines.map(key => {
        const d = decay[key];
        if (!d) return '';
        const rel = d.reliability;
        const known = Number.isFinite(rel);
        const pct = known ? Math.round(Math.max(0, Math.min(100, rel * 100))) : 0;
        const t = known ? tier(rel) : 'unknown';
        const label = known ? tierLabel[t] : '待核验';
        const ageStr = d.precision === 'trading_day' && Number.isFinite(d.age_trading_days)
            ? `T-${d.age_trading_days}`
            : d.age_min >= 0
            ? (d.age_min < 60 ? d.age_min + 'm' : (d.age_min / 60).toFixed(0) + 'h')
            : '—';
        const zone = ['vix', 'gold', 'bond'].includes(key) ? '纽约' : '北京';
        const precisionNote = d.precision === 'trading_day'
            ? `按错过的收盘次数计龄 (工作日近似, 未扣节假日)；日历日 ${d.age_calendar_days ?? '?'} 天`
            : '日期精度不表示盘中新鲜度';
        const tip = `观测: ${_fmtObsDate(d.observed_at, zone)}；接收: ${_fmtDateTime(d.received_at)}；半衰期: ${d.half_life_hours}小时；${precisionNote}`;
        return `
        <div class="sd-bar-row sd-${t}">
            <span class="sd-bar-engine">${_hubEscape(d.label)}</span>
            <div class="sd-bar-track"><div class="sd-bar-fill" style="width:${pct}%"></div></div>
            <span class="sd-bar-age" title="${_hubEscape(tip)}">${ageStr}</span>
            <span class="sd-bar-badge">${label}</span>
        </div>`;
    }).join('');

    // 更新脚注
    let noteEl = document.getElementById('signal-decay-note');
    if (!noteEl) {
        noteEl = document.createElement('div');
        noteEl.id = 'signal-decay-note';
        noteEl.className = 'sd-footnote';
        bars.parentElement.appendChild(noteEl);
    }
    noteEl.textContent = '时效折扣 = 0.5^(观测年龄/半衰期)，日频数据按错过的交易日计龄 (T-n)；仅为启发式折扣，不代表准确率；观测时间未知时不显示新鲜度。';
    noteEl.classList.add('jcs-fold-note');
}

// ═══════════════════════════════════════════════════
//  V22.0: 仓位调整路径渲染
// ═══════════════════════════════════════════════════

async function fetchPositionPath() {
    // 2026-11-02 (C5): 状态已并入执行区; 模块关闭时不请求 /position-path
    if (window.DM && !window.DM.on('position_path')) return;
    const card = document.getElementById('position-path-card');
    const body = document.getElementById('pp-body');
    if (!card || !body) return;

    card.classList.remove('initially-hidden');
    body.innerHTML = '<div class="loading-spinner">⏳ 生成执行路径...</div>';

    try {
        const data = await _safeFetch(`${API_BASE}/position-path`);
        if (data.status === 'success') {
            renderPositionPath(data);
        } else {
            body.innerHTML = `<div class="pp-empty">⚠️ ${data.error || '路径生成失败'}</div>`;
        }
    } catch (e) {
        body.innerHTML = '<div class="pp-empty">⚠️ 网络异常，请点击「刷新决策数据」重试</div>';
    }
}

function renderPositionPath(data) {
    const body = document.getElementById('pp-body');
    const badge = document.getElementById('pp-gap-badge');
    const footer = document.getElementById('pp-footer');
    if (!body) return;
    if (data.permissions?.create_order === false) {
        if (badge) { badge.textContent = '未批准'; badge.title = '未生成执行目标'; }
        body.innerHTML = `<div class="pp-warnings">${(data.warnings || []).map(w => `<div class="pp-warn-item">${_hubEscape(w)}</div>`).join('')}</div>`;
        if (footer) footer.textContent = '研究与风险复核，不生成订单或分批执行路径';
        return;
    }

    // Gap badge
    if (badge) {
        const dirIcon = data.direction === 'increase' ? '▲' : (data.direction === 'decrease' ? '▼' : '━');
        const dirColor = data.direction === 'increase' ? '#34d399' : (data.direction === 'decrease' ? '#f87171' : '#94a3b8');
        const gapSign = data.gap > 0 ? '+' : '';
        badge.innerHTML = `${dirIcon} <span style="color:${dirColor}">${gapSign}${data.gap}%</span>`;
        badge.title = `当前 ${data.current_cap}% → 目标 ${data.target_cap}%`;
    }

    // Warnings
    let warnHtml = '';
    if (data.warnings && data.warnings.length > 0) {
        warnHtml = `<div class="pp-warnings">${data.warnings.map(w => `<div class="pp-warn-item">${w}</div>`).join('')}</div>`;
    }

    // Data source indicator
    const srcLabel = data.data_source === 'portfolio' ? '🟢 基于实际持仓' : '🟡 基于策略信号';

    // V24.0: Progress tracker bar with delta annotations
    const stepColors    = ['#a78bfa', '#3b82f6', '#34d399'];
    const stepColorRGBs = ['167,139,250', '59,130,246', '52,211,153'];
    const stepIcons     = ['🚀', '⚙️', '🎯'];
    const allCaps = [data.current_cap, ...data.steps.map(s => s.step_cap)];
    const progressNodes = [
        { label: '当前', cap: data.current_cap, color: '#94a3b8', delta: null },
        ...data.steps.map((s, i) => ({
            label: s.day, cap: s.step_cap, color: stepColors[i],
            delta: round1(allCaps[i + 1] - allCaps[i]),
        })),
    ];
    function round1(v) { return Math.round(v * 10) / 10; }

    const progressHtml = `<div class="pp-progress-track">${progressNodes.map((n, i) => {
        const deltaHtml = n.delta !== null
            ? `<span class="pp-progress-delta" style="color:${n.delta > 0 ? '#34d399' : '#f87171'}">${n.delta > 0 ? '+' : ''}${n.delta}%</span>`
            : '';
        const dot = `<div class="pp-progress-node">
            <div class="pp-progress-dot" style="background:${n.color}; --node-color:${n.color}">${i === 0 ? '◉' : i}</div>
            <span class="pp-progress-label">${n.label}</span>
            <span class="pp-progress-cap" style="color:${n.color}">${n.cap}%</span>
            ${deltaHtml}
        </div>`;
        const line = i < progressNodes.length - 1
            ? `<div class="pp-progress-line" style="--line-from:${n.color}; --line-to:${progressNodes[i+1].color}"></div>`
            : '';
        return dot + line;
    }).join('')}</div>`;

    // Steps
    const stepsHtml = data.steps.map((step, i) => {
        const hasActions = step.actions && step.actions.length > 0;
        const stepDelta = hasActions ? step.actions.reduce((s, a) => s + a.delta, 0) : 0;
        const deltaSign = stepDelta > 0 ? '+' : '';
        const deltaColor = stepDelta > 0 ? '#34d399' : '#f87171';

        const actionRows = hasActions ? step.actions.map(a => {
            const dirIcon = a.action === 'reduce' ? '🔻' : (a.action === 'increase' ? '🔺' : '━');
            const dirCls  = a.action === 'reduce' ? 'pp-action-reduce' : (a.action === 'increase' ? 'pp-action-increase' : '');
            const adSign  = a.delta > 0 ? '+' : '';
            const adColor = a.delta > 0 ? '#34d399' : '#f87171';
            const reason  = a.reason || '';
            const isPriority = /止盈|止损|超配|亏/.test(reason);
            const priCls = isPriority ? ' priority-high' : '';
            let reasonCls = '';
            if (/止盈|浮盈/.test(reason)) reasonCls = ' reason-profit';
            else if (/止损|浮亏|亏/.test(reason)) reasonCls = ' reason-loss';
            else if (/超配/.test(reason)) reasonCls = ' reason-overweight';

            return `
            <div class="pp-action-row ${dirCls}${priCls}">
                <span class="pp-action-icon">${isPriority ? '⚡' : dirIcon}</span>
                <span class="pp-action-name">${a.name}<span class="pp-action-code">${a.code}</span></span>
                <span class="pp-action-weights">${a.current_weight}% → ${a.target_weight}%</span>
                <span class="pp-action-delta" style="color:${adColor}">${adSign}${a.delta}%</span>
                <span class="pp-action-reason${reasonCls}">${reason}</span>
                ${a.execution_cost ? `
                <span class="pp-action-cost" title="冲击成本: ${a.execution_cost.impact_cost_pct}% · ${a.execution_cost.liquidity_grade}">
                    ~${a.execution_cost.impact_cost_value.toFixed(0)}元
                </span>` : '<span class="pp-action-cost"></span>'}
            </div>`;
        }).join('') : '<div class="pp-action-row pp-no-action">━ 此步骤无需操作</div>';

        // P3: Step summary
        const summaryHtml = hasActions ? `
            <span class="pp-step-summary">
                <span class="count">${step.actions.length}项</span>
                <span class="total-delta" style="color:${deltaColor}">${deltaSign}${stepDelta.toFixed(1)}%</span>
            </span>` : '';

        // P7: Collapsed summary — top 3 actions
        let collapsedHtml = '';
        if (hasActions) {
            const sorted = [...step.actions].sort((a, b) => Math.abs(b.delta) - Math.abs(a.delta));
            const top3 = sorted.slice(0, 3).map(a =>
                `<span class="pp-collapsed-tag">${a.name} ${a.delta > 0 ? '+' : ''}${a.delta}%</span>`
            ).join('');
            const more = sorted.length > 3 ? `<span class="pp-collapsed-more"> +${sorted.length - 3}项</span>` : '';
            collapsedHtml = `<div class="pp-step-collapsed-summary">${top3}${more}</div>`;
        }

        // P4: Connector with time span
        let connectorHtml = '';
        if (i < data.steps.length - 1) {
            const nextStep = data.steps[i + 1];
            const dayDiff = (nextStep.interval_days || 0) - (step.interval_days || 0);
            connectorHtml = `<div class="pp-step-connector" style="--conn-from:${stepColors[i]}; --conn-to:${stepColors[i+1]}">
                <span class="pp-conn-label">
                    <span class="pp-conn-arrow">↓</span>
                    <span class="pp-conn-days">+${dayDiff}日</span>
                </span>
            </div>`;
        }

        return `
        <div class="pp-step" style="--step-color: ${stepColors[i]}; --step-color-rgb: ${stepColorRGBs[i]}" data-step="${i}">
            <div class="pp-step-header" onclick="this.parentElement.classList.toggle('collapsed')">
                <div class="pp-step-hdr-left">
                    <span class="pp-step-icon">${stepIcons[i]}</span>
                    <span class="pp-step-day">${step.day}</span>
                    <span class="pp-step-note">${step.note}</span>
                </div>
                <div class="pp-step-hdr-right">
                    ${summaryHtml}
                    <span class="pp-step-cap" style="color:${stepColors[i]}">→ ${step.step_cap}%</span>
                    <span class="pp-step-toggle">▼</span>
                </div>
            </div>
            <div class="pp-step-actions">${actionRows}</div>
            ${collapsedHtml}
        </div>${connectorHtml}`;
    }).join('');

    body.innerHTML = `${warnHtml}${progressHtml}<div class="pp-steps">${stepsHtml}</div>`;

    if (footer) {
        footer.innerHTML = `<span class="pp-src">${srcLabel}</span><span class="pp-disclaimer">以上为系统生成建议，不构成投资指令</span>`;
    }
}

// ═══════════════════════════════════════════════════
//  V26.0: 跨页持仓变更监听 — 自动刷新调仓路径
//  当 portfolio 页发生 import/trade/reset 时,
//  BroadcastChannel 通知决策页实时更新路径卡片。
// ═══════════════════════════════════════════════════

(function _initPortfolioChangeListener() {
    const _actionLabels = { import: '📥 持仓导入', trade: '📊 交易执行', reset: '🗑️ 组合清零' };

    function _onPortfolioChanged(action) {
        console.info('[Decision] 检测到持仓变更 (%s), 刷新调仓路径', action);
        // 闪烁路径卡片边框 (视觉反馈)
        const card = document.getElementById('position-path-card');
        if (card) {
            card.style.transition = 'box-shadow 0.3s ease';
            card.style.boxShadow = '0 0 12px rgba(99, 102, 241, 0.5)';
            setTimeout(() => { card.style.boxShadow = ''; }, 2000);
        }
        // 重新获取路径数据
        fetchPositionPath();
    }

    try {
        const bc = new BroadcastChannel('alphacore_portfolio');
        bc.onmessage = (evt) => {
            if (evt.data?.type === 'portfolio_updated') {
                _onPortfolioChanged(evt.data.action || 'unknown');
            }
        };
    } catch(e) {
        // 降级: localStorage storage 事件 (跨 Tab)
        window.addEventListener('storage', (evt) => {
            if (evt.key === '_ac_portfolio_ts') {
                _onPortfolioChanged('storage_fallback');
            }
        });
    }
})();

// ═══════════════════════════════════════════════════
//  P4: AI 叙事分析面板
// ═══════════════════════════════════════════════════

async function loadNarrative() {
    const body = document.getElementById('narrative-body');
    if (!body) return;
    console.info('[Narrative] 加载叙事报告...');

    try {
        const data = await _safeFetch(`${API_BASE}/narrative`);
        console.info('[Narrative] API 响应:', data.status, data.provider || 'N/A');
        if (data.status === 'success' && data.report) {
            renderNarrative(data);
        } else {
            body.innerHTML = `<div style="text-align:center;padding:20px;color:#64748b;font-size:0.82rem;">
                ${data.message || '叙事报告暂不可用'} · 点击「重新生成」手动触发
            </div>`;
        }
    } catch (e) {
        console.error('[Narrative] 加载失败:', e);
        body.innerHTML = '<div style="text-align:center;padding:20px;color:#64748b;font-size:0.82rem;">⚠️ 网络异常</div>';
    }
}

function renderNarrative(data) {
    const body = document.getElementById('narrative-body');
    const provEl = document.getElementById('narrative-provider');
    const timeEl = document.getElementById('narrative-time');
    const summaryEl = document.getElementById('narrative-summary');
    if (!body) return;

    // ── V2.0: 段落语义映射 (图标 + 色温) ──
    const _sectionMeta = {
        '市场温度': { icon: '🌡️', color: '#3b82f6', rgb: '59,130,246' },
        '行业轮动': { icon: '🏭', color: '#a78bfa', rgb: '167,139,250' },
        '策略信号': { icon: '🎯', color: '#34d399', rgb: '52,211,153' },
        '风险提示': { icon: '🛡️', color: '#f87171', rgb: '248,113,113' },
        '操作建议': { icon: '💡', color: '#fbbf24', rgb: '251,191,36' },
    };

    // Provider badge
    if (provEl) {
        const provLabels = {
            deepseek: 'DeepSeek', gemini: 'Gemini',
            openai: 'GPT-4o', claude: 'Claude',
            deterministic: '确定性引擎'
        };
        provEl.textContent = provLabels[data.provider] || data.provider;
        provEl.className = 'narrative-provider-badge provider-' + data.provider;
    }

    // Time
    if (timeEl && data.generated_at) {
        const dt = new Date(data.generated_at);
        timeEl.textContent = dt.toLocaleTimeString('zh-CN', {hour: '2-digit', minute: '2-digit'}) + ' 生成';
    }

    // Summary (折叠时显示)
    if (summaryEl) {
        const srcLabel = data.provider === 'deterministic' ? '规则引擎' : 'DeepSeek LLM';
        summaryEl.textContent = `${srcLabel} · ${data.snapshot_date}`;
    }

    // ── 数据高亮: 将数字+单位自动标记为金色等宽体 ──
    function _highlightMetrics(text) {
        // 匹配: JCS 75.7, R3, 53%, 22.3%, +0.64, -4.27%, VIX 18.5, 3.2%
        return text
            .replace(/(\b\d+\.?\d*\s*%)/g, '<span class="nar-metric">$1</span>')
            .replace(/(R[1-5])/g, '<span class="nar-metric">$1</span>')
            .replace(/(JCS\s*\d+\.?\d*)/gi, '<span class="nar-metric nar-metric-key">$1</span>')
            .replace(/(VIX\s*\d+\.?\d*)/gi, '<span class="nar-metric nar-metric-key">$1</span>')
            .replace(/(ERP\s*\d+\.?\d*%?)/gi, '<span class="nar-metric nar-metric-key">$1</span>');
    }

    // Report body — parse sections by 【】markers
    const report = data.report || '';
    const sectionRegex = /【(.+?)】/g;
    const parts = report.split(sectionRegex);

    if (parts.length > 1) {
        // Has section markers — render as institutional cards
        let html = '';
        let sectionIdx = 0;
        for (let i = 1; i < parts.length; i += 2) {
            const title = parts[i];
            const text = (parts[i + 1] || '').trim();
            const meta = _sectionMeta[title] || { icon: '📋', color: '#94a3b8', rgb: '148,163,184' };
            const highlighted = _highlightMetrics(text);
            html += `
            <div class="narrative-section" style="--nar-color:${meta.color};--nar-rgb:${meta.rgb}" data-section="${sectionIdx++}">
                <div class="nar-section-header">
                    <span class="nar-section-icon">${meta.icon}</span>
                    <span class="nar-section-tag" style="color:${meta.color};border-color:rgba(${meta.rgb},0.3);background:rgba(${meta.rgb},0.08)">${title}</span>
                </div>
                <div class="nar-section-content">${highlighted}</div>
            </div>`;
        }
        body.innerHTML = html;
    } else {
        // Plain text fallback
        body.textContent = report;
    }
    console.info('[Narrative] 渲染完成 (%d 段)', Math.floor(parts.length / 2));
}

// 默认不外联: 只有显式传入 useAI=true (「AI 生成 · 外联」按钮) 才允许后端调用外部 LLM
async function generateNarrative(useAI = false) {
    const btn = document.getElementById(useAI ? 'btn-narrative-ai' : 'btn-narrative-gen');
    const btnLabel = btn ? btn.textContent : '';
    const body = document.getElementById('narrative-body');
    if (btn) { btn.classList.add('generating'); btn.disabled = true; btn.textContent = '⏳ 生成中...'; }
    if (body) body.innerHTML = useAI
        ? '<div class="loading-spinner">🤖 调用外部 LLM 分析中...</div>'
        : '<div class="loading-spinner">⏳ 规则引擎生成中...</div>';

    try {
        const resp = await AC.secureFetch(`${API_BASE}/narrative/generate?force_deterministic=${useAI ? 'false' : 'true'}`, { method: 'POST' });
        const data = await resp.json();
        if (data.status === 'success') {
            renderNarrative(data);
        } else {
            if (body) body.innerHTML = `<div style="text-align:center;padding:20px;color:#f87171;">${data.message || '生成失败'}</div>`;
        }
    } catch (e) {
        console.error('[Narrative] 生成失败:', e);
        if (body) body.innerHTML = '<div style="text-align:center;padding:20px;color:#f87171;">⚠️ 生成失败，请重试</div>';
    } finally {
        if (btn) { btn.classList.remove('generating'); btn.disabled = false; btn.textContent = btnLabel; }
    }
}

