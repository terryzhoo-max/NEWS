/**
 * 2026-11-02 (C5) 执行区: 「执行目标从哪来」+「降仓路径」+ 分批路径状态
 * 只转述后端已有字段, 不新算口径:
 *   约束瀑布   ← hub.action_plan.constraints (AIAE 上限 / 市场尾部刹车 / 组合波动预算 / 回撤刹车, binding = 最严约束)
 *   差额       ← action_plan.current_position − execution_target (= action_plan.execution_gap)
 *   降仓金额   ← /portfolio/vol-budget execution.reduce_amount (回撤刹车降仓清单)
 *   节奏       ← /portfolio/vol-budget execution_layer.reduce_days (唯一来源 EXEC_PARAMS, 统一为 3–5 个交易日)
 *   每日约 X pp 只是 差额 ÷ 天数 的换算, 用于提示节奏, 不是新目标。
 */
(function () {
    'use strict';
    const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
    const num = v => (typeof v === 'number' && isFinite(v)) ? v : null;
    const pct = v => `${v.toFixed(1)}%`;
    let _plan = null;
    let _vb = null;

    /** "3-5" → [3, 5]; 解析失败返回 null */
    function parseDays(text) {
        const m = String(text || '').match(/(\d+)\s*[-–~]\s*(\d+)/);
        if (m) return [Number(m[1]), Number(m[2])];
        const one = String(text || '').match(/^\s*(\d+)\s*$/);
        return one ? [Number(one[1]), Number(one[1])] : null;
    }

    function reduceDays(vb) {
        const layer = (vb && vb.execution_layer) || {};
        if (layer.reduce_days) return String(layer.reduce_days);
        const m = String(layer.instruction || '').match(/分\s*(\d+\s*[-–~]\s*\d+|\d+)\s*个交易日/);
        return m ? m[1].replace(/\s/g, '') : null;
    }

    function money(v) {
        if (v == null) return null;
        return v >= 1e4 ? `¥${(v / 1e4).toFixed(1)}万` : `¥${Math.round(v)}`;
    }

    function waterfallHtml(plan) {
        const rows = Array.isArray(plan.constraints) ? plan.constraints : [];
        if (!rows.length) return '';
        const target = num(plan.execution_target);
        const items = rows.map(r => {
            const v = num(r.value);
            return `<li class="ep-row${r.binding ? ' binding' : ''}">
                <span class="ep-k">${esc(r.label)}</span>
                <span class="ep-v">${v == null ? '--' : pct(v)}</span>
                <span class="ep-n">${esc(r.note || '')}${r.binding ? ' · 最严约束' : ''}${r.asof ? `<span class="ep-asof ac-asof">${esc(r.asof)}</span>` : ''}</span></li>`;
        }).join('');
        return `<div class="ep-block" aria-label="执行目标从哪来">
            <div class="ep-title">执行目标从哪来 <span class="ep-sub">取最严约束, 按周评估, 风险事件当日只向下</span></div>
            <ul class="ep-list">${items}
                <li class="ep-row ep-total"><span class="ep-k">= 执行目标</span><span class="ep-v">${target == null ? '--' : pct(target)}</span><span class="ep-n">唯一仓位数字</span></li>
            </ul></div>`;
    }

    // 2026-11-02 仓位口径统一: 当前仓位的数据时间
    function asOfLine(plan) {
        const lbl = (plan.position_meta || {}).label;
        return lbl ? `<div class="ep-line ep-asof ac-asof">当前仓位：${esc(lbl)}</div>` : '';
    }

    function pathHtml(plan, vb) {
        const cur = num(plan.current_position);
        const target = num(plan.execution_target);
        if (cur == null || target == null) return '';
        const gap = num(plan.execution_gap) != null ? num(plan.execution_gap) : +(cur - target).toFixed(1);
        if (gap <= 0) {
            return `<div class="ep-block ep-path"><div class="ep-title">仓位路径</div>
                <div class="ep-line">当前 ${pct(cur)} 不高于执行目标 ${pct(target)}，无需降仓。</div>${asOfLine(plan)}</div>`;
        }
        const days = reduceDays(vb);
        const range = parseDays(days);
        const amount = money(num(((vb || {}).execution || {}).reduce_amount));
        const perDay = range ? `每日约 ${Math.round(gap / range[1])}–${Math.round(gap / range[0])}pp` : '';
        const pace = days ? `分 ${esc(days)} 个交易日完成${perDay ? ` · ${perDay}` : ''}` : '节奏数据暂不可用';
        return `<div class="ep-block ep-path" aria-label="降仓路径">
            <div class="ep-title">降仓路径 <span class="ep-sub">数据取自 AIAE 执行层与回撤刹车降仓清单</span></div>
            <div class="ep-line ep-main">当前 ${pct(cur)} → 执行目标 ${pct(target)} · 差额 ${gap.toFixed(1)}pp${amount ? `（约 ${amount}）` : ''}</div>
            ${asOfLine(plan)}
            <div class="ep-line">${pace} · 开盘跌停的顺延, 不改目标</div>
            <div class="ep-line ep-muted">具体卖出顺序见「持仓跟踪止盈 → 降仓清单」</div></div>`;
    }

    function statusHtml(plan) {
        const allowed = plan.permissions && plan.permissions.create_order === true;
        return `<div class="ep-line ep-status">分批调仓路径：${allowed ? '已获批，可生成' : '未获批执行目标，暂停生成（下单权限关闭）'}</div>`;
    }

    function render() {
        const el = document.getElementById('exec-path');
        if (!el || !_plan) return;
        el.innerHTML = waterfallHtml(_plan) + pathHtml(_plan, _vb) + statusHtml(_plan);
        el.hidden = false;
    }

    window.addEventListener('ac:action-plan', e => { _plan = e.detail || null; render(); });

    async function loadVb() {
        try {
            const raw = await fetch('/api/v1/portfolio/vol-budget', { signal: AbortSignal.timeout(15000) }).then(r => r.json());
            _vb = raw && (raw.data || raw);
        } catch (e) {
            console.warn('[ExecPath] vol-budget 读取失败, 降仓金额/节奏不显示:', e);
            _vb = null;
        }
        render();
    }
    if (typeof document !== 'undefined' && document.addEventListener) {
        document.addEventListener('DOMContentLoaded', () => setTimeout(loadVb, 400));
    }
    window.ExecPath = { render, parseDays, reduceDays, pathHtml, waterfallHtml, loadVb };
})();
