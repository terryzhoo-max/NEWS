/**
 * 决策中枢模块开关 (2026-11-02 精简)
 * 读取 /api/v1/decision/modules (唯一配置: config/decision_modules.json)。
 * 关闭的模块: 面板加 .dm-off 隐藏, 各加载函数通过 DM.on(key) 跳过请求; 不删代码。
 * 接口失败时全部视为开启 (不因开关故障隐藏任何模块)。
 */
(function () {
    'use strict';
    // 模块 key → 页面元素 (一个模块可对应多个元素)
    const SELECTORS = {
        global_temp: ['#global-temp-panel'],
        multi_asset: ['#multi-asset-panel'],
        swing_guard: ['#swing-guard-dashboard'],
        narrative: ['#narrative-panel'],
        intelligence: ['#intelligence-panel'],
        rebalance: ['#rebalance-panel'],
        scenario: ['#scenario-panel', '#shock-panel'],
        optimizer: ['.decision-tab[data-tab="tab-optimizer"]', '#tab-optimizer'],
        tail_risk: ['#risk-tail-card'],
        performance: ['#risk-perf-card', '#perf-section'],
        correlation: ['#correlation-section'],
        overlap: ['#risk-overlap-card'],
        sector_concentration: ['#risk-sector-card'],
        brinson: ['#brinson-panel'],
        drift: ['#drift-card'],
        calendar: ['.decision-tab[data-tab="tab-calendar"]', '#tab-calendar'],
        param_compare: ['#btn-param-compare'],
        vol_budget: ['#vol-budget-panel'],          // C5: 约束瀑布并入执行区
        position_path: ['#position-path-card'],     // C5: 状态并入执行区
        timeline: ['#timeline-legacy'],             // C6: 由复盘「执行目标 vs 实际仓位」替代
        ref_manual: ['#ref-manual-panel'],          // C7: 合并为 docs/DECISION_RULES.md
        risk_sop: ['#risk-sop-panel'],              // C7: 合并为 docs/DECISION_RULES.md
        risk_tab: ['.decision-tab[data-tab="tab-risk"]', '#tab-risk'],  // C7: 标签已空
    };
    let modules = null;

    function on(key) {
        if (!modules) return true;
        const m = modules[key];
        return !(m && m.enabled === false);
    }

    function apply() {
        Object.keys(SELECTORS).forEach(key => {
            const off = !on(key);
            SELECTORS[key].forEach(sel => document.querySelectorAll(sel).forEach(el => {
                el.classList.toggle('dm-off', off);
                if (off) el.setAttribute('data-dm-off', key); else el.removeAttribute('data-dm-off');
            }));
        });
        // 一行内两张卡都关闭时, 整行一并隐藏 (避免留下空行间距)
        document.querySelectorAll('[data-dm-row]').forEach(row => {
            const cards = [...row.children];
            row.classList.toggle('dm-off', cards.length > 0 && cards.every(c => c.classList.contains('dm-off')));
        });
    }

    const ready = fetch('/api/v1/decision/modules', { signal: AbortSignal.timeout(5000) })
        .then(r => r.json())
        .then(d => { modules = (d && d.status === 'success' && d.modules) || {}; })
        .catch(e => { console.warn('[DM] 模块开关读取失败, 全部按开启处理:', e); modules = {}; })
        .then(() => {
            if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', apply);
            else apply();
        });

    window.DM = { ready, on, apply, SELECTORS };
})();
