/**
 * 2026-11-02 (1a) 今日结论
 * 三项均来自下方模块同一次加载的结果 (事件转发), 本文件不发请求、不计算任何数字:
 *   执行目标仓位 ← renderActionPlan (hub.action_plan.execution_target)
 *   合规状态     ← loadRiskGuardrail (/compliance-check, 硬阻断条数 = blocks.length)
 *   止损已触发未执行 ← 跟踪止盈 (/portfolio/trailing-stops, summary.RED = 已触发、次日开盘卖出)
 */
(function () {
    'use strict';
    const STATES = ['s-pass', 's-warn', 's-fail', 's-block', 's-info'];

    function set(key, text, state, title) {
        const item = document.querySelector(`.today-summary [data-sum="${key}"]`);
        const val = item && item.querySelector('.ts-sum-value');
        if (!item || !val) return;
        val.textContent = text;
        item.classList.remove(...STATES);
        item.classList.add(state || 's-info');
        if (title) item.title = title; else item.removeAttribute('title');
    }

    const num = v => (typeof v === 'number' && isFinite(v)) ? v : null;

    // 2026-11-03 (1b): 当前仓位数据时间直接显示在卡片下方 (手机无悬浮), 悬浮提示保留
    function setAsOf(label) {
        const el = (typeof document.getElementById === 'function') ? document.getElementById('sum-exec-asof') : null;
        if (!el) return;
        el.textContent = label || '';
        el.hidden = !label;
    }

    window.addEventListener('ac:action-plan', e => {
        const plan = e.detail || {};
        const target = num(plan.execution_target);
        const current = num(plan.current_position);
        if (target === null) { set('exec', '执行目标不可用', 's-fail'); setAsOf(''); return; }
        const text = `${target.toFixed(1)}%` + (current === null ? '' : `（当前 ${current.toFixed(1)}%）`);
        // 2026-11-02 仓位口径统一: 悬浮提示标注当前仓位的数据时间
        const asOf = (plan.position_meta || {}).label || '';
        set('exec', text, 's-info', [plan.action_label || '', asOf ? `当前仓位：${asOf}` : ''].filter(Boolean).join('\n'));
        setAsOf(asOf);
    });

    window.addEventListener('ac:compliance', e => {
        const d = e.detail || {};
        const blocks = Array.isArray(d.blocks) ? d.blocks.length : 0;
        const warns = num(d.warn_count) || 0;
        if (d.status === 'warming_up') set('compliance', '数据加载中', 's-info', d.summary || '服务启动预热中');
        else if (d.status === 'blocked') set('compliance', `阻断 · ${blocks} 条硬阻断`, 's-block', d.summary || '');
        else if (d.status === 'warning') set('compliance', `警告 · ${warns} 条`, 's-warn', d.summary || '');
        else if (d.status === 'passed') set('compliance', '通过', 's-pass', d.summary || '');
        else set('compliance', '不可用', 's-fail', '合规引擎未返回结论');
    });

    window.addEventListener('ac:trailing', e => {
        const d = e.detail || {};
        const red = num((d.summary || {}).RED) || 0;
        set('stops', `${red} 只`, red > 0 ? 's-block' : 's-pass', red > 0 ? '已触发止损, 规则要求下一交易日开盘卖出' : '');
    });

    // 2026-11-02: 服务启动预热中 — 执行目标与合规不显示读数
    window.addEventListener('ac:warming', () => {
        set('exec', '数据加载中', 's-info', '服务启动预热中');
        setAsOf('');
        set('compliance', '数据加载中', 's-info', '服务启动预热中');
    });

    window.addEventListener('ac:trailing-error', () => set('stops', '不可用', 's-fail', '跟踪止盈暂不可用'));
})();
