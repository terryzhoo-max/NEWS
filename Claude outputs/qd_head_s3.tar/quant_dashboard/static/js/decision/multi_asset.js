/**
 * AlphaCore V27 · 多资产配置雷达模块 (Multi-Asset Radar)
 * ========================================================
 *   - 方向、置信评分、来源日期与模型目标分开展示
 *   - 带方向条形图保留独立信号，柱图比较 SAA 与受约束的 TAA
 *   - 黄金贡献使用统一刻度；缺失数据不替换成中性或零仓位
 *
 * 依赖: API_BASE, _getChart, _fmt, _safeFetch (from _infra.js)
 */

// ═══════════════════════════════════════════════════
//  工具函数
// ═══════════════════════════════════════════════════

/** HTML 转义 (防 XSS) */
function _maEscape(str) {
    return String(str ?? '').replace(/[&<>"']/g, ch =>
        ({'&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'}[ch]));
}

function _maNumber(value) {
    return typeof value === 'number' && Number.isFinite(value) ? value : null;
}

function _maPct(value) {
    return _maNumber(value) === null ? '—' : `${Number(value.toFixed(1))}%`;
}

function _maTime(value) {
    if (!value) return '—';
    // Preserve source wall time when its producer omitted a timezone.
    if (!/(Z|[+-]\d{2}:\d{2})$/.test(String(value))) return String(value).replace('T', ' ').slice(0, 19) + '（源时间）';
    const date = new Date(value);
    return Number.isNaN(date.getTime()) ? '—' : date.toLocaleString('zh-CN', {timeZoneName: 'short'});
}

function _maFreshnessNote(comp) {
    if (comp.data_status === 'unavailable') return comp.unusable_reason || '来源待恢复';
    const state = comp.freshness;
    if (!state) return '';
    const cadence = state.release_cadence === 'weekly' ? '按周发布' : '日频来源';
    const next = state.next_update_at ? ` · 下次预计 ${_maTime(state.next_update_at)}` : '';
    return `${cadence} · ${state.reason || ''}${next}`;
}

function _maDisposeCharts() {
    if (typeof _chartInstances === 'undefined') return;
    ['ma-radar-chart', 'ma-alloc-pie'].forEach(id => {
        if (_chartInstances[id]) _chartInstances[id].dispose();
        delete _chartInstances[id];
    });
}

function _maInvalidateTargets(data, reason) {
    const result = JSON.parse(JSON.stringify(data));
    result.status = 'degraded';
    result.decision_locked = true;
    result.constraints = {...result.constraints, reasons: [reason], total_pct: null};
    Object.values(result.assets || {}).forEach(asset => {
        asset.allocation = null;
        asset.active_weight = null;
        asset.allocation_label = '暂无有效目标';
    });
    return result;
}

/** 信号值 → 文字标签 */
function _maSignalLabel(signal) {
    if (_maNumber(signal) === null) return '—';
    const abs = Math.abs(signal);
    if (abs >= 60) return '强';
    if (abs >= 30) return '中';
    return '弱';
}

// ═══════════════════════════════════════════════════
//  数据层
// ═══════════════════════════════════════════════════

let _multiAssetCache = null;
let _multiAssetPending = false;
let _multiAssetRenderId = 0;

async function loadMultiAssetRadar(forceRefresh = false) {
    const container = document.getElementById('multi-asset-body');
    if (!container || _multiAssetPending) return;
    _multiAssetPending = true;
    const refresh = container.querySelector('.ma-refresh-btn');
    if (refresh) refresh.disabled = true;

    // 骨架屏加载态
    if (!_multiAssetCache) container.innerHTML = `
        <div class="ma-loading-state">
            <div class="ma-loading-ring"></div>
            <div class="ma-loading-text">多资产信号聚合中...</div>
        </div>`;

    try {
        const data = await _safeFetch(`${API_BASE}/multi-asset${forceRefresh ? '?refresh=true' : ''}`);

        if (['success', 'degraded'].includes(data.status) && data.assets) {
            _multiAssetCache = data;
            renderMultiAssetRadar(data);
            _updateMultiAssetSummary(data);
        } else {
            throw new Error(data.error || '数据加载失败');
        }
    } catch (e) {
        console.warn('Multi-Asset Radar load error:', e);
        if (_multiAssetCache) {
            const stale = _maInvalidateTargets(_multiAssetCache, '刷新失败，当前为历史信号；组合目标已暂停');
            renderMultiAssetRadar(stale);
            _updateMultiAssetSummary(stale);
            return;
        }
        _maDisposeCharts();
        const summary = document.getElementById('multi-asset-summary');
        if (summary) summary.textContent = '数据不可用 · 暂无有效目标';
        const errMsg = _maEscape(e.message || '');
        container.innerHTML = `<div class="ma-error">
            <span class="ma-error-icon">⚠️</span>
            <span>多资产信号暂时不可用</span>
            <span class="ma-error-detail">${errMsg}</span>
            <button class="ma-retry-btn" onclick="loadMultiAssetRadar(true)">↻ 重试</button>
        </div>`;
    } finally {
        _multiAssetPending = false;
        const button = container.querySelector('.ma-refresh-btn');
        if (button) button.disabled = false;
    }
}

// ═══════════════════════════════════════════════════
//  折叠态摘要行
// ═══════════════════════════════════════════════════

function _updateMultiAssetSummary(data) {
    const el = document.getElementById('multi-asset-summary');
    if (!el || !data.assets) return;

    const order = ['equity_cn', 'bond', 'gold', 'cash'];
    const parts = order
        .map(key => data.assets[key])
        .filter(Boolean)
        .map(a => `${a.icon} ${a.label} ${_maPct(a.allocation)}`)
        .slice(0, 4);
    el.textContent = `${data.decision_locked ? '目标暂停 · ' : ''}${parts.join(' · ') || '数据不可用'}`;
}

// ═══════════════════════════════════════════════════
//  主渲染 — 机构级视觉
// ═══════════════════════════════════════════════════

const _MA_DIR_COLORS = {
    bullish: { main: '#34d399', bg: 'rgba(52,211,153,0.08)', border: 'rgba(52,211,153,0.2)' },
    bearish: { main: '#f87171', bg: 'rgba(248,113,113,0.08)', border: 'rgba(248,113,113,0.2)' },
    neutral: { main: '#94a3b8', bg: 'rgba(148,163,184,0.06)', border: 'rgba(148,163,184,0.12)' },
    unavailable: { main: '#fbbf24', bg: 'rgba(251,191,36,0.06)', border: 'rgba(251,191,36,0.2)' },
};
const _MA_DIR_ICONS = { bullish: '▲', bearish: '▼', neutral: '━', unavailable: '…', not_applicable: '•' };
const _MA_ASSET_COLORS = {
    equity_cn: '#3b82f6',
    bond:      '#a78bfa',
    gold:      '#fbbf24',
    cash:      '#6ee7b7',
};

function renderMultiAssetRadar(data) {
    const container = document.getElementById('multi-asset-body');
    if (!container || !data.assets) return;

    const assets = data.assets;
    const order = ['equity_cn', 'bond', 'gold', 'cash'];

    // ── 四资产卡片 ──
    let cardsHtml = '';
    order.forEach((key, idx) => {
        const a = assets[key];
        if (!a) return;

        const dir = a.direction || 'neutral';
        const dc = _MA_DIR_COLORS[dir] || _MA_DIR_COLORS.neutral;
        const dirIcon = _MA_DIR_ICONS[dir] || '━';
        const dirCn = a.direction_cn || '—';
        const alloc = _maNumber(a.allocation);
        const allocLabel = a.allocation_label || '暂无有效目标';
        const signal = _maNumber(a.signal);
        const sigLabel = key === 'cash' ? '不适用' : _maSignalLabel(signal);
        const hasError = !!a.error || a.data_status === 'unavailable';
        const accentColor = _MA_ASSET_COLORS[key] || '#94a3b8';
        const targetLabel = alloc === null ? (key === 'cash' ? '组合目标暂停'
            : hasError ? '来源待恢复 · 组合目标暂停' : '信号有效 · 组合目标暂停') : allocLabel;

        let cardDesc = '';
        if (key === 'cash') {
            cardDesc = `<div class="ma-card-desc">预算余量形成现金储备，最低 ${_maPct(data.constraints?.min_cash_pct)}。</div>`;
        } else if (key === 'equity_cn') {
            cardDesc = `<div class="ma-card-desc">方向来自权益因子（固定权重，含 MR 策略信号）；仓位受 AIAE 上限约束，不使用 JCS。</div>`;
        } else if (key === 'bond') {
            cardDesc = `<div class="ma-card-desc">美国国债利率信号；人民币收益还受汇率、久期与产品结构影响。</div>`;
        } else if (key === 'gold') {
            cardDesc = `<div class="ma-card-desc">黄金宏观因子评分；目标以 SAA 为锚，配置效果待历史验证。</div>`;
        }
        if (a.data_as_of) cardDesc += `<div class="ma-source-date">${key === 'equity_cn' ? '引擎更新' : '源数据'} ${_maEscape(key === 'equity_cn' ? _maTime(a.data_as_of) : a.data_as_of)}</div>`;
        if (a.availability_reason) cardDesc += `<div class="ma-source-issue">${_maEscape(a.availability_reason)}</div>`;

        cardsHtml += `
        <div class="ma-card ${hasError ? 'ma-card-err' : ''}" data-asset="${key}"
             style="--ma-accent:${accentColor};--ma-dir:${dc.main};animation-delay:${idx * 0.08}s">
            <div class="ma-card-accent"></div>
            <div class="ma-card-top">
                <span class="ma-card-icon">${_maEscape(a.icon || '●')}</span>
                <div class="ma-card-meta">
                    <span class="ma-card-name">${_maEscape(a.label)}</span>
                    <span class="ma-card-sublabel">${_maEscape(targetLabel)}</span>
                </div>
                <div class="ma-card-signal-badge" style="color:${dc.main};border-color:${dc.border};background:${dc.bg}">
                    ${dirIcon} ${_maEscape(dirCn)} · ${sigLabel}
                </div>
            </div>
            <div class="ma-card-bar-wrap">
                <div class="ma-card-bar-track ${alloc === null ? 'ma-target-unavailable' : ''}" aria-label="${alloc === null ? '暂无有效目标' : `目标 ${_maPct(alloc)}`}">
                    ${alloc === null ? '' : `<div class="ma-card-bar-fill" style="width:${Math.max(0, Math.min(alloc, 100))}%;background:linear-gradient(90deg,${accentColor},${dc.main})"></div>`}
                </div>
                <span class="ma-card-pct">${_maPct(alloc)}</span>
            </div>
            ${cardDesc}
            ${a.error ? `<div class="ma-card-err-msg">${_maEscape(a.error)}</div>` : ''}
        </div>`;
    });

    // ── 黄金三维信号 ──
    let goldHtml = '';
    const gold = assets.gold;
    if (gold && gold.components && !gold.error) {
        const comps = gold.components;
        const compItems = [
            { key: 'real_rate', label: '实际利率', icon: '📉', desc: '利率下行 → 利好黄金' },
            { key: 'dollar',    label: '美元强弱', icon: '💲', desc: '美元走弱 → 利好黄金' },
            { key: 'inflation', label: '通胀预期', icon: '🔥', desc: '通胀上行 → 利好黄金' },
        ];

        let compRows = '';
        compItems.forEach(ci => {
            const comp = comps[ci.key];
            if (!comp) return;
            const val = _maNumber(comp.contribution);
            const weight = _maNumber(comp.weight) ?? 0;
            
            // A: 方向判定 — 优先使用后端返回的 direction
            const unavailable = comp.data_status === 'unavailable' || val === null;
            const computedDir = unavailable ? 'unavailable' : (comp.direction || (val > 0 ? 'bullish' : (val < 0 ? 'bearish' : 'neutral')));
            const dc = _MA_DIR_COLORS[computedDir] || _MA_DIR_COLORS.neutral;

            // B: 中文语义标签 — 优先使用后端返回的 direction_cn
            const directionCn = unavailable ? '待恢复' : (comp.direction_cn || (val > 5 ? '利好' : (val < -5 ? '利空' : '中性')));

            // Weighted contributions use the same scale across all rows.
            // Compare weighted points on one scale across all factors.
            const absVal = Math.abs(val ?? 0);
            const barWidth = Math.min(50, absVal / 100 * 50);
            const isPos = val >= 0;
            const barStyle = isPos 
                ? `left:50%;width:${barWidth}%;background:#10b981;`
                : `right:50%;width:${barWidth}%;background:#ef4444;`;

            const weightPct = weight ? `${Math.round(weight * 100)}%` : '';

            compRows += `
            <div class="ma-gold-row ${unavailable ? 'ma-factor-unavailable' : ''}">
                <span class="ma-gold-icon">${ci.icon}</span>
                <div class="ma-gold-info" style="flex:0 0 110px;">
                    <span class="ma-gold-label">${_maEscape(unavailable ? `${ci.label}：数据不可用` : (comp.label || ci.label))}</span>
                    <span class="ma-gold-desc">${weightPct ? `权重 ${weightPct} · ` : ''}原始分 ${_fmt(comp.score, 1)}</span>
                    <span class="ma-gold-desc">${_maEscape(comp.data_as_of || '日期不可用')}</span>
                    <span class="ma-factor-note">${_maEscape(_maFreshnessNote(comp))}</span>
                </div>
                <!-- 横向双向条形图 -->
                <div class="ma-gold-diverging-wrap">
                    ${unavailable ? '<span class="ma-gold-na">贡献不可用</span>' : `<div class="ma-gold-diverging-center"></div><div class="ma-gold-diverging-bar" style="${barStyle}"></div>`}
                </div>
                <span class="ma-gold-val" style="color:${dc.main}; min-width:44px; text-align:right;">${val > 0 ? '+' : ''}${_fmt(val, 1)}</span>
                <span class="ma-gold-tag" style="color:${dc.main};border-color:${dc.border};background:${dc.bg}; min-width:38px; text-align:center;">
                    ${_maEscape(directionCn)}
                </span>
            </div>`;
        });

        if (compRows) {
            // C: 黄金综合分值根据数值变色 Fallback
            const goldDir = gold.direction || 'neutral';
            const totalColor = (_MA_DIR_COLORS[goldDir] || _MA_DIR_COLORS.neutral).main;
            const usable = _maNumber(gold.signal) !== null && gold.data_status !== 'unavailable';
            const coverage = _maNumber(gold.quality?.coverage);
            const partial = _maNumber(gold.partial_signal);
            const coverageText = `${coverage === null ? '' : `有效权重覆盖 ${Math.round(coverage * 100)}%`}${!usable && partial !== null ? ` · 有效项小计 ${partial > 0 ? '+' : ''}${_fmt(partial, 1)}（非完整综合分）` : ''}`;

            goldHtml = `
            <div class="ma-gold-panel">
                <div class="ma-gold-header">
                    <span>🥇 黄金贡献分 · 统一刻度 ±100</span>
                    <span class="ma-gold-total" style="color:${totalColor}">
                        ${usable ? `综合 ${gold.signal > 0 ? '+' : ''}${_fmt(gold.signal, 1)}` : '综合待恢复'}
                    </span>
                </div>
                <div class="ma-gold-coverage">${_maEscape(coverageText)}</div>
                ${compRows}
            </div>`;
        }
    }

    // ── 时间戳 + 刷新 ──
    const ts = _maTime(data.timestamp);
    const reasons = data.constraints?.reasons || [];
    const bindings = data.constraints?.binding || [];
    const warnings = reasons.length ? reasons.join('；') : (bindings.length ? '目标已按仓位上限与现金底线调整' : '约束检查通过');
    const total = _maNumber(data.constraints?.total_pct);
    const sourceKeys = ['equity_cn', 'bond', 'gold'];
    const validSources = sourceKeys.filter(key => assets[key]?.data_status === 'ok').length;
    const sourceHtml = sourceKeys.map(key => `<span class="ma-health-pill ${assets[key]?.data_status === 'ok' ? '' : 'ma-health-missing'}">${_maEscape(assets[key]?.label || key)} · ${assets[key]?.data_status === 'ok' ? '有效' : '待恢复'}</span>`).join('');
    const sourceWarnings = Array.isArray(data.warnings) ? data.warnings : [];
    _maDisposeCharts();
    const renderId = ++_multiAssetRenderId;

    container.innerHTML = `
    <div class="ma-policy-state ${data.decision_locked ? 'ma-policy-blocked' : ''}" role="status">
        ${_maEscape(warnings)}${total === null ? '' : ` · 合计 ${_maPct(total)}`}
        <span>模型目标 · 参数待样本外验证</span>
        ${sourceWarnings.length ? `<span class="ma-release-note">${sourceWarnings.map(_maEscape).join('；')}</span>` : ''}
    </div>
    <div class="ma-health-row" aria-label="资产来源状态"><span>有效资产信号 ${validSources}/3</span>${sourceHtml}</div>
    <div class="ma-layout">
        <div class="ma-left">
            <div class="ma-section-label">方向信号（−100～+100，非概率）</div>
            <div id="ma-radar-chart" class="ma-radar-box"></div>
            <div class="ma-ts-row">
                <span>计算于 ${_maEscape(ts)}${data._cache?.stale ? ' · 旧缓存' : ''}</span>
                <button class="ma-refresh-btn" onclick="loadMultiAssetRadar(true)">↻ 刷新评估</button>
            </div>
            <div class="ma-section-label" style="margin-top:20px;">SAA 战略基准 vs TAA 模型目标</div>
            <div id="ma-alloc-pie" class="ma-pie-box"></div>
        </div>
        <div class="ma-right">
            <div class="ma-section-label">资产配置模型目标</div>
            <div class="ma-cards-wrap">${cardsHtml}</div>
            ${goldHtml}
        </div>
    </div>`;

    // ── 渲染图表 ──
    requestAnimationFrame(() => {
        if (renderId !== _multiAssetRenderId) return;
        _drawMARadar(assets, order);
        _drawMASaaTaaBar(data, assets, order);
    });
}

// ═══════════════════════════════════════════════════
//  独立方向信号图（历史函数名保留以兼容现有调用）
// ═══════════════════════════════════════════════════

function _drawMARadar(assets, order) {
    const chart = _getChart('ma-radar-chart');
    if (!chart) return;
    if (typeof AC !== 'undefined' && AC.registerChart) AC.registerChart(chart);
    // Signed, independent bars preserve valid signals when another source is missing.
    const keys = order.filter(key => key !== 'cash');
    const values = keys.map(key => _maNumber(assets[key]?.signal));
    const available = values.filter(value => value !== null).length;
    chart.setOption({
        backgroundColor: 'transparent',
        grid: {left: 112, right: 55, top: 42, bottom: 35},
        tooltip: {
            trigger: 'axis', axisPointer: {type: 'shadow'},
            backgroundColor: 'rgba(15,23,42,0.95)', borderColor: 'rgba(255,255,255,0.08)',
            textStyle: {color: '#e2e8f0', fontSize: 11},
            formatter(params) {
                const items = Array.isArray(params) ? params : [params];
                return items.map(item => {
                    const key = keys[item.dataIndex];
                    const asset = assets[key] || {};
                    const value = _maNumber(asset.signal);
                    return `${_maEscape(asset.label || key)}：${value === null ? '数据不足' : `${value > 0 ? '+' : ''}${_fmt(value, 1)} · ${_maEscape(asset.direction_cn || '')}`}`;
                }).join('<br>');
            },
        },
        xAxis: {
            type: 'value', min: -100, max: 100, interval: 50,
            axisLabel: {color: '#94a3b8', fontSize: 10},
            splitLine: {lineStyle: {color: 'rgba(148,163,184,0.1)'}},
        },
        yAxis: {
            type: 'category', inverse: true,
            data: keys.map((key, index) => `${assets[key]?.label || key}${values[index] === null ? ' · 待恢复' : ''}`),
            axisTick: {show: false}, axisLine: {show: false},
            axisLabel: {color: '#cbd5e1', fontSize: 11, width: 100, overflow: 'truncate'},
        },
        graphic: [{type: 'text', left: 'center', top: available ? 12 : 'middle', silent: true,
            style: {text: available ? `有效方向信号 ${available}/3 · 正值看多 / 负值看空` : '暂无有效方向信号，等待来源恢复',
                fill: '#94a3b8', fontSize: 11}}],
        series: [{name: '方向信号', type: 'bar', barMaxWidth: 20,
            data: values.map((value, index) => ({value, itemStyle: {
                color: (_MA_DIR_COLORS[assets[keys[index]]?.direction] || _MA_DIR_COLORS.neutral).main,
                borderRadius: 4}})),
            label: {show: true, color: '#e2e8f0', position: 'right', fontSize: 11,
                formatter: item => _maNumber(item.value) === null ? '' : `${item.value > 0 ? '+' : ''}${_fmt(item.value, 1)}`},
            markLine: {silent: true, symbol: 'none', label: {show: false},
                lineStyle: {color: '#64748b', type: 'solid'}, data: [{xAxis: 0}]},
        }],
    });
}

// SAA is a strategic reference; suspended TAA is never displayed as zero weights.
function _drawMASaaTaaBar(data, assets, order) {
    const chart = _getChart('ma-alloc-pie');
    if (!chart) return;
    if (typeof AC !== 'undefined' && AC.registerChart) AC.registerChart(chart);

    // Policy remains owned by the backend; no silent frontend portfolio default.
    const saaWeights = data.saa_weights || {};

    const categories = order.map(k => assets[k]?.label || k);
    const saaData = order.map(k => _maNumber(saaWeights[k]));
    const taaData = order.map(k => _maNumber(assets[k]?.allocation));
    const hasTargets = taaData.every(value => value !== null);

    chart.setOption({
        backgroundColor: 'transparent',
        tooltip: {
            trigger: 'axis',
            axisPointer: { type: 'shadow' },
            backgroundColor: 'rgba(15,23,42,0.95)',
            borderColor: 'rgba(255,255,255,0.08)',
            textStyle: { color: '#e2e8f0', fontSize: 11 },
            formatter: function(params) {
                if (!params.length) return '';
                let html = `<div style="font-weight:600;margin-bottom:4px;">${_maEscape(params[0].name)}</div>`;
                params.forEach(p => {
                    html += `<div>${p.marker} ${_maEscape(p.seriesName)}: <span style="font-weight:700">${_maPct(p.value)}</span></div>`;
                });
                return html;
            }
        },
        legend: {
            data: hasTargets ? ['战略基准 (SAA)', '模型目标 (TAA)'] : ['战略基准 (SAA)'],
            top: 4,
            textStyle: { color: '#94a3b8', fontSize: 10 }
        },
        grid: {
            left: 35, right: 10, top: hasTargets ? 35 : 65, bottom: 25
        },
        graphic: hasTargets ? [] : [{type: 'text', left: 'center', top: 35, silent: true,
            style: {text: 'TAA 目标暂停，当前仅展示 SAA 战略参考', fill: '#fbbf24', fontSize: 11}}],
        xAxis: {
            type: 'category',
            data: categories,
            axisLabel: { color: '#94a3b8', fontSize: 10 },
            axisLine: { lineStyle: { color: 'rgba(148,163,184,0.15)' } },
            axisTick: { show: false }
        },
        yAxis: {
            type: 'value',
            max: 100,
            axisLabel: { color: '#94a3b8', fontSize: 9, formatter: '{value}%' },
            splitLine: { lineStyle: { color: 'rgba(148,163,184,0.08)' } },
            axisLine: { show: false }
        },
        series: [
            {
                name: '战略基准 (SAA)',
                type: 'bar',
                data: saaData,
                itemStyle: { color: 'rgba(148, 163, 184, 0.25)', borderRadius: [3, 3, 0, 0] },
                barMaxWidth: 16
            },
            {
                name: '模型目标 (TAA)',
                type: 'bar',
                data: taaData,
                itemStyle: {
                    color: function(params) {
                        const keys = ['equity_cn', 'bond', 'gold', 'cash'];
                        const k = keys[params.dataIndex];
                        return _MA_ASSET_COLORS[k] || '#3b82f6';
                    },
                    borderRadius: [3, 3, 0, 0]
                },
                barMaxWidth: 16
            }
        ]
    });
}
