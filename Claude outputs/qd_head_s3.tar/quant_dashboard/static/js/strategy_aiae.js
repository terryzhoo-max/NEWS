// ============================================================
// strategy_aiae.js — A股 AIAE 宏观仓位管控前端模块
// 依赖: strategy.js (需先加载)
// ============================================================

//  AIAE 宏观仓位管控模块 V2.0
//  琥珀金色系 · ECharts仪表盘 · 五档markArea色带 · 脉冲信号卡片
// ====================================================================

let _aiaeData = null;
let _aiaeLoading = false;

// DOM 缓存 — 避免每次 render 执行 ~30 次 getElementById
const _aiaeDOM = {};
function _aiaeCacheDOM() {
    // V5.1: 校验关键 DOM 节点有效性，允许首次失败后重新获取
    if (_aiaeDOM._ready && _aiaeDOM['hero-value'] && document.contains(_aiaeDOM['hero-value'])) return;
    ['hero-value','hero-regime','hero-position','hero-erp',
     'gauge-container','gauge-label','gauge-regime','slope-indicator',
     'data-simple','data-margin','data-fund','data-fund-date',
     'history-chart','hist-current','signal-cards',
     'matrix-table','matrix-verdict','cross-validation',
     'action-buy-list','action-hold-list','action-sell-list',
     'warn-margin','warn-slope','warn-fund',
     'warn-margin-val','warn-slope-val','warn-fund-val',
     'warn-margin-bar','warn-slope-bar','warn-fund-bar',
     'warning-panel','history-summary','regime-cards',
     'alloc-cards','load-status','load-btn','refresh-btn',
     'fund-reminder-banner','fund-stale-badge',
     'slippage-desk', 'slip-size', 'slip-cost', 'slip-algo',
     'contagion-matrix-container', 'contagion-matrix',
     'grc-emergency-alert', 'discipline-drawer', 'drawer-trigger',
     'drawer-close', 'drawer-overlay', 'grc-read-confirm',
     'grc-sig-input', 'grc-sign-btn', 'grc-audit-trail'
    ].forEach(k => {
        _aiaeDOM[k] = document.getElementById('aiae-' + k);
    });
    _aiaeDOM._ready = true;
}

// V5.1: ECharts 异步就绪等待 — 解决 CDN 首次加载竞态
function _waitForECharts(callback, retries) {
    if (retries === undefined) retries = 25; // 最多等 ~7.5 秒
    if (typeof echarts !== 'undefined') { try { callback(); } catch(e) { console.warn('[AIAE] ECharts callback error:', e); } return; }
    if (retries <= 0) { console.warn('[AIAE] ECharts 未能在超时内加载，图表渲染跳过'); return; }
    setTimeout(function() { _waitForECharts(callback, retries - 1); }, 300);
}


async function loadAIAEReport(forceRefresh = false) {
    if (_aiaeLoading) return;
    if (_aiaeData && !forceRefresh) {
        renderAIAEUI(_aiaeData);
        return;
    }

    _aiaeLoading = true;
    const statusEl = document.getElementById('aiae-load-status');
    const loadBtn = document.getElementById('aiae-load-btn');
    const refreshBtn = document.getElementById('aiae-refresh-btn');
    if (statusEl) statusEl.textContent = '⏳ 正在连接 Tushare 数据源...';
    if (loadBtn) { loadBtn.disabled = true; loadBtn.innerHTML = '⏳ 加载中...'; }
    if (refreshBtn) refreshBtn.disabled = true;

    try {
        const endpoint = forceRefresh ? '/api/v1/aiae/refresh' : '/api/v1/aiae/report';
        const resp = await fetch(endpoint, { signal: AbortSignal.timeout(20000) });
        const json = await resp.json();

        if (json.status === 'success' && json.data) {
            _aiaeData = json.data;
            try {
                renderAIAEUI(_aiaeData);
            } catch(renderErr) {
                console.warn('[AIAE] Partial render error (non-blocking):', renderErr);
            }
            if (statusEl) {
                const st = _aiaeData.status === 'fallback' ? '⚠️ 降级数据' : '✅ 实时数据';
                statusEl.textContent = st + ' · ' + new Date().toLocaleTimeString();
            }
            if (loadBtn) loadBtn.innerHTML = '✅ 数据已加载';
            setTimeout(() => { if (loadBtn) loadBtn.innerHTML = '⚡ 加载实时数据'; }, 2000);
        } else {
            if (statusEl) statusEl.textContent = `❌ ${json.message || '加载失败'}`;
            if (loadBtn) loadBtn.innerHTML = '❌ 重试';
            setTimeout(() => { if (loadBtn) loadBtn.innerHTML = '⚡ 加载实时数据'; }, 3000);
        }
    } catch (e) {
        console.error('[AIAE] Load error:', e);
        if (statusEl) statusEl.textContent = `❌ 网络异常: ${e.message}`;
        if (loadBtn) loadBtn.innerHTML = '❌ 重试';
        setTimeout(() => { if (loadBtn) loadBtn.innerHTML = '⚡ 加载实时数据'; }, 3000);
    } finally {
        _aiaeLoading = false;
        if (loadBtn) loadBtn.disabled = false;
        if (refreshBtn) refreshBtn.disabled = false;
    }
}

// ── 生产级风控抽屉交互绑定 ──
let _grcDrawerBound = false;

// 辅助渲染时间轴
function renderGRCAuditTrail() {
    const trailEl = _aiaeDOM['grc-audit-trail'];
    if (!trailEl) return;
    
    let history = [];
    try {
        history = JSON.parse(localStorage.getItem('aiae_grc_audit_history') || '[]');
    } catch(e) {
        history = [];
    }
    
    if (history.length === 0) {
        trailEl.innerHTML = `<div style="font-size: 0.65rem; color: #64748b; font-style: italic;">暂无签认记录</div>`;
        return;
    }
    
    const regimeRoman = {1:'Ⅰ', 2:'Ⅱ', 3:'Ⅲ', 4:'Ⅳ', 5:'Ⅴ'};
    trailEl.innerHTML = history.map((record, idx) => {
        const gapVal = parseFloat(record.gap);
        const gapStr = (gapVal >= 0 ? '+' : '') + gapVal.toFixed(1) + ' pt';
        return `
            <div class="aiae-audit-node">
                <div class="aiae-audit-dot signed"></div>
                <div class="aiae-audit-info">
                    交易员 <b>${record.operator}</b> 签认 SOP 纪律<br/>
                    <span style="color:#94a3b8;">状态: AIAE ${regimeRoman[record.regime] || record.regime}级 · 实盘偏差 ${gapStr}</span>
                </div>
                <div class="aiae-audit-time">${record.timestamp}</div>
            </div>
        `;
    }).join('');
}

function bindGRCDrawer() {
    if (_grcDrawerBound) return;
    
    const trigger = _aiaeDOM['drawer-trigger'];
    const drawer = _aiaeDOM['discipline-drawer'];
    const closeBtn = _aiaeDOM['drawer-close'];
    const overlay = _aiaeDOM['drawer-overlay'];
    const checkbox = _aiaeDOM['grc-read-confirm'];
    const sigInput = _aiaeDOM['grc-sig-input'];
    const signBtn = _aiaeDOM['grc-sign-btn'];

    if (trigger && drawer) {
        trigger.addEventListener('click', () => {
            drawer.classList.add('open');
            if (overlay) overlay.style.display = 'block';
            renderGRCAuditTrail();
        });
    }

    const closeDrawer = () => {
        if (drawer) drawer.classList.remove('open');
        if (overlay) overlay.style.display = 'none';
    };

    if (closeBtn) closeBtn.addEventListener('click', closeDrawer);
    if (overlay) overlay.addEventListener('click', closeDrawer);

    // 键盘 Esc 快捷键关闭抽屉
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape' && drawer && drawer.classList.contains('open')) {
            closeDrawer();
        }
    });

    // 记住签认勾选状态并绑定提交签名按钮
    if (checkbox && sigInput && signBtn) {
        const confirmed = localStorage.getItem('aiae_grc_confirmed') === 'true';
        checkbox.checked = confirmed;
        
        // 初始高亮检查
        const lastSignature = localStorage.getItem('aiae_grc_last_signature');
        if (confirmed && lastSignature && trigger) {
            trigger.style.background = 'rgba(16, 185, 129, 0.25)';
            trigger.textContent = `🛡️ ${lastSignature} 已签认`;
        }

        checkbox.addEventListener('change', () => {
            if (!checkbox.checked) {
                localStorage.setItem('aiae_grc_confirmed', 'false');
                if (trigger) {
                    trigger.style.background = 'rgba(16, 185, 129, 0.15)';
                    trigger.textContent = '🛡️ 风控 SOP 百科';
                }
            }
        });

        signBtn.addEventListener('click', () => {
            if (!checkbox.checked) {
                alert('请先勾选：我已阅读并理解生产级风控合规纪律');
                return;
            }
            
            const operatorName = sigInput.value.trim().toUpperCase();
            if (!operatorName) {
                sigInput.style.borderColor = '#ef4444';
                sigInput.style.boxShadow = '0 0 8px rgba(239, 68, 68, 0.3)';
                setTimeout(() => {
                    sigInput.style.borderColor = 'rgba(255,255,255,0.08)';
                    sigInput.style.boxShadow = 'none';
                }, 2000);
                return;
            }
            
            // 构造签认审计记录
            const gapVal = _aiaeData ? (_aiaeData.position.gap ?? _aiaeData.position.gap_pt ?? 0) : 0;
            const regimeVal = _aiaeData ? _aiaeData.current.regime : 3;
            
            const record = {
                operator: operatorName,
                timestamp: new Date().toLocaleString('zh-CN'),
                regime: regimeVal,
                gap: gapVal
            };
            
            let history = [];
            try {
                history = JSON.parse(localStorage.getItem('aiae_grc_audit_history') || '[]');
            } catch(e) {
                history = [];
            }
            
            history.unshift(record);
            if (history.length > 3) {
                history = history.slice(0, 3);
            }
            
            localStorage.setItem('aiae_grc_audit_history', JSON.stringify(history));
            localStorage.setItem('aiae_grc_confirmed', 'true');
            localStorage.setItem('aiae_grc_last_signature', operatorName);
            
            checkbox.checked = true;
            sigInput.value = '';
            
            if (trigger) {
                trigger.style.background = 'rgba(16, 185, 129, 0.25)';
                trigger.textContent = `🛡️ ${operatorName} 已签认`;
            }
            
            renderGRCAuditTrail();
            
            // 提示签认成功并关闭抽屉
            const originalText = signBtn.textContent;
            signBtn.textContent = '✅ 已成功签认';
            signBtn.disabled = true;
            setTimeout(() => {
                signBtn.textContent = originalText;
                signBtn.disabled = false;
                closeDrawer();
            }, 1000);
        });
    }

    _grcDrawerBound = true;
}

// ── 动态合规警示渲染 ──
function renderAIAEGRCAlert(c, pd) {
    const alertEl = _aiaeDOM['grc-emergency-alert'];
    if (!alertEl) return;

    const gap = pd.gap ?? pd.gap_pt;
    const regime = c.regime;
    const ri = c.regime_info || {};

    let alertHtml = '';
    let levelClass = 'alert-level-green';

    // 场景 1：超额违规强平警告 (Regime 4/5 且实盘偏差为负或为正，只要实盘偏离严重)
    if (regime >= 4) {
        levelClass = 'alert-level-red';
        alertHtml = `🚨 <b>合规预警</b>：当前宏观定位为 <b style="color:${ri.color};">${ri.cn || '偏热'} (${regime}级)</b>。根据 GRC 一级防御铁律，<b>严禁在此状态下开新仓或追高进攻型标的！</b> 必须严格按照交易指令，每周强制降低总权益仓位上限至 ${ri.position || '25-40%'} 水平。`;
    } 
    // 场景 2：实盘仓位严重超配 (Critical Breach >15pt)
    else if (gap !== null && gap > 10.0) {
        levelClass = 'alert-level-red';
        alertHtml = `🚨 <b>合规违规</b>：当前仓位偏离度达 <b>+${gap.toFixed(1)} pt</b>，超出合规警示硬红线 (10.0pt)！属于<b>【严重超配违规】</b>，禁止因主观执念手动覆盖信号，请立即开启执行决策桌并启动 TWAP/VWAP 算法分拆减仓。`;
    } 
    // 场景 3：大底机会建仓提示
    else if (regime <= 2 && gap !== null && gap < -10.0) {
        levelClass = 'alert-level-blue';
        alertHtml = `💡 <b>合规建仓提示</b>：当前市场处于配置性极佳的 <b style="color:${ri.color};">${ri.cn || '底部'} (${regime}级)</b>，但实盘偏离度为 <b>${gap.toFixed(1)} pt</b> (严重欠配)。依据一级防御 SOP，建议利用盘中日度回踩机会，被动买入宽基 ETF 完成补仓，禁止单日一步满仓。`;
    }
    // 场景 4：常规超配或欠配警示（橙色警告，偏差处于 5 到 10pt 之间）
    else if (gap !== null && (gap > 5.0 || gap < -5.0)) {
        levelClass = 'alert-level-orange';
        const typeStr = gap > 0 ? '超配偏离' : '欠配偏离';
        alertHtml = `⚠️ <b>合规提示</b>：当前实盘处于常规 ${typeStr} 状态，偏离度为 <b>${gap > 0 ? '+' : ''}${gap.toFixed(1)} pt</b>，超出 5.0pt 软限限制。请投资经理与交易员密切监控，仓位调整建议利用执行桌算法分摊 1.5 - 2 天完成，禁止因主观情绪一步到位。`;
    }
    // 正常状态 (Gap 处于合规区间 [-5.0, 5.0]pt)
    else {
        levelClass = 'alert-level-green';
        alertHtml = `🟢 <b>合规运行中</b>：当前实盘与宏观 AIAE 偏离度为 <b>${gap >= 0 ? '+' : ''}${gap !== null ? gap.toFixed(1) : '0.0'} pt</b>，处于合规偏差允许区间 [-5.0, +5.0]pt 内。系统风控与三层防御正常运转。`;
    }

    // 设置警示类名并显示
    alertEl.className = 'aiae-grc-alert ' + levelClass;
    alertEl.innerHTML = alertHtml;
    alertEl.style.display = 'block';
}

function renderAIAEUI(data) {
    if (!data) return;
    _aiaeCacheDOM();  // 懒初始化 DOM 缓存
    try { bindGRCDrawer(); } catch(e) { console.warn('[AIAE GRC] Drawer bind error:', e); }
    const c = data.current;
    const p = data.position;
    const cv = data.cross_validation;
    const ri = c.regime_info;
    const basisVal = c.regime_basis_value !== undefined ? c.regime_basis_value : c.aiae_v1;
    const thresholds = c.regime_thresholds || [22.0, 24.0, 27.0, 29.0];

    // ── Hero Stats (使用 DOM 缓存) ──
    const $v = _aiaeDOM['hero-value'];
    const $r = _aiaeDOM['hero-regime'];
    const $p = _aiaeDOM['hero-position'];
    const $e = _aiaeDOM['hero-erp'];
    if ($v) $v.textContent = basisVal + '%';
    if ($r) { $r.textContent = `${ri.emoji} ${ri.cn}`; $r.style.color = ri.color; }
    if ($p && _amExecTarget == null) $p.textContent = p.matrix_position + '%';   // 执行目标到达后由 renderHeroExec 覆盖
    if ($e) { $e.textContent = cv.verdict; $e.style.color = cv.color; }

    // ── 宏观基准温度计 (2026-10-31: 放大线性标尺替代 0–50 仪表盘) ──
    try { renderThermo(c, ri, basisVal, thresholds); } catch(e) { console.warn('[AIAE] thermo skip:', e); }

    // ── Regime cards highlight ──
    // 2026-10-31: 区间随 V6-A 阈值动态生成 (原为写死的 V5 22/24/27/29)
    const _rcF = x => Number(x).toFixed(2).replace(/0$/, '');
    const _rcTip = { 1: '2018底 / 2024底', 2: '标准建仓', 3: '有纪律持有', 4: '持续减仓', 5: '2015泡沫 · 紧急防御' };
    document.querySelectorAll('.aiae-regime-card').forEach(card => {
        const r = parseInt(card.dataset.regime);
        card.classList.toggle('active', r === c.regime);
        const tip = card.querySelector('.aiae-rc-tip');
        if (tip && thresholds && thresholds.length === 4) {
            const rng = r === 1 ? `<${_rcF(thresholds[0])}%` : r === 5 ? `>${_rcF(thresholds[3])}%`
                : `${_rcF(thresholds[r - 2])}–${_rcF(thresholds[r - 1])}%`;
            tip.textContent = `AIAE_简 ${rng} · ${_rcTip[r]}`;
        }
    });

    // ── ZONE 2: Matrix highlight ──
    renderAIAEMatrix(p, cv, p.matrix, thresholds);

    // ── Allocations ──
    renderAIAEAllocs(p.allocations, p.matrix_position);

    // ── Cross validation (M1: 动态罗马数字映射, 修复硬编码 Ⅳ bug) ──
    const $cv = _aiaeDOM['cross-validation'];
    if ($cv) {
        const _romanMap = {1:'Ⅰ', 2:'Ⅱ', 3:'Ⅲ', 4:'Ⅳ', 5:'Ⅴ'};
        const _romanLabel = _romanMap[c.regime] || 'Ⅲ';
        $cv.innerHTML = `
            <div style="display:flex;align-items:center;gap:10px;">
                <span class="aiae-cross-stars">${cv.confidence_stars}</span>
                <span class="aiae-cross-verdict" style="color:${cv.color};">${cv.verdict}</span>
            </div>
            <div style="font-size:0.75rem;color:var(--text-muted);margin-top:6px;line-height:1.6;">
                AIAE ${_romanLabel}${c.regime}级 × ERP ${p.erp_value}% (${cv.erp_level}) · 置信度 ${cv.confidence}/5
            </div>
        `;
    }

    // ── ZONE 3: History chart (V5.1: 异步等待 ECharts 就绪) ──
    if (data.chart) {
        var _chartData = data.chart, _chartBasis = basisVal;
        try {
            if (typeof echarts !== 'undefined') { renderAIAEHistoryChart(_chartData, _chartBasis, thresholds); }
            else { _waitForECharts(function() { renderAIAEHistoryChart(_chartData, _chartBasis, thresholds); }); }
        } catch(e) { console.warn('[AIAE] chart skip:', e); }
    }

    // ── History summary current value (DOM 缓存) ──
    const $hc = _aiaeDOM['hist-current'];
    if ($hc) $hc.textContent = basisVal + '%';

    // ── ZONE 4: Signals ──
    renderAIAESignals(data.signals);

    // ── Warning Indicators ──
    try { renderAIAEWarnings(c); } catch(e) { console.warn('[AIAE] warnings skip:', e); }

    // ── V2.1: Fund Position Quarterly Reminder ──
    try { renderAIAEFundReminder(data.stale_data_warnings || []); } catch(e) { console.warn('[AIAE] fund reminder skip:', e); }

    // ── Action Dashboard ──
    try { renderAIAEActionDashboard(c.regime, ri, p.matrix_position, thresholds, basisVal); } catch(e) { console.warn('[AIAE] action skip:', e); }

    // ── ZONE 6: Factor Decomposition + HF (async, non-blocking) ──
    try { loadAndRenderZone6(); } catch(e) { console.warn('[AIAE] zone6 skip:', e); }

    // ── ZONE 7: Health + Cross-Market + Reconciliation (async, non-blocking) ──
    try { loadAndRenderZone7(); } catch(e) { console.warn('[AIAE] zone7 skip:', e); }

    // ── GRC: 生产级风控警告动态渲染 ──
    try { renderAIAEGRCAlert(c, p); } catch(e) { console.warn('[AIAE GRC] GRC alert render error:', e); }
}

// ── Warning Indicators V3.0 (机构级多维信号) ──
// ── 宏观基准温度计 (2026-10-31 重构): 放大线性标尺 + V6-A 阈值 + 距档位线距离 + 计算公式透明化 ──
function renderThermo(c, ri, basisVal, thresholds) {
    const t = (thresholds && thresholds.length === 4) ? thresholds.map(Number) : [22, 24, 27, 29];
    const v = Number(basisVal);
    const f1 = x => Number(x).toFixed(2).replace(/0$/, '');
    const R = _AM_REGIMES;
    const cur = R.find(x => x.r === c.regime) || R[2];
    const $v = document.getElementById('aiae-gauge-label');
    if ($v) { $v.textContent = isFinite(v) ? v.toFixed(2) : '—'; $v.style.color = cur.color; }
    const $r = document.getElementById('aiae-gauge-regime');
    if ($r) { $r.textContent = `${cur.name}级 · ${(ri && ri.cn) || cur.cn}`; $r.style.setProperty('--c', cur.color); }
    const sl = c.slope || {};
    const aux = c.aux_thresholds || {};
    const $s = document.getElementById('aiae-slope-indicator');
    if ($s) {
        const sv = Number(sl.slope || 0);
        const up = aux.slope_up ?? 1.5, dn = aux.slope_down ?? -1.5;
        const [txt, col] = sv > up ? ['加速上行 · 过热风险', '#ef4444'] : sv > 0 ? ['温和上行', '#f59e0b']
            : sv < dn ? ['加速回落 · 降温', '#10b981'] : sv < 0 ? ['温和回落', '#10b981'] : ['持平', '#94a3b8'];
        $s.innerHTML = `月环比 <b>${sv > 0 ? '+' : ''}${sv.toFixed(2)}pp</b> · ${txt}`;
        $s.style.setProperty('--c', col);
        $s.title = `AIAE_简 本月 − 上月月末; 超过 +${up}pp 视为加速上行, 低于 ${dn}pp 视为加速回落`;
    }
    // 标尺: 放大到 [t0−3, t3+3], 分档区间按实际宽度绘制
    const lo = Math.min(t[0] - 3, v - 0.5), hi = Math.max(t[3] + 3, v + 0.5);
    const pos = x => ((x - lo) / (hi - lo) * 100).toFixed(2) + '%';
    const edges = [lo, ...t, hi];
    const $sc = document.getElementById('aiae-thermo-scale');
    if ($sc) {
        const segs = R.map((x, i) => `<div class="am-tseg${x.r === c.regime ? ' on' : ''}" style="--c:${x.color};left:${pos(edges[i])};width:calc(${pos(edges[i + 1])} - ${pos(edges[i])})" title="${x.name}级 ${x.cn} · 宏观仓位 ${x.pos}"><span>${x.name}</span></div>`).join('');
        const ticks = t.map(x => `<div class="am-ttick" style="left:${pos(x)}"><span>${f1(x)}</span></div>`).join('');
        const mk = isFinite(v) ? `<div class="am-tmark" style="left:${pos(v)};--c:${cur.color}"><b>${v.toFixed(2)}</b></div>` : '';
        $sc.innerHTML = `<div class="am-ttrack">${segs}</div>${ticks}${mk}`;
    }
    const $d = document.getElementById('aiae-thermo-dist');
    if ($d && isFinite(v)) {
        const i = c.regime - 1;   // 当前档 Ri 的下沿 = t[i-1], 上沿 = t[i]
        const parts = [];
        if (i < 4) parts.push(`距 ${R[i + 1].name} 级线 ${f1(t[i])}% <b style="color:${R[i + 1].color}">+${(t[i] - v).toFixed(2)}pp</b>`);
        if (i > 0) parts.push(`距 ${R[i - 1].name} 级线 ${f1(t[i - 1])}% <b style="color:${R[i - 1].color}">−${(v - t[i - 1]).toFixed(2)}pp</b>`);
        const v6 = c.v6 || {};
        $d.innerHTML = parts.join('<span class="am-dot">·</span>')
            + (c.regime_mode === 'V6A_expanding' ? `<span class="am-dot">·</span><span class="am-muted" title="扩展窗口 P10/30/70/90, 截至 ${_amEsc(v6.through || '')}, ${v6.n_months || '?'} 个月; 换档有 ${v6.buffer ?? '—'}pp 缓冲带防抖">V6-A 动态阈值</span>`
                : '<span class="am-dot">·</span><span class="am-muted">V5 固定阈值</span>');
    }
    const $fm = document.getElementById('aiae-thermo-formula');
    if ($fm && c.total_mv_wan_yi && c.m2_wan_yi) {
        $fm.innerHTML = `= 总市值 ${Number(c.total_mv_wan_yi).toFixed(1)} 万亿 ÷ (总市值 + M2 ${Number(c.m2_wan_yi).toFixed(1)} 万亿)`;
    }
    const $meta = document.getElementById('aiae-thermo-meta');
    const mvd = (c.margin_heat_meta || {}).mv_trade_date;
    if ($meta && mvd) $meta.textContent = `市值数据 ${String(mvd).slice(0, 4)}-${String(mvd).slice(4, 6)}-${String(mvd).slice(6, 8)}`;
}

function _amAuxBar(el, value, stops, lo, hi, labels) {
    // stops: [[upTo, color], ...] 连续色段; 指针在 value
    if (!el) return;
    let prev = lo;
    const seg = stops.map(([upTo, col]) => { const w = (Math.min(upTo, hi) - prev) / (hi - lo) * 100; prev = Math.min(upTo, hi); return `<i style="width:${w}%;background:${col}"></i>`; }).join('');
    const p = Math.max(0, Math.min(100, (value - lo) / (hi - lo) * 100));
    const lab = labels.map(x => `<span style="left:${(x - lo) / (hi - lo) * 100}%">${x}</span>`).join('');
    el.innerHTML = `<div class="am-aux-track">${seg}</div><div class="am-aux-ptr" style="left:${p}%"></div><div class="am-aux-labels">${lab}</div>`;
}

function renderAIAEWarnings(c) {
    const aux = c.aux_thresholds || {};
    const mLow = aux.margin_low ?? 1.5, mWarn = aux.margin_warn ?? 3.0, mDan = aux.margin_danger ?? 3.5;
    // ── 融资热度 ── (颜色语义: 低 = 去杠杆 (绿), 中性 (灰蓝), 偏高 (黄), 散户杠杆 (红))
    const meta = c.margin_heat_meta || {};
    // 2026-11-04: 融资热度不可用 (缺数据 / 回退数据) → 显示 "--（降级）", 不用 0 顶替
    const mUnavail = c.margin_heat == null || !Number.isFinite(Number(c.margin_heat)) || meta.status === 'unavailable';
    const mv = mUnavail ? null : Number(c.margin_heat);
    const [mTxt, mCol] = mUnavail ? ['不可用（降级）', '#64748b'] : mv >= mDan ? ['散户杠杆涌入 · 高风险', '#ef4444'] : mv >= mWarn ? ['杠杆偏高 · 关注', '#f59e0b']
        : mv <= mLow ? ['杠杆出清 · 情绪低迷', '#10b981'] : ['杠杆水位正常', '#94a3b8'];
    const bad = !!meta.exchanges_incomplete;   // 只含沪市的旧缓存: 数值约为真实一半, 不做解读
    const $mv = document.getElementById('aiae-warn-margin-val');
    if ($mv) {
        $mv.textContent = mUnavail ? '--（降级）' : mv.toFixed(2) + '%';
        $mv.style.color = (bad || mUnavail) ? '#64748b' : mCol; $mv.style.textDecoration = (bad && !mUnavail) ? 'line-through' : '';
    }
    const $mn = document.getElementById('aiae-warn-margin-note');
    if ($mn) $mn.textContent = mUnavail ? `不可用（降级）：${meta.degraded_reason || '融资余额或总市值缺失'} · 不用缺省值`
        : bad ? '缺深市数据, 数值偏低, 暂不解读 · 下次刷新自动修正' : mTxt + ' · 融资余额 / 总市值';
    const $mt = document.getElementById('aiae-warn-margin-trend');
    if ($mt) {
        const md = meta.margin_trade_date ? String(meta.margin_trade_date).slice(4).replace(/(\d{2})(\d{2})/, '$1-$2') : '';
        if (mUnavail) { $mt.textContent = '降级'; $mt.className = 'am-aux-tag warn'; $mt.title = meta.degraded_reason || '融资热度不可用'; }
        else if (meta.exchanges_incomplete) { $mt.textContent = '⚠ 数据不全'; $mt.className = 'am-aux-tag warn'; $mt.title = '缓存的融资余额可能只含沪市, 待下次刷新'; }
        else if (meta.date_mismatch) { $mt.textContent = `⚠ 日期错配 ${meta.date_gap_days}天`; $mt.className = 'am-aux-tag warn'; }
        else { $mt.textContent = md ? `数据 ${md}` : '—'; $mt.className = 'am-aux-tag'; $mt.title = (meta.exchanges || []).join(' + '); }
    }
    const $mb = document.getElementById('aiae-warn-margin-bar');
    if (mUnavail) { if ($mb) $mb.innerHTML = ''; }
    else _amAuxBar($mb, mv, [[mLow, '#10b981'], [mWarn, '#475569'], [mDan, '#f59e0b'], [5, '#ef4444']], 0, 5, [mLow, mWarn, mDan]);

    // ── 基金仓位 ── (同花顺日频估算, 自动抓取; 85/90 为经验参考线)
    const fv = Number(c.fund_position || 0);
    const [fTxt, fCol] = fv >= 90 ? ['机构高仓位 · 加仓空间小', '#ef4444'] : fv >= 85 ? ['机构仓位偏高', '#f59e0b']
        : fv <= 75 ? ['机构仓位偏低 · 有加仓空间', '#10b981'] : ['机构仓位中性', '#94a3b8'];
    const $fv = document.getElementById('aiae-warn-fund-val');
    if ($fv) { $fv.textContent = fv.toFixed(2) + '%'; $fv.style.color = fCol; $fv.title = fTxt; }
    _amAuxBar(document.getElementById('aiae-warn-fund-bar'), fv,
        [[75, '#10b981'], [85, '#475569'], [90, '#f59e0b'], [100, '#ef4444']], 60, 100, [75, 85, 90]);
    const fDate = c.fund_position_date || '';
    const days = fDate ? Math.floor((Date.now() - new Date(fDate).getTime()) / 86400000) : null;
    const $fd = document.getElementById('aiae-data-fund-date');
    if ($fd) $fd.textContent = fDate || '未知';
    const $ft = document.getElementById('aiae-warn-fund-trend');
    if ($ft) {
        const src = String(c.fund_position_source || '');
        const auto = /ths|auto|10jqka/i.test(src);
        if (days != null && days > 7) { $ft.textContent = `⚠ ${days} 天未更新`; $ft.className = 'am-aux-tag ' + (days > 30 ? 'bad' : 'warn'); }
        else { $ft.textContent = auto ? '日频 · 自动' : '手动录入'; $ft.className = 'am-aux-tag'; }
        $ft.title = `来源: ${src || '未知'}`;
    }
    const $fs = document.getElementById('aiae-fund-stale-badge');
    if ($fs) $fs.style.display = 'none';
}

// ── V2.1: Fund Position Quarterly Reminder ──
function renderAIAEFundReminder(staleWarnings) {
    const banner = document.getElementById('aiae-fund-reminder-banner');
    if (!banner) return;

    // 查找基金仓位相关告警
    const fundWarning = staleWarnings.find(w => w.type === 'fund_update_due' || w.type === 'fund_position_stale');
    if (!fundWarning) {
        banner.style.display = 'none';
        return;
    }

    banner.style.display = 'block';

    // 设置标签
    const labelEl = document.getElementById('aiae-fund-reminder-label');
    if (labelEl) {
        const severity = fundWarning.severity === 'critical' ? '🔴 紧急' : '🟡 提醒';
        labelEl.textContent = severity + (fundWarning.expected_label ? ' · ' + fundWarning.expected_label : '');
    }

    // 设置消息
    const msgEl = document.getElementById('aiae-fund-reminder-message');
    if (msgEl) {
        const days = fundWarning.days_stale || 0;
        msgEl.innerHTML = fundWarning.message + 
            '<br><span style="color:#64748b;">当前值: ' + (fundWarning.current_value||'--') + '% · 截至 ' + (fundWarning.current_date||'--') + 
            ' · 滞后 <b style="color:#f59e0b;">' + days + '</b> 天 · 占 AIAE_V1 权重 30%</span>';
    }

    // 如果是 critical 级别，加脉冲动画
    if (fundWarning.severity === 'critical') {
        banner.style.animation = 'pulse 2s infinite';
        banner.style.borderColor = 'rgba(239,68,68,0.4)';
    } else {
        banner.style.animation = 'none';
        banner.style.borderColor = 'rgba(245,158,11,0.3)';
    }

    // P1: 基金更新 toggle 按钮事件绑定 (替代 inline onclick)
    const toggleBtn = document.getElementById('aiae-fund-update-toggle');
    if (toggleBtn && !toggleBtn._bound) {
        toggleBtn.addEventListener('click', () => {
            const panel = document.getElementById('aiae-fund-update-panel');
            if (panel) panel.style.display = panel.style.display === 'none' ? 'block' : 'none';
        });
        toggleBtn._bound = true;
    }
}

// ── V2.1: Fund Position Update Submit ──
async function submitFundPositionUpdate() {
    const valueEl = document.getElementById('aiae-fund-input-value');
    const dateEl = document.getElementById('aiae-fund-input-date');
    const resultEl = document.getElementById('aiae-fund-update-result');
    const submitBtn = document.getElementById('aiae-fund-submit-btn');

    if (!valueEl || !dateEl) return;
    const value = parseFloat(valueEl.value);
    const date = dateEl.value;

    if (isNaN(value) || value < 50 || value > 100) {
        if (resultEl) { resultEl.textContent = '❌ 仓位值须在 50-100% 之间'; resultEl.style.color = '#ef4444'; }
        return;
    }

    if (submitBtn) { submitBtn.disabled = true; submitBtn.textContent = '⏳ 提交中...'; }
    if (resultEl) { resultEl.textContent = '⏳ 正在更新...'; resultEl.style.color = '#f59e0b'; }

    try {
        const resp = await AC.secureFetch('/api/v1/aiae/update_fund_position', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ value: value, date: date })
        });
        const json = await resp.json();

        if (json.status === 'success') {
            if (resultEl) { resultEl.innerHTML = '✅ 更新成功! ' + json.message + ' <span style="color:#64748b;">· 3秒后自动刷新数据...</span>'; resultEl.style.color = '#10b981'; }
            // 隐藏提醒 banner
            const banner = document.getElementById('aiae-fund-reminder-banner');
            if (banner) banner.style.display = 'none';
            // 3秒后自动刷新报告
            setTimeout(() => {
                document.getElementById('aiae-fund-update-panel').style.display = 'none';
                loadAIAEReport(true);  // 强制刷新
            }, 3000);
        } else {
            if (resultEl) { resultEl.textContent = '❌ ' + (json.message || '更新失败'); resultEl.style.color = '#ef4444'; }
        }
    } catch(e) {
        console.error('[AIAE Fund Update] Error:', e);
        if (resultEl) { resultEl.textContent = '❌ 网络异常: ' + e.message; resultEl.style.color = '#ef4444'; }
    } finally {
        if (submitBtn) { submitBtn.disabled = false; submitBtn.textContent = '✅ 提交更新'; }
    }
}

// ── 交易指令面板 · 宏观背景 (2026-10-31 重构): 只渲染当前档位指引 + 五档标尺; 阈值随 V6-A 动态, 不再写死 27% ──
const _AM_REGIMES = [
    { r: 1, name: 'Ⅰ', cn: '极低估值', pos: '60-80%', color: '#10b981' },
    { r: 2, name: 'Ⅱ', cn: '低估区', pos: '50-75%', color: '#3b82f6' },
    { r: 3, name: 'Ⅲ', cn: '中性均衡', pos: '35-65%', color: '#eab308' },
    { r: 4, name: 'Ⅳ', cn: '偏高区域', pos: '15-40%', color: '#f97316' },
    { r: 5, name: 'Ⅴ', cn: '极度过热', pos: '0-15%', color: '#ef4444' },
];

function renderAIAEActionDashboard(regime, ri, matrixPos, thresholds, value) {
    const t = (thresholds && thresholds.length === 4) ? thresholds : [22.0, 24.0, 27.0, 29.0];
    const f = v => Number(v).toFixed(1).replace(/\.0$/, '');
    const guide = {
        1: [`AIAE_简 < ${f(t[0])}%: 恐慌区, 宏观上允许分批越跌越买`, '优先宽基 ETF (300/50/500/创业板), 红利同步配置底仓', '仍受组合波动预算与回撤刹车约束'],
        2: [`AIAE_简 ${f(t[0])}–${f(t[1])}%: 标准建仓区`, '按节奏建仓, 宽基 + 红利均衡; ERP 高时可加大力度', '不因短期波动减仓; 止损触发时被动减仓'],
        3: ['宏观中性: 不主动加仓, 新增仓位 ≤ 总仓 5% 且需子策略强信号', '偏向宽基 + 红利, 减少进攻型标的; 到止盈目标就卖',
            `若 AIAE_简 升至 ${f(t[2])}% (Ⅳ级线) 以上, 宏观上限降至 15–40%`],
        4: [`AIAE_简 ${f(t[2])}–${f(t[3])}%: 禁止新开仓`, '每周减约 5% 总仓位, 优先清退高波动标的', '红利型可继续持有'],
        5: [`AIAE_简 > ${f(t[3])}%: 泡沫区, 禁止任何买入`, '3 天内清仓至 ≤ 15%, 仅保留红利防御', '无例外, 不抄底'],
    };
    const cur = _AM_REGIMES.find(x => x.r === regime) || _AM_REGIMES[2];
    const $reg = document.getElementById('aiae-macro-regime');
    if ($reg) {
        $reg.innerHTML = `<b style="color:${cur.color}">${cur.name}级 ${(ri && ri.cn) || cur.cn}</b>`
            + ` · 宏观上限 ${matrixPos != null ? matrixPos + '%' : '—'}`;
    }
    const $scale = document.getElementById('aiae-regime-scale');
    if ($scale) {
        const bounds = ['', ...t.map(f)];
        $scale.innerHTML = _AM_REGIMES.map((x, i) => {
            const on = x.r === regime;
            const rng = i === 0 ? `<${bounds[1]}` : i === 4 ? `>${bounds[4]}` : `${bounds[i]}–${bounds[i + 1]}`;
            return `<div class="am-seg${on ? ' on' : ''}" style="--c:${x.color}" title="${x.name}级 ${x.cn} · AIAE_简 ${rng}% · 宏观仓位 ${x.pos}">`
                + `<i></i><b>${x.name}</b><small>${rng}%</small>`
                + (on && value != null ? `<em>${f(value)}%</em>` : '') + '</div>';
        }).join('');
    }
    const $list = document.getElementById('aiae-macro-list');
    if ($list) $list.innerHTML = (guide[regime] || guide[3]).map(s => `<li>${_amEsc(s)}</li>`).join('');
}

// ── 2026-10-31: 宏观上限 → 执行目标 的传导 (Hero / 上限链 / 子策略配额统一到执行目标) ──
let _amLastAllocs = null;
let _amExecTarget = null;

function renderHeroExec(dev) {
    const et = dev && dev.execution_target;
    const pd = (dev && dev.position_deviation) || {};
    const $p = document.getElementById('aiae-hero-position');
    const $l = document.getElementById('aiae-hero-position-label');
    const $s = document.getElementById('aiae-hero-position-sub');
    if (!et || !$p) return;
    _amExecTarget = Number(et.target_pct);
    const col = { reduce: '#ef4444', pause: '#eab308', hold: '#10b981', add: '#3b82f6' }[et.zone] || '#10b981';
    if ($l) $l.textContent = '执行目标';
    $p.textContent = Number(et.target_pct).toFixed(0) + '%';
    $p.style.color = col;
    if ($s) {
        const tag = { reduce: '须降仓', pause: '暂停加仓', hold: '维持', add: '可加仓' }[et.zone] || '';
        $s.innerHTML = `<b style="color:${col}">${tag}</b> · 实际 ${pd.actual_pct != null ? Number(pd.actual_pct).toFixed(0) + '%' : '—'}`
            + ` · AIAE 上限 ${pd.base_suggested_pct ?? pd.suggested_pct ?? '—'}%`;
    }
    if (_amLastAllocs) renderAIAEAllocs(_amLastAllocs[0], _amLastAllocs[1]);
}

function renderCapChain(dev, dd) {
    const box = document.getElementById('aiae-cap-chain');
    if (!box || !dev) return;
    const pd = dev.position_deviation || {};
    const et = dev.execution_target;
    const vb = dev.vol_budget || {};
    const brake = (dd && dd.brake) || null;
    const steps = [];
    const num = v => (v === null || v === undefined || !isFinite(Number(v))) ? null : Number(v);
    const base = num(pd.base_suggested_pct);
    if (base != null) steps.push({ k: 'AIAE × ERP 矩阵', v: base, note: '宏观估值上限 (按大盘 β 标定)' });
    const sug = num(pd.suggested_pct);
    if (sug != null && base != null && Math.abs(sug - base) > 0.05)
        steps.push({ k: '× 市场尾部刹车', v: sug, note: `沪深300 波动系数 ${pd.vol_factor ?? '—'}` });
    else if (sug != null) steps.push({ k: '× 市场尾部刹车', v: sug, note: `系数 ${pd.vol_factor ?? '1.0'} · 未触发` });
    const vbv = num(vb.max_equity_pct);
    if (vbv != null) steps.push({ k: '组合波动预算', v: vbv, note: '按你的持仓结构反算的权益上限' });
    const bc = brake ? num(brake.cap_pct) : null;
    if (bc != null) steps.push({ k: '回撤刹车', v: bc, note: brake.label || `第 ${brake.tier} 档` });
    if (!steps.length) { box.style.display = 'none'; return; }
    const binding = Math.min(...steps.map(s => s.v));
    const tgt = et ? num(et.target_pct) : null;
    box.style.display = 'block';
    box.innerHTML = `<div class="am-sub-head"><span class="am-h" title="有效上限 = 各约束取最小; 执行目标再经执行层节奏规则 (下调立即生效, 上调每周最多 +10pp)">上限传导 · 为什么不是 ${base ?? '—'}%</span>`
        + `<span class="am-muted">取最小值 = ${binding}%</span></div>`
        + steps.map(s => {
            const on = s.v === binding;
            return `<div class="am-chain-row${on ? ' on' : ''}"><span class="am-chain-k">${_amEsc(s.k)}${on ? ' <em>约束项</em>' : ''}</span>`
                + `<span class="am-chain-bar"><i style="width:${Math.max(0, Math.min(100, s.v))}%"></i></span>`
                + `<span class="am-chain-v">${s.v}%</span><small>${_amEsc(s.note)}</small></div>`;
        }).join('')
        + (tgt != null ? `<div class="am-chain-row target"><span class="am-chain-k">执行目标</span><span class="am-chain-bar"><i style="width:${tgt}%"></i></span>`
            + `<span class="am-chain-v">${tgt}%</span><small>${tgt === binding ? '= 有效上限' : '节奏规则: 上调每周最多 +10pp'}</small></div>` : '');
}

// ── 交易指令 · 执行层指令卡 (← /aiae/deviation.execution_target) ──
function renderOrderCommand(dev) {
    const box = document.getElementById('aiae-order-cmd');
    if (!box || !dev) return;
    const et = dev.execution_target;
    const pd = dev.position_deviation || {};
    const meta = document.getElementById('aiae-order-meta');
    if (!et) {
        box.className = 'am-cmd unknown';
        box.innerHTML = `<div class="am-cmd-main"><span class="am-cmd-tag">待评估</span><span class="am-cmd-title">执行层目标暂不可用</span></div>`
            + `<div class="am-cmd-text">打开「决策中枢」完成一次执行层评估后显示指令; 在此之前请参考 AIAE 建议 ${pd.suggested_pct ?? '—'}% 与回撤刹车, 不要据此加仓。</div>`;
        if (meta) meta.textContent = '执行层 · 未评估';
        return;
    }
    const Z = { reduce: ['reduce', '须降仓'], pause: ['pause', '暂停加仓'], hold: ['hold', '维持'], add: ['add', '可加仓 (需信号)'] };
    const [cls, tag] = Z[et.zone] || ['hold', et.zone];
    const trig = { risk_event: '风险事件', weekly_eval: '周评估', weekly: '周评估' }[et.last_trigger] || et.last_trigger || '';
    const md = s => s ? String(s).slice(5) : '—';
    box.className = `am-cmd ${cls}`;
    box.innerHTML = `<div class="am-cmd-main"><span class="am-cmd-tag">${tag}</span>`
        + `<span class="am-cmd-title">${pd.actual_pct != null ? Number(pd.actual_pct).toFixed(1) + '%' : '—'}`
        + ` <span class="am-arrow">→</span> ${Number(et.target_pct).toFixed(0)}%</span>`
        + `<span class="am-cmd-gap">${et.gap > 0 ? '+' : ''}${Number(et.gap).toFixed(1)}pp</span></div>`
        + `<div class="am-cmd-text">${_amEsc(et.instruction || '')}</div>`
        + `<div class="am-cmd-foot"><span>目标生效 ${md(et.last_change)}${trig ? ' · ' + trig : ''}</span>`
        + `<span>下次评估 ${md(et.next_eval_date)} (周五)</span></div>`;
    if (meta) meta.textContent = `执行层 ${et.params_version || ''}`.trim();
}

// ── 交易指令 · 降仓清单 (← /portfolio/drawdown.brake.plan, 与决策页回撤刹车同一份清单) ──
async function loadAndRenderOrderPlan(dev) {
    const wrap = document.getElementById('aiae-plan');
    if (!wrap) return;
    let dd = null;
    try {
        const resp = await fetch('/api/v1/portfolio/drawdown', { signal: AbortSignal.timeout(20000) });
        const js = await resp.json();
        dd = js && js.status === 'success' ? (js.data || null) : null;
    } catch (e) { console.warn('[AIAE] drawdown plan skip:', e); }
    try { renderCapChain(dev, dd); } catch (e) { console.warn('[AIAE] cap chain skip:', e); }
    const et = dev && dev.execution_target;
    const needReduce = et && et.zone === 'reduce';
    const plan = dd && dd.brake && dd.brake.plan;
    const items = (plan && plan.items) || [];
    const $sum = document.getElementById('aiae-plan-sum');
    const $steps = document.getElementById('aiae-plan-steps');
    const $list = document.getElementById('aiae-plan-list');
    const $note = document.getElementById('aiae-plan-note');
    const wan = v => (Number(v) / 10000).toFixed(1) + ' 万';
    if (!items.length) {
        // 无回撤刹车清单: 须降仓时给出等比估算 (来自 execution_cost), 否则隐藏
        const ec = dev && dev.execution_cost;
        if (!needReduce || !ec || !(ec.orders || []).length) { wrap.style.display = 'none'; return; }
        wrap.style.display = 'block';
        if ($sum) $sum.textContent = `合计约 ${wan(ec.trade_value)} · 等比估算`;
        if ($steps) $steps.innerHTML = '';
        if ($list) $list.innerHTML = ec.orders.slice(0, 15).map((o, i) =>
            `<div class="am-order"><span class="am-ostep muted">等比</span><span class="am-oname"><b>${_amEsc(o.name)}</b><small>${_amEsc(o.ts_code)}</small></span>`
            + `<span class="am-oqty">—</span><span class="am-oval">${wan(o.amount)}</span></div>`).join('');
        if ($note) $note.textContent = '当前无回撤刹车清单, 以上按持仓市值等比估算 (未取整到手); 实际下单前请在决策中枢核对。';
        return;
    }
    wrap.style.display = 'block';
    const STEP = { 1: ['red', '止损'], 2: ['legacy', '越线'], 3: ['amber', '超预算'], 4: ['muted', '等比'] };
    const byStep = {};
    items.forEach(i => { (byStep[i.step] = byStep[i.step] || { n: 0, v: 0 }); byStep[i.step].n++; byStep[i.step].v += Number(i.value) || 0; });
    const b = dd.brake || {};
    if ($sum) {
        const after = plan.after_invested_pct;
        const gapNote = (et && after != null && after > et.target_pct + 0.5)
            ? ` · 距执行目标 ${et.target_pct}% 还差 ${(after - et.target_pct).toFixed(1)}pp` : '';
        $sum.textContent = `${items.length} 笔 · 合计 ${wan(plan.total)} · 执行后约 ${after ?? '—'}%${gapNote}`;
    }
    if ($steps) {
        $steps.innerHTML = Object.keys(byStep).sort().map(k => {
            const [cls, tag] = STEP[k] || ['muted', '其他'];
            return `<span class="am-ostep ${cls}">${tag} ${byStep[k].n} 笔 · ${wan(byStep[k].v)}</span>`;
        }).join('') + (b.label ? `<span class="am-muted" style="margin-left:auto;">${_amEsc(b.label)}</span>` : '');
    }
    if ($list) {
        $list.innerHTML = items.map(i => {
            const [cls, tag] = STEP[i.step] || ['muted', ''];
            return `<div class="am-order" title="${_amEsc(i.reason)}"><span class="am-ostep ${cls}">${tag}</span>`
                + `<span class="am-oname"><b>${_amEsc(i.name)}</b><small>${_amEsc(i.ts_code)}${i.remaining_qty ? '' : ' · 清仓'}</small></span>`
                + `<span class="am-oqty">${Number(i.qty).toLocaleString('zh-CN')} 股</span>`
                + `<span class="am-oval">${wan(i.value)}</span></div>`;
        }).join('');
    }
    if ($note) $note.textContent = (plan.note || '') + ' · 清单与决策中枢「降仓清单」为同一份。';
}


// ── ECharts Gauge V2.0 ──
function renderAIAEGauge(value, regime, ri, thresholds) {
    const container = document.getElementById('aiae-gauge-container');
    if (!container || typeof echarts === 'undefined') return;
    try { window._aiaeGaugeChart = AC.disposeChart(window._aiaeGaugeChart); } catch(_) {}
    window._aiaeGaugeChart = AC.registerChart(echarts.init(container));

    const v = Math.min(Math.max(value, 0), 50);
    const t = thresholds || [22.0, 24.0, 27.0, 29.0];

    window._aiaeGaugeChart.setOption({
        series: [{
            type: 'gauge',
            startAngle: 200,
            endAngle: -20,
            min: 0,
            max: 50,
            pointer: {
                show: true,
                length: '58%',
                width: 4,
                itemStyle: { color: ri.color, shadowColor: ri.color, shadowBlur: 8 },
                icon: 'triangle'
            },
            anchor: {
                show: true,
                size: 10,
                itemStyle: { color: '#0f172a', borderColor: ri.color, borderWidth: 3 }
            },
            axisLine: {
                lineStyle: {
                    width: 14,
                    color: [
                        [t[0] / 50, '#10b981'],
                        [t[1] / 50, '#3b82f6'],
                        [t[2] / 50, '#eab308'],
                        [t[3] / 50, '#f97316'],
                        [1, '#ef4444']
                    ]
                }
            },
            axisTick: {
                length: 8,
                distance: -14,
                lineStyle: { color: 'auto', width: 1.5 }
            },
            splitLine: {
                length: 14,
                distance: -14,
                lineStyle: { color: 'auto', width: 2 }
            },
            splitNumber: 5,
            axisLabel: {
                distance: -36,
                color: '#64748b',
                fontSize: 9,
                formatter: function(val) {
                    var map = {0: '0', 10: '10', 20: '20', 40: '40', 50: '50'};
                    map[Math.round(t[0])] = 'Ⅰ';
                    map[Math.round(t[1])] = 'Ⅱ';
                    map[Math.round(t[2])] = 'Ⅲ';
                    map[Math.round(t[3])] = 'Ⅳ';
                    return map[val] || '';
                }
            },
            detail: { show: false },
            data: [{ value: v }],
            animationDuration: 1200,
            animationEasingUpdate: 'cubicOut'
        }]
    });
}

// ── History Chart V2.0 (五档 markArea 色带) ──
function renderAIAEHistoryChart(chart, currentValue, thresholds) {
    const container = document.getElementById('aiae-history-chart');
    if (!container || typeof echarts === 'undefined') return;
    try {
        try { if (window._aiaeHistChart) AC.disposeChart(window._aiaeHistChart); } catch(_) {}
        window._aiaeHistChart = AC.registerChart(echarts.init(container));

        const t = thresholds || [22.0, 24.0, 27.0, 29.0];

        // 五档区间色带
        const markAreaData = [
            [{ yAxis: 0, itemStyle: { color: 'rgba(16,185,129,0.06)' } }, { yAxis: t[0] }],   // Ⅰ
            [{ yAxis: t[0], itemStyle: { color: 'rgba(59,130,246,0.05)' } }, { yAxis: t[1] }],   // Ⅱ
            [{ yAxis: t[1], itemStyle: { color: 'rgba(234,179,8,0.05)' } }, { yAxis: t[2] }],    // Ⅲ
            [{ yAxis: t[2], itemStyle: { color: 'rgba(249,115,22,0.06)' } }, { yAxis: t[3] }],   // Ⅳ
            [{ yAxis: t[3], itemStyle: { color: 'rgba(239,68,68,0.06)' } }, { yAxis: 50 }],    // Ⅴ
        ];

        // 分界参考线
        const markLines = t.map((val, idx) => {
            const labels = ['Ⅰ|Ⅱ', 'Ⅱ|Ⅲ', 'Ⅲ|Ⅳ', 'Ⅳ|Ⅴ'];
            return {
                yAxis: val,
                lineStyle: { color: val <= t[1] ? '#3b82f644' : (val <= t[2] ? '#eab30844' : '#ef444444'), type: 'dashed', width: 1 },
                label: {
                    formatter: labels[idx] || '',
                    position: 'end', color: '#64748b', fontSize: 9
                }
            };
        });

            // V3.1: 根据数据密度自适应标记大小和标签显示
            const isSparse = chart.values.length <= 12;
            const symbolSizes = chart.labels.map(l => l ? (isSparse ? 10 : 7) : (isSparse ? 10 : 3));
            window._aiaeHistChart.setOption({
                backgroundColor: 'transparent',
                tooltip: {
                    trigger: 'axis',
                    backgroundColor: 'rgba(15,23,42,0.95)',
                    borderColor: 'rgba(245,158,11,0.3)',
                    textStyle: { color: '#e2e8f0', fontSize: 11 },
                    formatter: function(params) {
                        if (!params.length) return '';
                        const p = params[0];
                        const idx = chart.dates.indexOf(p.axisValue);
                        const label = idx >= 0 && chart.labels[idx] ? chart.labels[idx] : '';
                        const val = p.value;
                        let tierLabel = '';
                        if (val < t[0]) tierLabel = '<span style="color:#10b981">Ⅰ级 极度恐慌</span>';
                        else if (val < t[1]) tierLabel = '<span style="color:#3b82f6">Ⅱ级 低配置区</span>';
                        else if (val < t[2]) tierLabel = '<span style="color:#eab308">Ⅲ级 中性均衡</span>';
                        else if (val < t[3]) tierLabel = '<span style="color:#f97316">Ⅳ级 偏热区域</span>';
                        else tierLabel = '<span style="color:#ef4444">Ⅴ级 极度过热</span>';
                        return '<b>' + p.axisValue + '</b><br/>' +
                            '<span style="color:#f59e0b">●</span> AIAE: <b>' + p.value + '%</b><br/>' +
                            tierLabel +
                            (label ? '<br/><span style="color:#94a3b8">' + label + '</span>' : '');
                    }
                },
                grid: { left: 55, right: 30, top: 32, bottom: 32 },
                xAxis: {
                    type: 'category', data: chart.dates, boundaryGap: false,
                    axisLabel: { color: '#64748b', fontSize: 9, formatter: function(v) { return v.substring(0, 7); } },
                    axisLine: { lineStyle: { color: '#334155' } }
                },
                yAxis: {
                    type: 'value', min: 0, max: 50,
                    axisLabel: { color: '#64748b', fontSize: 9, formatter: function(v) { return v + '%'; } },
                    splitLine: { lineStyle: { color: 'rgba(255,255,255,0.04)' } }
                },
                series: [{
                    type: 'line', data: chart.values, smooth: true,
                    symbol: 'circle', symbolSize: symbolSizes,
                    lineStyle: { color: '#f59e0b', width: isSparse ? 3 : 2, shadowColor: 'rgba(245,158,11,0.3)', shadowBlur: 6 },
                    itemStyle: { color: '#f59e0b', borderColor: '#0f172a', borderWidth: 2 },
                    areaStyle: {
                        color: { type: 'linear', x: 0, y: 0, x2: 0, y2: 1,
                            colorStops: [
                                { offset: 0, color: 'rgba(245,158,11,0.25)' },
                                { offset: 1, color: 'rgba(245,158,11,0)' }
                            ]
                        }
                    },
                    label: {
                        show: true, fontSize: 8, color: '#f59e0b',
                        formatter: function(p) {
                            // V3.1: 仅在有标注的关键节点上显示标签, 避免密集数据时标签重叠
                            const idx = p.dataIndex;
                            if (chart.labels[idx]) return p.value + '%';
                            return '';
                        },
                        position: 'top'
                    },
                    markArea: { silent: true, data: markAreaData },
                    markLine: { silent: true, symbol: 'none', data: markLines }
                }]
            });
    } catch(err) {
        console.warn('[AIAE] History chart error:', err);
    }
}


function renderAIAEMatrix(pos, cv, apiMatrix, thresholds) {
    const table = document.getElementById('aiae-matrix-table');
    if (!table) return;

    // ── 从 API matrix dict 构建 posValues 二维数组 (行序: erp_gt6 → erp_lt2) ──
    const erpKeys = ['erp_gt6', 'erp_4_6', 'erp_2_4', 'erp_lt2'];
    const fallbackMatrix = {erp_gt6:[80,75,65,40,15], erp_4_6:[75,70,60,35,10], erp_2_4:[70,60,50,25,5], erp_lt2:[60,50,35,15,0]};
    const mx = apiMatrix || fallbackMatrix;
    const posValues = erpKeys.map(k => mx[k] || fallbackMatrix[k]);

    // ── 从 API thresholds 动态生成列头 ──
    const t = thresholds || [22.0, 24.0, 27.0, 29.0];
    const thead = table.querySelector('thead tr');
    if (thead) {
        const thLabels = [
            '<' + t[0] + '%',
            t[0] + '-' + t[1] + '%',
            t[1] + '-' + t[2] + '%',
            t[2] + '-' + t[3] + '%',
            '>' + t[3] + '%'
        ];
        const regimeLabels = ['Ⅰ级','Ⅱ级','Ⅲ级','Ⅳ级','Ⅴ级'];
        thead.innerHTML = '<th></th>' + regimeLabels.map((r, i) =>
            '<th>' + r + '<br><span style="font-size:0.55rem;">' + thLabels[i] + '</span></th>'
        ).join('');
    }

    // ── 动态填充格子文本 + 热力图着色 ──
    function posColor(v) {
        if (v >= 80) return 'rgba(16,185,129,0.2)';
        if (v >= 60) return 'rgba(52,211,153,0.12)';
        if (v >= 40) return 'rgba(234,179,8,0.1)';
        if (v >= 20) return 'rgba(249,115,22,0.12)';
        return 'rgba(239,68,68,0.15)';
    }

    const rows = table.querySelectorAll('tbody tr');
    rows.forEach((row, ri) => {
        const cells = row.querySelectorAll('td');
        cells.forEach((td, ci) => {
            td.classList.remove('aiae-matrix-active');
            if (ci > 0 && posValues[ri]) {
                const val = posValues[ri][ci - 1];
                td.textContent = val + '%';
                td.style.background = posColor(val);
            }
        });
    });

    // ── 高亮当前交叉位置 ──
    const erpMap = { 'erp_gt6': 0, 'erp_4_6': 1, 'erp_2_4': 2, 'erp_lt2': 3 };
    const rowIdx = erpMap[pos.erp_level] ?? 2;
    const colIdx = Math.min(pos.regime - 1, 4);
    if (rows[rowIdx]) {
        const cells = rows[rowIdx].querySelectorAll('td');
        if (cells[colIdx + 1]) cells[colIdx + 1].classList.add('aiae-matrix-active');
    }

    // ── verdict (含平滑修正透明度) ──
    const regimeNames = {1:'Ⅰ', 2:'Ⅱ', 3:'Ⅲ', 4:'Ⅳ', 5:'Ⅴ'};
    const $verdict = document.getElementById('aiae-matrix-verdict');
    if ($verdict) {
        const rawCell = posValues[rowIdx] ? posValues[rowIdx][colIdx] : null;
        const smoothNote = (rawCell !== null && rawCell !== pos.matrix_position)
            ? ' <span style="font-size:0.62rem;color:#94a3b8;">(含分界线平滑修正，原始格值' + rawCell + '%)</span>'
            : '';
        $verdict.innerHTML = '当前: <b style="color:#f59e0b">' + regimeNames[pos.regime] + '级</b>' +
            ' × <b style="color:#60a5fa">ERP ' + pos.erp_value + '%</b>' +
            ' → 宏观上限 <b style="color:#10b981;font-size:1.1rem;">' + pos.matrix_position + '%</b>' + smoothNote +
            ' <span style="font-size:0.62rem;color:#64748b;">(执行目标见下方上限传导)</span>';
    }
}

function renderAIAEAllocs(allocs, totalPos) {
    if (!allocs) return;
    _amLastAllocs = [allocs, totalPos];
    // 2026-10-31: 各子策略仓位按执行目标折算 (原按 AIAE 宏观上限, 合计会超过实际可持有仓位)
    const base = _amExecTarget != null ? _amExecTarget : totalPos;
    const $basis = document.getElementById('aiae-alloc-basis');
    if ($basis) $basis.textContent = _amExecTarget != null ? `· 按执行目标 ${base}% 折算 (宏观上限 ${totalPos}%)` : `· 按 AIAE 宏观上限 ${totalPos}%`;
    // M2: 新增 aiae_etf 第5策略配额 (金色主题)
    const strategies = ['mr', 'div', 'mom', 'gem', 'erp', 'aiae_etf'];
    strategies.forEach(key => {
        const a = allocs[key];
        if (!a) {
            // aiae_etf 可能不在后端 allocations 中, 用 JOINT_WEIGHTS 补算
            if (key === 'aiae_etf') {
                const etfPct = 100 - Object.values(allocs).reduce((s, v) => s + (v.pct || 0), 0);
                const etfPos = Math.round(base * Math.max(etfPct, 0) / 100 * 10) / 10;
                const $pct = document.getElementById('aiae-alloc-aiae_etf-pct');
                const $pos = document.getElementById('aiae-alloc-aiae_etf-pos');
                const $bar = document.getElementById('aiae-alloc-aiae_etf-bar');
                if ($pct) $pct.textContent = Math.max(etfPct, 0) + '%';
                if ($pos) $pos.textContent = etfPos + '% 仓位';
                if ($bar) $bar.style.width = Math.min(Math.max(etfPct, 0), 100) + '%';
            }
            return;
        }
        const $pct = document.getElementById(`aiae-alloc-${key}-pct`);
        const $pos = document.getElementById(`aiae-alloc-${key}-pos`);
        const $bar = document.getElementById(`aiae-alloc-${key}-bar`);
        if ($pct) $pct.textContent = a.pct + '%';
        if ($pos) $pos.textContent = (Math.round(base * a.pct / 10) / 10) + '% 仓位';
        if ($bar) $bar.style.width = Math.min(a.pct, 100) + '%';
    });
}

function renderAIAESignals(signals) {
    const container = document.getElementById('aiae-signal-cards');
    if (!container || !signals || !signals.length) return;

    function hexToRgba(hex, alpha) {
        const r = parseInt(hex.slice(1, 3), 16);
        const g = parseInt(hex.slice(3, 5), 16);
        const b = parseInt(hex.slice(5, 7), 16);
        return `rgba(${r},${g},${b},${alpha})`;
    }

    container.innerHTML = signals.map((s, i) => {
        const c = s.color || '#f59e0b';
        const isMain = s.type === 'main' || i === 0;
        const icon = s.type === 'main' ? '🌡️' : (s.type === 'slope' ? '📐' : (s.type === 'margin' ? '💳' : '📡'));
        const mainClass = isMain ? ' aiae-signal-main' : '';
        const time = new Date().toLocaleTimeString('zh-CN', {hour:'2-digit', minute:'2-digit'});
        return `<div class="aiae-signal-card${mainClass}" style="--signal-color:${c};">
            <div class="aiae-signal-icon">${icon}</div>
            <div>
                <div class="aiae-signal-text" style="color:${c}">${s.text}</div>
                <span class="aiae-signal-time">${time}</span>
            </div>
        </div>`;
    }).join('');
}

// ═══════════════════════════════════════════════════════════════
//  ZONE 6: 因子分解 + HF 高频代理
// ═══════════════════════════════════════════════════════════════

async function loadAndRenderZone6() {
    // 并发请求 decomposition + factor_trend
    const [decompResp, trendResp] = await Promise.allSettled([
        fetch('/api/v1/aiae/decomposition', { signal: AbortSignal.timeout(8000) }).then(r => r.json()),
        fetch('/api/v1/aiae/factor_trend?days=60', { signal: AbortSignal.timeout(8000) }).then(r => r.json()),
    ]);

    const decomp = decompResp.status === 'fulfilled' ? decompResp.value : null;
    const trend = trendResp.status === 'fulfilled' ? trendResp.value : null;

    if (decomp && decomp.decomposition) {
        renderWaterfallChart(decomp.decomposition, decomp.aiae_v1);
    }
    // 2026-11-04: 融资热度降级 → 融合值与融资因子不可用, 图下写明 (不用 0 顶替)
    const $wfNote = document.getElementById('aiae-waterfall-degraded');
    const _mDeg = decomp && decomp.decomposition && decomp.decomposition.margin_heat
        && decomp.decomposition.margin_heat.status === 'unavailable';
    if ($wfNote) { $wfNote.textContent = _mDeg ? '融资热度不可用（降级）：AIAE V1 融合值与融资因子不显示' : ''; $wfNote.hidden = !_mDeg; }
    // 2026-10-31: 校准基准改为 AIAE_简 (分档依据), 不再用已弃用的 AIAE_V1
    renderHFCard(decomp && decomp.hf_estimate, _aiaeData && _aiaeData.current);
    if (trend && trend.status === 'success' && trend.series) {
        renderFactorTrendChart(trend);
    }
}

function renderWaterfallChart(decomp, totalV1) {
    const container = document.getElementById('aiae-waterfall-chart');
    if (!container || typeof echarts === 'undefined') return;
    try { window._aiaeWfChart = AC.disposeChart(window._aiaeWfChart); } catch(_) {}
    window._aiaeWfChart = AC.registerChart(echarts.init(container));

    const marginOk = !(decomp.margin_heat && decomp.margin_heat.status === 'unavailable');
    const factors = marginOk ? ['aiae_simple', 'fund_position', 'margin_heat'] : ['aiae_simple', 'fund_position'];
    const labels = factors.map(f => decomp[f]?.label || f);
    if (marginOk && totalV1 != null) labels.push('AIAE V1');

    const contribs = factors.map(f => decomp[f]?.contribution || 0);

    // Waterfall: transparent base stacks
    let cumBase = 0;
    const baseData = [];
    const contribData = [];

    for (let i = 0; i < contribs.length; i++) {
        baseData.push(cumBase);
        contribData.push(contribs[i]);
        cumBase += contribs[i];
    }
    // Total bar: from 0 to total (融资热度降级时融合值不可用, 不画总柱)
    if (marginOk && totalV1 != null) {
        baseData.push(0);
        contribData.push(totalV1);
    }

    const colors = ['#f59e0b', '#eab308', '#f97316', 'rgba(255,255,255,0.9)'];

    window._aiaeWfChart.setOption({
        backgroundColor: 'transparent',
        tooltip: {
            trigger: 'axis',
            backgroundColor: 'rgba(15,23,42,0.95)',
            borderColor: 'rgba(245,158,11,0.3)',
            textStyle: { color: '#e2e8f0', fontSize: 11 },
            formatter: function(params) {
                if (!params.length) return '';
                const idx = params[0].dataIndex;
                const val = contribData[idx];
                const freq = idx < factors.length ? (decomp[factors[idx]]?.frequency || '') : '';
                const weight = idx < factors.length ? (decomp[factors[idx]]?.weight * 100).toFixed(0) + '%' : '100%';
                return '<b>' + labels[idx] + '</b><br/>' +
                    '贡献: <b>' + val.toFixed(2) + '</b> pt<br/>' +
                    '权重: ' + weight + (freq ? ' · ' + freq : '');
            }
        },
        grid: { left: 50, right: 20, top: 20, bottom: 40 },
        xAxis: {
            type: 'category', data: labels,
            axisLabel: { color: '#94a3b8', fontSize: 10, interval: 0, rotate: 0 },
            axisLine: { lineStyle: { color: '#334155' } }
        },
        yAxis: {
            type: 'value',
            axisLabel: { color: '#64748b', fontSize: 9 },
            splitLine: { lineStyle: { color: 'rgba(255,255,255,0.04)' } }
        },
        series: [
            {
                type: 'bar', stack: 'wf', data: baseData, barWidth: '45%',
                itemStyle: { color: 'transparent' }, emphasis: { disabled: true }
            },
            {
                type: 'bar', stack: 'wf', data: contribData.map((v, i) => ({
                    value: v,
                    itemStyle: { color: colors[i], borderRadius: [4, 4, 0, 0] }
                })),
                barWidth: '45%',
                label: {
                    show: true, position: 'top', color: '#cbd5e1', fontSize: 10,
                    formatter: p => p.value.toFixed(2)
                }
            }
        ]
    });
}

function renderHFCard(hf, c) {
    // 2026-10-31 重构: 左 = 分档依据 (官方 M2 的 AIAE_简), 右 = M2 按同比外推至今 (仅参考); 情绪动量单列观察
    c = c || {};
    const nc = c.m2_nowcast;
    const t = (c.regime_thresholds && c.regime_thresholds.length === 4) ? c.regime_thresholds.map(Number) : [22, 24, 27, 29];
    const regOf = v => 1 + t.filter(x => v > x).length;
    const R = _AM_REGIMES;
    const $base = document.getElementById('hf-aiae-v1');
    const $now = document.getElementById('hf-aiae-hf');
    const $d = document.getElementById('hf-delta-val');
    const $reg = document.getElementById('hf-confidence');
    const $meta = document.getElementById('hf-m2-meta');
    const $note = document.getElementById('hf-m2-note');
    if (nc) {
        const rb = regOf(nc.aiae_official), rn = regOf(nc.aiae_nowcast);
        if ($base) { $base.textContent = nc.aiae_official.toFixed(2) + '%'; $base.style.color = R[rb - 1].color; }
        if ($now) { $now.textContent = nc.aiae_nowcast.toFixed(2) + '%'; $now.style.color = R[rn - 1].color; }
        if ($d) {
            $d.textContent = (nc.adjust_pp > 0 ? '+' : '') + nc.adjust_pp.toFixed(2) + 'pp';
            $d.style.color = Math.abs(nc.adjust_pp) < 0.3 ? '#94a3b8' : '#f59e0b';
        }
        if ($reg) {
            $reg.textContent = rb === rn ? `档位不变 (${R[rb - 1].name}级)` : `⚠ 外推后进入 ${R[rn - 1].name}级`;
            $reg.style.color = rb === rn ? '#64748b' : '#f59e0b';
            $reg.title = rb === rn ? '' : '仅为参考: 分档仍按官方 M2; 下次 M2 发布后自动更新';
        }
        if ($meta) $meta.textContent = `M2 截至 ${nc.m2_month} · 已 ${nc.days} 天`;
        if ($note) {
            $note.textContent = `总市值为日频, AIAE_简 只有 M2 滞后 (次月中旬发布)。按最新同比 ${nc.m2_yoy_pct}% 把 M2 从 ${nc.m2_official} 外推到 `
                + `${nc.m2_nowcast} 万亿 (至 ${nc.asof}); 分档仍以官方数据为准。`;
        }
    } else {
        if ($base) $base.textContent = c.aiae_simple != null ? Number(c.aiae_simple).toFixed(2) + '%' : '—';
        if ($now) $now.textContent = '—';
        if ($d) $d.textContent = '—';
        if ($reg) $reg.textContent = 'M2 数据不全, 暂无外推';
        if ($meta) $meta.textContent = '';
        if ($note) $note.textContent = '';
    }

    // 情绪动量 (观察): 三项归一化值 [−1, +1] 的发散条; 旧 HF Delta 不再加到 AIAE
    const box = document.getElementById('hf-radar-chart');
    if (!box) return;
    try { window._hfRadar = AC.disposeChart(window._hfRadar); } catch(_) {}
    box.removeAttribute('_echarts_instance_');
    const bd = (hf && hf.breakdown) || {};
    const det = (hf && hf.delta_detail) || {};
    const items = [
        ['换手率 Z', bd.turnover ?? bd.turnover_zscore, det.turnover, x => x && x.zscore != null ? `Z ${Number(x.zscore).toFixed(2)}` : ''],
        ['宽基 ETF 资金流', bd.etf_flow ?? bd.etf_flow_rank, det.etf_flow, x => x && x.rank_60d != null ? `60 日 ${Math.round(x.rank_60d * 100)} 分位` : ''],
        ['融资余额 5 日', bd.margin_delta ?? bd.margin_delta_5d, det.margin_delta, x => x && x.delta_pct != null ? `${x.delta_pct > 0 ? '+' : ''}${Number(x.delta_pct).toFixed(2)}%` : ''],
    ];
    const label = v => v > 0.33 ? ['偏热', '#f97316'] : v < -0.33 ? ['偏冷', '#60a5fa'] : ['中性', '#94a3b8'];
    let n = 0, sum = 0;
    box.innerHTML = items.map(([name, b, raw, fmt]) => {
        const v = b && b.normalized != null ? Number(b.normalized) : null;
        if (v == null) return `<div class="am-sent-row na"><span>${name}</span><span class="am-sent-bar"></span><em>无数据</em></div>`;
        n++; sum += v;
        const [txt, col] = label(v);
        const w = Math.min(50, Math.abs(v) * 50);
        const bar = `<i style="${v >= 0 ? 'left:50%' : `left:${50 - w}%`};width:${w}%;background:${col}"></i>`;
        return `<div class="am-sent-row"><span>${name}</span><span class="am-sent-bar">${bar}</span>`
            + `<em style="color:${col}">${txt}</em><small>${_amEsc(fmt(raw))}</small></div>`;
    }).join('');
    const $tot = document.getElementById('hf-sent-total');
    if ($tot) {
        if (n) { const [txt, col] = label(sum / n); $tot.innerHTML = `综合 <b style="color:${col}">${txt}</b> · ${n}/3 项可用`; }
        else $tot.textContent = '暂无数据';
    }
}

function renderFactorTrendChart(trend) {
    const container = document.getElementById('aiae-factor-trend-chart');
    if (!container || typeof echarts === 'undefined') return;
    try { window._ftChart = AC.disposeChart(window._ftChart); } catch(_) {}
    window._ftChart = AC.registerChart(echarts.init(container));

    const series = trend.series;
    const dates = trend.dates || [];
    const colors = { 'aiae_simple': '#f59e0b', 'fund_position': '#eab308', 'margin_heat': '#f97316' };
    const names = { 'aiae_simple': 'AIAE简', 'fund_position': '基金仓位', 'margin_heat': '融资热度' };

    // series 格式: {aiae_simple: {label: "...", values: [...]}} 或 {aiae_simple: [...]}
    const echartsData = Object.entries(series).map(([key, valOrObj]) => {
        const vals = Array.isArray(valOrObj) ? valOrObj : (valOrObj?.values || []);
        return {
            name: names[key] || (valOrObj?.label) || key,
            type: 'line', stack: 'factor', areaStyle: { opacity: 0.4 },
            data: vals, smooth: true,
            lineStyle: { width: 1.5, color: colors[key] || '#94a3b8' },
            itemStyle: { color: colors[key] || '#94a3b8' },
            symbol: 'none'
        };
    });

    window._ftChart.setOption({
        backgroundColor: 'transparent',
        tooltip: {
            trigger: 'axis',
            backgroundColor: 'rgba(15,23,42,0.95)',
            borderColor: 'rgba(245,158,11,0.3)',
            textStyle: { color: '#e2e8f0', fontSize: 11 }
        },
        legend: {
            data: Object.values(names), top: 0, right: 10,
            textStyle: { color: '#94a3b8', fontSize: 10 }
        },
        grid: { left: 45, right: 15, top: 30, bottom: 30 },
        xAxis: {
            type: 'category', data: dates, boundaryGap: false,
            axisLabel: { color: '#64748b', fontSize: 9 },
            axisLine: { lineStyle: { color: '#334155' } }
        },
        yAxis: {
            type: 'value',
            axisLabel: { color: '#64748b', fontSize: 9 },
            splitLine: { lineStyle: { color: 'rgba(255,255,255,0.04)' } }
        },
        series: echartsData
    });
}

// ═══════════════════════════════════════════════════════════════
//  ZONE 7: 实盘健康度 + 跨市场 + 对账
// ═══════════════════════════════════════════════════════════════

async function loadAndRenderZone7() {
    // P1-a (2026-10-30): β 敞口读数独立加载, 首次需计算组合风险 (较慢), 不阻塞其余卡片
    loadAndRenderBetaExposure();
    const [devResp, alertResp, reconResp] = await Promise.allSettled([
        fetch('/api/v1/aiae/deviation', { signal: AbortSignal.timeout(8000) }).then(r => r.json()),
        fetch('/api/v1/aiae/cross_market_alerts', { signal: AbortSignal.timeout(8000) }).then(r => r.json()),
        fetch('/api/v1/aiae/reconciliation', { signal: AbortSignal.timeout(8000) }).then(r => r.json()),
    ]);

    const dev = devResp.status === 'fulfilled' ? devResp.value : null;
    const alerts = alertResp.status === 'fulfilled' ? alertResp.value : null;
    const recon = reconResp.status === 'fulfilled' ? reconResp.value : null;

    if (dev && dev.status === 'success') {
        renderHealthGauge(dev.health_score);
        renderHealthRadar(dev.health_score);
        renderDeviationStats(dev);
        renderOrderCommand(dev);
        renderHeroExec(dev);
        loadAndRenderOrderPlan(dev);
    }
    if (alerts) {
        renderCrossMarketAlerts(alerts);
    }
    if (recon && recon.status === 'success') {
        renderReconSummary(recon);
    }
}

// ═══ P1-a (2026-10-30): β 调整后有效敞口 vs AIAE β 预算 (只读读数, 不参与决策约束) ═══
async function loadAndRenderBetaExposure() {
    try {
        const resp = await fetch('/api/v1/aiae/beta_exposure', { signal: AbortSignal.timeout(30000) });
        const js = await resp.json();
        renderBetaExposure(js && js.status === 'success' ? js.data : null, js && js.message);
    } catch (e) {
        renderBetaExposure(null, '加载超时或失败');
    }
}

function renderBetaExposure(be, errMsg) {
    const anchor = document.getElementById('aiae-deviation-stats');
    if (!anchor) return;
    let box = document.getElementById('aiae-beta-exposure');
    if (!box) {
        box = document.createElement('div');
        box.id = 'aiae-beta-exposure';
        box.style.cssText = 'margin-top:10px;padding:8px 10px;background:rgba(0,0,0,0.2);' +
            'border:1px solid rgba(255,255,255,0.06);border-radius:6px;font-size:0.68rem;line-height:1.7;color:#94a3b8;';
        anchor.insertAdjacentElement('afterend', box);
    }
    const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
    const fmt = (v, d = 0) => (v === null || v === undefined || !isFinite(v)) ? '—' : Number(v).toFixed(d);
    const title = '<div style="color:#64748b;font-weight:700;margin-bottom:4px;" ' +
        'title="有效 β 敞口 = Σ 持仓权重 × β(对沪深300)。AIAE 上限按大盘 β 标定, 此处把持仓换算到同一把尺子。只读读数, 不改变有效上限与结论。">' +
        '⚖️ β 调整后敞口 <span style="font-weight:400;color:#475569;">(只读 · 观察期)</span></div>';
    if (!be) {
        box.innerHTML = title + '<div>' + esc(errMsg || '暂无数据') + '</div>';
        return;
    }
    const color = { danger: '#ef4444', warning: '#f97316', ok: '#10b981', room: '#60a5fa' }[be.level] || '#94a3b8';
    let html = title;
    html += '<div style="display:flex;justify-content:space-between;"><span>有效 β 敞口</span>' +
        '<span style="color:' + color + ';font-weight:800;font-size:0.8rem;">' + fmt(be.effective_beta_pct) + '%</span></div>';
    html += '<div style="display:flex;justify-content:space-between;"><span>AIAE β 预算' +
        (be.regime ? ' (R' + esc(be.regime) + ')' : '') + '</span><span style="color:#cbd5e1;font-weight:700;">' +
        fmt(be.budget_pct) + '%</span></div>';
    const levelText = { danger: '超出预算', warning: '略超预算', ok: '基本一致', room: '低于预算' }[be.level] || '';
    html += '<div style="display:flex;justify-content:space-between;gap:8px;"><span style="white-space:nowrap;">差额</span>' +
        '<span style="color:' + color + ';font-weight:700;white-space:nowrap;">' + (be.gap_pp > 0 ? '+' : '') +
        fmt(be.gap_pp, 1) + 'pp' + (levelText ? ' · ' + levelText : '') + '</span></div>';
    html += '<div style="margin-top:4px;color:#64748b;">名义仓位 ' + fmt(be.nominal_pct) + '% × 组合 β ' + fmt(be.portfolio_beta, 2);
    if (be.nominal_at_budget_pct !== null && be.nominal_at_budget_pct !== undefined) {
        html += '；按当前持仓结构，名义仓位约 ' + fmt(be.nominal_at_budget_pct) + '% 时与预算相当';
    }
    html += '</div>';
    if (be.top_contributors && be.top_contributors.length) {
        html += '<div style="margin-top:4px;color:#64748b;">主要贡献: ' + be.top_contributors.slice(0, 3).map(t =>
            esc(t.name) + ' ' + fmt(t.weight_pct, 1) + '%×' + fmt(t.beta_mkt, 2) + (t.estimated ? '*' : '')).join('、') + '</div>';
    }
    if (be.caveats && be.caveats.length) {
        html += '<div style="margin-top:4px;color:#f59e0b;">⚠️ ' + be.caveats.map(esc).join('；') + '</div>';
    }
    box.innerHTML = html;
    updateBetaLimitRow(be);
}

// ═══ 实盘监控与对账 (2026-10-31 视觉重构) ═══
// 状态横幅 → 等级卡 (限额决定等级 + 质量分条形) → 限额表 → 下一步 (调仓执行) → 可折叠明细
// 规则见 docs/AIAE_MONITOR_LIMITS.md; 后端 position_deviation_engine._compute_health_score
const _AM_C = { red: '#ef4444', yellow: '#eab308', green: '#10b981', unknown: '#64748b', pending: '#64748b' };
const _AM_PILL = { red: '越限', yellow: '预警', green: '达标', unknown: '无数据', pending: '加载中' };
const _AM_GRADE_C = { A: '#10b981', B: '#3b82f6', C: '#eab308', D: '#ef4444' };
const _amEsc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
let _lastHealth = null;
let _lastBeta = null;

function renderHealthGauge(hs) {
    if (!hs) return;
    _lastHealth = hs;
    const card = document.getElementById('aiae-health-gauge');
    if (!card) return;
    try { window._healthGauge = AC.disposeChart(window._healthGauge); } catch(_) {}
    const c = _AM_GRADE_C[(hs.grade || '')[0]] || '#64748b';
    const labels = { diversification: '分散度', theme_diversity: '主题分散', discipline: '执行纪律', data_quality: '数据质量' };
    const barC = v => v == null ? '#334155' : v >= 80 ? '#10b981' : v >= 60 ? '#eab308' : v >= 40 ? '#f97316' : '#ef4444';
    const rows = Object.entries(hs.quality || {}).map(([k, q]) => {
        const v = q.score;
        return `<div class="am-qrow${v == null ? ' na' : ''}" title="${_amEsc(q.value_text)}">`
            + `<span>${labels[k] || _amEsc(k)}</span><span class="am-qbar"><i style="width:${v ?? 0}%;background:${barC(v)}"></i></span>`
            + `<em>${v ?? '—'}</em></div>`;
    }).join('');
    card.style.setProperty('--c', c);
    card.innerHTML = `<div class="am-grade-ring" style="--c:${c}" title="等级由限额决定: 任一红灯 → D; 有黄无红 → C; 有无数据项 → 最高 B; 全绿 → 质量分 ≥80 为 A">${_amEsc(hs.grade || '—')}</div>`
        + `<div class="am-grade-verdict" style="--c:${c}">${_amEsc(hs.verdict || '')}</div>`
        + `<div class="am-quality"><div class="am-quality-head"><span title="仅供参考, 不影响等级">质量分</span><b>${hs.score ?? '—'}</b></div>${rows}</div>`;
}

function _amLimitMain(l) {
    if (l.value === null || l.value === undefined) return l.status === 'unknown' ? '—' : '';
    const v = Number(l.value);
    if (l.id === 'L1') return (v > 0 ? '+' : '') + v.toFixed(1) + 'pp';
    if (l.id === 'L5') {
        const m = String(l.value_text || '').match(/(\d{4})-(\d{2})-(\d{2})/);
        return m ? `${m[2]}-${m[3]}` : v + ' 个工作日';
    }
    return v.toFixed(1) + '%';
}

function _amShortRule(l) {
    return ({ L1: '偏差 >10pp 越限 · 5–10 预警', L2: '单票 >20% 越限 · >10% 预警',
              L3: '单一主题占权益 >60% 越限 · >40% 预警', L4: '观察项 · 不计入等级',
              L5: '>2 个工作日未导入 → 越限' })[l.id] || l.rule || '';
}

function renderHealthRadar(hs) {
    if (!hs || !hs.limits) return;
    const box = document.getElementById('aiae-health-radar');
    if (!box) return;
    try { window._healthRadar = AC.disposeChart(window._healthRadar); } catch(_) {}
    box.removeAttribute('_echarts_instance_');
    box.innerHTML = hs.limits.map(l => {
        const st = l.status in _AM_C ? l.status : 'unknown';
        const pill = l.graded ? _AM_PILL[st] : '观察';
        // L1/L2/L3/L5 的 value_text 已含对象与数值; 主数值单列, 说明文字去重
        const vt = String(l.value_text || '');
        const sub = (l.id === 'L2' || l.id === 'L3') ? vt.replace(/\s*[\d.]+%.*$/, '')
            : l.id === 'L1' ? vt.replace(/^[+\-]?[\d.]+pp\s*/, '')
            : l.id === 'L5' ? (l.value != null ? `导入日 · 距今 ${l.value} 个工作日` : vt) + (vt.includes('台账') ? ' · 台账有更新' : '')
            : vt;
        return `<div class="am-limit ${st}${l.graded ? '' : ' obs'}" data-limit="${_amEsc(l.id)}" title="${_amEsc(l.rule)}">`
            + `<span class="am-pill">${pill}</span>`
            + `<span class="am-lname"><b>${_amEsc(l.name)}</b><small>${_amEsc(_amShortRule(l))}</small></span>`
            + `<span class="am-lval"><b>${_amEsc(_amLimitMain(l))}</b><small>${_amEsc(sub)}</small></span></div>`;
    }).join('');
    const n = hs.limit_counts || {};
    const cnt = document.getElementById('aiae-limit-counts');
    if (cnt) {
        cnt.innerHTML = [['red', '越限'], ['yellow', '预警'], ['green', '达标']].map(([k, t]) =>
            `<span class="am-count" style="color:${_AM_C[k]};background:${_AM_C[k]}1f;">${t} ${n[k] || 0}</span>`).join('');
    }
    if (_lastBeta) updateBetaLimitRow(_lastBeta);
}

// β 观察项: β 卡片加载完成后填入 L4 行 (不改变等级)
function updateBetaLimitRow(be) {
    if (be) _lastBeta = be;
    const row = document.querySelector('#aiae-health-radar [data-limit="L4"]');
    if (!row || !be) return;
    const st = { danger: 'red', warning: 'yellow', ok: 'green', room: 'green' }[be.level] || 'unknown';
    row.className = `am-limit ${st} obs`;
    const main = row.querySelector('.am-lval b');
    const sub = row.querySelector('.am-lval small');
    const ok = be.effective_beta_pct != null && be.budget_pct != null;
    if (main) main.textContent = ok ? Math.round(be.effective_beta_pct) + '%' : '—';
    if (sub) sub.textContent = ok ? `预算 ${Math.round(be.budget_pct)}% · ${be.gap_pp > 0 ? '超出' : '差额'} ${Math.abs(Math.round(be.gap_pp))}pp` : '数据不足';
}

function _amBanner(dev) {
    const el = document.getElementById('aiae-mon-banner');
    if (!el) return;
    const items = [];
    const fr = dev.data_freshness;
    if (fr && fr.stale) {
        const nl = fr.newer_ledger_snapshot;
        items.push(`<b>持仓数据截至 ${_amEsc(fr.import_date || '未知')}</b>`
            + (fr.weekdays_since != null ? `（已 ${fr.weekdays_since} 个工作日）` : '')
            + (nl ? `，账户台账 ${_amEsc(nl.as_of)} 有更新快照` + (nl.implied_position_pct != null ? `（仓位约 ${nl.implied_position_pct}%）` : '') : '')
            + ' — 以下偏差与成本基于旧持仓，请先在持仓页导入最新「资金股份查询」。');
    }
    if (!dev.execution_target) {
        items.push('<b>执行层目标暂不可用</b> — 仓位偏差暂按 AIAE 建议计算；打开决策页完成一次执行层评估后恢复。');
    }
    el.innerHTML = items.length ? '<span>⚠️</span><div>' + items.map(t => `<div class="am-banner-item">${t}</div>`).join('') + '</div>' : '';
    el.style.display = items.length ? 'flex' : 'none';
}

function renderDeviationStats(dev) {
    const pd = dev.position_deviation;
    const conc = dev.concentration;
    const etf = dev.etf_coverage;
    const et = dev.execution_target;
    const pct = v => (v === null || v === undefined) ? '—' : Number(v).toFixed(0) + '%';

    _amBanner(dev);

    // 明细: 仓位口径 (三个"目标"并列, 标明哪个是执行口径)
    const $gap = document.getElementById('dev-gap');
    if ($gap && pd) {
        $gap.innerHTML = `实际 <b>${pct(pd.actual_pct)}</b> · 执行目标 <b>${et ? pct(et.target_pct) : '—'}</b>`
            + ` · 有效上限 ${pct(pd.effective_cap_pct)} · AIAE ${pct(pd.suggested_pct)}`;
        $gap.title = et
            ? `执行目标来自执行层 (${et.last_trigger === 'risk_event' ? '风险事件' : et.last_trigger || ''} ${et.last_change || ''}); `
              + `分区: >${et.bands.reduce_band_pp}pp 降仓 / ${et.bands.pause_band_pp}–${et.bands.reduce_band_pp}pp 暂停加仓 / ≤−${et.bands.add_band_pp}pp 可加仓`
            : '执行层目标暂不可用, 偏差按 AIAE 建议';
    }
    const $etf = document.getElementById('dev-etf');
    if ($etf && etf) {
        $etf.textContent = etf.metric === 'etf_share'
            ? `${etf.coverage_pct}% · ${etf.etf_count} 只 (宽基 ${etf.broad_etf_pct}% / 行业 ${etf.sector_etf_pct}%)`
            : `${etf.held_count}/${etf.total_count} (${etf.coverage_pct}%)`;
        $etf.title = '宽基+行业 ETF 市值 / 持仓总市值 (不含现金、黄金); 仅展示, 不计分';
    }
    const $max = document.getElementById('dev-max');
    if ($max && conc) $max.textContent = conc.max_name ? `${conc.max_name} ${(conc.max_pct || 0).toFixed(1)}%` : '—';
    const $conc = document.getElementById('dev-conc');
    if ($conc && conc) $conc.textContent = `${conc.verdict}${conc.alert_count ? ` · ${conc.alert_count} 只超 10%` : ''}`;

    // 下一步: 调仓执行 (成本由后端 services/trade_cost.py 估算)
    const $desk = _aiaeDOM['slippage-desk'] || document.getElementById('aiae-slippage-desk');
    const ec = dev.execution_cost;
    if (!$desk) return;
    if (!(ec && ec.trade_value > 0)) { $desk.style.display = 'none'; return; }
    $desk.style.display = 'block';
    $desk.classList.toggle('reduce', !!(et && et.zone === 'reduce'));
    const wan = v => (v / 10000).toFixed(1) + ' 万';
    const yuan = v => Math.round(v).toLocaleString('zh-CN') + ' 元';
    const basisTxt = ec.basis === 'exec_target' ? '执行目标' : 'AIAE 建议';
    const title = document.getElementById('aiae-desk-title');
    if (title) title.textContent = et && et.zone === 'reduce' ? '降仓至执行目标' : `调仓至 ${basisTxt}`;
    const basis = document.getElementById('aiae-desk-basis');
    if (basis) basis.textContent = `${ec.actual_pct}% → ${ec.target_pct}% (${basisTxt}) · 按持仓等比估算`;
    const $s = document.getElementById('aiae-slip-size');
    if ($s) $s.innerHTML = `<span class="big">${wan(ec.trade_value)}</span>占总资产 ${(ec.actual_pct - ec.target_pct).toFixed(1)}%`;
    const $c = document.getElementById('aiae-slip-cost');
    if ($c) {
        const cov = ec.data_coverage || {};
        const partial = cov.total && cov.complete < cov.total;
        $c.innerHTML = `<span class="big">${ec.total_bps.toFixed(1)} bps</span>约 ${yuan(ec.total)} · 显性 ${ec.explicit_bps.toFixed(1)} / 隐性 ${ec.implicit_bps.toFixed(1)}`
            + (partial ? `<br><span class="warn">${cov.total - cov.complete}/${cov.total} 只缺行情, 隐性未计</span>` : '');
        const top = (ec.orders || []).slice(0, 3).map(o => `${o.name} ${wan(o.amount)} · ${o.total_bps.toFixed(1)}bps`
            + (o.participation_pct != null ? ` · 日参与率 ${o.participation_pct.toFixed(3)}%` : '')).join('\n');
        $c.title = `显性 = 佣金 + 印花税 (仅股票卖出 0.05%) + 过户费; 隐性 = 半价差 + 平方根冲击\n前三大卖出:\n${top}\n\n`
            + `${(ec.assumptions || {}).impact_model || ''}; 佣金按万 ${(((ec.assumptions || {}).commission_rate) || 0.00025) * 10000}, 以券商实际费率为准`;
    }
    const $a = document.getElementById('aiae-slip-algo');
    if ($a) {
        const mp = ec.max_participation_pct;
        $a.innerHTML = `<span class="algo">${_amEsc(ec.algo)}</span>`
            + (mp != null ? `最大日参与率 ${mp < 0.01 ? '<0.01' : mp.toFixed(2)}%` : '');
    }
}

function renderReconSummary(recon) {
    const pos = recon.position_reconciliation;
    const trades = recon.trade_analysis;
    const maturity = recon.maturity;

    const $gap = document.getElementById('recon-gap');
    const $comp = document.getElementById('recon-compliance');
    const $score = document.getElementById('recon-score');
    const $bsr = document.getElementById('recon-bsr');

    // V3.2: 数据成熟度检查 — 不足时显示降级提示，避免零值误导
    if (maturity && !maturity.is_mature) {
        const msg = maturity.message || '数据采集中';
        const _gray = '#64748b';
        if ($gap) { $gap.textContent = msg; $gap.style.color = _gray; $gap.style.fontSize = '0.7rem'; }
        if ($comp) { $comp.textContent = '—'; $comp.style.color = _gray; }
        if ($score) { $score.textContent = '—'; $score.style.color = _gray; }
        if ($bsr) { $bsr.textContent = '—'; $bsr.style.color = _gray; }
        return;
    }

    if (pos && pos.summary) {
        const s = pos.summary;
        // V3.3: 优先展示 EWMA 加权偏差 (近期权重更高)
        const ewmaGap = s.ewma_gap_abs ?? s.avg_gap_abs ?? 0;
        const simpleGap = s.avg_gap_abs ?? 0;
        const recent7 = s.recent_7d_gap;
        const trend = s.trend || 'stable';
        const trendEmoji = trend === 'converging' ? ' ↘' : trend === 'diverging' ? ' ↗' : '';

        if ($gap) {
            // 主显示: EWMA, 小字标注近7天
            $gap.textContent = ewmaGap.toFixed(1) + 'pt';
            $gap.style.color = ewmaGap > 10 ? '#ef4444' : ewmaGap > 5 ? '#f59e0b' : '#10b981';
            $gap.style.fontSize = '';
            $gap.title = `EWMA=${ewmaGap.toFixed(1)}pt | 简均=${simpleGap.toFixed(1)}pt | 近7天=${recent7 != null ? recent7.toFixed(1) : '—'}pt`;
        }
        const compVal = s.compliance_rate_pct ?? 0;
        if ($comp) {
            $comp.textContent = compVal.toFixed(1) + '%';
            $comp.style.color = compVal >= 80 ? '#10b981' : compVal >= 50 ? '#f59e0b' : '#ef4444';
        }
        const scoreVal = s.score ?? 0;
        if ($score) {
            $score.textContent = scoreVal + '/100' + trendEmoji;
            $score.style.color = scoreVal >= 80 ? '#10b981' : scoreVal >= 60 ? '#60a5fa' : scoreVal >= 40 ? '#f59e0b' : '#ef4444';
            $score.title = `趋势: ${trend === 'converging' ? '收敛改善中' : trend === 'diverging' ? '偏差扩大中' : '稳定'}`;
        }
    }
    if (trades && trades.status === 'success') {
        const bsrVal = trades.buy_sell_ratio;
        if ($bsr) {
            $bsr.textContent = bsrVal === Infinity ? '∞' : (typeof bsrVal === 'number' ? bsrVal.toFixed(2) : (bsrVal || '0.00'));
            $bsr.style.color = '#a78bfa';
        }
    }

    // V3.3: 偏差趋势迷你折线图 — 展示 gap 收敛/发散趋势
    const records = (pos && pos.daily_records) ? pos.daily_records.filter(r => r.gap !== null) : [];
    if (records.length >= 3 && typeof echarts !== 'undefined') {
        const $container = document.getElementById('aiae-recon-summary');
        if ($container) {
            let $trendBox = document.getElementById('aiae-recon-trend');
            if (!$trendBox) {
                $trendBox = document.createElement('div');
                $trendBox.id = 'aiae-recon-trend';
                $trendBox.style.cssText = 'grid-column: 1 / -1; height: 100px; margin-top: 6px;';
                $container.appendChild($trendBox);
            }
            try { window._reconTrend = AC.disposeChart(window._reconTrend); } catch(_) {}
            window._reconTrend = AC.registerChart(echarts.init($trendBox));
            const dates = records.map(r => r.date.slice(5)); // MM-DD
            const gaps = records.map(r => r.gap);
            window._reconTrend.setOption({
                grid: { top: 16, right: 8, bottom: 20, left: 36 },
                tooltip: {
                    trigger: 'axis', backgroundColor: 'rgba(15,23,42,0.9)', borderColor: 'rgba(255,255,255,0.08)',
                    textStyle: { fontSize: 10, color: '#e2e8f0' },
                    formatter: function(params) {
                        const p = params[0];
                        const v = p.value;
                        const sev = Math.abs(v) > 15 ? '🔴 Critical' : Math.abs(v) > 10 ? '🟠 Hard' : Math.abs(v) > 5 ? '🟡 Soft' : '🟢 OK';
                        return `${p.name}<br/>偏差: <b>${v > 0 ? '+' : ''}${v.toFixed(1)}pt</b> ${sev}`;
                    }
                },
                xAxis: { type: 'category', data: dates, axisLabel: { fontSize: 9, color: '#475569' }, axisLine: { lineStyle: { color: 'rgba(255,255,255,0.06)' } } },
                yAxis: { type: 'value', axisLabel: { fontSize: 9, color: '#475569', formatter: '{value}pt' }, splitLine: { lineStyle: { color: 'rgba(255,255,255,0.04)' } } },
                series: [{
                    type: 'line', data: gaps, smooth: true, symbol: 'circle', symbolSize: 4,
                    lineStyle: { width: 2, color: '#f59e0b' },
                    itemStyle: { color: '#f59e0b' },
                    areaStyle: { color: { type: 'linear', x: 0, y: 0, x2: 0, y2: 1,
                        colorStops: [{ offset: 0, color: 'rgba(245,158,11,0.15)' }, { offset: 1, color: 'rgba(245,158,11,0)' }]
                    }},
                    markLine: {
                        silent: true, symbol: 'none',
                        lineStyle: { type: 'dashed', width: 1 },
                        data: [
                            { yAxis: 5, lineStyle: { color: 'rgba(234,179,8,0.3)' }, label: { show: false } },
                            { yAxis: -5, lineStyle: { color: 'rgba(234,179,8,0.3)' }, label: { show: false } },
                            { yAxis: 10, lineStyle: { color: 'rgba(239,68,68,0.3)' }, label: { formatter: '±10pt', fontSize: 8, color: '#ef4444', position: 'end' } },
                            { yAxis: -10, lineStyle: { color: 'rgba(239,68,68,0.3)' }, label: { show: false } },
                            { yAxis: 0, lineStyle: { color: 'rgba(16,185,129,0.4)', type: 'solid' }, label: { show: false } },
                        ]
                    }
                }]
            });
        }
    }
}


function renderCrossMarketAlerts(data) {
    const regimeBar = document.getElementById('aiae-cross-regime-bar');
    const alertsEl = document.getElementById('aiae-cross-alerts');
    const emptyEl = document.getElementById('aiae-cross-empty');

    // Regime bar
    if (regimeBar && data.regimes) {
        const regimeColors = { 1: '#10b981', 2: '#3b82f6', 3: '#eab308', 4: '#f97316', 5: '#ef4444' };
        const marketNames = { 'CN': 'A股', 'US': '美股', 'HK': '港股', 'JP': '日股' };
        // 2026-11-01 海外 AIAE P0: 海外档位为代理口径; 无数据 / 降级 / 锁定时后端给 null, 显示 "—" (不再默认 R3)
        // P3 (2026-11-01): 海外不分档, 显示读数 (美股 Z.1 AIAE / 港股南向与 AH 溢价 / 日股代理值)
        const rd = data.readings || {};
        const escT = s => String(s ?? '').replace(/[&<>"']/g, ch => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[ch]));
        regimeBar.innerHTML = Object.entries(data.regimes).map(([mkt, r]) => {
            const known = Number.isInteger(r);
            const c = known ? (regimeColors[r] || '#94a3b8') : '#475569';
            const reading = rd[mkt];
            const tip = mkt === 'CN' ? 'A 股 AIAE 档位'
                : [reading && reading.label, reading && reading.note, '不分档 · 仅作背景'].filter(Boolean).join(' · ');
            const body = known
                ? `<div style="font-size:1.1rem; font-weight:800; color:${c}; font-family:'Outfit',sans-serif;">R${r}</div>`
                : `<div style="font-size:0.68rem; font-weight:600; color:#cbd5e1; line-height:1.4; margin-top:2px;">${escT(reading ? reading.text : '—')}</div>`;
            return `<div title="${escT(tip)}" style="flex:1; text-align:center; padding:8px; background:rgba(255,255,255,0.03); border-radius:6px; border:1px solid ${c}33;">
                <div style="font-size:0.65rem; color:#64748b;">${marketNames[mkt] || mkt}</div>${body}
            </div>`;
        }).join('');
    }

    // Alerts
    const alerts = data.alerts || [];
    if (alertsEl) {
        if (alerts.length === 0) {
            alertsEl.innerHTML = '';
            if (emptyEl) emptyEl.style.display = 'block';
        } else {
            if (emptyEl) emptyEl.style.display = 'none';
            // 2026-11-01 海外 AIAE P0: 只陈述状态 (message), 不显示操作指令; 系数注明未经验证
            const sevColors = { 'critical': '#f97316', 'warning': '#f97316', 'opportunity': '#64748b', 'info': '#64748b' };
            const esc = s => String(s ?? '').replace(/[&<>"']/g, ch => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[ch]));
            alertsEl.innerHTML = alerts.map(a => {
                const c = sevColors[a.severity] || '#94a3b8';
                return `<div style="padding:10px 14px; background:${c}08; border:1px solid ${c}26; border-radius:6px; border-left:2px solid ${c};">
                    <div style="font-size:0.78rem; font-weight:700; color:${c};">${esc(a.title)}</div>
                    <div style="font-size:0.7rem; color:#94a3b8; margin-top:4px; line-height:1.5;">${esc(a.message)}</div>
                    <div style="font-size:0.65rem; color:#64748b; margin-top:2px;">${esc(a.action || '背景信息')}${a.contagion_coef ? ' · 经验系数 ' + esc(a.contagion_coef) + ' (未验证)' : ''}</div>
                </div>`;
            }).join('');
        }
    }

    // 🌐 跨市场风险传染系数矩阵 (Contagion Correlation Matrix)
    const mContainer = _aiaeDOM['contagion-matrix-container'];
    const mTableContainer = _aiaeDOM['contagion-matrix'];
    if (mContainer && mTableContainer && data.contagion_matrix && data.contagion_matrix.matrix) {
        mContainer.style.display = 'block';
        const matrix = data.contagion_matrix.matrix;
        const markets = ['CN', 'US', 'HK', 'JP'];
        const mNames = { 'CN': 'A股', 'US': '美股', 'HK': '港股', 'JP': '日股' };
        
        let html = '<table class="aiae-contagion-table">';
        html += '<thead><tr><th>源 ➔ 宿</th>' + markets.map(m => `<th>${mNames[m]}</th>`).join('') + '</tr></thead>';
        html += '<tbody>';
        
        markets.forEach(src => {
            html += `<tr><td>${mNames[src]}</td>`;
            markets.forEach(dest => {
                const key = `${src}➔${dest}`;
                const keyAlt = `${src}→${dest}`;
                const val = matrix[key] ?? matrix[keyAlt] ?? (src === dest ? 1.0 : 0.0);
                
                // 根据传染系数分配热力背景色 (红、橙、蓝)
                let bgColor = 'rgba(255,255,255,0.01)';
                let textColor = '#cbd5e1';
                if (src !== dest) {
                    if (val >= 0.7) {
                        bgColor = `rgba(239, 68, 68, ${val * 0.28})`; // 强传染: 红色
                        textColor = '#f87171';
                    } else if (val >= 0.4) {
                        bgColor = `rgba(249, 115, 22, ${val * 0.22})`;  // 中传染: 橙色
                        textColor = '#fbd58d';
                    } else if (val >= 0.2) {
                        bgColor = `rgba(59, 130, 246, ${val * 0.18})`; // 弱传染: 蓝色
                        textColor = '#93c5fd';
                    }
                } else {
                    bgColor = 'rgba(255, 255, 255, 0.04)';
                    textColor = '#94a3b8';
                }
                
                html += `<td style="background: ${bgColor}; color: ${textColor}">${val.toFixed(2)}</td>`;
            });
            html += '</tr>';
        });
        
        html += '</tbody></table>';
        mTableContainer.innerHTML = html;
    } else if (mContainer) {
        mContainer.style.display = 'none';
    }
}


// 页面首次加载时，如果AIAE是默认active tab则自动加载
// V5.1: 等待 ECharts 就绪后再加载，解决 CDN 首次访问竞态
document.addEventListener('DOMContentLoaded', function() {
    const aiaeTab = document.querySelector('.st-tab[data-report="st-aiae-position"]');
    if (aiaeTab && aiaeTab.classList.contains('active')) {
        _waitForECharts(function() { loadAIAEReport(); }, 30);
    }
});

// V3.3: Zone 7 ECharts resize — gauge/radar/trend 响应式
window.addEventListener('resize', function() {
    if (window._healthGauge) try { window._healthGauge.resize(); } catch(_) {}
    if (window._healthRadar) try { window._healthRadar.resize(); } catch(_) {}
    if (window._reconTrend) try { window._reconTrend.resize(); } catch(_) {}
});


// 2026-10-31: V1 历史口径默认折叠, 展开时图表需要按实际宽度重绘
document.addEventListener('toggle', e => {
    if (e.target && e.target.id === 'aiae-legacy-attr' && e.target.open) {
        setTimeout(() => { try { window._aiaeWfChart && window._aiaeWfChart.resize(); window._ftChart && window._ftChart.resize(); } catch (_) {} }, 30);
    }
}, true);
