/**
 * 非权威环境标注 (2026-11-04 权威环境收尾 3, docs/ACCOUNT_AUTHORITY_AND_RISK_REFRESH_PLAN.md 1.3 续)
 * ============================================================================
 * 服务器 (ACCOUNT_AUTHORITY=server) 为权威环境: 不显示任何横幅 / 标注。
 * 本机 (非权威) 或状态读取失败 (未知, 不默认为权威):
 *   - 页面顶部 .ac-authority-banner: 非权威数据 · 账户截至 … · 执行建议以服务器为准
 *   - 执行目标、合规结论、跟踪止盈、回撤刹车所在标题旁 .ac-authority-tag
 *     (静态位置用 data-ac-authority-tag 标记; 动态渲染的位置用 DYNAMIC_SELECTORS, 渲染后自动补上)
 * 只读 /api/v1/system/authority, 不改任何数字。
 */
(function (root) {
    'use strict';

    // 动态渲染的标题 (面板每次重绘后补标注)
    const DYNAMIC_SELECTORS = [
        '#ts-dd-h',              // 决策中枢 · 跟踪止盈面板: 组合回撤 · 分档刹车
        '.ep-title',             // 决策中枢 · 执行目标从哪来 / 降仓路径 (含回撤刹车)
    ];
    const TAG_ATTR = 'data-ac-authority-tag';

    function esc(s) {
        return String(s == null ? '' : s).replace(/[&<>"']/g, c => (
            { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
    }

    /** 是否需要标注: 只有明确 authoritative === true 才不标。 */
    function needsMark(info) {
        return !(info && info.authoritative === true);
    }

    /** 账户数据截至: 持仓快照时点 (估值时点未知时只写对账单日期) + 成交台账最后一笔。 */
    function accountAsOf(acc) {
        const a = acc || {};
        const h = String(a.holdings_as_of || '');
        const d = String(a.statement_date || '');
        let s = '';
        if (h.length >= 16) s = `账户截至 ${h.slice(5, 10)} ${h.slice(11, 16)} 对账单`;
        else if (d.length >= 10) s = `账户截至 ${d.slice(5, 10)} 对账单（估值时点未知）`;
        else s = '账户数据时点未知';
        const t = String(a.last_trade || '');
        if (t.length >= 10) s += ` · 成交记录至 ${t.slice(5, 10)}${t.length >= 16 ? ' ' + t.slice(11, 16) : ''}`;
        return s;
    }

    function bannerText(info) {
        if (!needsMark(info)) return '';
        if (!info || info.unknown) {
            return '权威状态未知 · 无法确认本页是否为服务器权威数据 · 执行建议以服务器为准（localhost:18000）';
        }
        return `非权威数据（本机开发） · ${accountAsOf(info.account)} · 执行建议以服务器为准（localhost:18000）`;
    }

    function tagText(info) {
        if (!needsMark(info)) return '';
        return (!info || info.unknown) ? '状态未知' : '非权威';
    }

    function tagTitle(info) {
        if (!needsMark(info)) return '';
        return (!info || info.unknown) ? '权威状态未知：执行建议以服务器为准'
            : `本机数据（${accountAsOf(info.account)}），执行建议以服务器为准`;
    }

    function addTag(el, info, doc) {
        if (!el || el.querySelector && el.querySelector(':scope > .ac-authority-tag')) return false;
        const t = doc.createElement('span');
        t.className = 'ac-authority-tag';
        t.textContent = tagText(info);
        t.title = tagTitle(info);
        el.appendChild(t);
        return true;
    }

    function markAll(info, doc) {
        if (!needsMark(info)) return 0;
        let n = 0;
        doc.querySelectorAll(`[${TAG_ATTR}]`).forEach(el => { if (addTag(el, info, doc)) n++; });
        DYNAMIC_SELECTORS.forEach(sel => doc.querySelectorAll(sel).forEach(el => { if (addTag(el, info, doc)) n++; }));
        return n;
    }

    function showBanner(info, doc) {
        const text = bannerText(info);
        if (!text || doc.getElementById('ac-authority-banner')) return null;
        const b = doc.createElement('div');
        b.id = 'ac-authority-banner';
        b.className = 'ac-authority-banner';
        b.setAttribute('role', 'status');
        b.innerHTML = `<span class="ac-authority-tag">${esc(tagText(info))}</span><span>${esc(text)}</span>`;
        const host = doc.querySelector('main') || doc.body;
        host.insertBefore(b, host.firstChild);
        return b;
    }

    function fetchInfo() {
        if (root.AC && typeof root.AC.authority === 'function') return root.AC.authority();
        const unknown = { authority: 'unknown', authoritative: false, unknown: true };
        return fetch('/api/v1/system/authority', { cache: 'no-store' })
            .then(r => (r.ok ? r.json() : null))
            .then(j => (j && j.data && typeof j.data.authoritative === 'boolean') ? j.data : unknown)
            .catch(() => unknown);
    }

    function init(doc) {
        return fetchInfo().then(info => {
            if (!needsMark(info)) return info;           // 服务器: 什么都不显示
            showBanner(info, doc);
            markAll(info, doc);
            if (typeof root.MutationObserver === 'function') {
                let pending = false;
                new root.MutationObserver(() => {
                    if (pending) return;
                    pending = true;
                    setTimeout(() => { pending = false; markAll(info, doc); }, 200);
                }).observe(doc.body, { childList: true, subtree: true });
            }
            return info;
        });
    }

    root.AuthorityBanner = { needsMark, accountAsOf, bannerText, tagText, tagTitle, markAll, showBanner, init,
                             DYNAMIC_SELECTORS, TAG_ATTR };
    if (root.document && typeof root.document.addEventListener === 'function') {
        if (root.document.readyState === 'loading') root.document.addEventListener('DOMContentLoaded', () => init(root.document));
        else init(root.document);
    }
})(typeof window !== 'undefined' ? window : this);
