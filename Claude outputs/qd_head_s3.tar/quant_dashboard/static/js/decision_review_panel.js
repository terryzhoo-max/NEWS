/*
 * AlphaCore · 组合页「决定记录与复盘」面板 (方案 B 阶段4B-2, 2026-10-29)
 * 接口: /api/v1/analysis/journal*, /api/v1/analysis/review/*
 * 原则: 只记录与复盘, 不下单不改持仓; 成交关联须人工确认; 不足以评价时不出数字;
 *       假设对照明确标注; 金额默认隐藏 (账户隐私), 可切换显示。
 */
(function (global) {
    'use strict';

    const API = '/api/v1/analysis';
    const STATUS = {adopted: '采用', not_adopted: '未采用', deferred: '暂不行动', planned: '已确认计划',
                    watch: '观察', declined: '拒绝', self_directed: '自主决定'};
    const INTENT = {buy: '买入/加仓', sell: '卖出/减仓', rebalance: '调仓', hold: '维持不动'};
    const state = {showAmounts: false, review: null, decisions: null, start: ''};

    function esc(v) {
        return String(v == null ? '' : v).replace(/[&<>"']/g, (c) => (
            {'&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'}[c]));
    }
    function pct(v, d = 2) {
        return v == null || !isFinite(Number(v)) ? '—' : `${(Number(v) * 100).toFixed(d)}%`;
    }
    function money(v, show) {
        if (!show) return '***';
        return v == null || !isFinite(Number(v)) ? '—' : `${(Number(v) / 10000).toFixed(2)} 万`;
    }
    // 2026-11-04 视觉轮: 实际收益 / 实际增值红涨绿跌 (0 中性); 假设对照 ("若执行") 不着色
    function signCls(v) { return v == null ? '' : (Number(v) > 0 ? 'ac-up' : Number(v) < 0 ? 'ac-down' : 'ac-flat'); }

    // ── 组合区间比较 ──
    function renderPortfolioReview(r, show) {
        if (!r) return '<div class="pf-empty">复盘数据不可用</div>';
        if (r.status !== 'ok') {
            const hint = r.earliest_start ? `<div class="dr-sub">最早可用起点: ${esc(r.earliest_start)}</div>` : '';
            return `<div class="dr-insufficient"><span class="ac-tag ac-tag-info">不足以评价</span> ${esc(r.reason || r.label || '')}${hint}</div>`;
        }
        const rows = (r.paths || []).map((p) => `<tr><td>${esc(p.label)}</td>
            <td class="num ${signCls(p.return)}">${p.return == null ? '<span class="dr-sub">不比较</span>' : pct(p.return)}</td>
            <td class="num">${pct(p.max_drawdown)}</td><td class="num">${money(p.end_value, show)}</td></tr>`).join('');
        const cav = (r.caveats || []).map((c) => `<li>${esc(c)}</li>`).join('');
        return `<div class="dr-meta">${esc(r.from)} ~ ${esc(r.to)} · ${esc(r.trading_days)} 个交易日 · 终点: ${esc(r.end_rule || '指定')}
                · 期初风险资产 ${money(r.start_value, show)}</div>
            <table class="pf-table dr-table"><thead><tr><th>路径</th><th class="num">区间收益</th><th class="num">最大回撤</th>
                <th class="num">期末价值</th></tr></thead><tbody>${rows}</tbody></table>
            <div class="dr-kpi">实际操作相对"维持期初组合":
                <b class="${signCls(r.value_added_vs_hold)}">${pct(r.value_added_vs_hold_pct)}</b> (占期初风险资产)
                · ${money(r.value_added_vs_hold, show)}</div>
            ${cav ? `<ul class="dr-caveats">${cav}</ul>` : ''}
            <p class="dr-note">${esc(r.label || '')} — 衡量交易决定本身, 不是整账户收益; 区间短时不构成能力证据。</p>`;
    }

    // ── 决定列表 + 单条复盘 ──
    function reviewCell(rv, show) {
        if (!rv) return '<span class="dr-sub">—</span>';
        if (rv.evaluation === 'not_applicable') return `<span class="dr-sub">${esc(rv.label)}</span>`;
        if (rv.status_eval === 'insufficient') return `<span class="ac-tag ac-tag-info">不足以评价</span>
            <div class="dr-sub">${esc(rv.reason || '')}</div>`;
        if (rv.evaluation === 'executed_vs_not_trading') {
            return `<b class="${signCls(rv.value_added)}">${pct(rv.value_added_pct_of_notional)}</b>
                <span class="dr-sub">(占成交额) ${money(rv.value_added, show)}</span>
                <div class="dr-sub">${esc(rv.label)} · ${esc(rv.from)}~${esc(rv.to)}</div>`;
        }
        if (rv.evaluation === 'hypothetical_direction') {
            const items = (rv.items || []).map((i) => `${esc(i.ts_code)} ${pct(i.price_change)}`
                + (i.if_executed == null ? '' : ` → 若执行 <b class="dr-hypo-num">${pct(i.if_executed)}</b>`))
                .join('<br>');
            return `<span class="ac-tag">假设对照</span><div class="dr-hypo-items">${items}</div>`;
        }
        return '<span class="dr-sub">—</span>';
    }

    function renderDecisionRows(reviews, show) {
        if (!reviews || !reviews.length) return '<div class="pf-empty">暂无决定记录</div>';
        const rows = reviews.map((r) => {
            const st = STATUS[r.decision_status] || r.decision_status || '';
            const retro = r.retrospective ? ' <span class="ac-tag dr-retro" title="事后补记, 不计入汇总">补记</span>' : '';
            const linkBtn = ['adopted', 'planned'].includes(r.decision_status) && r.intent !== 'hold'
                ? `<button class="pf-btn pf-btn-sm dr-cand-btn" data-id="${esc(r.decision_id)}">成交关联</button>` : '';
            return `<tr data-id="${esc(r.decision_id)}"><td>${esc(r.decided_on)}</td><td>${st ? `<span class="ac-tag">${esc(st)}</span>` : ''}${retro}</td>
                <td>${esc(INTENT[r.intent] || r.intent || '')}</td><td>${esc((r.codes || []).join(', '))}</td>
                <td class="dr-thesis" title="${esc(r.thesis || '')}">${esc((r.thesis || '').slice(0, 40))}</td>
                <td>${reviewCell(r, show)}</td><td>${linkBtn}</td></tr>
                <tr class="dr-cand-row" id="dr-cand-${esc(r.decision_id)}" hidden><td colspan="7"></td></tr>`;
        }).join('');
        return `<table class="pf-table dr-table"><thead><tr><th>决定日</th><th>状态</th><th>意图</th><th>代码</th>
            <th>理由</th><th>复盘</th><th></th></tr></thead><tbody>${rows}</tbody></table>`;
    }

    function renderSummary(s) {
        if (!s) return '';
        const ex = s.executed || {}, na = s.not_adopted_or_deferred || {};
        return `<div class="dr-meta">已完成复盘的执行决定 ${ex.count || 0} 条 (改善 ${ex.positive || 0})
            · 中期读数 ${s.executed_interim_count || 0} · 不足以评价 ${s.insufficient_count || 0}
            · 未采用/暂不行动 ${na.count || 0} 条 (若执行会更好 ${na.would_have_helped || 0} / 更差 ${na.would_have_hurt || 0})
            · 事后补记 ${s.retrospective_count || 0} (不计入)</div>
            ${s.sample_note ? `<div class="dr-banner">${esc(s.sample_note)}</div>` : ''}`;
    }

    function renderCandidates(detail, cands, show) {
        const linked = (detail && detail.linked_trades) || [];
        const ex = (detail && detail.execution) || {};
        const lrows = linked.map((t) => `<li>${esc(t.date)} ${esc(t.ts_code)} ${esc(t.side === 'buy' ? '买' : '卖')}
            ${show ? esc(t.qty) + ' @ ' + esc(t.price) : ''}
            <input class="pf-input dr-unlink-reason" placeholder="取消原因 (必填)" data-key="${esc(t.key)}">
            <button class="pf-btn pf-btn-sm dr-unlink-btn" data-key="${esc(t.key)}">取消关联</button></li>`).join('');
        const crows = ((cands && cands.candidates) || []).filter((t) => !linked.some((l) => l.key === t.key))
            .map((t) => `<li>${esc(t.date)} ${esc(t.ts_code)} ${esc(t.side === 'buy' ? '买' : '卖')}
                ${show ? esc(t.qty) + ' @ ' + esc(t.price) : ''}
                ${t.linked_to ? '<span class="dr-sub">已属另一条决定</span>'
                              : `<button class="pf-btn pf-btn-sm dr-link-btn" data-key="${esc(t.key)}">确认关联</button>`}</li>`)
            .join('');
        return `<div class="dr-cand"><div><b>执行状态</b>: ${esc(ex.label || '')}</div>
            ${lrows ? `<div>已关联:</div><ul>${lrows}</ul>` : ''}
            <div>候选成交 (${esc((cands && cands.window_days) || '')} 天内, 同代码同方向; 须人工确认):</div>
            ${crows ? `<ul>${crows}</ul>` : '<div class="dr-sub">无候选; 若已成交请先导入券商成交记录</div>'}</div>`;
    }

    // ── 录入 ──
    function entryFromForm(v) {
        const codes = String(v.codes || '').split(/[\s,，;；]+/).map((c) => c.trim().toUpperCase()).filter(Boolean);
        const payload = {request_id: v.request_id, status: v.status, intent: v.intent, codes,
                         thesis: String(v.thesis || '').trim(), counter_evidence: String(v.counter_evidence || '').trim(),
                         relates_to: String(v.relates_to || '').trim(), retrospective: !!v.retrospective};
        if (v.expected_holding_days) payload.expected_holding_days = parseInt(v.expected_holding_days, 10);
        if (v.review_after) payload.review_after = v.review_after;
        if (v.decided_on) payload.decided_on = v.decided_on;
        const bad = codes.filter((c) => !/^[0-9]{6}\.(SH|SZ|BJ)$/.test(c));
        if (bad.length) return {error: `代码格式应为 600000.SH: ${bad.join(', ')}`};
        if (!payload.thesis) return {error: '请填写理由'};
        if (payload.status === 'adopted' && !payload.counter_evidence) return {error: '采用的决定须填写反证 (什么情况说明判断错了)'};
        if (payload.intent !== 'hold' && !codes.length) return {error: '买卖或调仓须填写代码'};
        if (payload.expected_holding_days != null && !(payload.expected_holding_days > 0)) return {error: '预期持有期须为正整数天'};
        return {payload};
    }

    function newRequestId() {
        const c = global.crypto;
        if (c && c.randomUUID) return 'jr-' + c.randomUUID();
        return 'jr-' + Date.now().toString(36) + Math.random().toString(36).slice(2, 10);
    }

    // ── I/O ──
    async function call(path, options) {
        const post = options && options.method && options.method !== 'GET';
        const fetcher = post ? (global.AC && global.AC.secureFetch ? global.AC.secureFetch.bind(global.AC) : null)
                             : global.fetch.bind(global);
        if (!fetcher) throw new Error('安全通信组件尚未就绪, 请刷新页面');
        const r = await fetcher(API + path, post ? {...options, headers: {'Content-Type': 'application/json',
                                                     ...((options && options.headers) || {})}} : options);
        const j = await r.json();
        if (!r.ok || j.status !== 'success') throw new Error((global.AC && global.AC.errorText ? global.AC.errorText(j) : j.detail) || j.message || '操作未完成');
        return j.data;
    }

    function $(id) { return global.document.getElementById(id); }
    function setMsg(text, ok) {
        const el = $('dr-msg');
        if (el) { el.textContent = text; el.className = ok ? 'dr-ok' : 'dr-err'; }
    }

    async function loadPortfolio() {
        const el = $('dr-portfolio');
        if (!el) return;
        try {
            let start = state.start;
            if (!start) {
                const probe = await call('/review/portfolio?start=2000-01-01');
                start = probe.earliest_start || '';
                if (!start) { state.review = probe; el.innerHTML = renderPortfolioReview(probe, state.showAmounts); return; }
                const inp = $('dr-start');
                if (inp && !inp.value) inp.value = start;
            }
            state.review = await call('/review/portfolio?start=' + encodeURIComponent(start));
        } catch (e) {
            state.review = {status: 'error', reason: e.message};
        }
        el.innerHTML = renderPortfolioReview(state.review, state.showAmounts);
    }

    async function loadDecisions() {
        const el = $('dr-decisions');
        if (!el) return;
        try {
            state.decisions = await call('/review/decisions');
            $('dr-summary').innerHTML = renderSummary(state.decisions.summary);
            el.innerHTML = renderDecisionRows(state.decisions.reviews, state.showAmounts);
        } catch (e) {
            el.innerHTML = `<div class="pf-empty">决定记录加载失败: ${esc(e.message)}</div>`;
        }
    }

    async function openCandidates(id) {
        const row = $('dr-cand-' + id);
        if (!row) return;
        row.hidden = false;
        row.firstElementChild.innerHTML = '<div class="pf-empty">加载中…</div>';
        try {
            const [detail, cands] = await Promise.all([call('/journal/' + id), call('/journal/' + id + '/candidates')]);
            row.firstElementChild.innerHTML = renderCandidates(detail, cands, state.showAmounts);
        } catch (e) {
            row.firstElementChild.innerHTML = `<div class="dr-err">${esc(e.message)}</div>`;
        }
    }

    // 2026-11-04 权威环境 1b: 非权威 (本机) / 状态未知 → 决定记录与成交关联不可写 (后端同样拒绝)
    let writeBlocked = '';

    function bind() {
        const root = $('pf-decision-zone');
        if (!root) return;
        const form = $('dr-form');
        if (global.AC && typeof global.AC.authority === 'function') {
            global.AC.authority().then((info) => {
                writeBlocked = global.AC.accountWriteBlockedText(info, 'write');
                if (!writeBlocked || !form) return;
                const submit = form.querySelector('button[type="submit"]');
                if (submit) { submit.disabled = true; submit.title = writeBlocked; }
                setMsg(writeBlocked, false);
            });
        }
        if (form) {
            form.dataset.requestId = newRequestId();
            form.addEventListener('submit', async (ev) => {
                ev.preventDefault();
                if (writeBlocked) { setMsg(writeBlocked, false); return; }
                const fd = new global.FormData(form);
                const v = Object.fromEntries(fd.entries());
                v.retrospective = fd.get('retrospective') === 'on';
                v.request_id = form.dataset.requestId;
                const built = entryFromForm(v);
                if (built.error) { setMsg(built.error, false); return; }
                try {
                    await call('/journal', {method: 'POST', body: JSON.stringify(built.payload)});
                    setMsg('已记录 (不代表下单或成交)', true);
                    form.reset();
                    form.dataset.requestId = newRequestId();
                    loadDecisions();
                } catch (e) { setMsg(e.message, false); }
            });
        }
        root.addEventListener('click', async (ev) => {
            const t = ev.target;
            if (t.classList.contains('dr-cand-btn')) { openCandidates(t.dataset.id); return; }
            const row = t.closest && t.closest('.dr-cand-row');
            const id = row && row.id.replace('dr-cand-', '');
            if (writeBlocked && (t.classList.contains('dr-link-btn') || t.classList.contains('dr-unlink-btn'))) {
                setMsg(writeBlocked, false); return;
            }
            try {
                if (t.classList.contains('dr-link-btn') && id) {
                    await call('/journal/' + id + '/links', {method: 'POST', body: JSON.stringify({trade_key: t.dataset.key})});
                    await openCandidates(id); loadDecisions();
                } else if (t.classList.contains('dr-unlink-btn') && id) {
                    const inp = row.querySelector(`.dr-unlink-reason[data-key="${CSS.escape(t.dataset.key)}"]`);
                    const reason = inp ? inp.value.trim() : '';
                    if (!reason) { setMsg('取消关联须填写原因', false); return; }
                    await call('/journal/' + id + '/unlink', {method: 'POST',
                        body: JSON.stringify({trade_key: t.dataset.key, reason})});
                    await openCandidates(id); loadDecisions();
                }
            } catch (e) { setMsg(e.message, false); }
        });
        const toggle = $('dr-show-amounts');
        if (toggle) toggle.addEventListener('change', () => {
            state.showAmounts = toggle.checked;
            $('dr-portfolio').innerHTML = renderPortfolioReview(state.review, state.showAmounts);
            if (state.decisions) $('dr-decisions').innerHTML = renderDecisionRows(state.decisions.reviews, state.showAmounts);
        });
        const startBtn = $('dr-start-btn');
        if (startBtn) startBtn.addEventListener('click', () => { state.start = ($('dr-start') || {}).value || ''; loadPortfolio(); });
        loadPortfolio();
        loadDecisions();
    }

    global.DecisionReviewPanel = {renderPortfolioReview, renderDecisionRows, renderSummary, renderCandidates,
                                  entryFromForm, newRequestId};
    if (global.document && global.document.addEventListener && global.fetch) {
        global.document.addEventListener('DOMContentLoaded', bind);
    }
})(typeof window !== 'undefined' ? window : globalThis);
