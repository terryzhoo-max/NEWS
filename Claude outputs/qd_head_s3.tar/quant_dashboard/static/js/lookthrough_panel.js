/*
 * AlphaCore · 组合页「穿透暴露与压力情景」面板 (方案 B 阶段3B-4, 2026-10-29)
 * 只读展示 /api/v1/portfolio/lookthrough 与 /api/v1/portfolio/stress-lookthrough。
 * 原则: 未知暴露单列 (不当作零风险); 口径与日期逐 ETF 标注; 压力情景标明"条件估计·示例参数未校准"。
 */
(function (global) {
    'use strict';

    function esc(v) {
        return String(v == null ? '' : v).replace(/[&<>"']/g, (c) => (
            {'&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'}[c]));
    }
    function pct(v, d = 1) { return v == null || !isFinite(Number(v)) ? '--' : `${Number(v).toFixed(d)}%`; }
    function wan(v) { return v == null || !isFinite(Number(v)) ? '--' : `${(Number(v) / 10000).toFixed(1)} 万`; }

    const BASIS_LABEL = {
        tracking_index_weight: '指数权重近似',
        fund_reported_holdings: '基金报告持仓',
    };
    const REASON_LABEL = {
        INDEX_WEIGHT_STALE: '指数权重过期', INDEX_WEIGHT_UNAVAILABLE: '无指数权重',
        CONSTITUENT_ETF_NOT_FOUND: '未登记成分来源', FUND_HOLDINGS_STALE: '基金报告过期',
        INDEX_WEIGHT_COVERAGE_BELOW_100: '权重覆盖不足', FUND_HOLDINGS_UNDISCLOSED_REMAINDER: '报告未披露部分',
        unsupported_instrument: '不支持的品种',
    };

    // 2026-11-04 视觉轮 V3: 中性水平条 (从大到小); "行业未知"不截断, 始终排最后并标"未知"
    const UNKNOWN_INDUSTRY = '行业未知';
    const TOP_INDUSTRIES = 8;
    function bar(pctVal, max, dim) {
        const v = Number(pctVal);
        const w = isFinite(v) && max > 0 ? Math.max(0, Math.min(100, v / max * 100)) : 0;
        return `<span class="lt-bar${dim ? ' lt-bar-dim' : ''}"><i style="width:${w.toFixed(1)}%"></i></span>`;
    }
    /** 行业行: 已知行业按占比降序取前 N, "行业未知"不参与截断、始终在最后一行。 */
    function industryRows(list) {
        const all = (list || []).filter((r) => r && r.industry != null);
        const known = all.filter((r) => r.industry !== UNKNOWN_INDUSTRY)
            .sort((a, b) => Number(b.pct_of_total || 0) - Number(a.pct_of_total || 0));
        const shown = known.slice(0, TOP_INDUSTRIES);
        const rest = known.slice(TOP_INDUSTRIES).reduce((s, r) => s + Number(r.pct_of_total || 0), 0);
        const unk = all.filter((r) => r.industry === UNKNOWN_INDUSTRY)
            .reduce((s, r) => s + Number(r.pct_of_total || 0), 0);
        const hasUnk = all.some((r) => r.industry === UNKNOWN_INDUSTRY);
        return { shown, rest, restCount: Math.max(0, known.length - TOP_INDUSTRIES), unknown: hasUnk ? unk : 0, hasUnk };
    }
    function industryHtml(list) {
        const r = industryRows(list);
        const max = Math.max(...r.shown.map((x) => Number(x.pct_of_total || 0)), r.unknown, 0.0001);
        const row = (name, v, cls, extra) => `<tr class="${cls}"><td class="lt-name">${name}${extra || ''}</td>` +
            `<td class="lt-bar-td">${bar(v, max, cls === 'lt-unknown-row')}</td><td class="num">${pct(v, 2)}</td></tr>`;
        return r.shown.map((x) => row(esc(x.industry), x.pct_of_total, '')).join('') +
            (r.restCount ? row(`其余 ${r.restCount} 个行业`, r.rest, 'lt-rest-row') : '') +
            row(UNKNOWN_INDUSTRY, r.unknown, 'lt-unknown-row', ' <span class="ac-tag ac-tag-info">未知</span>');
    }

    function renderLookthrough(d) {
        if (!d || d.status !== 'ok') {
            return `<div class="pf-empty">${d && d.status === 'empty' ? '无持仓' : '穿透数据不可用'}</div>`;
        }
        const unk = d.unknown || {};
        const kpi = `
            <div class="lt-kpi-row">
                <div class="lt-kpi"><div class="lt-kpi-label">可穿透识别</div>
                    <div class="lt-kpi-value">${pct(d.known_lookthrough_pct_of_invested)}</div>
                    <div class="lt-kpi-sub">占持仓市值</div></div>
                <div class="lt-kpi" data-unknown="${Number(unk.value) > 0 ? '1' : '0'}">
                    <div class="lt-kpi-label">未知暴露</div>
                    <div class="lt-kpi-value">${pct(unk.pct_of_total)}</div>
                    <div class="lt-kpi-sub">${Number(unk.value) > 0 ? '不是零风险, 见下方明细' : '无未知暴露'}</div></div>
                <div class="lt-kpi"><div class="lt-kpi-label">现金</div>
                    <div class="lt-kpi-value">${pct(d.cash_pct)}</div>
                    <div class="lt-kpi-sub">占总资产</div></div>
                <div class="lt-kpi"><div class="lt-kpi-label">重叠公司</div>
                    <div class="lt-kpi-value">${(d.overlap_companies || []).length}</div>
                    <div class="lt-kpi-sub">出现在多只 ETF/直接持股</div></div>
            </div>`;
        const inds = industryHtml(d.industries);
        const top = (d.companies || []).slice().sort((a, b) => Number(b.pct_of_total || 0) - Number(a.pct_of_total || 0)).slice(0, 10);
        const cmax = Math.max(...top.map((c) => Number(c.pct_of_total || 0)), 0.0001);
        const comps = top.map((c) => {
            const via = Array.from(new Set((c.sources || []).map((s) => s.via === 'direct' ? '直接持股' : s.via)));
            const unk = !c.industry;
            return `<tr${c.overlap ? ' class="lt-overlap"' : ''}><td class="lt-name">${esc(c.name)}<small> ${esc(c.code)}</small></td>
                <td class="lt-ind${unk ? ' lt-unknown-cell' : ''}">${unk ? '行业未知' : esc(c.industry)}</td>
                <td class="lt-bar-td">${bar(c.pct_of_total, cmax, unk)}</td><td class="num">${pct(c.pct_of_total, 2)}</td>
                <td class="lt-sub">${via.map(esc).join(' · ')}${c.overlap ? ' <span class="ac-tag" title="同一公司来自多个来源">重叠</span>' : ''}</td></tr>`;
        }).join('');
        const etfs = (d.etfs || []).map((e) => `<tr>
                <td>${esc(e.instrument_name || e.name || e.ts_code)}<small> ${esc(e.ts_code)}</small>
                    ${e.research_label ? `<div class="lt-sub">研究标签: ${esc(e.research_label)}</div>` : ''}</td>
                <td>${esc(e.tracking_index_name || '--')}<small> ${esc(e.tracking_index_code || '')}</small></td>
                <td>${esc(BASIS_LABEL[e.exposure_basis] || e.exposure_basis || '--')}</td>
                <td>${esc(e.weights_as_of || '--')}${e.reported_ann_date ? `<div class="lt-sub">公告 ${esc(e.reported_ann_date)}</div>` : ''}</td>
                <td>${e.is_verified ? '已核验' : '<span class="ac-tag ac-tag-warn">未核验</span>'}</td></tr>`).join('');
        const unknownRows = (unk.items || []).map((u) =>
            `<li>${esc(u.name || u.ts_code)} ${esc(u.ts_code)} · ${wan(u.value)} · ${esc(REASON_LABEL[u.reason] || u.reason)}</li>`).join('');
        return `${kpi}
            <div class="lt-grid">
              <div><h4>行业暴露（占总资产）</h4><table class="pf-table lt-table lt-bars"><tbody>${inds}</tbody></table></div>
              <div><h4>前 10 大公司暴露</h4><table class="pf-table lt-table lt-bars"><thead><tr><th>公司</th><th>行业</th>
                <th></th><th class="num">占总资产</th><th>来源</th></tr></thead><tbody>${comps}</tbody></table></div>
            </div>
            <h4>ETF 成分来源</h4>
            <table class="pf-table lt-table"><thead><tr><th>ETF (正式名称)</th><th>跟踪指数</th><th>口径</th>
                <th>成分日期</th><th>状态</th></tr></thead><tbody>${etfs}</tbody></table>
            ${unknownRows ? `<h4>未知暴露明细</h4><ul class="lt-unknown">${unknownRows}</ul>` : ''}
            <p class="lt-note">${esc((d.basis || {}).note || '')}</p>`;
    }

    function renderStress(s) {
        if (!s || s.status !== 'ok') return '<div class="pf-empty">压力情景不可用</div>';
        const rows = (s.scenarios || []).map((x) => {
            const r = x.total_loss_pct_range || [];
            const range = r[0] === r[1] ? pct(r[0]) : `${pct(r[0])} ~ ${pct(r[1])}`;
            const shocks = Object.entries(x.shocks || {}).map(([k, v]) =>
                `${k === '_other_equity' ? '其余权益' : esc(k)} ${(Number(v) * 100).toFixed(0)}%`).join('，');
            const top = (x.by_theme || []).slice(0, 2).map((t) => `${esc(t.theme)} ${wan(t.loss)}`).join('；');
            return `<tr><td><b>${esc(x.name)}</b><div class="lt-sub">${esc(x.desc || '')}</div></td>
                <td class="lt-sub">${shocks}</td><td class="num lt-stress-num"><b>${range}</b></td><td class="lt-sub">${top}</td></tr>`;
        }).join('');
        const lims = (s.limitations || []).map(esc).join('；');
        return `<div class="lt-banner"><span class="ac-tag ac-tag-info">条件估计 · 非预测</span> ${esc(s.nature)}<br>参数来源：${esc(s.param_source)}</div>
            <table class="pf-table lt-table"><thead><tr><th>情景</th><th>冲击假设</th><th class="num">估算损失 (占总资产)</th>
            <th>主要来源</th></tr></thead><tbody>${rows}</tbody></table>
            <p class="lt-note">${esc(s.unknown_rule || '')}。局限: ${lims}</p>`;
    }


    // ── 2026-11-03 组合页精简 P3: 合规主题集中度 + 行业拆分说明 ──
    // 合规数字是唯一判定; 行业表按 Tushare 行业列示。两者合计相差 ≤ 0.5pp 时并列并写明口径, 否则只显示合规数字。
    const TOLERANCE_PP = 0.5;
    function sectorMetrics(compliance) {
        const c = ((compliance && compliance.checks) || []).find((r) => r && r.rule_id === 'sector_concentration');
        return c && c.metrics && c.metrics.top_theme ? c.metrics : null;
    }
    function levelText(m) {
        if (m.level === 'hard_block') return `> ${m.danger_pct}% 严重集中（硬阻断）`;
        if (m.level === 'breach') return `> ${m.limit_pct}% 超出主题上限`;
        if (m.level === 'near') return `接近 ${m.limit_pct}% 主题上限`;
        return `在 ${m.limit_pct}% 主题上限以内`;
    }
    // 2026-11-04 视觉轮 V3: 合规行是本区第一信息 = 状态标签 (只读合规检查项结果) + 主题读数; 下一行行业拆分;
    // 合规「行业未知」按 ETF 分列的占比用小字显示 (compliance metrics.unknown_industry)
    function statusTag(compliance) {
        const c = ((compliance && compliance.checks) || []).find((r) => r && r.rule_id === 'sector_concentration');
        if (!c || typeof c.passed !== 'boolean') return '';
        if (c.passed) return '<span class="ac-tag ac-tag-pass">通过</span> ';
        return c.severity === 'hard_block' ? '<span class="ac-tag ac-tag-block">硬阻断</span> ' : '<span class="ac-tag ac-tag-warn">警告</span> ';
    }
    function unknownByEtf(m) {
        const list = (m && m.unknown_industry) || [];
        if (!list.length) return '<div class="lt-sub">穿透后行业未知（按 ETF）：0%</div>';
        return `<div class="lt-sub">穿透后行业未知（按 ETF，不计入任何主题）：${list.map((e) => `${esc(e.name || e.ts_code)} ${pct(e.pct, 2)}`).join('，')}</div>`;
    }
    function complianceLineHtml(compliance, themeView) {
        const m = sectorMetrics(compliance);
        if (!m) return '<div class="lt-banner">合规主题集中度读数不可用，以决策中枢合规区为准；下方为穿透行业明细（读数，不作判定）。</div>';
        const head = `${statusTag(compliance)}<b>合规判定</b> · 主题「${esc(m.top_theme)}」占账户 <b>${pct(m.top_pct)}</b>，${esc(levelText(m))}（唯一判定）` +
            (m.basis_note ? `<div class="lt-sub">口径：${esc(m.basis_note)}</div>` : '') +
            (String(m.basis_note || '').includes('行业未知') ? '' : unknownByEtf(m));   // basis_note 已按 ETF 写明时不重复
        const t = ((themeView && themeView.themes) || []).find((x) => x && x.theme === m.top_theme);
        if (!t || Math.abs(Number(t.pct) - Number(m.top_pct)) > TOLERANCE_PP) {
            const sum = t ? `行业合计 ${pct(t.pct)}，` : '';
            return `<div class="lt-banner lt-warn-banner">${head}<details><summary>行业拆分（口径不一致：${sum}以合规为准）</summary>` +
                `${t ? t.industries.map((r) => `${esc(r.industry)} ${pct(r.pct, 2)}`).join('，') : '无对应行业'}</details></div>`;
        }
        const inds = t.industries || [];
        const shown = inds.slice(0, 3).map((r) => `${esc(r.industry)} ${pct(r.pct)}`);
        const rest = inds.slice(3).reduce((s, r) => s + Number(r.pct || 0), 0);
        if (inds.length > 3) shown.push(`其他 ${pct(rest)}`);
        return `<div class="lt-banner">${head}<br>其中 行业 ${shown.join(' + ')}` +
            `<div class="lt-sub">口径：主题「${esc(m.top_theme)}」= ${inds.map((r) => esc(r.industry)).join(' + ')}（与合规用同一张行业→主题映射表）；下方行业表按行业列示，故单一行业数字小于主题数字。</div></div>`;
    }

    async function load(fetchFn) {
        const get = async (url) => {
            const r = await fetchFn(url);
            const j = await r.json();
            return j && j.status === 'success' ? j.data : null;
        };
        const ltEl = global.document.getElementById('lt-lookthrough');
        const stEl = global.document.getElementById('lt-stress');
        try {
            const [lt, st] = await Promise.all([get('/api/v1/portfolio/lookthrough'),
                get('/api/v1/portfolio/stress-lookthrough')]);
            if (ltEl) ltEl.innerHTML = renderLookthrough(lt);
            const cEl = global.document.getElementById('lt-compliance');
            const paint = (c) => { if (cEl) cEl.innerHTML = complianceLineHtml(c, lt && lt.theme_view); };
            const pc = global.PfCompliance;
            paint(pc && pc.last ? pc.last() : null);
            if (global.addEventListener) global.addEventListener('pf:compliance', (e) => paint(e.detail));
            if (stEl) stEl.innerHTML = renderStress(st);
        } catch (e) {
            if (ltEl) ltEl.innerHTML = '<div class="pf-empty">穿透数据加载失败</div>';
            if (global.console) global.console.warn('lookthrough panel:', e);
        }
    }

    global.LookthroughPanel = {renderLookthrough, renderStress, load, complianceLineHtml, industryRows, UNKNOWN_INDUSTRY};
    if (global.document && global.document.addEventListener && global.fetch) {
        global.document.addEventListener('DOMContentLoaded', () => load(global.fetch.bind(global)));
    }
})(typeof window !== 'undefined' ? window : globalThis);
