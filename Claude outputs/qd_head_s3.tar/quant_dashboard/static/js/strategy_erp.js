// ============================================================
// strategy_erp.js — A股 ERP 择时引擎前端模块
// 依赖: strategy.js (需先加载)
// ============================================================

let _erpLoaded = false;
let _erpLastFetchTime = 0;          // 上次拉取时间戳 (ms)
let _erpCountdownTimer = null;      // P1: 倒计时定时器
let _erpGaugeChart = null;
let _erpHistoryChart = null;
const ERP_COOLDOWN_MS = 5 * 60 * 1000;  // 5 分钟刷新冷却
const ERP_STALE_MS = 30 * 60 * 1000;    // C4 fix: 30 分钟数据过期阈值
// 2026-10-24 简化: 主信号 = ERP 数值 + 估值区间 (已验证); 综合分 / 建议仓位降级为参考
const ERP_REF_NOTE = '仅供参考：2026-10 逐日回放实盘信号 (2010–2026) 显示，综合分与建议仓位相对"同等平均仓位一直持有"没有统计上显著的超额；' +
    '且对芯片 / 科创类 ETF 没有预测力。ERP 原始值经验证有预测力；近 4 年滚动分位区间样本外 R² 为负，仅作参考。详见 docs/ERP_VALIDATION_STEP3_CONCLUSIONS.md';

// P1: 注入变化高亮 CSS
(function injectERPHighlightCSS() {
    if (document.getElementById('erp-highlight-style')) return;
    const style = document.createElement('style');
    style.id = 'erp-highlight-style';
    style.textContent = `
        @keyframes erpValueFlash {
            0% { background: rgba(245,158,11,0.35); }
            100% { background: transparent; }
        }
        .erp-value-changed {
            animation: erpValueFlash 1.2s ease-out;
            border-radius: 4px;
        }
    `;
    document.head.appendChild(style);
})();

/**
 * P1: 启动/重启倒计时显示
 */
function startERPCountdown() {
    if (_erpCountdownTimer) clearInterval(_erpCountdownTimer);
    const el = document.getElementById('erp-refresh-countdown');
    if (!el) return;
    _erpCountdownTimer = setInterval(() => {
        const elapsed = Date.now() - _erpLastFetchTime;
        const remaining = Math.max(0, ERP_COOLDOWN_MS - elapsed);
        if (remaining <= 0) {
            el.textContent = '可刷新';
            el.style.color = '#10b981';
            clearInterval(_erpCountdownTimer);
            _erpCountdownTimer = null;
        } else {
            const mins = Math.floor(remaining / 60000);
            const secs = Math.floor((remaining % 60000) / 1000);
            el.textContent = `${mins}m${secs.toString().padStart(2,'0')}s 后可刷新`;
            el.style.color = '#475569';
        }
    }, 1000);
}

/**
 * P1: 检测数值变化并添加高亮动画
 */
function highlightERPChanges(oldSnap, newSnap) {
    if (!oldSnap || !newSnap) return;
    const pairs = [
        ['erp-val-erp',    oldSnap.erp_value,    newSnap.erp_value],
        ['erp-val-pe',     oldSnap.pe_ttm,       newSnap.pe_ttm],
        ['erp-val-yield',  oldSnap.yield_10y,    newSnap.yield_10y],
    ];
    pairs.forEach(([id, oldVal, newVal]) => {
        if (oldVal != null && newVal != null && oldVal !== newVal) {
            const el = document.getElementById(id);
            if (el) {
                el.classList.remove('erp-value-changed');
                void el.offsetWidth;  // force reflow
                el.classList.add('erp-value-changed');
            }
        }
    });
}

let _erpPrevSnapshot = null;  // P1: 保存上次快照用于变化比较

/**
 * 刷新按钮入口 — 带 5 分钟冷却 + Loading 状态
 */
async function refreshERPData() {
    const btn = document.getElementById('erp-refresh-btn');
    const elapsed = Date.now() - _erpLastFetchTime;
    
    // 5 分钟冷却检查
    if (_erpLoaded && elapsed < ERP_COOLDOWN_MS) {
        const remaining = Math.ceil((ERP_COOLDOWN_MS - elapsed) / 60000);
        // 闪烁提示
        if (btn) {
            const orig = btn.innerHTML;
            btn.innerHTML = '✅ 数据仍为最新';
            btn.style.borderColor = 'rgba(16,185,129,0.4)';
            btn.style.color = '#10b981';
            setTimeout(() => {
                btn.innerHTML = orig;
                btn.style.borderColor = 'rgba(245,158,11,0.3)';
                btn.style.color = '#f59e0b';
            }, 1500);
        }
        return;
    }
    
    // 解锁 + 设置 Loading 状态
    _erpLoaded = false;
    if (btn) {
        btn.disabled = true;
        btn.innerHTML = '⏳ 刷新中...';
        btn.style.opacity = '0.6';
    }
    
    try {
        await loadERPTimingData();
    } finally {
        if (btn) {
            btn.disabled = false;
            btn.innerHTML = '🔄 刷新实时数据';
            btn.style.opacity = '1';
        }
    }
}

async function loadERPTimingData() {
    // C4 fix: 数据超过30分钟自动刷新，而非永久缓存
    if (_erpLoaded && (Date.now() - _erpLastFetchTime) < ERP_STALE_MS) return;
    
    // Loading 状态: 信号 Badge
    const sigLabel = document.getElementById('erp-signal-label');
    const sigEmoji = document.getElementById('erp-signal-emoji');
    if (sigLabel) { sigLabel.textContent = '刷新中...'; sigLabel.style.color = '#f59e0b'; }
    if (sigEmoji) sigEmoji.textContent = '⏳';
    
    try {
        const resp = await fetch('/api/v1/strategy/erp-timing');
        const json = await resp.json();
        if (json.status !== 'success' || !json.data) { console.error('ERP API error:', json); return; }
        const data = json.data;

        // V2.1: 降级状态检测 — 引擎返回 fallback 时显示警告
        const bar = document.getElementById('erp-identity-bar');
        if (data.status === 'fallback') {
            if (bar) {
                bar.style.borderLeftColor = '#f59e0b';
                bar.style.boxShadow = '0 0 20px rgba(245,158,11,0.3)';
            }
            const badge = document.getElementById('erp-resonance-badge');
            if (badge) {
                badge.textContent = '⚠️ 数据降级模式';
                badge.style.background = 'rgba(245,158,11,0.15)';
                badge.style.color = '#f59e0b';
            }
        }
        // P1: 变化高亮 (比较新旧快照)
        const newSnap = data.current_snapshot || {};
        highlightERPChanges(_erpPrevSnapshot, newSnap);
        _erpPrevSnapshot = { ...newSnap };
        
        renderERPSnapshot(data);
        // 2026-10-31: 预警只保留决策相关 (v4 / 数据质量 / 引擎降级); 旧综合分预警不再上横幅
        const _decAlerts = buildERPDecisionAlerts(data);
        renderERPAlerts(_decAlerts);
        renderERPValuationKeys((data.current_snapshot || {}).allocation_v4, data.current_snapshot || {});
        renderERPTradeHub(data.trade_rules || {});
        renderERPDimBars(data.dimensions, data.encyclopedia || {});
        renderERPGauge(data.signal, data.trade_rules, data.position_layer, (data.current_snapshot || {}).allocation_v4, data.status);
        if (data.chart && data.chart.status === 'success') renderERPHistoryChart(data.chart, data);
        renderERPEncyclopedia(data.encyclopedia || {});
        renderERPDiagnosis(data.diagnosis || []);
        // V3.4: 仓位管理层
        if (data.position_layer) renderERPPositionLayer(data.position_layer, (data.current_snapshot || {}).allocation_v4);
        // 头部徽章
        const sig = data.signal || {};
        const tr = data.trade_rules || {};
        // 2026-10-24: 头部主信号改为 ERP 数值 + 估值区间; 综合分 / 仓位降为参考小字
        const snapH = data.current_snapshot || {};
        const zoneColor = (_ERP_ZONE_COLORS[snapH.valuation_zone]) || '#94a3b8';
        const emo = document.getElementById('erp-signal-emoji');
        emo.textContent = '\u25CF'; emo.style.color = zoneColor;
        // 2026-10-30: \u4E3B\u4FE1\u53F7 = \u4E09\u4E2A\u6570 (ERP / E/P \u5206\u4F4D / 10Y \u5206\u4F4D), \u4E00\u773C\u770B\u51FA"\u4FBF\u5B9C"\u6765\u81EA\u4F30\u503C\u8FD8\u662F\u6765\u81EA\u5229\u7387
        const lbl = document.getElementById('erp-signal-label');
        const _p = (v) => (v == null ? '--' : Math.round(v) + '%');
        lbl.textContent = 'ERP ' + (snapH.erp_value ?? '--') + '% \u00B7 E/P \u5206\u4F4D ' + _p(snapH.ep_percentile) +
            ' \u00B7 10Y \u5206\u4F4D ' + _p(snapH.yield_percentile);
        lbl.style.color = zoneColor;
        lbl.title = '\u4F30\u503C\u533A\u95F4: ' + (snapH.valuation_zone_label || '--') +
            '\nE/P = 1/PE (\u6CAA\u6DF1300 PE-TTM ' + (snapH.pe_ttm ?? '--') + 'x \u2192 ' + (snapH.earnings_yield ?? '--') + '%)' +
            '\n10Y \u56FD\u503A ' + (snapH.yield_10y ?? '--') + '%' +
            '\n\u5206\u4F4D = \u622A\u81F3\u5F53\u65E5\u5168\u90E8\u53EF\u5F97\u5386\u53F2 (\u81EA ' + (snapH.pct_history_start || '--') + ')\uFF0C\u6570\u503C\u8D8A\u9AD8\u8D8A\u4FBF\u5B9C/\u5229\u7387\u8D8A\u9AD8';
        const plPct = data.position_layer?.position?.suggested_position_pct;
        const v4 = snapH.allocation_v4;
        const posEl = document.getElementById('erp-signal-position');
        posEl.textContent = (snapH.valuation_zone_label ? snapH.valuation_zone_label + ' \u00B7 ' : '') +
            (v4 && v4.target_position_pct != null
                ? 'v4 \u76EE\u6807 ' + v4.target_position_pct + '% (' + (v4.status || '\u5F85\u68C0\u9A8C') + ') \u00B7 '
                : '') +
            '\u65E7\u89C4\u5219\u53C2\u8003: \u7EFC\u5408\u5206 ' + (sig.score ?? '--') +
            (plPct != null ? ' \u00B7 \u4ED3\u4F4D ' + plPct + '%' : '');
        posEl.title = ERP_REF_NOTE + (v4
            ? '\n\nv4 \u4ED3\u4F4D\u89C4\u5219 (' + v4.param_hash + ', ' + (v4.status || '') + (v4.forward_days != null ? ', \u524D\u5411\u8BB0\u5F55 ' + v4.forward_days + ' \u5929' : '') + '): ' +
              'ERP \u6B63\u5E38\u5316 ' + (v4.erp_adj ?? '--') + '% (10Y \u6309\u4E0D\u4F4E\u4E8E ' + v4.y10_floor + '% \u8BA1) \u2192 \u5206\u6863 ' +
              (v4.tier_position_pct ?? '--') + '%\uFF1B\u8D8B\u52BF ' + v4.trend + (v4.staging_active ? '\uFF0C\u5206\u6279\u5EFA\u4ED3\u4E2D' : '') +
              '\u3002\u4EC5\u9002\u7528\u4E8E\u6CAA\u6DF1300 \u7C7B\u5927\u76D8\u4ED3\u4F4D\uFF0C\u4E0D\u7528\u4E8E\u82AF\u7247 / \u79D1\u521B ETF\u3002'
            : '');
        // 2026-10-31: 共振标签来自旧综合分, 不再放在头部 (避免与 v4 冲突)
        const _rb = document.getElementById('erp-resonance-badge');
        if (_rb) { _rb.textContent = ''; _rb.style.display = 'none'; }
        document.getElementById('erp-update-time').textContent = '\u6700\u540E\u66F4\u65B0: ' + new Date().toLocaleString('zh-CN');
        // 脉冲动画 (只由决策相关预警驱动)
        const alerts = _decAlerts;
        const hasPulse = alerts.some(a => a.pulse);
        if (hasPulse) {
            const bar = document.getElementById('erp-identity-bar');
            const pulseAlert = alerts.find(a => a.pulse);
            const pulseColor = pulseAlert.level === 'danger' ? '#ef4444' : (pulseAlert.level === 'opportunity' ? '#10b981' : '#f59e0b');
            bar.style.boxShadow = '0 0 20px ' + pulseColor + '40';
            bar.style.borderLeftColor = pulseColor;
        }
        _erpLoaded = true;
        _erpLastFetchTime = Date.now();
        
        // P1: 启动倒计时
        startERPCountdown();
        
    } catch (e) {
        console.error('ERP load error:', e);
        // 错误恢复: 保持 _erpLoaded = false 允许重试
        if (sigLabel) { sigLabel.textContent = '加载失败'; sigLabel.style.color = '#ef4444'; }
        if (sigEmoji) sigEmoji.textContent = '❌';
    }
}


function renderERPSnapshot(data) {
    const snap = data.current_snapshot || {};
    const dims = data.dimensions || {};
    const m1 = dims.m1_trend?.m1_info || {};
    const vol = dims.volatility?.vol_info || {};
    const credit = dims.credit?.credit_info || {};
    // V3.0: 阈值从后端读取, 消除硬编码
    const thresh = data.erp_thresholds || { bullish: 5.0, bearish: 3.5 };
    // ERP
    const erpEl = document.getElementById('erp-val-erp');
    erpEl.textContent = (snap.erp_value || '--') + '%';
    erpEl.style.color = snap.erp_value >= thresh.bullish ? '#10b981' : (snap.erp_value >= thresh.bearish ? '#f59e0b' : '#ef4444');
    document.getElementById('erp-sub-erp').textContent = '\u8FD14\u5E74 ' + (snap.erp_percentile || '--') + '% \u5206\u4F4D';
    const trendErp = document.getElementById('erp-trend-erp');
    if (snap.erp_value >= thresh.bullish) { trendErp.textContent = '\u2191'; trendErp.style.color = '#10b981'; }
    else if (snap.erp_value < thresh.bearish) { trendErp.textContent = '\u2193'; trendErp.style.color = '#ef4444'; }
    else { trendErp.textContent = '\u2192'; trendErp.style.color = '#f59e0b'; }
    // PE
    document.getElementById('erp-val-pe').textContent = (snap.pe_ttm || '--') + 'x';
    document.getElementById('erp-sub-pe').textContent = '\u76C8\u5229\u6536\u76CA\u7387 ' + (snap.earnings_yield || '--') + '%';
    // 10Y
    document.getElementById('erp-val-yield').textContent = (snap.yield_10y || '--') + '%';
    // M1
    const m1El = document.getElementById('erp-val-m1');
    m1El.textContent = (m1.current ?? '--') + '%';
    m1El.style.color = m1.current > 0 ? '#10b981' : '#ef4444';
    // M1 fix: show data month to detect stale M1
    const m1Month = m1.data_month ? m1.data_month.replace(/^(\d{4})(\d{2})$/, '$1-$2') : '';
    document.getElementById('erp-sub-m1').textContent = 'M2: ' + (m1.m2_yoy ?? '--') + '%' + (m1Month ? ' \u00b7 \u622a\u81f3' + m1Month : '');
    const trendM1 = document.getElementById('erp-trend-m1');
    if (m1.direction === 'rising') { trendM1.textContent = '\u2191'; trendM1.style.color = '#10b981'; }
    else { trendM1.textContent = '\u2193'; trendM1.style.color = '#ef4444'; }
    // Vol
    const volEl = document.getElementById('erp-val-vol');
    volEl.textContent = (vol.current ?? '--');
    volEl.style.color = vol.regime === 'calm' ? '#10b981' : (vol.regime === 'extreme_panic' ? '#ef4444' : '#94a3b8');
    document.getElementById('erp-sub-vol').textContent = (vol.pct ?? '--') + '% \u5206\u4F4D | ' + ({calm:'\u5E73\u9759',normal:'\u6B63\u5E38',high:'\u504F\u9AD8',extreme_panic:'\u6050\u614C'}[vol.regime]||'--');
    // Credit
    const creditEl = document.getElementById('erp-val-credit');
    const scissor = m1.scissor ?? credit.scissor ?? '--';
    creditEl.textContent = (typeof scissor === 'number' ? (scissor >= 0 ? '+' : '') + scissor.toFixed(1) : scissor) + '%';
    creditEl.style.color = scissor >= -2 ? '#10b981' : '#f59e0b';
    document.getElementById('erp-sub-credit').textContent = scissor >= 0 ? '\u8D44\u91D1\u6D3B\u5316' : '\u8D44\u91D1\u6C89\u6DC0';
}

// 2026-10-31: 决策层预警 — 只来自 v4 快照与数据状态 (旧综合分 / M1 / 4 年分位预警不再上横幅)
function buildERPDecisionAlerts(data) {
    const out = [];
    const v4 = (data.current_snapshot || {}).allocation_v4;
    if (data.status === 'fallback') out.push({ level: 'danger', icon: '⛔', text: 'ERP 引擎降级：数据源异常，今日不给仓位', pulse: true });
    if (!v4) return out.length ? out : [{ level: 'normal' }];
    const fr = v4.freshness || {};
    if (fr.stale) out.push({ level: 'warning', icon: '⚠️', text: '数据截至 ' + fr.as_of + '，已 ' + fr.weekdays_since + ' 个工作日未更新' });
    if (v4.pending_increase) out.push({ level: 'opportunity', icon: '🪜', text: '分批加仓中：目标 ' + v4.target_position_pct + '% → 分档 ' + v4.tier_position_pct + '%（每周 +5pp）' });
    const tg = v4.triggers || {};
    const NEAR = 3.0;   // 距触发线 PE 变动 ≤3% 视为"接近" (展示规则, 不影响仓位)
    if (tg.up && Math.abs(tg.up.pe_change_pct) <= NEAR) out.push({ level: 'opportunity', icon: '▲', text: '接近升档：沪深300 PE ≤ ' + Number(tg.up.pe_at_or_below).toFixed(2) + '（距 ' + tg.up.pe_change_pct + '%）→ ' + tg.up.position_pct + '%' });
    if (tg.down && Math.abs(tg.down.pe_change_pct) <= NEAR) out.push({ level: 'warning', icon: '▼', text: '接近降档：沪深300 PE > ' + Number(tg.down.pe_above).toFixed(2) + '（距 +' + tg.down.pe_change_pct + '%）→ ' + tg.down.position_pct + '%' });
    return out.length ? out : [{ level: 'normal' }];
}

// 2026-10-31: 估值拆解 — ERP / E/P / 10Y / 正常化 ERP, 数字全部来自 v4 快照
function renderERPValuationKeys(v4, snap) {
    const box = document.getElementById('erp-valuation-keys');
    const note = document.getElementById('erp-valuation-note');
    if (!box) return;
    if (!v4) { box.innerHTML = '<div style="grid-column:1/-1;color:#94a3b8;font-size:0.75rem;">估值数据不可用</div>'; if (note) note.textContent = ''; return; }
    const NUM = 'font-variant-numeric:tabular-nums;';
    const f2 = (x) => (x == null || isNaN(x) ? '--' : Number(x).toFixed(2));
    const pct = (x) => (x == null ? '--' : Math.round(x) + '%');
    const bar = (x) => '<div style="height:4px;border-radius:2px;background:#1e293b;margin-top:6px;overflow:hidden;"><div style="height:4px;width:' + Math.max(0, Math.min(100, x || 0)) + '%;background:#475569;"></div></div>';
    const tile = (label, value, sub, p, emph) =>
        '<div style="padding:10px 12px;border-radius:8px;background:rgba(15,23,42,0.55);border:1px solid ' + (emph ? 'rgba(20,184,201,0.45)' : 'rgba(148,163,184,0.12)') + ';' + NUM + '">' +
        '<div style="font-size:0.62rem;letter-spacing:0.04em;color:#94a3b8;">' + label + '</div>' +
        '<div style="font-size:1.25rem;font-weight:700;color:#f1f5f9;line-height:1.3;">' + value + '</div>' +
        '<div style="font-size:0.64rem;color:#94a3b8;">' + sub + '</div>' + (p != null ? bar(p) : '') + '</div>';
    box.innerHTML =
        tile('ERP（原始）', f2(v4.erp) + '%', '全历史分位 ' + pct(v4.erp_pct), v4.erp_pct) +
        tile('E/P = 1/PE', f2(v4.ep) + '%', '沪深300 PE ' + f2(v4.pe_ttm) + 'x · 分位 ' + pct(v4.ep_pct), v4.ep_pct) +
        tile('10Y 国债', f2(v4.y10) + '%', '分位 ' + pct(v4.y10_pct) + (v4.guard_on ? ' · 低于 ' + f2(v4.y10_floor) + '%' : ''), v4.y10_pct) +
        tile('正常化 ERP', f2(v4.erp_adj) + '%', 'v4 分档 ' + (v4.tier_position_pct ?? '--') + '%', null, true);
    if (note) {
        const lift = (v4.erp != null && v4.erp_adj != null) ? (v4.erp - v4.erp_adj) : null;
        note.innerHTML = v4.guard_on && lift != null
            ? '原始 ERP 中有 <b>' + lift.toFixed(2) + 'pp</b> 来自利率低于 ' + f2(v4.y10_floor) + '%（10Y 处于历史 ' + pct(v4.y10_pct) + ' 分位）。'
              + '估值本身（E/P）处于 ' + pct(v4.ep_pct) + ' 分位，' + ((v4.ep_pct ?? 50) >= 60 ? '偏便宜。' : ((v4.ep_pct ?? 50) <= 40 ? '偏贵。' : '接近历史中位。'))
            : '10Y 不低于 ' + f2(v4.y10_floor) + '%，ERP 按实际利率计算，未做正常化。';
    }
}

function renderERPAlerts(alerts) {
    const banner = document.getElementById('erp-alert-banner');
    if (!alerts.length || (alerts.length === 1 && alerts[0].level === 'normal')) { banner.style.display = 'none'; return; }
    const colorMap = { danger: '#ef4444', warning: '#f59e0b', opportunity: '#10b981', normal: '#64748b' };
    banner.style.display = 'flex';
    banner.style.cssText += 'display:flex;flex-wrap:wrap;gap:6px;margin-top:8px;';
    banner.innerHTML = alerts.filter(a => a.level !== 'normal').map(a => {
        const c = colorMap[a.level] || '#64748b';
        const pulse = a.pulse ? 'animation:erpPulse 2s infinite;' : '';
        return '<div style="font-size:0.7rem;padding:4px 10px;border-radius:6px;background:' + c + '15;border:1px solid ' + c + '40;color:' + c + ';' + pulse + '">' + a.icon + ' ' + a.text + '</div>';
    }).join('');
    // 注入脉冲动画CSS
    if (!document.getElementById('erp-pulse-style')) {
        const style = document.createElement('style');
        style.id = 'erp-pulse-style';
        style.textContent = '@keyframes erpPulse{0%,100%{opacity:1;box-shadow:0 0 8px rgba(245,158,11,0.3)}50%{opacity:0.7;box-shadow:0 0 16px rgba(245,158,11,0.6)}}';
        document.head.appendChild(style);
    }
}

function renderERPTradeHub(trade) {
    // 信号等级条
    const levelBar = document.getElementById('erp-signal-level-bar');
    const levels = ['cash','underweight','reduce','hold','buy','strong_buy'];
    const levelLabels = ['\u6E05\u4ED3','\u4F4E\u914D','\u51CF\u4ED3','\u6807\u914D','\u4E70\u5165','\u5F3A\u4E70'];
    const levelColors = ['#ef4444','#f97316','#f59e0b','#3b82f6','#34d399','#10b981'];
    if (levelBar) {
        levelBar.innerHTML = levels.map((l, i) => {
            const active = l === trade.signal_key;
            return '<div style="width:' + (active ? '40' : '20') + 'px;height:8px;border-radius:4px;background:' + (active ? levelColors[i] : 'rgba(100,116,139,0.2)') + ';transition:all 0.5s;" title="' + levelLabels[i] + '"></div>';
        }).join('');
    }
    // ETF
    const etfC = document.getElementById('erp-etf-advice');
    if (etfC && trade.etf_advice) {
        etfC.innerHTML = trade.etf_advice.map(e => {
            return '<div style="display:flex;justify-content:space-between;align-items:center;padding:5px 8px;background:rgba(100,116,139,0.1);border-radius:4px;">' +
                '<div><span style="font-size:0.75rem;color:#e2e8f0;">' + e.etf.name + '</span><span style="font-size:0.6rem;color:#64748b;margin-left:6px;">' + e.etf.code + '</span></div>' +
                '<div style="text-align:right;"><span style="font-size:0.8rem;font-weight:700;color:#f59e0b;">' + e.ratio + '</span><div style="font-size:0.55rem;color:#64748b;">' + e.reason + '</div></div></div>';
        }).join('');
    }
    // 止盈 — V2.1: 动态触发标注 (与海外版对齐)
    const tpC = document.getElementById('erp-take-profit');
    if (tpC && trade.take_profit) {
        tpC.innerHTML = trade.take_profit.map(r => {
            const triggered = r.triggered;
            const bg = triggered
                ? 'background:rgba(16,185,129,0.18);border-left:3px solid #10b981;box-shadow:0 0 8px rgba(16,185,129,0.15);'
                : 'background:rgba(16,185,129,0.06);border-left:2px solid rgba(16,185,129,0.3);';
            const currentTag = r.current
                ? ' <span style="color:#64748b;font-size:0.58rem;margin-left:4px;">[' + r.current + ']</span>'
                : '';
            const statusIcon = triggered ? '✅ ' : '';
            return '<div style="font-size:0.65rem;padding:5px 8px;border-radius:5px;' + bg + 'transition:all 0.3s;">' +
                '<div style="color:' + (triggered ? '#10b981' : '#6ee7b7') + ';font-weight:' + (triggered ? '700' : '400') + ';">' + statusIcon + r.trigger + currentTag + '</div>' +
                '<div style="color:#94a3b8;margin-top:2px;font-size:0.6rem;">\u2192 ' + r.action + '</div></div>';
        }).join('');
    }
    // 止损 — V2.1: 动态触发标注
    const slC = document.getElementById('erp-stop-loss');
    if (slC && trade.stop_loss) {
        slC.innerHTML = trade.stop_loss.map(r => {
            const c = r.color || '#f59e0b';
            const triggered = r.triggered;
            const bg = triggered
                ? 'background:' + c + '20;border-left:3px solid ' + c + ';box-shadow:0 0 8px ' + c + '25;'
                : 'background:' + c + '08;border-left:2px solid ' + c + '40;';
            const currentTag = r.current
                ? ' <span style="color:#64748b;font-size:0.58rem;margin-left:4px;">[' + r.current + ']</span>'
                : '';
            const statusIcon = triggered ? '✅ ' : '';
            return '<div style="font-size:0.65rem;padding:5px 8px;border-radius:5px;' + bg + 'transition:all 0.3s;">' +
                '<div style="color:' + c + ';font-weight:' + (triggered ? '700' : '400') + ';">' + statusIcon + r.trigger + currentTag + '</div>' +
                '<div style="color:#94a3b8;margin-top:2px;font-size:0.6rem;">\u2192 ' + r.action + '</div></div>';
        }).join('');
    }
}

function renderERPDimBars(dims, encyclopedia) {
    const container = document.getElementById('erp-dim-bars');
    if (!container || !dims) return;
    const order = ['erp_abs', 'erp_pct', 'm1_trend', 'volatility', 'credit'];
    const icons = { erp_abs: '\uD83D\uDCCA', erp_pct: '\uD83D\uDCD0', m1_trend: '\uD83D\uDCA7', volatility: '\uD83C\uDF0A', credit: '\uD83D\uDD17' };
    const encKeys = { erp_abs: 'erp_abs', erp_pct: 'erp_pct', m1_trend: 'm1_trend', volatility: 'volatility', credit: 'credit' };
    let html = order.map(key => {
        const d = dims[key];
        if (!d) return '';
        const barColor = d.score >= 70 ? '#10b981' : (d.score >= 40 ? '#f59e0b' : '#ef4444');
        const weightPct = Math.round(d.weight * 100);
        const enc = encyclopedia[encKeys[key]];
        const encHtml = enc ? '<div id="erp-enc-' + key + '" style="display:none;margin-top:6px;padding:8px;background:rgba(59,130,246,0.08);border-radius:6px;border:1px solid rgba(59,130,246,0.2);font-size:0.63rem;color:#cbd5e1;line-height:1.6;">' +
            '<div style="color:#60a5fa;font-weight:600;margin-bottom:3px;">' + enc.title + '</div>' +
            '<div>\uD83D\uDCD6 ' + enc.what + '</div>' +
            '<div>\u2753 ' + enc.why + '</div>' +
            '<div style="color:#f59e0b;">\u26A0\uFE0F ' + enc.alert + '</div>' +
            '<div style="color:#64748b;">\uD83D\uDCDC ' + enc.history + '</div></div>' : '';
        return '<div>' +
            '<div style="display:flex;justify-content:space-between;align-items:baseline;margin-bottom:4px;">' +
            '<span style="font-size:0.78rem;color:#e2e8f0;">' + (icons[key]||'') + ' ' + d.label + ' <span style="color:#64748b;font-size:0.65rem;">(' + weightPct + '%)</span>' +
            (enc ? ' <span style="cursor:pointer;font-size:0.65rem;" onclick="var e=document.getElementById(\'erp-enc-' + key + '\');e.style.display=e.style.display===\'none\'?\'block\':\'none\';">\u2139\uFE0F</span>' : '') +
            '</span>' +
            '<span style="font-size:0.82rem;font-weight:700;color:' + barColor + ';">' + d.score + '</span></div>' +
            '<div style="height:8px;background:rgba(100,116,139,0.2);border-radius:4px;overflow:hidden;position:relative;">' +
            '<div style="height:100%;width:' + d.score + '%;background:linear-gradient(90deg,' + barColor + '80,' + barColor + ');border-radius:4px;transition:width 0.8s ease;"></div>' +
            '<div style="position:absolute;top:0;left:35%;width:1px;height:100%;background:rgba(255,255,255,0.15);"></div>' +
            '<div style="position:absolute;top:0;left:70%;width:1px;height:100%;background:rgba(255,255,255,0.15);"></div></div>' +
            '<div style="font-size:0.63rem;color:#94a3b8;margin-top:3px;">' + (d.desc || '') + '</div>' +
            encHtml + '</div>';
    }).join('');

    // V3.3: O7 ERP动量 + O12 市场势能修正器 (正负标签, 非进度条)
    const modifiers = ['erp_momentum', 'market_trend', 'momentum_confirm'];
    const modIcons = { erp_momentum: '\u26A1', market_trend: '\uD83C\uDF0A', momentum_confirm: '\uD83C\uDFAF' };
    const modItems = modifiers.map(key => {
        const d = dims[key];
        if (!d) return '';
        const val = d.score || 0;
        const color = val > 0 ? '#10b981' : (val < 0 ? '#ef4444' : '#64748b');
        const sign = val > 0 ? '+' : '';
        return '<div style="display:flex;justify-content:space-between;align-items:center;padding:5px 8px;background:' + color + '10;border-radius:6px;border:1px solid ' + color + '25;">' +
            '<span style="font-size:0.72rem;color:#cbd5e1;">' + (modIcons[key]||'') + ' ' + (d.label||key) + '</span>' +
            '<span style="font-size:0.78rem;font-weight:700;color:' + color + ';">' + sign + val + '\u5206</span></div>';
    }).filter(Boolean);

    if (modItems.length) {
        html += '<div style="margin-top:10px;padding-top:8px;border-top:1px solid rgba(100,116,139,0.2);">' +
            '<div style="font-size:0.65rem;color:#64748b;margin-bottom:5px;">\u4FEE\u6B63\u5668</div>' +
            '<div style="display:grid;grid-template-columns:1fr 1fr;gap:6px;">' + modItems.join('') + '</div>';
        // 修正器描述 (折叠显示)
        const descItems = modifiers.map(key => {
            const d = dims[key];
            return d && d.desc ? '<div style="font-size:0.6rem;color:#94a3b8;">' + (modIcons[key]||'') + ' ' + d.desc + '</div>' : '';
        }).filter(Boolean);
        if (descItems.length) {
            html += '<div style="margin-top:4px;">' + descItems.join('') + '</div>';
        }
        html += '</div>';
    }

    container.innerHTML = html;
}

// 2026-10-30: 综合分仪表盘 → v4 决策面板 (目标仓位 / 拆解链 / 触发地图 / 执行节奏 / 数据状态)
// 所有数字来自后端 current_snapshot.allocation_v4 (单一事实来源), 这里只做展示, 不做任何计算。
const _V4_TREND_CN = { bullish: '双均线多头', bearish: '双均线空头', weak: '短期弱势', neutral: '趋势中性', insufficient_data: '趋势数据不足' };

function _v4PosColor(p) { return p >= 65 ? '#10b981' : (p <= 25 ? '#ef4444' : '#f59e0b'); }
function _v4Esc(x) { return String(x == null ? '--' : x).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c])); }

function _v4LegacyHtml(signal, trade, posLayer) {
    const pl = (posLayer && posLayer.status === 'success') ? posLayer.position : null;
    const pct = pl ? pl.suggested_position_pct : null;
    const mods = [];
    if (pl && pl.o16_cap) mods.push('O16 ' + pl.o16_cap);
    if (pl && pl.o17_boost) mods.push('O17 +10pp');
    return '<details style="cursor:pointer;"><summary style="list-style:none;outline:none;">' +
        '旧规则（综合分+O16）' + _v4Esc(pct != null ? pct + '%' : (signal.position || '--')) + ' · 未验证 ▾</summary>' +
        '<div style="margin-top:6px;line-height:1.6;">综合分 ' + _v4Esc(signal.score) + ' · ' + _v4Esc(signal.label || '') +
        (trade && trade.resonance_label ? ' · ' + _v4Esc(trade.resonance_label) : '') +
        (mods.length ? '<br>' + _v4Esc(mods.join(' · ')) : '') +
        '<br><span style="color:#64748b;">2026-10 逐日回放验证：相对同等平均仓位没有显著超额，仅作对照。</span></div></details>';
}

function renderERPGauge(signal, trade, posLayer, v4, engineStatus) {
    signal = signal || {};
    const dom = document.getElementById('erp-gauge-chart');
    if (!dom) return;
    _erpGaugeChart = AC.disposeChart(_erpGaugeChart);
    dom.removeAttribute('_echarts_instance_');
    dom.style.height = 'auto';
    dom.style.minHeight = '200px';
    const panel = dom.parentElement;
    const title = panel ? panel.querySelector('h3') : null;
    const matrix = document.getElementById('erp-signal-matrix');
    if (matrix) {
        matrix.style.textAlign = 'left';
        matrix.innerHTML = _v4LegacyHtml(signal, trade, posLayer);
        matrix.title = ERP_REF_NOTE;
    }

    const ok = engineStatus !== 'fallback' && v4 && v4.target_position_pct != null;
    if (!ok) {   // fail-closed: 数据不可用时不显示任何仓位数字
        if (title) { title.textContent = '🎯 v4 目标仓位'; title.title = ''; }
        if (panel) panel.style.opacity = '0.6';
        dom.innerHTML = '<div style="padding:40px 8px;text-align:center;color:#94a3b8;font-size:0.8rem;">' +
            '⚠️ 数据不可用或引擎降级 — 不显示仓位<br><span style="font-size:0.7rem;color:#64748b;">刷新后仍不可用请检查数据源</span></div>';
        return;
    }
    if (panel) panel.style.opacity = '1';
    if (title) {
        title.textContent = '🎯 v4 目标仓位';
        title.title = 'v4 仓位规则（' + v4.param_hash + '）· 2010–2017 一次性检验弱通过（超额 +4.32%，90% 区间 [−0.19%, +8.92%]）。详见 docs/ERP_V4_PREREGISTRATION.md';
    }

    const fr = v4.freshness || {};
    const tg = v4.triggers || {};
    const lad = v4.ladder || { thresholds: [], positions_pct: [] };
    const tgt = v4.target_position_pct, tier = v4.tier_position_pct;
    const P = lad.positions_pct || [], T = lad.thresholds || [];
    const NUM = 'font-variant-numeric:tabular-nums;';
    const LBL = 'font-size:0.62rem;letter-spacing:0.04em;color:#94a3b8;';
    const f2 = (x) => (x == null || isNaN(x) ? '--' : Number(x).toFixed(2));
    const sgn = (x) => (x == null ? '--' : (x > 0 ? '+' : (x < 0 ? '−' : '')) + Math.abs(x).toFixed(1) + '%');
    // 档位色: 仓位越高越亮的单色阶 (表达"暴露程度", 不表达涨跌/好坏)
    const SEG = ['#334155', '#3f5873', '#3b6f8f', '#2f88a8', '#22a2bd', '#14b8c9'];
    const k = Math.max(0, P.indexOf(tier));
    const accent = SEG[k] || '#14b8c9';

    // 1) 主数字 + 证据
    let h = '<div style="display:flex;align-items:flex-end;justify-content:space-between;gap:10px;flex-wrap:wrap;">' +
        '<div style="border-left:3px solid ' + accent + ';padding-left:10px;">' +
        '<div style="' + LBL + '">目标仓位 · 沪深300 类大盘</div>' +
        '<div style="font-size:2.4rem;font-weight:700;line-height:1.1;color:#f1f5f9;' + NUM + '">' + _v4Esc(tgt) + '<span style="font-size:1.2rem;color:#94a3b8;">%</span>' +
        (v4.pending_increase ? '<span style="font-size:0.72rem;color:#94a3b8;margin-left:8px;">分档 ' + _v4Esc(tier) + '% · 分批加仓中</span>' : '') + '</div></div>' +
        '<div style="display:flex;flex-direction:column;align-items:flex-end;gap:4px;">' +
        '<span style="font-size:0.64rem;padding:2px 8px;border-radius:999px;border:1px solid rgba(245,158,11,0.5);color:#fbbf24;white-space:nowrap;">' + _v4Esc(v4.status) + '</span>' +
        '<span style="font-size:0.6rem;color:#94a3b8;' + NUM + '">前向 ' + _v4Esc(v4.forward_days != null ? v4.forward_days : 0) + ' 天 · <span style="font-family:ui-monospace,Consolas,monospace;">' + _v4Esc(String(v4.param_hash || '').slice(0, 8)) + '</span></span>' +
        '</div></div>';

    // 2) 连续刻度: 正常化 ERP 在档位带中的位置 (实心 = 正常化值, 空心 = 原始 ERP)
    if (P.length && T.length) {
        const lo = T[0] - 1.0, hi = T[T.length - 1] + 1.0, span = hi - lo;
        const pos = (x) => Math.max(0, Math.min(100, (x - lo) / span * 100));
        const edges = [lo].concat(T, [hi]);
        h += '<div style="margin:14px 0 2px;">';
        // 档位仓位标签
        h += '<div style="position:relative;height:14px;' + NUM + '">';
        for (let i = 0; i < P.length; i++) {
            const mid = (pos(edges[i]) + pos(edges[i + 1])) / 2;
            h += '<span style="position:absolute;left:' + mid + '%;transform:translateX(-50%);font-size:0.64rem;' +
                (i === k ? 'color:#f1f5f9;font-weight:700;' : 'color:#94a3b8;') + '">' + P[i] + '%</span>';
        }
        h += '</div>';
        // 色带 + 指针
        h += '<div style="position:relative;height:10px;margin-top:2px;border-radius:5px;overflow:visible;display:flex;">';
        for (let i = 0; i < P.length; i++) {
            const w = pos(edges[i + 1]) - pos(edges[i]);
            h += '<div style="width:' + w + '%;height:10px;background:' + (i === k ? SEG[i] : '#1e293b') + ';' +
                (i === 0 ? 'border-radius:5px 0 0 5px;' : '') + (i === P.length - 1 ? 'border-radius:0 5px 5px 0;' : '') +
                (i > 0 ? 'border-left:1px solid #0f172a;' : '') + '"></div>';
        }
        if (v4.guard_on && v4.erp != null) {
            h += '<div title="原始 ERP ' + f2(v4.erp) + '%（未做利率正常化）" style="position:absolute;top:-3px;left:calc(' + pos(v4.erp) + '% - 7px);width:12px;height:12px;border-radius:50%;border:2px solid #94a3b8;background:transparent;"></div>';
        }
        if (v4.erp_adj != null) {
            h += '<div title="正常化 ERP ' + f2(v4.erp_adj) + '%" style="position:absolute;top:-4px;left:calc(' + pos(v4.erp_adj) + '% - 2px);width:4px;height:18px;border-radius:2px;background:#f8fafc;box-shadow:0 0 0 2px #0f172a;"></div>';
        }
        h += '</div>';
        // 阈值刻度
        h += '<div style="position:relative;height:14px;margin-top:4px;' + NUM + '">';
        for (let i = 0; i < T.length; i++) {
            h += '<span style="position:absolute;left:' + pos(T[i]) + '%;transform:translateX(-50%);font-size:0.6rem;color:#94a3b8;">' + T[i] + '</span>';
        }
        h += '</div><div style="' + LBL + 'text-align:right;margin-top:2px;">正常化 ERP（%）' +
            (v4.guard_on ? ' · ▮ 正常化值　○ 原始值' : ' · ▮ 当前值') + '</div></div>';
    }

    // 3) 依据 (键值表)
    const trendTxt = (_V4_TREND_CN[v4.trend] || v4.trend || '--') + (v4.pending_increase ? ' · 分批加仓中' : ' · 目标已到位');
    const kv = (k_, v_) => '<div style="' + LBL + '">' + k_ + '</div><div style="font-size:0.74rem;color:#e2e8f0;' + NUM + '">' + v_ + '</div>';
    h += '<div style="display:grid;grid-template-columns:auto 1fr auto 1fr;gap:4px 10px;align-items:baseline;margin-top:10px;padding-top:10px;border-top:1px solid rgba(148,163,184,0.12);">' +
        kv('ERP', f2(v4.erp) + '%') +
        kv('10Y', f2(v4.y10) + '%' + (v4.guard_on ? ' <span style="color:#fbbf24;">→ 按 ' + f2(v4.y10_floor) + '%</span>' : '')) +
        kv('正常化 ERP', '<b>' + f2(v4.erp_adj) + '%</b>') +
        kv('趋势', _v4Esc(trendTxt)) +
        '</div>';

    // 4) 触发地图
    if (tg.available) {
        const cell = (dir, d, color) => {
            if (!d) return '<div style="flex:1;padding:8px 10px;border-radius:6px;background:rgba(15,23,42,0.5);font-size:0.68rem;color:#94a3b8;">' + (dir === 'up' ? '▲ 已在最高档' : '▼ 已在最低档') + '</div>';
            const pe = dir === 'up' ? '≤ ' + f2(d.pe_at_or_below) : '> ' + f2(d.pe_above);
            return '<div style="flex:1;padding:8px 10px;border-radius:6px;background:rgba(15,23,42,0.5);border-left:2px solid ' + color + ';' + NUM + '">' +
                '<div style="' + LBL + '">' + (dir === 'up' ? '▲ 升至 ' : '▼ 降至 ') + d.position_pct + '%</div>' +
                '<div style="font-size:0.86rem;color:#f1f5f9;font-weight:600;">PE ' + pe + '</div>' +
                '<div style="font-size:0.64rem;color:#94a3b8;">距当前 ' + sgn(d.pe_change_pct) + '</div></div>';
        };
        h += '<div style="margin-top:10px;"><div style="' + LBL + 'margin-bottom:4px;' + NUM + '">触发条件 · 当前 PE ' + f2(tg.pe_current) + 'x · 假设 10Y 不变（按 ' + f2(tg.y10_effective) + '% 计）</div>' +
            '<div style="display:flex;gap:6px;">' + cell('up', tg.up, '#14b8c9') + cell('down', tg.down, '#64748b') + '</div></div>';
    }

    // 5) 执行 · 数据 · 范围
    const dot = (c) => '<span style="display:inline-block;width:6px;height:6px;border-radius:50%;background:' + c + ';margin-right:5px;vertical-align:middle;"></span>';
    h += '<div style="margin-top:10px;display:grid;grid-template-columns:auto 1fr;gap:3px 10px;font-size:0.66rem;color:#cbd5e1;' + NUM + '">' +
        '<div style="' + LBL + '">执行</div><div>每周五收盘评估 · 偏离 ≥' + _v4Esc(v4.rebalance_band_pct) + 'pp 调仓 · 下次约 ' + _v4Esc(v4.next_eval_date) + '</div>' +
        '<div style="' + LBL + '">数据</div><div>' + (fr.stale
            ? dot('#f59e0b') + '<span style="color:#fbbf24;">截至 ' + _v4Esc(fr.as_of) + '，已 ' + _v4Esc(fr.weekdays_since) + ' 个工作日未更新</span>'
            : dot('#22c55e') + '截至 ' + _v4Esc(fr.as_of)) + '</div>' +
        '<div style="' + LBL + '">范围</div><div style="color:#94a3b8;">' + _v4Esc(v4.scope) + '</div>' +
        '</div>';

    dom.innerHTML = h;
}

// V4.0: 估值区间工具 — 区间判定 / 区间历史段落 / σ 口径
const _ERP_ZONE_COLORS = { strong: '#10b981', over: '#34d399', neutral: '#f59e0b', under: '#fb923c', danger: '#ef4444' };

function _erpZoneOf(v, s) {
    if (v == null) return null;
    if (v >= s.strong_buy_line) return { key: 'strong', label: '🟢 强买区', color: _ERP_ZONE_COLORS.strong };
    if (v >= s.overweight_line) return { key: 'over', label: '🔵 超配区', color: _ERP_ZONE_COLORS.over };
    if (v >= s.underweight_line) return { key: 'neutral', label: '⚪ 中性区', color: _ERP_ZONE_COLORS.neutral };
    if (v >= s.danger_line) return { key: 'under', label: '🟠 低配区', color: _ERP_ZONE_COLORS.under };
    return { key: 'danger', label: '🔴 危险区', color: _ERP_ZONE_COLORS.danger };
}

// 线相对均值的 σ 倍数 (如 6.04 → "μ+1σ")
function _erpSigmaTag(line, s) {
    if (line == null || !s.std) return '';
    const k = Math.round(((line - s.mean) / s.std) * 2) / 2;
    if (k === 0) return 'μ';
    return 'μ' + (k > 0 ? '+' : '−') + Math.abs(k) + 'σ';
}

// 连续处于强买区的段落 (间隔 ≤ mergeGap 个数据点的短暂跌出视为同一段, 避免色带碎片化)
function _erpStrongBuyEpisodes(dates, erp, line, mergeGap) {
    const eps = [];
    let cur = null, gap = 0;
    for (let i = 0; i < erp.length; i++) {
        const v = erp[i];
        const inZone = v != null && v >= line;
        if (inZone) {
            if (!cur) cur = { s: i, e: i, n: 0, peak: v, peakIdx: i };
            cur.e = i; cur.n += 1; gap = 0;
            if (v > cur.peak) { cur.peak = v; cur.peakIdx = i; }
        } else if (cur) {
            gap += 1;
            if (gap > mergeGap) { eps.push(cur); cur = null; gap = 0; }
        }
    }
    if (cur) eps.push(cur);
    const last = erp.length - 1;
    eps.forEach(ep => { ep.ongoing = ep.e === last; ep.start = dates[ep.s]; ep.end = dates[ep.e]; ep.peakDate = dates[ep.peakIdx]; });
    return eps;
}

// 2026-11-01: v4 决策视图 / 相对估值视图 / 买卖区间表 已移入共享模块 static/js/erp_zone_chart.js (首页同用)

function renderERPHistoryChart(chart, signalData) {
    const dom = document.getElementById('erp-history-chart');
    if (!dom) return;
    if (chart.v4 && Array.isArray(chart.v4.erp_adj) && typeof renderERPChartWithToggle === 'function') {
        _erpHistoryChart = renderERPChartWithToggle(chart, signalData, _erpHistoryChart, inst => { _erpHistoryChart = inst; });
        return;
    }
    // V4.1: 后端提供时点一致的滚动分位区间时使用 PIT 渲染; 旧后端回退到全样本 μ±σ 静态区间
    // 区间图已抽取为共享模块 static/js/erp_zone_chart.js (首页同用)
    if (chart.bands && chart.pit && Array.isArray(chart.bands.zone) && typeof renderERPZoneChart === 'function') {
        _erpHistoryChart = renderERPZoneChart(chart, signalData, _erpHistoryChart);
        return;
    }
    _erpHistoryChart = AC.disposeChart(_erpHistoryChart);
    _erpHistoryChart = AC.registerChart(echarts.init(dom));
    const stats = chart.stats || {};
    const hasM1 = chart.m1_yoy && chart.m1_yoy.some(v => v != null);
    const dates = chart.dates || [];
    const erp = chart.erp || [];
    const sb = stats.strong_buy_line;
    const episodes = (sb != null) ? _erpStrongBuyEpisodes(dates, erp, sb, 3) : [];

    // 动态标题 (保留 section-icon 和 subtitle-pill 结构)
    const titleEl = document.getElementById('erp-chart-title');
    if (titleEl) {
        const yrs = stats.date_range_years || '?';
        const textNodes = Array.from(titleEl.childNodes).filter(n => n.nodeType === Node.TEXT_NODE);
        if (textNodes.length > 0) {
            textNodes.forEach(n => n.textContent = '');
            textNodes[0].textContent = ' ERP 估值走势 (近' + yrs + '年) ';
        } else {
            titleEl.textContent = '\u{1F4C8} ERP 估值走势 (近' + yrs + '年) · 五档估值区间';
        }
    }

    renderERPChartKPIs(stats, signalData, episodes);
    _renderERPChartNote(dom, stats, episodes);

    // 横向估值色带: 强买区显著加强, 其余区间保持低噪
    const markAreaData = [
        [{ yAxis: sb, name: '强买区 ≥' + sb + '%',
           itemStyle: { color: 'rgba(16,185,129,0.13)' },
           label: { show: true, position: 'insideTopLeft', color: '#10b981', fontSize: 10, fontWeight: 700 } },
         { yAxis: 'max' }],
        [{ yAxis: stats.overweight_line, itemStyle: { color: 'rgba(16,185,129,0.04)' } }, { yAxis: sb }],
        [{ yAxis: stats.underweight_line, itemStyle: { color: 'transparent' } }, { yAxis: stats.overweight_line }],
        [{ yAxis: stats.danger_line, itemStyle: { color: 'rgba(239,68,68,0.04)' } }, { yAxis: stats.underweight_line }],
        [{ yAxis: stats.danger_line, itemStyle: { color: 'rgba(239,68,68,0.07)' } }, { yAxis: 'min' }],
    ];

    // 纵向色带: 历史上每一段进入强买区的时间窗口
    const episodeAreas = episodes.map(ep => [
        { xAxis: ep.start, itemStyle: { color: ep.ongoing ? 'rgba(16,185,129,0.22)' : 'rgba(16,185,129,0.10)' },
          label: { show: ep.n >= 10 || ep.ongoing, position: 'insideTop', color: '#10b981', fontSize: 9,
                   formatter: ep.ongoing ? '当前' : (ep.start.substring(0, 7)) } },
        { xAxis: ep.end }
    ]);

    // 当前值 + 历史极值
    const markPointData = [];
    const lastDate = dates[dates.length - 1];
    const curZone = _erpZoneOf(stats.current, stats);
    if (stats.current != null) {
        markPointData.push({
            coord: [lastDate, stats.current], name: '当前', symbol: 'pin', symbolSize: 46,
            itemStyle: { color: curZone ? curZone.color : '#f59e0b', borderColor: '#0f172a', borderWidth: 1 },
            label: { formatter: stats.current + '%', color: '#fff', fontSize: 10, fontWeight: 700 }
        });
    }
    (stats.extremes || []).forEach(e => {
        markPointData.push({
            coord: [e.date, e.value],
            name: e.type === 'max' ? '历史最高' : '历史最低',
            symbol: e.type === 'max' ? 'triangle' : 'arrow',
            symbolSize: 12, symbolRotate: e.type === 'min' ? 180 : 0,
            itemStyle: { color: e.type === 'max' ? '#10b981' : '#ef4444' },
            label: { show: true, formatter: e.value + '%', fontSize: 9, color: e.type === 'max' ? '#10b981' : '#ef4444', position: e.type === 'max' ? 'top' : 'bottom' }
        });
    });

    const legendData = ['ERP', '强买区间', 'PE-TTM', '10Y国债'];
    if (hasM1) legendData.push('M1同比');
    const tag = line => _erpSigmaTag(line, stats);

    _erpHistoryChart.setOption({
        tooltip: {
            trigger: 'axis', backgroundColor: 'rgba(15,23,42,0.95)', borderColor: '#334155',
            textStyle: { fontSize: 11, color: '#e2e8f0' },
            formatter: function(params) {
                let r = '<div style="font-size:0.7rem;color:#64748b;margin-bottom:4px;">' + params[0].axisValue + '</div>';
                params.forEach(p => {
                    if (p.value != null && p.seriesName !== '强买区间') {
                        const unit = p.seriesName === 'PE-TTM' ? 'x' : '%';
                        r += '<div>' + p.marker + ' ' + p.seriesName + ': <b>' + p.value + unit + '</b></div>';
                    }
                });
                const erpParam = params.find(p => p.seriesName === 'ERP');
                if (erpParam && erpParam.value != null) {
                    const z = _erpZoneOf(erpParam.value, stats);
                    const gap = (erpParam.value - sb);
                    r += '<div style="margin-top:3px;padding-top:3px;border-top:1px solid rgba(255,255,255,0.1);font-size:10px;">' +
                         '<span style="color:' + z.color + ';font-weight:700;">' + z.label + '</span>' +
                         ' <span style="color:#64748b;">· 距强买线 ' + (gap >= 0 ? '+' : '') + gap.toFixed(2) + 'pp</span></div>';
                }
                return r;
            }
        },
        legend: {
            data: legendData, top: 0,
            textStyle: { color: '#94a3b8', fontSize: 10 },
            selected: { '10Y国债': false }
        },
        toolbox: {
            right: 20, top: 0,
            feature: {
                saveAsImage: { title: '保存', pixelRatio: 2, backgroundColor: '#0f172a' },
                restore: { title: '重置' }
            },
            iconStyle: { borderColor: '#64748b' }
        },
        // ERP 线按区间着色: 强买区绿色 / 危险区红色 / 其余琥珀色
        visualMap: {
            show: false, seriesIndex: 0, dimension: 1,
            pieces: [
                { gte: sb, color: _ERP_ZONE_COLORS.strong },
                { lt: stats.danger_line, color: _ERP_ZONE_COLORS.danger },
                { gte: stats.danger_line, lt: sb, color: _ERP_ZONE_COLORS.neutral }
            ]
        },
        grid: { top: 40, bottom: 55, left: 50, right: hasM1 ? 90 : 50 },
        dataZoom: [
            { type: 'inside', start: 65, end: 100 },
            { type: 'slider', height: 16, bottom: 4, borderColor: 'rgba(255,255,255,0.06)',
              fillerColor: 'rgba(245,158,11,0.12)', handleStyle: { color: '#f59e0b', borderColor: '#f59e0b' },
              textStyle: { color: '#64748b', fontSize: 9 },
              dataBackground: { lineStyle: { color: '#334155' }, areaStyle: { color: 'rgba(245,158,11,0.05)' } }
            }
        ],
        xAxis: {
            type: 'category', data: dates, boundaryGap: false,
            axisLabel: { color: '#64748b', fontSize: 10, formatter: function(v) { return v.substring(0, 7); } },
            axisLine: { lineStyle: { color: '#334155' } }
        },
        yAxis: [
            { type: 'value', name: 'ERP %', nameTextStyle: { color: '#64748b', fontSize: 10 },
              // 纵轴贴合可见数据, 避免被色带拉到 0% 而压缩强买区
              min: v => Math.max(0, Math.floor(v.min - 0.5)),
              axisLabel: { color: '#64748b', fontSize: 10, formatter: '{value}%' },
              splitLine: { lineStyle: { color: 'rgba(100,116,139,0.08)' } }
            },
            { type: 'value', name: 'PE-TTM', position: 'right',
              nameTextStyle: { color: '#3b82f6', fontSize: 10 },
              axisLabel: { color: '#3b82f680', fontSize: 9 },
              splitLine: { show: false }
            },
            hasM1 ? {
                type: 'value', name: 'M1%', nameTextStyle: { color: '#a78bfa', fontSize: 10 },
                position: 'right', offset: 40,
                axisLabel: { color: '#a78bfa', fontSize: 9, formatter: '{value}%' },
                splitLine: { show: false }
            } : null
        ].filter(Boolean),
        series: [
            {
                name: 'ERP', type: 'line', data: erp, yAxisIndex: 0,
                lineStyle: { width: 2.5, shadowColor: 'rgba(245,158,11,0.2)', shadowBlur: 4 },
                itemStyle: { color: '#f59e0b' },
                symbol: 'none', z: 10,
                areaStyle: {
                    color: { type: 'linear', x: 0, y: 0, x2: 0, y2: 1,
                        colorStops: [
                            { offset: 0, color: 'rgba(245,158,11,0.10)' },
                            { offset: 1, color: 'rgba(245,158,11,0)' }
                        ]
                    }
                },
                markLine: {
                    silent: true, symbol: 'none', lineStyle: { type: 'dashed', width: 1 },
                    data: [
                        { yAxis: stats.mean, label: { formatter: '均值μ ' + stats.mean + '%', color: '#94a3b8', fontSize: 9 }, lineStyle: { color: '#64748b' } },
                        { yAxis: sb, label: { formatter: '强买线 ' + sb + '% (' + tag(sb) + ')', color: '#10b981', fontSize: 10, fontWeight: 700, position: 'insideEndTop' }, lineStyle: { color: '#10b981', type: 'solid', width: 1.4 } },
                        { yAxis: stats.overweight_line, label: { formatter: '超配 ' + stats.overweight_line + '% (' + tag(stats.overweight_line) + ')', color: '#34d399', fontSize: 9, position: 'insideEndTop' }, lineStyle: { color: '#34d39966' } },
                        { yAxis: stats.underweight_line, label: { formatter: '低配 ' + stats.underweight_line + '% (' + tag(stats.underweight_line) + ')', color: '#fb923c', fontSize: 9, position: 'insideEndTop' }, lineStyle: { color: '#fb923c66' } },
                        { yAxis: stats.danger_line, label: { formatter: '危险线 ' + stats.danger_line + '% (' + tag(stats.danger_line) + ')', color: '#ef4444', fontSize: 9, position: 'insideEndTop' }, lineStyle: { color: '#ef4444aa', type: 'solid', width: 1 } }
                    ]
                },
                markArea: { silent: true, data: markAreaData },
                markPoint: { data: markPointData, animation: true, animationDuration: 600 }
            },
            {
                // 仅承载纵向强买区间色带, 可通过图例开关
                name: '强买区间', type: 'line', data: [], yAxisIndex: 0,
                itemStyle: { color: '#10b981' }, lineStyle: { opacity: 0 }, symbol: 'none',
                markArea: { silent: true, data: episodeAreas }
            },
            {
                name: 'PE-TTM', type: 'line', data: chart.pe_ttm, yAxisIndex: 1,
                lineStyle: { color: '#3b82f6', width: 1.5, type: 'dashed' },
                itemStyle: { color: '#3b82f6' }, symbol: 'none'
            },
            {
                name: '10Y国债', type: 'line', data: chart.yield_10y, yAxisIndex: 0,
                lineStyle: { color: '#ef4444', width: 1, type: 'dotted' },
                itemStyle: { color: '#ef4444' }, symbol: 'none'
            },
            hasM1 ? {
                name: 'M1同比', type: 'line', data: chart.m1_yoy, yAxisIndex: 2,
                lineStyle: { color: '#a78bfa', width: 2, type: 'solid' },
                itemStyle: { color: '#a78bfa' },
                symbol: 'none', smooth: true,
                areaStyle: {
                    color: { type: 'linear', x: 0, y: 0, x2: 0, y2: 1,
                        colorStops: [{offset:0,color:'rgba(167,139,250,0.10)'},{offset:1,color:'rgba(167,139,250,0)'}]
                    }
                }
            } : null
        ].filter(Boolean)
    });
}

// 口径说明: 区间来自全样本 μ/σ (含后视信息); 估值区间 ≠ 交易信号
function _renderERPChartNote(dom, stats, episodes) {
    let note = document.getElementById('erp-chart-note');
    if (!note) {
        note = document.createElement('div');
        note.id = 'erp-chart-note';
        note.style.cssText = 'margin-top:6px;font-size:0.65rem;line-height:1.5;color:#64748b;';
        dom.parentNode.insertBefore(note, dom.nextSibling);
    }
    const n = episodes.length;
    note.textContent = '区间口径: 全样本 μ=' + stats.mean + '%, σ=' + stats.std +
        '%，强买线=μ+1σ。历史区间使用了其后的数据 (含后视)，仅用于估值定位。' +
        '样本内共 ' + n + ' 段强买区间 (绿色纵带)。估值区间≠交易信号，仓位以上方综合信号为准。';
}

// ERP 图表 KPI 卡片: 新增"估值区间"状态卡, 并并列展示综合信号, 防止把估值区间误读为买入信号
function renderERPChartKPIs(stats, signalData, episodes) {
    const container = document.getElementById('erp-chart-kpis');
    if (!container) return;
    const sig = signalData || {};
    const snap = sig.current_snapshot || {};
    const signal = sig.signal || {};
    const pct = snap.erp_percentile || '--';
    const deviation = stats.current_vs_mean;
    const devColor = deviation > 0 ? '#10b981' : (deviation < -5 ? '#ef4444' : '#f59e0b');
    const devSign = deviation > 0 ? '+' : '';
    const zone = _erpZoneOf(stats.current, stats) || { label: '--', color: '#94a3b8', key: '' };
    const sb = stats.strong_buy_line;
    const gap = (stats.current != null && sb != null) ? (stats.current - sb) : null;
    const curEp = (episodes || []).find(ep => ep.ongoing);
    let zoneSub = '';
    if (zone.key === 'strong' && curEp) {
        zoneSub = '已持续约 ' + (curEp.n * 3) + ' 个交易日 (' + curEp.n + ' 个采样点) · 高出强买线 ' + gap.toFixed(2) + 'pp';
    } else if (gap != null) {
        zoneSub = '距强买线 ' + (gap >= 0 ? '+' : '') + gap.toFixed(2) + 'pp';
    }
    const sigText = signal.label ? ('综合信号(参考): ' + (signal.emoji || '') + signal.label +
        (signal.score != null ? ' ' + signal.score : '') + (signal.position ? ' · ' + signal.position : '')) : '';

    const card = (label, value, color, sub, flex) => `<div style="flex:${flex || 1};min-width:0;background:rgba(15,23,42,0.6);border:1px solid ${flex ? color + '55' : 'rgba(255,255,255,0.06)'};border-radius:8px;padding:8px 12px;text-align:center;">
        <div style="font-size:0.65rem;color:#64748b;margin-bottom:3px;">${label}</div>
        <div style="font-size:1.1rem;font-weight:800;color:${color};">${value}</div>
        ${sub ? `<div style="font-size:0.6rem;color:#94a3b8;margin-top:2px;">${sub}</div>` : ''}
    </div>`;

    container.innerHTML = [
        card('估值区间', zone.label, zone.color, [zoneSub, sigText].filter(Boolean).join('<br>'), 1.8),
        card('当前 ERP', (stats.current != null ? stats.current : '--') + '%', zone.color),
        card('均值偏离', devSign + deviation + '%', devColor),
        card('近4年分位', pct + '%', pct >= 70 ? '#10b981' : (pct <= 30 ? '#ef4444' : '#94a3b8')),
        card('历史超配区占比', (stats.buy_zone_pct || '--') + '%', '#34d399', '≥' + _erpSigmaTag(stats.overweight_line, stats)),
    ].join('');
}

function renderERPEncyclopedia(enc) {
    const body = document.getElementById('erp-encyclopedia-body');
    if (!body || !enc) return;
    const order = ['erp_abs', 'erp_pct', 'm1_trend', 'volatility', 'credit'];
    const colors = ['#f59e0b', '#8b5cf6', '#3b82f6', '#ec4899', '#06b6d4'];
    body.innerHTML = order.map((key, i) => {
        const e = enc[key];
        if (!e) return '';
        const c = colors[i];
        return '<div style="background:rgba(15,23,42,0.6);border:1px solid ' + c + '30;border-radius:8px;padding:12px;">' +
            '<div style="font-size:0.8rem;font-weight:600;color:' + c + ';margin-bottom:6px;">' + e.title + '</div>' +
            '<div style="font-size:0.65rem;color:#cbd5e1;line-height:1.7;">' +
            '<div style="margin-bottom:4px;">\uD83D\uDCD6 <b>\u662F\u4EC0\u4E48:</b> ' + e.what + '</div>' +
            '<div style="margin-bottom:4px;">\u2753 <b>\u4E3A\u4EC0\u4E48\u91CD\u8981:</b> ' + e.why + '</div>' +
            '<div style="margin-bottom:4px;color:#f59e0b;">\u26A0\uFE0F <b>\u8B66\u793A:</b> ' + e.alert + '</div>' +
            '<div style="color:#64748b;">\uD83D\uDCDC <b>\u5386\u53F2:</b> ' + e.history + '</div></div></div>';
    }).join('');
}

function renderERPDiagnosis(cards) {
    const container = document.getElementById('erp-diagnosis-cards');
    if (!container) return;
    const typeMap = {
        success: { bg: 'rgba(16,185,129,0.08)', border: '#10b981', icon: '\u2705' },
        info:    { bg: 'rgba(59,130,246,0.08)', border: '#3b82f6', icon: '\u2139\uFE0F' },
        warning: { bg: 'rgba(245,158,11,0.08)', border: '#f59e0b', icon: '\u26A0\uFE0F' },
        danger:  { bg: 'rgba(239,68,68,0.08)',  border: '#ef4444', icon: '\uD83D\uDEA8' }
    };
    container.innerHTML = cards.map(c => {
        const style = typeMap[c.type] || typeMap.info;
        return '<div style="background:' + style.bg + ';border:1px solid ' + style.border + '33;border-left:3px solid ' + style.border + ';border-radius:8px;padding:10px 12px;">' +
            '<div style="font-size:0.75rem;font-weight:600;color:' + style.border + ';margin-bottom:3px;">' + style.icon + ' ' + c.title + '</div>' +
            '<div style="font-size:0.65rem;color:#cbd5e1;line-height:1.5;">' + c.text + '</div></div>';
    }).join('');
}

// V3.4: 仓位管理层渲染 (O16 趋势 + O17 换手率 + 仓位建议)
function renderERPPositionLayer(pl, v4) {
    if (!pl || pl.status !== 'success') return;
    const trend = pl.trend || {};
    const vol = pl.volume || {};
    const pos = pl.position || {};

    // O16 趋势
    const trendColors = { bullish: '#10b981', neutral: '#94a3b8', weak: '#f59e0b', bearish: '#ef4444' };
    const trendColor = trendColors[trend.status] || '#94a3b8';
    const trendCard = document.getElementById('erp-pl-trend');
    if (trendCard) trendCard.style.borderColor = trendColor + '40';
    const te = document.getElementById('erp-pl-trend-emoji');
    if (te) te.textContent = trend.emoji || '⚪';
    const tl = document.getElementById('erp-pl-trend-label');
    if (tl) { tl.textContent = trend.label || '--'; tl.style.color = trendColor; }
    const td = document.getElementById('erp-pl-trend-detail');
    if (td) td.textContent = 'PE ' + (trend.pe_current || '--') + ' · MA60 ' + (trend.pe_ma60 || '--') + ' · MA120 ' + (trend.pe_ma120 || '--');

    // O17 换手率
    const zs = vol.zscore != null ? vol.zscore : '--';
    const volColor = vol.signal === 'high_conviction' ? '#10b981' : (vol.signal === 'low_activity' ? '#ef4444' : '#94a3b8');
    const volLabels = { high_conviction: '🔥 放量确认', low_activity: '💤 缩量冷淡', neutral: '📊 正常水平' };
    const zsEl = document.getElementById('erp-pl-vol-zscore');
    if (zsEl) { zsEl.textContent = typeof zs === 'number' ? (zs >= 0 ? '+' : '') + zs.toFixed(2) : zs; zsEl.style.color = volColor; }
    const vsEl = document.getElementById('erp-pl-vol-signal');
    if (vsEl) { vsEl.textContent = volLabels[vol.signal] || 'z-score'; vsEl.style.color = volColor; }
    const vdEl = document.getElementById('erp-pl-vol-detail');
    if (vdEl) vdEl.textContent = '换手率 ' + (vol.turnover_rate || '--') + '%';
    const volCard = document.getElementById('erp-pl-volume');
    if (volCard) volCard.style.borderColor = volColor + '40';

    // 仓位建议 — 2026-10-31: 该卡片已移入"旧框架附录", 显示旧规则 (综合分+O16/O17) 自身的仓位, 明确标注未验证
    const legacyPct = pos.suggested_position_pct;
    const posVal = document.getElementById('erp-pl-pos-value');
    if (posVal) {
        posVal.textContent = (legacyPct != null ? legacyPct : '--') + '%';
        posVal.style.color = '#94a3b8';
    }
    const posBase = document.getElementById('erp-pl-pos-base');
    if (posBase) posBase.textContent = '基础 ' + (pos.base_position_pct ?? '--') + '% (综合分 ' + (pos.score ?? '--') + ')';
    const posMods = document.getElementById('erp-pl-pos-mods');
    if (posMods) {
        const parts = [];
        if (pos.o16_cap) parts.push('O16: ' + pos.o16_cap);
        if (pos.o17_boost) parts.push('O17: +10pp');
        if (!parts.length) parts.push('无修正');
        posMods.textContent = parts.join(' · ') + (v4 && v4.target_position_pct != null ? ' · 现行 v4 目标 ' + v4.target_position_pct + '%' : '');
        posMods.title = ERP_REF_NOTE;
    }
    const posCard = document.getElementById('erp-pl-position');
    if (posCard) {
        posCard.style.borderColor = 'rgba(100,116,139,0.25)';
        const posTitle = posCard.firstElementChild;
        if (posTitle) { posTitle.textContent = '旧规则仓位（未验证）'; posTitle.title = ERP_REF_NOTE; }
    }
}

// Phase 2: resize 已由 alphacore_utils.js 注册中心统一处理

// ============================================================
