document.addEventListener('DOMContentLoaded', function() {
    const navContainer = document.getElementById('sector-nav-container');
    const datePicker = document.getElementById('data-date-picker');
    const syncBtn = document.getElementById('sync-btn');
    const overlay = document.getElementById('loading-overlay');

    let charts = { rps: null, value: null, risk: null, rsLine: null, heatmap: null };
    let currentCode = null;
    let allSectorData = [];

    const SECTORS = [
        // ── 硬科技·芯片算力 ──
        { code: "512760.SH", name: "半导体/芯片" },
        { code: "512720.SH", name: "计算机/AI" },
        { code: "562030.SH", name: "信创/算力" },
        // ── 通信·星际 ──
        { code: "515880.SH", name: "通信设备/卫星互联" },
        { code: "159218.SZ", name: "卫星/商业航天" },
        // ── 智造·装备 ──
        { code: "562500.SH", name: "人形机器人/智能制造" },
        { code: "159663.SZ", name: "工业母机/自主可控" },
        // ── 新能源·新材料 ──
        { code: "515030.SH", name: "新能源车" },
        { code: "516360.SH", name: "前沿新材料" },
        { code: "512400.SH", name: "有色金属" },
        // ── 生物·医药 ──
        { code: "512010.SH", name: "医药生物" },
        { code: "159992.SZ", name: "创新药/生物制造" },
        // ── 数字经济 ──
        { code: "515400.SH", name: "数据要素/数字经济" },
        // ── 国防·金融·成长 ──
        { code: "512660.SH", name: "军工龙头" },
        { code: "512880.SH", name: "证券/非银" },
        { code: "159915.SZ", name: "创业板(宽基)" }
    ];

    // === 指标百科数据 V4.0 ===
    const GLOSSARY = [
        { name: "Alpha Score (研究排序分)", desc: "四因子加权的研究排序分：热度30% + 动量25% + 价格位置安全25% + 趋势强度20%。只用于横向排序，不等同于买入信号，仍须通过市场环境与风险闸门。", range: "60-80 靠前", warn: "< 35 排序靠后" },
        { name: "RPS (动态相对强度)", desc: "该行业ETF近20日收益率在全部核心ETF池中的排名百分位。反映板块在同类中的相对表现。", range: "> 80 优秀", warn: "< 30 极弱，谨慎追入" },
        { name: "5年价格位置", desc: "当前复权价格在过去5年(1250个交易日)价格分布中的百分位。只衡量历史位置，不代表PE/PB估值，低位不等于便宜。", range: "20-60 中部区间", warn: "> 80 历史高位，回撤风险上升" },
        { name: "成交拥挤度", desc: "当日成交额与20日平均成交额的比值。衡量场内资金的拥挤程度，过高表示追涨情绪浓厚。", range: "0.8-1.5x 健康", warn: "> 2.0x 极度拥挤，追高危险" },
        { name: "热度分 (Heat Score)", desc: "资金关注度综合评分。成交放量比40% + 5日动量35% + 拥挤度修正25%。反映市场资金对该行业的关注热情。", range: "45-70 活跃", warn: "> 85 过热，可能见顶" },
        { name: "放量比 (Vol Ratio)", desc: "当日成交金额与20日均量的比值，>1表示放量。配合价格方向判断：放量上涨=强势，放量下跌=出货。", range: "0.8-1.5x", warn: "> 2.5x 可能见顶放量" },
        { name: "MA20 / MA60", desc: "20日/60日均线。站上MA20=短期趋势向好，站上MA60=中期趋势健康。MA20斜率向上=趋势加速。", range: "站上MA20+MA60 最佳", warn: "跌破MA60 → 中线止损" },
        { name: "20D 动量趋势", desc: "近20日的累计涨跌幅。正值=上涨趋势，负值=下跌趋势。", range: "+2~8% 健康上行", warn: "> +12% 短期严重过热" }
    ];

    // === 颜色工具 ===
    // 配色约定: 红/绿只表示涨跌 (红涨绿跌)；评级与状态使用中性色和琥珀色
    const C = { up: '#f0525a', down: '#1fb37e', flat: '#8b93a1', text: '#e6e8ec', text2: '#a3a9b5', text3: '#6b7280', accent: '#7c9cff', warn: '#d9a441', line: 'rgba(255,255,255,0.07)' };
    function gradeColor(grade) {
        return { A: '#9db4ff', B: '#7c9cff', C: '#8b93a1', D: '#d9a441', F: '#6b7280' }[grade] || '#8b93a1';
    }
    function trendColor(v) { return v > 0 ? C.up : (v < 0 ? C.down : C.flat); }
    function momTrendColor(trend) {
        return { strong_up: C.up, up: C.up, neutral: C.flat, down: C.down, strong_down: C.down }[trend] || C.flat;
    }
    function signed(v, d = 1) { const n = Number(v) || 0; return `${n > 0 ? '+' : ''}${n.toFixed(d)}%`; }

    // === 初始化 ===
    async function initPage() {
        datePicker.value = new Date().toISOString().split('T')[0];
        initCharts();
        renderGlossary();
        initGlossaryToggle();
        // V5.1 Fix P1#7: 先 loadRotationMatrix 获取 _lastFreshness，再 loadRegimeBanner
        await loadRotationMatrix();
        loadRegimeBanner();
        if (currentCode) loadIndustryDetail(currentCode);
    }

    function initCharts() {
        charts.rps = AC.registerChart(echarts.init(document.getElementById('gauge-rps')));
        charts.value = AC.registerChart(echarts.init(document.getElementById('gauge-value')));
        charts.risk = AC.registerChart(echarts.init(document.getElementById('gauge-risk')));
        charts.rsLine = AC.registerChart(echarts.init(document.getElementById('rs-line-chart')));
        charts.heatmap = AC.registerChart(echarts.init(document.getElementById('heatmap-chart')));
        // 容器尺寸变化(窄屏布局切换、首屏加载时宽度未定)后重算图表尺寸，避免图表被画成很窄
        if (window.ResizeObserver) {
            const ro = new ResizeObserver(entries => entries.forEach(e => {
                const inst = echarts.getInstanceByDom(e.target);
                if (inst) inst.resize();
            }));
            ['gauge-rps', 'gauge-value', 'gauge-risk', 'rs-line-chart', 'heatmap-chart'].forEach(id => {
                const el = document.getElementById(id);
                if (el) ro.observe(el);
            });
        }
    }

    // === V4.0 Regime Banner + V5.0 Data Freshness Badge (Fix5) ===
    let _lastFreshness = null;  // Fix5: 缓存 freshness 数据供 banner 使用
    let _lastRegime = null;     // 横幅与策略卡共用 (门槛分)
    let _lastLocked = false;    // 后端 decision_locked

    async function loadRegimeBanner() {
        try {
            const res = await fetch('/api/v1/market/regime');
            const result = await res.json();
            if (result.status === 'ok') {
                const r = result;
                const banner = document.getElementById('regime-banner');
                if (!banner) return;
                _lastRegime = r;
                const locked = _lastLocked || r.decision_locked === true;
                banner.classList.remove('is-bull', 'is-range', 'is-bear', 'is-crash');
                banner.classList.add(`is-${String(r.regime || '').toLowerCase()}`);

                // Fix5: 数据新鲜度
                let freshText = '';
                if (_lastFreshness && _lastFreshness.last_calc) {
                    const calcTime = new Date(_lastFreshness.last_calc);
                    const ageMin = Math.round((Date.now() - calcTime.getTime()) / 60000);
                    const isStale = ageMin > 30;
                    const ageText = ageMin < 1 ? '刚刚' : (ageMin < 60 ? `${ageMin}分钟前` : `${Math.round(ageMin/60)}小时前`);
                    freshText = `<span class="rb-fresh ${isStale ? 'is-stale' : ''}">数据 ${ageText}</span>`;
                }
                const ret5 = r.ret5d !== undefined && r.ret5d !== null ? Number(r.ret5d) : null;

                banner.innerHTML = `
                    <span class="rb-regime"><i class="rb-dot"></i>${r.regime_cn || r.regime}</span>
                    <span class="rb-kv"><span class="k">沪深300</span><span class="v num">${r.csi300}</span></span>
                    <span class="rb-kv"><span class="k">MA120</span><span class="v num">${r.ma120}</span></span>
                    <span class="rb-kv"><span class="k">5日</span><span class="v num" style="color:${ret5 === null ? C.flat : trendColor(ret5)}">${ret5 === null ? '--' : signed(ret5, 2)}</span></span>
                    <span class="rb-kv"><span class="k">组合上限</span><span class="v num">${r.pos_cap}%</span></span>
                    ${['BEAR', 'RANGE', 'CRASH'].includes(String(r.regime || '').toUpperCase())
                        ? '<span class="rb-lock">本环境不做行业轮动新开仓</span>'
                        : (locked ? '<span class="rb-lock">执行锁定 · 待验证</span>' : '')}
                    ${freshText}
                `;
                if (currentCode) renderStrategyCard(currentCode);
            }
        } catch(e) { console.log('Regime banner skipped:', e); }
    }

    // === V3.0 指标百科 ===
    function renderGlossary() {
        const grid = document.getElementById('glossary-grid');
        grid.innerHTML = GLOSSARY.map(g => `
            <div class="glossary-item">
                <div class="glossary-item-header">
                    <span class="glossary-item-name">${g.name}</span>
                    <span class="glossary-item-range">${g.range}</span>
                </div>
                <div class="glossary-item-desc">${g.desc}</div>
                <div class="glossary-item-warn">警示 · ${g.warn}</div>
            </div>
        `).join('');
    }

    function initGlossaryToggle() {
        const toggle = document.getElementById('glossary-toggle');
        const drawer = document.getElementById('glossary-drawer');
        const drawerOverlay = document.getElementById('glossary-overlay');
        const closeBtn = document.getElementById('glossary-close');

        if (!localStorage.getItem('alphacore_glossary_seen')) {
            toggle.classList.add('pulse-hint');
            setTimeout(() => {
                toggle.classList.remove('pulse-hint');
                localStorage.setItem('alphacore_glossary_seen', '1');
            }, 6000);
        }

        function openDrawer() { drawer.classList.add('open'); drawerOverlay.classList.add('open'); }
        function closeDrawer() { drawer.classList.remove('open'); drawerOverlay.classList.remove('open'); }

        toggle.addEventListener('click', openDrawer);
        closeBtn.addEventListener('click', closeDrawer);
        drawerOverlay.addEventListener('click', closeDrawer);
        document.addEventListener('keydown', e => { if (e.key === 'Escape') closeDrawer(); });
    }

    // === V4.0 导航条渲染 + 自动滚动聚焦 ===
    function renderSectorNav(rankData = []) {
        if (rankData.length > 0) {
            rankData.sort((a, b) => (b.alpha_score || 0) - (a.alpha_score || 0));
            if (!currentCode) currentCode = rankData[0]?.ts_code || rankData[0]?.code || SECTORS[0].code;
        }

        const orderedSectors = rankData.length > 0
            ? rankData.map(d => ({ code: d.ts_code || d.code, name: d.name }))
            : SECTORS;

        navContainer.innerHTML = orderedSectors.map((s, idx) => {
            const d = rankData.find(r => (r.ts_code === s.code || r.code === s.code)) || {};
            const trend = d.trend_5d || 0;
            const alpha = d.alpha_score || 0;
            const grade = d.alpha_grade || 'C';
            const heat = d.heat_score || 0;
            const gc = gradeColor(grade);
            const tc = trendColor(trend);
            const rankClass = idx < 3 ? `rank-top rank-${idx+1}` : '';
            const rankLabel = `${idx+1}`;

            return `
                <div class="sector-tile ${s.code === currentCode ? 'active' : ''}" data-code="${s.code}" style="--tile-heat-color: ${gc};">
                    <span class="tile-rank ${rankClass}">${rankLabel}</span>
                    <div class="tile-alpha">
                        <span class="tile-alpha-score">${alpha.toFixed(0)}</span>
                        <span class="tile-grade grade-${grade}">${grade}</span>
                    </div>
                    <span class="tile-name">${s.name}</span>
                    <div class="tile-bottom">
                        <span class="tile-trend num" style="color:${tc};">${signed(trend)}</span>
                        <span class="tile-heat-label num" title="热度">热 ${heat.toFixed(0)}</span>
                    </div>
                    <div class="tile-heat-bar"><div class="tile-heat-fill" style="width:${Math.min(100, alpha)}%; background:${gc};"></div></div>
                </div>
            `;
        }).join('');

        document.querySelectorAll('.sector-tile').forEach(tile => {
            tile.addEventListener('click', () => {
                const code = tile.getAttribute('data-code');
                if (code === currentCode) return;
                document.querySelectorAll('.sector-tile').forEach(t => t.classList.remove('active'));
                tile.classList.add('active');
                currentCode = code;
                updateActiveCard();
                renderStrategyCard(code);
                loadIndustryDetail(code);
            });
        });
    }

    // V4.0: 自动滚动到选中tile
    function scrollToActiveTile() {
        const activeTile = document.querySelector('.sector-tile.active');
        if (activeTile) {
            activeTile.scrollIntoView({ behavior: 'smooth', block: 'nearest', inline: 'center' });
        }
    }

    // === V4.0 Alpha Score 排行榜 (带stagger动画) ===
    function renderAlphaRanking(data) {
        const container = document.getElementById('alpha-ranking-list');
        const strongCount = data.filter(d => d.alpha_grade === 'A' || d.alpha_grade === 'B').length;
        document.getElementById('alpha-a-count').textContent = `A/B 级 ${strongCount} 个`;

        container.innerHTML = data.map((d, idx) => {
            const gc = gradeColor(d.alpha_grade || 'C');
            const tc5 = trendColor(d.trend_5d);
            const tc20 = trendColor(d.ret_20d || 0);
            const code = d.ts_code || d.code;
            const isActive = code === currentCode;

            // 风险警示标签
            const alertsHtml = (d.risk_alerts || []).map(a =>
                `<span class="risk-tag ${a.level}">${a.text}</span>`
            ).join('');

            // V4.0: Mini factor bars (紧凑模式可见)
            const fBars = [
                { label: '热', val: d.f_heat || 0, color: C.accent },
                { label: '动', val: d.f_momentum || 0, color: C.accent },
                { label: '位', val: d.f_valuation || 0, color: C.accent },
                { label: '趋', val: d.f_trend || 0, color: C.accent }
            ];
            const miniBarsHtml = `<div class="mini-factor-bars">
                ${fBars.map(f => `<div class="mini-bar-item">
                    <span class="mini-bar-label">${f.label}</span>
                    <div class="mini-bar-track"><div class="mini-bar-fill" style="width:${Math.min(100,f.val)}%;background:${f.color};opacity:${f.val>=60?1:0.45}"></div></div>
                    <span class="mini-bar-val num" style="color:${f.val>=60?C.text:C.text3}">${f.val.toFixed(0)}</span>
                </div>`).join('')}
            </div>`;

            return `
                <div class="alpha-card grade-${d.alpha_grade || 'C'} ${isActive ? 'active-card' : ''}" data-code="${code}" style="animation-delay:${idx * 60}ms">
                    <div class="alpha-card-top">
                        <div class="alpha-card-info">
                            <span class="alpha-card-rank">#${idx+1}</span>
                            <span class="alpha-card-name">${d.name}</span>
                            <div class="alpha-card-trends">
                                <span class="num" style="color:${tc5};"><small>5D</small>${signed(d.trend_5d)}</span>
                                <span class="num" style="color:${tc20};"><small>20D</small>${signed(d.ret_20d || 0)}</span>
                            </div>
                        </div>
                        <div class="alpha-score-box" style="--grade-color:${gc}">
                            <span class="alpha-score-num num">${(d.alpha_score||0).toFixed(0)}</span>
                            <span class="alpha-score-grade">${d.alpha_grade||'C'}</span>
                        </div>
                    </div>

                    ${miniBarsHtml}

                    <div class="alpha-strategy">
                        <div class="alpha-strat-row">
                            <span class="alpha-strat-text"><b>买入:</b> ${d.buy_strategy || '—'}</span>
                        </div>
                        <div class="alpha-strat-row">
                            <span class="alpha-strat-text"><b>止盈:</b> ${d.take_profit || '—'}</span>
                        </div>
                    </div>

                    ${alertsHtml ? `<div class="risk-tags">${alertsHtml}</div>` : ''}

                    <div class="alpha-advice-row" style="display:flex; justify-content:space-between; align-items:center;">
                        <span class="alpha-advice-text">${d.advice || ''}</span>
                        <span class="alpha-advice-label ${d.advice_action || 'neutral'}">${String(d.advice_label || '').replace(/^[^\p{L}\p{N}]+/u, '')}</span>
                    </div>
                </div>
            `;
        }).join('');

        // 卡片点击事件
        document.querySelectorAll('.alpha-card').forEach(card => {
            card.addEventListener('click', () => {
                const code = card.getAttribute('data-code');
                if (code === currentCode) return;
                currentCode = code;
                document.querySelectorAll('.sector-tile').forEach(t => {
                    t.classList.toggle('active', t.getAttribute('data-code') === code);
                });
                updateActiveCard();
                renderStrategyCard(code);
                loadIndustryDetail(code);
                scrollToActiveTile();
            });
        });
    }

    function updateActiveCard() {
        document.querySelectorAll('.alpha-card').forEach(c => {
            c.classList.toggle('active-card', c.getAttribute('data-code') === currentCode);
        });
    }

    // === V3.1 因子进度条可视化 ===
    function renderFactorBars(d) {
        const factors = [
            { label: '热度', value: d.f_heat || 0, color: C.accent, weight: '30%' },
            { label: '动量', value: d.f_momentum || 0, color: C.accent, weight: '25%' },
            { label: '价格位置', value: d.f_valuation || 0, color: C.accent, weight: '25%' },
            { label: '趋势', value: d.f_trend || 0, color: C.accent, weight: '20%' }
        ];
        return factors.map(f => {
            const v = Math.min(100, Math.max(0, f.value));
            const opacity = v >= 60 ? 1 : 0.5;
            return `<div class="factor-bar-wrap">
                <span class="factor-bar-label">${f.label} <small>${f.weight}</small></span>
                <div class="factor-bar-track">
                    <div class="factor-bar-fill" style="width:${v}%; background:${f.color}; opacity:${opacity};"></div>
                </div>
                <span class="factor-bar-value num" style="color:${v>=60?C.text:C.text3}">${v.toFixed(0)}</span>
            </div>`;
        }).join('');
    }

    // === V3.1 策略操作卡 ===
    function renderStrategyCard(code) {
        const d = allSectorData.find(s => (s.ts_code === code || s.code === code));
        if (!d) return;

        const gc = gradeColor(d.alpha_grade || 'C');
        const badge = document.getElementById('soc-grade-badge');
        badge.textContent = `${d.alpha_grade || 'C'} · ${(d.alpha_score||0).toFixed(0)}分`;
        badge.className = `soc-grade-badge grade-${d.alpha_grade || 'C'}`;
        document.getElementById('soc-sector-name').textContent = `${d.name} · 投资策略`;
        document.getElementById('strategy-ops-card').style.setProperty('--grade-color', gc);

        const alerts = (d.risk_alerts || []).map(a =>
            `<li class="risk-${a.level}">${a.text}</li>`
        ).join('') || '<li class="risk-none">暂无风险警示</li>';
        const gate = _lastRegime && _lastRegime.score_gate != null ? Number(_lastRegime.score_gate) : null;
        const score = Number(d.alpha_score || 0);
        const triggerText = gate !== null
            ? `研究分 ≥ ${gate.toFixed(0)}（当前 <span class="num">${score.toFixed(1)}</span>）+ 趋势与风险闸门全部通过`
            : '研究分达到当前市场环境门槛 + 趋势与风险闸门全部通过';

        document.getElementById('soc-body').innerHTML = `
            <div class="soc-fade-in">
            <div class="soc-section">
                <div class="soc-section-title buy">买入策略</div>
                <ul class="soc-content">
                    <li><b>触发条件</b><span>${triggerText}</span></li>
                    <li><b>建仓方法</b><span>${d.buy_strategy || '—'}</span></li>
                    <li><b>仓位上限</b><span class="num">${d.position_cap || '—'}</span></li>
                </ul>
            </div>
            <div class="soc-divider"></div>
            <div class="soc-section">
                <div class="soc-section-title profit">止盈策略</div>
                <ul class="soc-content">
                    <li>${d.take_profit || '—'}</li>
                </ul>
            </div>
            <div class="soc-divider"></div>
            <div class="soc-section">
                <div class="soc-section-title stop">止损策略</div>
                <ul class="soc-content">
                    <li>${d.stop_loss || '—'}</li>
                </ul>
            </div>
            <div class="soc-divider"></div>
            <div class="soc-section">
                <div class="soc-section-title risk">风险警示</div>
                <ul class="soc-content">${alerts}</ul>
            </div>
            <div class="soc-factors">
                <div class="soc-factors-title">Alpha Score 因子拆解</div>
                ${renderFactorBars(d)}
            </div>
            </div>
        `;
    }

    // === V5.0 热力矩阵 (5维: +趋势强度) — Fix4 ===
    function renderHeatmapChart(data) {
        if (!data || data.length === 0) return;
        // V6.0: 热力矩阵使用短名，避免16+标签在X轴挤压重叠
        const names = data.map(d => {
            const n = String(d.name || '').replace(/[（(].*$/, '');  // 去掉括号说明，如 "创业板(宽基)" -> "创业板"
            if (n.includes('/')) return n.split('/')[0];
            return n.length > 4 ? n.substring(0, 4) : n;
        });
        const fullNames = data.map(d => d.name);  // tooltip 用全名
        const dims = ['研究分', '热度', '动量', '价格位置', '趋势强度'];
        const gradeLabels = { 0: '极弱', 20: '弱', 40: '偏弱', 50: '中性', 60: '偏强', 75: '强', 90: '极强' };
        const heatData = [];

        function getGradeLabel(val) {
            const thresholds = [90, 75, 60, 50, 40, 20, 0];
            for (const t of thresholds) { if (val >= t) return gradeLabels[t]; }
            return '极弱';
        }

        data.forEach((d, xi) => {
            // 用 ?? 而不是 ||：0 是有效分值，不能被当成"缺失"显示成 50
            const scores = [
                d.alpha_score,
                d.heat_score,
                d.f_momentum,
                d.f_valuation,
                d.f_trend
            ];
            scores.forEach((val, yi) => {
                const n = Number(val);
                heatData.push([xi, yi, (val === null || val === undefined || !Number.isFinite(n)) ? '-' : Math.round(n)]);
            });
        });

        charts.heatmap.setOption({
            tooltip: {
                // 跟随鼠标、限制在图表区域内：顶行单元格不再被容器裁掉
                confine: true,
                position: (point, params, dom, rect, size) => {
                    const [x, y] = point;
                    const [w, h] = size.contentSize;
                    const [vw, vh] = size.viewSize;
                    let left = x + 14, top = y + 14;
                    if (left + w > vw) left = x - w - 14;
                    if (top + h > vh) top = y - h - 14;
                    return [Math.max(0, left), Math.max(0, top)];
                },
                backgroundColor: '#151922',
                borderColor: 'rgba(255,255,255,0.1)',
                textStyle: { color: '#fff', fontSize: 12 },
                formatter: p => {
                    const val = p.data[2];
                    if (val === '-') return `<b>${fullNames[p.data[0]]}</b><br/>${dims[p.data[1]]}: <b>—</b> <span style="opacity:0.6">(无数据)</span>`;
                    const grade = getGradeLabel(val);
                    return `<b>${fullNames[p.data[0]]}</b><br/>${dims[p.data[1]]}: <b>${val}</b> <span style="opacity:0.6">(${grade})</span>`;
                }
            },
            grid: { top: 10, bottom: 70, left: 80, right: 20 },
            xAxis: {
                type: 'category',
                data: names,
                axisLabel: { color: '#a3a9b5', fontSize: 10, rotate: 45, interval: 0 },
                splitArea: { show: false }
            },
            yAxis: {
                type: 'category',
                data: dims,
                axisLabel: { color: '#a3a9b5', fontSize: 11 },
                splitArea: { show: false }
            },
            visualMap: {
                min: 0, max: 100,
                calculable: false,
                orient: 'horizontal',
                left: 'center',
                bottom: 0,
                itemWidth: 14, itemHeight: 100,
                textStyle: { color: '#6b7280', fontSize: 10 },
                inRange: {
                    color: ['#12161e', '#18233a', '#213660', '#2d4f8c', '#4a72c4', '#8fb0ff']
                }
            },
            series: [{
                type: 'heatmap',
                data: heatData,
                label: {
                    show: true,
                    color: '#fff',
                    fontSize: 11,
                    fontWeight: 700,
                    fontFamily: 'Inter'
                },
                emphasis: {
                    itemStyle: { borderColor: '#e6e8ec', borderWidth: 1 }
                },
                itemStyle: { borderColor: '#0b0d12', borderWidth: 2, borderRadius: 2 }
            }]
        });
        // V6.0: 延迟触发 resize 确保 16 只 ETF 尺寸计算准确
        setTimeout(() => charts.heatmap.resize(), 200);
    }

    // === ECharts 仪表盘配置 (AIAE 温度计风格) ===
    function getGaugeOption(name, value, color, unit = '') {
        // 各指标专属色段与量程
        const gaugeProfiles = {
            RPS: {
                max: 100,
                colors: [
                    [0.30, '#d9a441'],  // 0-30: 极弱
                    [0.80, '#2a303b'],  // 30-80: 中性
                    [1.00, '#7c9cff']   // 80-100: 强势
                ],
                splitNumber: 5,
                labels: {0:'0',20:'20',40:'40',60:'60',80:'80',100:'100'}
            },
            Value: {
                max: 100,
                colors: [
                    [0.30, '#7c9cff'],  // 0-30: 历史低位
                    [0.70, '#2a303b'],  // 30-70: 中部区间
                    [1.00, '#d9a441']   // 70-100: 历史高位
                ],
                splitNumber: 5,
                labels: {0:'0',20:'20',40:'40',60:'60',80:'80',100:'100'}
            },
            Risk: {
                max: 3,
                colors: [
                    [0.50, '#2a303b'],  // 0-1.5: 正常
                    [0.67, '#8a6d33'],  // 1.5-2.0: 偏热
                    [1.00, '#d9a441']   // 2.0-3.0: 拥挤
                ],
                splitNumber: 6,
                labels: {0:'0',0.5:'0.5',1:'1',1.5:'1.5',2:'2',2.5:'2.5',3:'3'}
            }
        };

        const profile = gaugeProfiles[name] || gaugeProfiles.RPS;
        const clampedValue = Math.min(Math.max(value, 0), profile.max);

        return {
            series: [{
                type: 'gauge',
                startAngle: 200,
                endAngle: -20,
                min: 0,
                max: profile.max,
                radius: '92%',
                center: ['50%', '68%'],
                pointer: {
                    show: true,
                    length: '55%',
                    width: 3,
                    itemStyle: { color: color },
                    icon: 'triangle'
                },
                anchor: {
                    show: true,
                    size: 7,
                    itemStyle: {
                        color: '#0b0d12',
                        borderColor: color,
                        borderWidth: 2
                    }
                },
                axisLine: {
                    lineStyle: {
                        width: 6,
                        color: profile.colors
                    }
                },
                axisTick: {
                    length: 5,
                    distance: -12,
                    lineStyle: { color: 'auto', width: 1 }
                },
                splitLine: {
                    length: 9,
                    distance: -12,
                    lineStyle: { color: 'auto', width: 1.5 }
                },
                splitNumber: profile.splitNumber,
                axisLabel: {
                    distance: -28,
                    color: '#64748b',
                    fontSize: 8,
                    fontFamily: 'Inter',
                    // Fix2: 容差匹配，解决浮点精度导致轴标签消失的问题
                    formatter: function(val) {
                        const keys = Object.keys(profile.labels).map(Number);
                        for (let i = 0; i < keys.length; i++) {
                            if (Math.abs(val - keys[i]) < 0.01) return profile.labels[keys[i]];
                        }
                        return '';
                    }
                },
                detail: {
                    valueAnimation: true,
                    offsetCenter: [0, '30%'],
                    fontSize: 22,
                    fontWeight: '600',
                    color: '#e6e8ec',
                    fontFamily: 'Inter',
                    formatter: `{value}${unit}`
                },
                data: [{ value: clampedValue }],
                animationDuration: 1000,
                animationEasingUpdate: 'cubicOut'
            }]
        };
    }

    // === V5.0 加载行业详情 (Fix6: skeleton loading + 适配新数据结构) ===
    function showDetailSkeleton() {
        // Fix6: 在 fetch 前显示骨架屏，避免旧数据→新数据的跳变
        document.querySelectorAll('.metric-row .metric-card').forEach(card => {
            card.classList.add('skeleton-loading');
        });
        const rsChart = document.getElementById('rs-line-chart');
        if (rsChart) rsChart.style.opacity = '0.3';
        const listEl = document.getElementById('list-constituents');
        if (listEl) listEl.style.opacity = '0.3';
    }
    function hideDetailSkeleton() {
        document.querySelectorAll('.metric-row .metric-card').forEach(card => {
            card.classList.remove('skeleton-loading');
        });
        const rsChart = document.getElementById('rs-line-chart');
        if (rsChart) rsChart.style.opacity = '1';
        const listEl = document.getElementById('list-constituents');
        if (listEl) listEl.style.opacity = '1';
    }

    async function loadIndustryDetail(code) {
        showDetailSkeleton();  // Fix6: 进入 loading 态
        try {
            const res = await fetch(`/api/v1/industry-detail?code=${code}`);
            const result = await res.json();
            if (result.status === 'success') {
                const data = result.data;
                const m = data.metrics;

                charts.rps.setOption(getGaugeOption('RPS', m.rps, m.rps > 80 ? C.accent : (m.rps < 30 ? C.warn : C.text2)));
                charts.value.setOption(getGaugeOption('Value', m.pe_percentile, m.pe_percentile > 70 ? C.warn : (m.pe_percentile < 30 ? C.accent : C.text2), '%'));
                charts.risk.setOption(getGaugeOption('Risk', m.crowding, m.crowding > 1.5 ? C.warn : C.text2, 'x'));

                // V4.0: 20D动量趋势卡 (替代北向资金)
                const mom20d = m.momentum_20d || {};
                const momEl = document.getElementById('val-mom20d');
                const momDescEl = document.getElementById('desc-mom20d');
                if (momEl) {
                    const momColor = momTrendColor(mom20d.trend);
                    momEl.textContent = mom20d.ret_20d !== undefined ? signed(mom20d.ret_20d) : '--';
                    momEl.style.color = momColor;
                }
                if (momDescEl) {
                    momDescEl.textContent = mom20d.label || '—';
                }

                document.getElementById('desc-rps').innerHTML = `<span style="color:${m.rps > 80 ? C.accent : (m.rps < 30 ? C.warn : C.text2)}">${m.rps > 80 ? "强势领涨" : (m.rps < 30 ? "极度弱势" : "震荡蓄势")}</span>`;
                document.getElementById('desc-value').innerHTML = `<span style="color:${m.pe_percentile < 30 ? C.accent : (m.pe_percentile > 70 ? C.warn : C.text2)}">${m.pe_percentile < 30 ? "历史低位" : (m.pe_percentile > 70 ? "历史高位" : "中部区间")}</span>`;
                document.getElementById('desc-risk').innerHTML = `<span style="color:${m.crowding > 1.5 ? C.warn : C.text2}">${m.crowding > 1.5 ? "交易拥挤" : "拥挤度正常"}</span>`;

                // V3.1: 仪表盘动态风险边框
                const metricCards = document.querySelectorAll('.metric-row .metric-card');
                if (metricCards[0]) {
                    metricCards[0].classList.remove('metric-danger','metric-safe','metric-warn');
                    if (m.rps > 80) metricCards[0].classList.add('metric-safe');
                    else if (m.rps < 30) metricCards[0].classList.add('metric-danger');
                }
                if (metricCards[1]) {
                    metricCards[1].classList.remove('metric-danger','metric-safe','metric-warn');
                    if (m.pe_percentile > 70) metricCards[1].classList.add('metric-danger');
                    else if (m.pe_percentile < 30) metricCards[1].classList.add('metric-safe');
                    else metricCards[1].classList.add('metric-warn');
                }
                if (metricCards[2]) {
                    metricCards[2].classList.remove('metric-danger','metric-safe','metric-warn');
                    if (m.crowding > 1.5) metricCards[2].classList.add('metric-danger');
                    else if (m.crowding > 1.2) metricCards[2].classList.add('metric-warn');
                    else metricCards[2].classList.add('metric-safe');
                }

                // RS Line Chart
                if (data.chart_data && data.chart_data.dates.length > 0) {
                    charts.rsLine.setOption({
                        tooltip: { trigger: 'axis', backgroundColor: '#151922', borderColor: 'rgba(255,255,255,0.1)', textStyle: { color: '#e6e8ec', fontSize: 12 } },
                        grid: { top: 30, bottom: 28, left: 48, right: 44 },
                        xAxis: { type: 'category', data: data.chart_data.dates.map(d => String(d).substring(4)), axisLabel: { color: '#6b7280', fontSize: 10 }, axisLine: { lineStyle: { color: 'rgba(255,255,255,0.1)' } } },
                        yAxis: [
                            { type: 'value', scale: true, name: '价格', nameTextStyle: { color: '#6b7280', fontSize: 10 }, axisLabel: { color: '#6b7280', fontSize: 10 }, splitLine: { lineStyle: { color: 'rgba(255,255,255,0.05)' } } },
                            { type: 'value', scale: true, name: 'RS', nameTextStyle: { color: '#6b7280', fontSize: 10 }, axisLabel: { color: '#6b7280', fontSize: 10 }, splitLine: { show: false } }
                        ],
                        legend: { data: ['中枢价格', '相对强度(RS)'], textStyle: { color: '#a3a9b5', fontSize: 11 }, right: 0, icon: 'roundRect', itemWidth: 10, itemHeight: 3 },
                        series: [
                            { name: '中枢价格', type: 'line', yAxisIndex: 0, data: data.chart_data.prices, itemStyle: { color: '#e6e8ec' }, lineStyle: { width: 1.5 }, smooth: false, showSymbol: false },
                            { name: '相对强度(RS)', type: 'line', yAxisIndex: 1, data: data.chart_data.relative_strength, itemStyle: { color: '#7c9cff' }, lineStyle: { width: 1.5 }, smooth: false, showSymbol: false }
                        ]
                    });
                }

                // 成分股列表
                const listEl = document.getElementById('list-constituents');
                listEl.innerHTML = m.constituents.map(c => `
                    <div class="constituent-item">
                        <span class="constituent-name">${c.name}${c.code ? `<small>${c.code}</small>` : ''}</span>
                        <span class="constituent-weight num">${c.weight ?? (c.weight_pct != null ? Number(c.weight_pct).toFixed(2) + "%" : "—")}</span>
                    </div>
                `).join('');
            }
        } catch (err) { console.error('Detail load error:', err); }
        finally { hideDetailSkeleton(); }  // Fix6: 无论成功失败都移除骨架屏
    }

    // === 加载轮动矩阵 + Alpha 排行 (Fix5: 抓取 freshness) ===
    async function loadRotationMatrix() {
        try {
            // V5.1 Fix P1#14: 将日期选择器的值传递到 API
            const dateParam = datePicker.value ? `?date=${datePicker.value}` : '';
            const res = await fetch(`/api/v1/industry-tracking${dateParam}`);
            const result = await res.json();
            if (result.status === 'success') {
                allSectorData = result.data.sector_heatmap;
                _lastLocked = result.decision_locked === true || result.data.decision_locked === true;

                // Fix5: 缓存 freshness 供 regime banner 使用
                if (result.data_freshness) {
                    _lastFreshness = result.data_freshness;
                    loadRegimeBanner();  // 刷新 banner 以显示最新 freshness
                }

                // V4.0: 渲染四大组件
                renderSectorNav(allSectorData);
                renderAlphaRanking(allSectorData);
                renderHeatmapChart(allSectorData);

                // 自动选中排名第一并渲染策略卡
                if (allSectorData.length > 0 && currentCode) {
                    renderStrategyCard(currentCode);
                }
            }
        } catch (err) { console.error('Rotation load error:', err); }
    }

    // === 同步数据 ===
    async function syncData() {
        if (!confirm(`确定要同步全量产业数据？\n将触发 ${SECTORS.length} 个核心 ETF 数据深度抓取，约需 15-30 秒。`)) return;

        overlay.style.display = 'flex';
        try {
            const res = await AC.secureFetch('/api/v1/sync/industry', { method: 'POST' });

            const result = await res.json();
            if (result.status === 'success') {
                alert("同步成功！最新数据已就绪。");
            } else {
                alert("同步完成，请刷新查看。");
            }
            await loadRotationMatrix();
            loadIndustryDetail(currentCode);
        } catch (err) {
            console.error("同步异常", err);
            alert("网络或系统错误，同步异常。");
        } finally {
            overlay.style.display = 'none';
        }
    }

    syncBtn.addEventListener('click', syncData);
    initPage();
    // resize 由 AC (alphacore_utils.js) 统一管理
});
