"""
AlphaCore · 全局配置中心
========================
V5.1: 将所有引擎中的分散常量统一管理
      Token 统一从环境变量/.env 读取 (安全加固)
使用方式:
    from config import TUSHARE_TOKEN, CACHE_TTL_INTRADAY
"""

import os
from pathlib import Path

from services.strategy_params import load_runtime_config

# ── 加载 .env 文件 (兼容 dotenv 未安装的环境) ──
try:
    from dotenv import load_dotenv
    _env_path = Path(__file__).resolve().parent / ".env"
    load_dotenv(_env_path)
except ImportError:
    pass  # 无 dotenv 时依赖 Docker env 或系统环境变量

# ── Tushare API (从环境变量读取, 禁止硬编码) ──
TUSHARE_TOKEN = os.environ.get("TUSHARE_TOKEN", "")
if not TUSHARE_TOKEN:
    import logging as _log
    _log.getLogger("alphacore.config").critical(
        "⚠️ TUSHARE_TOKEN 未设置! 数据引擎将不可用。请在 .env 或环境变量中配置。"
    )

# ==========================================
# TUSHARE CONNECTION FIX (Monkey Patch)
# ==========================================
import tushare as ts
import tushare.pro.client
import time

_orig_post = tushare.pro.client.requests.post

def _patched_post(url, **kwargs):
    # Intercept requests to waditu and forward to the reliable tushare.pro root endpoint
    if 'api.waditu.com' in url or 'api.tushare.pro' in url:
        url = 'https://api.tushare.pro'
        # V5.2: 全局限频 — 防止6引擎32+并发线程超限
        try:
            from services.tushare_limiter import tushare_limiter
            tushare_limiter.acquire()
        except Exception:
            pass  # 限频器不可用时降级为无限频
        
        max_retries = 3
        for i in range(max_retries):
            try:
                return _orig_post(url, **kwargs)
            except Exception as e:
                if i == max_retries - 1:
                    raise e
                time.sleep(1.5)
    return _orig_post(url, **kwargs)


tushare.pro.client.requests.post = _patched_post
# ==========================================

# ── FRED API (VIX / 国债收益率 / M1 / 美股宏观) ──
FRED_API_KEY = os.environ.get("FRED_API_KEY", "")

# ── Finnhub API (美股ETF实时报价) ──
FINNHUB_API_KEY = os.environ.get("FINNHUB_API_KEY", "")

# ── 数据缓存 TTL ──
CACHE_TTL_INTRADAY    = 300       # 盘中5分钟（09:30-15:00 工作日）
CACHE_TTL_AFTERHOURS  = 3600      # 盘后1小时
CACHE_TTL_WEEKEND     = 86400     # 周末24小时

# ── Regime / 策略参数兼容导出（权威来源：config/strategy_runtime.json）──
_STRATEGY_RUNTIME = load_runtime_config()
_REGIME_RULES = _STRATEGY_RUNTIME["regime"]
_RUNTIME_STRATEGIES = _STRATEGY_RUNTIME["strategies"]

REGIME_MA_PERIOD   = int(_REGIME_RULES["ma_period"])
REGIME_SLOPE_DAYS  = int(_REGIME_RULES["slope_days"])
REGIME_RET20_BULL  = float(_REGIME_RULES["bull_return_20d_min"])
REGIME_DIP_THRESH  = float(_REGIME_RULES["crash_return_3d"])
REGIME_REBOUND_RET5 = float(_REGIME_RULES["rebound_return_5d_min"])
REGIME_MIN_DATA    = 300     # 最少需要 300 个交易日数据

# ═══════════════════════════════════════════════════════
#  统一仓位常量 (Single Source of Truth · V6.0)
#  所有引擎/前端/审计的仓位参数 统一从此处读取
# ═══════════════════════════════════════════════════════
POSITION_CONFIG = {
    # ── 审计红线 (绝对天花板，防追保) ──
    "total_cap": 95.0,              # 审计红线: 最大允许总仓位 (%)
    "single_limit": 20.0,           # 单票集中度上限 (%)
    "sector_limit": 40.0,           # 行业集中度上限 (%)
    "min_holdings": 5,              # 最少持仓数

    # ── 子策略 Regime 仓位上限 ──
    # 均值回归 (MR): 震荡主战场, 牛市低配防过度交易
    "mr_regime_cap": dict(_RUNTIME_STRATEGIES["mr"]["position_caps"]),
    # 动量轮动 (MOM): 牛市追强, 熊市防守
    "mom_regime_cap": dict(_RUNTIME_STRATEGIES["momentum"]["position_caps"]),
    # 双重动量 (GEM): 第1.5层战术配置, 绝对动量过滤天然防御
    "gem_regime_cap": dict(_RUNTIME_STRATEGIES["gem"]["position_caps"]),
    "dividend_regime_cap": dict(_RUNTIME_STRATEGIES["dividend"]["position_caps"]),

    # ── 回测引擎统一上限 ──
    # 回测不受 AIAE 动态调整, 用固定值保证可重复性
    "backtest_total_cap": 85,
}

# ── 各 Regime 仓位上限（均值回归策略 · 从 POSITION_CONFIG 统一读取）──
MR_POS_CAP = {k: v / 100.0 for k, v in POSITION_CONFIG["mr_regime_cap"].items()}

# ── 信号评分入场门槛（100分制）──
MR_SCORE_GATE = dict(_RUNTIME_STRATEGIES["mr"]["score_gates"])

# ── 止损幅度（负数，浮亏超过该值触发）──
MR_STOP_LOSS = {
    regime: -float(stop)
    for regime, stop in _RUNTIME_STRATEGIES["mr"]["stop_losses"].items()
}

# ── 动量轮动策略参数 ──
MOMENTUM_LOOKBACK   = 20      # N日动量回看期
MOMENTUM_VOL_MIN    = 0.8     # 量比最低要求
MOMENTUM_GROUP_CAP  = 40      # 单行业组仓位上限 (%)
MOMENTUM_MIN_HOLD   = 3       # 最少持仓数量

# ── 前端 API ──
API_BASE_URL = "http://127.0.0.1:8000"

# ── 旧优化器产物路径（仅兼容离线工具；生产读取 strategy_runtime.json）──
MR_PARAMS_FILE = "mr_per_regime_params.json"

# ── 自动重优化周期（天）──
MR_REOPTIMIZE_DAYS = 60

# ═══════════════════════════════════════════════════════
#  审计引擎 (系统可信度) 阈值
# ═══════════════════════════════════════════════════════
# 2026-11-02: 风险阈值 (止损线/单票/行业/总仓位/最少持仓) 已从审计配置删除 ——
# 组合风险的唯一判定是合规引擎 (engines/compliance_engine.py), 止损由跟踪止盈引擎判定。

AUDIT_CONFIG = {
    # 数据新鲜度阈值
    "daily_stale_warn_days": 3,         # 日线过期 ≤N天 = 警告
    "daily_stale_fail_days": 5,         # 日线过期 >N天 = 失败
    "fina_fresh_days": 90,              # 财务数据新鲜期 (季度更新)
    "erp_stale_warn_days": 3,
    "erp_stale_fail_days": 7,

    # 策略参数新鲜期 (V6.1 生产级差异化时效)
    "strategy_fresh_days": 30,          # 通用新鲜期兜底
    "strategy_stale_days": 60,          # 通用过期期兜底
    "strategy_fresh_days_mr": 14,       # 均值回归新鲜期 (高频波动率策略)
    "strategy_stale_days_mr": 30,       # 均值回归过期期
    "strategy_fresh_days_mom": 60,      # 行业动量新鲜期 (中频行业轮动)
    "strategy_stale_days_mom": 90,      # 行业动量过期期
    "strategy_fresh_days_div": 90,      # 红利趋势新鲜期 (季度基本面更新)
    "strategy_stale_days_div": 180,     # 红利趋势过期期
    "strategy_fresh_days_erp": 180,     # ERP宏观择时新鲜期 (低频宏观因子)
    "strategy_stale_days_erp": 360,     # ERP宏观择时过期期
}

# 2026-11-02: 旧审计执行器 (AUDIT_ENFORCER 自动强平/交易阻断, AUDIT_MUTE 静音降级) 已退役;
# 风控拦截只保留在合规引擎的下单环节。

# ── AI 配置加载中心 (生产级安全加固) ──
import json

def get_ai_config() -> dict:
    """
    统一加载 AI 配置文件，并动态使用环境变量覆盖敏感 API 密钥。
    提供集中式配置与双向保底逻辑。
    """
    config_dir = Path(__file__).resolve().parent / "config"
    config_path = config_dir / "ai_config.json"
    
    # 默认保底配置
    default_cfg = {
        "enable_ai_narrative": False,
        "provider": "deepseek",
        "gemini": {
            "api_key": "",
            "model": "gemini-2.0-flash"
        },
        "deepseek": {
            "api_key": "",
            "model": "deepseek-chat",
            "base_url": "https://api.deepseek.com"
        },
        "timeout_seconds": 30,
        "max_tokens": 1024,
        "fallback_on_error": True
    }
    
    if not config_path.exists():
        return default_cfg
        
    try:
        with open(config_path, "r", encoding="utf-8") as f:
            cfg = json.load(f)
    except Exception:
        return default_cfg

    # 动态注入环境变量 (支持 .env 中的密钥)
    ds_key = os.environ.get("DEEPSEEK_API_KEY", "").strip()
    if ds_key and ds_key != "ENV_VAR":
        if "deepseek" not in cfg:
            cfg["deepseek"] = {}
        cfg["deepseek"]["api_key"] = ds_key

    gemini_key = os.environ.get("GEMINI_API_KEY", "").strip()
    if gemini_key and gemini_key != "ENV_VAR":
        if "gemini" not in cfg:
            cfg["gemini"] = {}
        cfg["gemini"]["api_key"] = gemini_key

    return cfg
