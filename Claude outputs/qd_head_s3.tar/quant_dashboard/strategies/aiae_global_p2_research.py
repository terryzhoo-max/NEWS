"""
海外 AIAE P2 · 预登记检验 (只读研究脚本)
=========================================
规则见 docs/AIAE_GLOBAL_PREREGISTRATION.md (登记于 2026-11-01, 运行前写定)。

用法 (项目目录 quant_dashboard/quant_dashboard 下):
    python strategies/aiae_global_p2_research.py
输出: docs/AIAE_GLOBAL_P2_RESULTS.md 与 data_lake/aiae_global_p2_research.json
"""
import json
import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402

from engines import us_aiae_real as R  # noqa: E402

HORIZONS = (1, 3, 5, 10)
NW_LAG_Q = 40
MA_MONTHS = 10
PUB_LAG_MONTHS = 3
BACKTEST_START = "1961-01"


# ───────── R1 ─────────

def newey_west_t(x: np.ndarray, lag: int) -> float:
    """均值的 Newey-West t 值 (Bartlett 核)。"""
    x = np.asarray(x, float)
    n = len(x)
    e = x - x.mean()
    s = e @ e / n
    for k in range(1, min(lag, n - 1) + 1):
        w = 1 - k / (lag + 1)
        s += 2 * w * (e[k:] @ e[:-k]) / n
    se = np.sqrt(max(s, 1e-18) / n)
    return float(x.mean() / se)


def r1(th: pd.DataFrame, shiller: pd.DataFrame) -> dict:
    rows = {}
    for h in HORIZONS:
        fwd = R.forward_real_returns(th.index, shiller["real_tr_price"], h)
        d = pd.DataFrame({"tier": th["tier"], "f": fwd}).dropna()
        rows[h] = {t: {"mean": round(float(g["f"].mean()), 2), "n": int(len(g))}
                   for t, g in d.groupby("tier")}
    # R1-b: 偏低 − 偏高 (10 年), 用"指示变量差"序列做 NW: y_t = f_t·(1[low]/p_low − 1[high]/p_high)
    fwd10 = R.forward_real_returns(th.index, shiller["real_tr_price"], 10)
    d = pd.DataFrame({"tier": th["tier"], "f": fwd10}).dropna()
    lo, hi = d["tier"] == "low", d["tier"] == "high"
    p_lo, p_hi = lo.mean(), hi.mean()
    y = d["f"] * (lo / p_lo - hi / p_hi)
    diff = float(d.loc[lo, "f"].mean() - d.loc[hi, "f"].mean())
    t_nw = newey_west_t(y.to_numpy(), NW_LAG_Q)
    m = rows[10]
    mono = all(k in m for k in ("low", "neutral", "high")) and m["low"]["mean"] > m["neutral"]["mean"] > m["high"]["mean"]
    return {"by_horizon": rows, "diff_low_minus_high_10y": round(diff, 2), "nw_t": round(t_nw, 2),
            "nw_lag_q": NW_LAG_Q, "monotonic_10y": bool(mono),
            "pass": bool(mono and diff > 0 and t_nw >= 2.0)}


# ───────── R2 ─────────

def _metrics(ret: pd.Series, invested: pd.Series) -> dict:
    eq = (1 + ret).cumprod()
    years = len(ret) / 12
    cagr = eq.iloc[-1] ** (1 / years) - 1
    dd = float((eq / eq.cummax() - 1).min())
    switches = int((invested.astype(int).diff().abs() > 0).sum())
    return {"cagr_pct": round(cagr * 100, 2), "max_dd_pct": round(dd * 100, 1),
            "calmar": round(cagr / abs(dd), 3) if dd < 0 else None,
            "switches_per_year": round(switches / years, 2),
            "out_share_pct": round((1 - invested.mean()) * 100, 1)}


def r2(th: pd.DataFrame, shiller: pd.DataFrame) -> dict:
    sh = shiller.dropna(subset=["price", "real_tr_price"]).copy()
    r = sh["real_tr_price"].pct_change()
    below = sh["price"] < sh["price"].rolling(MA_MONTHS).mean()
    # 当月可得的最近实测季度档位: 季末 ≤ 当月 − 3 个月
    tier_q = th["tier"].dropna()
    avail_idx = (tier_q.index.to_period("M") + PUB_LAG_MONTHS).to_timestamp(how="end").normalize()
    tier_avail = pd.Series(tier_q.to_numpy(), index=avail_idx).reindex(sh.index, method="ffill")
    high = tier_avail == "high"
    # t 月末信号 → t+1 月是否持有
    hold_a = pd.Series(True, index=sh.index)
    hold_b = ~below
    hold_c = ~(below & high)
    start = pd.Period(BACKTEST_START, freq="M").to_timestamp(how="end").normalize()
    out = {}
    for name, hold in (("A_buy_hold", hold_a), ("B_trend_only", hold_b), ("C_aiae_and_trend", hold_c)):
        inv = hold.astype(bool).shift(1, fill_value=True)
        ret = (r.where(inv, 0.0)).loc[start:].dropna()
        out[name] = _metrics(ret, inv.loc[ret.index])
    out["period"] = f"{start:%Y-%m}~{sh.index[-1]:%Y-%m}"
    out["pass"] = bool(out["C_aiae_and_trend"]["calmar"] is not None and out["B_trend_only"]["calmar"] is not None
                       and out["C_aiae_and_trend"]["calmar"] >= out["B_trend_only"]["calmar"])
    return out


def main():
    z1 = R.load_z1()
    hist = R.aiae_history(z1)
    th = R.tier_history(hist)
    shiller = R.load_shiller()
    res = {"tier_params": R.TIER_PARAMS, "z1_last": f"{hist.index[-1].year}Q{hist.index[-1].quarter}",
           "r1": r1(th, shiller), "r2": r2(th, shiller)}
    t = th["tier"].dropna()
    res["tier_switches_per_year"] = round(int((t != t.shift()).sum() - 1) / (len(t) / 4), 2)
    res["tier_share_pct"] = {k: round(v * 100, 1) for k, v in t.value_counts(normalize=True).items()}
    res["latest"] = {"quarter": res["z1_last"], "aiae": round(float(th["aiae"].iloc[-1]), 2),
                     "pct": round(float(th["pct"].iloc[-1]), 1), "tier": th["tier"].iloc[-1]}

    os.makedirs(os.path.join(ROOT, "data_lake"), exist_ok=True)
    with open(os.path.join(ROOT, "data_lake", "aiae_global_p2_research.json"), "w", encoding="utf-8") as f:
        json.dump(res, f, ensure_ascii=False, indent=2, default=str)
    print(json.dumps(res, ensure_ascii=False, indent=2, default=str))
    return res


if __name__ == "__main__":
    main()
