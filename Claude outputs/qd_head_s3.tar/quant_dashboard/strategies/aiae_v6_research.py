# -*- coding: utf-8 -*-
"""
AIAE v6 研究 (P2-2) — 按 docs/AIAE_V6_PREREGISTRATION.md 执行, 不调参
=====================================================================
运行 (项目根目录):
    python strategies/aiae_v6_research.py
输出:
    docs/AIAE_V6_RESEARCH_RESULTS.md     报告 (含判定结论)
    data_lake/aiae_v6_research.json      全部数值 (月度仓位与净值)

只读: 不改任何参数、不写数据库、不影响线上服务。
"""
from __future__ import annotations

import json
import math
import os
import sys
from datetime import datetime
from typing import Optional

import numpy as np
import pandas as pd

_HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(_HERE)
for _p in (ROOT, os.path.join(ROOT, "engines")):
    if _p not in sys.path:
        sys.path.insert(0, _p)

import aiae_params as AP  # noqa: E402  (只读参数, 无副作用)

SIGNAL_FILE = os.path.join(ROOT, "data_lake", "aiae_true_history.parquet")
PRICE_FILE = os.path.join(ROOT, "data_lake", "daily_prices", "000300.SH.parquet")
OUT_JSON = os.path.join(ROOT, "data_lake", "aiae_v6_research.json")
OUT_MD = os.path.join(ROOT, "docs", "AIAE_V6_RESEARCH_RESULTS.md")

# ── 预登记的固定设定 (docs/AIAE_V6_PREREGISTRATION.md §2–§5) ──
MIN_HISTORY = 36
PCTS = (10, 30, 70, 90)
HYST = 0.5
V5_BUFFER = 0.8
COST = 5.4e-4
V6B_AIAE_MAX = 0.80
ERP_V4_TH = (2.5, 3.5, 4.5, 5.5, 6.5)
ERP_V4_POS = (0.10, 0.25, 0.45, 0.65, 0.80, 0.90)
BOOT_N, BOOT_BLOCK, BOOT_SEED = 2000, 12, 7
RULE_SHARPE_TOL, RULE_MDD_TOL_PP, RULE_TURNOVER_X = 0.05, 2.0, 1.2


# ══════════════════════════════════════════════════════════════
#  数据
# ══════════════════════════════════════════════════════════════

def load_signals(path: str = SIGNAL_FILE) -> pd.DataFrame:
    df = pd.read_parquet(path)
    df["month"] = pd.PeriodIndex(df["month"].astype(str), freq="M")
    df = df.set_index("month").sort_index()
    keep = ["aiae_simple", "erp"] + [c for c in ("erp_degraded", "data_quality") if c in df.columns]
    return df[keep].astype({"aiae_simple": float, "erp": float})


def load_monthly_returns(path: str = PRICE_FILE) -> pd.Series:
    df = pd.read_parquet(path)
    d = pd.to_datetime(df["trade_date"].astype(str), errors="coerce")
    px = pd.Series(pd.to_numeric(df["close"], errors="coerce").values, index=d).dropna().sort_index()
    px = px[~px.index.duplicated(keep="last")]
    m = px.groupby(px.index.to_period("M")).last()
    return m.pct_change().dropna()


# ══════════════════════════════════════════════════════════════
#  规则 (与线上引擎同一机制; tests 校验 V5 与 AIAEEngine 逐点一致)
# ══════════════════════════════════════════════════════════════

def classify(value: float, prev: Optional[int], th, hyst: float = HYST) -> int:
    if prev is None:
        return next((i + 1 for i, t in enumerate(th) if value < t), len(th) + 1)
    eff = []
    for i, t in enumerate(th):
        lo, hi = i + 1, i + 2
        eff.append(t + hyst if prev <= lo else (t - hyst if prev >= hi else t))
    return next((i + 1 for i, t in enumerate(eff) if value < t), len(th) + 1)


def erp_level(erp: float) -> str:
    return "erp_gt6" if erp >= 6 else "erp_4_6" if erp >= 4 else "erp_2_4" if erp >= 2 else "erp_lt2"


def smooth(lo_pos, hi_pos, v, t, buf):
    a, b = t - buf, t + buf
    if v <= a:
        return hi_pos
    if v >= b:
        return lo_pos
    return round(hi_pos + (lo_pos - hi_pos) * (v - a) / (b - a))


def matrix_position(regime: int, erp: float, v: float, th, buf: float, matrix=None) -> float:
    row = (matrix or AP.V5_POSITION_MATRIX).get(erp_level(erp))
    pos = row[min(regime - 1, 4)]
    for i, t in enumerate(th):
        if abs(v - t) <= buf:
            pos = smooth(row[i + 1], row[i], v, t, buf)
            break
    return pos / 100.0


def erp_v4_tier(erp: float) -> float:
    k = int(np.searchsorted(np.asarray(ERP_V4_TH), erp, side="right"))
    return ERP_V4_POS[min(k, len(ERP_V4_POS) - 1)]


def expanding_thresholds(x: pd.Series, t: int):
    hist = x.iloc[:t].dropna().values                      # 截至上月, 不含当月
    if len(hist) < MIN_HISTORY:
        return None
    return [float(np.percentile(hist, p)) for p in PCTS]


def expanding_rank(x: pd.Series, t: int) -> Optional[float]:
    hist = x.iloc[:t].dropna().values
    if len(hist) < MIN_HISTORY or pd.isna(x.iloc[t]):
        return None
    return float((hist < x.iloc[t]).mean())


def build_positions(sig: pd.DataFrame) -> pd.DataFrame:
    """每个月末的目标仓位 (0–1); 扩展分位不足 MIN_HISTORY 的月份为 NaN。"""
    a, e = sig["aiae_simple"], sig["erp"]
    v5_th = list(AP.V5_REGIME_THRESHOLDS)
    out = {k: [] for k in ("V5", "V6-A", "V6-B", "ERP-only", "AIAE-only", "固定65%", "满仓")}
    reg_v5 = reg_6a = None
    for t in range(len(sig)):
        v, er = float(a.iloc[t]), float(e.iloc[t])
        reg_v5 = classify(v, reg_v5, v5_th)
        out["V5"].append(matrix_position(reg_v5, er, v, v5_th, V5_BUFFER))
        th = expanding_thresholds(a, t)
        if th is None:
            out["V6-A"].append(np.nan)
        else:
            gap = min(th[i + 1] - th[i] for i in range(3))
            buf = max(0.0, min(V5_BUFFER, gap / 2 - 0.01))
            reg_6a = classify(v, reg_6a, th)
            out["V6-A"].append(matrix_position(reg_6a, er, v, th, buf))
        rk = expanding_rank(a, t)
        aiae_comp = np.nan if rk is None else V6B_AIAE_MAX * (1 - rk)
        erp_comp = erp_v4_tier(er)
        out["AIAE-only"].append(aiae_comp)
        out["ERP-only"].append(erp_comp)
        out["V6-B"].append(np.nan if rk is None else round((0.5 * aiae_comp + 0.5 * erp_comp) * 20) / 20)
        out["固定65%"].append(0.65)
        out["满仓"].append(1.0)
    return pd.DataFrame(out, index=sig.index)


# ══════════════════════════════════════════════════════════════
#  回测与指标
# ══════════════════════════════════════════════════════════════

def simulate(pos: pd.Series, ret: pd.Series) -> pd.Series:
    """第 t 月末仓位 × 第 t+1 月收益 − 换手成本; 返回按 t+1 月索引的月收益。"""
    p = pos.shift(1)                                          # t 月的收益用 t−1 月末的仓位
    turn = pos.diff().abs().shift(1).fillna(p)                # 首月建仓也计成本
    df = pd.concat([p.rename("p"), turn.rename("turn"), ret.rename("r")], axis=1, join="inner").dropna()
    return df["p"] * df["r"] - COST * df["turn"]


def metrics(r: pd.Series, pos: pd.Series) -> dict:
    n = len(r)
    if n == 0:
        return {}
    nav = (1 + r).cumprod()
    yrs = n / 12
    cagr = nav.iloc[-1] ** (1 / yrs) - 1
    vol = r.std(ddof=1) * math.sqrt(12)
    mdd = float((nav / nav.cummax() - 1).min())
    p = pos.reindex(r.index.map(lambda m: m - 1)).values
    return {
        "months": n, "start": str(r.index[0]), "end": str(r.index[-1]),
        "cagr": round(float(cagr), 4), "vol": round(float(vol), 4),
        "sharpe": round(float(r.mean() / r.std(ddof=1) * math.sqrt(12)), 3) if r.std(ddof=1) > 0 else None,
        "mdd": round(mdd, 4), "calmar": round(float(cagr / abs(mdd)), 3) if mdd < 0 else None,
        "turnover": round(float(np.nansum(np.abs(np.diff(p))) / yrs), 3),
        "avg_pos": round(float(np.nanmean(p)), 3),
    }


def _sharpe(x: np.ndarray) -> float:
    s = x.std(ddof=1)
    return x.mean() / s * math.sqrt(12) if s > 0 else 0.0


def boot_prob_better(a: pd.Series, b: pd.Series, n: int = BOOT_N, block: int = BOOT_BLOCK, seed: int = BOOT_SEED):
    """分块自助法: P(Sharpe(a) > Sharpe(b)), a/b 同一月份对齐。"""
    df = pd.concat([a, b], axis=1, join="inner").dropna().values
    T = len(df)
    if T < block * 2:
        return None
    rng = np.random.default_rng(seed)
    nb = math.ceil(T / block)
    wins = 0
    for _ in range(n):
        idx = np.concatenate([np.arange(s, s + block) % T for s in rng.integers(0, T, nb)])[:T]
        x = df[idx]
        wins += _sharpe(x[:, 0]) > _sharpe(x[:, 1])
    return round(wins / n, 3)


# ══════════════════════════════════════════════════════════════
#  判定 (预登记 §5)
# ══════════════════════════════════════════════════════════════

def decide(m: dict, p_better: dict) -> dict:
    v5 = m["V5"]
    checks = {}
    for k in ("V6-A", "V6-B"):
        c = m[k]
        checks[k] = {
            "sharpe_ok": c["sharpe"] >= v5["sharpe"] - RULE_SHARPE_TOL,
            "mdd_ok": (v5["mdd"] - c["mdd"]) * 100 <= RULE_MDD_TOL_PP,
            "turnover_ok": c["turnover"] <= v5["turnover"] * RULE_TURNOVER_X + 1e-9,
        }
        checks[k]["non_inferior"] = all(checks[k].values())
    ok = [k for k in ("V6-A", "V6-B") if checks[k]["non_inferior"]]
    chosen = max(ok, key=lambda k: m[k]["calmar"] or -1e9) if ok else "V5"
    c, erp = m[chosen], m["ERP-only"]
    aiae_adds = (c["sharpe"] > erp["sharpe"]) or (c["mdd"] > erp["mdd"])
    stab = {k: ("差异较稳定" if (v is not None and (v < 0.3 or v > 0.7)) else "差异在噪声范围内")
            for k, v in p_better.items()}
    return {"checks": checks, "chosen": chosen,
            "r1": (f"{chosen} 不劣于 V5 → 可替换" if chosen != "V5"
                   else "两个 v6 候选均未达到不劣标准 → 维持 V5; V5 回测需按含后视打折看待"),
            "r2_aiae_adds_value": bool(aiae_adds),
            "r2": ("AIAE 相对 ERP-only 有可测增量" if aiae_adds
                   else "AIAE 在本样本中无可测增量 → 提交 P3 讨论是否降级为读数"),
            "r3": stab}


# ══════════════════════════════════════════════════════════════
#  主流程
# ══════════════════════════════════════════════════════════════

def run(sig: pd.DataFrame, ret: pd.Series) -> dict:
    pos = build_positions(sig)
    first = pos["V6-A"].first_valid_index()
    pos = pos.loc[first:]                                     # 所有方案同一评估区间 (预登记 §2)
    rets = {k: simulate(pos[k], ret) for k in pos.columns}
    common = None
    for r in rets.values():
        common = r.index if common is None else common.intersection(r.index)
    rets = {k: r.loc[common] for k, r in rets.items()}
    m = {k: metrics(r, pos[k]) for k, r in rets.items()}
    pb = {k: boot_prob_better(rets[k], rets["V5"]) for k in ("V6-A", "V6-B", "ERP-only")}
    return {"metrics": m, "p_better_than_v5": pb, "decision": decide(m, pb),
            "positions": pos, "returns": rets}


def _fmt_pct(x, d=1):
    return "—" if x is None else f"{x * 100:.{d}f}%"


def write_report(res: dict, sig: pd.DataFrame) -> str:
    m, d, pb = res["metrics"], res["decision"], res["p_better_than_v5"]
    any_m = next(iter(m.values()))
    lines = [
        "# AIAE v6 研究结果", "",
        f"> 运行: {datetime.now():%Y-%m-%d %H:%M} · 预登记: docs/AIAE_V6_PREREGISTRATION.md · "
        f"评估区间 {any_m['start']} ~ {any_m['end']} ({any_m['months']} 个月)",
        f"> 信号数据 {sig.index[0]} ~ {sig.index[-1]}"
        + (f" · ERP 降级月份 {int(sig['erp_degraded'].sum())} 个" if "erp_degraded" in sig.columns else ""), "",
        "## 1. 指标", "",
        "| 方案 | 年化 | 波动 | Sharpe | 最大回撤 | Calmar | 年化换手 | 平均仓位 | P(优于V5) |",
        "|---|---|---|---|---|---|---|---|---|",
    ]
    for k, v in m.items():
        lines.append(f"| {k} | {_fmt_pct(v['cagr'])} | {_fmt_pct(v['vol'])} | {v['sharpe']} | {_fmt_pct(v['mdd'])} | "
                     f"{v['calmar']} | {v['turnover']} | {_fmt_pct(v['avg_pos'], 0)} | {pb.get(k, '—') if k != 'V5' else '—'} |")
    lines += ["", "## 2. 判定 (按预登记 §5, 未改动规则)", ""]
    for k, c in d["checks"].items():
        lines.append(f"- {k}: Sharpe {'✅' if c['sharpe_ok'] else '❌'} · 回撤 {'✅' if c['mdd_ok'] else '❌'} · "
                     f"换手 {'✅' if c['turnover_ok'] else '❌'} → {'不劣于 V5' if c['non_inferior'] else '未达标'}")
    lines += ["", f"**R1**: {d['r1']}", "", f"**R2**: {d['r2']}", "",
              "**R3**: " + " · ".join(f"{k} {v}" for k, v in d["r3"].items()), "",
              "## 3. 局限", "", "见预登记 §6。本结果只说明本样本 (约 2 个周期) 内的情况。", ""]
    return "\n".join(lines)


def main():
    sig = load_signals()
    ret = load_monthly_returns()
    res = run(sig, ret)
    md = write_report(res, sig)
    os.makedirs(os.path.dirname(OUT_MD), exist_ok=True)
    with open(OUT_MD, "w", encoding="utf-8") as f:
        f.write(md)
    dump = {"generated_at": datetime.now().isoformat(timespec="seconds"),
            "metrics": res["metrics"], "p_better_than_v5": res["p_better_than_v5"], "decision": res["decision"],
            "positions": {str(i): {k: (None if pd.isna(v) else round(float(v), 4)) for k, v in row.items()}
                          for i, row in res["positions"].iterrows()}}
    with open(OUT_JSON, "w", encoding="utf-8") as f:
        json.dump(dump, f, ensure_ascii=False, indent=2)
    print(md)
    print(f"\n已写入: {OUT_MD}\n        {OUT_JSON}")


if __name__ == "__main__":
    main()
