"""strategies package"""
