"""
组合回撤刹车 (分档 + 迟滞) 校准
================================

    python -m strategies.drawdown_calibration          # 结果写 data_lake/drawdown_calibration.json

方法 (与生产 services/drawdown.py 同一口径):
  · 信号: 风险资产净值 (不含现金) 自高水位的回撤, 收盘判定
  · 执行: 次日开盘调仓, 隔夜收益按旧仓位、日内按新仓位; 开盘即跌停 → 卖出顺延; 单边成本 0.1%; 现金年化 1.5%
  · 资产池: data_lake/daily_prices 全部可交易标的, 每只单独作为一个 "组合" ——
    本账户有效独立押注 ≈1.3, 行为更接近单一资产而不是分散组合
  · 样本内 < 2021-01-01 ≤ 样本外; 指标取各资产相对买入持有的中位数
  · 网格 = 当前参数的邻域 (±2pp / 软硬两种仓位上限 / 回补 1/3 vs 1/2) —— 选平稳区域, 不追单点最优
"""
from __future__ import annotations

import json
import os
import sys
from datetime import datetime
from typing import Callable, Optional

import numpy as np
import pandas as pd

_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _ROOT not in sys.path:
    sys.path.insert(0, _ROOT)

from strategies.trailing_stop_calibration import load_assets, limit_pct  # noqa: E402

OUT_PATH = os.path.join(_ROOT, "data_lake", "drawdown_calibration.json")
SPLIT = "2021-01-01"
CASH = 0.015 / 250
COST = 0.001

GRID = {
    "D 12/20/28→75/50/25": [(0.12, 0.75), (0.20, 0.50), (0.28, 0.25)],
    "D− 10/18/26": [(0.10, 0.75), (0.18, 0.50), (0.26, 0.25)],
    "D+ 14/22/30": [(0.14, 0.75), (0.22, 0.50), (0.30, 0.25)],
    "软 →80/60/40": [(0.12, 0.80), (0.20, 0.60), (0.28, 0.40)],
    "硬 →70/40/20": [(0.12, 0.70), (0.20, 0.40), (0.28, 0.20)],
}


def simulate(open_: np.ndarray, close: np.ndarray, pre_close: np.ndarray, lim: float,
             tiers: list, rerisk: float, signal: str = "book") -> tuple[np.ndarray, np.ndarray]:
    n = len(close)
    acct, book, e, target = 1.0, 1.0, 1.0, 1.0
    hwm, tier, trough = 1.0, 0, 1.0
    nav, expo = np.ones(n), np.ones(n)
    for t in range(1, n):
        r_on = open_[t] / close[t - 1] - 1
        r_id = close[t] / open_[t] - 1
        locked = open_[t] <= pre_close[t] * (1 - lim) * 1.002
        acct *= 1 + e * r_on + (1 - e) * CASH / 2
        if target != e and not (target < e and locked):
            acct *= 1 - COST * abs(target - e)
            e = target
        acct *= 1 + e * r_id + (1 - e) * CASH / 2
        book *= (1 + r_on) * (1 + r_id)
        nav[t], expo[t] = acct, e
        x = book if signal == "book" else acct
        hwm = max(hwm, x)
        dd = x / hwm - 1
        lvl = tier
        while lvl < len(tiers) and dd <= -tiers[lvl][0]:
            lvl += 1
        if lvl > tier:
            tier, trough = lvl, x
        elif tier > 0:
            trough = min(trough, x)
            if x >= trough + rerisk * (hwm - trough) or x >= hwm:
                tier, trough = tier - 1, x
        target = 1.0 if tier == 0 else tiers[tier - 1][1]
    return nav, expo


def _metrics(nav: pd.Series, expo: pd.Series) -> dict:
    nav = nav / nav.iloc[0]
    yrs = len(nav) / 250
    cagr = nav.iloc[-1] ** (1 / yrs) - 1
    dd = nav / nav.cummax() - 1
    mdd = float(dd.min())
    return {"cagr": cagr, "mdd": mdd, "calmar": cagr / abs(mdd) if mdd < 0 else np.nan,
            "ulcer": float(np.sqrt((dd ** 2).mean())), "expo": float(expo.mean()),
            "turn": float(expo.diff().abs().sum() / yrs)}


def run(loader: Optional[Callable[[str], pd.DataFrame]] = None, codes: Optional[list] = None) -> dict:
    assets = load_assets(loader, codes)
    pols = {"BH": ([], 0.0, "book")}
    for name, t in GRID.items():
        for rr in (1 / 3, 1 / 2):
            pols[f"{name} 回补{round(rr * 100)}%"] = (t, rr, "book")
    rows = []
    for a in assets:
        if len(a["C"]) < 500:
            continue
        c = a["C"]
        o = np.where(a["O"] > 0, a["O"], c)
        pc = np.r_[c[0], c[:-1]]                     # 已连续化收盘 → 前收
        for pn, (t, rr, sig) in pols.items():
            nav, ex = simulate(o, c, pc, limit_pct(a["code"]), t, rr, sig)
            nav, ex = pd.Series(nav, index=a["idx"]), pd.Series(ex, index=a["idx"])
            for per, m in (("all", slice(None)), ("is", nav.index < SPLIT), ("oos", nav.index >= SPLIT)):
                if isinstance(m, slice):
                    nv, ee = nav, ex
                else:
                    nv, ee = nav[m], ex[m]
                if len(nv) < 250:
                    continue
                rows.append({"code": a["code"], "policy": pn, "period": per, **_metrics(nv, ee)})
    df = pd.DataFrame(rows)
    bh = df[df.policy == "BH"].set_index(["code", "period"])
    x = df[df.policy != "BH"].join(bh[["cagr", "mdd", "calmar"]], on=["code", "period"], rsuffix="_bh")
    x["d_mdd"], x["d_cagr"] = x.mdd - x.mdd_bh, x.cagr - x.cagr_bh
    x["calmar_up"] = x.calmar > x.calmar_bh
    g = x.groupby(["period", "policy"]).agg(n=("code", "size"), d_mdd=("d_mdd", "median"), d_cagr=("d_cagr", "median"),
                                            calmar_up=("calmar_up", "mean"), expo=("expo", "mean"),
                                            turn=("turn", "median")).round(4)
    out = {"generated_at": datetime.now().isoformat(timespec="seconds"), "assets": int(df.code.nunique()),
           "method": __doc__.strip().splitlines()[4:11],
           "summary": [{"period": p, "policy": q, **v} for (p, q), v in g.to_dict("index").items()]}
    return out


# ═══════════════════════════════════════════════════════════════
#  按"个人最大可承受回撤"重新校准 (2026-10-24)
#    python -m strategies.drawdown_calibration --budget 0.5
#  同一模拟器 / 同一资产池 / 同一执行口径, 只是:
#    · 网格换成以预算为中心的邻域 (末档 = 预算 − 10pp, 留出跌停卖不出与跳空的余量)
#    · 额外报告 "最大回撤超过预算的资产占比" (breach) 与回撤分布的尾部 (最差 10%)
#    · 额外报告当前持仓篮子 (portfolio_store 持仓按市值加权) 的模拟
#  选择规则 (看结果之前写定, 见 docs/drawdown_control.md §3b):
#    ① 全区间与样本外 breach ≤ 10%;  ② 满足①者中年化代价最小;  ③ 其 ±2pp / 软硬邻居也基本满足①
# ═══════════════════════════════════════════════════════════════

BREACH_MAX = 0.10


def budget_grid(budget: float) -> dict:
    b = round(budget, 2)
    t3 = b - 0.10                                   # 末档触发
    base = [t3 - 0.20, t3 - 0.10, t3]
    pct = lambda x: int(round(x * 100))
    g = {}
    for tag, shift in (("B", 0.0), ("B−", -0.02), ("B+", 0.02)):
        t = [round(x + shift, 2) for x in base]
        g[f"{tag} {pct(t[0])}/{pct(t[1])}/{pct(t[2])}→75/50/25"] = [(t[0], 0.75), (t[1], 0.50), (t[2], 0.25)]
    g[f"B软 {pct(base[0])}/{pct(base[1])}/{pct(base[2])}→80/60/40"] = [(base[0], 0.80), (base[1], 0.60), (base[2], 0.40)]
    g[f"B硬 {pct(base[0])}/{pct(base[1])}/{pct(base[2])}→70/40/20"] = [(base[0], 0.70), (base[1], 0.40), (base[2], 0.20)]
    g["现行 D 12/20/28→75/50/25"] = GRID["D 12/20/28→75/50/25"]
    return g


def _holdings_basket(store_path: Optional[str] = None, loader: Optional[Callable[[str], pd.DataFrame]] = None,
                     start: str = "2024-01-02") -> Optional[dict]:
    """当前持仓按市值加权的组合 (每日按固定权重再平衡; 缺行情的标的当日按剩余标的归一)。"""
    from strategies.trailing_stop_calibration import PRICE_DIR, normalize_bars
    store_path = store_path or os.path.join(_ROOT, "data_lake", "portfolio_store.json")
    if not os.path.exists(store_path):
        return None
    with open(store_path, "r", encoding="utf-8") as f:
        pos = (json.load(f) or {}).get("positions") or {}
    w = {c: float(p.get("broker_market_value") or 0) for c, p in pos.items()}
    w = {c: v for c, v in w.items() if v > 0}
    if not w:
        return None
    loader = loader or (lambda c: pd.read_parquet(os.path.join(PRICE_DIR, f"{c}.parquet")))
    on, idy = {}, {}
    for c in w:
        try:
            d = normalize_bars(loader(c))
        except Exception:
            continue
        o = d["open"].where(d["open"] > 0, d["close"])
        on[c] = o / d["close"].shift(1) - 1
        idy[c] = d["close"] / o - 1
    if not on:
        return None
    ON, ID = pd.DataFrame(on), pd.DataFrame(idy)
    ON, ID = ON[ON.index >= start], ID[ID.index >= start]
    W = pd.Series(w)[ON.columns]
    avail = ON.notna() & ID.notna()
    wm = avail.mul(W, axis=1)
    wm = wm.div(wm.sum(axis=1), axis=0)
    r_on = (ON.fillna(0) * wm).sum(axis=1)
    r_id = (ID.fillna(0) * wm).sum(axis=1)
    C = np.cumprod((1 + r_on) * (1 + r_id)).to_numpy()
    O = C / (1 + r_id.to_numpy())
    return {"idx": ON.index, "C": C, "O": O, "weights_pct": {c: round(100 * v / sum(w.values()), 1) for c, v in w.items()},
            "coverage": round(float(sum(W)) / sum(w.values()), 3)}


def run_budget(budget: float = 0.5, loader: Optional[Callable[[str], pd.DataFrame]] = None,
               codes: Optional[list] = None, store_path: Optional[str] = None) -> dict:
    assets = load_assets(loader, codes)
    grid = budget_grid(budget)
    pols = {"BH": ([], 0.0)}
    for name, t in grid.items():
        for rr in (1 / 3, 1 / 2):
            pols[f"{name} 回补{round(rr * 100)}%"] = (t, rr)
    rows = []
    for a in assets:
        if len(a["C"]) < 500:
            continue
        c = a["C"]
        o = np.where(a["O"] > 0, a["O"], c)
        pc = np.r_[c[0], c[:-1]]
        for pn, (t, rr) in pols.items():
            nav, ex = simulate(o, c, pc, limit_pct(a["code"]), t, rr, "book")
            nav, ex = pd.Series(nav, index=a["idx"]), pd.Series(ex, index=a["idx"])
            for per, m in (("all", None), ("is", nav.index < SPLIT), ("oos", nav.index >= SPLIT)):
                nv, ee = (nav, ex) if m is None else (nav[m], ex[m])
                if len(nv) < 250:
                    continue
                rows.append({"code": a["code"], "policy": pn, "period": per, **_metrics(nv, ee)})
    df = pd.DataFrame(rows)
    df["breach"] = df.mdd < -budget
    bh = df[df.policy == "BH"].set_index(["code", "period"])
    x = df.join(bh[["cagr", "mdd"]], on=["code", "period"], rsuffix="_bh")
    x["d_cagr"] = x.cagr - x.cagr_bh
    g = x.groupby(["period", "policy"]).agg(
        n=("code", "size"), breach=("breach", "mean"), mdd_med=("mdd", "median"),
        mdd_p10=("mdd", lambda s: s.quantile(0.10)), d_cagr=("d_cagr", "median"),
        expo=("expo", "mean"), turn=("turn", "median")).round(4)
    summary = [{"period": p, "policy": q, **v} for (p, q), v in g.to_dict("index").items()]

    # 选择 (规则见模块注释): 只在新网格 (非 BH / 非现行) 中选
    def ok(p, per):
        r = g.loc[(per, p)] if (per, p) in g.index else None
        return r is not None and r["breach"] <= BREACH_MAX
    cands = [p for p in pols if p != "BH" and not p.startswith("现行")]
    feasible = [p for p in cands if ok(p, "all") and ok(p, "oos")]
    pick = max(feasible, key=lambda p: g.loc[("all", p), "d_cagr"]) if feasible else None
    neighbors = {}
    if pick:
        rr = pick.split(" 回补")[1]
        for p in cands:
            if p.endswith("回补" + rr) and p != pick:
                neighbors[p] = bool(ok(p, "all") and ok(p, "oos"))

    basket = None
    hb = _holdings_basket(store_path, loader)
    if hb is not None:
        basket = {"start": str(hb["idx"][0].date()), "end": str(hb["idx"][-1].date()),
                  "weights_pct": hb["weights_pct"], "coverage": hb["coverage"], "policies": {}}
        pc = np.r_[hb["C"][0], hb["C"][:-1]]
        for pn, (t, rr) in pols.items():
            nav, ex = simulate(hb["O"], hb["C"], pc, 0.99, t, rr, "book")
            m = _metrics(pd.Series(nav, index=hb["idx"]), pd.Series(ex, index=hb["idx"]))
            basket["policies"][pn] = {k: round(float(v), 4) for k, v in m.items()}

    return {"generated_at": datetime.now().isoformat(timespec="seconds"), "budget": budget,
            "assets": int(df.code.nunique()), "split": SPLIT, "breach_max": BREACH_MAX,
            "grid": {k: [list(t) for t in v] for k, v in grid.items()},
            "selection": {"pick": pick, "feasible": feasible, "neighbors_feasible": neighbors,
                          "rule": "全区间与样本外 breach≤10% → 年化代价最小 → 邻居也满足"},
            "summary": summary, "holdings_basket": basket}


if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--budget", type=float, default=None,
                    help="个人最大可承受回撤 (如 0.5); 不给则运行原有 25% 邻域网格")
    args = ap.parse_args()
    if args.budget is None:
        res = run()
        out = OUT_PATH
    else:
        res = run_budget(args.budget)
        out = os.path.join(_ROOT, "data_lake", f"drawdown_calibration_b{int(round(args.budget * 100))}.json")
    os.makedirs(os.path.dirname(out), exist_ok=True)
    with open(out, "w", encoding="utf-8") as f:
        json.dump(res, f, ensure_ascii=False, indent=2, default=str)
    df = pd.DataFrame(res["summary"])
    key = "breach" if args.budget is not None else "d_mdd"
    with pd.option_context("display.width", 220, "display.max_rows", 100):
        print(df[df.period == "all"].sort_values(key, ascending=args.budget is not None).to_string(index=False))
    if args.budget is not None:
        print("选择:", res["selection"])
    print(f"→ {out}")
