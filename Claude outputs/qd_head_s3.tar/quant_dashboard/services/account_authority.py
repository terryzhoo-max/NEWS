"""账户数据权威环境 (2026-11-04, docs/ACCOUNT_AUTHORITY_AND_RISK_REFRESH_PLAN.md 1.3 续)。

规则 (用户已定): 服务器为权威环境, 账本以服务器导入的对账单和成交为准。
  - 环境变量 ACCOUNT_AUTHORITY=server → 权威 (服务器 .env 必须写这一行);
    =local 或未设置 / 其他值 → 非权威 (fail-closed, 用户 11-04 确认: 未设置按非权威处理)。
  - 非权威环境: 写账户数据的接口返回 403 (code=NON_AUTHORITATIVE);
    买入门控一律拒绝 (reason_code=NON_AUTHORITATIVE); 不向外推送 (serverchan / email / 企微)。
  - 每次调用时读取环境变量 (不缓存), 测试与运行时切换均即时生效。
"""
from __future__ import annotations

import os
from typing import Any, Optional

ENV_VAR = "ACCOUNT_AUTHORITY"
SERVER = "server"
LOCAL = "local"
UNSET = "unset"

NON_AUTHORITATIVE = "NON_AUTHORITATIVE"
IMPORT_MESSAGE = "本环境非权威（本机开发），请在服务器导入（localhost:18000）"
WRITE_MESSAGE = "本环境非权威（本机开发），账户数据只在服务器写入（localhost:18000）"
GATE_MESSAGE = "本环境非权威（本机开发），禁止买入/加仓；执行建议以服务器为准（localhost:18000）"


def authority() -> str:
    """server / local / unset (未设置或无法识别的值都归为 unset)。"""
    raw = str(os.environ.get(ENV_VAR, "") or "").strip().lower()
    if raw in (SERVER, LOCAL):
        return raw
    return UNSET


def is_authoritative() -> bool:
    """只有 ACCOUNT_AUTHORITY=server 才是权威环境。"""
    return authority() == SERVER


def env_label() -> str:
    return "权威" if is_authoritative() else "非权威"


def rejection(message: str = IMPORT_MESSAGE) -> dict:
    """接口拒绝时的统一说明 (FastAPI HTTPException 的 detail)。"""
    return {"code": NON_AUTHORITATIVE, "message": message, "authority": authority()}


def require_authoritative(message: str = IMPORT_MESSAGE) -> None:
    """写账户数据的接口第一行调用: 非权威 → HTTP 403。"""
    if is_authoritative():
        return
    from fastapi import HTTPException
    raise HTTPException(status_code=403, detail=rejection(message))


def _account_as_of() -> dict:
    """账户数据截至时间 (只读): 持仓快照时点 + 对账单日期 + 成交台账最后一笔。"""
    out: dict[str, Any] = {"holdings_as_of": None, "statement_date": None,
                           "valuation_time_known": None, "last_trade": None}
    try:
        from services import account_exposure as ax
        store = ax.load_store() or {}
        meta = ax.snapshot_meta(store)
        out["holdings_as_of"] = meta["at"].isoformat(timespec="minutes") if meta["at"] else None
        out["statement_date"] = store.get("import_date")
        out["valuation_time_known"] = meta["time_known"]
    except Exception:
        pass
    try:
        from services.trade_import import load_ledger
        trades = (load_ledger() or {}).get("trades") or []
        if trades:
            last = max(trades, key=lambda t: (str(t.get("date") or ""), str(t.get("time") or "")))
            out["last_trade"] = " ".join(x for x in (str(last.get("date") or ""), str(last.get("time") or "")) if x)
    except Exception:
        pass
    return out


def status(include_account: bool = True) -> dict:
    """GET /api/v1/system/authority 的内容 (横幅与审计页读取)。"""
    a = authority()
    out = {"authority": a, "authoritative": a == SERVER, "label": env_label(),
           "env_var": ENV_VAR,
           "note": ("服务器权威环境：账户数据在此导入" if a == SERVER else
                    "非权威环境：导入 / 清零 / 账户写入已关闭，买入门控拒绝，不对外推送；执行建议以服务器为准")}
    if a == UNSET:
        out["note"] += f"（{ENV_VAR} 未设置，按非权威处理）"
    if include_account:
        out["account"] = _account_as_of()
    return out


def startup_log(logger: Optional[Any] = None) -> None:
    """启动时写明当前环境 (main.py lifespan 调用)。"""
    import logging
    lg = logger or logging.getLogger("alphacore.authority")
    a = authority()
    if a == SERVER:
        lg.info("账户权威环境: %s=server（权威）", ENV_VAR)
    elif a == LOCAL:
        lg.warning("账户权威环境: %s=local（非权威）: 导入 / 清零 / 账户写入关闭, 买入门控拒绝, 不对外推送", ENV_VAR)
    else:
        lg.warning("账户权威环境: %s 未设置, 按非权威处理: 导入 / 清零 / 账户写入关闭, 买入门控拒绝, 不对外推送; "
                   "服务器 .env 必须写 %s=server", ENV_VAR, ENV_VAR)
