"""
AlphaCore · ERP 仓位规则 v4 前向记录 (2026-10-30 起)
====================================================
真正的样本外: 每个交易日只记录"第一次看到"的 v4 目标仓位, 之后不覆盖、不回填。
半年后用这份记录评估 v4 (见 docs/ERP_V4_PREREGISTRATION.md)。

- 触发: ERPTimingEngine.generate_report() 每次生成报告时调用 record();
        每日 15:35 收盘预热、早盘预热和页面访问都会走到这里。同一 trade_date 已有记录则跳过。
- 文件: data_lake/erp_v4_forward_log.csv (data_lake 不入 git, 只在运行服务的那台机器上累积)
- 测试运行时 (PYTEST_CURRENT_TEST) 不写文件、不推送。
- 提醒: 写入新交易日时与上一条记录比较, 分档变化 / 进入或退出分批加仓 / 利率正常化开关变化
        → 写入预警表并按 config/alert_config.json 的渠道推送 (与 alert_monitor 同一套渠道)。
        每个交易日最多比较一次, 天然去重。
"""
from __future__ import annotations

import csv
import logging
import os
import threading
from datetime import datetime

logger = logging.getLogger(__name__)

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
LOG_PATH = os.path.join(ROOT, "data_lake", "erp_v4_forward_log.csv")
START_DATE = "2026-10-30"     # 登记日; 之前的 trade_date 不记 (不算前向)

COLUMNS = [
    "trade_date", "recorded_at", "param_hash", "status",
    "erp", "erp_adj", "ep", "y10", "ep_pct", "y10_pct",
    "tier_position_pct", "trend", "staging_active", "target_position_pct",
    "legacy_score", "legacy_position_pct",
]

_lock = threading.Lock()


def _read_rows(path: str) -> list[dict]:
    if not os.path.exists(path):
        return []
    with open(path, encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))


def _existing_dates(path: str) -> set[str]:
    if not os.path.exists(path):
        return set()
    with open(path, encoding="utf-8-sig", newline="") as f:
        return {row.get("trade_date", "") for row in csv.DictReader(f)}


def count_days(path: str | None = None) -> int:
    p = path or LOG_PATH
    return len(_existing_dates(p) - {""})


def build_row(report: dict) -> dict | None:
    snap = report.get("current_snapshot") or {}
    v4 = snap.get("allocation_v4") or {}
    td = snap.get("trade_date")
    if not td or v4.get("target_position_pct") is None:
        return None
    pl = (report.get("position_layer") or {}).get("position") or {}
    return {
        "trade_date": td,
        "recorded_at": datetime.now().isoformat(timespec="seconds"),
        "param_hash": v4.get("param_hash"),
        "status": v4.get("status"),
        "erp": v4.get("erp"), "erp_adj": v4.get("erp_adj"),
        "ep": v4.get("ep"), "y10": v4.get("y10"),
        "ep_pct": v4.get("ep_pct"), "y10_pct": v4.get("y10_pct"),
        "tier_position_pct": v4.get("tier_position_pct"),
        "trend": v4.get("trend"),
        "staging_active": v4.get("staging_active"),
        "target_position_pct": v4.get("target_position_pct"),
        "legacy_score": (report.get("signal") or {}).get("score"),
        "legacy_position_pct": pl.get("suggested_position_pct"),
    }


def record(report: dict, path: str | None = None, force_in_tests: bool = False) -> str:
    """返回 'written' / 'exists' / 'skipped:<原因>'。"""
    if os.environ.get("PYTEST_CURRENT_TEST") and not force_in_tests:
        return "skipped:pytest"
    if report.get("status") != "success":
        return "skipped:status"
    row = build_row(report)
    if row is None:
        return "skipped:no_v4"
    if row["trade_date"] < START_DATE:
        return "skipped:before_start"
    p = path or LOG_PATH
    with _lock:
        rows = _read_rows(p)
        if row["trade_date"] in {r.get("trade_date") for r in rows}:
            return "exists"
        prev = rows[-1] if rows else None
        os.makedirs(os.path.dirname(p), exist_ok=True)
        new = not os.path.exists(p)
        with open(p, "a", encoding="utf-8-sig" if new else "utf-8", newline="") as f:
            w = csv.DictWriter(f, fieldnames=COLUMNS)
            if new:
                w.writeheader()
            w.writerow(row)
    logger.info("ERP v4 前向记录: %s 目标 %s%%", row["trade_date"], row["target_position_pct"])
    try:
        events = detect_events(prev, row)
        if events:
            _emit(events)
    except Exception as e:   # 提醒失败不影响记录
        logger.warning("ERP v4 提醒失败: %s", e)
    return "written"


# ══════════════════════════════════════════════════════════════
# 提醒
# ══════════════════════════════════════════════════════════════

def _f(x):
    try:
        return float(x)
    except (TypeError, ValueError):
        return None


def _b(x) -> bool:
    return str(x).strip().lower() in ("true", "1", "yes")


_BACKGROUND_NOTE = "ERP 只作背景，不作执行依据；仓位以 AIAE 执行目标为准。"


def detect_events(prev: dict | None, new: dict) -> list[dict]:
    """比较相邻两条记录 (CSV 读回的是字符串, 新行是原始类型), 返回事件列表。"""
    if not prev:
        return []
    from engines.erp_allocation_v4 import PARAMS
    floor = PARAMS["y10_floor"]
    ev = []
    t0, t1 = _f(prev.get("tier_position_pct")), _f(new.get("tier_position_pct"))
    if t0 is not None and t1 is not None and t0 != t1:
        up = t1 > t0
        # 2026-11-02: ERP 为背景读数 — 告警表文案不写仓位数字和加减仓措辞 (前向记录 CSV 不受影响)
        ev.append({"rule_id": "erp_v4_tier_change", "severity": "warning", "icon": "📈" if up else "📉",
                   "title": f"ERP v4 读数分档{'上调' if up else '下调'}（背景读数）",
                   "detail": (f"{new['trade_date']} 正常化 ERP {new.get('erp_adj')}%（原始 {new.get('erp')}%）。"
                              f"{_BACKGROUND_NOTE}"),
                   "value": _f(new.get("erp_adj")) or 0})
    s0, s1 = _b(prev.get("staging_active")), _b(new.get("staging_active"))
    if s0 != s1:
        ev.append({"rule_id": "erp_v4_staging", "severity": "info", "icon": "🪜",
                   "title": "ERP v4 读数进入分批阶段（背景读数）" if s1 else "ERP v4 读数退出分批阶段（背景读数）",
                   "detail": f"{new['trade_date']} 趋势 {new.get('trend')}。{_BACKGROUND_NOTE}",
                   "value": _f(new.get("erp_adj")) or 0})
    y0, y1 = _f(prev.get("y10")), _f(new.get("y10"))
    if y0 is not None and y1 is not None and (y0 < floor) != (y1 < floor):
        on = y1 < floor
        ev.append({"rule_id": "erp_v4_rate_floor", "severity": "info", "icon": "🏦",
                   "title": f"ERP v4 利率正常化{'开启' if on else '关闭'}（10Y {y1:.2f}%）",
                   "detail": (f"10Y 国债{'跌破' if on else '回到'} {floor}%"
                              f"{'，计算 ERP 时按 ' + str(floor) + '% 计' if on else '以上，按实际利率计算'}。"
                              f"当前正常化 ERP {new.get('erp_adj')}%。{_BACKGROUND_NOTE}"),
                   "value": y1})
    return ev


def _emit(events: list[dict]):
    if os.environ.get("PYTEST_CURRENT_TEST"):
        return
    try:
        from services import db as ac_db
        for e in events:
            ac_db.save_alert(rule_id=e["rule_id"], severity=e["severity"],
                             title=f'{e["icon"]} {e["title"]}', detail=e["detail"], value=e["value"])
    except Exception as ex:
        logger.warning("ERP v4 预警写库失败: %s", ex)
    # 2026-11-02: ERP 为背景读数, 与 JCS 一致 — 只写告警表, 不推送 Server酱/邮件/企微
