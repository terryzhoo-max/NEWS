"""Evidence gate bound to the exact JCS implementation. Never invent a backtest."""
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
EVIDENCE_PATH = ROOT / "config" / "jcs_validation.json"
MODEL_VERSION = "jcs-26.0-macro-env"  # 2026-11-01: JCS = 宏观环境读数 (MR/BOND 移出, 等比例归一; 待核验因子按未知)


def model_fingerprint():
    digest = hashlib.sha256()
    for name in ("jcs.py", "conflicts.py", "quality.py", "snapshot.py", "action_plan.py", "controls.py"):
        path = ROOT / "dashboard_modules" / "decision" / name
        digest.update(name.encode())
        digest.update(path.read_text(encoding="utf-8").encode("utf-8"))
    return digest.hexdigest()


def validation_status(*, path=None, now=None):
    fingerprint = model_fingerprint()
    result = {"model_version": MODEL_VERSION, "model_fingerprint": fingerprint,
              "status": "insufficient_evidence", "execution_ready": False,
              "detail": "尚无绑定当前版本的样本外验证；数学与软件测试不代表投资有效性"}
    try:
        evidence = json.loads(Path(path or EVIDENCE_PATH).read_text(encoding="utf-8"))
        if evidence.get("model_fingerprint") != fingerprint:
            return {**result, "status": "mismatch", "detail": "历史验证未覆盖当前模型版本"}
        expires = datetime.fromisoformat(evidence["expires_at"].replace("Z", "+00:00"))
        now = now or datetime.now(timezone.utc)
        if expires.tzinfo is None or expires <= now:
            return {**result, "status": "stale", "detail": "验证证据到期或缺少时区"}
        checks = evidence.get("checks")
        required = {"out_of_time", "no_lookahead", "costs_and_slippage", "risk_limits", "calibration"}
        if (evidence.get("schema_version") != 1 or evidence.get("status") != "validated"
                or not isinstance(checks, dict) or not required.issubset(checks)
                or any(checks[key] is not True for key in required)
                or not evidence.get("run_id") or not evidence.get("reviewer")
                or not evidence.get("data_through")):
            return result
        # A checklist without its actual immutable run artifact is not evidence.
        artifact = (ROOT / evidence["artifact_path"]).resolve()
        if not artifact.is_relative_to(ROOT.resolve()):
            return result
        raw = artifact.read_bytes()
        if hashlib.sha256(raw).hexdigest() != evidence.get("artifact_sha256"):
            return result
        report = json.loads(raw)
        if (report.get("model_fingerprint") != fingerprint
                or report.get("run_id") != evidence["run_id"]
                or report.get("statistical_validation") != "passed"
                or not isinstance(report.get("out_of_sample_observations"), int)
                or report["out_of_sample_observations"] <= 0):
            return result
        # Validation is evidence for review, never an order-release credential.
        return {**result, "status": "validated", "execution_ready": False,
                "run_id": evidence["run_id"], "data_through": evidence["data_through"],
                "detail": "验证记录已关联；订单仍须独立账户、行情与交易通道校验"}
    except (OSError, ValueError, KeyError, TypeError, AttributeError):
        return result
