"""
AlphaCore · 海外 AIAE 降级为估值背景 (P0, 2026-11-01)
=====================================================
方案: docs/AIAE_GLOBAL_OPTIMIZATION_PLAN.md

美/日/港 AIAE 引擎的读数是代理口径 (总市值 / M2 等), 档位阈值、仓位矩阵、ETF 配额均未经回测。
本模块不改引擎计算, 只在输出层:
  1. 给每个地区报告加 role=background 与口径说明;
  2. 仓位 / 配额 / 交叉验证标记 deprecated (字段保留, 向后兼容), 档位文案去掉操作指令;
  3. 统一构建 /aiae_global/report 的四地对比载荷 (路由与后台预热共用, 避免两处口径不一致)。

AIAE 执行目标 (A 股) 是全站唯一的仓位数字; 海外 AIAE 不参与任何仓位计算。

P3 (2026-11-01): 海外三地一律不分档 (REGIMES_DISABLED)。
  - 美股: P2 预登记检验未通过, 展示真实 AIAE (Z.1) 读数与分位;
  - 港股: AIAE 框架不适用 (市值以内地公司为主, 定价资金以外资 / 南向为主), 展示南向资金与 AH 溢价;
  - 日股: 代理读数, 只展示数值。
  引擎仍计算 regime (保留历史记录与向后兼容), 但不再用于任何展示或提示。
"""
from copy import deepcopy
from datetime import datetime
from typing import Dict, Optional

from services import aiae_normalizer as _norm

ROLE = "background"
PAYLOAD_VERSION = "p3"   # 缓存载荷版本: 旧版本缓存视为未命中

BASIS_NOTES = {
    "us": "代理口径: 美股总市值 / M2 (非美联储 Z.1 AIAE), 仅作对照; 真实 AIAE 见 aiae_real; 档位阈值未经回测",
    "jp": "代理口径: 日经推算市值 / 日本 M2, 外资流向为估算值; 档位阈值未经回测",
    "hk": "代理口径: 恒指市值 / 中国 M2; 档位阈值未经回测",
}

POSITION_NOTE = "海外 AIAE 仓位与 ETF 配额未经验证, 不执行; 仓位以 A 股 AIAE 执行目标为准"
CROSS_VALIDATION_NOTE = "交叉验证使用旧估算 ERP, 不作结论"
BACKGROUND_ACTION = "估值背景"
BACKGROUND_DESC = "仅作外部估值参考, 不构成操作建议"


REGIMES_DISABLED = True
NO_TIER_TEXT = "不分档 · 仅读数"

REMOVED_NOTE = "海外 AIAE 仓位矩阵 / ETF 配额 / ERP 交叉验证已删除 (2026-11-01 P1); 仓位以 A 股 AIAE 执行目标为准"


def removed_position(regime) -> Dict:
    """P1 起引擎不再计算仓位。保留键名 (值为 None), 旧调用方读取时不报错。"""
    return {"removed": True, "deprecated": True, "deprecated_note": REMOVED_NOTE, "regime": regime,
            "matrix_position": None, "erp_value": None, "erp_level": None, "matrix": None, "allocations": None}


def removed_cross_validation() -> Dict:
    return {"removed": True, "deprecated": True, "deprecated_note": REMOVED_NOTE,
            "verdict": "已停用", "confidence": 0, "confidence_stars": "", "color": "#64748b"}


def demote_region_report(report: Optional[Dict], region: str) -> Optional[Dict]:
    """返回降级后的副本 (不修改原对象与引擎常量)。幂等。"""
    if not isinstance(report, dict):
        return report
    out = deepcopy(report)
    out["role"] = ROLE
    out["basis_note"] = BASIS_NOTES.get(region, "代理口径; 档位阈值未经回测")

    pos = out.get("position")
    if isinstance(pos, dict):
        pos["deprecated"] = True
        pos.setdefault("deprecated_note", POSITION_NOTE)

    cv = out.get("cross_validation")
    if isinstance(cv, dict):
        cv["deprecated"] = True
        cv.setdefault("deprecated_note", CROSS_VALIDATION_NOTE)

    cur = out.get("current")
    ri = cur.get("regime_info") if isinstance(cur, dict) else None
    if isinstance(ri, dict):
        ri["action"] = BACKGROUND_ACTION
        ri["desc"] = BACKGROUND_DESC
        ri["position"] = "—"
        if REGIMES_DISABLED:
            ri["cn"] = NO_TIER_TEXT
    if REGIMES_DISABLED:
        out["regime_disabled"] = True

    sigs = out.get("signals")
    if isinstance(sigs, list) and isinstance(ri, dict):
        for s in sigs:
            if isinstance(s, dict) and s.get("type") == "main":
                val = (cur or {}).get("aiae_v1")
                val_txt = f"{float(val):.1f}%" if isinstance(val, (int, float)) else "—"
                s["text"] = f"{ri.get('cn', '')} · {region.upper()} 读数 {val_txt} · 估值背景"
    return out


def is_current_payload(data) -> bool:
    return isinstance(data, dict) and data.get("role") == ROLE and data.get("payload_version") == PAYLOAD_VERSION


def regime_or_none(report: Optional[Dict]) -> Optional[int]:
    """可用于跨市场展示的档位: 报告缺失、降级或数据锁定时返回 None (不再默认 Ⅲ 档)。P3 起海外一律 None。"""
    if REGIMES_DISABLED or not isinstance(report, dict):
        return None
    if report.get("status") != "success" or report.get("decision_locked"):
        return None
    r = (report.get("current") or {}).get("regime")
    return int(r) if isinstance(r, (int, float)) else None


def _fmt(v, nd=1):
    return f"{float(v):.{nd}f}" if isinstance(v, (int, float)) else "—"


def region_readings(us: Optional[Dict], jp: Optional[Dict], hk: Optional[Dict]) -> Dict:
    """跨市场面板的海外读数 (不分档)。数据为默认值 / 兜底时标注, 不伪装成实测。"""
    out = {}
    real = (us or {}).get("aiae_real") or {}
    if real.get("status") == "success":
        out["US"] = {"label": "AIAE (Z.1)", "value": real.get("aiae"), "pct": real.get("pct"),
                     "as_of": (real.get("measured") or {}).get("quarter"),
                     "text": f"AIAE {_fmt(real.get('aiae'))}%" + (f" · {real['pct']:.0f}分位" if real.get("pct") is not None else ""),
                     "note": real.get("tier_note")}
    else:
        out["US"] = {"label": "AIAE (Z.1)", "value": None, "text": "Z.1 数据不可用", "note": (real or {}).get("reason")}

    jcur = (jp or {}).get("current") or {}
    out["JP"] = {"label": "代理读数", "value": jcur.get("aiae_v1"),
                 "text": f"代理 {_fmt(jcur.get('aiae_v1'))}%", "note": BASIS_NOTES["jp"],
                 "locked": bool((jp or {}).get("decision_locked"))}

    raw = (hk or {}).get("raw_data") or {}
    sb, ah = raw.get("southbound") or {}, raw.get("ah_premium") or {}
    sb_v, ah_v = sb.get("cumulative_12m_billion_rmb"), ah.get("index_value")
    sb_def, ah_def = sb.get("source") == "default", ah.get("source") == "default"
    parts = []
    if sb_v is not None:
        parts.append(f"南向12月 {float(sb_v):+,.0f}亿" + ("(默认值)" if sb_def else ""))
    if ah_v is not None:
        parts.append(f"AH溢价 {float(ah_v):.0f}" + ("(默认值)" if ah_def else ""))
    out["HK"] = {"label": "资金与比价", "southbound_12m_bn_rmb": sb_v, "southbound_date": sb.get("date"),
                 "southbound_source": sb.get("source"), "ah_premium": ah_v, "ah_date": ah.get("date"),
                 "ah_source": ah.get("source"), "ah_interpretation": ah.get("interpretation"),
                 "text": " · ".join(parts) if parts else "数据不可用",
                 "note": "AIAE 框架不适用于港股; AH 溢价 >100 表示 A 股比同公司 H 股贵"}
    return out


def build_global_payload(us_report: Dict, jp_report: Dict, hk_report: Dict,
                         cn_aiae_v1: float, cn_regime: int,
                         thresholds: Optional[Dict] = None) -> Dict:
    """/aiae_global/report 载荷 (路由与预热共用)。"""
    if thresholds is None:
        thresholds = _norm.get_region_thresholds()

    us = demote_region_report(us_report, "us")
    jp = demote_region_report(jp_report, "jp")
    hk = demote_region_report(hk_report, "hk")

    def _cur(rep, key, default):
        return ((rep or {}).get("current") or {}).get(key, default)

    us_v1, jp_v1, hk_v1 = _cur(us, "aiae_v1", 25.0), _cur(jp, "aiae_v1", 17.0), _cur(hk, "aiae_v1", 14.0)
    raw_vals = {"cn": cn_aiae_v1, "us": us_v1, "jp": jp_v1, "hk": hk_v1}
    # 2026-11-04: A 股 AIAE_V1 融合值可能因融资热度降级而为 None → 不参与温度比较 (不用缺省值补)
    norm_vals = {r: round(_norm.normalize_temp(v, r, thresholds), 1) for r, v in raw_vals.items() if v is not None}
    coldest = min(norm_vals, key=norm_vals.get)
    hottest = max(norm_vals, key=norm_vals.get)
    regimes = {"cn": cn_regime, "us": _cur(us, "regime", 3), "jp": _cur(jp, "regime", 3), "hk": _cur(hk, "regime", 3)}
    gp = _norm.mark_deprecated(_norm.compute_global_position(sum(norm_vals.values()) / len(norm_vals), regimes))

    return {
        "status": "success",
        "role": ROLE,
        "payload_version": PAYLOAD_VERSION,
        "timestamp": datetime.now().isoformat(),
        "us": us, "jp": jp, "hk": hk,
        "global_comparison": {
            "cn_aiae": cn_aiae_v1, "cn_regime": cn_regime,
            "us_aiae": us_v1, "us_regime": regimes["us"],
            "jp_aiae": jp_v1, "jp_regime": regimes["jp"],
            "hk_aiae": hk_v1, "hk_regime": regimes["hk"],
            # 跨市场展示用: P3 起海外一律不分档 (None), 改为展示读数
            "display_regimes": {"US": regime_or_none(us), "JP": regime_or_none(jp), "HK": regime_or_none(hk)},
            "display_readings": region_readings(us, jp, hk),
            "temps_note": "标准温度基于各地代理口径阈值, 不可横向比较, 仅保留字段",
            "cn_temp": norm_vals.get("cn"), "us_temp": norm_vals["us"],
            "jp_temp": norm_vals["jp"], "hk_temp": norm_vals["hk"],
            "coldest": coldest, "hottest": hottest,
            "recommendation": _norm.background_note(coldest, hottest, norm_vals),
            "global_position": gp,
            "allocation_deprecated": {"deprecated": True, "deprecated_note": _norm.DEPRECATED_NOTE},
            "locked_regions": [r for r, rep in (("us", us), ("jp", jp), ("hk", hk))
                               if isinstance(rep, dict) and rep.get("decision_locked")],
        },
    }
