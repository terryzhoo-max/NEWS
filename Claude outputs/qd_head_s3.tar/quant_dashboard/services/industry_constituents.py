"""Verified ETF tracking-index constituents with fail-closed lineage checks."""

from __future__ import annotations

import hashlib
import json
import math
import os
import threading
from datetime import date, datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Mapping

import pandas as pd

from services.strategy_params import get_industry_execution_rules


PROJECT_ROOT = Path(__file__).resolve().parents[1]
SNAPSHOT_PATH = PROJECT_ROOT / "data_lake" / "industry_index_constituents.json"
MANIFEST_PATH = PROJECT_ROOT / "config" / "industry_universe_history.json"
STOCK_LIST_PATH = PROJECT_ROOT / "data_lake" / "stock_list.parquet"
# 阶段3A: 研究池之外的实际持仓 ETF (须人工核对基金合同/招募说明书后登记跟踪指数)
EXTRA_HOLDINGS_PATH = PROJECT_ROOT / "config" / "lookthrough_extra_etfs.json"
# 2026-11-03 (docs/ETF_CONSTITUENT_FIX_PLAN.md C1): 登记表列出实际持仓, 不进 git; 服务器放在持久化目录 data_lake/
# (镜像内的 config/ 每次部署都会被覆盖)。读取顺序: data_lake/ → config/ (本机旧位置)。
DATA_EXTRA_HOLDINGS_PATH = PROJECT_ROOT / "data_lake" / "lookthrough_extra_etfs.json"
SNAPSHOT_SCHEMA_VERSION = 2
EXPOSURE_BASIS = "tracking_index_weight"
EXPOSURE_BASIS_NOTE = ("跟踪指数的官方月度成分权重, 作为 ETF 暴露的近似; 不是基金实际持仓 "
                       "(实际持仓存在跟踪误差、现金与替代成分)")
# 阶段3B-1: 指数权重不可得时的替代来源 — 基金定期报告披露的股票持仓 (Tushare fund_portfolio)
FUND_HOLDINGS_BASIS = "fund_reported_holdings"
FUND_HOLDINGS_NOTE = ("基金定期报告披露的股票持仓 (报告期末时点, 公告有滞后); 权重为占基金股票市值比例; "
                      "季报通常只披露前十大, 未披露部分计为未知")
# 报告期末 + 下一期公告滞后 ≈ 一个季度 + 45 天。这是数据本身的发布节奏, 不是放宽指数权重的 45 天阈值
FUND_HOLDINGS_MAX_AGE_DAYS = 136
_write_lock = threading.Lock()


def _canonical_hash(payload: Any) -> str:
    encoded = json.dumps(
        payload,
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=True,
        allow_nan=False,
    ).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def _iso_date(value: Any) -> str:
    text = str(value or "").strip().replace("-", "")[:8]
    if len(text) != 8 or not text.isdigit():
        raise ValueError(f"invalid date: {value}")
    return datetime.strptime(text, "%Y%m%d").date().isoformat()


def _finite(value: Any) -> float | None:
    if isinstance(value, bool):
        return None
    try:
        number = float(value)
    except (TypeError, ValueError):
        return None
    return number if math.isfinite(number) else None


def build_constituent_snapshot(
    manifest: Mapping[str, Any],
    frames_by_index: Mapping[str, pd.DataFrame],
    *,
    stock_names: Mapping[str, str],
    as_of: Any,
    retrieved_at: str | None = None,
    max_age_days: int,
    top_n: int,
    weight_sum_bounds_pct: tuple[float, float] | list[float] = (95, 105),
    fund_frames_by_etf: Mapping[str, pd.DataFrame] | None = None,
) -> dict:
    """Build a deterministic snapshot from official monthly index weights.

    阶段3B-1: 某 ETF 仅因指数权重不可得而失败时, 若提供了该 ETF 的基金报告持仓,
    改用 fund_reported_holdings 口径 (独立时效规则), 并保留 fallback_from 说明。
    """
    reference_date = date.fromisoformat(_iso_date(as_of))
    lower_weight, upper_weight = map(float, weight_sum_bounds_pct)
    members = manifest.get("members")
    if not isinstance(members, list):
        raise ValueError("industry universe manifest has no members")

    records: list[dict] = []
    for member in members:
        etf_code = str(member.get("code") or "").strip()
        index_code = str(member.get("tracking_index_code") or "").strip()
        issues: list[str] = []
        latest_date: str | None = None
        age_days: int | None = None
        weight_sum: float | None = None
        constituent_count = 0
        verified_top: list[dict] = []
        verified_all: list[dict] = []

        if not etf_code:
            raise ValueError("industry universe contains empty ETF code")
        if not index_code:
            issues.append("TRACKING_INDEX_MISSING")
            frame = pd.DataFrame()
        else:
            frame = frames_by_index.get(index_code, pd.DataFrame())

        required = {"con_code", "trade_date", "weight"}
        if frame is None or frame.empty:
            issues.append("INDEX_WEIGHT_UNAVAILABLE")
        elif not required.issubset(frame.columns):
            issues.append("INDEX_WEIGHT_SCHEMA_INVALID")
        else:
            work = frame[list(required)].copy()
            try:
                work["trade_date_iso"] = work["trade_date"].map(_iso_date)
            except ValueError:
                issues.append("INDEX_WEIGHT_DATE_INVALID")
                work = pd.DataFrame()
            if not work.empty:
                work = work[work["trade_date_iso"] <= reference_date.isoformat()]
            if work.empty and "INDEX_WEIGHT_DATE_INVALID" not in issues:
                issues.append("INDEX_WEIGHT_UNAVAILABLE")
            elif not work.empty:
                latest_date = str(work["trade_date_iso"].max())
                latest = work[work["trade_date_iso"] == latest_date].copy()
                latest["con_code"] = latest["con_code"].astype(str).str.strip()
                latest["weight_num"] = pd.to_numeric(latest["weight"], errors="coerce")
                if latest["con_code"].eq("").any():
                    issues.append("INDEX_CONSTITUENT_CODE_INVALID")
                if latest["con_code"].duplicated().any():
                    issues.append("INDEX_CONSTITUENT_DUPLICATE")
                if latest["weight_num"].isna().any() or (
                    latest["weight_num"] <= 0
                ).any():
                    issues.append("INDEX_WEIGHT_VALUE_INVALID")
                constituent_count = int(len(latest))
                weight_sum_value = _finite(latest["weight_num"].sum())
                weight_sum = (
                    round(weight_sum_value, 4)
                    if weight_sum_value is not None
                    else None
                )
                if constituent_count < max(5, int(top_n)):
                    issues.append("INDEX_CONSTITUENT_COUNT_TOO_SMALL")
                if weight_sum is None or not lower_weight <= weight_sum <= upper_weight:
                    issues.append("INDEX_WEIGHT_SUM_INVALID")
                age_days = (reference_date - date.fromisoformat(latest_date)).days
                if age_days < 0 or age_days > int(max_age_days):
                    issues.append("INDEX_WEIGHT_STALE")

                if not issues:
                    latest = latest.sort_values(
                        ["weight_num", "con_code"], ascending=[False, True]
                    )
                    # 阶段3A: 保留全部可得成分 (原实现只存前 top_n, 无法识别跨 ETF 重复持仓)
                    verified_all = [
                        {
                            "code": row.con_code,
                            "name": str(stock_names.get(row.con_code) or row.con_code),
                            "weight_pct": round(float(row.weight_num), 4),
                        }
                        for row in latest.itertuples(index=False)
                    ]
                    verified_top = verified_all[: int(top_n)]

        issues = list(dict.fromkeys(issues))
        fund_frame = (fund_frames_by_etf or {}).get(etf_code)
        if issues == ["INDEX_WEIGHT_UNAVAILABLE"] and fund_frame is not None:
            records.append(_fund_holdings_record(member, etf_code, index_code, fund_frame,
                                                 reference_date, stock_names, int(top_n)))
            continue
        records.append(
            {
                "etf_code": etf_code,
                "policy_label": str(member.get("name") or ""),
                "instrument_name": str(member.get("instrument_name") or ""),
                "tracking_index_code": index_code,
                "tracking_index_name": str(member.get("tracking_index_name") or ""),
                "is_verified": not issues,
                "as_of": latest_date,
                "age_days": age_days,
                "constituent_count": constituent_count,
                "weight_sum_pct": weight_sum,
                "top_constituents": verified_top if not issues else [],
                "constituents": verified_all if not issues else [],
                "weight_coverage_pct": (round(min(weight_sum, 100.0), 4)
                                        if weight_sum is not None and not issues else None),
                "exposure_basis": EXPOSURE_BASIS,
                "fund_holdings_available": False,
                "membership": str(member.get("membership") or "research_universe"),
                "issues": issues,
            }
        )

    records.sort(key=lambda item: item["etf_code"])
    observed_at = retrieved_at or datetime.now(timezone.utc).isoformat()
    return {
        "schema_version": SNAPSHOT_SCHEMA_VERSION,
        "exposure_basis": EXPOSURE_BASIS,
        "exposure_basis_note": EXPOSURE_BASIS_NOTE,
        "provider": "tushare_pro",
        "dataset": "index_weight",
        "primary_origin": "index company public data",
        "retrieved_at": observed_at,
        "as_of": reference_date.isoformat(),
        "max_age_days": int(max_age_days),
        "top_n": int(top_n),
        "weight_sum_bounds_pct": [lower_weight, upper_weight],
        "record_count": len(records),
        "snapshot_sha256": _canonical_hash(records),
        "records": records,
    }


def _atomic_write_json(path: Path, payload: Mapping[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name(
        f"{path.name}.{os.getpid()}.{threading.get_ident()}.tmp"
    )
    with _write_lock:
        try:
            with temp.open("w", encoding="utf-8", newline="\n") as handle:
                json.dump(payload, handle, ensure_ascii=False, indent=2, allow_nan=False)
                handle.write("\n")
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(temp, path)
        finally:
            if temp.exists():
                temp.unlink()


def _fund_holdings_record(member: Mapping[str, Any], etf_code: str, index_code: str, frame: pd.DataFrame,
                          reference_date: date, stock_names: Mapping[str, str], top_n: int) -> dict:
    """基金报告持仓 → 成分记录。取最新的已公告且通过校验的报告期; 同一报告期同一股票取最新公告。"""
    issues = ["INDEX_WEIGHT_UNAVAILABLE"]          # 保留原因, 便于追溯
    blocking: list[str] = []
    skipped: list[dict] = []
    dropped: dict = {}
    cons: list[dict] = []
    latest_date = ann_date = None
    age_days = coverage = None
    required = {"end_date", "ann_date", "symbol", "stk_mkv_ratio"}
    if frame is None or frame.empty:
        blocking.append("FUND_HOLDINGS_UNAVAILABLE")
    elif not required.issubset(frame.columns):
        blocking.append("FUND_HOLDINGS_SCHEMA_INVALID")
    else:
        w = frame[list(required)].copy()
        try:
            w["end_iso"] = w["end_date"].map(_iso_date)
            w["ann_iso"] = w["ann_date"].map(_iso_date)
        except ValueError:
            blocking.append("FUND_HOLDINGS_DATE_INVALID")
            w = pd.DataFrame()
        if not w.empty:
            # 只用在参考日之前已经公告的报告 (不使用参考日之后才公布的信息)
            w = w[(w["end_iso"] <= reference_date.isoformat()) & (w["ann_iso"] <= reference_date.isoformat())]
        if w.empty and not blocking:
            blocking.append("FUND_HOLDINGS_UNAVAILABLE")
        elif not w.empty:
            # 从最新已公告报告期往前, 取第一个通过校验的报告期; 跳过的期次与原因留痕
            # (新报告刚公告时数据源可能尚未收录完整, 例如只有少数几行)
            for end_iso in sorted(w["end_iso"].unique(), reverse=True):
                cur = (w[w["end_iso"] == end_iso].sort_values("ann_iso")
                       .drop_duplicates("symbol", keep="last"))
                cur = cur.assign(ratio=pd.to_numeric(cur["stk_mkv_ratio"], errors="coerce"))
                period_issues = []
                # 个别行占比缺失/非正: 剔除该行 (其市值计入未知), 不否决整期; 留痕计数
                bad_nan = int(cur["ratio"].isna().sum())
                bad_nonpos = int((cur["ratio"] <= 0).sum())
                rows_total = int(len(cur))
                cur = cur[cur["ratio"] > 0]
                cov = _finite(cur["ratio"].sum())
                cov = round(cov, 4) if cov is not None else None
                if len(cur) < 5:
                    period_issues.append("FUND_HOLDINGS_COUNT_TOO_SMALL")
                if cov is None or not 0 < cov <= 105:
                    period_issues.append("FUND_HOLDINGS_RATIO_SUM_INVALID")
                age = (reference_date - date.fromisoformat(str(end_iso))).days
                if age < 0 or age > FUND_HOLDINGS_MAX_AGE_DAYS:
                    period_issues.append("FUND_HOLDINGS_STALE")
                if period_issues:
                    skipped.append({"end_date": str(end_iso), "rows": rows_total, "valid_rows": int(len(cur)),
                                    "dropped_ratio_missing": bad_nan, "dropped_ratio_nonpositive": bad_nonpos,
                                    "issues": period_issues})
                    if "FUND_HOLDINGS_STALE" in period_issues:
                        break                       # 更早的期次只会更旧
                    continue
                latest_date, ann_date, coverage, age_days = str(end_iso), str(cur["ann_iso"].max()), cov, age
                dropped = {"dropped_ratio_missing": bad_nan, "dropped_ratio_nonpositive": bad_nonpos,
                           "rows_total": rows_total}
                if bad_nan or bad_nonpos:
                    issues.append("FUND_HOLDINGS_ROWS_DROPPED")   # 信息项: 不阻断
                cur = cur.sort_values(["ratio", "symbol"], ascending=[False, True])
                cons = [{"code": str(r.symbol), "name": str(stock_names.get(str(r.symbol)) or r.symbol),
                         "weight_pct": round(float(r.ratio), 4)} for r in cur.itertuples(index=False)]
                break
            if not cons:
                last = skipped[0] if skipped else {"issues": ["FUND_HOLDINGS_UNAVAILABLE"]}
                blocking.extend(last["issues"])
                if skipped:
                    latest_date = skipped[0]["end_date"]
            elif skipped:
                issues.append("FUND_HOLDINGS_NEWER_PERIOD_SKIPPED")   # 信息项: 不阻断
    ok = not blocking
    return {
        "etf_code": etf_code,
        "policy_label": str(member.get("name") or ""),
        "instrument_name": str(member.get("instrument_name") or ""),
        "tracking_index_code": index_code,
        "tracking_index_name": str(member.get("tracking_index_name") or ""),
        "is_verified": ok,
        "as_of": latest_date,
        "reported_ann_date": ann_date,
        "age_days": age_days,
        "max_age_days": FUND_HOLDINGS_MAX_AGE_DAYS,
        "constituent_count": len(cons),
        "weight_sum_pct": coverage,
        "top_constituents": cons[:top_n] if ok else [],
        "constituents": cons if ok else [],
        "weight_coverage_pct": (round(min(coverage, 100.0), 4) if ok and coverage is not None else None),
        "exposure_basis": FUND_HOLDINGS_BASIS,
        "exposure_basis_note": FUND_HOLDINGS_NOTE,
        "fallback_from": "INDEX_WEIGHT_UNAVAILABLE",
        "skipped_periods": skipped,
        "dropped_rows": dropped,
        "fund_holdings_available": ok,
        "membership": str(member.get("membership") or "research_universe"),
        "issues": issues + blocking,
    }


def _unavailable(etf_code: str, issue: str) -> dict:
    return {
        "etf_code": etf_code,
        "is_verified": False,
        "as_of": None,
        "top_constituents": [],
        "issues": [issue],
    }


def get_constituents_for_etf(
    etf_code: str,
    *,
    path: Path | str = SNAPSHOT_PATH,
    as_of: Any | None = None,
) -> dict:
    """Return verified constituents, rechecking integrity and staleness."""
    target = Path(path)
    if not target.exists():
        return _unavailable(etf_code, "CONSTITUENT_SNAPSHOT_MISSING")
    try:
        snapshot = json.loads(target.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return _unavailable(etf_code, "CONSTITUENT_SNAPSHOT_INVALID")
    records = snapshot.get("records")
    if (
        not isinstance(records, list)
        or snapshot.get("record_count") != len(records)
        or snapshot.get("snapshot_sha256") != _canonical_hash(records)
    ):
        return _unavailable(etf_code, "CONSTITUENT_SNAPSHOT_INTEGRITY_FAILED")
    record = next(
        (item for item in records if item.get("etf_code") == etf_code), None
    )
    if not isinstance(record, Mapping):
        return _unavailable(etf_code, "CONSTITUENT_ETF_NOT_FOUND")
    result = dict(record)
    result["top_constituents"] = [
        dict(item) for item in (record.get("top_constituents") or [])
    ]
    result["constituents"] = [dict(item) for item in (record.get("constituents") or [])]
    if snapshot.get("schema_version", 1) < 2 and result.get("is_verified"):
        # 旧版快照只存前 N 大: 未列出的权重视为未知, 不可当作完整成分
        result["constituents_complete"] = False
        result["constituents"] = [dict(item) for item in result["top_constituents"]]
        result["weight_coverage_pct"] = round(sum(float(i.get("weight_pct") or 0) for i in result["constituents"]), 4)
    else:
        result.setdefault("constituents_complete", bool(result["constituents"]))
    if result.get("as_of"):
        current = date.fromisoformat(_iso_date(as_of or date.today().isoformat()))
        age_days = (current - date.fromisoformat(result["as_of"])).days
        result["age_days"] = age_days
        max_age = int(record.get("max_age_days") or snapshot.get("max_age_days", 0))
        stale_issue = "FUND_HOLDINGS_STALE" if record.get("exposure_basis") == FUND_HOLDINGS_BASIS else "INDEX_WEIGHT_STALE"
        if age_days < 0 or age_days > max_age:
            result["is_verified"] = False
            result["top_constituents"] = []
            result["constituents"] = []
            result["issues"] = list(
                dict.fromkeys([*(result.get("issues") or []), stale_issue])
            )
    if result.get("is_verified") is not True:
        result["top_constituents"] = []
        result["constituents"] = []
        result["weight_coverage_pct"] = None
    result["exposure_basis"] = record.get("exposure_basis") or snapshot.get("exposure_basis", EXPOSURE_BASIS)
    result["exposure_basis_note"] = (record.get("exposure_basis_note")
                                     or snapshot.get("exposure_basis_note", EXPOSURE_BASIS_NOTE))
    result["provider"] = snapshot.get("provider")
    result["dataset"] = snapshot.get("dataset")
    result["retrieved_at"] = snapshot.get("retrieved_at")
    return result


def get_industry_constituent_status(
    *, path: Path | str = SNAPSHOT_PATH, as_of: Any | None = None
) -> dict:
    """Summarize current verified coverage without exposing stale weights."""
    target = Path(path)
    if not target.exists():
        return {
            "integrity_ok": False,
            "record_count": 0,
            "verified_count": 0,
            "reasons": ["CONSTITUENT_SNAPSHOT_MISSING"],
        }
    try:
        snapshot = json.loads(target.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {
            "integrity_ok": False,
            "record_count": 0,
            "verified_count": 0,
            "reasons": ["CONSTITUENT_SNAPSHOT_INVALID"],
        }
    records = snapshot.get("records")
    integrity_ok = bool(
        isinstance(records, list)
        and snapshot.get("record_count") == len(records)
        and snapshot.get("snapshot_sha256") == _canonical_hash(records)
    )
    if not integrity_ok:
        return {
            "integrity_ok": False,
            "record_count": len(records) if isinstance(records, list) else 0,
            "verified_count": 0,
            "reasons": ["CONSTITUENT_SNAPSHOT_INTEGRITY_FAILED"],
        }
    results = [
        get_constituents_for_etf(
            str(record.get("etf_code") or ""), path=target, as_of=as_of
        )
        for record in records
    ]
    return {
        "integrity_ok": True,
        "record_count": len(results),
        "verified_count": sum(item.get("is_verified") is True for item in results),
        "unverified_count": sum(item.get("is_verified") is not True for item in results),
        "as_of": snapshot.get("as_of"),
        "retrieved_at": snapshot.get("retrieved_at"),
        "snapshot_sha256": snapshot.get("snapshot_sha256"),
        "records": results,
        "reasons": [],
    }


def extra_holdings_path() -> Path:
    """登记表实际读取位置: data_lake/ 存在则用它, 否则 config/。调用时解析 (测试可 monkeypatch 两个常量)。"""
    data = Path(DATA_EXTRA_HOLDINGS_PATH)
    return data if data.exists() else Path(EXTRA_HOLDINGS_PATH)


def extra_holdings_info(path: Path | str | None = None) -> dict:
    """登记表元信息 (审计页显示, 便于比对本机与服务器): 位置、修改时间、内容指纹、登记的 ETF。不含持仓数量或金额。"""
    target = Path(path) if path is not None else extra_holdings_path()
    info: dict[str, Any] = {"path": str(target.relative_to(PROJECT_ROOT)) if target.is_relative_to(PROJECT_ROOT) else str(target),
                            "exists": target.exists()}
    if not target.exists():
        return {**info, "status": "missing", "members": [], "valid_count": 0}
    try:
        raw = target.read_bytes()
        members = json.loads(raw.decode("utf-8")).get("members") or []
    except (OSError, ValueError) as exc:
        return {**info, "status": "invalid", "error": str(exc)[:120], "members": [], "valid_count": 0}
    valid = [m for m in members if str(m.get("code") or "").strip() and m.get("tracking_index_code") and m.get("source")]
    return {**info, "status": "ok",
            "modified_at": datetime.fromtimestamp(target.stat().st_mtime).isoformat(timespec="minutes"),
            "sha256": hashlib.sha256(raw).hexdigest()[:12],
            "members": sorted(str(m.get("code")).strip() for m in valid),
            "valid_count": len(valid), "ignored_count": len(members) - len(valid)}


def _with_extra_holdings(members: list, path: Path | str | None = None) -> list:
    """研究池成员 + 人工登记的持仓 ETF (不改动冻结的研究池清单)。路径在调用时解析, 便于测试隔离。"""
    out = [dict(m, membership="research_universe") for m in members]
    seen = {str(m.get("code") or "").strip() for m in members}
    target = Path(path) if path is not None else extra_holdings_path()
    if not target.exists():
        return out
    try:
        extra = json.loads(target.read_text(encoding="utf-8")).get("members") or []
    except (OSError, json.JSONDecodeError):
        return out
    for m in extra:
        code = str(m.get("code") or "").strip()
        if code and code not in seen and m.get("tracking_index_code") and m.get("source"):
            out.append({"code": code, "name": m.get("name") or code,
                        "instrument_name": m.get("instrument_name") or "",
                        "tracking_index_code": m["tracking_index_code"],
                        "tracking_index_name": m.get("tracking_index_name") or "",
                        "membership": "holding_extra"})
            seen.add(code)
    return out


def refresh_industry_constituents(
    *,
    manifest_path: Path | str = MANIFEST_PATH,
    output_path: Path | str = SNAPSHOT_PATH,
    stock_list_path: Path | str = STOCK_LIST_PATH,
    client: Any = None,
    as_of: Any | None = None,
    retrieved_at: str | None = None,
) -> dict:
    """Fetch official monthly weights for every frozen core ETF tracking index."""
    manifest = json.loads(Path(manifest_path).read_text(encoding="utf-8"))
    manifest = {**manifest, "members": _with_extra_holdings(manifest.get("members") or [])}
    rules = get_industry_execution_rules()
    reference_date = date.fromisoformat(_iso_date(as_of or date.today().isoformat()))
    if client is None:
        import tushare as ts
        from config import TUSHARE_TOKEN

        ts.set_token(TUSHARE_TOKEN)
        client = ts.pro_api()

    index_codes = sorted(
        {
            str(member.get("tracking_index_code") or "").strip()
            for member in manifest.get("members", [])
            if str(member.get("tracking_index_code") or "").strip()
        }
    )
    start_date = (reference_date - timedelta(days=150)).strftime("%Y%m%d")
    end_date = reference_date.strftime("%Y%m%d")
    frames: dict[str, pd.DataFrame] = {}
    for index_code in index_codes:
        try:
            frame = client.index_weight(
                index_code=index_code,
                start_date=start_date,
                end_date=end_date,
            )
            frames[index_code] = frame if isinstance(frame, pd.DataFrame) else pd.DataFrame()
        except Exception:
            frames[index_code] = pd.DataFrame()

    # 阶段3B-1: 指数权重缺失的 ETF 改取基金报告持仓 (近 400 天, 覆盖年报/半年报/季报)
    fund_frames: dict[str, pd.DataFrame] = {}
    for member in manifest.get("members", []):
        idx = str(member.get("tracking_index_code") or "").strip()
        code = str(member.get("code") or "").strip()
        if code and (not idx or frames.get(idx) is None or frames.get(idx).empty):
            try:
                ff = client.fund_portfolio(
                    ts_code=code,
                    start_date=(reference_date - timedelta(days=400)).strftime("%Y%m%d"),
                    end_date=end_date,
                )
                fund_frames[code] = ff if isinstance(ff, pd.DataFrame) else pd.DataFrame()
            except Exception:
                fund_frames[code] = pd.DataFrame()

    stock_names: dict[str, str] = {}
    stock_path = Path(stock_list_path)
    if stock_path.exists():
        try:
            stocks = pd.read_parquet(stock_path, columns=["ts_code", "name"])  # noqa: E501
            stock_names = {
                str(row.ts_code): str(row.name)
                for row in stocks.itertuples(index=False)
                if row.ts_code and row.name
            }
        except Exception:
            stock_names = {}

    snapshot = build_constituent_snapshot(
        manifest,
        frames,
        stock_names=stock_names,
        as_of=reference_date.isoformat(),
        retrieved_at=retrieved_at,
        max_age_days=int(rules["constituent_max_age_days"]),
        top_n=int(rules["constituent_top_n"]),
        weight_sum_bounds_pct=rules["constituent_weight_sum_bounds_pct"],
        fund_frames_by_etf=fund_frames,
    )
    _atomic_write_json(Path(output_path), snapshot)
    return snapshot


# ═══════════════════════════════════════════════════════
#  2026-11-03 C1: 按需刷新 (每个交易日 08:40 检查; 周六全量刷新保留)
# ═══════════════════════════════════════════════════════
REFRESH_MAX_RETRIEVED_AGE_DAYS = 7     # 快照获取超过 7 天 → 刷新
REFRESH_EXPIRY_MARGIN_DAYS = 10        # 任一持仓 ETF 权重距过期 ≤ 10 天 → 刷新


def _held_etf_codes(store_path: Path | str | None = None) -> list[str]:
    path = Path(store_path) if store_path is not None else PROJECT_ROOT / "data_lake" / "portfolio_store.json"
    try:
        positions = (json.loads(path.read_text(encoding="utf-8")) or {}).get("positions") or {}
    except (OSError, ValueError):
        return []
    from services.concentration import _is_etf
    return sorted(c for c in positions if _is_etf(c))


def constituent_refresh_reasons(*, path: Path | str = SNAPSHOT_PATH, held: list[str] | None = None,
                                as_of: Any | None = None) -> list[str]:
    """是否需要刷新成分快照 → 原因列表 (空 = 不需要)。只读。"""
    target = Path(path)
    today = date.fromisoformat(_iso_date(as_of or date.today().isoformat()))
    held = _held_etf_codes() if held is None else held
    if not target.exists():
        return ["SNAPSHOT_MISSING"]
    try:
        snapshot = json.loads(target.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return ["SNAPSHOT_INVALID"]
    reasons = []
    try:
        retrieved = datetime.fromisoformat(str(snapshot.get("retrieved_at")).replace("Z", "+00:00")).date()
        if (today - retrieved).days > REFRESH_MAX_RETRIEVED_AGE_DAYS:
            reasons.append(f"RETRIEVED_{(today - retrieved).days}D_AGO")
    except (TypeError, ValueError):
        reasons.append("RETRIEVED_AT_UNKNOWN")
    for code in held:
        rec = get_constituents_for_etf(code, path=target, as_of=today.isoformat())
        if rec.get("is_verified") is not True:
            reasons.append(f"{code}:{'|'.join(rec.get('issues') or ['UNVERIFIED'])}")
            continue
        max_age = int(rec.get("max_age_days") or snapshot.get("max_age_days") or 0)
        if rec.get("age_days") is not None and max_age and max_age - int(rec["age_days"]) <= REFRESH_EXPIRY_MARGIN_DAYS:
            reasons.append(f"{code}:EXPIRES_IN_{max_age - int(rec['age_days'])}D")
    return reasons


def refresh_constituents_if_needed(**kwargs) -> dict:
    """每个交易日检查一次; 需要时刷新 (失败抛异常, 由定时任务记录)。"""
    reasons = constituent_refresh_reasons()
    if not reasons:
        return {"refreshed": False, "reasons": []}
    snap = refresh_industry_constituents(**kwargs)
    return {"refreshed": True, "reasons": reasons, "as_of": snap.get("as_of"),
            "record_count": snap.get("record_count")}


def constituent_health(*, path: Path | str = SNAPSHOT_PATH, held: list[str] | None = None,
                       as_of: Any | None = None) -> dict:
    """审计页读数: 快照获取时间、持仓 ETF 的权重日期 / 是否可穿透、登记表元信息。只读。"""
    target = Path(path)
    held = _held_etf_codes() if held is None else held
    today = as_of or date.today().isoformat()
    snapshot = {}
    try:
        snapshot = json.loads(target.read_text(encoding="utf-8")) if target.exists() else {}
    except (OSError, ValueError):
        snapshot = {}
    etfs = []
    for code in held:
        rec = get_constituents_for_etf(code, path=target, as_of=today)
        max_age = int(rec.get("max_age_days") or snapshot.get("max_age_days") or 0) or None
        etfs.append({"ts_code": code, "verified": rec.get("is_verified") is True, "weights_as_of": rec.get("as_of"),
                     "age_days": rec.get("age_days"), "max_age_days": max_age,
                     "days_left": (max_age - int(rec["age_days"])) if (max_age and rec.get("age_days") is not None) else None,
                     "issues": rec.get("issues") or []})
    return {"retrieved_at": snapshot.get("retrieved_at"), "snapshot_as_of": snapshot.get("as_of"),
            "record_count": snapshot.get("record_count"), "held_etfs": etfs,
            "name_fallback": [e["ts_code"] for e in etfs if not e["verified"]],
            "refresh_reasons": constituent_refresh_reasons(path=target, held=held, as_of=today),
            "registry": extra_holdings_info()}

