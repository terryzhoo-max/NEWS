"""定时任务与外部 AI 服务开关 (2026-11-04)。

唯一配置: config/job_switches.json (进 git, 不含密钥)。
  · jobs.<id>.enabled=false → 任务到点不运行 (services.job_runs.tracked 在调用前检查)。
    关键任务 (job_runs.CRITICAL_JOBS) 也可以被暂停, 但审计页 A 区为警告、看门狗按逾期推送, 不当作正常状态。
  · ai_services.enabled=false → 不调用任何大模型: 日报用规则模板, NLP 扫描 / AI 助手返回"已暂停"。
未列出 = 开启; 文件缺失或损坏 = 全部开启 (暂停是例外, 配置故障不能让任务悄悄停掉)。
"""
from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Optional

logger = logging.getLogger("alphacore.job_switches")

CONFIG_PATH = Path(__file__).resolve().parent.parent / "config" / "job_switches.json"
DEFAULT_AI_PAUSED_MESSAGE = "AI 服务暂停"


def load_switches(path=None) -> dict:
    p = Path(path) if path else CONFIG_PATH
    try:
        data = json.loads(p.read_text(encoding="utf-8"))
        if not isinstance(data, dict):
            raise ValueError("顶层必须是对象")
        jobs = data.get("jobs") or {}
        ai = data.get("ai_services") or {}
        if not isinstance(jobs, dict) or not isinstance(ai, dict):
            raise ValueError("jobs / ai_services 必须是对象")
        return {"jobs": jobs, "ai_services": ai}
    except FileNotFoundError:
        return {"jobs": {}, "ai_services": {}}
    except Exception as e:  # noqa: BLE001
        logger.warning("job_switches.json 读取失败, 全部按开启处理: %s", e)
        return {"jobs": {}, "ai_services": {}, "error": str(e)[:200]}


def _paused_info(item) -> Optional[dict]:
    if isinstance(item, dict) and item.get("enabled") is False:
        return {"reason": str(item.get("reason") or ""), "paused_on": item.get("paused_on")}
    return None


def job_paused(job_id: str, path=None) -> Optional[dict]:
    """任务被暂停 → {"reason", "paused_on"}; 否则 None。"""
    return _paused_info(load_switches(path)["jobs"].get(job_id))


def paused_jobs(path=None) -> dict:
    return {k: v for k, v in ((k, _paused_info(item)) for k, item in load_switches(path)["jobs"].items()) if v}


def ai_paused(path=None) -> Optional[dict]:
    """外部 AI 服务被暂停 → {"reason", "paused_on", "message"}; 否则 None。"""
    ai = load_switches(path)["ai_services"]
    info = _paused_info(ai)
    if info is None:
        return None
    return {**info, "message": str(ai.get("message") or DEFAULT_AI_PAUSED_MESSAGE)}
