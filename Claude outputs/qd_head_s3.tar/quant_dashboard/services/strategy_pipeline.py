"""
AlphaCore · 策略 CI/CD 管道 V2.0 (P1-3 + V5 自检)
==========================================
触发: APScheduler 月度任务 / 手动 API 调用
流程:
  1. 从 config/strategy_runtime.json 读取当前生产参数
  2. 运行参数优化 (复用已有优化器)
  3. 用新参数跑回测, 获取 KPI
  4. 质量门检查 (Quality Gate)
  5. A/B 对比 (新参数 vs 旧参数)
  6. 决策: ACCEPT / REJECT / REVIEW
  7. 评估结果归档到 SQLite ci_runs 表
第 0 轮 0a-1 (2026-11-05, docs/ROUND0_CI_EVALUATE_ONLY_PLAN.md 3.1 / 3.2): 只评估不发布。
  - 流水线不再调用参数发布函数, 服务器进程不改 config/strategy_runtime.json 的参数
  - ACCEPT / REVALIDATED / REVIEW 记为待人工批准 (approval_status=PENDING), 其余 NOT_APPLICABLE;
    批准后参数经仓库提交、推送部署生效
  - 每条记录带触发来源 (scheduler / api / direct) 与 batch_id; SKIPPED / DISABLED / ERROR 也落库
第 0 轮 0a-2: REJECT / INSUFFICIENT_EVIDENCE 的 lifecycle 记到 data_lake/strategy_state/mr_lifecycle.json,
  服务器进程不再写 config/strategy_runtime.json
"""

import json
import os
import socket
import sys
import threading
import uuid
import gc
import traceback
from datetime import datetime
from typing import Dict, Mapping, Optional

from services.logger import get_logger
from services import db as ac_db
from services.strategy_params import (
    get_all_mr_params,
    get_erp_params,
    get_mr_params,
    record_ci_outcome,
)
from services.mr_validation import (
    compare_regime,
    run_frozen_oos_validation,
)

logger = get_logger("ci.pipeline")

# ── 质量门阈值 ──
QUALITY_GATE = {
    "sharpe_min":       0.5,       # Sharpe ≥ 0.5 (生产最低线)
    "max_dd_ceil":      -25.0,     # MaxDD ≤ -25% (百分比)
    "calmar_min":       0.3,       # Calmar ≥ 0.3
    "coverage_min":     15.0,      # 信号覆盖率 ≥ 15%
    "regression_tol":   0.10,      # 回归容忍: Sharpe 下降不超过 10%
    "min_trades":       5,         # 最少交易轮次
}

# 参数文件路径
MR_PARAMS_FILE = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
    "mr_per_regime_params.json"
)
ERP_PARAMS_FILE = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
    "erp_optimization_results.json"
)


def _load_json_safe(path: str) -> dict:
    """安全加载 JSON, 文件不存在返回空 dict"""
    if not os.path.exists(path):
        return {}
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def _check_quality_gate(metrics: dict) -> list:
    """
    对回测指标执行质量门检查
    返回: [{rule, expected, actual, passed}]
    """
    checks = []

    # Sharpe
    sharpe = metrics.get("sharpe", metrics.get("sharpe_ratio", 0))
    checks.append({
        "rule": "Sharpe ≥ {:.1f}".format(QUALITY_GATE["sharpe_min"]),
        "expected": QUALITY_GATE["sharpe_min"],
        "actual": round(sharpe, 3),
        "passed": sharpe >= QUALITY_GATE["sharpe_min"],
    })

    # MaxDD
    max_dd = metrics.get("max_dd", metrics.get("max_drawdown", 0))
    # 统一为百分比 (可能是小数或百分比)
    if isinstance(max_dd, (int, float)) and abs(max_dd) < 1:
        max_dd = max_dd * 100  # 小数 → 百分比
    checks.append({
        "rule": "MaxDD ≥ {:.0f}%".format(QUALITY_GATE["max_dd_ceil"]),
        "expected": QUALITY_GATE["max_dd_ceil"],
        "actual": round(max_dd, 2),
        "passed": max_dd >= QUALITY_GATE["max_dd_ceil"],
    })

    # Calmar
    calmar = metrics.get("calmar", metrics.get("calmar_ratio", 0))
    checks.append({
        "rule": "Calmar ≥ {:.1f}".format(QUALITY_GATE["calmar_min"]),
        "expected": QUALITY_GATE["calmar_min"],
        "actual": round(calmar, 3),
        "passed": calmar >= QUALITY_GATE["calmar_min"],
    })

    # Coverage (仅 MR 策略)
    coverage = metrics.get("coverage", 100)
    if coverage < 100:
        checks.append({
            "rule": "Coverage ≥ {:.0f}%".format(QUALITY_GATE["coverage_min"]),
            "expected": QUALITY_GATE["coverage_min"],
            "actual": round(coverage, 1),
            "passed": coverage >= QUALITY_GATE["coverage_min"],
        })

    # 优化器返回交易次数时必须执行最小样本门，避免零交易参数被 Sharpe 误放行。
    trade_count = metrics.get("total_trades", metrics.get("trades"))
    if trade_count is not None:
        checks.append({
            "rule": "Trades ≥ {}".format(QUALITY_GATE["min_trades"]),
            "expected": QUALITY_GATE["min_trades"],
            "actual": trade_count,
            "passed": trade_count >= QUALITY_GATE["min_trades"],
        })

    return checks


def _compute_ab_decision(old_metrics: dict, new_metrics: dict, gate_results: list) -> str:
    """
    根据质量门 + A/B 对比判定:
    - ACCEPT: 所有质量门通过 + 新参数不劣于旧参数
    - REJECT: 有质量门失败 或 显著退步
    - REVIEW: 边界情况, 需人工审查
    """
    gate_passed = all(g["passed"] for g in gate_results)

    if not gate_passed:
        # 有质量门未通过
        return "REJECT"

    old_sharpe = old_metrics.get("sharpe", old_metrics.get("sharpe_ratio", 0))
    new_sharpe = new_metrics.get("sharpe", new_metrics.get("sharpe_ratio", 0))

    if old_sharpe > 0:
        regression = (old_sharpe - new_sharpe) / old_sharpe
        if regression > QUALITY_GATE["regression_tol"]:
            # 新参数 Sharpe 下降超过容忍度
            return "REJECT"
        elif regression > 0:
            # 轻微下降, 需要人工确认
            return "REVIEW"

    # 新参数不差于旧参数, 且质量门全通过
    return "ACCEPT"


def _build_diff_summary(strategy: str, old_params: dict, new_params: dict) -> str:
    """生成人可读的参数变更摘要"""
    lines = [f"策略: {strategy}", "参数变更:"]
    all_keys = sorted(set(list(old_params.keys()) + list(new_params.keys())))
    changed = 0
    for k in all_keys:
        old_v = old_params.get(k, "N/A")
        new_v = new_params.get(k, "N/A")
        if old_v != new_v:
            lines.append(f"  {k}: {old_v} → {new_v}")
            changed += 1

    if changed == 0:
        lines.append("  (无变更)")
    else:
        lines.append(f"共 {changed} 项变更")
    return "\n".join(lines)


# ── 第 0 轮 0a-1: 只评估不发布 + 批准状态 ──
PENDING_STATUSES = frozenset({"ACCEPT", "REVALIDATED", "REVIEW"})
PENDING_NOTE = "待人工批准（批准后经仓库提交生效）"
# ci_runs.validation 的结构版本。0a-3 批准时只认带 schema_version 的验证记录;
# 迁移前的旧记录 validation 为空, 一律拒绝批准 (不当作通过)
CI_VALIDATION_SCHEMA_VERSION = 1
TRIGGER_SOURCES = ("scheduler", "api", "direct")
_PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def _mark_approval(ci_run: dict) -> dict:
    """ACCEPT / REVALIDATED / REVIEW → PENDING (diff_summary 末尾注明); 其余 → NOT_APPLICABLE。"""
    if ci_run.get("status") in PENDING_STATUSES:
        ci_run["approval_status"] = "PENDING"
        summary = ci_run.get("diff_summary") or ""
        if PENDING_NOTE not in summary:
            ci_run["diff_summary"] = (summary + "\n" if summary else "") + PENDING_NOTE
    else:
        ci_run["approval_status"] = "NOT_APPLICABLE"
    return ci_run


def _short_path(path: str) -> str:
    full = os.path.abspath(path)
    if os.path.normcase(full).startswith(os.path.normcase(_PROJECT_ROOT) + os.sep):
        return os.path.relpath(full, _PROJECT_ROOT).replace(os.sep, "/")
    return full


def _external_caller() -> Optional[str]:
    """调用栈里流水线之外最近的一帧: 文件:行号 函数名。"""
    here = os.path.normcase(os.path.abspath(__file__))
    frame = sys._getframe(1)
    while frame is not None:
        code = frame.f_code
        if os.path.normcase(os.path.abspath(code.co_filename)) != here:
            return f"{_short_path(code.co_filename)}:{frame.f_lineno} {code.co_name}"
        frame = frame.f_back
    return None


def resolve_trigger(trigger: Optional[Mapping] = None) -> dict:
    """规范化触发来源 {source, detail, reason, batch_id}; 同一次调用里的各状态共用 batch_id。

    没传 trigger 一律记为 direct, 打 WARNING, 并记主机名 / pid / argv / 线程名 / 流水线之外最近的调用位置。
    """
    if trigger is None:
        detail = {
            "host": socket.gethostname(),
            "pid": os.getpid(),
            "argv": [str(a)[:200] for a in sys.argv[:10]],
            "thread": threading.current_thread().name,
            "caller": _external_caller(),
        }
        logger.warning("[CI] CI 直接调用（非定时 / 非接口）: caller=%s pid=%s thread=%s argv=%s",
                       detail["caller"], detail["pid"], detail["thread"], detail["argv"])
        resolved = {"source": "direct", "detail": detail, "reason": None}
    else:
        if not isinstance(trigger, Mapping):
            raise TypeError(f"CI trigger 须为 dict, 实际: {type(trigger).__name__}")
        source = trigger.get("source")
        if source not in TRIGGER_SOURCES:
            raise ValueError(f"未知 CI 触发来源: {source!r} (允许: {', '.join(TRIGGER_SOURCES)})")
        resolved = {
            "source": source,
            "detail": dict(trigger.get("detail") or {}),
            "reason": trigger.get("reason"),
        }
    resolved["batch_id"] = (trigger or {}).get("batch_id") or uuid.uuid4().hex[:12]
    return resolved


def scheduler_trigger(job_id: str, schedule=None, now: Optional[datetime] = None) -> dict:
    """定时任务回调用的触发来源: 任务名、标签、应运行时间 (调度规则下 ≤ now 的最近一次)。"""
    from services.job_runs import JOB_LABELS, previous_fire
    detail = {"job_id": job_id, "job_label": JOB_LABELS.get(job_id, job_id), "scheduled_at": None}
    if schedule is not None:
        try:
            tz = getattr(schedule, "timezone", None)
            cur = now or (datetime.now(tz) if tz is not None else datetime.now().astimezone())
            due = previous_fire(schedule, cur)
            detail["scheduled_at"] = due.isoformat() if due else None
        except Exception as e:  # noqa: BLE001 — 应运行时间算不出不影响任务本身
            detail["scheduled_at_error"] = f"{type(e).__name__}: {e}"
    detail["started_at"] = (now or datetime.now().astimezone()).isoformat()
    return {"source": "scheduler", "detail": detail}


def _stamp(ci_run: dict, trig: dict) -> dict:
    """写入触发来源与批准状态 (落库前调用)。"""
    ci_run["trigger_source"] = trig["source"]
    ci_run["trigger_detail"] = trig["detail"]
    ci_run["batch_id"] = trig["batch_id"]
    ci_run["reason"] = trig.get("reason")
    return _mark_approval(ci_run)


def _blank_run(run_id: str, strategy: str, regime, status: str, summary: str, quality_gate=None) -> dict:
    return {
        "run_id": run_id, "strategy": strategy, "regime": regime, "status": status,
        "old_params": {}, "new_params": {}, "old_metrics": {}, "new_metrics": {},
        "quality_gate": quality_gate or [],
        "diff_summary": summary,
    }


def _save_safely(ci_run: dict, label: str) -> None:
    try:
        ac_db.save_ci_run(ci_run)
    except Exception as persist_error:
        logger.error("[CI] %s 记录持久化失败: %s", label, persist_error, exc_info=True)


# ═══════════════════════════════════════════════════════════
#  MR 均值回归 CI (三态分别优化)
# ═══════════════════════════════════════════════════════════

def run_mr_ci(
    regime: str = None,
    *,
    dry_run: bool = False,
    price_dir: str | os.PathLike | None = None,
    trigger: Optional[Mapping] = None,
) -> list:
    """
    运行 MR 策略 CI (只评估不发布)
    如果 regime 为 None, 则全部三态都跑
    trigger: 触发来源 {source, detail, reason[, batch_id]}; 不传记为 direct
    返回: [ci_run_dict, ...]
    """
    trig = resolve_trigger(trigger)
    results = []
    if not dry_run:
        ac_db.init_db()
    regimes_to_run = [regime] if regime else ["BEAR", "RANGE", "BULL"]

    for r in regimes_to_run:
        run_id = str(uuid.uuid4())[:12]
        logger.info("[CI] MR-%s 开始优化 (run_id=%s)", r, run_id)

        try:
            # 读取旧参数
            old_params = get_mr_params(r)

            # 调用已有优化器 (内存安全)
            from strategies.mr_per_regime_optimizer import (
                optimize_regime, REGIME_PERIODS, REGIME_GRIDS
            )

            if r not in REGIME_PERIODS:
                logger.warning("[CI] MR-%s: 无对应 REGIME_PERIODS, 跳过", r)
                ci_run = _stamp(_blank_run(run_id, "mr", r, "SKIPPED",
                                           f"跳过: MR-{r} 无对应 REGIME_PERIODS, 未运行优化"), trig)
                ci_run["dry_run"] = bool(dry_run)
                if not dry_run:
                    ac_db.save_ci_run(ci_run)
                results.append(ci_run)
                continue

            new_result = optimize_regime(
                r,
                REGIME_PERIODS[r],
                REGIME_GRIDS[r],
                price_dir=price_dir,
            )
            gc.collect()  # 释放回测 DataFrame

            if not new_result:
                logger.warning("[CI] MR-%s: 优化器返回空结果", r)
                ci_run = _stamp(_blank_run(run_id, "mr", r, "SKIPPED",
                                           f"跳过: MR-{r} 优化器返回空结果"), trig)
                ci_run["dry_run"] = bool(dry_run)
                if not dry_run:
                    ac_db.save_ci_run(ci_run)
                results.append(ci_run)
                continue

            new_params = new_result.get("params", {})
            incumbent_params = get_all_mr_params()
            challenger_params = {
                state: dict(params)
                for state, params in incumbent_params.items()
            }
            challenger_params[r] = dict(new_params)
            validation_kwargs = {
                "incumbent": incumbent_params,
                "challenger": challenger_params,
            }
            if price_dir is not None:
                validation_kwargs["price_dir"] = price_dir
            validation_result = run_frozen_oos_validation(
                **validation_kwargs,
            )
            old_kpi = validation_result["incumbent"]["by_regime"][r]
            new_kpi = validation_result["challenger"]["by_regime"][r]
            comparison = compare_regime(old_kpi, new_kpi)
            status = {
                "ACCEPT_CHALLENGER": "ACCEPT",
                "REVALIDATE_INCUMBENT": "REVALIDATED",
                "INSUFFICIENT_EVIDENCE": "INSUFFICIENT_EVIDENCE",
                "REJECT": "REJECT",
            }[comparison["decision"]]
            gate_results = _check_quality_gate(new_kpi)

            ci_run = {
                "run_id": run_id,
                "strategy": "mr",
                "regime": r,
                "status": status,
                "old_params": old_params,
                "new_params": new_params,
                "old_metrics": old_kpi,
                "new_metrics": new_kpi,
                "quality_gate": gate_results,
                "diff_summary": _build_diff_summary(f"MR-{r}", old_params, new_params),
                "dry_run": bool(dry_run),
                "validation": {
                    "schema_version": CI_VALIDATION_SCHEMA_VERSION,
                    "method": "frozen_oos",
                    "oos_start": validation_result["oos_start"],
                    "data_through": validation_result["data_through"],
                    "decision": comparison["decision"],
                    "reason": comparison["reason"],
                    "incumbent": old_kpi,
                    "challenger": new_kpi,
                },
            }

            _stamp(ci_run, trig)
            if not dry_run:
                # 第 0 轮 0a-1: 不发布参数; ACCEPT / REVALIDATED 只记为待人工批准
                if ci_run.get("status") in ("INSUFFICIENT_EVIDENCE", "REJECT"):
                    try:
                        record_ci_outcome(ci_run)
                        logger.info(
                            "[CI] MR-%s lifecycle recorded (data_lake): %s",
                            r, ci_run["status"],
                        )
                    except Exception as rec_err:
                        logger.error(
                            "[CI] MR-%s lifecycle record failed: %s",
                            r, rec_err, exc_info=True,
                        )
                ac_db.save_ci_run(ci_run)
            results.append(ci_run)
            logger.info("[CI] MR-%s 完成: status=%s, sharpe=%.3f",
                        r, ci_run["status"], new_kpi.get("sharpe", 0))

        except Exception as e:
            logger.error("[CI] MR-%s 失败: %s\n%s", r, e, traceback.format_exc())
            ci_run = {
                "run_id": run_id,
                "strategy": "mr",
                "regime": r,
                "status": "ERROR",
                "old_params": {},
                "new_params": {},
                "old_metrics": {},
                "new_metrics": {},
                "quality_gate": [{"rule": "执行", "passed": False, "actual": str(e)}],
                "diff_summary": f"CI 执行异常: {e}",
            }
            _stamp(ci_run, trig)
            if not dry_run:
                try:
                    ac_db.save_ci_run(ci_run)
                except Exception as persist_error:
                    logger.error(
                        "[CI] MR-%s 错误记录持久化失败: %s",
                        r,
                        persist_error,
                        exc_info=True,
                    )
            results.append(ci_run)

    return results


# ═══════════════════════════════════════════════════════════
#  ERP 择时 CI
# ═══════════════════════════════════════════════════════════

def run_erp_ci(*, trigger: Optional[Mapping] = None) -> dict:
    """运行 ERP 策略 CI (只评估不发布; 停用时也落一条 DISABLED 记录)"""
    trig = resolve_trigger(trigger)
    run_id = str(uuid.uuid4())[:12]
    try:
        ac_db.init_db()      # 建表与 ci_runs 迁移 (幂等); DISABLED / ERROR 也要落库
    except Exception as e:
        logger.error("[CI] ERP: 数据库初始化失败: %s", e, exc_info=True)
    # 2026-10-24: ERP 自动调参发布默认停用 (见 engines/erp_params.ERP_CI_AUTO_OPTIMIZE)
    try:
        from engines import erp_params as _ep
        _auto = bool(getattr(_ep, "ERP_CI_AUTO_OPTIMIZE", True))
    except Exception:
        _auto = True
    if not _auto:
        logger.info("[CI] ERP 自动调参已停用 (ERP_CI_AUTO_OPTIMIZE=False), 跳过, 参数保持不变")
        ci_run = _stamp(_blank_run(
            run_id, "erp", None, "DISABLED",
            "ERP 自动调参已停用: 优化器与实盘信号不一致且样本外参与选参, "
            "见 docs/ERP_VALIDATION_STEP3_CONCLUSIONS.md"), trig)
        _save_safely(ci_run, "ERP 停用")
        return ci_run
    logger.info("[CI] ERP 开始优化 (run_id=%s)", run_id)

    try:
        old_data = _load_json_safe(ERP_PARAMS_FILE)
        old_params = get_erp_params()
        old_kpi = old_data.get("best_out_sample", old_data.get("best_in_sample", {}))

        # 调用 ERP 优化器
        from strategies.erp_backtest_optimizer import run_optimization
        new_result = run_optimization(persist_results=False)
        gc.collect()

        if not new_result:
            logger.warning("[CI] ERP: 优化器返回空结果")
            ci_run = _stamp(_blank_run(
                run_id, "erp", None, "ERROR", "CI 执行异常: ERP 优化器返回空结果",
                quality_gate=[{"rule": "执行", "passed": False, "actual": "优化器返回空结果"}]), trig)
            ac_db.save_ci_run(ci_run)
            return ci_run

        new_params = new_result.get("best_params", {})
        new_kpi = new_result.get("best_out_sample", new_result.get("best_in_sample", {}))

        gate_results = _check_quality_gate(new_kpi)
        status = _compute_ab_decision(old_kpi, new_kpi, gate_results)

        ci_run = {
            "run_id": run_id,
            "strategy": "erp",
            "regime": None,
            "status": status,
            "old_params": old_params,
            "new_params": new_params,
            "old_metrics": old_kpi,
            "new_metrics": new_kpi,
            "quality_gate": gate_results,
            "diff_summary": _build_diff_summary("ERP", old_params, new_params),
        }

        _stamp(ci_run, trig)      # 第 0 轮 0a-1: 不发布参数; ACCEPT / REVIEW 只记为待人工批准
        ac_db.save_ci_run(ci_run)
        logger.info("[CI] ERP 完成: status=%s", ci_run["status"])
        return ci_run

    except Exception as e:
        logger.error("[CI] ERP 失败: %s\n%s", e, traceback.format_exc())
        ci_run = {
            "run_id": run_id,
            "strategy": "erp",
            "regime": None,
            "status": "ERROR",
            "old_params": {},
            "new_params": {},
            "old_metrics": {},
            "new_metrics": {},
            "quality_gate": [{"rule": "执行", "passed": False, "actual": str(e)}],
            "diff_summary": f"CI 执行异常: {e}",
        }
        _stamp(ci_run, trig)
        _save_safely(ci_run, "ERP 错误")
        return ci_run


# ═══════════════════════════════════════════════════════════
#  全策略 CI 入口 (月度定时任务调用)
# ═══════════════════════════════════════════════════════════

def _phase_error_run(strategy: str, exc: Exception, trig: dict) -> dict:
    """run_full_ci 某阶段整体出错: 落一条 ERROR 记录 (regime 为空)。"""
    ci_run = _stamp(_blank_run(
        str(uuid.uuid4())[:12], strategy, None, "ERROR", f"CI 阶段异常: {exc}",
        quality_gate=[{"rule": "执行", "passed": False, "actual": str(exc)}]), trig)
    _save_safely(ci_run, f"{strategy.upper()} 阶段错误")
    return ci_run


def run_full_ci(*, trigger: Optional[Mapping] = None) -> dict:
    """
    月度全策略 CI (只评估不发布)
    按内存安全顺序执行: MR(三态串行) → ERP → AIAE V5 自检
    trigger: 触发来源; MR 与 ERP 的各条记录共用一个 batch_id
    """
    trig = resolve_trigger(trigger)
    logger.info("═══ 策略 CI/CD 月度管道启动 (来源=%s, batch=%s) ═══", trig["source"], trig["batch_id"])
    t0 = datetime.now()
    try:
        ac_db.init_db()      # 建表与 ci_runs 迁移 (幂等); 阶段出错时的 ERROR 记录也要能落库
    except Exception as e:
        logger.error("[CI] 数据库初始化失败: %s", e, exc_info=True)

    all_results = {
        "timestamp": t0.isoformat(),
        "batch_id": trig["batch_id"],
        "trigger_source": trig["source"],
        "mr_results": [],
        "erp_result": None,
        "aiae_v5_check": None,
        "summary": {},
    }

    # Phase 1: MR 三态 (串行, 每态完成后 gc)
    try:
        mr_runs = run_mr_ci(trigger=trig)
        all_results["mr_results"] = mr_runs
    except Exception as e:
        logger.error("[CI] MR 全局异常: %s", e)
        all_results["mr_results"] = [_phase_error_run("mr", e, trig)]

    # Phase 2: ERP
    try:
        erp_run = run_erp_ci(trigger=trig)
        all_results["erp_result"] = erp_run
    except Exception as e:
        logger.error("[CI] ERP 全局异常: %s", e)
        all_results["erp_result"] = _phase_error_run("erp", e, trig)

    # Phase 3: AIAE V5 月度自检
    try:
        v5_check = _run_aiae_v5_monthly_check()
        all_results["aiae_v5_check"] = v5_check
    except Exception as e:
        logger.error("[CI] AIAE V5 自检异常: %s", e)
        all_results["aiae_v5_check"] = {"status": "ERROR", "error": str(e)}

    # 汇总
    total_runs = len(all_results["mr_results"]) + (1 if all_results["erp_result"] else 0)
    accepted = sum(1 for r in all_results["mr_results"] if r.get("status") == "ACCEPT")
    if (all_results.get("erp_result") or {}).get("status") == "ACCEPT":
        accepted += 1
    all_runs = list(all_results["mr_results"]) + ([all_results["erp_result"]] if all_results["erp_result"] else [])
    pending = sum(1 for r in all_runs if r.get("approval_status") == "PENDING")

    elapsed = (datetime.now() - t0).total_seconds()
    v5_status = (all_results.get("aiae_v5_check") or {}).get("status", "SKIP")
    all_results["summary"] = {
        "total_runs": total_runs,
        "accepted": accepted,
        "pending_approval": pending,
        "aiae_v5_status": v5_status,
        "elapsed_seconds": round(elapsed, 1),
    }

    logger.info("═══ CI/CD 月度管道完成: %d/%d ACCEPT · 待人工批准 %d · V5=%s · %.0fs ═══",
                accepted, total_runs, pending, v5_status, elapsed)
    return all_results


# ═══════════════════════════════════════════════════════════
#  AIAE V5 月度自检 (Phase 3)
# ═══════════════════════════════════════════════════════════

def _run_aiae_v5_monthly_check() -> dict:
    """
    V5 月度自检:
      1. 生产就绪检查 (12 项)
      2. 联合回测刷新 (对比上月)
      3. 漂移监控状态
      4. 回归检测 (本月 Sharpe vs 上月)
    """
    logger.info("[CI] AIAE V5 月度自检开始")
    result = {"status": "PASS", "checks": {}, "alerts": []}

    # ── Check 1: 生产就绪 ──
    try:
        from engines.production_check import (
            check_aiae_params, check_aiae_engine, check_v5_regime_classify,
            check_v5_position_matrix, check_sub_strategy_alloc,
            check_dividend_aiae_integration, check_frontend_v5_sync,
            check_history_parquet, check_backtest_results,
        )
        prod_checks = {
            "params": check_aiae_params(),
            "engine": check_aiae_engine(),
            "regime": check_v5_regime_classify(),
            "matrix": check_v5_position_matrix(),
            "alloc": check_sub_strategy_alloc(),
            "div_aiae": check_dividend_aiae_integration(),
            "frontend": check_frontend_v5_sync(),
            "history": check_history_parquet(),
            "backtest": check_backtest_results(),
        }
        prod_pass = sum(1 for v in prod_checks.values() if v[0] == "pass")
        prod_total = len(prod_checks)
        result["checks"]["production_ready"] = f"{prod_pass}/{prod_total}"

        if prod_pass < prod_total:
            failed = [k for k, v in prod_checks.items() if v[0] != "pass"]
            result["alerts"].append(f"生产就绪检查失败: {', '.join(failed)}")
            result["status"] = "WARN"

        logger.info("[CI] V5 生产就绪: %d/%d PASS", prod_pass, prod_total)
    except Exception as e:
        result["checks"]["production_ready"] = f"ERROR: {e}"
        logger.warning("[CI] V5 生产就绪检查异常: %s", e)

    # ── Check 2: V5 配额 ETF 持有代理回测刷新 (F2: 软件回归检查, 非策略有效性证据) ──
    try:
        from engines.portfolio_backtest import (
            BACKTEST_VERSION, V5_KEY, load_backtest_results, run_portfolio_backtest, _results_path,
        )
        bt_path = _results_path()

        # 读取上月结果: 仅与同版本、真实行情的代理结果比较 (旧版同月信号结果不参与)
        old_metrics = {}
        if os.path.exists(bt_path):
            old_data = load_backtest_results(bt_path)
            if (old_data.get("version") == BACKTEST_VERSION
                    and old_data.get("evidence_grade") == "research_proxy"):
                old_v5 = old_data.get("strategies", {}).get(V5_KEY, {})
                old_metrics = {
                    "sharpe": old_v5.get("sharpe", 0),
                    "mdd": old_v5.get("mdd_pct", 0),
                    "cagr": old_v5.get("cagr_pct", 0),
                }
            else:
                result["checks"]["backtest_baseline"] = old_data.get("evidence_status", "unknown")

        # 重新运行 (只用真实行情; 不可用时如实报告, 不合成)
        new_data = run_portfolio_backtest("2018-01", allow_synthetic=False)
        gc.collect()
        result["checks"]["backtest_evidence_grade"] = new_data.get("evidence_grade", new_data.get("status"))
        if new_data.get("status") != "success":
            raise RuntimeError(new_data.get("error") or new_data.get("status"))

        new_v5 = new_data.get("strategies", {}).get(V5_KEY, {})
        new_metrics = {
            "sharpe": new_v5.get("sharpe", 0),
            "mdd": new_v5.get("mdd_pct", 0),
            "cagr": new_v5.get("cagr_pct", 0),
        }

        result["checks"]["backtest_sharpe"] = new_metrics["sharpe"]
        result["checks"]["backtest_mdd"] = new_metrics["mdd"]
        result["checks"]["backtest_cagr"] = new_metrics["cagr"]

        # 回归检测: Sharpe 下降 > 15% 则告警
        if old_metrics and old_metrics.get("sharpe", 0) > 0:
            sharpe_delta = new_metrics["sharpe"] - old_metrics["sharpe"]
            sharpe_pct_change = sharpe_delta / old_metrics["sharpe"] * 100
            result["checks"]["sharpe_drift"] = round(sharpe_pct_change, 1)

            if sharpe_pct_change < -15:
                result["alerts"].append(
                    f"V5 Sharpe 回归告警: {old_metrics['sharpe']:.2f} → "
                    f"{new_metrics['sharpe']:.2f} ({sharpe_pct_change:+.1f}%)"
                )
                result["status"] = "WARN"

        logger.info("[CI] V5 配额ETF代理回测: Sharpe=%.2f MDD=%.1f%% CAGR=%.1f%%",
                    new_metrics["sharpe"], new_metrics["mdd"], new_metrics["cagr"])
    except Exception as e:
        result["checks"]["backtest"] = f"ERROR: {e}"
        logger.warning("[CI] V5 联合回测异常: %s", e)

    # ── Check 3: 漂移监控 ──
    try:
        from engines.drift_monitor import check_regime_transition
        drift = check_regime_transition()
        drift_status = drift.get("status", "ok")
        result["checks"]["regime_drift"] = drift_status

        if drift_status == "critical":
            result["alerts"].append(f"Regime 告警: {drift.get('label', '')}")
            result["status"] = "CRITICAL"
        elif drift_status == "warning":
            result["alerts"].append(f"Regime 预警: {drift.get('label', '')}")
            if result["status"] != "CRITICAL":
                result["status"] = "WARN"

        logger.info("[CI] V5 漂移监控: %s", drift_status)
    except Exception as e:
        result["checks"]["regime_drift"] = f"ERROR: {e}"
        logger.warning("[CI] V5 漂移监控异常: %s", e)

    # ── Check 4: 组合压力测试 ──
    try:
        from engines.rebalance_engine import run_stress_test
        stress = run_stress_test()
        if stress["status"] == "success":
            ra = stress["risk_assessment"]
            result["checks"]["liquidity_risk"] = ra["liquidity_risk"]
            result["checks"]["r5_liquidation_days"] = ra["r5_liquidation_days"]

            if ra["liquidity_risk"] == "HIGH":
                result["alerts"].append(
                    f"流动性风险 HIGH: R5 清仓需 {ra['r5_liquidation_days']:.1f} 天 "
                    f"(单日最大 {ra['max_daily_sell']:,.0f})"
                )
                if result["status"] not in ("CRITICAL",):
                    result["status"] = "WARN"

            logger.info("[CI] V5 压力测试: 流动性=%s, R5清仓=%.1f天",
                        ra["liquidity_risk"], ra["r5_liquidation_days"])
    except Exception as e:
        result["checks"]["stress_test"] = f"ERROR: {e}"
        logger.warning("[CI] V5 压力测试异常: %s", e)

    # ── 写入告警 ──
    if result["alerts"]:
        try:
            from services.alert_monitor import push_alert
            for alert_msg in result["alerts"]:
                push_alert(
                    title="V5 月度自检",
                    detail=alert_msg,
                    severity="warning" if result["status"] == "WARN" else "critical",
                    source="ci_pipeline",
                )
        except Exception:
            pass  # 告警推送失败不影响 CI 结果

    logger.info("[CI] AIAE V5 月度自检完成: status=%s, alerts=%d",
                result["status"], len(result["alerts"]))
    return result
