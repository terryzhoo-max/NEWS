# -*- coding: utf-8 -*-
"""
AIAE 基金仓位自动化抓取调度服务 (同花顺 + AKShare 双通道集成)
=====================================================
主通道：同花顺 H5 API，时效性为 T-1 天，精度高、更新快。
备用通道：AKShare / 乐咕乐股，作为容灾降级数据源。
在每天 16:00 (交易日) 触发执行，更新 data_lake/aiae_fund_position.json，支持延迟退避重试。
"""
import sys
import os
import json
import urllib.request
import threading
import time
from datetime import datetime
import logging

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from engines.aiae_engine import get_aiae_engine

logger = logging.getLogger("alphacore.aiae_scheduler")

def fetch_ths_position() -> dict:
    """从同花顺日频基金仓位估算接口获取数据"""
    url = "https://fund.10jqka.com.cn/quotation/wealth_page/query/v2/fund_pos?timeInterval=ONE_YEAR"
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        "Referer": "https://fund.10jqka.com.cn/ifundapp_web/public/m/FundPosition/dist/index.html"
    }
    
    req = urllib.request.Request(url, headers=headers)
    with urllib.request.urlopen(req, timeout=10) as response:
        res_data = response.read().decode("utf-8")
        if not res_data:
            raise ValueError("Tonghuashun response is empty")
        js_obj = json.loads(res_data)
        if js_obj.get("status_code") != 0 or not js_obj.get("data"):
            raise ValueError(f"Tonghuashun API error, code: {js_obj.get('status_code')}")
            
        data = js_obj["data"]
        pos_val_raw = data.get("fundPosPercent")
        if pos_val_raw is None:
            raise ValueError("Tonghuashun fundPosPercent is missing")
        pos_val = round(float(pos_val_raw) * 100, 2)
        
        fund_list = data.get("fundPosList", [])
        if not fund_list:
            raise ValueError("Tonghuashun fundPosList is empty")
            
        latest_item = fund_list[-1]
        raw_date = str(latest_item.get("posDate"))
        if not raw_date or len(raw_date) != 8:
            raise ValueError(f"Tonghuashun date format invalid: {raw_date}")
            
        fmt_date = f"{raw_date[:4]}-{raw_date[4:6]}-{raw_date[6:]}"
        # P2-1 (2026-10-30): 同时返回整段日频序列, 供调度器在最新点异常时回退到最近一个合格点
        series = []
        for it in fund_list:
            d = str(it.get("posDate") or "")
            v = it.get("posValue")
            if len(d) == 8 and v is not None:
                try:
                    series.append((f"{d[:4]}-{d[4:6]}-{d[6:]}", round(float(v) * 100, 2)))
                except (TypeError, ValueError):
                    continue
        return {"date": fmt_date, "position": pos_val, "series": series}


def pick_latest_valid(series, current_value, current_date, validate, source: str = "ths_api"):
    """P2-1: 在比当前值更新的点里, 按日期顺序逐点过护栏, 返回最后一个合格点。

    每个点与"上一个已接受的值"比较 (链式), 真实的缓慢漂移能逐日通过, 单日异常跳变被拒。
    返回 (accepted, skipped): accepted = 按日期排列的合格点列表 [(date, value)]; skipped = [(date, value, reason)]。
    同花顺序列一年内约 17 次跳到 51~61% 并在 1~3 天内恢复 (2026-10-30 复核), 只看最后一点会整段卡住。
    """
    cur = current_value
    accepted, skipped = [], []
    for d, v in sorted(series or []):
        if current_date and str(d) <= str(current_date):
            continue
        reason = validate(v, cur, source)
        if reason is None:
            accepted.append((d, v))
            cur = v
        else:
            skipped.append((d, v, reason))
    return accepted, skipped

def fetch_lg_position() -> dict:
    """备用通道：从 AKShare / 乐咕乐股接口获取数据"""
    import akshare as ak
    df = ak.fund_stock_position_lg()
    if df is None or df.empty:
        raise ValueError("AKShare fund position returns empty")
        
    latest_record = df.iloc[-1]
    latest_date = str(latest_record['date'])       # 格式: 'YYYY-MM-DD'
    latest_pos = float(latest_record['position'])  # 格式: 浮点数 (如 95.67)
    return {"date": latest_date, "position": latest_pos}

def run_delayed_retry(retry_count: int, delay_seconds: int = 600):
    """开启后台单次守护线程，进行非阻塞延时重试"""
    def _retry_worker():
        logger.info(f"延时 {delay_seconds} 秒后启动重试任务...")
        time.sleep(delay_seconds)
        logger.info(f"开始执行第 {retry_count} 次延时重试...")
        update_aiae_fund_position_task(retry_count=retry_count)
        
    t = threading.Thread(target=_retry_worker, daemon=True)
    t.start()

def update_aiae_fund_position_task(retry_count: int = 0):
    """基金仓位自动抓取调度任务 (主备双通道 + 容灾降级)"""
    logger.info(f"开始执行基金仓位抓取流水线 (重试层级: {retry_count})...")
    
    latest_date = None
    latest_pos = None
    source = "degraded_cache"
    
    # 1. 尝试主通道 (同花顺 API)
    try:
        logger.info("尝试 [同花顺 API] (主通道)...")
        res = fetch_ths_position()
        latest_date = res["date"]
        latest_pos = res["position"]
        source = "ths_api"
        logger.info(f"[SUCCESS] 主通道获取成功: {latest_pos}% (日期: {latest_date})")
        # P2-1: 最新点不合格时, 回退到序列里最近一个合格点 (链式护栏)
        if res.get("series"):
            engine = get_aiae_engine()
            accepted, skipped = pick_latest_valid(
                res["series"], engine._fund_position, engine._fund_position_date,
                engine._validate_fund_position, source)
            for d, v, why in skipped:
                logger.warning(f"[P2-1] 同花顺 {d} 原始值 {v}% 未通过护栏, 跳过: {why}")
            if not accepted and skipped:
                return {"status": "rejected", "reason": "同花顺新数据点均未通过护栏",
                        "skipped": [{"date": d, "value": v} for d, v, _ in skipped],
                        "date": engine._fund_position_date, "position": engine._fund_position, "source": source}
            if accepted:
                # 漏跑多日时按日期依次写入中间合格点 (每点与前一点比较), 真实的缓慢漂移不会被一次性拒收
                for d, v in accepted[:-1]:
                    engine.update_fund_position(v, d, source=source)
                if accepted[-1][0] != latest_date:
                    logger.info(f"[P2-1] 最新点 {latest_date} 不合格, 采用最近合格点 {accepted[-1][1]}% ({accepted[-1][0]})")
                latest_date, latest_pos = accepted[-1]
    except Exception as e:
        logger.warning(f"主通道抓取异常: {e}")
        
        # 2. 尝试备用通道 (AKShare / 乐咕乐股)
        try:
            logger.info("自动切换到 [AKShare/乐咕乐股] (备用通道)...")
            res = fetch_lg_position()
            latest_date = res["date"]
            latest_pos = res["position"]
            source = "lg_api"
            logger.info(f"[SUCCESS] 备用通道获取成功: {latest_pos}% (日期: {latest_date})")
        except Exception as lg_err:
            logger.error(f"备份通道也抓取失败: {lg_err}")
            
    # 3. 结果处理
    if latest_date is not None and latest_pos is not None:
        try:
            # 校验数据合理性 (P0 2026-10-30: 区间与跳变护栏统一由引擎 update_fund_position 执行,
            # 阈值见 aiae_params.FUND_POS_*; 这里只挡明显的单位错误, 例如 0.83 / 8300)
            if not (1 <= latest_pos <= 100):
                raise ValueError(f"估算仓位 {latest_pos}% 超出可解析范围 [1, 100]")
                
            engine = get_aiae_engine()
            current_date = engine._fund_position_date
            current_pos = engine._fund_position
            current_src = getattr(engine, "_fund_position_source", None)

            # 2026-10-23 口径守卫:
            # (1) 时间不倒退: 10-23 09:50 同花顺超时后, 乐咕 10-16 的旧数据覆盖了同花顺 10-22 的新数据
            if current_date and str(latest_date) < str(current_date):
                logger.warning(f"放弃更新: 新数据日期 {latest_date} 早于现有 {current_date} ({current_src})")
                return {"status": "skipped", "reason": "older_than_current", "date": current_date, "position": current_pos}
            # (2) 不混用口径: 乐咕(股票型基金仓位, 约 90%+) 与 同花顺(偏股基金估算, 约 83%)
            #     水平相差 ~13 个百分点, 直接替换会使 AIAE_V1 跳变约 1.5pt. 已有同花顺序列时不接受乐咕值
            if source == "lg_api" and current_src == "ths_api":
                logger.warning(f"放弃备用通道值 {latest_pos}% (乐咕口径与同花顺不可比), 保留同花顺 {current_pos}% ({current_date})")
                return {"status": "skipped", "reason": "incompatible_source", "date": current_date, "position": current_pos}
            
            # 判断是否产生数据更新
            if latest_date != current_date or abs(latest_pos - current_pos) > 0.01:
                logger.info(f"检测到仓位数据变动: 原 [{current_pos}% ({current_date})] -> 新 [{latest_pos}% ({latest_date})]")
                res_engine = engine.update_fund_position(latest_pos, latest_date, source=source)
                if res_engine.get("success"):
                    logger.info(f"[SUCCESS] 成功更新数据湖且已落库: {res_engine.get('message')}")
                    # 强制重新加载，确保 API 与计算端点读到最新值
                    engine.refresh()
                elif res_engine.get("rejected"):
                    logger.warning(f"[P0] 护栏拒收, 保留 {current_pos}% ({current_date}): {res_engine.get('message')}")
                    return {"status": "rejected", "reason": res_engine.get("message"),
                            "date": current_date, "position": current_pos, "source": source}
                else:
                    logger.error(f"引擎接口更新失败: {res_engine.get('message')}")
            else:
                logger.info(f"当前数据湖中基金仓位 [{current_pos}% ({current_date})] 已经是最新，无增量变化")
                
                # 如果获取到的是最新日期，但日期依旧不是今天，且处于定时任务触发时间点，执行延迟重试
                today_str = datetime.today().strftime("%Y-%m-%d")
                if latest_date != today_str and retry_count < 2:
                    logger.info(f"未检测到今日 ({today_str}) 新数据，已注册 10 分钟后延迟重试")
                    run_delayed_retry(retry_count=retry_count + 1, delay_seconds=600)
                    
            return {"status": "success", "date": latest_date, "position": latest_pos, "source": source}
        except Exception as update_err:
            logger.warning(f"处理抓取数据时发生异常: {update_err}")
            return {"status": "degraded", "error": str(update_err)}
    else:
        logger.warning("所有抓取通道全部不可用，已安全降级使用本地缓存，不阻塞系统运行")
        return {"status": "degraded", "error": "All channels failed"}

if __name__ == "__main__":
    # 本地测试自检
    res = update_aiae_fund_position_task()
    print("Self-test result:", res)
