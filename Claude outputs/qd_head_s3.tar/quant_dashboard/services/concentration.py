"""
AlphaCore · 主题集中度约束 (Theme Concentration V1, 2026-10 P1)
================================================================

问题: 组合波动预算 (portfolio_vol) 回答"总仓位能放多少", 但不回答"放在哪"。
同样 60% 仓位, 若全部是半导体/电子, 一次行业级冲击 (出口管制、景气下行)
就会让所有持仓同向下跌 —— 分散化失效。机构通用做法: 单一主题 ≤ 权益部分的 40%。

规则:
  - 权益基数 = 全部持仓市值 - 固收/现金类
  - 主题占比 = 主题市值 / 权益基数
  - 宽基与固收/现金不受主题上限约束 (本身即分散 / 非权益)
  - 超过 limit (默认 40%) → warning: 禁止新增该主题
  - 超过 danger (默认 60%) → danger: 禁止新增 + 给出减持量

主题归类口径 (concentration.classification_basis):
  · "lookthrough" (默认, 2026-10-29 用户决定): ETF 按已核验成分 (指数权重或基金报告持仓)
    拆到成分公司, 再按公司行业映射主题; 成分不可用 (过期/缺失/未登记) 或未披露余量
    → 按该 ETF 名称关键词保守回退归类并单列 (不当作零暴露)。固收类 ETF 不穿透。
  · "keyword": 旧口径, ETF 名称关键词整只归入单一主题。
  阈值 (theme_limit_pct / theme_danger_pct) 两种口径相同, 不因口径切换而改变。

主题归类优先级:
  1. 配置 concentration.theme_overrides {ts_code: 主题}  (用户手工指定, 最高优先; 对 ETF 即不穿透)
  2. ETF: 穿透成分 (lookthrough 口径) / 名称关键词 (keyword 口径或回退)
  3. 个股: Tushare stock_basic.industry → 主题映射; 未映射的行业以行业名自成一类
  4. 都没有 → "未分类" (单独列出, 占比 > 10% 时提示补充 override)

说明: 科创50 约六成权重为电子/半导体, 与芯片类 ETF 高度同涨同跌, 归入"半导体电子"。

本模块是纯计算 + 只读诊断, 不下单。
"""

from __future__ import annotations

import os
from typing import Any, Callable, Mapping, Optional

from services.logger import get_logger

logger = get_logger("ac.concentration")

DEFAULT_CONCENTRATION_CONFIG: dict[str, Any] = {
    "enabled": True,
    "theme_limit_pct": 40.0,        # 单一主题 ≤ 权益部分的 40%
    "theme_danger_pct": 60.0,       # 超过该值视为严重集中
    "exempt_themes": ["宽基指数", "固收现金"],
    "unclassified_warn_pct": 10.0,
    "theme_overrides": {},          # {"688019.SH": "半导体电子"}
    "classification_basis": "lookthrough",   # 或 "keyword"; 见模块说明
}

NON_EQUITY_THEMES = {"固收现金"}
UNKNOWN_INDUSTRY_THEME = "行业未知"   # 穿透到公司但本地行业表无行业: 非单一主题, 不受上限约束, 超比例时提示

# ETF 名称关键词 → 主题 (按顺序匹配, 先具体后宽泛)
ETF_KEYWORD_RULES: list[tuple[str, tuple[str, ...]]] = [
    ("固收现金", ("国债", "政金债", "信用债", "可转债", "城投", "短融", "货币", "债")),
    ("贵金属资源", ("黄金", "白银", "有色", "稀土", "煤炭", "钢铁", "矿业", "能源化工")),
    ("半导体电子", ("芯片", "半导体", "集成电路", "科创", "电子", "通信", "5G")),
    ("军工航天", ("卫星", "军工", "国防", "航天", "航空", "通航")),
    ("电力设备新能源", ("光伏", "新能源", "电池", "储能", "电网", "电力设备", "锂电")),
    ("机器人智能制造", ("机器人", "智能制造", "工业母机", "机床")),
    ("软件互联网", ("软件", "计算机", "人工智能", "云计算", "大数据", "互联网", "传媒", "游戏")),
    ("医药医疗", ("医药", "医疗", "生物", "创新药", "中药")),
    ("大金融", ("证券", "券商", "保险", "金融", "银行")),
    ("消费", ("消费", "酒", "食品", "家电", "旅游", "汽车")),
    ("红利防御", ("红利", "低波", "价值", "公用")),
    ("海外市场", ("恒生", "港股", "香港", "纳指", "纳斯达克", "标普", "日经", "德国", "法国", "中概", "H股")),
    ("宽基指数", ("沪深300", "中证500", "中证1000", "中证2000", "上证50", "上证180", "A500", "A50",
                 "中证800", "创业板", "深证100", "双创", "MSCI")),
]

# Tushare stock_basic.industry → 主题
INDUSTRY_THEME_MAP: dict[str, str] = {
    **{k: "半导体电子" for k in ("半导体", "元器件", "通信设备", "IT设备", "电器仪表")},
    **{k: "软件互联网" for k in ("软件服务", "互联网", "影视音像", "出版业")},
    **{k: "电力设备新能源" for k in ("电气设备", "电源设备")},
    **{k: "军工航天" for k in ("航空", "船舶", "运输设备")},
    **{k: "机器人智能制造" for k in ("专用机械", "机械基件", "工程机械", "机床制造", "轻工机械", "化工机械", "农用机械", "纺织机械")},
    **{k: "贵金属资源" for k in ("黄金", "小金属", "铜", "铝", "铅锌", "普钢", "特种钢", "钢加工", "煤炭开采", "焦炭加工", "石油开采", "矿物制品")},
    **{k: "大金融" for k in ("银行", "证券", "保险", "多元金融")},
    **{k: "医药医疗" for k in ("化学制药", "生物制药", "中成药", "医疗保健", "医药商业")},
    **{k: "消费" for k in ("白酒", "红黄酒", "啤酒", "软饮料", "乳制品", "食品", "家用电器", "服饰", "纺织",
                         "旅游服务", "旅游景点", "酒店餐饮", "百货", "超市连锁", "汽车整车", "汽车配件", "日用化工")},
    **{k: "公用事业" for k in ("新型电力", "火力发电", "水力发电", "供气供热", "水务", "环境保护")},
}


def industry_theme_breakdown(industries) -> list[dict]:
    """穿透行业行 [{industry, pct_of_total}] → 按 INDUSTRY_THEME_MAP 汇总的主题 (与合规主题同一映射)。

    2026-11-03 组合页精简 P3: 组合页并列显示"合规主题 x% = 行业 a + b + …"时用; 只做加总, 不判定、不设阈值。
    返回 [{theme, pct, industries: [{industry, pct}]}], 按 pct 降序。未映射的行业以行业名作主题 (与 theme_rows 一致)。
    """
    themes: dict[str, dict] = {}
    for r in industries or []:
        ind = r.get("industry")
        try:
            pct = float(r.get("pct_of_total"))
        except (TypeError, ValueError):
            continue
        if not ind or pct != pct:
            continue
        theme = INDUSTRY_THEME_MAP.get(ind, ind)
        t = themes.setdefault(theme, {"theme": theme, "pct": 0.0, "industries": []})
        t["pct"] += pct
        t["industries"].append({"industry": ind, "pct": round(pct, 2)})
    out = sorted(themes.values(), key=lambda x: x["pct"], reverse=True)
    for t in out:
        t["pct"] = round(t["pct"], 2)
        t["industries"].sort(key=lambda x: x["pct"], reverse=True)
    return out


def _merge_cfg(cfg: Optional[Mapping[str, Any]]) -> dict:
    merged = dict(DEFAULT_CONCENTRATION_CONFIG)
    if cfg:
        merged.update({k: v for k, v in cfg.items() if k in merged})
    return merged


def load_concentration_config() -> dict:
    """strategy_runtime.json → concentration (可选段), 缺省用默认值."""
    try:
        from services.strategy_params import load_runtime_config
        return _merge_cfg(load_runtime_config().get("concentration") or {})
    except Exception as e:
        logger.debug("concentration 配置加载失败, 使用默认值: %s", e)
        return _merge_cfg(None)


def default_industry_loader() -> dict[str, str]:
    """data_lake/stock_list.parquet → {ts_code: industry}; 失败返回空 dict."""
    try:
        import pandas as pd
        root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        path = os.path.join(root, "data_lake", "stock_list.parquet")
        if not os.path.exists(path):
            return {}
        df = pd.read_parquet(path, columns=["ts_code", "industry"])
        return {str(c): str(i) for c, i in zip(df["ts_code"], df["industry"]) if isinstance(i, str) and i}
    except Exception as e:
        logger.warning("行业表读取失败, 个股将按未分类处理: %s", e)
        return {}


_INDUSTRY_CACHE: dict[str, Any] = {"key": None, "map": {}}


def cached_industry_map() -> dict[str, str]:
    """default_industry_loader 的按文件 mtime 缓存版 (合规检查会频繁调用)."""
    root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    path = os.path.join(root, "data_lake", "stock_list.parquet")
    try:
        key = os.path.getmtime(path)
    except OSError:
        return {}
    if _INDUSTRY_CACHE["key"] != key:
        _INDUSTRY_CACHE["map"] = default_industry_loader()
        _INDUSTRY_CACHE["key"] = key
    return _INDUSTRY_CACHE["map"]


def _default_constituent_lookup(ts_code: str) -> Mapping[str, Any]:
    from services.industry_constituents import get_constituents_for_etf
    return get_constituents_for_etf(ts_code)


def _is_etf(ts_code: str) -> bool:
    c = (ts_code or "").split(".")[0]
    return c.startswith(("51", "52", "56", "58", "159", "16"))


def classify_theme(ts_code: str, name: str, industry_map: Mapping[str, str],
                   overrides: Mapping[str, str]) -> tuple[str, str]:
    """→ (主题, 归类依据)."""
    if ts_code in overrides and overrides[ts_code]:
        return str(overrides[ts_code]), "override"
    nm = name or ""
    if _is_etf(ts_code):
        for theme, kws in ETF_KEYWORD_RULES:
            if any(k in nm for k in kws):
                return theme, "etf_name"
        return "未分类", "none"
    ind = industry_map.get(ts_code)
    if ind:
        return INDUSTRY_THEME_MAP.get(ind, ind), f"industry:{ind}"
    # 港股 / 其他市场个股: 无 Tushare A 股行业
    if ts_code.endswith(".HK"):
        return "海外市场", "market:HK"
    return "未分类", "none"


def theme_rows(holdings, industry_map: Mapping[str, str], overrides: Mapping[str, str],
               basis: str = "lookthrough",
               constituent_lookup: Optional[Callable[[str], Mapping[str, Any]]] = None) -> list[dict]:
    """持仓 [{ts_code, name, value}] → 主题行 [{ts_code, name, theme, value, basis}]。

    lookthrough 口径下一只 ETF 可拆成多行; 各行 value 之和 = 持仓 value (拆分规则见 lookthrough.split_etf_value:
    小额残余按名称回退、权重 ≤100.5% 缩放、>100.5% 整只回退)。
    basis 取值: override / industry:<行业> / market:HK / none / etf_name (keyword 口径) /
    lookthrough:<exposure_basis> / etf_name_fallback:<原因>。
    """
    lookup = constituent_lookup or _default_constituent_lookup
    out: list[dict] = []
    for h in holdings:
        code, name, mv = str(h["ts_code"]), h.get("name") or h["ts_code"], float(h["value"])
        if mv <= 0:
            continue
        kw_theme, kw_basis = classify_theme(code, name, industry_map, overrides)
        if (basis != "lookthrough" or kw_basis == "override" or not _is_etf(code)
                or kw_theme in NON_EQUITY_THEMES):
            out.append({"ts_code": code, "name": name, "theme": kw_theme, "value": mv, "basis": kw_basis})
            continue
        try:
            rec = lookup(code) or {}
        except Exception as e:  # noqa: BLE001 — 查询失败按回退处理, 原因可见
            logger.warning("ETF 成分查询失败 %s: %s", code, e)
            rec = {"issues": ["CONSTITUENT_LOOKUP_ERROR"]}
        from services.lookthrough import split_etf_value   # 与穿透/压力共用同一拆分与守恒口径
        split = split_etf_value(mv, rec)
        if split["status"] != "ok":
            out.append({"ts_code": code, "name": name, "theme": kw_theme, "value": mv,
                        "basis": f"etf_name_fallback:{split['reason']}"})
            continue
        agg: dict[str, float] = {}
        for ccode, _cname, v, _w in split["parts"]:
            if overrides.get(ccode):
                theme = str(overrides[ccode])
            else:
                ind = industry_map.get(ccode)
                theme = INDUSTRY_THEME_MAP.get(ind, ind) if ind else UNKNOWN_INDUSTRY_THEME
            agg[theme] = agg.get(theme, 0.0) + v
        for theme, v in agg.items():
            out.append({"ts_code": code, "name": name, "theme": theme, "value": v,
                        "basis": f"lookthrough:{split['exposure_basis']}"})
        if split["residual"] > 0:
            out.append({"ts_code": code, "name": name, "theme": kw_theme, "value": split["residual"],
                        "basis": f"etf_name_fallback:{split['residual_reason']}"})
    return out


def compute_concentration(store: Mapping[str, Any],
                          industry_map: Optional[Mapping[str, str]] = None,
                          cfg: Optional[Mapping[str, Any]] = None,
                          target_equity_pct: Optional[float] = None,
                          constituent_lookup: Optional[Callable[[str], Mapping[str, Any]]] = None) -> dict:
    """持仓 → 主题集中度诊断 (口径见 cfg.classification_basis).

    target_equity_pct: 可执行仓位上限 (占总资产 %), 用于计算主题上限金额; None = 按当前权益轮动.
    """
    c = _merge_cfg(cfg)
    if not c.get("enabled", True):
        return {"status": "disabled"}
    positions = (store or {}).get("positions") or {}
    if not positions:
        return {"status": "empty", "message": "无持仓"}
    if industry_map is None:
        industry_map = default_industry_loader()
    overrides = c.get("theme_overrides") or {}

    basis = "keyword" if str(c.get("classification_basis") or "").lower() == "keyword" else "lookthrough"

    total_asset = float((store or {}).get("broker_total_asset") or 0)
    holdings = [{"ts_code": code, "name": p.get("name", code), "value": float(p.get("broker_market_value", 0) or 0)}
                for code, p in positions.items()]
    holdings = [h for h in holdings if h["value"] > 0]
    rows = theme_rows(holdings, industry_map, overrides, basis=basis, constituent_lookup=constituent_lookup)
    # 2026-10-23: 总资产以 持仓市值+可用资金 为准 (券商「资产」字段可能漏计当日卖出资金)
    _computed = sum(h["value"] for h in holdings) + float((store or {}).get("cash", 0) or 0)
    if _computed > 0:
        total_asset = _computed

    equity = sum(r["value"] for r in rows if r["theme"] not in NON_EQUITY_THEMES)
    if equity <= 0:
        return {"status": "empty", "message": "无权益持仓", "as_of": store.get("import_date")}

    buckets: dict[str, dict] = {}
    for r in rows:
        b = buckets.setdefault(r["theme"], {"theme": r["theme"], "value": 0.0, "_m": {}})
        b["value"] += r["value"]
        m = b["_m"].setdefault((r["ts_code"], r["basis"]), {"ts_code": r["ts_code"], "name": r["name"],
                                                            "value": 0.0, "basis": r["basis"]})
        m["value"] += r["value"]
    for b in buckets.values():
        b["members"] = [{**m, "value": round(m["value"], 2)} for m in b.pop("_m").values()]

    limit = float(c["theme_limit_pct"])
    danger = float(c["theme_danger_pct"])
    exempt = set(c.get("exempt_themes") or []) | NON_EQUITY_THEMES | {UNKNOWN_INDUSTRY_THEME}

    themes = []
    for b in buckets.values():
        is_equity = b["theme"] not in NON_EQUITY_THEMES
        pct_eq = b["value"] / equity * 100 if is_equity else None
        b["members"].sort(key=lambda m: -m["value"])
        themes.append({
            "theme": b["theme"],
            "value": round(b["value"], 2),
            "pct_of_equity": round(pct_eq, 1) if pct_eq is not None else None,
            "pct_of_account": round(b["value"] / total_asset * 100, 1) if total_asset else None,
            "count": len({m["ts_code"] for m in b["members"]}),
            "exempt": b["theme"] in exempt,
            "members": b["members"],
        })
    themes.sort(key=lambda t: -t["value"])

    eq_themes = [t for t in themes if t["pct_of_equity"] is not None]
    w = [t["pct_of_equity"] / 100 for t in eq_themes]
    effective_themes = round(1 / sum(x * x for x in w), 2) if w else None

    constrained = [t for t in eq_themes if not t["exempt"]]
    top = max(constrained, key=lambda t: t["pct_of_equity"]) if constrained else None
    top_pct = top["pct_of_equity"] if top else 0.0

    breaches = [t["theme"] for t in constrained if t["pct_of_equity"] > limit]
    # 主题上限金额 = 限额 × 目标权益规模
    #   目标权益 = min(当前权益, 可执行仓位上限 × 总资产); 无上限时按当前权益 (纯轮动)
    #   与总仓位约束联立求解, 避免 "卖到现金 → 权益缩小 → 占比不降" 的无解建议
    target_equity = equity
    if target_equity_pct is not None and total_asset:
        try:
            target_equity = min(equity, max(0.0, float(target_equity_pct)) / 100 * total_asset)
        except (TypeError, ValueError):
            target_equity = equity
    theme_max_value = trim_value = trim_pct_account = None
    if top:
        theme_max_value = round(limit / 100 * target_equity, 0)
    if top and top_pct > limit:
        trim_value = round(max(0.0, top["value"] - theme_max_value), 0)
        trim_pct_account = round(trim_value / total_asset * 100, 1) if total_asset else None

    if not top:
        level, text, instruction = "ok", "无受约束主题", "维持"
    elif top_pct > danger:
        level = "danger"
        text = f"{top['theme']} 占权益 {top_pct:.0f}% (> {danger:.0f}%)"
        instruction = (f"禁止新增「{top['theme']}」; 该主题上限 {theme_max_value / 10000:.1f} 万"
                       f" ({limit:.0f}% × 目标权益 {target_equity / 10000:.1f} 万), 需减持约"
                       f" {trim_value / 10000:.1f} 万 (占账户 {trim_pct_account}%), 分批执行, 可留现金或转投其他主题")
    elif top_pct > limit:
        level = "warning"
        text = f"{top['theme']} 占权益 {top_pct:.0f}% (> {limit:.0f}%)"
        instruction = (f"禁止新增「{top['theme']}」; 新增资金只投向其他主题"
                       f" (该主题上限 {theme_max_value / 10000:.1f} 万)")
    else:
        level, text, instruction = "ok", f"最大主题 {top['theme']} {top_pct:.0f}%", "在限额内"
    if basis == "lookthrough" and level in ("warning", "danger"):
        instruction += "; 金额为穿透后的主题暴露, 卖出 ETF 时需按其该主题占比折算卖出额"

    unclassified = next((t for t in themes if t["theme"] == "未分类"), None)
    unclassified_pct = unclassified["pct_of_equity"] if unclassified else 0.0
    caveats = []
    if unclassified_pct and unclassified_pct > float(c["unclassified_warn_pct"]):
        caveats.append(f"{unclassified_pct:.0f}% 的权益未能归类, 请在 strategy_runtime.json → "
                       "concentration.theme_overrides 中补充")
    if not industry_map:
        caveats.append("行业表不可用, 个股归类可能不全")
    unk_ind = next((t for t in themes if t["theme"] == UNKNOWN_INDUSTRY_THEME), None)
    if unk_ind and unk_ind["pct_of_equity"] and unk_ind["pct_of_equity"] > float(c["unclassified_warn_pct"]):
        caveats.append(f"穿透后 {unk_ind['pct_of_equity']:.0f}% 的权益对应公司无本地行业数据, 未计入任何主题上限")
    fb: dict[str, dict] = {}
    for r in rows:
        if r["basis"].startswith("etf_name_fallback:"):
            f = fb.setdefault(r["ts_code"], {"ts_code": r["ts_code"], "name": r["name"], "theme": r["theme"],
                                            "value": 0.0, "reason": r["basis"].split(":", 1)[1]})
            f["value"] += r["value"]
    fallback = sorted(({**f, "value": round(f["value"], 2)} for f in fb.values()), key=lambda f: -f["value"])
    fallback_value = sum(f["value"] for f in fallback)
    fallback_pct = round(fallback_value / equity * 100, 1) if equity else None
    if fallback_value > 0:
        caveats.append(f"{fallback_pct:.0f}% 的权益因成分不可用或未披露, 按 ETF 名称关键词保守归类 (不当作零暴露)")

    return {
        "status": "ok",
        "as_of": (store or {}).get("import_date"),
        "classification_basis": basis,
        "fallback": fallback,
        "fallback_pct_of_equity": fallback_pct,
        "limit_pct": limit,
        "danger_pct": danger,
        "equity_value": round(equity, 2),
        "total_asset": round(total_asset, 2),
        "top_theme": top["theme"] if top else None,
        "top_pct": round(top_pct, 1) if top else None,
        "effective_themes": effective_themes,
        "breaches": breaches,
        "target_equity": round(target_equity, 2),
        "theme_max_value": theme_max_value,
        "trim_value": trim_value,
        "trim_pct_account": trim_pct_account,
        "level": level,
        "text": text,
        "instruction": instruction,
        "themes": themes,
        "caveats": caveats,
    }


# ═══════════════════════════════════════════════════════
#  阶段3B-2 (2026-10-29): 穿透视角 (公司/重叠/成分来源明细)
#  2026-10-29 用户决定后, 执行等级默认也按穿透口径 (见 theme_rows); 本视图保留作明细与复核
# ═══════════════════════════════════════════════════════

def lookthrough_view(store: Mapping[str, Any], industry_map: Mapping[str, str],
                     constituent_lookup: Optional[Callable[[str], Mapping[str, Any]]] = None,
                     top: int = 10) -> dict:
    """持仓穿透到公司 → 行业 → 主题 (与关键词主题同一套 INDUSTRY_THEME_MAP)。

    只做明细: 不判定违规、不新增阈值。未知暴露单列, 不分摊到任何主题。
    """
    from services.lookthrough import build_lookthrough
    if constituent_lookup is None:
        constituent_lookup = _default_constituent_lookup
    positions = [{"ts_code": code, "name": p.get("name", code),
                  "market_value": float(p.get("broker_market_value", 0) or 0)}
                 for code, p in ((store or {}).get("positions") or {}).items()]
    lt = build_lookthrough(positions, cash=float((store or {}).get("cash", 0) or 0),
                           constituent_lookup=constituent_lookup,
                           stock_info={c: {"industry": i} for c, i in (industry_map or {}).items()},
                           top=10 ** 6)
    if lt["status"] != "ok":
        return {"status": lt["status"]}
    invested = lt["invested_value"]
    theme_v: dict[str, float] = {}
    for c in lt["companies"]:
        ind = c.get("industry")
        theme = INDUSTRY_THEME_MAP.get(ind, ind) if ind else "行业未知"
        theme_v[theme] = theme_v.get(theme, 0.0) + c["total_value"]
    themes = sorted(({"theme": t, "value": round(v, 2), "pct_of_invested": round(v / invested * 100, 1)}
                     for t, v in theme_v.items()), key=lambda x: -x["value"])
    return {
        "status": "ok",
        "basis": "lookthrough",
        "note": "按穿透到公司后的行业映射主题; 未知部分单列 (执行口径中未知部分按 ETF 名称回退归类)",
        "invested_value": invested,
        "known_pct_of_invested": lt["known_lookthrough_pct_of_invested"],
        "unknown": {"value": lt["unknown"]["value"],
                    "pct_of_invested": round(lt["unknown"]["value"] / invested * 100, 1) if invested else None,
                    "items": [{k: u[k] for k in ("ts_code", "name", "value", "reason")} for u in lt["unknown"]["items"]]},
        "themes": themes,
        "top_companies": [{"code": c["code"], "name": c["name"], "industry": c["industry"],
                           "pct_of_invested": round(c["total_value"] / invested * 100, 2) if invested else None,
                           "via": sorted({s["via"] for s in c["sources"]}), "overlap": c["overlap"]}
                          for c in lt["companies"][:top]],
        "overlap_company_count": len(lt["overlap_companies"]),
        "etfs": [{k: e.get(k) for k in ("ts_code", "instrument_name", "tracking_index_name", "exposure_basis",
                                         "weights_as_of", "is_verified")} for e in lt["etfs"]],
    }


def explain(result: Mapping[str, Any]) -> dict:
    """告警说明: 触发原因 / 数据可信度 / 应复核事项 (描述性, 不新增判定阈值)。"""
    themes = result.get("themes") or []
    total = sum(m["value"] for t in themes for m in t["members"]) or 0.0
    by_basis: dict[str, float] = {}
    for t in themes:
        for m in t["members"]:
            key = m["basis"].split(":")[0]
            by_basis[key] = by_basis.get(key, 0.0) + m["value"]
    basis_pct = {k: round(v / total * 100, 1) for k, v in by_basis.items()} if total else {}
    lookthrough_basis = result.get("classification_basis") == "lookthrough"
    review = []
    if lookthrough_basis:
        review.append(f"执行口径: 穿透后的实际持仓 ({basis_pct.get('lookthrough', 0.0):.0f}% 市值按成分拆分)")
        if basis_pct.get("etf_name_fallback"):
            fb = ", ".join(f"{f['ts_code']}" for f in (result.get("fallback") or [])[:5])
            review.append(f"{basis_pct['etf_name_fallback']:.0f}% 市值成分不可用或未披露, 按 ETF 名称关键词保守归类"
                          + (f": {fb}" if fb else ""))
        kw = result.get("keyword_reference") or {}
        if kw.get("top_theme"):
            review.append(f"参考: 旧关键词口径最大主题「{kw['top_theme']}」{kw.get('top_pct')}% (等级 {kw.get('level')})")
    elif basis_pct.get("etf_name"):
        review.append(f"{basis_pct['etf_name']:.0f}% 市值按 ETF 名称关键词整只归入单一主题, 未反映成分实际分布")
    lv = result.get("lookthrough") or {}
    if lv.get("status") == "ok":
        u = lv["unknown"]["pct_of_invested"]
        review.append(f"穿透可识别 {lv['known_pct_of_invested']}% 持仓; 未知 {u}% (成分缺失/过期/未披露/不支持品种)")
        top_t = result.get("top_theme")
        if top_t and not lookthrough_basis:
            lt_pct = next((t["pct_of_invested"] for t in lv["themes"] if t["theme"] == top_t), 0.0)
            review.append(f"关键词口径最大主题「{top_t}」{result.get('top_pct')}% (占权益); "
                          f"穿透口径该主题 {lt_pct}% (占持仓, 不含未知部分)")
        if lv.get("overlap_company_count"):
            review.append(f"{lv['overlap_company_count']} 家公司同时出现在多只 ETF 或直接持股中")
        stale = [e["ts_code"] for e in lv.get("etfs", []) if not e.get("is_verified")]
        if stale:
            review.append(f"成分未核验的 ETF: {', '.join(stale)} — "
                          + ("执行口径按名称回退归类" if lookthrough_basis else "其暴露计入未知"))
        fund_basis = [e["ts_code"] for e in lv.get("etfs", []) if e.get("exposure_basis") == "fund_reported_holdings"]
        if fund_basis:
            review.append(f"按基金报告持仓穿透 (时点较早): {', '.join(fund_basis)}")
    elif lv:
        review.append("穿透明细不可用" + ("" if lookthrough_basis else ", 仅有关键词归类"))
    note = ("执行等级基于穿透后的主题暴露与已配置阈值; 成分不可用部分按 ETF 名称保守回退" if lookthrough_basis
            else "执行等级基于关键词主题与已配置阈值; 穿透数据仅用于复核")
    return {"trigger": result.get("text"), "level": result.get("level"), "basis": result.get("classification_basis"),
            "classification_basis_pct": basis_pct, "review_items": review, "note": note}


def compute_from_store(store: Optional[Mapping[str, Any]] = None,
                       industry_loader: Optional[Callable[[], Mapping[str, str]]] = None,
                       target_equity_pct: Optional[float] = None) -> dict:
    """从 data_lake/portfolio_store.json 计算 (与 portfolio_vol 同一持仓源)."""
    import json
    if store is None:
        root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        path = os.path.join(root, "data_lake", "portfolio_store.json")
        try:
            with open(path, "r", encoding="utf-8") as f:
                store = json.load(f)
        except Exception as e:
            return {"status": "empty", "message": f"持仓文件不可读: {e}"}
    ind = (industry_loader or default_industry_loader)()
    cfg = load_concentration_config()
    result = compute_concentration(store, ind, cfg, target_equity_pct=target_equity_pct)
    if result.get("status") == "ok" and result.get("classification_basis") == "lookthrough":
        try:   # 旧口径仅作对照展示, 不参与判定
            kw = compute_concentration(store, ind, {**cfg, "classification_basis": "keyword"},
                                       target_equity_pct=target_equity_pct)
            if kw.get("status") == "ok":
                result["keyword_reference"] = {k: kw.get(k) for k in ("top_theme", "top_pct", "level", "text")}
        except Exception as e:  # noqa: BLE001
            logger.debug("关键词口径对照计算失败: %s", e)
    if result.get("status") == "ok":
        try:
            result["lookthrough"] = lookthrough_view(store, ind)
        except Exception as e:  # noqa: BLE001 — 明细失败不影响执行口径, 但要可见
            logger.warning("穿透集中度计算失败: %s", e)
            result["lookthrough"] = {"status": "error", "error": str(e)}
        result["explain"] = explain(result)
    return result


def summarize(result: Mapping[str, Any]) -> Optional[dict]:
    """面板用精简版 (主题列表只保留前 5 个, 成员只保留名称)."""
    if not isinstance(result, Mapping) or result.get("status") != "ok":
        return None
    keys = ("status", "as_of", "limit_pct", "danger_pct", "top_theme", "top_pct", "effective_themes",
            "breaches", "target_equity", "theme_max_value", "trim_value", "trim_pct_account", "level", "text", "instruction", "caveats",
            "classification_basis", "fallback_pct_of_equity", "keyword_reference")
    out = {k: result.get(k) for k in keys}
    lv = result.get("lookthrough") or {}
    if lv.get("status") == "ok":
        out["lookthrough"] = {"known_pct_of_invested": lv["known_pct_of_invested"],
                              "unknown_pct_of_invested": lv["unknown"]["pct_of_invested"],
                              "themes": lv["themes"][:5], "top_companies": lv["top_companies"][:5],
                              "overlap_company_count": lv["overlap_company_count"]}
    if result.get("explain"):
        out["explain"] = result["explain"]
    out["themes"] = [
        {"theme": t["theme"], "pct_of_equity": t["pct_of_equity"], "pct_of_account": t["pct_of_account"],
         "count": t["count"], "exempt": t["exempt"], "names": [m["name"] for m in t["members"]][:8]}
        for t in result.get("themes", [])[:5]
    ]
    return out
