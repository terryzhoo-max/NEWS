"""
AlphaCore · 收益口径契约 (方案 B 阶段2B, 2026-10-29)
===================================================

系统内所有收益/净值输出必须带 `return_basis`, 四种口径不可混用:

  account_total_actual         整账户实际收益 (含现金; 剔除入出金; 依赖现金台账覆盖与券商总资产快照)
  risk_asset_twr               风险资产时间加权净值 (不含现金; 成交台账回滚持仓; services/drawdown)
  current_holdings_simulation  当前持仓历史模拟 (假设一直持有今天的持仓; 不是真实历史业绩)
  strategy_backtest            策略/代理回测 (规则回放; 不是账户业绩)

整账户两种收益的用途:
  · 时间加权 (TWR): 剔除入出金时点与金额的影响, 衡量"投资决策本身"的表现, 可与基准比较。
    需要每次入出金当日的账户总值; 只有期初/期末估值时, 用 Modified Dietz 近似并如实标注。
  · 资金加权 (MWR / XIRR): 反映投入金额与时点对"你实际赚到的钱"的影响; 加仓时点好坏会改变它。
费用、税、分红都已包含在账户总值变化中; 只有入金/出金被视为外部资金流。
"""
from __future__ import annotations

from datetime import date
from typing import Any, Iterable, Mapping, Optional

BASES: dict[str, dict] = {
    "account_total_actual": {
        "label": "整账户实际收益（含现金，剔除入出金）",
        "is_actual_history": True, "includes_cash": True, "external_flows_handled": True,
        "source": "现金台账 + 券商总资产快照",
    },
    "risk_asset_twr": {
        "label": "风险资产时间加权净值（不含现金，成交回滚持仓）",
        "is_actual_history": True, "includes_cash": False, "external_flows_handled": True,
        "source": "成交台账 + 券商持仓快照 + 收盘价",
    },
    "current_holdings_simulation": {
        "label": "当前持仓历史模拟（假设一直持有今天的持仓，非真实历史业绩）",
        "is_actual_history": False, "includes_cash": False, "external_flows_handled": False,
        "source": "当前持仓权重 × 历史收盘价",
    },
    "strategy_backtest": {
        "label": "策略/代理回测（规则回放，非账户业绩）",
        "is_actual_history": False, "includes_cash": True, "external_flows_handled": False,
        "source": "历史数据回放",
    },
}


def basis_meta(basis: str, **extra: Any) -> dict:
    if basis not in BASES:
        raise ValueError(f"未知收益口径: {basis}")
    return {"return_basis": basis, **BASES[basis], **extra}


def _d(s: str) -> date:
    return date.fromisoformat(str(s)[:10])


# ═══════════════════════════════════════════════════════
#  整账户收益 (纯函数)
#  估值时点契约 (验收修补, 2026-10-29):
#    · 快照估值 V_t = 当日收盘后的账户总资产, 已包含当日发生的资金流 F (入金 F>0, 出金 F<0)。
#    · 资金流时点决定"流前价值" B:
#        开盘前 (时间 < 09:15, 尚无成交价形成) → B = 上一交易日收盘估值 (须有该快照);
#        收盘后 (时间 ≥ 15:00)                 → B = V_t − F;
#        盘中或时间未知                        → 无法精确分段。
#    · 只有全部资金流都能精确分段时才标 chain_linked_exact; 否则给出两种极端时点下的区间
#      (approx_flow_timing_unknown) 或 Modified Dietz 近似 (modified_dietz_approx), 均如实标注。
#  twr_chain() 仍按"资金流在估值之前、不参与当日收益" (即收盘后) 的约定, 供已知时点的调用方使用。
# ═══════════════════════════════════════════════════════

FLOW_BEFORE_OPEN = "before_open"
FLOW_AFTER_CLOSE = "after_close"
FLOW_UNKNOWN = "unknown"


def flow_timing(time_str: Optional[str]) -> str:
    t = str(time_str or "").strip().replace(":", "")
    if len(t) < 4 or not t[:4].isdigit():
        return FLOW_UNKNOWN
    hhmm = int(t[:4])
    if hhmm < 915:
        return FLOW_BEFORE_OPEN
    if hhmm >= 1500:
        return FLOW_AFTER_CLOSE
    return FLOW_UNKNOWN


def _prev_weekday(d: date) -> date:
    from datetime import timedelta
    d = d - timedelta(days=1)
    while d.weekday() >= 5:
        d = d - timedelta(days=1)
    return d


def twr_segmented(start: tuple[str, float], end: tuple[str, float], flows: list[tuple[str, float, str]],
                  valuations: Mapping[str, float]) -> Optional[float]:
    """按资金流时点精确分段的 TWR。flows = [(日期, 金额, before_open|after_close)]。

    开盘前资金流要求上一工作日有收盘估值 (节假日无法确认 → 返回 None, 由调用方降级);
    收盘后资金流要求当日有估值。任一条件不满足返回 None。"""
    order = {FLOW_BEFORE_OPEN: 0, FLOW_AFTER_CLOSE: 1}
    grouped: dict[tuple[str, str], float] = {}
    for d, f, timing in flows:
        if timing not in order:
            return None
        grouped[(d, timing)] = grouped.get((d, timing), 0.0) + f
    g, anchor_v, anchor_d = 1.0, start[1], start[0]
    for (d, timing) in sorted(grouped, key=lambda k: (k[0], order[k[1]])):
        f = grouped[(d, timing)]
        if timing == FLOW_BEFORE_OPEN:
            prev = _prev_weekday(_d(d)).isoformat()
            if prev not in valuations or prev < anchor_d:
                return None
            pre = valuations[prev]
        else:
            if d not in valuations:
                return None
            pre = valuations[d] - f
        if anchor_v <= 0:
            return None
        g *= pre / anchor_v
        anchor_v, anchor_d = pre + f, d
    if anchor_v <= 0 or end[0] < anchor_d:
        return None
    return g * end[1] / anchor_v - 1

def twr_chain(points: list[tuple[str, float, float]]) -> Optional[float]:
    """points = [(日期, 当日估值, 当日外部资金流)], 按日期升序, 首点资金流忽略。
    分段收益 r_i = (V_i − F_i) / V_{i−1} − 1, 连乘。任一 V_{i−1} ≤ 0 返回 None。"""
    if len(points) < 2:
        return None
    g = 1.0
    for (_, v0, _), (_, v1, f1) in zip(points, points[1:]):
        if v0 <= 0:
            return None
        g *= (v1 - f1) / v0
    return g - 1


def modified_dietz(v0: float, v1: float, flows: Iterable[tuple[str, float]], start: str, end: str) -> Optional[float]:
    """只有期初/期末估值时的 TWR 近似。权重 w = (期末 − 流日) / 区间天数。"""
    total = (_d(end) - _d(start)).days
    if total <= 0:
        return None
    flows = list(flows)
    f_sum = sum(f for _, f in flows)
    weighted = sum(f * (_d(end) - _d(t)).days / total for t, f in flows)
    denom = v0 + weighted
    if denom <= 0:
        return None
    return (v1 - v0 - f_sum) / denom


def xirr(cashflows: list[tuple[str, float]], lo: float = -0.9999, hi: float = 10.0) -> Optional[float]:
    """年化资金加权收益。cashflows 为投资者视角 (投入为负, 取回/期末价值为正)。二分法求解。"""
    if len(cashflows) < 2 or not (any(c < 0 for _, c in cashflows) and any(c > 0 for _, c in cashflows)):
        return None
    t0 = min(_d(t) for t, _ in cashflows)

    def npv(r: float) -> float:
        return sum(c / (1 + r) ** ((_d(t) - t0).days / 365.0) for t, c in cashflows)

    f_lo, f_hi = npv(lo), npv(hi)
    if f_lo * f_hi > 0:
        return None
    for _ in range(200):
        mid = (lo + hi) / 2
        f_mid = npv(mid)
        if abs(f_mid) < 1e-9:
            break
        if f_lo * f_mid < 0:
            hi, f_hi = mid, f_mid
        else:
            lo, f_lo = mid, f_mid
    return (lo + hi) / 2


def account_returns(ledger: Mapping[str, Any], start: Optional[str] = None, end: Optional[str] = None) -> dict:
    """整账户收益: 用券商总资产快照作估值、现金台账的入出金作外部资金流。

    覆盖不足或缺少估值时返回 insufficient_*, 不估算、不补造。
    """
    from services import account_ledger as al

    # 旧快照以导入当天为 as_of (来源注明"as_of=导入日期"), 不是券商账单日期 → 不作为历史估值
    all_snaps = [s for s in ledger.get("snapshots", []) if s.get("total_asset")]
    snaps = [s for s in all_snaps if "as_of=导入日期" not in str(s.get("source") or "")]
    excluded_legacy = len(all_snaps) - len(snaps)
    if start:
        snaps = [s for s in snaps if s["as_of"] >= start]
    if end:
        snaps = [s for s in snaps if s["as_of"] <= end]
    base = basis_meta("account_total_actual")
    if len(snaps) < 2:
        return {**base, "status": "insufficient_valuations",
                "note": "需要至少两个带总资产、且日期为券商账单实际日期的快照才能计算整账户收益",
                "snapshot_count": len(snaps), "excluded_legacy_snapshots": excluded_legacy}
    a, b = snaps[0], snaps[-1]
    if a["as_of"] == b["as_of"]:
        return {**base, "status": "insufficient_valuations", "note": "快照日期相同", "snapshot_count": len(snaps)}
    covered = al.cash_coverage_ok(ledger, a["as_of"], b["as_of"])
    if not covered:
        return {**base, "status": "insufficient_cash_coverage", "from": a["as_of"], "to": b["as_of"],
                "note": "区间内缺少含发生金额的交割单/资金流水, 入出金未知; 不能计算剔除入出金的收益"}
    flow_events = [e for e in al.effective_events(ledger)
                   if e["type"] in al.EXTERNAL_FLOW_TYPES and a["as_of"] < e["date"] <= b["as_of"]]
    # 2026-11-04: 区间末端由"按导出日推定"的覆盖补齐 (文件里无该日记录) → 标注, 不影响计算
    inferred_days = sorted({s.get("covered_to") for s in ledger.get("sources", [])
                            if s.get("cash_coverage") and s.get("covered_to") and s.get("date_to")
                            and s["covered_to"] > s["date_to"] and a["as_of"] < s["covered_to"]})
    flows = [(e["date"], float(e["amount"])) for e in flow_events]
    timed = [(e["date"], float(e["amount"]), flow_timing(e.get("time"))) for e in flow_events]
    v0, v1 = float(a["total_asset"]), float(b["total_asset"])
    by_date = {s["as_of"]: float(s["total_asset"]) for s in snaps}
    start_pt, end_pt = (a["as_of"], v0), (b["as_of"], v1)
    twr_range, twr_note = None, ""
    unknown = [t for t in timed if t[2] == FLOW_UNKNOWN]
    exact = twr_segmented(start_pt, end_pt, timed, by_date) if not unknown else None
    if exact is not None:
        twr, twr_method = exact, "chain_linked_exact"
        twr_note = "全部资金流时点已知 (开盘前/收盘后) 且流前估值可得, 精确分段"
    else:
        lo_hi = [twr_segmented(start_pt, end_pt,
                               [(d, f, tm if tm != FLOW_UNKNOWN else alt) for d, f, tm in timed], by_date)
                 for alt in (FLOW_BEFORE_OPEN, FLOW_AFTER_CLOSE)]
        if unknown and all(x is not None for x in lo_hi):
            twr_range = sorted(round(x, 6) for x in lo_hi)
            twr = (lo_hi[0] + lo_hi[1]) / 2
            twr_method = "approx_flow_timing_unknown"
            twr_note = (f"{len(unknown)} 笔资金流发生在盘中或时点未知, 无法精确分段; 给出按开盘前/收盘后两种时点"
                        "计算的区间, 点估计取中值")
        else:
            twr = modified_dietz(v0, v1, flows, a["as_of"], b["as_of"])
            twr_method = "modified_dietz_approx"
            twr_note = "缺少资金流时点或流前估值快照, 用 Modified Dietz 按日近似 (资金流视为当日收盘后)"
    # 估值时点: 快照须为收盘后估值才可能精确; 盘中/未知时点 (含旧快照无该字段) 一律降为近似
    bad_timing = sorted({sn["as_of"] for sn in snaps if sn.get("valuation_timing") != "close"})
    if bad_timing:
        if twr_method == "chain_linked_exact":
            twr_method = "approx_valuation_timing_unknown"
        twr_note = (twr_note + "; " if twr_note else "") + \
            f"{len(bad_timing)} 个快照的估值时点不是收盘后或未知 ({', '.join(bad_timing[:5])}), 不作精确分段"
    cfs = [(a["as_of"], -v0)] + [(t, -f) for t, f in flows] + [(b["as_of"], v1)]
    mwr = xirr(cfs)
    net_flows = round(sum(f for _, f in flows), 2)
    return {**base, "status": "ok", "from": a["as_of"], "to": b["as_of"],
            "start_value": v0, "end_value": v1, "net_external_flows": net_flows,
            "investment_pnl": round(v1 - v0 - net_flows, 2),
            "twr": None if twr is None else round(twr, 6), "twr_method": twr_method,
            "twr_range": twr_range, "twr_note": twr_note,
            "excluded_legacy_snapshots": excluded_legacy,
            "coverage_inferred_to": inferred_days[-1] if inferred_days else None,
            "valuation_timing": "快照 = 当日收盘后总资产 (含当日资金流)",
            "mwr_annualized": None if mwr is None else round(mwr, 6),
            "valuation_basis": "券商总资产快照 (as_of = 导入日期)",
            "usage": {"twr": "衡量投资决策本身, 可与基准比较", "mwr": "反映投入金额与时点对实际所得的影响"}}
