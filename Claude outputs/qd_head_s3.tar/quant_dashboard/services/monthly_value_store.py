"""
按自然月保存的"上月值" (2026-11-01 数据质量审计 #9)
=================================================
美/日/港 AIAE 的月度斜率原本拿"上一次调用的值"当作上月值: 每次请求都覆盖, 斜率变成相邻两次调用之差,
"加速上行/下行"信号基本不会触发; 港股冷启动时还会拿 2024-09 的历史快照当上月值, 产生虚假信号。

这里按月份保存每个月最后一次的读数, 上月值 = 严格早于当前月份的最近一个月的读数。
"""

from __future__ import annotations

import json
import os
from datetime import datetime
from typing import Dict, Optional

KEEP_MONTHS = 36


def _month(dt: Optional[datetime] = None) -> str:
    return (dt or datetime.now()).strftime("%Y-%m")


def _read(path: str) -> Dict[str, float]:
    if not os.path.exists(path):
        return {}
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
    except Exception:
        return {}
    months = data.get("months")
    if isinstance(months, dict):
        return {str(k): float(v) for k, v in months.items() if v is not None}
    # 旧格式 {"aiae_v1": x, "saved_at": iso}: 归入 saved_at 所在月份
    if data.get("aiae_v1") is not None and data.get("saved_at"):
        try:
            return {_month(datetime.fromisoformat(str(data["saved_at"]))): float(data["aiae_v1"])}
        except ValueError:
            return {}
    return {}


def load_prev_month(path: str, now: Optional[datetime] = None) -> Optional[float]:
    """严格早于当前月份的最近一个月的读数; 没有则 None (斜率记为持平, 不发信号)。"""
    cur = _month(now)
    earlier = sorted(m for m in _read(path) if m < cur)
    return _read(path)[earlier[-1]] if earlier else None


def save_month_value(path: str, value: float, now: Optional[datetime] = None, writer=None) -> None:
    """更新当前月份的读数 (同月多次调用只保留最后一次), 保留最近 KEEP_MONTHS 个月。"""
    months = _read(path)
    months[_month(now)] = float(value)
    keep = dict(sorted(months.items())[-KEEP_MONTHS:])
    payload = {"months": keep, "saved_at": (now or datetime.now()).isoformat()}
    if writer is not None:
        writer(payload, path)
        return
    tmp = f"{path}.tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(payload, f, ensure_ascii=False, indent=2)
    os.replace(tmp, path)


def prev_month_from_history(records, now: Optional[datetime] = None, key: str = "aiae") -> Optional[float]:
    """从按时间排序的历史记录 (含 'date': 'YYYY-MM-DD') 中取上个自然月 (及更早) 的最后一条读数。"""
    cur = _month(now)
    best = None
    for r in records:
        d = str(r.get("date", ""))[:7]
        if d and d < cur and r.get(key) is not None:
            best = float(r[key])
    return best
