"""
AlphaCore · 服务器写操作日志 (第 0 轮 0a-4, 2026-11-05)
=======================================================
方案见 docs/ROUND0_CI_EVALUATE_ONLY_PLAN.md 3.5。

- 范围: /api/ 下的 POST / PUT / PATCH / DELETE; GET / HEAD / OPTIONS 不记
- 位置: main.py 里注册在 ApiKeyMiddleware 之后 (= 外层), 401 / 403 也记得到
- 每条一行 JSON, 追加到 data_lake/audit/write_log-YYYY-MM.jsonl (按北京时间分月)
- 单个文件上限 20 MB: 超出后当月只追加一条 {"truncated": true} 并打 WARNING; 不自动删除旧文件
- 不记令牌: 从不读取 X-API-Key / Authorization 请求头的值; auth 只取 ApiKeyMiddleware 写的标记
- 不记请求体: 中间件不读请求体 (纯 ASGI, 不碰 receive), 只记 content-type / content-length;
  接口通过 request.state.write_log 附加自己的安全摘要 (文件名、字节数、行数、结果、错误码等)
- 写日志失败不影响请求本身: 打 ERROR 日志 (只有任务运行记录会统计 ERROR, 且只统计定时任务线程里的;
  HTTP 请求不在任务线程里, 不会被算成任务失败), 失败次数与最后一次错误留在 status() 里给审计页 (0a-6)

局限: 在容器里直接调用函数不经过 HTTP, 这个日志看不到 (CI 由 0a-1 的 direct 来源兜住, 其他靠固定规则 8)。
"""

import json
import os
import threading
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional
from urllib.parse import unquote_plus
from zoneinfo import ZoneInfo

from services.logger import get_logger

logger = get_logger("write_log")

PROJECT_ROOT = Path(__file__).resolve().parents[1]
WRITE_LOG_DIR = PROJECT_ROOT / "data_lake" / "audit"
FILE_PREFIX = "write_log-"
MAX_FILE_BYTES = 20 * 1024 * 1024
BJ = ZoneInfo("Asia/Shanghai")

WRITE_METHODS = frozenset({"POST", "PUT", "PATCH", "DELETE"})
API_PREFIX = "/api/"
# query 键名含这些词 (不分大小写) 的, 连键名也不记
SENSITIVE_QUERY_MARKERS = ("key", "token", "secret", "password", "auth")
HEADER_MAX = 200
# 只读这些请求头 (白名单); X-API-Key / Authorization 永远不在里面
_HEADER_FIELDS = {
    b"x-forwarded-for": "x_forwarded_for",
    b"user-agent": "user_agent",
    b"origin": "origin",
    b"referer": "referer",
    b"x-ac-caller": "caller",
    b"content-type": "content_type",
    b"content-length": "content_length",
}
DETAIL_STR_MAX = 200
DETAIL_MAX_ITEMS = 50
DETAIL_MAX_DEPTH = 4

_lock = threading.Lock()
_status = {
    "writes": 0,
    "failures": 0,
    "last_write_at": None,
    "last_error": None,
    "last_error_at": None,
    "truncated_files": [],
}


# ── 记录内容 ────────────────────────────────────────────────────────────

def _cut(value: Optional[str]) -> Optional[str]:
    return value[:HEADER_MAX] if value else None


def _query_keys(raw: bytes) -> tuple[list, int]:
    """只取键名 (不解码值); 敏感键连键名也不记, 只计数。"""
    keys, dropped = [], 0
    if not raw:
        return keys, dropped
    for part in raw.split(b"&"):
        if not part:
            continue
        name = unquote_plus(part.split(b"=", 1)[0].decode("latin-1"))[:HEADER_MAX]
        if any(m in name.lower() for m in SENSITIVE_QUERY_MARKERS):
            dropped += 1
        elif name not in keys:
            keys.append(name)
    return keys, dropped


def _headers(scope) -> dict:
    out = {v: None for v in _HEADER_FIELDS.values()}
    for name, value in scope.get("headers") or []:
        field = _HEADER_FIELDS.get(name.lower())
        if field and out[field] is None:
            out[field] = _cut(value.decode("latin-1"))
    if out["content_length"] is not None:
        try:
            out["content_length"] = int(out["content_length"])
        except ValueError:
            out["content_length"] = None
    return out


def _safe_detail(value: Any, depth: int = 0) -> Any:
    """接口附加的摘要只保留 JSON 标量 / 短字符串 / 小容器; 键名像令牌的丢掉。"""
    if depth > DETAIL_MAX_DEPTH:
        return "…"
    if value is None or isinstance(value, (bool, int, float)):
        return value
    if isinstance(value, str):
        return value[:DETAIL_STR_MAX]
    if isinstance(value, dict):
        out = {}
        for k, v in list(value.items())[:DETAIL_MAX_ITEMS]:
            k = str(k)[:DETAIL_STR_MAX]
            if any(m in k.lower() for m in ("token", "secret", "password", "api_key", "apikey", "x-api-key")):
                continue
            out[k] = _safe_detail(v, depth + 1)
        return out
    if isinstance(value, (list, tuple)):
        return [_safe_detail(v, depth + 1) for v in list(value)[:DETAIL_MAX_ITEMS]]
    return str(value)[:DETAIL_STR_MAX]


def build_entry(scope, status: Optional[int], duration_ms: float, state: dict,
                now: Optional[datetime] = None) -> dict:
    now_utc = (now or datetime.now(timezone.utc)).astimezone(timezone.utc)
    keys, dropped = _query_keys(scope.get("query_string") or b"")
    h = _headers(scope)
    client = scope.get("client")
    entry = {
        "ts_bj": now_utc.astimezone(BJ).isoformat(timespec="milliseconds"),
        "ts_utc": now_utc.isoformat(timespec="milliseconds"),
        "method": scope.get("method"),
        "path": (scope.get("path") or "")[:HEADER_MAX * 2],
        "query_keys": keys,
        "query_keys_omitted": dropped,
        "status": status,
        "duration_ms": round(float(duration_ms), 1),
        "client_host": client[0] if client else None,
        "x_forwarded_for": h["x_forwarded_for"],
        "user_agent": h["user_agent"],
        "origin": h["origin"],
        "referer": h["referer"],
        "caller": h["caller"],
        "auth": state.get("auth_result") or "unknown",
        "content_type": h["content_type"],
        "content_length": h["content_length"],
        "detail": _safe_detail(state.get("write_log")) if state.get("write_log") is not None else None,
    }
    return entry


# ── 存储 ────────────────────────────────────────────────────────────────

def log_path(now: Optional[datetime] = None) -> Path:
    now_bj = (now or datetime.now(timezone.utc)).astimezone(BJ)
    return Path(WRITE_LOG_DIR) / f"{FILE_PREFIX}{now_bj:%Y-%m}.jsonl"


def _tail_is_truncated(path: Path) -> bool:
    try:
        with path.open("rb") as fh:
            fh.seek(0, os.SEEK_END)
            size = fh.tell()
            fh.seek(max(0, size - 512))
            tail = fh.read().decode("utf-8", errors="ignore").strip().splitlines()
        if not tail:
            return False
        last = json.loads(tail[-1])
        return isinstance(last, dict) and last.get("truncated") is True
    except (OSError, ValueError):
        return False


def append_entry(entry: dict, now: Optional[datetime] = None) -> Path:
    """整行追加 (加锁; 服务器单 worker 进程)。超过上限只追加一次截断标记。失败抛出, 由调用方兜住。"""
    path = log_path(now)
    line = json.dumps(entry, ensure_ascii=False, separators=(",", ":"), default=str) + "\n"
    data = line.encode("utf-8")
    with _lock:
        path.parent.mkdir(parents=True, exist_ok=True)
        size = path.stat().st_size if path.exists() else 0
        if size + len(data) > MAX_FILE_BYTES:
            if _tail_is_truncated(path):
                return path
            marker = {"truncated": True, "ts_bj": entry.get("ts_bj"), "ts_utc": entry.get("ts_utc"),
                      "max_bytes": MAX_FILE_BYTES,
                      "note": "本月写操作日志已达上限, 之后的写操作本月不再记录"}
            data = (json.dumps(marker, ensure_ascii=False, separators=(",", ":")) + "\n").encode("utf-8")
            if path.name not in _status["truncated_files"]:
                _status["truncated_files"].append(path.name)
            logger.warning("写操作日志 %s 已达 %d MB 上限, 本月之后的写操作不再记录 (已追加截断标记)",
                           path.name, MAX_FILE_BYTES // (1024 * 1024))
        with path.open("ab") as fh:          # 一次 write 整行
            fh.write(data)
        _status["writes"] += 1
        _status["last_write_at"] = entry.get("ts_bj")
    return path


def record(entry: dict, now: Optional[datetime] = None) -> None:
    try:
        append_entry(entry, now)
    except Exception as exc:                 # 写日志失败不影响请求本身
        with _lock:
            _status["failures"] += 1
            _status["last_error"] = f"{type(exc).__name__}: {str(exc)[:200]}"
            _status["last_error_at"] = datetime.now(BJ).isoformat(timespec="seconds")
        logger.error("写操作日志写入失败 (请求不受影响): %s %s → %s",
                     entry.get("method"), entry.get("path"), _status["last_error"])


def status() -> dict:
    """审计页 (0a-6) 用: 写入次数、失败次数与最后一次错误、截断过的文件 (本进程启动以来)。"""
    with _lock:
        return {**_status, "truncated_files": list(_status["truncated_files"]),
                "dir": str(WRITE_LOG_DIR), "max_bytes": MAX_FILE_BYTES}


def attach(request, **detail) -> None:
    """接口附加安全摘要: request.state.write_log 合并 detail。只放文件名 / 字节数 / 行数 / 结果 / 错误码这类。"""
    if request is None:          # 直接调用路由函数 (测试) 时没有 request
        return
    try:
        current = getattr(request.state, "write_log", None) or {}
        current.update(detail)
        request.state.write_log = current
    except Exception:
        pass


def file_name(name: Optional[str]) -> Optional[str]:
    """上传文件名只留最后一段 (去掉浏览器可能带的路径), 截断 200 字。"""
    if not name:
        return None
    return str(name).replace("\\", "/").rsplit("/", 1)[-1][:DETAIL_STR_MAX]


def finish(request, resp, ok_result: str = "imported"):
    """按接口的 R.ok / R.error 结果补上 result / error_code, 原样返回 resp。"""
    try:
        if isinstance(resp, dict):
            if resp.get("status") == "success":
                attach(request, result=ok_result, error_code=None)
            else:
                attach(request, result="rejected", error_code=resp.get("code"))
    except Exception:
        pass
    return resp


# ── 中间件 ──────────────────────────────────────────────────────────────

class WriteLogMiddleware:
    """纯 ASGI 中间件: 不读请求体 (不碰 receive), 只从 http.response.start 取状态码。"""

    def __init__(self, app):
        self.app = app

    async def __call__(self, scope, receive, send):
        if (scope.get("type") != "http" or scope.get("method") not in WRITE_METHODS
                or not (scope.get("path") or "").startswith(API_PREFIX)):
            await self.app(scope, receive, send)
            return

        state = scope.setdefault("state", {})
        started = time.perf_counter()
        holder = {"status": None}

        async def _send(message):
            if message.get("type") == "http.response.start":
                holder["status"] = message.get("status")
            await send(message)

        try:
            await self.app(scope, receive, _send)
        except BaseException:
            if holder["status"] is None:
                holder["status"] = 500
            raise
        finally:
            try:
                entry = build_entry(scope, holder["status"], (time.perf_counter() - started) * 1000, state)
            except Exception as exc:
                entry = {"ts_utc": datetime.now(timezone.utc).isoformat(), "method": scope.get("method"),
                         "path": scope.get("path"), "status": holder["status"],
                         "build_error": f"{type(exc).__name__}"}
            record(entry)
