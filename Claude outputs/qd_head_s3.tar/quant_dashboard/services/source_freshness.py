"""Observation age follows publication cadence; no live network or future vintages.

H.10 publishes the previous business week's daily observations on Monday 16:15
New York time, shifted to the next federal business day on a federal holiday.
Source: https://www.federalreserve.gov/releases/h10/
"""
from datetime import datetime, time, timedelta, timezone
from functools import lru_cache
from zoneinfo import ZoneInfo

from pandas.tseries.holiday import USFederalHolidayCalendar

from services.multi_asset_policy import (
    H10_INGESTION_GRACE_HOURS, MAX_SOURCE_AGE_DAYS, finite_number,
)

_NY = ZoneInfo("America/New_York")
GOLD_SOURCES = {"real_rate": "DFII10", "dollar": "DTWEXBGS", "inflation": "DGS10_DFII10"}


@lru_cache(maxsize=32)
def _holidays(year):
    return frozenset(x.date() for x in USFederalHolidayCalendar().holidays(
        start=f"{year - 1}-12-01", end=f"{year + 1}-01-31"))


def _business_day(day):
    return day.weekday() < 5 and day not in _holidays(day.year)


def _release_at(monday):
    day = monday
    while not _business_day(day):
        day += timedelta(days=1)
    return datetime.combine(day, time(16, 15), tzinfo=_NY)


def _week_last_observation(monday):
    day = monday - timedelta(days=3)
    while not _business_day(day):
        day -= timedelta(days=1)
    return day


def h10_release_window(now=None):
    """Current completed batch and the next scheduled batch, including grace."""
    now = now or datetime.now(timezone.utc)
    if now.tzinfo is None:
        now = now.replace(tzinfo=timezone.utc)
    local_now = now.astimezone(_NY)
    monday = local_now.date() - timedelta(days=local_now.weekday())
    grace = timedelta(hours=H10_INGESTION_GRACE_HOURS)
    if local_now < _release_at(monday) + grace:
        monday -= timedelta(days=7)
    next_monday = monday + timedelta(days=7)
    return {"expected_observation_date": _week_last_observation(monday).isoformat(),
            "current_release_deadline_at": (_release_at(monday) + grace).isoformat(),
            "next_release_at": _release_at(next_monday).isoformat(),
            "next_expected_observation_date": _week_last_observation(next_monday).isoformat(),
            "following_release_at": _release_at(next_monday + timedelta(days=7)).isoformat()}


def evaluate_source_freshness(source_id, observed_at, *, now=None):
    now = now or datetime.now(timezone.utc)
    if now.tzinfo is None:
        now = now.replace(tzinfo=timezone.utc)
    local_now = now.astimezone(_NY)
    result = {"source_id": source_id, "usable": False, "status": "missing",
              "observation_date": None, "age_calendar_days": None,
              "expected_observation_date": None, "next_release_at": None,
              "release_deadline_at": None, "next_update_at": None,
              "release_cadence": "weekly" if source_id == "DTWEXBGS" else "daily",
              "reason": "观测日期缺失或无效"}
    try:
        observed = datetime.fromisoformat(str(observed_at).replace("Z", "+00:00")).date()
    except (TypeError, ValueError, OverflowError):
        return result
    age = (local_now.date() - observed).days
    result.update(observation_date=observed.isoformat(), age_calendar_days=age)
    if age < 0:
        result.update(status="future", reason="观测日期晚于来源当地日期")
        return result
    if source_id != "DTWEXBGS":
        usable = age <= MAX_SOURCE_AGE_DAYS
        result.update(usable=usable, status="on_schedule" if usable else "stale",
                      reason="日频观测有效" if usable else f"日频观测已超过 {MAX_SOURCE_AGE_DAYS} 天容忍度")
        return result

    window = h10_release_window(now)
    grace = timedelta(hours=H10_INGESTION_GRACE_HOURS)
    expected = datetime.fromisoformat(window["expected_observation_date"]).date()
    next_expected = datetime.fromisoformat(window["next_expected_observation_date"]).date()
    next_release = datetime.fromisoformat(window["next_release_at"])
    # New data already delivered during ingestion grace takes precedence.
    if local_now >= next_release and observed >= next_expected:
        expected = next_expected
        next_release = datetime.fromisoformat(window["following_release_at"])
    in_grace = next_release <= local_now < next_release + grace
    usable = observed >= expected
    status = ("stale" if not usable else "release_grace" if in_grace
              else "publication_lag" if age > MAX_SOURCE_AGE_DAYS else "on_schedule")
    reason = ({"stale": f"已错过应发布批次，预期至少覆盖 {expected.isoformat()}",
               "release_grace": "H.10 已到发布时间，处于 FRED 同步宽限期",
               "publication_lag": "日频观测按周发布，当前日期符合 H.10 发布周期",
               "on_schedule": "符合 H.10 周度发布周期"}[status])
    result.update(usable=usable, status=status, reason=reason,
                  expected_observation_date=expected.isoformat(),
                  next_release_at=next_release.isoformat(),
                  release_deadline_at=(next_release + grace).isoformat(),
                  next_update_at=(next_release + grace if in_grace else next_release).isoformat())
    return result


def gold_source_diagnostics(gold, *, now=None):
    """Re-evaluate component dates at every consuming layer, including cache hits."""
    gold = gold if isinstance(gold, dict) else {}
    components = gold.get("components")
    if not isinstance(components, dict) or not components:
        # Legacy reports without component provenance keep the stricter daily rule.
        state = evaluate_source_freshness("DFII10", gold.get("data_as_of"), now=now)
        return {"usable": state["usable"], "sources": {},
                "reasons": [] if state["usable"] else [state["reason"]]}
    sources, reasons = {}, []
    for key, source_id in GOLD_SOURCES.items():
        comp = components.get(key)
        comp = comp if isinstance(comp, dict) else {}
        state = evaluate_source_freshness(source_id, comp.get("data_as_of"), now=now)
        if not finite_number(comp.get("score"), -100, 100):
            was_usable = state["usable"]
            state.update(usable=False, status="insufficient_history" if was_usable else state["status"],
                         reason="有效历史不足或待重新计算" if was_usable else state["reason"])
        sources[key] = state
        if not state["usable"]:
            reasons.append(f"{source_id}：{state['reason']}")
    return {"usable": not reasons, "sources": sources, "reasons": reasons}


def gold_result_is_usable(gold, *, now=None):
    if not isinstance(gold, dict):
        return False
    quality = gold.get("quality")
    return (gold.get("status") == "success" and isinstance(quality, dict)
            and quality.get("usable") is True and finite_number(gold.get("gold_signal"), -100, 100)
            and gold_source_diagnostics(gold, now=now)["usable"])
