"""
AlphaCore · AIAE β 敞口对接 (P1-a, 2026-10-30)
==============================================
AIAE × ERP 矩阵给出的仓位上限, 是按"沪深300 这类大盘 β"标定的 (ERP v4 文档同样写明只适用于大盘仓位)。
同样 90% 的名义仓位, 放在宽基 ETF 和放在半导体个股上, 对大盘的风险暴露相差 1.5 倍以上。

本模块把两者放到同一把尺子上:
    有效 β 敞口 = Σ (持仓权重_占总资产 × β_沪深300)
    β 预算     = AIAE 矩阵上限 (把它理解为"相当于多少 % 的沪深300 风险")
    差额       = 有效 β 敞口 − β 预算

β 直接复用 services/portfolio_vol (250 日窗口对沪深300 回归; 行情不足的持仓用同类中位数填充),
不另建模型, 保证与组合风险面板同一口径。

定位: 只读读数 (binding=False)。不改变决策页的有效上限与结论, 不生成交易指令;
      前向观察一段时间、确认口径稳定后, 再决定是否纳入约束 (见 docs/AIAE_OPTIMIZATION_PLAN.md)。
"""
from __future__ import annotations

import math
from typing import Any, Mapping, Optional

SCHEMA = "aiae_beta_exposure/1"

# 判定档位 (pp, 有效 β 敞口 − β 预算), 与 portfolio_vol._verdict 的偏离分档保持一致
GAP_DANGER = 10.0
GAP_WARNING = 5.0
GAP_ROOM = -5.0
TOP_N = 5


def _num(v) -> Optional[float]:
    try:
        x = float(v)
    except (TypeError, ValueError):
        return None
    return x if math.isfinite(x) else None


def _verdict(gap: Optional[float]) -> tuple[str, str]:
    if gap is None:
        return "unknown", "数据不足"
    if gap > GAP_DANGER:
        return "danger", f"β 敞口超出预算 {gap:.0f}pp"
    if gap > GAP_WARNING:
        return "warning", f"β 敞口略超预算 {gap:.0f}pp"
    if gap >= GAP_ROOM:
        return "ok", "β 敞口与预算基本一致"
    return "room", f"β 敞口低于预算 {-gap:.0f}pp"


def build_beta_exposure(portfolio: Optional[Mapping[str, Any]],
                        aiae_ctx: Optional[Mapping[str, Any]]) -> dict:
    """组合风险结果 (portfolio_vol.compute_from_store) + AIAE 上下文 (aiae_safety.build_aiae_context) → β 敞口读数。

    纯函数, 不读文件、不联网。任一输入不可用时返回 status="insufficient" 并说明原因。
    """
    pf = dict(portfolio or {})
    ctx = dict(aiae_ctx or {})
    caveats: list[str] = []

    locked = ctx.get("decision_locked") is not False
    budget = None if locked else _num(ctx.get("base_cap", ctx.get("cap")))
    if locked:
        caveats.append("AIAE 决策锁定或缺失, 无 β 预算可比")

    pf_ok = pf.get("status") in ("ok", "partial")
    positions = [p for p in (pf.get("positions") or []) if isinstance(p, Mapping)] if pf_ok else []
    if not pf_ok:
        caveats.append(pf.get("message") or "无持仓风险数据 (请先在持仓页导入资金股份查询)")

    rows = []
    for p in positions:
        w = _num(p.get("weight_pct"))
        b = _num(p.get("beta_mkt"))
        if w is None or b is None:
            continue
        rows.append({
            "ts_code": p.get("ts_code"), "name": p.get("name"), "bucket": p.get("bucket"),
            "weight_pct": round(w, 2), "beta_mkt": round(b, 2),
            "contribution_pct": round(w * b, 2),
            # 行情不足时 portfolio_vol 用同类中位数 / 默认值填充 β
            "estimated": p.get("vol_source") == "proxy",
        })

    nominal = round(sum(r["weight_pct"] for r in rows), 1) if rows else None
    effective = round(sum(r["contribution_pct"] for r in rows), 1) if rows else None
    port_beta = round(effective / nominal, 2) if nominal and effective is not None and nominal > 0 else None
    gap = round(effective - budget, 1) if effective is not None and budget is not None else None
    nominal_at_budget = (round(budget / port_beta, 1)
                         if budget is not None and port_beta is not None and port_beta > 0 else None)
    level, verdict = _verdict(gap)

    est_w = round(sum(r["weight_pct"] for r in rows if r["estimated"]), 1) if rows else 0.0
    if rows and est_w > 0:
        caveats.append(f"{est_w:.0f}% 仓位行情不足, β 为同类中位数估计")
    if pf.get("status") == "partial":
        caveats.append("组合风险数据为部分覆盖 (status=partial), 读数偏粗")
    dq = pf.get("data_quality") or {}
    if (dq.get("positions_age_days") or 0) > 3:
        caveats.append(f"持仓快照已 {dq['positions_age_days']} 天未更新")
    if port_beta is not None and port_beta < 0.8:
        caveats.append("组合 β 偏低 (红利/类现金为主), 按 β 折算后名义仓位可能高于 AIAE 上限, 但上限本身不放宽")

    buckets: dict[str, dict] = {}
    for r in rows:
        b = buckets.setdefault(r["bucket"] or "其他", {"bucket": r["bucket"] or "其他",
                                                       "weight_pct": 0.0, "contribution_pct": 0.0})
        b["weight_pct"] += r["weight_pct"]
        b["contribution_pct"] += r["contribution_pct"]
    by_bucket = sorted(({**b, "weight_pct": round(b["weight_pct"], 1),
                         "contribution_pct": round(b["contribution_pct"], 1)} for b in buckets.values()),
                       key=lambda x: -x["contribution_pct"])
    top = sorted(rows, key=lambda r: -r["contribution_pct"])[:TOP_N]

    return {
        "status": "ok" if gap is not None else "insufficient",
        "schema": SCHEMA,
        "binding": False,
        "budget_pct": budget,
        "regime": ctx.get("regime"),
        "regime_cn": ctx.get("regime_cn"),
        "nominal_pct": nominal,
        "effective_beta_pct": effective,
        "portfolio_beta": port_beta,
        "gap_pp": gap,
        "nominal_at_budget_pct": nominal_at_budget,
        "level": level,
        "verdict": verdict,
        "estimated_weight_pct": est_w,
        "by_bucket": by_bucket,
        "top_contributors": top,
        "positions_asof": pf.get("as_of"),
        "price_asof": dq.get("price_asof"),
        "caveats": caveats,
        "method": [
            "有效 β 敞口 = Σ 持仓权重(占总资产) × β(对沪深300)",
            "β: 250 日日收益对沪深300 回归 (portfolio_vol 同一口径); 行情不足用同类中位数",
            "β 预算 = AIAE 矩阵上限, 理解为相当于多少 % 的沪深300 风险",
            "只读读数: 不改变有效上限与结论, 不生成交易指令",
        ],
    }
