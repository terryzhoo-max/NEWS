"""
M2 数据源 (2026-11-01, 数据质量审计 #4)
======================================
替代已停更的 FRED IMF 序列:
  - MYAGM2CNM189N (中国 M2) 最后观测 2019-08
  - MYAGM2JPM189N (日本 M2) 最后观测 2017-02
两者在 FRED 上取不到近 180 天数据, 港股/日股 AIAE 长期落到硬编码常数。

中国 M2: 复用 A 股 AIAE 的 tushare cn_m (人民银行官方, 亿元, 次月中旬发布)
日本 M2: 日本银行时系列统计 API (2026-02-18 开放, 免注册)
         db=MD02, code=MAM1NAM2M2MO (M2 平残, 单位 1 亿日元, 月频)
"""

from __future__ import annotations

import logging
from datetime import date
from typing import Any, Optional

logger = logging.getLogger("alphacore.m2_sources")

BOJ_API = "https://www.stat-search.boj.or.jp/api/v1/getDataCode"
BOJ_M2_DB = "MD02"
BOJ_M2_CODE = "MAM1NAM2M2MO"
M2_STALE_MONTHS = 3  # M2 次月中下旬发布; 统计月距今超过 3 个月视为过期


def normalize_month(m: Any) -> Optional[str]:
    """'202609' / 202609 / '2026-09' / '2026-09-01' → '2026-09'。"""
    if m is None:
        return None
    s = str(m).strip().replace("/", "-")
    if len(s) >= 7 and s[4] == "-":
        return s[:7]
    digits = "".join(ch for ch in s if ch.isdigit())
    if len(digits) >= 6:
        return f"{digits[:4]}-{digits[4:6]}"
    return None


def months_since(month: Optional[str], today: Optional[date] = None) -> Optional[int]:
    m = normalize_month(month)
    if not m:
        return None
    today = today or date.today()
    y, mo = int(m[:4]), int(m[5:7])
    return (today.year - y) * 12 + (today.month - mo)


def is_stale(month: Optional[str], today: Optional[date] = None) -> bool:
    n = months_since(month, today)
    return n is None or n > M2_STALE_MONTHS


# ───────────────────────── 日本银行 API ─────────────────────────

def _find_series(node: Any, code: str):
    """在 BOJ JSON 中找到指定系列的 (日期列表, 数值列表)。兼容数值平铺或嵌套在 VALUES 字典两种结构。"""
    if isinstance(node, dict):
        if str(node.get("SERIES_CODE", "")).upper() == code.upper():
            dates, vals = node.get("SURVEY_DATES"), node.get("VALUES")
            if isinstance(vals, dict):
                dates = vals.get("SURVEY_DATES", dates)
                vals = vals.get("VALUES")
            if isinstance(dates, list) and isinstance(vals, list):
                return dates, vals
        for v in node.values():
            found = _find_series(v, code)
            if found:
                return found
    elif isinstance(node, list):
        for v in node:
            found = _find_series(v, code)
            if found:
                return found
    return None


def parse_boj_series(payload: Any, code: str = BOJ_M2_CODE) -> Optional[dict]:
    """返回最新一个非空观测 {'month', 'value'}; 状态非 200 或找不到系列时返回 None。"""
    if isinstance(payload, dict) and str(payload.get("STATUS", "200")) != "200":
        logger.warning("BOJ API 状态 %s: %s", payload.get("STATUS"), payload.get("MESSAGE"))
        return None
    found = _find_series(payload, code)
    if not found:
        return None
    dates, vals = found
    for d, v in reversed(list(zip(dates, vals))):
        if v is None:
            continue
        try:
            return {"month": normalize_month(d), "value": float(v)}
        except (TypeError, ValueError):
            continue
    return None


def fetch_boj_jp_m2(timeout: float = 10.0, start_yyyymm: Optional[str] = None) -> Optional[dict]:
    """日本 M2 平残最新值。返回 {'month', 'm2_100m_yen', 'm2_trillion_jpy', 'source'}; 失败返回 None。"""
    try:
        import requests
        if start_yyyymm is None:
            t = date.today()
            y, m = (t.year, t.month - 8) if t.month > 8 else (t.year - 1, t.month + 4)
            start_yyyymm = f"{y:04d}{m:02d}"
        r = requests.get(BOJ_API, timeout=timeout, headers={"Accept-Encoding": "gzip"}, params={
            "format": "json", "lang": "en", "db": BOJ_M2_DB, "code": BOJ_M2_CODE, "startDate": start_yyyymm})
        r.raise_for_status()
        latest = parse_boj_series(r.json(), BOJ_M2_CODE)
        if not latest:
            return None
        v = latest["value"]  # 单位: 1 亿日元
        return {"month": latest["month"], "m2_100m_yen": v,
                "m2_trillion_jpy": round(v / 10000.0, 1), "source": "boj_api"}
    except Exception as e:  # noqa: BLE001
        logger.warning("BOJ M2 获取失败: %s", e)
        return None


# ───────────────────────── 中国 M2 (复用 A 股 AIAE) ─────────────────────────

def fetch_cn_m2() -> Optional[dict]:
    """中国 M2, 来自 A 股 AIAE 引擎的 tushare cn_m (同一份数据, 同一缓存)。
    返回 {'month', 'm2_trillion_rmb', 'is_fallback', 'source'}; 失败返回 None。"""
    try:
        from engines.aiae_engine import get_aiae_engine
        d = get_aiae_engine()._fetch_m2()
        if not d or not d.get("m2_wan_yi"):
            return None
        return {"month": normalize_month(d.get("month")), "m2_trillion_rmb": float(d["m2_wan_yi"]),
                "m2_yoy": d.get("m2_yoy"), "is_fallback": bool(d.get("is_fallback", False)),
                "source": "tushare_cn_m"}
    except Exception as e:  # noqa: BLE001
        logger.warning("中国 M2 (A 股 AIAE) 获取失败: %s", e)
        return None
