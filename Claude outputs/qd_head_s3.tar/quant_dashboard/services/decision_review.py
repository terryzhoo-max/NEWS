"""
AlphaCore · 决策复盘比较 (方案 B 阶段4B-1, 2026-10-29)
====================================================

一、组合区间比较 (同一起点、同一口径):
    实际操作            期初风险资产 + 区间内真实成交 (卖出所得留作现金, 买入从现金支付)
    维持期初组合        期初持仓数量不变
    定期再平衡          每月首个交易日按期初权重再平衡 (未计再平衡交易费用)
  口径: 期初风险资产市值为起点; 区间内入金/出金、现金利息不计入 (三条路径相同),
        成交现金按台账金额与费用; 日收益用复权收盘 (拆分/分红连续化, 同 services/drawdown)。
  性质: return_basis = risk_asset_twr 的"自融资"变体 —— 衡量交易决策本身, 不是整账户收益。

二、单条决定复盘:
  · 采用且已关联成交: 与"不做这些成交"比较 (卖出所得 − 若继续持有的价值; 买入后价值 − 买入成本)。
  · 未采用 / 暂不行动 (有代码与买卖方向): "若当时执行"的方向性对照, 只给涨跌幅, 明确标为假设。
  · 采用但未关联成交、维持不动: 不评价。事后补记 (retrospective) 单列, 不计入汇总。

不足以评价 (insufficient) 时不输出数字: 交易日不足、期初持仓未知 (早于成交台账)、缺行情。
本模块只读, 不改持仓、不下单。
"""
from __future__ import annotations

from datetime import date, timedelta
from typing import Any, Callable, Mapping, Optional

import numpy as np
import pandas as pd

from services.decision_policy import parse_day
from services.return_basis import basis_meta

MIN_TRADING_DAYS = 20
SMALL_SAMPLE = 10
SELF_FINANCING_TOL = 0.05          # 区间内净买入超过期初风险资产 5% → 实际收益率不可比, 只给增减值


def _bars(loader: Callable[[str], Any], code: str) -> Optional[pd.DataFrame]:
    from services.trailing_stop import normalize_bars
    try:
        b = loader(code)
        if b is None or len(b) == 0:
            return None
        nb = normalize_bars(b)
        out = pd.DataFrame({"close": nb["close"]})
        out["raw_close"] = nb["raw_close"] if "raw_close" in nb.columns else nb["close"]
        return out.dropna()
    except Exception:  # noqa: BLE001
        return None


def _insufficient(reason: str, **extra) -> dict:
    return {"status": "insufficient", "label": "不足以评价", "reason": reason, **extra}


def _mdd(path: pd.Series) -> Optional[float]:
    if path is None or len(path) < 2 or (path <= 0).any():
        return None
    return round(float((path / path.cummax() - 1).min()), 4)


def _trade_cash(t: Mapping[str, Any]) -> tuple[float, bool]:
    """→ (现金变动, 费用未知)。卖出 +(金额−费用), 买入 −(金额+费用)。"""
    amt = float(t.get("amount") or 0.0)
    fees = t.get("fees")
    unknown = fees is None
    f = 0.0 if unknown else float(fees)
    return ((amt - f) if t.get("side") == "sell" else -(amt + f)), unknown


# ═══════════════════════════════════════════════════════
#  一、组合区间比较
# ═══════════════════════════════════════════════════════

def portfolio_comparison(start: str, end: Optional[str], *, end_holdings: Mapping[str, float],
                         snapshot_date: Optional[str], trades: list[Mapping[str, Any]],
                         loader: Callable[[str], Any], min_days: int = MIN_TRADING_DAYS) -> dict:
    from services.drawdown import holdings_history
    meta = basis_meta("risk_asset_twr", variant="self_financing_comparison",
                      note="期初风险资产为起点, 区间内入出金与现金利息不计; 三条路径同口径")
    trades = [t for t in trades if t.get("ts_code") and t.get("qty") and t.get("date")]
    ledger_start = min((t["date"] for t in trades), default=None)
    codes = sorted({c for c, q in end_holdings.items() if q} | {t["ts_code"] for t in trades})
    frames = {c: _bars(loader, c) for c in codes}
    closes = {c: f["close"] for c, f in frames.items() if f is not None}
    if not closes:
        return {**meta, **_insufficient("无本地行情")}
    P = pd.DataFrame(closes).sort_index()
    RAW = pd.DataFrame({c: frames[c]["raw_close"] for c in closes}).sort_index()
    s_day = pd.Timestamp(start)
    if ledger_start:
        pre = P.index[P.index < pd.Timestamp(ledger_start)]
        earliest = pre[-1] if len(pre) else P.index[0]
        if s_day < earliest:
            return {**meta, **_insufficient(f"期初持仓未知: 成交台账自 {ledger_start} 起, 起点不能早于其前一交易日",
                                             earliest_start=earliest.date().isoformat())}
    all_dates = P.index[P.index >= s_day]
    if len(all_dates) == 0:
        return {**meta, **_insufficient("起点之后无行情")}
    H_all = holdings_history(all_dates, end_holdings, trades, snapshot_date)

    def needed(e: pd.Timestamp) -> tuple[pd.DatetimeIndex, list, list]:
        ds = all_dates[all_dates <= e]
        if len(ds) == 0:
            return ds, [], []
        hw = H_all.reindex(ds).fillna(0.0)
        tw = [t for t in trades if ds[0] < pd.Timestamp(t["date"]) <= ds[-1]]
        return ds, tw, sorted({c for c in hw.columns if hw[c].iloc[0] > 0 or hw[c].iloc[-1] > 0}
                              | {t["ts_code"] for t in tw})

    if end:
        e_day, end_rule = pd.Timestamp(end), "指定"
    else:   # 默认终点: 区间内相关标的都有收盘价的最后一个交易日 (各标的行情更新日可能不同)
        e_day, end_rule = all_dates[-1], "相关标的共同最新行情日"
        for _ in range(3):
            _, _, need0 = needed(e_day)
            lasts = [P[c].last_valid_index() for c in need0 if c in P.columns and P[c].last_valid_index() is not None]
            new_e = min(lasts + [e_day])
            if new_e == e_day:
                break
            e_day = new_e
    dates, in_window, need = needed(e_day)
    if len(dates) < min_days + 1:
        return {**meta, **_insufficient(f"区间仅 {max(len(dates) - 1, 0)} 个交易日, 少于 {min_days}",
                                         trading_days=max(len(dates) - 1, 0))}
    H = H_all.reindex(dates).fillna(0.0)
    Pw, RAWw = P.reindex(index=dates, columns=H.columns), RAW.reindex(index=dates, columns=H.columns)
    # 上市前成交 (新股中签/配售): 上市前没有市场价, 按成交价 (发行价) 计值, 上市首日起用收盘价
    prelisting = []
    for c in need:
        if c not in closes or P[c].first_valid_index() is None:
            continue
        first = P[c].first_valid_index()
        pre = [t for t in trades if t["ts_code"] == c and pd.Timestamp(t["date"]) < first]
        if not pre:
            continue
        t0 = min(pre, key=lambda t: (t["date"], t.get("time", "")))
        mask = (dates >= pd.Timestamp(t0["date"])) & (dates < first)
        if not mask.any():
            continue
        price = float(t0["price"])
        fac = float(P[c].loc[first] / RAW[c].loc[first]) if RAW[c].loc[first] else 1.0
        Pw.loc[mask, c] = price * fac
        RAWw.loc[mask, c] = price
        prelisting.append(f"{c} 上市前 ({t0['date']} 至 {first.date()} 前) 按成交价 {price:g} 计值")
    gaps, detail = [], []
    for c in need:
        if c not in closes:
            gaps.append(c)
            detail.append({"ts_code": c, "missing": "无本地行情文件"})
            continue
        s_c = P[c].dropna()
        rng = f"{s_c.index[0].date()}~{s_c.index[-1].date()}" if len(s_c) else "空"
        sides = []
        if H[c].iloc[0] > 0 and pd.isna(Pw[c].iloc[0]):
            sides.append(f"起点 {dates[0].date()}")
        if (H[c].iloc[-1] > 0 or H[c].iloc[0] > 0) and pd.isna(Pw[c].ffill().iloc[-1]):
            sides.append(f"终点 {dates[-1].date()}")
        for t in in_window:
            if t["ts_code"] == c and pd.isna(Pw[c].ffill().get(pd.Timestamp(t["date"]))):
                sides.append(f"成交日 {t['date']}")
                break
        if sides:
            gaps.append(c)
            detail.append({"ts_code": c, "missing": "、".join(sides), "local_range": rng})
    if gaps:
        return {**meta, **_insufficient("区间内缺行情: " + "; ".join(
            f"{d['ts_code']} 缺{d['missing']}" + (f" (本地行情 {d['local_range']})" if d.get("local_range") else "")
            for d in detail), missing_prices=gaps, missing_detail=detail,
            window={"from": dates[0].date().isoformat(), "to": dates[-1].date().isoformat()})}
    stale_end = [f"{c} 终点沿用 {Pw[c].last_valid_index().date()} 收盘" for c in need
                 if c in Pw.columns and Pw[c].last_valid_index() is not None and Pw[c].last_valid_index() < dates[-1]
                 and (H[c].iloc[-1] > 0 or H[c].iloc[0] > 0)]
    Pw = Pw.ffill()
    q0 = H.iloc[0]
    v0 = float((q0 * RAWw.iloc[0]).sum(min_count=1) or 0.0)
    if v0 <= 0:
        return {**meta, **_insufficient("期初无风险资产持仓")}

    rets = (Pw / Pw.shift(1) - 1).fillna(0.0)
    # 维持期初组合
    w_hold = (q0 * Pw.iloc[0]) / float((q0 * Pw.iloc[0]).sum())
    hold = [v0]
    w = w_hold.copy()
    for i in range(1, len(dates)):
        r = float((w * rets.iloc[i]).sum())
        hold.append(hold[-1] * (1 + r))
        g = w * (1 + rets.iloc[i])
        w = g / g.sum() if g.sum() > 0 else g
    # 定期再平衡 (每月首个交易日回到期初权重)
    reb = [v0]
    w = w_hold.copy()
    rebalances = 0
    for i in range(1, len(dates)):
        if dates[i].month != dates[i - 1].month:
            w = w_hold.copy()
            rebalances += 1
        r = float((w * rets.iloc[i]).sum())
        reb.append(reb[-1] * (1 + r))
        g = w * (1 + rets.iloc[i])
        w = g / g.sum() if g.sum() > 0 else g
    # 实际: 持仓市值按上一日持仓的复权收益滚动; 成交日按当日收盘价把成交数量计入/移出市值,
    #       现金按台账金额与费用变动 (成交价与收盘价之差因此计入结果)
    by_day: dict[pd.Timestamp, list] = {}
    for t in in_window:
        by_day.setdefault(pd.Timestamp(t["date"]), []).append(t)
    mv, cash, fees_unknown, min_cash = v0, 0.0, 0, 0.0
    actual = [v0]
    for i in range(1, len(dates)):
        prev_h = H.iloc[i - 1]
        base = float((prev_h * Pw.iloc[i - 1]).sum())
        r = float((prev_h * (Pw.iloc[i] - Pw.iloc[i - 1])).sum() / base) if base > 0 else 0.0
        mv *= (1 + r)
        for t in by_day.get(dates[i], []):
            c, unk = _trade_cash(t)
            fees_unknown += unk
            close_raw = RAWw[t["ts_code"]].iloc[i]
            close_raw = float(close_raw) if pd.notna(close_raw) else float(t.get("price") or 0.0)
            v = float(t["qty"]) * close_raw
            mv += v if t.get("side") == "buy" else -v
            cash += c
        min_cash = min(min_cash, cash)
        actual.append(mv + cash)
    idx = [d.date().isoformat() for d in dates]
    paths = {"actual": pd.Series(actual, index=dates), "hold": pd.Series(hold, index=dates),
             "rebalance": pd.Series(reb, index=dates)}
    external_funding = -min_cash / v0
    self_financed = external_funding <= SELF_FINANCING_TOL

    def summary(key: str, label: str) -> dict:
        s = paths[key]
        ret = float(s.iloc[-1] / v0 - 1)
        comparable = key != "actual" or self_financed
        return {"key": key, "label": label, "end_value": round(float(s.iloc[-1]), 2),
                "return": round(ret, 6) if comparable else None, "max_drawdown": _mdd(s) if comparable else None}

    rows = [summary("actual", "实际操作"), summary("hold", "维持期初组合"),
            summary("rebalance", "每月再平衡到期初权重")]
    added_vs_hold = round(float(paths["actual"].iloc[-1] - paths["hold"].iloc[-1]), 2)
    added_vs_reb = round(float(paths["actual"].iloc[-1] - paths["rebalance"].iloc[-1]), 2)
    caveats = ["区间内入金/出金、现金利息不计入 (三条路径相同)", "再平衡路径未计交易费用"]
    if prelisting:
        caveats.append("新股/上市前成交: " + "; ".join(prelisting) + "; 上市首日涨跌计入实际路径")
    if stale_end:
        caveats.append("行情未更新到终点: " + "; ".join(stale_end))
    if fees_unknown:
        caveats.append(f"{fees_unknown} 笔成交费用未知, 按 0 计, 实际路径偏乐观")
    adj = [c for c in need if c in RAWw.columns and (RAWw[c] / Pw[c]).dropna().pipe(
        lambda r: len(r) > 1 and float(r.max() / r.min()) > 1.003)]
    if adj:
        caveats.append("区间内有拆分/分红除权: " + ", ".join(adj) + "; 成交台账回滚不调整份额, 期初市值可能有偏差")
    if not self_financed:
        caveats.append(f"区间内净买入约为期初风险资产的 {external_funding:.0%}, 动用了额外资金; "
                       "实际收益率不与基准比较, 只看增减值")
    return {**meta, "status": "ok", "from": idx[0], "to": idx[-1], "end_rule": end_rule,
            "trading_days": len(dates) - 1,
            "start_value": round(v0, 2), "trades_in_window": len(in_window), "rebalances": rebalances,
            "paths": rows, "value_added_vs_hold": added_vs_hold, "value_added_vs_rebalance": added_vs_reb,
            "value_added_vs_hold_pct": round(added_vs_hold / v0, 6),
            "self_financed": self_financed, "caveats": caveats,
            "curve": {"d": idx, **{k: [round(float(v) / v0, 5) for v in s] for k, s in paths.items()}}}


# ═══════════════════════════════════════════════════════
#  二、单条决定复盘
# ═══════════════════════════════════════════════════════

def _eval_window(rec: Mapping[str, Any], last_px: date) -> tuple[date, date, bool]:
    """→ (起点, 评估日, 是否中期读数)。目标日 = 复盘日 或 决定日 + 预期持有期; 未到则用最新行情并标中期。"""
    start = parse_day(rec.get("decided_on")) or parse_day(rec.get("created_at")) or last_px
    target = parse_day(rec.get("review_after"))
    if target is None and rec.get("expected_holding_days"):
        target = start + timedelta(days=int(rec["expected_holding_days"]))
    if target is None or target > last_px:
        return start, last_px, target is not None and target > last_px
    return start, target, False


def _px_on_or_after(s: pd.Series, d: date) -> Optional[tuple[pd.Timestamp, float]]:
    after = s[s.index >= pd.Timestamp(d)]
    return (after.index[0], float(after.iloc[0])) if len(after) else None


def _px_on_or_before(s: pd.Series, d: date) -> Optional[tuple[pd.Timestamp, float]]:
    before = s[s.index <= pd.Timestamp(d)]
    return (before.index[-1], float(before.iloc[-1])) if len(before) else None


def review_decision(rec: Mapping[str, Any], linked_trades: list[Mapping[str, Any]],
                    loader: Callable[[str], Any], min_days: int = MIN_TRADING_DAYS) -> dict:
    status = rec.get("status")
    kind = "journal" if rec.get("kind") == "journal" else "mr_plan" if status == "planned" else "other"
    base = {"decision_id": rec.get("id"), "decision_status": status, "kind": kind,
            "retrospective": bool(rec.get("retrospective")), "intent": rec.get("intent") or rec.get("side")}
    intent = rec.get("intent") or rec.get("side")
    codes = list(rec.get("codes") or ([rec["code"]] if rec.get("code") else []))
    if intent == "hold" or not codes:
        return {**base, "evaluation": "not_applicable", "label": "维持不动或无标的, 不做收益复盘"}
    if status in ("adopted", "planned"):
        if not linked_trades:
            return {**base, "evaluation": "not_applicable", "label": "未关联成交, 无法评价执行效果"}
        return {**base, **_as_eval(_review_executed(rec, linked_trades, loader, min_days))}
    if status in ("not_adopted", "deferred") and intent in ("buy", "sell", "rebalance"):
        return {**base, **_as_eval(_review_hypothetical(rec, codes, intent, loader, min_days))}
    return {**base, "evaluation": "not_applicable", "label": "该类记录不做收益复盘"}


def _as_eval(res: dict) -> dict:
    res = dict(res)
    if res.pop("status", None) == "insufficient":
        res["status_eval"] = "insufficient"
    return res


def _review_executed(rec, trades, loader, min_days) -> dict:
    bars = {c: _bars(loader, c) for c in {t["ts_code"] for t in trades}}
    missing = [c for c, b in bars.items() if b is None]
    if missing:
        return _insufficient("缺行情: " + ", ".join(missing), evaluation="executed_vs_not_trading")
    last_px = min(b.index[-1] for b in bars.values()).date()
    start, eval_day, interim = _eval_window(rec, last_px)
    first_fill = min(parse_day(t["date"]) for t in trades)
    items, total, notional, fees_unknown = [], 0.0, 0.0, 0
    for t in trades:
        frame = bars[t["ts_code"]]
        b, raw = frame["close"], frame["raw_close"]
        tday = pd.Timestamp(parse_day(t["date"]))
        t1 = _px_on_or_before(b, eval_day)
        if tday not in b.index or t1 is None or t1[0] < tday:
            return _insufficient(f"{t['ts_code']} 成交日 {t['date']} 或评估日无行情", evaluation="executed_vs_not_trading")
        # 衔接: 成交价 → 成交日原始收盘 (当日价差) → 评估日 (复权收益, 含其后分红/拆分)
        close_raw, adj0 = float(raw.loc[tday]), float(b.loc[tday])
        growth = t1[1] / adj0
        qty, price = float(t["qty"]), float(t["price"])
        cash, unk = _trade_cash(t)
        fees_unknown += unk
        held_value = qty * close_raw * growth          # 这些股份若持有到评估日的价值
        # 卖出: 所得 − 若继续持有的价值; 买入: 持有价值 − 买入成本 (cash 为负, 已含费用)
        diff = (cash - held_value) if t["side"] == "sell" else (held_value + cash)
        items.append({"trade_key": t.get("key"), "ts_code": t["ts_code"], "side": t["side"], "date": t["date"],
                      "fill_vs_close": round(close_raw / price - 1, 6) if price else None,
                      "price_change_after": round(growth - 1, 6), "value_added": round(diff, 2)})
        total += diff
        notional += qty * price
    days = int(((bars[trades[0]["ts_code"]].index > pd.Timestamp(first_fill))
                & (bars[trades[0]["ts_code"]].index <= pd.Timestamp(eval_day))).sum())
    if days < min_days:
        return _insufficient(f"首笔成交后仅 {days} 个交易日, 少于 {min_days}", evaluation="executed_vs_not_trading",
                             trading_days=days, interim=interim)
    caveats = ["成交价至成交日收盘的价差计入; 其后按复权收盘收益推算 (分红再投资、拆分连续化)"]
    if fees_unknown:
        caveats.append(f"{fees_unknown} 笔成交费用未知, 按 0 计")
    return {"evaluation": "executed_vs_not_trading", "status_eval": "ok",
            "label": "与不做这些成交相比" + ("（中期读数, 持有期未到）" if interim else ""),
            "from": first_fill.isoformat(), "to": eval_day.isoformat(), "trading_days": days, "interim": interim,
            "value_added": round(total, 2), "value_added_pct_of_notional": round(total / notional, 6) if notional else None,
            "items": items, "caveats": caveats}


def _review_hypothetical(rec, codes, intent, loader, min_days) -> dict:
    out, days_min = [], None
    for c in codes:
        b = _bars(loader, c)
        if b is None:
            return _insufficient(f"缺行情: {c}", evaluation="hypothetical_direction")
        s = b["close"]
        start, eval_day, interim = _eval_window(rec, s.index[-1].date())
        p0, p1 = _px_on_or_after(s, start), _px_on_or_before(s, eval_day)
        if p0 is None or p1 is None or p1[0] <= p0[0]:
            return _insufficient(f"{c} 决定日之后行情不足", evaluation="hypothetical_direction")
        days = int(((s.index > p0[0]) & (s.index <= p1[0])).sum())
        days_min = days if days_min is None else min(days_min, days)
        r = p1[1] / p0[1] - 1
        out.append({"ts_code": c, "from": p0[0].date().isoformat(), "to": p1[0].date().isoformat(),
                    "price_change": round(r, 6),
                    "if_executed": None if intent == "rebalance" else round(r if intent == "buy" else -r, 6)})
    if days_min is None or days_min < min_days:
        return _insufficient(f"决定后仅 {days_min or 0} 个交易日, 少于 {min_days}", evaluation="hypothetical_direction")
    return {"evaluation": "hypothetical_direction", "status_eval": "ok",
            "label": "假设对照: 若当时按该方向执行 (不含数量与费用, 非真实结果)", "items": out,
            "note": "if_executed: 买入为其后涨跌幅, 卖出为避免的涨跌幅 (正数表示执行会更好); 调仓不判方向"}


def summarize_reviews(reviews: list[dict]) -> dict:
    """汇总: 事后补记与中期读数单列; 样本少时明确说明不构成能力证据。"""
    executed = [r for r in reviews if r.get("evaluation") == "executed_vs_not_trading" and r.get("status_eval") == "ok"]
    final = [r for r in executed if not r["retrospective"] and not r.get("interim")]
    hypo = [r for r in reviews if r.get("evaluation") == "hypothetical_direction" and r.get("status_eval") == "ok"
            and not r["retrospective"]]
    hypo_vals = [i["if_executed"] for r in hypo for i in r["items"] if i.get("if_executed") is not None]
    out = {
        "executed": {"count": len(final), "positive": sum(r["value_added"] > 0 for r in final),
                     "total_value_added": round(sum(r["value_added"] for r in final), 2)},
        "executed_interim_count": sum(1 for r in executed if r.get("interim") and not r["retrospective"]),
        "retrospective_count": sum(1 for r in reviews if r.get("retrospective")),
        "not_adopted_or_deferred": {"count": len(hypo), "would_have_helped": sum(v > 0 for v in hypo_vals),
                                    "would_have_hurt": sum(v < 0 for v in hypo_vals)},
        "insufficient_count": sum(1 for r in reviews if r.get("status_eval") == "insufficient"),
    }
    if len(final) < SMALL_SAMPLE:
        out["sample_note"] = f"已完成复盘的执行决定仅 {len(final)} 条 (< {SMALL_SAMPLE}), 不构成判断能力的证据"
    return out


# ═══════════════════════════════════════════════════════
#  I/O 封装 (路由调用)
# ═══════════════════════════════════════════════════════

def _default_loader():
    from services.trailing_stop_service import default_bars_loader
    return default_bars_loader


def _store_and_trades():
    import json
    from services.decision_policy import ROOT
    from services.trade_import import load_ledger
    from services import decision_journal as dj
    store = json.loads((ROOT / "data_lake" / "portfolio_store.json").read_text(encoding="utf-8"))
    return store, list(load_ledger(dj.TRADE_LEDGER_PATH).get("trades") or [])


def portfolio_review(start: str, end: Optional[str] = None, loader=None) -> dict:
    from services.manual_decisions import DecisionError
    if parse_day(start) is None or (end and parse_day(end) is None):
        raise DecisionError("日期格式须为 YYYY-MM-DD", 422)
    try:
        store, trades = _store_and_trades()
    except (OSError, ValueError) as e:
        raise DecisionError(f"持仓快照或成交台账不可读: {e}", 409)
    holdings = {c: float(p.get("amount") or 0) for c, p in (store.get("positions") or {}).items()}
    return portfolio_comparison(start, end, end_holdings=holdings, snapshot_date=store.get("import_date"),
                                trades=trades, loader=loader or _default_loader())


def decision_reviews(limit: int = 200, loader=None) -> dict:
    from services import decision_journal as dj
    loader = loader or _default_loader()
    reviews = []
    for rec in dj.list_journal(limit):
        linked = dj.get_decision(rec["id"])["linked_trades"] if rec["execution"]["status"] == "linked" else []
        r = review_decision(rec, linked, loader)
        r["thesis"] = rec.get("thesis")
        r["decided_on"] = rec.get("decided_on") or (rec.get("created_at") or "")[:10]
        r["codes"] = rec.get("codes") or ([rec["code"]] if rec.get("code") else [])
        reviews.append(r)
    return {"reviews": reviews, "summary": summarize_reviews(reviews),
            "note": "复盘只读; 未关联成交的采用决定不评价; 假设对照不是实际结果"}
