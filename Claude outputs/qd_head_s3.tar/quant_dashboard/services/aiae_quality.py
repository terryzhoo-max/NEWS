"""
海外 AIAE 数据质量评分 (2026-11-01 数据质量审计 #6 / #13)
=========================================================
美/日/港 AIAE 原本在市值、M2、融资、南向资金、AH 溢价、ERP 取不到时用硬编码兜底值继续计算,
报告状态仍是 success, 也没有质量分与决策锁定 (A 股 AIAE 已有)。

规则 (与 A 股 AIAE 一致):
  - 每项硬编码兜底 (is_fallback=True 或 source="default", 或输入缺失) 扣 25 分
  - 每项过期 (is_stale=True) 扣 10 分
  - 质量分 ≤ 50, 或核心输入 (市值 / M2, 决定 AIAE_Core) 任一为兜底 → decision_locked
"""

from __future__ import annotations

from typing import Dict, Iterable, Optional


def _is_fallback(d: Optional[dict]) -> bool:
    return d is None or bool(d.get("is_fallback")) or str(d.get("source", "")).lower() == "default"


def assess(inputs: Dict[str, Optional[dict]], core: Iterable[str] = ("市值", "M2"),
           erp_fallback: bool = False) -> dict:
    warnings, l3, l2 = [], 0, 0
    for name, d in inputs.items():
        if _is_fallback(d):
            l3 += 1
            warnings.append({"type": "fallback", "source": name, "severity": "warning",
                             "message": f"{name}数据使用降级值, 非实时"})
        elif d.get("is_stale"):
            l2 += 1
            warnings.append({"type": "stale", "source": name, "severity": "info",
                             "message": f"{name}数据已过期 ({d.get('month') or d.get('trade_date') or '?'})"})
    if erp_fallback:
        l3 += 1
        warnings.append({"type": "fallback", "source": "ERP", "severity": "warning",
                         "message": "ERP 读取失败, 使用降级常数, 仓位矩阵查表结果不可信"})
    score = max(0, 100 - 25 * l3 - 10 * l2)
    core_fb = [n for n in core if n in inputs and _is_fallback(inputs[n])]
    locked = score <= 50 or bool(core_fb)
    if locked:
        why = f"核心数据降级 ({'/'.join(core_fb)})" if core_fb else f"数据质量评分 {score}/100 ≤ 50"
        warnings.append({"type": "decision_locked", "severity": "critical",
                         "message": f"{why}, 档位与仓位仅供参考"})
    return {"data_quality_score": score, "decision_locked": locked,
            "data_warnings": warnings, "core_fallback": core_fb}
