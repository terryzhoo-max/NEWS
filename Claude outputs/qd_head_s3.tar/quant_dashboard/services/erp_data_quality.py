"""
AlphaCore · ERP 数据质量守卫 (2026-10-24)
=========================================
背景: docs/ERP_VALIDATION_STEP1_2.md §2.1 —— 10Y 国债收益率缓存每半年只有约 4 个交易日,
其余靠 ffill/bfill 静默补齐, 导致 ERP / D2 分位 / 估值区间失真, 且回测在不同时间运行
会拿到不同的数据。

原则:
  1. 只允许向前填充 (ffill), 且有天数上限; 永不 bfill (bfill = 用未来值填过去)。
  2. 回测: 覆盖率不达标直接抛 DataQualityError, 拒绝运行。
  3. 实盘: 记录 error 日志并返回报告, 不阻断页面 (由调用方决定)。
"""
from __future__ import annotations

import logging
from typing import Optional

import pandas as pd

logger = logging.getLogger("ac.erp_data_quality")

MIN_COVERAGE = 0.98        # 有效观测日 / 交易日 的最低比例
MAX_GAP_TRADING_DAYS = 5   # 连续缺失的最大交易日数 (超过即判失败)
FFILL_LIMIT = 5            # 合并时最多向前填充的交易日数


class DataQualityError(ValueError):
    """回测数据不满足时点一致 / 覆盖率要求。"""


def daily_coverage(series_dates, calendar_dates, start=None, end=None) -> dict:
    """series_dates 相对交易日历 calendar_dates 的覆盖率与最长连续缺口 (按交易日计)。"""
    cal = pd.DatetimeIndex(pd.to_datetime(pd.Series(calendar_dates))).unique().sort_values()
    if start is not None:
        cal = cal[cal >= pd.Timestamp(start)]
    if end is not None:
        cal = cal[cal <= pd.Timestamp(end)]
    have = set(pd.to_datetime(pd.Series(series_dates)).dropna())
    if len(cal) == 0:
        return {"expected": 0, "observed": 0, "coverage": 0.0, "max_gap": None,
                "worst_gap_end": None, "first": None, "last": None}
    hit = pd.Series([d in have for d in cal], index=cal)
    # 最长连续缺失段
    miss = (~hit).astype(int)
    run_id = (hit != hit.shift()).cumsum()
    runs = miss.groupby(run_id).sum()
    max_gap = int(runs.max()) if len(runs) else 0
    worst_end = None
    if max_gap > 0:
        rid = runs.idxmax()
        worst_end = hit[run_id == rid].index[-1].strftime("%Y-%m-%d")
    obs = hit[hit]
    return {
        "expected": int(len(cal)),
        "observed": int(hit.sum()),
        "coverage": round(float(hit.mean()), 4),
        "max_gap": max_gap,
        "worst_gap_end": worst_end,
        "first": obs.index[0].strftime("%Y-%m-%d") if len(obs) else None,
        "last": obs.index[-1].strftime("%Y-%m-%d") if len(obs) else None,
    }


def check_daily_series(name: str, series_dates, calendar_dates, start=None, end=None,
                       min_coverage: float = MIN_COVERAGE,
                       max_gap: int = MAX_GAP_TRADING_DAYS,
                       strict: bool = True) -> dict:
    """检查日频序列覆盖率; strict=True 时不达标抛 DataQualityError, 否则记 error 日志。"""
    rep = daily_coverage(series_dates, calendar_dates, start, end)
    rep["name"] = name
    problems = []
    if rep["expected"] == 0:
        problems.append("交易日历为空")
    else:
        if rep["first"] is None or (start is not None and pd.Timestamp(rep["first"]) >
                                     pd.Timestamp(start) + pd.Timedelta(days=10)):
            problems.append(f"起点 {rep['first']} 晚于要求的 {pd.Timestamp(start).date() if start else '-'}")
        if rep["coverage"] < min_coverage:
            problems.append(f"覆盖率 {rep['coverage']:.1%} < {min_coverage:.0%}")
        if rep["max_gap"] is not None and rep["max_gap"] > max_gap:
            problems.append(f"最长连续缺失 {rep['max_gap']} 个交易日 (截至 {rep['worst_gap_end']}) > {max_gap}")
    rep["ok"] = not problems
    rep["problems"] = problems
    if problems:
        msg = f"[数据质量] {name}: " + "; ".join(problems)
        if strict:
            raise DataQualityError(msg)
        logger.error(msg)
    return rep
