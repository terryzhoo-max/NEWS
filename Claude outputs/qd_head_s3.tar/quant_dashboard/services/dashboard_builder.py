import asyncio
import copy
import math
import time
import threading
import traceback
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor

import tushare as ts

from config import TUSHARE_TOKEN
from services.logger import get_logger

logger = get_logger("dashboard")
from services.cache_service import cache_manager
from services.cache_store import (
    get_cache_ttl as _get_cache_ttl,
    get_global_aiae_ttl as _get_global_aiae_ttl,
    get_snapshot_retention_ttl as _get_snapshot_retention_ttl,
)
from services.aiae_safety import build_aiae_context, apply_vol_overlay
from services.position_engine import (
    get_vix_analysis, get_position_path, get_tomorrow_plan,
    get_institutional_mindset,
)
from aiae_engine import get_aiae_engine, REGIMES as AIAE_REGIMES

executor = ThreadPoolExecutor(max_workers=10)

# P0-4: 统一策略缓存写入锁 (Single Source of Truth, 供 main.py / strategy.py 共用)
_STRATEGY_LOCK = threading.Lock()

CACHE_TTL = 3600  # 向下兼容

def _get_cache_ttl_compat() -> int:
    """P2-1: 统一使用 cache_store 的 TTL 计算 (DRY)"""
    return _get_cache_ttl()


def _get_global_aiae_ttl_compat() -> int:
    """P2-1: 统一使用 cache_store 的海外 AIAE TTL (DRY)"""
    return _get_global_aiae_ttl()


_MACRO_MEMO = {"ts": 0.0, "value": None}
_MACRO_REFRESH_SECONDS = 300   # VIX/CNY 为日频或低频数据, 盘中 5 分钟刷新足够; 避免每 30 秒请求外部源


def _hot_macro_snapshot():
    """热数据循环使用的宏观快照 (节流), 失败时不缓存。"""
    from dashboard_modules.fetch_macro import fetch_vix_for_dashboard, fetch_cny_for_dashboard
    if _MACRO_MEMO["value"] is not None and time.time() - _MACRO_MEMO["ts"] < _MACRO_REFRESH_SECONDS:
        return _MACRO_MEMO["value"]
    hot_vix, prev_vix = fetch_vix_for_dashboard()
    cny = fetch_cny_for_dashboard()
    _MACRO_MEMO.update(ts=time.time(), value=(hot_vix, prev_vix, cny))
    return _MACRO_MEMO["value"]


# ── 快照自愈 (Self-Heal) ──────────────────────────────────────────
# 热循环只负责"续写"已有快照; 一旦快照缺失 (TTL 过期 / LRU 驱逐 / 构建失败),
# 旧逻辑要等到 15:35 daily_warmup 才会重建, 期间整页 warming_up + 决策锁定。
# 这里在快照缺失时触发后台全量重建: 单飞 (single-flight) + 失败指数退避。
_SELF_HEAL_LOCK = threading.Lock()          # 单飞: 同一时刻只允许一个重建
# 启动宽限 180s: 让 main.py 的分层预热 (Dashboard 在 +30s) 先完成, 避免启动时重复全量构建
_SELF_HEAL_STATE = {"next_allowed_ts": time.time() + 180, "failures": 0, "last_started_ts": 0.0}
_SELF_HEAL_BASE_COOLDOWN = 120              # 首次失败后 2 分钟再试
_SELF_HEAL_MAX_COOLDOWN = 1800              # 退避上限 30 分钟


def _run_self_heal_rebuild():
    try:
        try:
            result = asyncio.run(_build_dashboard_data_full())
            ok = isinstance(result, dict) and result.get("status") == "success"
        except Exception:
            logger.error("快照自愈重建异常: %s", traceback.format_exc())
            ok = False
        if ok:
            _SELF_HEAL_STATE.update(failures=0, next_allowed_ts=0.0)
            logger.info("快照自愈重建成功, dashboard_data 已恢复")
        else:
            n = _SELF_HEAL_STATE["failures"] + 1
            cooldown = min(_SELF_HEAL_MAX_COOLDOWN, _SELF_HEAL_BASE_COOLDOWN * (2 ** (n - 1)))
            _SELF_HEAL_STATE.update(failures=n, next_allowed_ts=time.time() + cooldown)
            logger.warning("快照自愈重建失败 (第 %d 次), %ds 后重试", n, cooldown)
    finally:
        _SELF_HEAL_LOCK.release()


def trigger_dashboard_self_heal(reason: str = "snapshot_missing") -> bool:
    """快照缺失时触发后台全量重建。返回 True 表示本次已启动重建。

    非阻塞: 已有重建在跑或处于退避窗口内则直接返回 False。
    """
    if time.time() < _SELF_HEAL_STATE["next_allowed_ts"]:
        return False
    if not _SELF_HEAL_LOCK.acquire(blocking=False):
        return False
    try:
        _SELF_HEAL_STATE["last_started_ts"] = time.time()
        logger.warning("dashboard_data 快照缺失 (%s), 启动后台自愈重建", reason)
        threading.Thread(target=_run_self_heal_rebuild, name="dashboard-self-heal", daemon=True).start()
        return True
    except Exception:
        _SELF_HEAL_LOCK.release()
        raise


def get_self_heal_status() -> dict:
    """运维可观测: 自愈重建状态"""
    return {
        "running": _SELF_HEAL_LOCK.locked(),
        "failures": _SELF_HEAL_STATE["failures"],
        "next_allowed_ts": _SELF_HEAL_STATE["next_allowed_ts"] or None,
        "last_started_ts": _SELF_HEAL_STATE["last_started_ts"] or None,
    }


def _hot_data_reactor_tick():
    """后台高频预热循环：盘中提取 VIX/CNY，主动写入缓存; 快照缺失时触发自愈重建"""
    try:
        from services.market_clock import CN_TZ
        now_dt = datetime.now()
        cn_dt = datetime.now(CN_TZ).replace(tzinfo=None)  # A 股时段必须按北京时间判断 (服务器可能不在 UTC+8)
        is_trading_hours = cn_dt.weekday() < 5 and ((cn_dt.hour == 9 and cn_dt.minute >= 30) or (10 <= cn_dt.hour < 15))
        with _STRATEGY_LOCK:
            # 先取快照再做网络请求, 避免"检查时存在、取数时已过期"的竞态 (TOCTOU)
            hot_data = cache_manager.get_json("dashboard_data")
            _hot_aiae_ctx = cache_manager.get_json("aiae_ctx")
        has_strategy_cache = isinstance(hot_data, dict) and bool(hot_data)

        if not has_strategy_cache:
            trigger_dashboard_self_heal("reactor_tick")
            return

        if is_trading_hours:
            hot_vix, prev_vix, cny_result = _hot_macro_snapshot()

            hot_vix_change = ((hot_vix - prev_vix) / prev_vix * 100) if prev_vix > 0 else 0
            hot_vix_status = "down" if hot_vix_change < 0 else "up"
            hot_vix_analysis = get_vix_analysis(hot_vix)

            mc = hot_data.get("data", {}).get("macro_cards", {})
            if "vix" in mc:
                mc["vix"]["value"] = round(hot_vix, 2)
                mc["vix"]["trend"] = f"{round(hot_vix_change, 1)}%"
                mc["vix"]["status"] = hot_vix_status
                mc["vix"]["regime"] = hot_vix_analysis["label"]
                mc["vix"]["class"] = hot_vix_analysis["class"]
                mc["vix"]["desc"] = hot_vix_analysis.get("desc", "")
                mc["vix"]["percentile"] = hot_vix_analysis.get("percentile", 0)
                # 2026-11-01: 观测日期随数值一起更新 (下游 JCS 据此判断时效)
                from dashboard_modules.fetch_macro import vix_observation
                _obs = vix_observation()
                mc["vix"].update(data_as_of=_obs.get("observed_at"), observation_basis=_obs.get("basis"),
                                 source=_obs.get("source"), updated_at=_obs.get("received_at"))
            if mc.get("regime_banner"):
                mc["regime_banner"]["vix"] = round(hot_vix, 2)
                mc["regime_banner"]["vix_label"] = hot_vix_analysis.get("label", "—")
            if mc.get("market_temp") and "multiplier" in hot_vix_analysis:
                mc["market_temp"]["market_vix_multiplier"] = hot_vix_analysis["multiplier"]

            if "tomorrow_plan" in mc:
                mc["tomorrow_plan"] = get_tomorrow_plan(hot_vix_analysis, mc.get("market_temp", {}).get("value", 50), _hot_aiae_ctx)
            hot_data["timestamp"] = now_dt.isoformat()

            with _STRATEGY_LOCK:
                _hot_ttl = _get_snapshot_retention_ttl()
                cache_manager.set_json("last_hot_update", time.time(), ttl_seconds=_hot_ttl)
                cache_manager.set_json("dashboard_data", hot_data, ttl_seconds=_hot_ttl)
        else:
            # 盘后安全网: 周期性续期保留期 (30 分钟节流, O(1) 无数据拷贝)
            _last_ka = getattr(_hot_data_reactor_tick, '_last_keepalive', 0)
            if time.time() - _last_ka > 1800:
                _renew_ttl = _get_snapshot_retention_ttl()
                cache_manager.touch("dashboard_data", _renew_ttl)
                cache_manager.touch("last_update", _renew_ttl)
                cache_manager.touch("last_hot_update", _renew_ttl)
                cache_manager.touch("aiae_ctx", _renew_ttl)
                _hot_data_reactor_tick._last_keepalive = time.time()
                logger.debug("盘后缓存续期: TTL=%ds", _renew_ttl)
    except Exception as e:
        logger.warning(f"Reactor tick 异常: {e}")


async def _build_dashboard_data_full():
    """由后台 Reactor 主动触发的全量构建逻辑，绝不在 API 线程中直接调用"""
    from dashboard_modules.fetch_macro import fetch_vix_for_dashboard, fetch_cny_for_dashboard, fetch_macro_data
    from dashboard_modules.run_strategies import run_all_strategies, wrap_mr_results
    from dashboard_modules.capital_flow import compute_capital_flow
    from dashboard_modules.market_temp import compute_market_temperature
    from dashboard_modules.sector_heatmap import compute_sector_heatmap
    from dashboard_modules.assemble_response import assemble_dashboard_response

    current_time = time.time()

    # ── 全量刷新: 子模块并发编排 ──
    ts.set_token(TUSHARE_TOKEN)
    pro = ts.pro_api()
    today_str = datetime.now().strftime('%Y%m%d')
    loop = asyncio.get_running_loop()

    try:
        # 第一层: 并发执行 I/O 和独立计算
        async def fetch_macro_safe():
            # Fail closed: the outer build handler leaves the last-known-good
            # cache untouched when primary macro inputs cannot be verified.
            return await fetch_macro_data(executor)

        async def get_capital_flow():
            return await loop.run_in_executor(executor, compute_capital_flow, pro, today_str)

        async def get_aiae_report():
            def _fetch():
                try:
                    eng = get_aiae_engine()
                    return eng.generate_report()
                except Exception as e:
                    logger.error(f"AIAE引擎异常: {e}")
                    return {"status": "error", "message": str(e)}
            return await loop.run_in_executor(executor, _fetch)

        macro_task = asyncio.create_task(fetch_macro_safe())
        strat_task = asyncio.create_task(run_all_strategies(executor))
        cap_task = asyncio.create_task(get_capital_flow())
        aiae_task = asyncio.create_task(get_aiae_report())

        # 等待第一层完成
        macro_res, strat_res, cap_res, aiae_report = await asyncio.gather(
            macro_task, strat_task, cap_task, aiae_task
        )

        # 解包第一层结果
        latest_vix, prev_vix, latest_cny = macro_res
        vix_change = ((latest_vix - prev_vix) / prev_vix * 100) if prev_vix > 0 else 0
        vix_status = "down" if vix_change < 0 else "up"

        mr_res, div_res, mom_res = strat_res
        cache_manager.set_json("strategy_results", {"mr": mr_res, "div": div_res, "mom": mom_res})

        capital_a, capital_h, liquidity_score, total_money_z, z_s = cap_res

        # 处理 AIAE
        _full_aiae_ctx = build_aiae_context(aiae_report)
        # Vol overlay V2: 市场尾部刹车 → 有效上限; 组合波动预算 → 风险面板
        try:
            from services.vol_regime import current_overlay
            _full_aiae_ctx = apply_vol_overlay(_full_aiae_ctx, current_overlay())
        except Exception as e:
            logger.warning("波动率系数应用失败 (保持原上限): %s", e)
        try:
            from services.portfolio_vol import compute_from_store, summarize
            _vb_summary = summarize(compute_from_store())
            if _vb_summary:
                _full_aiae_ctx["vol_budget"] = _vb_summary
                cache_manager.set_json("vol_budget", _vb_summary, ttl_seconds=_get_cache_ttl())
        except Exception as e:
            logger.warning("组合波动预算计算失败 (非致命): %s", e)
        if _full_aiae_ctx.get("decision_locked") is not False:
            logger.error("AIAE 上下文未通过状态、质量或仓位校验，停止发布 Dashboard")
            raise RuntimeError("AIAE_CONTEXT_UNUSABLE")
        try:
            aiae_regime = int(_full_aiae_ctx["regime"])
            aiae_cap = float(_full_aiae_ctx["cap"])
            aiae_v1_value = float(_full_aiae_ctx["aiae_v1"])
            aiae_regime_cn = str(_full_aiae_ctx["regime_cn"] or "").strip()
        except (KeyError, TypeError, ValueError) as exc:
            raise RuntimeError("AIAE_CONTEXT_UNUSABLE") from exc
        if (
            aiae_regime not in AIAE_REGIMES
            or not math.isfinite(aiae_cap)
            or not 0 <= aiae_cap <= 100
            or not math.isfinite(aiae_v1_value)
            or not aiae_regime_cn
        ):
            raise RuntimeError("AIAE_CONTEXT_UNUSABLE")
        logger.info(
            "AIAE注入成功: BasisValue=%.2f%% Regime=%s Cap=%s%%",
            aiae_v1_value,
            aiae_regime,
            aiae_cap,
        )

        # 第二层: 温度分析与热力图
        vix_analysis = get_vix_analysis(latest_vix)

        async def get_temp():
            def _calc():
                return compute_market_temperature(
                    pro, today_str, latest_vix, latest_cny, liquidity_score, z_s,
                    aiae_regime, aiae_cap, aiae_v1_value, aiae_regime_cn, aiae_report, vix_analysis
                )
            return await loop.run_in_executor(executor, _calc)

        temp_task = asyncio.create_task(get_temp())
        heatmap_task = asyncio.create_task(compute_sector_heatmap(executor, mr_res, mom_res))

        temp_data, sector_heatmap = await asyncio.gather(temp_task, heatmap_task)

        import aiae_params as AP
        is_v5 = getattr(AP, 'V5_ENABLED', False)
        fallback_thresholds = list(AP.V5_REGIME_THRESHOLDS) if is_v5 else list(AP.REGIME_THRESHOLDS)

        # 单一 AIAE 上下文同时供全量响应、热更新与缓存使用，避免健康字段在组装时丢失。
        _full_aiae_ctx.update({
            "regime_cn": aiae_regime_cn,
            "regime_info": _full_aiae_ctx.get("regime_info") or AIAE_REGIMES.get(aiae_regime, AIAE_REGIMES[3]),
            "aiae_v1": round(aiae_v1_value, 2),
            "erp_val": round(temp_data["erp_val"], 2),
            "erp_label": temp_data["valuation_label"],
            "erp_tier": temp_data["erp_tier"],
            "margin_heat": _full_aiae_ctx.get("margin_heat"),
            "fund_position": _full_aiae_ctx.get("fund_position"),
            "fund_position_source": _full_aiae_ctx.get("fund_position_source"),
            "fund_position_date": _full_aiae_ctx.get("fund_position_date"),
            "regime_basis_value": aiae_v1_value,
            "regime_thresholds": _full_aiae_ctx.get("regime_thresholds") or fallback_thresholds,
            "regime_mode": _full_aiae_ctx.get("regime_mode") or ("V5_simple" if is_v5 else "V3_composite"),
        })

        # Step 8: 组装最终响应
        final_data = assemble_dashboard_response(
            latest_vix=latest_vix, vix_change=vix_change,
            vix_status=vix_status, vix_analysis=vix_analysis,
            capital_a=capital_a, capital_h=capital_h,
            total_money_z=total_money_z,
            temp_data=temp_data,
            mr_res=mr_res, div_res=div_res, mom_res=mom_res,
            aiae_regime=aiae_regime, aiae_cap=aiae_cap,
            aiae_v1_value=aiae_v1_value, aiae_regime_cn=aiae_regime_cn,
            aiae_report=aiae_report, aiae_ctx=_full_aiae_ctx,
            sector_heatmap=sector_heatmap,
            get_tomorrow_plan_fn=get_tomorrow_plan,
            get_position_path_fn=get_position_path,
            get_institutional_mindset_fn=get_institutional_mindset,
            liquidity_score=liquidity_score,
        )

        # 更新缓存 (P0-2: 原子写入, R7: 智能 TTL 防陈旧)
        # 写入用"保留期"而非"新鲜度": 陈旧判定由 API is_stale / health 按 last_update 计算
        _build_ttl = _get_snapshot_retention_ttl()
        with _STRATEGY_LOCK:
            cache_manager.set_json("last_update", current_time, ttl_seconds=_build_ttl)
            cache_manager.set_json("dashboard_data", final_data, ttl_seconds=_build_ttl)
            cache_manager.set_json("aiae_ctx", _full_aiae_ctx, ttl_seconds=_build_ttl)
        return final_data

    except Exception as e:
        logger.error(f"Dashboard 全量构建异常: {traceback.format_exc()}")
        return {"status": "error", "message": f"Global Error: {str(e)}"}
