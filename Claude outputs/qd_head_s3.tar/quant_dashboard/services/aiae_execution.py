"""
AlphaCore · AIAE 执行层 (P1-c, 2026-10-30)
=========================================
规则登记: docs/AIAE_EXECUTION_RULES.md · 参数: aiae_params.EXEC_PARAMS (哈希冻结)

只管"触线之后怎么执行", 不改变有效上限的算法 (portfolio_vol.build_decision_view: AIAE ∧ 波动预算 ∧ 回撤刹车)。

R1 评估节奏: 有效上限每天照算; 执行目标 T 每周评估一次 (周五及以后首次计算; 上周漏评则本周首次计算时补评)。
            风险事件 (回撤刹车 / 市场尾部刹车 / AIAE 锁定) 当日立即把 T 下调到有效上限, 只允许向下。
R2 偏离分区: gap = 实际 − T; >10 必须降仓 / 5~10 暂停加仓 / −15~5 维持 / ≤−15 允许加仓 (需信号确认)。
R3 节奏:    T 每个评估周最多上调 10pp (趋势空头或未知时 5pp); 下调一步到位。

结构: evaluate() 是纯函数 (状态进、状态出); run() 负责读写状态文件与前向记录。
前向记录: data_lake/aiae_exec_forward_log.csv, 每个评估日 / 风险事件日一行, 写入后不覆盖、不回填。
测试运行时 (PYTEST_CURRENT_TEST) 不写任何文件。
"""
from __future__ import annotations

import csv
import json
import logging
import math
import os
import threading
from datetime import date, datetime, timedelta
from typing import Any, Mapping, Optional

logger = logging.getLogger("alphacore.aiae_execution")

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
STATE_PATH = os.path.join(ROOT, "data_lake", "aiae_exec_state.json")
LOG_PATH = os.path.join(ROOT, "data_lake", "aiae_exec_forward_log.csv")
V4_LOG_PATH = os.path.join(ROOT, "data_lake", "erp_v4_forward_log.csv")

LOG_COLUMNS = [
    "trade_date", "recorded_at", "param_hash", "trigger", "aiae_cap", "vol_budget_cap", "drawdown_cap",
    "effective_cap", "target", "actual", "gap", "zone", "trend", "staging_active", "risk_events",
]
ZONE_LABEL = {"reduce": "必须降仓", "pause": "暂停加仓", "hold": "维持", "add": "允许加仓"}
_lock = threading.Lock()


def _params() -> dict:
    try:
        import aiae_params as AP
    except ImportError:  # pragma: no cover
        from engines import aiae_params as AP
    return AP.EXEC_PARAMS, AP.exec_param_hash()


def _num(v) -> Optional[float]:
    try:
        x = float(v)
    except (TypeError, ValueError):
        return None
    return x if math.isfinite(x) else None


def _to_date(v) -> Optional[date]:
    if isinstance(v, date):
        return v
    try:
        return datetime.strptime(str(v)[:10], "%Y-%m-%d").date()
    except (TypeError, ValueError):
        return None


def _week(d: date) -> tuple:
    iso = d.isocalendar()
    return (iso[0], iso[1])


# ══════════════════════════════════════════════════════════════
#  R1 评估节奏
# ══════════════════════════════════════════════════════════════

def is_eval_due(today: date, last_eval: Optional[date], eval_weekday: int = 4) -> bool:
    """本周未评估, 且 (已到周五及以后, 或上周漏评) → 应评估。从未评估过 → 立即评估 (建立初值)。"""
    if last_eval is None:
        return True
    if _week(last_eval) >= _week(today):
        return False
    if today.weekday() >= eval_weekday:
        return True
    return _week(last_eval) < _week(today - timedelta(days=7))      # 上周漏评 → 补评


def next_eval_date(today: date, evaluated_this_week: bool, eval_weekday: int = 4) -> date:
    """下一次例行评估日: 本周已评估 → 下周五; 否则本周五 (周末未评估时即今天)。"""
    friday = today + timedelta(days=eval_weekday - today.weekday())
    if evaluated_this_week:
        return friday + timedelta(days=7)
    return max(friday, today)


def risk_events(market: Optional[Mapping], drawdown: Optional[Mapping], aiae_ctx: Optional[Mapping]) -> list:
    ev = []
    f = _num((market or {}).get("factor"))
    if f is not None and f < 1.0:
        ev.append("market_brake")
    if (drawdown or {}).get("tier"):
        ev.append("drawdown_brake")
    if aiae_ctx is not None and (aiae_ctx or {}).get("decision_locked") is not False:
        ev.append("aiae_locked")
    return ev


# ══════════════════════════════════════════════════════════════
#  R2 分区 · R3 节奏
# ══════════════════════════════════════════════════════════════

def classify_zone(gap: float, p: Mapping) -> str:
    if gap > p["reduce_band_pp"]:
        return "reduce"
    if gap > p["pause_band_pp"]:
        return "pause"
    if gap > -p["add_band_pp"]:
        return "hold"
    return "add"


def step_target(prev: Optional[float], effective: float, trend: Optional[str], p: Mapping) -> tuple:
    """周评估时的新执行目标: 下调一步到位; 上调每周最多 add_step (空头/未知趋势 add_step_bear)。返回 (T, staging_active)。"""
    if prev is None or effective <= prev:
        return effective, False
    # 与 ERP v4 trend_status 同一标签: bearish = PE < MA60 且 < MA120; 未知 (None / insufficient_data) 按空头, 偏保守
    step = p["add_step_pp"] if trend in ("bullish", "neutral", "weak") else p["add_step_bear_pp"]
    t = min(effective, prev + step)
    return t, t < effective


def _instruction(zone: str, t: float, gap: float, nxt: date, p: Mapping) -> str:
    if zone == "reduce":
        return (f"超出执行目标 {gap:.0f}pp: 禁止加仓; 分 {p['reduce_days']} 个交易日降至 {t:.0f}% 以内 "
                f"(跌停顺延, 不改目标)")
    if zone == "pause":
        return f"超出执行目标 {gap:.0f}pp (≤{p['reduce_band_pp']:.0f}pp): 暂停加仓, 不强制卖出"
    if zone == "hold":
        return f"维持; 下次评估 {nxt.isoformat()}"
    return (f"低于执行目标 {-gap:.0f}pp: 允许加仓, 但需信号确认 (上限不是目标); "
            f"执行目标每周最多上调 {p['add_step_pp']:.0f}pp (趋势空头时 {p['add_step_bear_pp']:.0f}pp)")


def evaluate(view: Mapping[str, Any], state: Optional[Mapping[str, Any]], today: date,
             trend: Optional[str] = None, market: Optional[Mapping] = None,
             drawdown: Optional[Mapping] = None, aiae_ctx: Optional[Mapping] = None,
             params: Optional[Mapping] = None) -> tuple:
    """纯函数: (决策视图, 上次状态) → (执行层结果, 新状态)。

    view: build_decision_view 的输出 (effective_cap_pct / actual_pct / waterfall / verdict)。
    数据不足时不推进状态 (返回原状态)。
    """
    p, h = (params, "custom") if params is not None else _params()
    st = dict(state or {})
    eff = _num(view.get("effective_cap_pct"))
    actual = _num(view.get("actual_pct"))
    steps = {s.get("key"): s.get("value") for s in (view.get("waterfall") or []) if isinstance(s, Mapping)}
    base = {
        "schema": "aiae_execution/1", "param_hash": h, "version": p.get("version"),
        "rules_doc": "docs/AIAE_EXECUTION_RULES.md",
        "daily_verdict": {k: (view.get("verdict") or {}).get(k) for k in ("level", "text", "instruction")},
    }
    if eff is None or actual is None:
        return {**base, "status": "insufficient", "reason": "有效上限或实际仓位缺失"}, st

    prev_t = _num(st.get("target"))
    last_eval = _to_date(st.get("last_eval_date"))
    due = is_eval_due(today, last_eval, int(p["eval_weekday"]))
    ev = risk_events(market, drawdown, aiae_ctx)

    t, trigger, staging = prev_t, None, bool(st.get("staging_active"))
    if due:
        t, staging = step_target(prev_t, eff, trend, p)
        trigger = "bootstrap" if prev_t is None else "weekly"
    if ev and (t is None or eff < t):           # 风险事件: 当日下调, 只向下
        t, staging = eff, False
        trigger = trigger or "risk_event"
    if t is None:                               # 理论上不会发生 (due 在无状态时恒为真)
        t, trigger = eff, "bootstrap"

    gap = round(actual - t, 1)
    zone = classify_zone(gap, p)
    evaluated_today = trigger in ("bootstrap", "weekly")
    evaluated_this_week = evaluated_today or (last_eval is not None and _week(last_eval) == _week(today))
    nxt = next_eval_date(today, evaluated_this_week, int(p["eval_weekday"]))

    new_state = dict(st)
    if trigger:
        new_state.update({"target": round(t, 1), "staging_active": staging,
                          "last_change": today.isoformat(), "last_trigger": trigger})
        if evaluated_today:
            new_state["last_eval_date"] = today.isoformat()

    result = {
        **base, "status": "ok",
        "target_pct": round(t, 1),
        "effective_cap_pct": round(eff, 1),
        "actual_pct": round(actual, 1),
        "gap_pp": gap,
        "zone": zone, "zone_label": ZONE_LABEL[zone],
        "instruction": _instruction(zone, t, gap, nxt, p),
        "reduce_days": str(p.get("reduce_days")) if p.get("reduce_days") is not None else None,  # 2026-11-02: 降仓节奏 (唯一来源 EXEC_PARAMS)
        "trigger": trigger,                      # None = 本次沿用上次目标
        "evaluated_today": evaluated_today,
        "last_eval_date": new_state.get("last_eval_date"),
        "next_eval_date": nxt.isoformat(),
        "staging_active": staging,
        "trend": trend,
        "risk_events": ev,
        "target_vs_effective_pp": round(t - eff, 1),
        "caps": {"aiae": steps.get("market"), "vol_budget": steps.get("portfolio"), "drawdown": steps.get("drawdown")},
    }
    return result, new_state


# ══════════════════════════════════════════════════════════════
#  I/O: 状态文件 + 前向记录
# ══════════════════════════════════════════════════════════════

def latest_v4_trend(path: str = V4_LOG_PATH) -> Optional[str]:
    """ERP v4 前向记录最后一行的沪深300 PE 趋势 (bearish / ...); 读不到返回 None (按空头处理, 偏保守)。"""
    try:
        with open(path, encoding="utf-8-sig", newline="") as f:
            rows = list(csv.DictReader(f))
        return (rows[-1].get("trend") or None) if rows else None
    except Exception:
        return None


def load_state(path: str = STATE_PATH) -> dict:
    try:
        with open(path, encoding="utf-8") as f:
            d = json.load(f)
        return d if isinstance(d, dict) else {}
    except Exception:
        return {}


def target_text(path: str = STATE_PATH) -> str:
    """告警 / 推送 / 行动项引用仓位的唯一写法 (2026-11-02): "AIAE 执行目标 25%"; 不可用时明确写出, 不用其他仓位数字替代。"""
    t = _num(load_state(path).get("target"))
    return f"AIAE 执行目标 {t:.0f}%" if t is not None else "AIAE 执行目标（暂不可用）"


def _save_state(state: Mapping, path: str) -> None:
    os.makedirs(os.path.dirname(path), exist_ok=True)
    tmp = f"{path}.tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(state, f, ensure_ascii=False, indent=2)
    os.replace(tmp, path)


def _append_log(result: Mapping, today: date, path: str) -> str:
    row = {
        "trade_date": today.isoformat(), "recorded_at": datetime.now().isoformat(timespec="seconds"),
        "param_hash": result.get("param_hash"), "trigger": result.get("trigger"),
        "aiae_cap": result["caps"].get("aiae"), "vol_budget_cap": result["caps"].get("vol_budget"),
        "drawdown_cap": result["caps"].get("drawdown"), "effective_cap": result.get("effective_cap_pct"),
        "target": result.get("target_pct"), "actual": result.get("actual_pct"), "gap": result.get("gap_pp"),
        "zone": result.get("zone"), "trend": result.get("trend"), "staging_active": result.get("staging_active"),
        "risk_events": "|".join(result.get("risk_events") or []),
    }
    os.makedirs(os.path.dirname(path), exist_ok=True)
    exists = os.path.exists(path)
    if exists:
        with open(path, encoding="utf-8-sig", newline="") as f:
            # 去重键 = (日期, 触发原因, 目标): 同日可能先例行评估、再多次风险事件下调 (2026-10-30 实测:
            # 64 → 二档 50 → 三档 25), 每次目标变化都要留一行; 只有完全相同的记录才视为重复
            def _t(v):
                try:
                    return round(float(v), 1)
                except (TypeError, ValueError):
                    return None
            key = (row["trade_date"], str(row["trigger"]), _t(row["target"]))
            if any((r.get("trade_date"), r.get("trigger"), _t(r.get("target"))) == key for r in csv.DictReader(f)):
                return "exists"
    with open(path, "a", encoding="utf-8" if exists else "utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=LOG_COLUMNS)
        if not exists:
            w.writeheader()
        w.writerow(row)
    return "written"


def run(view: Mapping[str, Any], *, market=None, drawdown=None, aiae_ctx=None, today: Optional[date] = None,
        state_path: str = STATE_PATH, log_path: str = LOG_PATH, trend: Optional[str] = None,
        force_io_in_tests: bool = False) -> dict:
    """读状态 → evaluate → 有变化时写状态与前向记录。任何 I/O 失败都不影响返回结果。"""
    today = today or date.today()
    trend = trend if trend is not None else latest_v4_trend()
    with _lock:
        state = load_state(state_path)
        result, new_state = evaluate(view, state, today, trend=trend, market=market,
                                     drawdown=drawdown, aiae_ctx=aiae_ctx)
        no_io = bool(os.environ.get("PYTEST_CURRENT_TEST")) and not force_io_in_tests
        if result.get("status") == "ok" and result.get("trigger") and not no_io:
            try:
                _save_state(new_state, state_path)
                result["forward_log"] = _append_log(result, today, log_path)
            except Exception as e:
                logger.warning("AIAE 执行层状态/前向记录写入失败: %s", e)
                result["forward_log"] = f"error: {e}"
    return result


def current_view_and_execution(refresh: bool = False) -> tuple:
    """决策视图 + 执行层 (与 /portfolio/vol-budget 同一来源, 供决策中枢复用)。

    返回 (view, execution_layer)。任一环节失败 → execution_layer.status = "error"/"insufficient",
    调用方据此暂停, 不得用其他数字替代执行目标。
    """
    from services.cache_service import cache_manager
    from services.vol_regime import get_vol_regime_info
    from services.portfolio_vol import compute_from_store, build_decision_view
    market = get_vol_regime_info()
    portfolio = compute_from_store(None, None, not refresh)
    try:
        aiae_ctx = cache_manager.get_json("aiae_ctx")
    except Exception:
        aiae_ctx = None
    # 2026-11-02: 经 risk_state 读取 (缓存 → 日终快照)。旧逻辑只读内存缓存, 服务重启后上限瀑布缺"回撤刹车"一档,
    # 唯一仓位数字被放宽 (实测有效上限 63% 而非 25%)。
    from services.risk_state import drawdown_brake
    dd_brake = drawdown_brake()
    view = build_decision_view(market, portfolio, aiae_ctx, drawdown=dd_brake)
    try:
        execution = run(view, market=market, drawdown=dd_brake, aiae_ctx=aiae_ctx)
    except Exception as ex:  # pragma: no cover - 防御
        logger.warning("AIAE 执行层计算失败 (非致命): %s", ex)
        execution = {"status": "error", "reason": str(ex)}
    return view, execution
