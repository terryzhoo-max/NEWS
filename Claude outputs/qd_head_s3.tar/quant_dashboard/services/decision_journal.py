"""
AlphaCore · 决策记录与成交关联 (方案 B 阶段4A, 2026-10-29)
=========================================================

在已有的人工决定台账 (services/manual_decisions → data_lake/analysis_decisions.db) 上补齐:
  · 决定记录: 采用 adopted / 未采用 not_adopted / 暂不行动 deferred —— 三类都记, 避免只记"做了的";
  · 每条记录绑定当时的数据快照 (最新 decision_evidence、持仓导入日与内容指纹、主题集中度等级);
  · 投资理由 / 反证 (什么情况说明判断错了) / 预期持有期 / 复盘日;
  · 与真实成交 (成交台账 trade_ledger.json 的 key) 的关联, 由用户确认后追加, 不自动认定。

原则:
  · 计划或决定永远不会自行变成"已成交"; 执行状态只由已确认的成交关联推出。
  · 只追加: 决定记录写入后不修改; 关联与取消关联都是追加事件, 以最后一条为准。
  · 不读写持仓、不下单、不改风险阈值。快照只存指纹与日期/等级, 不复制账户金额明细。
  · 事后补记 (decided_on 早于记录日) 明确标记 retrospective, 复盘时单列, 防止事后合理化混入。
"""
from __future__ import annotations

import json
import uuid
from datetime import date, datetime, timedelta, timezone
from typing import Any, Mapping, Optional

from services.decision_policy import ROOT, fingerprint, parse_day
from services.manual_decisions import DecisionError, _existing, connection
from services.market_clock import cn_now

JOURNAL_STATUSES = {"adopted": "采用", "not_adopted": "未采用", "deferred": "暂不行动"}
INTENTS = {"buy": "买入/加仓", "sell": "卖出/减仓", "rebalance": "调仓", "hold": "维持不动"}
LINKABLE_STATUSES = {"adopted", "planned"}        # planned = manual_decisions 的已确认计划
TRADE_LEDGER_PATH: Optional[str] = None            # None → trade_import.LEDGER_PATH (测试可替换)
CANDIDATE_WINDOW_DAYS = 14


def _links_table(conn) -> None:
    conn.execute("""CREATE TABLE IF NOT EXISTS decision_trade_links (
        id INTEGER PRIMARY KEY AUTOINCREMENT, decision_id TEXT NOT NULL, trade_key TEXT NOT NULL,
        action TEXT NOT NULL CHECK (action IN ('link','unlink')), reason TEXT NOT NULL DEFAULT '',
        at TEXT NOT NULL)""")


def _trades() -> list[dict]:
    from services.trade_import import load_ledger
    return list(load_ledger(TRADE_LEDGER_PATH).get("trades") or [])


# ── 快照 ────────────────────────────────────────────────

def _latest_evidence() -> Optional[dict]:
    try:
        from services.db.connection import _get_conn
        row = _get_conn().execute("SELECT evidence_id, model_version, recorded_at FROM decision_evidence "
                                  "ORDER BY recorded_at DESC LIMIT 1").fetchone()
        return {"evidence_id": row[0], "model_version": row[1], "recorded_at": row[2]} if row else None
    except Exception:  # noqa: BLE001 — 证据库不可用时如实记为缺失
        return None


def capture_context() -> dict:
    """决定当时的数据版本。缺失项记为 None 并列入 missing, 不用默认值冒充。"""
    ctx: dict[str, Any] = {"captured_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
                           "missing": []}
    ev = _latest_evidence()
    ctx["decision_evidence"] = ev
    if ev is None:
        ctx["missing"].append("decision_evidence")
    try:
        raw = (ROOT / "data_lake" / "portfolio_store.json").read_bytes()
        store = json.loads(raw.decode("utf-8"))
        ctx["portfolio"] = {"import_date": store.get("import_date"),
                            "content_sha256": __import__("hashlib").sha256(raw).hexdigest(),
                            "position_count": len(store.get("positions") or {})}
    except (OSError, ValueError):
        ctx["portfolio"] = None
        ctx["missing"].append("portfolio")
    try:
        from services.concentration import compute_from_store
        c = compute_from_store()
        ctx["concentration"] = ({k: c.get(k) for k in ("classification_basis", "top_theme", "top_pct", "level")}
                                if c.get("status") == "ok" else None)
    except Exception:  # noqa: BLE001
        ctx["concentration"] = None
    if ctx["concentration"] is None:
        ctx["missing"].append("concentration")
    ctx["snapshot_id"] = fingerprint({k: v for k, v in ctx.items() if k not in ("captured_at", "snapshot_id")})
    return ctx


# ── 记录决定 ────────────────────────────────────────────

def _clean_codes(codes) -> list[str]:
    import re
    if isinstance(codes, str):
        codes = [codes]
    out = sorted({str(c).strip().upper() for c in codes or [] if str(c).strip()})
    bad = [c for c in out if not re.fullmatch(r"[0-9]{6}\.(SH|SZ|BJ)", c)]
    if bad:
        raise DecisionError(f"证券代码格式无效: {', '.join(bad)}", 422)
    return out


def record_decision(payload: Mapping[str, Any]) -> dict:
    """payload: request_id, status, intent, codes, thesis, counter_evidence, expected_holding_days,
    review_after, relates_to, decided_on, retrospective."""
    p = dict(payload)
    status, intent = p.get("status"), p.get("intent")
    if status not in JOURNAL_STATUSES:
        raise DecisionError("状态须为 采用/未采用/暂不行动", 422)
    if intent not in INTENTS:
        raise DecisionError("意图须为 buy/sell/rebalance/hold", 422)
    codes = _clean_codes(p.get("codes"))
    if intent != "hold" and not codes:
        raise DecisionError("买卖或调仓须注明涉及的证券代码", 422)
    thesis = str(p.get("thesis") or "").strip()
    counter = str(p.get("counter_evidence") or "").strip()
    if not thesis:
        raise DecisionError("须记录理由 (为什么采用/不采用/暂不行动)", 422)
    if status == "adopted" and not counter:
        raise DecisionError("采用的决定须记录反证: 出现什么情况说明判断错了", 422)
    hold_days = p.get("expected_holding_days")
    if hold_days is not None and (isinstance(hold_days, bool) or not isinstance(hold_days, int)
                                  or not 0 < hold_days <= 3650):
        raise DecisionError("预期持有期须为 1~3650 的整数天, 或留空表示未设定", 422)
    today = cn_now().date()
    decided_on = parse_day(p.get("decided_on")) if p.get("decided_on") else today
    if decided_on is None or decided_on > today:
        raise DecisionError("决定日期无效或晚于今天", 422)
    retrospective = decided_on < today
    if retrospective and p.get("retrospective") is not True:
        raise DecisionError("决定日期早于今天须明确标记为事后补记 (retrospective)", 422)
    review_after = parse_day(p.get("review_after")) if p.get("review_after") else None
    if p.get("review_after") and (review_after is None or review_after < decided_on):
        raise DecisionError("复盘日期无效或早于决定日期", 422)
    relates_to = str(p.get("relates_to") or "").strip()[:200]

    request = {"kind": "journal", "request_id": p.get("request_id"), "status": status, "intent": intent,
               "codes": codes, "thesis": thesis, "counter_evidence": counter,
               "expected_holding_days": hold_days, "review_after": review_after.isoformat() if review_after else None,
               "relates_to": relates_to, "decided_on": decided_on.isoformat(), "retrospective": retrospective}
    if not request["request_id"]:
        raise DecisionError("缺少请求标识", 422)
    with connection() as conn:
        conn.execute("BEGIN IMMEDIATE")
        try:
            existing = _existing(conn, request)
            if existing:
                conn.rollback()
                return existing
            if relates_to.startswith("decision:"):
                ref = relates_to.split(":", 1)[1]
                if not conn.execute("SELECT 1 FROM analysis_decisions WHERE id=?", (ref,)).fetchone():
                    raise DecisionError("关联的原决定不存在", 422)
            record = {**request, "id": str(uuid.uuid4()),
                      "status_label": JOURNAL_STATUSES[status], "intent_label": INTENTS[intent],
                      "created_at": datetime.now(timezone.utc).isoformat(), "context": capture_context(),
                      "auto_execute": False, "note": "决定记录, 不代表订单或成交; 成交须导入券商记录后人工关联"}
            conn.execute("INSERT INTO analysis_decisions VALUES (?,?,?,?,?,?)",
                         (record["id"], request["request_id"], fingerprint(request), status, record["created_at"],
                          json.dumps(record, ensure_ascii=False, allow_nan=False)))
            conn.commit()
            return record
        except Exception:
            conn.rollback()
            raise


# ── 成交关联 ────────────────────────────────────────────

def _load_decision(conn, decision_id: str) -> dict:
    row = conn.execute("SELECT payload FROM analysis_decisions WHERE id=?", (decision_id,)).fetchone()
    if not row:
        raise DecisionError("决定记录不存在", 404)
    return json.loads(row[0])


def _decision_codes(rec: Mapping[str, Any]) -> list[str]:
    return list(rec.get("codes") or ([rec["code"]] if rec.get("code") else []))


def _decision_day(rec: Mapping[str, Any]) -> Optional[date]:
    if rec.get("decided_on"):
        return parse_day(rec["decided_on"])
    created = rec.get("created_at")
    if not created:
        return None
    try:   # 计划记录: 以北京时间的创建日为决定日
        return (datetime.fromisoformat(created) + timedelta(hours=8)).date()
    except ValueError:
        return None


def _expected_side(rec: Mapping[str, Any]) -> Optional[str]:
    if rec.get("kind") == "journal":
        return {"buy": "buy", "sell": "sell"}.get(rec.get("intent"))   # rebalance: 两个方向都可
    return rec.get("side")


def effective_links(conn) -> dict[str, dict]:
    """trade_key → 最后一次有效关联 (取消关联后不出现)。"""
    _links_table(conn)
    last: dict[str, dict] = {}
    for r in conn.execute("SELECT decision_id, trade_key, action, reason, at FROM decision_trade_links ORDER BY id"):
        last[r[1]] = {"decision_id": r[0], "trade_key": r[1], "action": r[2], "reason": r[3], "at": r[4]}
    return {k: v for k, v in last.items() if v["action"] == "link"}


def _check_trade(rec: Mapping[str, Any], trade: Mapping[str, Any]) -> None:
    status = rec.get("status")
    if status not in LINKABLE_STATUSES:
        raise DecisionError(f"「{JOURNAL_STATUSES.get(status, status)}」的记录不能关联成交; "
                            "后来改变主意请新增一条采用记录", 409)
    if rec.get("kind") == "journal" and rec.get("intent") == "hold":
        raise DecisionError("维持不动的决定不能关联成交", 409)
    if trade.get("ts_code") not in _decision_codes(rec):
        raise DecisionError("成交证券不在该决定涉及的代码中", 409)
    side = _expected_side(rec)
    if side and trade.get("side") != side:
        raise DecisionError("成交方向与决定方向不一致", 409)
    day, tday = _decision_day(rec), parse_day(trade.get("date"))
    if day is None or tday is None or tday < day:
        raise DecisionError("成交日期早于决定日期, 不能作为该决定的执行", 409)


def link_trade(decision_id: str, trade_key: str, reason: str = "") -> dict:
    trades = {t.get("key"): t for t in _trades()}
    trade = trades.get(trade_key)
    if trade is None:
        raise DecisionError("成交台账中没有该成交; 请先导入券商成交记录", 404)
    with connection() as conn:
        _links_table(conn)
        conn.execute("BEGIN IMMEDIATE")
        try:
            rec = _load_decision(conn, decision_id)
            _check_trade(rec, trade)
            current = effective_links(conn).get(trade_key)
            if current and current["decision_id"] == decision_id:
                conn.rollback()
                return current
            if current:
                raise DecisionError("该成交已关联到另一条决定; 请先取消原关联", 409)
            at = datetime.now(timezone.utc).isoformat(timespec="seconds")
            conn.execute("INSERT INTO decision_trade_links (decision_id, trade_key, action, reason, at) "
                         "VALUES (?,?,?,?,?)", (decision_id, trade_key, "link", reason.strip()[:500], at))
            conn.commit()
            return {"decision_id": decision_id, "trade_key": trade_key, "action": "link",
                    "reason": reason.strip()[:500], "at": at}
        except Exception:
            conn.rollback()
            raise


def unlink_trade(decision_id: str, trade_key: str, reason: str) -> dict:
    if not reason.strip():
        raise DecisionError("取消关联须写明原因", 422)
    with connection() as conn:
        _links_table(conn)
        conn.execute("BEGIN IMMEDIATE")
        try:
            current = effective_links(conn).get(trade_key)
            if not current or current["decision_id"] != decision_id:
                raise DecisionError("该成交当前未关联到此决定", 409)
            at = datetime.now(timezone.utc).isoformat(timespec="seconds")
            conn.execute("INSERT INTO decision_trade_links (decision_id, trade_key, action, reason, at) "
                         "VALUES (?,?,?,?,?)", (decision_id, trade_key, "unlink", reason.strip()[:500], at))
            conn.commit()
            return {"decision_id": decision_id, "trade_key": trade_key, "action": "unlink", "at": at}
        except Exception:
            conn.rollback()
            raise


def _execution(rec: Mapping[str, Any], linked: list[dict]) -> dict:
    if rec.get("status") not in LINKABLE_STATUSES or (rec.get("kind") == "journal" and rec.get("intent") == "hold"):
        return {"status": "not_applicable", "label": "无需成交"}
    if not linked:
        return {"status": "no_linked_fill", "label": "未关联成交 (不代表未执行, 也不代表已执行)"}
    by_side: dict[str, dict] = {}
    for t in linked:
        s = by_side.setdefault(t.get("side") or "?", {"qty": 0, "amount": 0.0, "fees": 0.0, "fees_unknown": False})
        s["qty"] += int(t.get("qty") or 0)
        s["amount"] += float(t.get("amount") or 0.0)
        if t.get("fees") is None:
            s["fees_unknown"] = True
        else:
            s["fees"] += float(t["fees"])
    for s in by_side.values():
        s["avg_price"] = round(s["amount"] / s["qty"], 4) if s["qty"] else None
        s["amount"] = round(s["amount"], 2)
        s["fees"] = None if s["fees_unknown"] else round(s["fees"], 2)
    dates = sorted(t.get("date") for t in linked)
    return {"status": "linked", "label": f"已关联 {len(linked)} 笔成交", "fill_count": len(linked),
            "first_fill": dates[0], "last_fill": dates[-1], "by_side": by_side}


def get_decision(decision_id: str) -> dict:
    trades = {t.get("key"): t for t in _trades()}
    with connection() as conn:
        rec = _load_decision(conn, decision_id)
        links = [l for l in effective_links(conn).values() if l["decision_id"] == decision_id]
    linked, missing = [], []
    for l in links:
        t = trades.get(l["trade_key"])
        (linked.append({**t, "linked_at": l["at"]}) if t else missing.append(l["trade_key"]))
    linked.sort(key=lambda t: (t.get("date", ""), t.get("time", "")))
    return {"decision": rec, "linked_trades": linked, "missing_trade_keys": missing,
            "execution": _execution(rec, linked)}


def candidate_trades(decision_id: str, window_days: int = CANDIDATE_WINDOW_DAYS) -> dict:
    """可供用户确认关联的成交 (只是候选, 不自动关联)。"""
    with connection() as conn:
        rec = _load_decision(conn, decision_id)
        taken = effective_links(conn)
    day = _decision_day(rec)
    out = []
    if rec.get("status") in LINKABLE_STATUSES and day is not None:
        end = day + timedelta(days=window_days)
        for t in _trades():
            tday = parse_day(t.get("date"))
            if tday is None or not day <= tday <= end:
                continue
            try:
                _check_trade(rec, t)
            except DecisionError:
                continue
            owner = taken.get(t.get("key"))
            out.append({**t, "linked_to": owner["decision_id"] if owner else None})
    out.sort(key=lambda t: (t.get("date", ""), t.get("time", "")))
    return {"decision_id": decision_id, "window_days": window_days,
            "decided_on": day.isoformat() if day else None, "candidates": out,
            "note": "候选按代码、方向、日期窗口筛出; 须人工确认后才关联"}


def list_journal(limit: int = 50) -> list[dict]:
    """所有决定 (含 MR 计划/观察与本模块记录), 附执行状态摘要。"""
    from services.manual_decisions import DB_PATH
    if not DB_PATH.exists():
        return []
    trades = {t.get("key"): t for t in _trades()}
    with connection() as conn:
        rows = conn.execute("SELECT payload FROM analysis_decisions ORDER BY created_at DESC LIMIT ?",
                            (limit,)).fetchall()
        links = effective_links(conn)
    by_dec: dict[str, list] = {}
    for l in links.values():
        if l["trade_key"] in trades:
            by_dec.setdefault(l["decision_id"], []).append(trades[l["trade_key"]])
    out = []
    for row in rows:
        rec = json.loads(row[0])
        out.append({**rec, "execution": _execution(rec, by_dec.get(rec["id"], []))})
    return out
