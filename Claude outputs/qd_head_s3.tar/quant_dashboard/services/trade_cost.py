"""A 股交易成本估算 (事前, 2026-10-31) —— 实盘监控面板「调仓执行决策桌」的唯一口径。

显性成本 (按现行规则):
  - 佣金: 成交额 × 费率 (默认万 2.5, 以券商实际费率为准), 每笔最低 5 元
  - 印花税: 仅卖出、仅股票, 0.05% (2023-08-28 起减半); 基金/ETF 免征
  - 过户费: 仅股票, 0.001% 双向 (2022-04-29 起); 基金/ETF 免收
隐性成本 (估算, 非报价):
  - 半价差: 0.5 × 最小价位 / 价格 (基金 0.001 元, 股票 0.01 元) —— 价差下限, 实际可能更宽
  - 市场冲击 (平方根模型): Y × σ日 × √(每日成交额 / ADV), Y = 0.7 (文献常用 0.5–1)
    σ日 = 近 60 日收益率标准差, ADV = 近 20 日成交额中位数; 数据缺失时冲击记为未知 (不臆造)
"""
from __future__ import annotations

import math
from typing import Any, Callable, Mapping, Optional

COMMISSION_RATE = 0.00025
MIN_COMMISSION = 5.0
STAMP_TAX_A_SELL = 0.0005        # A 股卖出 (2023-08-28 起)
STAMP_TAX_HK = 0.001             # 港股 (未改动, 沿用原值)
TRANSFER_FEE_A = 0.00001         # A 股过户费 双向 (2022-04-29 起)
IMPACT_Y = 0.7
TICK_FUND = 0.001
TICK_STOCK = 0.01
ADV_WINDOW = 20
VOL_WINDOW = 60

FUND_PREFIXES = ("51", "52", "56", "58", "159", "16", "18", "50")


def is_fund(ts_code: str) -> bool:
    """场内基金 (ETF/LOF/封基): 免印花税、免过户费, 最小价位 0.001 元。"""
    code = (ts_code or "").split(".")[0]
    return not (ts_code or "").upper().endswith(".HK") and code.startswith(FUND_PREFIXES)


def explicit_fees(ts_code: str, side: str, amount: float, orders: int = 1,
                  commission_rate: float = COMMISSION_RATE) -> dict:
    """显性费用 (元)。orders = 拆成几笔下单 (每笔最低佣金 5 元)。"""
    amount = max(float(amount or 0), 0.0)
    orders = max(int(orders or 1), 1)
    commission = max(amount * commission_rate, MIN_COMMISSION * orders) if amount > 0 else 0.0
    hk = (ts_code or "").upper().endswith(".HK")
    fund = is_fund(ts_code)
    if hk:
        stamp = amount * STAMP_TAX_HK if side == "sell" else 0.0
        transfer = 0.0
    else:
        stamp = amount * STAMP_TAX_A_SELL if (side == "sell" and not fund) else 0.0
        transfer = 0.0 if fund else amount * TRANSFER_FEE_A
    return {"commission": round(commission, 2), "stamp": round(stamp, 2), "transfer": round(transfer, 2),
            "total": round(commission + stamp + transfer, 2)}


def market_inputs(ts_code: str, price_loader: Optional[Callable] = None,
                  amount_loader: Optional[Callable] = None) -> dict:
    """最近价格、σ日、ADV (任一缺失为 None)。"""
    out = {"price": None, "sigma_daily": None, "adv": None}
    try:
        px = price_loader(ts_code) if price_loader else None
        if px is not None and len(px) >= 2:
            s = [float(v) for v in list(px)[-(VOL_WINDOW + 1):] if v and math.isfinite(float(v)) and float(v) > 0]
            if s:
                out["price"] = s[-1]
            rets = [s[i] / s[i - 1] - 1 for i in range(1, len(s))]
            if len(rets) >= 20:
                m = sum(rets) / len(rets)
                out["sigma_daily"] = math.sqrt(sum((r - m) ** 2 for r in rets) / (len(rets) - 1))
    except Exception:
        pass
    try:
        am = amount_loader(ts_code) if amount_loader else None
        if am is not None and len(am) >= 5:
            vals = sorted(float(v) for v in list(am)[-ADV_WINDOW:] if v and math.isfinite(float(v)) and float(v) > 0)
            if vals:
                n = len(vals)
                out["adv"] = vals[n // 2] if n % 2 else (vals[n // 2 - 1] + vals[n // 2]) / 2
    except Exception:
        pass
    return out


def estimate_order(ts_code: str, name: str, side: str, amount: float, *, days: int = 1,
                   price: Optional[float] = None, sigma_daily: Optional[float] = None,
                   adv: Optional[float] = None, commission_rate: float = COMMISSION_RATE) -> dict:
    """单只标的成本估算。days = 分几个交易日执行 (每日一笔)。"""
    amount = max(float(amount or 0), 0.0)
    days = max(int(days or 1), 1)
    fees = explicit_fees(ts_code, side, amount, orders=days, commission_rate=commission_rate)
    tick = TICK_FUND if is_fund(ts_code) else TICK_STOCK
    half_spread_bps = round(0.5 * tick / price * 1e4, 2) if price else None
    per_day = amount / days
    part = (per_day / adv) if adv else None
    impact_bps = round(IMPACT_Y * sigma_daily * math.sqrt(part) * 1e4, 2) if (part is not None and sigma_daily) else None
    implicit = amount * ((half_spread_bps or 0) + (impact_bps or 0)) / 1e4
    total = fees["total"] + implicit
    return {
        "ts_code": ts_code, "name": name, "side": side, "amount": round(amount, 0),
        "is_fund": is_fund(ts_code), "price": price,
        "adv": round(adv, 0) if adv else None,
        "participation_pct": round(part * 100, 3) if part is not None else None,
        "sigma_daily_pct": round(sigma_daily * 100, 2) if sigma_daily else None,
        "half_spread_bps": half_spread_bps, "impact_bps": impact_bps,
        **{k: fees[k] for k in ("commission", "stamp", "transfer")},
        "explicit": fees["total"], "implicit": round(implicit, 2),
        "total": round(total, 2), "total_bps": round(total / amount * 1e4, 2) if amount else 0.0,
        "complete": impact_bps is not None and half_spread_bps is not None,
    }


def suggest_algo(max_participation_pct: Optional[float], days_label: str) -> str:
    """按最大日参与率给执行方式 (个人账户: 限价单分批即可, 不需要算法单)。"""
    if max_participation_pct is None:
        return f"限价单分 {days_label} 个交易日执行 (部分标的缺成交额数据)"
    if max_participation_pct > 10:
        return f"单日占成交额 >10%: 至少分 {days_label} 个交易日, 盘中分多笔限价"
    if max_participation_pct > 1:
        return f"分 {days_label} 个交易日, 每日盘中分 2–3 笔限价"
    return f"限价单即可; 按执行规则分 {days_label} 个交易日"


def estimate_reduction_plan(positions: Mapping[str, Mapping[str, Any]], total_asset: float,
                            actual_pct: float, target_pct: Optional[float], *, basis: str,
                            days: int = 3, days_label: str = "3-5",
                            price_loader: Optional[Callable] = None,
                            amount_loader: Optional[Callable] = None,
                            commission_rate: float = COMMISSION_RATE) -> Optional[dict]:
    """把仓位从 actual_pct 降到 target_pct 的成本: 按持仓市值等比分摊卖出 (估算口径;
    实际卖哪几只以降仓清单为准)。actual ≤ target 时返回 None。"""
    if target_pct is None or total_asset <= 0 or actual_pct <= target_pct:
        return None
    total_mv = sum(float(p.get("broker_market_value", 0) or 0) for p in positions.values())
    if total_mv <= 0:
        return None
    reduce_value = (actual_pct - float(target_pct)) / 100.0 * total_asset
    reduce_value = min(reduce_value, total_mv)
    orders = []
    for code, p in positions.items():
        mv = float(p.get("broker_market_value", 0) or 0)
        if mv <= 0:
            continue
        mi = market_inputs(code, price_loader, amount_loader)
        orders.append(estimate_order(code, p.get("name", code), "sell", reduce_value * mv / total_mv, days=days,
                                     price=mi["price"], sigma_daily=mi["sigma_daily"], adv=mi["adv"],
                                     commission_rate=commission_rate))
    orders.sort(key=lambda o: -o["amount"])
    explicit = sum(o["explicit"] for o in orders)
    implicit = sum(o["implicit"] for o in orders)
    traded = sum(o["amount"] for o in orders)
    parts = [o["participation_pct"] for o in orders if o["participation_pct"] is not None]
    max_part = max(parts) if parts else None
    complete = sum(1 for o in orders if o["complete"])
    return {
        "basis": basis, "target_pct": round(float(target_pct), 1), "actual_pct": round(actual_pct, 1),
        "trade_value": round(traded, 0), "days": days, "days_label": days_label,
        "explicit": round(explicit, 2), "implicit": round(implicit, 2),
        "total": round(explicit + implicit, 2),
        "total_bps": round((explicit + implicit) / traded * 1e4, 2) if traded else 0.0,
        "explicit_bps": round(explicit / traded * 1e4, 2) if traded else 0.0,
        "implicit_bps": round(implicit / traded * 1e4, 2) if traded else 0.0,
        "max_participation_pct": round(max_part, 3) if max_part is not None else None,
        "data_coverage": {"complete": complete, "total": len(orders)},
        "algo": suggest_algo(max_part if complete == len(orders) else None, days_label),
        "orders": orders,
        "assumptions": {
            "allocation": "按持仓市值等比分摊卖出 (实际以降仓清单为准)",
            "commission_rate": commission_rate, "min_commission": MIN_COMMISSION,
            "stamp_tax_sell_stock": STAMP_TAX_A_SELL, "transfer_fee_stock": TRANSFER_FEE_A,
            "impact_model": f"半价差 + {IMPACT_Y}×σ日×√(日成交额/ADV{ADV_WINDOW})",
        },
    }
