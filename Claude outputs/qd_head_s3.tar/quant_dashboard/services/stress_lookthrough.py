"""
AlphaCore · 穿透暴露压力情景 (方案 B 阶段3B-3, 2026-10-29)
=========================================================

以穿透后的"主题暴露"(公司 → 行业 → 主题, 与集中度同一映射) 为输入, 施加显式的主题冲击,
得到条件损失估计。与 services/portfolio_vol 的 β 冲击互补: 那里按历史 β 线性传导,
这里按"持有了哪些产业"直接冲击, 不依赖历史相关性是否稳定。

性质与边界:
  · 条件估计, 非预测: 结果回答"若发生 X, 按当前暴露大约损失多少", 不回答 X 发生的概率。
  · 冲击参数是**示例假设, 未经校准**, 全部显式列出; 可在 strategy_runtime.json →
    stress_lookthrough.scenarios 覆盖 (结构同 DEFAULT_SCENARIOS)。
  · 未知暴露不按零冲击处理: 给出区间 [情景内最轻的权益冲击, 情景内最重的冲击]。
  · 现金冲击为 0; 线性汇总, 未计流动性折价、跌停无法成交等非线性效应。
"""
from __future__ import annotations

from typing import Any, Mapping, Optional

OTHER = "_other_equity"

DEFAULT_SCENARIOS: list[dict] = [
    {"key": "valuation_compression", "name": "估值压缩",
     "desc": "高估值主题估值回落, 其余权益小幅下跌",
     "shocks": {"半导体电子": -0.30, "软件互联网": -0.25, OTHER: -0.10}},
    {"key": "demand_downturn", "name": "产业需求下降",
     "desc": "半导体/电子景气下行, 相关产业链受拖累",
     "shocks": {"半导体电子": -0.25, "电力设备新能源": -0.10, "机器人智能制造": -0.10, OTHER: -0.05}},
    {"key": "correlation_rise", "name": "相关性上升",
     "desc": "系统性下跌中各主题同向下跌, 分散化失效",
     "shocks": {OTHER: -0.20}},
]
PARAM_SOURCE = "默认示例假设, 未经历史校准; 可在 strategy_runtime.json → stress_lookthrough.scenarios 覆盖"


def load_scenarios() -> tuple[list[dict], str]:
    try:
        from services.strategy_params import load_runtime_config
        sc = (load_runtime_config().get("stress_lookthrough") or {}).get("scenarios")
        if isinstance(sc, list) and sc and all(isinstance(s.get("shocks"), Mapping) for s in sc):
            return sc, "strategy_runtime.json → stress_lookthrough.scenarios"
    except Exception:
        pass
    return DEFAULT_SCENARIOS, PARAM_SOURCE


def theme_exposures(lookthrough: Mapping[str, Any], theme_of_industry) -> dict[str, float]:
    """穿透结果 → {主题: 市值}。行业缺失记为"行业未知"(视为权益, 用 _other_equity 冲击)。"""
    out: dict[str, float] = {}
    for c in lookthrough.get("companies") or []:
        ind = c.get("industry")
        theme = theme_of_industry(ind) if ind else "行业未知"
        out[theme] = out.get(theme, 0.0) + float(c.get("total_value") or 0.0)
    return out


def run(lookthrough: Mapping[str, Any], theme_of_industry, scenarios: Optional[list] = None,
        param_source: Optional[str] = None, top: int = 5) -> dict:
    if lookthrough.get("status") != "ok":
        return {"status": lookthrough.get("status", "unavailable")}
    if scenarios is None:
        scenarios, param_source = load_scenarios()
    total = float(lookthrough.get("total_value") or 0.0)
    unknown_v = float((lookthrough.get("unknown") or {}).get("value") or 0.0)
    exposures = theme_exposures(lookthrough, theme_of_industry)
    companies = lookthrough.get("companies") or []

    def pct(v: float) -> Optional[float]:
        return round(v / total * 100, 2) if total > 0 else None

    results = []
    for sc in scenarios:
        shocks = dict(sc["shocks"])
        other = float(shocks.get(OTHER, 0.0))
        by_theme = []
        known_loss = 0.0
        for theme, v in exposures.items():
            s = float(shocks.get(theme, other))
            loss = v * s
            known_loss += loss
            by_theme.append({"theme": theme, "exposure": round(v, 2), "shock": s, "loss": round(loss, 2)})
        by_theme.sort(key=lambda x: x["loss"])
        equity_shocks = [float(x) for x in shocks.values()] or [0.0]
        mild, severe = max(equity_shocks), min(equity_shocks)        # 冲击为负: max 最轻
        unk_range = (round(unknown_v * mild, 2), round(unknown_v * severe, 2))
        comp = []
        for c in companies:
            ind = c.get("industry")
            th = theme_of_industry(ind) if ind else "行业未知"
            s = float(shocks.get(th, other))
            comp.append({"code": c["code"], "name": c.get("name"), "theme": th,
                         "loss": round(float(c.get("total_value") or 0) * s, 2)})
        comp.sort(key=lambda x: x["loss"])
        results.append({
            "key": sc.get("key"), "name": sc.get("name"), "desc": sc.get("desc"),
            "shocks": shocks,
            "known_loss": round(known_loss, 2), "known_loss_pct": pct(known_loss),
            "unknown_loss_range": list(unk_range),
            "total_loss_range": [round(known_loss + unk_range[0], 2), round(known_loss + unk_range[1], 2)],
            "total_loss_pct_range": [pct(known_loss + unk_range[0]), pct(known_loss + unk_range[1])],
            "by_theme": by_theme[:top],
            "top_companies": comp[:top],
        })
    return {
        "status": "ok",
        "nature": "条件估计: 若发生所述冲击, 按当前穿透暴露线性估算的损失; 非预测, 不含发生概率",
        "param_source": param_source,
        "total_value": round(total, 2),
        "cash_pct": lookthrough.get("cash_pct"),
        "unknown_pct_of_total": (lookthrough.get("unknown") or {}).get("pct_of_total"),
        "unknown_rule": "未知暴露按情景内最轻~最重冲击给出区间, 不视为零冲击",
        "exposure_basis": "穿透 (ETF 指数权重或基金报告持仓 + 直接持股), 日期见 /portfolio/lookthrough",
        "limitations": ["线性汇总, 未计流动性折价与跌停无法成交", "冲击参数未经历史校准",
                        "ETF 成分为报告/权重日时点, 非实时持仓"],
        "scenarios": results,
    }
