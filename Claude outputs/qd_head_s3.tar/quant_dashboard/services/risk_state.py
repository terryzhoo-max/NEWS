"""
AlphaCore · 组合风险状态的唯一读取入口 (2026-11-02)
====================================================
执行层 (AIAE 执行目标)、合规引擎、审计页都从这里读"回撤刹车"与"组合波动预算", 不再各自直读缓存。

背景: 本机未运行 Redis 时缓存是进程内存, 服务重启即清空。
  · drawdown_brake 只在跟踪止盈日终提交 (约 15:50) 时写入 → 重启到下次日终之间读不到;
    旧逻辑下执行层上限瀑布缺"回撤刹车"一档 (实测有效上限 63% 而非 25%), 合规规则按"无数据"放行。
  · vol_budget 只在总览构建/持仓变更时写入 → 重启到总览重建之间合规规则按"无数据"放行。
回落顺序:
  · 回撤刹车: 缓存 → data_lake/trailing_snapshots 最近日终快照 (持久化; 是否过期仍由调用方按 as_of 判定)
  · 波动预算: 缓存 → 当场按本地持仓与行情重算 (与总览同一函数), 算出后回写缓存
"""
from __future__ import annotations

import logging
from typing import Any, Optional

logger = logging.getLogger("alphacore.risk_state")


def latest_eod_snapshot() -> Optional[dict]:
    """跟踪止盈最近一次日终快照 (含 drawdown 摘要与各持仓 RED/LEGACY 状态)。"""
    try:
        from services import trailing_stop_service as ts
        snap = ts.load_previous_snapshot("9999-12-31")
        return snap if isinstance(snap, dict) else None
    except Exception as e:
        logger.debug("日终快照读取失败: %s", e)
        return None


def _cache_get(key: str) -> Any:
    try:
        from services.cache_service import cache_manager
        return cache_manager.get_json(key)
    except Exception:
        return None


def _live_get(key: str) -> Any:
    """2026-11-02: 导入后 / 日终写入的最新风险状态 (data_lake/risk_state_live.json), 缓存缺失 (重启) 时使用。"""
    try:
        import json
        from services import trailing_stop_service as ts
        with open(ts.LIVE_RISK_PATH, "r", encoding="utf-8") as f:
            return (json.load(f) or {}).get(key)
    except Exception:
        return None


def state_label(state: Optional[dict]) -> str:
    """回撤刹车 / 越线状态的时间标注: 状态计算于 MM-DD HH:MM（持仓截至 MM-DD HH:MM 对账单）。

    旧缓存 / 日终快照无 computed_at 时标注"日终 as_of"。"""
    s = state or {}
    c, h = str(s.get("computed_at") or ""), str(s.get("holdings_as_of") or "")
    if len(c) >= 16:
        out = f"状态计算于 {c[5:10]} {c[11:16]}"
        if len(h) >= 16:
            out += f"（持仓截至 {h[5:10]} {h[11:16]} 对账单）"
        elif len(h) == 10:   # 2026-11-04: 估值时点未知时只有对账单日期
            out += f"（持仓截至 {h[5:10]} 对账单 · 估值时点未知）"
        return out
    a = str(s.get("as_of") or "")
    return f"状态为 {a[5:10]} 日终计算" if len(a) >= 10 else ""


def drawdown_brake() -> Optional[dict]:
    """回撤刹车摘要 {tier, cap_pct, dd, label, basis, as_of, source}; 无任何来源时返回 None。"""
    b = _cache_get("drawdown_brake")
    if isinstance(b, dict) and b.get("tier") is not None:
        return {**b, "source": b.get("source") or "cache"}
    b = _live_get("drawdown_brake")
    if isinstance(b, dict) and b.get("tier") is not None:
        return {**b, "source": "live_file"}
    snap = latest_eod_snapshot()
    dd = (snap or {}).get("drawdown")
    if isinstance(dd, dict) and dd.get("tier") is not None:
        return {**dd, "as_of": snap.get("as_of"), "source": "eod_snapshot"}
    return None


def trailing_report() -> Optional[dict]:
    """跟踪止盈持仓状态 {as_of, positions:[{ts_code,name,status,...}], source}。"""
    rep = _cache_get("trailing_stop_report")
    if isinstance(rep, dict) and isinstance(rep.get("positions"), list):
        return {**rep, "source": rep.get("source") or "cache"}
    rep = _live_get("trailing_stop_report")
    if isinstance(rep, dict) and isinstance(rep.get("positions"), list):
        return {**rep, "source": "live_file"}
    snap = latest_eod_snapshot()
    if isinstance(snap, dict) and isinstance(snap.get("positions"), list):
        return {"as_of": snap.get("as_of"), "positions": snap["positions"], "source": "eod_snapshot"}
    return None


def _recompute_vol_budget() -> Optional[dict]:
    """按本地持仓与行情重算 (与总览构建同一函数)。"""
    try:
        from services.portfolio_vol import compute_from_store, summarize
        return summarize(compute_from_store())
    except Exception as e:
        logger.warning("组合波动预算重算失败: %s", e)
        return None


def vol_budget() -> Optional[dict]:
    """组合波动预算摘要 (summarize 结果); 缓存缺失时当场重算并回写缓存。"""
    vb = _cache_get("vol_budget")
    if isinstance(vb, dict) and vb.get("max_equity_pct") is not None:
        return vb
    vb = _recompute_vol_budget()
    if isinstance(vb, dict) and vb:
        try:
            from services.cache_service import cache_manager
            from services.cache_store import get_cache_ttl
            cache_manager.set_json("vol_budget", vb, ttl_seconds=get_cache_ttl())
        except Exception:
            pass
        return {**vb, "source": "recomputed"}
    return None
