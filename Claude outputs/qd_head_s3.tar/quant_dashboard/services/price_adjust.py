"""
AlphaCore · 日线前复权 (2026-10-31)
==================================
tushare fund_daily 是未复权价格: ETF 份额拆分 (如 1 拆 3) 当天 close 断崖下跌, 历史均线、
乖离、波动率和回测收益都会被伪造成暴跌。交易所给的 pre_close 是除权除息后的参考价,
据此可把历史价格连续化。

做法与跟踪止盈完全相同 (复用 services.trailing_stop.back_adjust, 全项目一种口径):
  - pre_close_t 与 close_{t-1} 偏离 > tol 时, t 之前的 OHLC/pre_close 乘以 pre_close_t / close_{t-1}
  - 锚定最新收盘 (前复权): 最新一行价格与真实价格完全一致, 只修正历史
  - 成交量 (股数) 按同一因子反向换算, 成交额不变
  - 原始收盘保留在 raw_close; adj_close = 复权收盘; adj_factor = 复权收盘 / 原始收盘
幂等: 已复权的数据 (两者一致) 再次处理不变, raw_close 不会被覆盖。
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from services.trailing_stop import back_adjust

PRICE_COLUMNS = ("open", "high", "low", "close", "pre_close")
VOLUME_COLUMNS = ("vol", "volume")


def forward_adjust_daily(df: pd.DataFrame, tol: float = 0.003) -> pd.DataFrame:
    """tushare 日线 (trade_date 列) → 前复权日线。缺 pre_close 时价格不变, 只补齐复权列。"""
    if df is None or len(df) == 0 or "close" not in df.columns:
        return df
    d = df.copy()
    if "trade_date" in d.columns:
        d = d.sort_values("trade_date", kind="stable").reset_index(drop=True)
    for c in PRICE_COLUMNS + VOLUME_COLUMNS:
        if c in d.columns:
            d[c] = pd.to_numeric(d[c], errors="coerce")
    had_raw = "raw_close" in d.columns
    before = d["close"].to_numpy(dtype=float)

    out = back_adjust(d, tol=tol)
    if out is d:
        out = d.copy()
    factor = out["close"].to_numpy(dtype=float) / before          # 本次新增的调整 (无事件时为 1)

    for c in VOLUME_COLUMNS:
        if c in out.columns:
            with np.errstate(divide="ignore", invalid="ignore"):
                out[c] = out[c].to_numpy(dtype=float) / factor

    if had_raw:
        out["raw_close"] = d["raw_close"].to_numpy(dtype=float)    # 保留最初的原始价
    else:
        out["raw_close"] = before
    with np.errstate(divide="ignore", invalid="ignore"):
        out["adj_factor"] = out["close"].to_numpy(dtype=float) / out["raw_close"].to_numpy(dtype=float)
    out["adj_close"] = out["close"]
    out["adj_events"] = int(np.sum(np.abs(np.diff(np.log(np.where(factor > 0, factor, np.nan)))) > 1e-9)) \
        if len(factor) > 1 else 0
    return out
