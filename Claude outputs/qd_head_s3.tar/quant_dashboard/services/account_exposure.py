"""账户当前仓位 · 全站唯一来源 (2026-11-02, docs/ACCOUNT_EXPOSURE_AND_MR_LIMITS_PLAN.md 项 1)。

口径 (用户确认):
  - 持仓 / 现金: 最新券商对账单快照 (data_lake/portfolio_store.json)。
  - 价格: 导入当日用对账单价, 之后用最新收盘价 (portfolio_engine._pick_price 现行规则, 与回撤刹车一致)。
  - 分母 = 持仓市值 + 现金; 分子 = 持仓市值扣除国债逆回购 (逆回购按现金)。
  - 现金: 对账单有「可用」字段时用「可用」, 否则用「余额」; 「冻结资金」不计入分母 (单独显示, 只会更严)。
  - 券商表头「资产」只作一致性校验: 与 市值 + 现金 相差 > 0.5% 时标注。
口径切换日期: 2026-11-02 (此前合规在导入当日用表头「资产」作分母)。
"""
from __future__ import annotations

import json
import os
import re
from datetime import datetime, time as dtime, timedelta
from typing import Any, Mapping, Optional

DISCREPANCY_PCT = 0.5          # 券商「资产」与 市值 + 现金 的容差 (%)
STALE_INTRADAY_REJECT = False   # 盘中: 快照在上一交易日收盘后、今日开盘前 → 只提示 (True = 也拒绝)
SWITCH_DATE = "2026-11-02"

_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
STORE_PATH = os.path.join(_ROOT, "data_lake", "portfolio_store.json")
LEDGER_PATH = os.path.join(_ROOT, "data_lake", "trade_ledger.json")
CALENDAR_PATH = os.path.join(_ROOT, "data_lake", "trading_calendar.json")
OPEN_T, CLOSE_T = dtime(9, 30), dtime(15, 0)


def _num(v) -> Optional[float]:
    try:
        f = float(v)
    except (TypeError, ValueError):
        return None
    return f if f == f and f not in (float("inf"), float("-inf")) else None


def is_repo(ts_code: str, name: str = "") -> bool:
    code = str(ts_code or "").split(".")[0]
    return code.startswith(("131", "204")) or "逆回购" in (name or "") or bool(re.search(r"GC\d", name or ""))


def snapshot_cash(store: Mapping[str, Any]) -> tuple[float, str]:
    """对账单现金: 有「可用」用「可用」, 否则「余额」。返回 (现金, 来源说明)。"""
    avail = _num((store or {}).get("broker_available"))
    if avail is not None and avail >= 0:
        return avail, "可用资金"
    return float(_num((store or {}).get("cash")) or 0.0), "资金余额"


def load_store(path: str = STORE_PATH) -> Optional[dict]:
    try:
        with open(path, "r", encoding="utf-8") as f:
            store = json.load(f)
        return store if isinstance(store, dict) and isinstance(store.get("positions"), dict) else None
    except Exception:
        return None


_HHMM = re.compile(r"^([01]?\d|2[0-3]):?([0-5]\d)(?::?[0-5]\d)?$")


def parse_valuation_time(raw) -> Optional[dtime]:
    """对账单估值时点 "15:10" / "1510" / "15:10:00" → time; 不合法 → None。"""
    m = _HHMM.match(str(raw or "").strip())
    return dtime(int(m.group(1)), int(m.group(2))) if m else None


def snapshot_meta(store: Mapping[str, Any]) -> dict:
    """持仓快照时点 (2026-11-04 用户确认): 对账单日期 + 导入时填写的估值时点。

    不再用导入时间 (imported_at) 冒充估值时间: 估值时点未填 → at=None、time_known=False,
    买入门控按持仓过时处理 (见 staleness)。对账单日期未知 (文件名无日期且未指定) → date=None。
    返回 {at: datetime|None, date: 'YYYY-MM-DD'|None, time_known: bool}。"""
    s = store or {}
    day = None
    if s.get("statement_date_basis") != "unknown":
        try:
            day = datetime.strptime(str(s.get("import_date") or "")[:10], "%Y-%m-%d").date()
        except ValueError:
            day = None
    raw = s.get("valuation_time")
    at = None
    if raw:
        txt = str(raw).strip()
        if "T" in txt or len(txt) >= 16:          # 完整时间戳 (兼容)
            try:
                at = datetime.fromisoformat(txt.replace("Z", "")).replace(tzinfo=None, second=0, microsecond=0)
            except ValueError:
                at = None
        else:
            t = parse_valuation_time(txt)
            at = datetime.combine(day, t) if (t and day) else None
    return {"at": at, "date": day.isoformat() if day else None, "time_known": at is not None}


def _snapshot_time(store: Mapping[str, Any]) -> Optional[datetime]:
    """持仓快照时点; 估值时点或对账单日期未知 → None (不回落到导入时间)。"""
    return snapshot_meta(store)["at"]


def from_valuation(valuation: Mapping[str, Any], store: Optional[Mapping[str, Any]] = None) -> dict:
    """由 get_valuation() 结果计算统一口径 (get_valuation 已按本口径计算分母与权重)。"""
    store = store if store is not None else (load_store() or {})
    positions = (valuation or {}).get("positions") or []
    mv = 0.0
    repo = 0.0
    price_dates = []
    for p in positions:
        v = _num(p.get("market_value")) or 0.0
        if is_repo(p.get("ts_code"), p.get("name")):
            repo += v
        else:
            mv += v
        if p.get("price_as_of"):
            price_dates.append(str(p["price_as_of"]))
    # 总市值以估值接口汇总值为准 (与 _position_from_valuation 一致); 缺失时用逐只合计
    total_mv = _num((valuation or {}).get("market_value"))
    if total_mv is not None:
        mv = total_mv - repo
    cash = _num((valuation or {}).get("cash"))
    total = _num((valuation or {}).get("total_asset"))
    frozen = _num((store or {}).get("broker_frozen"))
    meta = snapshot_meta(store or {})
    snap = meta["at"]
    ok = bool(total and total > 0 and mv >= 0 and (total_mv is not None or positions))
    out = {
        "status": "ok" if ok else "unavailable",
        "pct": round(mv / total * 100, 1) if ok else None,
        "invested_value": round(mv, 2), "repo_value": round(repo, 2),
        "cash": cash, "cash_basis": (valuation or {}).get("cash_basis"),
        "frozen": frozen, "total_asset": total,
        "holdings_as_of": snap.isoformat(timespec="minutes") if snap else None,
        "holdings_date": meta["date"],
        "valuation_time_known": meta["time_known"],
        "statement_date": (store or {}).get("import_date"),
        "price_as_of": max(price_dates) if price_dates else (store or {}).get("import_date"),
        "basis": "持仓市值(不含逆回购) / (持仓市值 + 现金)",
        "switch_date": SWITCH_DATE,
    }
    bta = _num((store or {}).get("broker_total_asset"))
    stmt_mv = sum(_num(p.get("broker_market_value")) or 0.0 for p in ((store or {}).get("positions") or {}).values())
    stmt_cash, _ = snapshot_cash(store or {})
    computed = stmt_mv + stmt_cash
    if bta and computed > 0:
        diff = bta - computed
        out["broker_check"] = {"broker_total_asset": round(bta, 2), "computed": round(computed, 2),
                               "diff": round(diff, 2), "diff_pct": round(diff / computed * 100, 2),
                               "consistent": abs(diff) / computed * 100 <= DISCREPANCY_PCT}
        stmt_repo = sum(_num(p.get("broker_market_value")) or 0.0
                        for c, p in ((store or {}).get("positions") or {}).items() if is_repo(c, p.get("name")))
        out["header_pct"] = round((stmt_mv - stmt_repo) / bta * 100, 1)
    out["label"] = label(out)
    return out


def label(exp: Mapping[str, Any]) -> str:
    """显示用时间标注: 持仓截至 MM-DD HH:MM 对账单 · 价格 MM-DD 收盘。"""
    parts = []
    h = exp.get("holdings_as_of")
    d = str(exp.get("holdings_date") or "")
    if h:
        parts.append(f"持仓截至 {h[5:10]} {h[11:16]} 对账单")
    elif len(d) >= 10:
        parts.append(f"持仓截至 {d[5:10]} 对账单（估值时点未知）")
    p = str(exp.get("price_as_of") or "")
    if len(p) >= 8:
        p = p.replace("-", "")
        parts.append(f"价格 {p[4:6]}-{p[6:8]} 收盘")
    return " · ".join(parts)


def current_exposure() -> dict:
    """全站唯一的当前仓位。失败 → status=unavailable (调用方不得用其他数字替代)。"""
    try:
        from portfolio_engine import get_portfolio_engine
        valuation = get_portfolio_engine().get_valuation()
    except Exception as e:  # pragma: no cover - 防御
        return {"status": "unavailable", "pct": None, "reason": str(e)[:200]}
    return from_valuation(valuation)


def gate_pct(exp: Mapping[str, Any]) -> tuple[Optional[float], str]:
    """买入门控用仓位: 统一口径; 与表头「资产」口径相差 > 0.5% 时取较高值 (不比改前更宽松)。"""
    pct = _num(exp.get("pct"))
    hdr = _num(exp.get("header_pct"))
    chk = exp.get("broker_check") or {}
    if pct is not None and hdr is not None and not chk.get("consistent", True) and hdr > pct:
        return hdr, (f"券商「资产」与 市值+现金 相差 ¥{chk.get('diff'):,.0f}（{chk.get('diff_pct')}%），"
                     f"门控取较高的 {hdr}%（统一口径 {pct}%）")
    return pct, ""


# ── 持仓快照过时检查 (买入门控) ──

def _trading_days() -> Optional[set]:
    try:
        with open(CALENDAR_PATH, "r", encoding="utf-8") as f:
            return set(json.load(f))
    except Exception:
        return None


def _is_trading_day(d, cal) -> bool:
    if cal is not None:
        return d.strftime("%Y%m%d") in cal
    return d.weekday() < 5


def last_close(now: datetime, cal=None) -> datetime:
    """最近一个已收盘交易日的 15:00 (≤ now)。"""
    cal = _trading_days() if cal is None else cal
    d = now.date()
    if _is_trading_day(d, cal) and now.time() >= CLOSE_T:
        return datetime.combine(d, CLOSE_T)
    for _ in range(30):
        d -= timedelta(days=1)
        if _is_trading_day(d, cal):
            return datetime.combine(d, CLOSE_T)
    return datetime.combine(d, CLOSE_T)


def _ledger_trades_after(snap: datetime, path: str = LEDGER_PATH) -> list:
    try:
        with open(path, "r", encoding="utf-8") as f:
            ledger = json.load(f)
    except Exception:
        return []
    trades = ledger.get("trades") if isinstance(ledger, dict) else ledger
    out = []
    for t in trades or []:
        if not isinstance(t, dict) or t.get("side") not in ("buy", "sell"):
            continue
        try:
            ts = datetime.fromisoformat(f"{t.get('date')}T{t.get('time') or '15:00:00'}")
        except (TypeError, ValueError):
            continue
        if ts > snap:
            out.append({"date": t.get("date"), "time": t.get("time"), "ts_code": t.get("ts_code"),
                        "name": t.get("name"), "side": t.get("side")})
    return out


def staleness(store: Optional[Mapping[str, Any]] = None, now: Optional[datetime] = None,
              ledger_path: str = LEDGER_PATH, cal=None) -> dict:
    """持仓快照是否过时。返回 {status: fresh|warn|stale, reason, snapshot_at, trades_after}。

    - 对账单估值时点未知 (导入时未填) → stale (拒绝; 2026-11-04 用户确认, 不再用导入时间冒充)
    - 流水中有晚于快照的成交 → stale (拒绝)
    - 快照早于最近一个已收盘交易日 15:00 → stale (拒绝)
    - 交易日 09:30 后、快照在今日开盘前 (且不早于上一收盘) → warn (提示; STALE_INTRADAY_REJECT=True 时拒绝)
    """
    from services.market_clock import cn_now
    store = store if store is not None else (load_store() or {})
    now = now or cn_now().replace(tzinfo=None)
    cal = _trading_days() if cal is None else cal
    meta = snapshot_meta(store)
    snap = meta["at"]
    if snap is None:
        if meta["date"]:   # 2026-11-04 用户确认: 估值时点未知按持仓过时处理 (不用导入时间冒充)
            return {"status": "stale", "snapshot_at": None, "trades_after": [], "time_unknown": True,
                    "reason": f"对账单（{meta['date'][5:]}）估值时点未知，持仓按过时处理；"
                              "请重新导入并填写估值时点（收盘后导出填 15:00，盘中导出填实际时间）"}
        return {"status": "stale", "reason": "持仓快照时间未知，请先导入对账单", "snapshot_at": None, "trades_after": []}
    snap = snap.replace(tzinfo=None)
    after = _ledger_trades_after(snap, ledger_path)
    base = {"snapshot_at": snap.isoformat(timespec="minutes"), "trades_after": after}
    if after:
        names = "、".join(f"{t['date']} {t.get('time') or ''} {t.get('name') or t.get('ts_code')}" for t in after[:3])
        return {**base, "status": "stale",
                "reason": f"交易流水中有对账单之后的成交（{names}），持仓可能已过时，请先导入对账单"}
    lc = last_close(now, cal)
    if snap < lc:
        return {**base, "status": "stale",
                "reason": f"对账单早于最近一个交易日收盘（{lc:%m-%d %H:%M}），持仓可能已过时，请先导入对账单"}
    if _is_trading_day(now.date(), cal) and now.time() >= OPEN_T and snap < datetime.combine(now.date(), OPEN_T):
        return {**base, "status": "stale" if STALE_INTRADAY_REJECT else "warn",
                "reason": "对账单早于今日开盘，盘中成交未计入：持仓可能已过时，请先导入对账单"}
    return {**base, "status": "fresh", "reason": ""}
