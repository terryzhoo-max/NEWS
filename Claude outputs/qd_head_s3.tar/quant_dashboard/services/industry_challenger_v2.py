"""Pre-registered BULL-only industry challenger v2 (shadow research only).

Differences from v1 (``industry_challenger.py``), frozen 2026-10-31 before any
v2 backtest was run:

* momentum is a cross-sectional rank of correctly-counted 20/60-session returns
  (no 5-day or single-day inputs, no historical price-position factor);
* a 5-day vs 60-day turnover-trend rank replaces single-day volume "heat";
* exits use a volatility-scaled close stop (1 sigma of the holding horizon,
  clipped to 6%-15%) instead of a fixed regime stop plus MA60 break;
* signals are sampled every 5 sessions with 20-session holds, i.e. 4 staggered
  sleeves; statistics report pooled periods and an overlap-adjusted effective
  sample size;
* at most one ETF per pre-declared economic cluster enters a period.

This module never grants execution permission and is not wired to any page.
"""

from __future__ import annotations

import hashlib
import json
import math
import os
import threading
from datetime import date, datetime, timezone
from pathlib import Path
from typing import Any, Mapping

import numpy as np
import pandas as pd

from services.industry_validation import (
    PROJECT_ROOT,
    _classify_regime,
    build_universe_fingerprint,
    load_industry_universe_history,
    point_in_time_universe_coverage,
    resolve_universe_codes,
    simulate_candidate_trade,
    summarize_portfolio_periods,
    wilson_lower_bound,
)
from services.strategy_params import load_runtime_config


SPEC_PATH = PROJECT_ROOT / "config" / "industry_challenger_v2_spec.json"
_write_lock = threading.Lock()

_WEIGHT_KEYS = {"rps_20d", "rps_60d", "turnover_trend", "low_volatility"}
_FINGERPRINT_KEYS = (
    "schema_version", "spec_revision", "model_id", "backtest_start",
    "design_data_end", "validation_start", "validation_end",
    "previously_observed_end", "confirmation_start", "allowed_regimes",
    "signal_step_days", "holding_days", "min_history_days", "top_n",
    "max_per_cluster", "round_trip_cost_bps", "filters", "weights",
    "turnover_trend", "exit", "clusters",
)


def _finite(value: Any) -> float | None:
    if isinstance(value, bool):
        return None
    try:
        result = float(value)
    except (TypeError, ValueError):
        return None
    return result if math.isfinite(result) else None


def _date(value: Any) -> date | None:
    try:
        return date.fromisoformat(str(value)[:10])
    except (TypeError, ValueError):
        return None


def _instant(value: Any) -> datetime | None:
    try:
        parsed = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
    except (TypeError, ValueError):
        return None
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    return parsed.astimezone(timezone.utc)


def _range(value: Any, name: str, lower: float, upper: float) -> None:
    number = _finite(value)
    if number is None or number < lower or number > upper:
        raise ValueError(f"{name} must be between {lower} and {upper}")


def validate_v2_spec(spec: Mapping[str, Any]) -> None:
    if not isinstance(spec, Mapping) or spec.get("schema_version") != 1:
        raise ValueError("unsupported challenger v2 schema")
    if not isinstance(spec.get("spec_revision"), int) or spec["spec_revision"] < 1:
        raise ValueError("spec_revision must be positive")
    if spec.get("lifecycle") not in {"shadow", "disabled", "enabled"}:
        raise ValueError("invalid lifecycle")
    keys = (
        "backtest_start", "design_data_end", "validation_start",
        "validation_end", "previously_observed_end", "confirmation_start",
    )
    dates = {key: _date(spec.get(key)) for key in keys}
    if any(value is None for value in dates.values()):
        raise ValueError("split dates must be ISO dates")
    if not (
        dates["backtest_start"] <= dates["design_data_end"]
        < dates["validation_start"] <= dates["validation_end"]
        <= dates["previously_observed_end"] < dates["confirmation_start"]
    ):
        raise ValueError("temporal split leaks future observations")
    frozen = _instant(spec.get("frozen_at"))
    if frozen is None:
        raise ValueError("frozen_at must be an ISO timestamp")
    if dates["confirmation_start"] <= frozen.date():
        raise ValueError("confirmation must start after the spec was frozen")
    if spec.get("allowed_regimes") != ["BULL"]:
        raise ValueError("challenger must remain BULL-only")
    _range(spec.get("signal_step_days"), "signal_step_days", 1, 63)
    _range(spec.get("holding_days"), "holding_days", 5, 63)
    if int(spec["holding_days"]) % int(spec["signal_step_days"]) != 0:
        raise ValueError("holding_days must be a multiple of signal_step_days")
    _range(spec.get("min_history_days"), "min_history_days", 61, 1250)
    _range(spec.get("top_n"), "top_n", 1, 5)
    _range(spec.get("max_per_cluster"), "max_per_cluster", 1, 5)
    _range(spec.get("round_trip_cost_bps"), "round_trip_cost_bps", 0, 200)
    filters = spec.get("filters")
    if not isinstance(filters, Mapping):
        raise ValueError("filters must be an object")
    _range(filters.get("min_return_20d"), "min_return_20d", -0.5, 1)
    _range(filters.get("min_return_60d"), "min_return_60d", -0.8, 2)
    _range(filters.get("max_annualized_volatility_20d"), "max_annualized_volatility_20d", 0.05, 2)
    weights = spec.get("weights")
    if not isinstance(weights, Mapping) or set(weights) != _WEIGHT_KEYS:
        raise ValueError("weights are incomplete")
    for key, value in weights.items():
        _range(value, f"weights.{key}", 0, 1)
    if not math.isclose(sum(float(v) for v in weights.values()), 1.0, abs_tol=1e-9):
        raise ValueError("weights must sum to 1")
    turnover = spec.get("turnover_trend")
    if not isinstance(turnover, Mapping):
        raise ValueError("turnover_trend must be an object")
    _range(turnover.get("short_days"), "turnover_trend.short_days", 1, 20)
    _range(turnover.get("long_days"), "turnover_trend.long_days", 20, 250)
    if int(turnover["short_days"]) >= int(turnover["long_days"]):
        raise ValueError("turnover short window must be shorter than long window")
    exit_rule = spec.get("exit")
    if not isinstance(exit_rule, Mapping) or exit_rule.get("type") != "volatility_scaled_stop_or_horizon":
        raise ValueError("unsupported exit rule")
    _range(exit_rule.get("stop_sigma_multiple"), "stop_sigma_multiple", 0.25, 5)
    _range(exit_rule.get("stop_vol_lookback_days"), "stop_vol_lookback_days", 10, 120)
    _range(exit_rule.get("stop_min_pct"), "stop_min_pct", 0.01, 0.5)
    _range(exit_rule.get("stop_max_pct"), "stop_max_pct", 0.01, 0.5)
    if float(exit_rule["stop_min_pct"]) > float(exit_rule["stop_max_pct"]):
        raise ValueError("stop_min_pct must not exceed stop_max_pct")
    ma_exit = exit_rule.get("ma_exit_days")
    if ma_exit is not None:
        _range(ma_exit, "ma_exit_days", 5, 250)
    clusters = spec.get("clusters")
    if not isinstance(clusters, Mapping) or not clusters:
        raise ValueError("clusters must be a non-empty object")
    seen: set[str] = set()
    for name, codes in clusters.items():
        if not isinstance(codes, list) or not codes:
            raise ValueError(f"cluster {name} must list codes")
        for code in codes:
            if code in seen:
                raise ValueError(f"{code} appears in more than one cluster")
            seen.add(code)
    promotion = spec.get("promotion")
    if not isinstance(promotion, Mapping):
        raise ValueError("promotion must be an object")
    _range(promotion.get("min_confirmation_effective_periods"), "min_confirmation_effective_periods", 1, 1000)
    _range(promotion.get("min_positive_period_rate"), "min_positive_period_rate", 0, 1)
    _range(promotion.get("min_wilson_lower_95"), "min_wilson_lower_95", 0, 1)
    _range(promotion.get("min_profit_factor"), "min_profit_factor", 0, 100)
    _range(promotion.get("min_avg_excess_return"), "min_avg_excess_return", -1, 1)
    _range(promotion.get("max_drawdown"), "max_drawdown", 0, 1)
    _range(promotion.get("max_artifact_age_days"), "max_artifact_age_days", 1, 365)
    _range(promotion.get("max_data_lag_days"), "max_data_lag_days", 1, 90)
    if not isinstance(promotion.get("require_point_in_time_universe"), bool):
        raise ValueError("require_point_in_time_universe must be boolean")
    if not str(spec.get("artifact_path", "")).endswith(".json"):
        raise ValueError("artifact_path must be JSON")
    if not str(spec.get("forward_ledger_path", "")).endswith(".jsonl"):
        raise ValueError("forward_ledger_path must be JSONL")


def load_v2_spec(path: Path | str | None = None) -> dict:
    target = Path(path) if path is not None else SPEC_PATH
    with target.open("r", encoding="utf-8") as handle:
        spec = json.load(handle)
    validate_v2_spec(spec)
    return spec


def build_v2_fingerprint(spec: Mapping[str, Any]) -> str:
    validate_v2_spec(spec)
    payload = {key: spec[key] for key in _FINGERPRINT_KEYS}
    encoded = json.dumps(payload, sort_keys=True, separators=(",", ":"), ensure_ascii=True).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def _cluster_of(spec: Mapping[str, Any]) -> dict[str, str]:
    return {code: name for name, codes in spec["clusters"].items() for code in codes}


def volatility_stop_pct(close: pd.Series, spec: Mapping[str, Any]) -> float:
    """Stop distance = multiple x daily sigma x sqrt(holding days), clipped."""
    rule = spec["exit"]
    daily = close.pct_change().tail(int(rule["stop_vol_lookback_days"])).dropna()
    sigma = float(daily.std(ddof=1)) if len(daily) >= 10 else math.nan
    if not math.isfinite(sigma):
        return float(rule["stop_max_pct"])
    raw = float(rule["stop_sigma_multiple"]) * sigma * math.sqrt(int(spec["holding_days"]))
    return round(min(float(rule["stop_max_pct"]), max(float(rule["stop_min_pct"]), raw)), 6)


def rank_v2_candidates(
    price_frames: Mapping[str, pd.DataFrame], signal_date: Any, spec: Mapping[str, Any]
) -> list[dict]:
    """Rank only data observable on signal_date; future rows are ignored."""
    validate_v2_spec(spec)
    target = pd.Timestamp(signal_date)
    min_history = int(spec["min_history_days"])
    filters = spec["filters"]
    short_days = int(spec["turnover_trend"]["short_days"])
    long_days = int(spec["turnover_trend"]["long_days"])
    clusters = _cluster_of(spec)
    records: list[dict] = []
    for code, source in price_frames.items():
        frame = source.copy()
        frame["trade_date"] = pd.to_datetime(frame["trade_date"])
        history = frame[frame["trade_date"] <= target].sort_values("trade_date")
        close = pd.to_numeric(history["close"], errors="coerce").dropna()
        if len(close) < max(min_history, 61) or close.iloc[-1] <= 0:
            continue
        # 20/60 个交易日涨幅：起点为 t-20 / t-60 (iloc[-21] / iloc[-61])
        return_20d = float(close.iloc[-1] / close.iloc[-21] - 1)
        return_60d = float(close.iloc[-1] / close.iloc[-61] - 1)
        daily = close.pct_change().tail(20).dropna()
        annual_volatility = float(daily.std(ddof=1) * math.sqrt(252)) if len(daily) >= 10 else math.inf
        ma20 = float(close.tail(20).mean())
        ma60 = float(close.tail(60).mean())
        ma20_prior = float(close.iloc[-25:-5].mean())
        slope = ma20 / ma20_prior - 1 if ma20_prior > 0 else -math.inf
        latest = float(close.iloc[-1])
        if not (
            return_20d > float(filters["min_return_20d"])
            and return_60d > float(filters["min_return_60d"])
            and annual_volatility <= float(filters["max_annualized_volatility_20d"])
            and (latest > ma20 or not filters.get("require_above_ma20", True))
            and (latest > ma60 or not filters.get("require_above_ma60", True))
            and (slope >= 0 or not filters.get("require_ma20_slope_non_negative", True))
        ):
            continue
        amount = pd.to_numeric(history.get("amount"), errors="coerce") if "amount" in history else None
        turnover_trend = math.nan
        if amount is not None:
            amount = amount.dropna()
            if len(amount) >= long_days:
                long_mean = float(amount.tail(long_days).mean())
                if long_mean > 0:
                    turnover_trend = float(amount.tail(short_days).mean()) / long_mean
        records.append({
            "code": str(code),
            "cluster": clusters.get(str(code), f"unclustered:{code}"),
            "return_20d": return_20d,
            "return_60d": return_60d,
            "annualized_volatility_20d": annual_volatility,
            "turnover_trend": turnover_trend,
            "ma20_slope_5d": slope,
            "stop_pct": volatility_stop_pct(close, spec),
        })
    if not records:
        return []
    ranked = pd.DataFrame(records)
    ranked["rps_20d"] = ranked["return_20d"].rank(method="average", pct=True) * 100
    ranked["rps_60d"] = ranked["return_60d"].rank(method="average", pct=True) * 100
    ranked["low_volatility_score"] = ranked["annualized_volatility_20d"].rank(
        method="average", ascending=False, pct=True
    ) * 100
    # 成交额趋势缺失时取中性 50，不奖励也不惩罚
    ranked["turnover_trend_score"] = (
        ranked["turnover_trend"].rank(method="average", pct=True) * 100
    ).fillna(50.0)
    weights = spec["weights"]
    ranked["challenger_score"] = (
        ranked["rps_20d"] * float(weights["rps_20d"])
        + ranked["rps_60d"] * float(weights["rps_60d"])
        + ranked["turnover_trend_score"] * float(weights["turnover_trend"])
        + ranked["low_volatility_score"] * float(weights["low_volatility"])
    )
    ranked = ranked.sort_values(
        ["challenger_score", "return_20d", "code"], ascending=[False, False, True]
    )
    selected: list[dict] = []
    per_cluster: dict[str, int] = {}
    for row in ranked.to_dict("records"):
        if per_cluster.get(row["cluster"], 0) >= int(spec["max_per_cluster"]):
            continue
        per_cluster[row["cluster"]] = per_cluster.get(row["cluster"], 0) + 1
        selected.append(row)
        if len(selected) >= int(spec["top_n"]):
            break
    numeric = [
        "return_20d", "return_60d", "annualized_volatility_20d", "turnover_trend",
        "ma20_slope_5d", "stop_pct", "rps_20d", "rps_60d", "turnover_trend_score",
        "low_volatility_score", "challenger_score",
    ]
    for item in selected:
        for key in numeric:
            value = _finite(item.get(key))
            item[key] = round(value, 8) if value is not None else None
    return selected


def summarize_v2_window(trades: list[Mapping[str, Any]], spec: Mapping[str, Any]) -> dict:
    """Pooled period stats plus an overlap-adjusted effective sample size."""
    sleeves = int(spec["holding_days"]) // int(spec["signal_step_days"])
    pooled = summarize_portfolio_periods(list(trades))
    periods = int(pooled.get("periods") or 0)
    effective = periods / sleeves if sleeves else periods
    rate = pooled.get("positive_period_rate")
    effective_n = int(math.floor(effective))
    effective_wins = int(round((rate or 0) * effective_n))
    pooled["sleeves"] = sleeves
    pooled["effective_periods"] = round(effective, 2)
    pooled["wilson_lower_95_effective"] = (
        wilson_lower_bound(effective_wins, effective_n) if effective_n > 0 else None
    )
    by_sleeve = {}
    for sleeve in range(sleeves):
        subset = [t for t in trades if int(t.get("sleeve", -1)) == sleeve]
        stats = summarize_portfolio_periods(subset)
        by_sleeve[str(sleeve)] = {
            key: stats.get(key)
            for key in ("periods", "positive_period_rate", "profit_factor", "avg_excess_return", "total_return", "max_drawdown")
        }
    pooled["by_sleeve"] = by_sleeve
    # 交错组在时间上重叠：把全部期次顺序连乘会夸大收益与回撤。
    # 复利收益与回撤只在单个(不重叠)组内计算，汇报最差组回撤与各组收益中位数。
    sleeve_drawdowns = [v["max_drawdown"] for v in by_sleeve.values() if v.get("max_drawdown") is not None]
    sleeve_totals = [v["total_return"] for v in by_sleeve.values() if v.get("total_return") is not None]
    pooled["total_return"] = None
    pooled["max_drawdown"] = round(min(sleeve_drawdowns), 8) if sleeve_drawdowns else None
    pooled["max_drawdown_basis"] = "worst_single_sleeve"
    pooled["median_sleeve_total_return"] = round(float(np.median(sleeve_totals)), 8) if sleeve_totals else None
    exits: dict[str, dict] = {}
    for trade in trades:
        bucket = exits.setdefault(str(trade.get("exit_reason")), {"count": 0, "sum": 0.0})
        bucket["count"] += 1
        bucket["sum"] += float(trade.get("net_return") or 0)
    pooled["exit_reasons"] = {
        reason: {"count": v["count"], "avg_net_return": round(v["sum"] / v["count"], 6)}
        for reason, v in sorted(exits.items())
    }
    return pooled


def split_v2_trades(trades: list[dict], spec: Mapping[str, Any]) -> dict[str, list[dict]]:
    design_end = pd.Timestamp(spec["design_data_end"])
    validation_start = pd.Timestamp(spec["validation_start"])
    validation_end = pd.Timestamp(spec["validation_end"])
    observed_end = pd.Timestamp(spec["previously_observed_end"])
    confirmation_start = pd.Timestamp(spec["confirmation_start"])
    result = {"design": [], "validation": [], "previously_observed": [], "confirmation": []}
    for trade in trades:
        signal = pd.Timestamp(trade["signal_date"])
        if signal <= design_end:
            result["design"].append(trade)
        elif validation_start <= signal <= validation_end:
            result["validation"].append(trade)
        elif validation_end < signal <= observed_end:
            result["previously_observed"].append(trade)
        elif signal >= confirmation_start:
            result["confirmation"].append(trade)
    return result


def evaluate_v2_artifact(
    artifact: Mapping[str, Any] | None,
    *,
    spec: Mapping[str, Any] | None = None,
    universe_history: Mapping[str, Any] | None = None,
    now: datetime | None = None,
) -> dict:
    spec = dict(spec or load_v2_spec())
    validate_v2_spec(spec)
    evidence = artifact if isinstance(artifact, Mapping) else {}
    universe = universe_history or load_industry_universe_history()
    promotion = spec["promotion"]
    current = now or datetime.now(timezone.utc)
    if current.tzinfo is None:
        current = current.replace(tzinfo=timezone.utc)
    reasons: list[str] = []
    gates: dict[str, dict] = {}

    def gate(name: str, actual: Any, threshold: Any, passed: bool, reason: str) -> None:
        gates[name] = {"actual": actual, "threshold": threshold, "passed": bool(passed)}
        if not passed:
            reasons.append(reason)

    gate("model_id", evidence.get("model_id"), spec["model_id"], evidence.get("model_id") == spec["model_id"], "V2_MODEL_ID_MISMATCH")
    fingerprint = build_v2_fingerprint(spec)
    gate("spec_fingerprint", evidence.get("spec_fingerprint"), fingerprint, evidence.get("spec_fingerprint") == fingerprint, "V2_SPEC_FINGERPRINT_MISMATCH")
    universe_fp = build_universe_fingerprint(universe)
    gate("universe_fingerprint", evidence.get("universe_fingerprint"), universe_fp, evidence.get("universe_fingerprint") == universe_fp, "V2_UNIVERSE_FINGERPRINT_MISMATCH")
    generated = _instant(evidence.get("generated_at"))
    age = max(0.0, (current - generated).total_seconds() / 86400) if generated else None
    gate("artifact_freshness", round(age, 2) if age is not None else None, promotion["max_artifact_age_days"], age is not None and age <= promotion["max_artifact_age_days"], "V2_ARTIFACT_STALE")
    data_end = _date(evidence.get("data_end_date"))
    lag = max(0, (current.date() - data_end).days) if data_end else None
    gate("data_freshness", lag, promotion["max_data_lag_days"], lag is not None and lag <= promotion["max_data_lag_days"], "V2_DATA_STALE")
    methodology = evidence.get("methodology") if isinstance(evidence.get("methodology"), Mapping) else {}
    pit = methodology.get("point_in_time_universe") is True
    require_pit = promotion["require_point_in_time_universe"] is True
    gate("point_in_time_universe", pit, require_pit, pit or not require_pit, "V2_POINT_IN_TIME_UNIVERSE_UNAVAILABLE")
    confirmation = evidence.get("confirmation") if isinstance(evidence.get("confirmation"), Mapping) else {}
    effective = _finite(confirmation.get("effective_periods"))
    gate("confirmation_effective_periods", effective, promotion["min_confirmation_effective_periods"],
         effective is not None and effective >= float(promotion["min_confirmation_effective_periods"]),
         "V2_CONFIRMATION_SAMPLE_TOO_SMALL")
    for metric, key, reason in (
        ("positive_period_rate", "min_positive_period_rate", "V2_CONFIRMATION_WIN_RATE_BELOW_GATE"),
        ("wilson_lower_95_effective", "min_wilson_lower_95", "V2_CONFIRMATION_CONFIDENCE_BELOW_GATE"),
        ("profit_factor", "min_profit_factor", "V2_CONFIRMATION_PROFIT_FACTOR_BELOW_GATE"),
        ("avg_excess_return", "min_avg_excess_return", "V2_CONFIRMATION_EXCESS_BELOW_GATE"),
    ):
        actual = _finite(confirmation.get(metric))
        threshold = float(promotion[key])
        gate(f"confirmation_{metric}", actual, threshold, actual is not None and actual >= threshold, reason)
    drawdown = _finite(confirmation.get("max_drawdown"))
    gate("confirmation_max_drawdown", drawdown, -float(promotion["max_drawdown"]),
         drawdown is not None and drawdown >= -float(promotion["max_drawdown"]),
         "V2_CONFIRMATION_DRAWDOWN_ABOVE_LIMIT")
    evidence_reasons = list(dict.fromkeys(reasons))
    evidence_ready = not evidence_reasons
    lifecycle = spec["lifecycle"]
    if lifecycle == "shadow":
        reasons.append("V2_SHADOW_ONLY")
    elif lifecycle == "disabled":
        reasons.append("V2_DISABLED")
    return {
        "model_id": spec["model_id"],
        "lifecycle": lifecycle,
        "evidence_ready": evidence_ready,
        "execution_ready": evidence_ready and lifecycle == "enabled",
        "reasons": list(dict.fromkeys(reasons)),
        "gates": gates,
    }


def run_v2_validation(
    price_frames: Mapping[str, pd.DataFrame],
    benchmark: pd.DataFrame,
    *,
    spec: Mapping[str, Any] | None = None,
    universe_history: Mapping[str, Any] | None = None,
    generated_at: datetime | None = None,
) -> dict:
    spec = dict(spec or load_v2_spec())
    validate_v2_spec(spec)
    universe = universe_history or load_industry_universe_history()
    runtime = load_runtime_config()
    benchmark = benchmark.copy()
    benchmark["trade_date"] = pd.to_datetime(benchmark["trade_date"])
    benchmark = benchmark.sort_values("trade_date").drop_duplicates("trade_date").reset_index(drop=True)
    normalized: dict[str, pd.DataFrame] = {}
    for code, source in price_frames.items():
        frame = source.copy()
        frame["trade_date"] = pd.to_datetime(frame["trade_date"])
        normalized[code] = frame.sort_values("trade_date").drop_duplicates("trade_date").reset_index(drop=True)
    step = int(spec["signal_step_days"])
    holding = int(spec["holding_days"])
    sleeves = holding // step
    first = max(
        int(spec["min_history_days"]) - 1,
        int(benchmark["trade_date"].searchsorted(pd.Timestamp(spec["backtest_start"]))),
    )
    last = len(benchmark) - holding - 1
    latest_date = benchmark["trade_date"].iloc[-1]
    complete_universe = point_in_time_universe_coverage(universe, spec["backtest_start"], latest_date)
    trades: list[dict] = []
    for bench_index in range(first, max(first, last + 1), step):
        sleeve = ((bench_index - first) // step) % sleeves
        signal_date = benchmark.iloc[bench_index]["trade_date"]
        regime = _classify_regime(
            pd.to_numeric(benchmark.loc[:bench_index, "close"], errors="coerce").dropna().values,
            runtime["regime"],
        )
        if regime not in spec["allowed_regimes"]:
            continue
        covered = point_in_time_universe_coverage(universe, signal_date)
        allowed = resolve_universe_codes(universe, signal_date) if covered else set(normalized)
        ranked = rank_v2_candidates(
            {code: normalized[code] for code in allowed if code in normalized}, signal_date, spec
        )
        benchmark_trade = simulate_candidate_trade(
            benchmark, signal_index=bench_index, holding_days=holding,
            stop_loss=1.0, round_trip_cost_bps=0, ma_exit_days=None,
        )
        if benchmark_trade is None:
            continue
        for candidate in ranked:
            frame = normalized[candidate["code"]]
            matches = np.flatnonzero(frame["trade_date"].values == signal_date.to_datetime64())
            if len(matches) != 1:
                continue
            trade = simulate_candidate_trade(
                frame,
                signal_index=int(matches[0]),
                holding_days=holding,
                stop_loss=float(candidate["stop_pct"]),
                round_trip_cost_bps=float(spec["round_trip_cost_bps"]),
                ma_exit_days=spec["exit"].get("ma_exit_days"),
            )
            if trade is None:
                continue
            trade.update(candidate)
            trade["regime"] = regime
            trade["sleeve"] = sleeve
            trade["benchmark_return"] = benchmark_trade["gross_return"]
            trade["excess_return"] = round(trade["net_return"] - benchmark_trade["gross_return"], 8)
            trades.append(trade)
    split = split_v2_trades(trades, spec)
    now = generated_at or datetime.now(timezone.utc)
    if now.tzinfo is None:
        now = now.replace(tzinfo=timezone.utc)
    latest_regime = _classify_regime(
        pd.to_numeric(benchmark["close"], errors="coerce").dropna().values, runtime["regime"]
    )
    latest_covered = point_in_time_universe_coverage(universe, latest_date)
    latest_allowed = resolve_universe_codes(universe, latest_date) if latest_covered else set()
    latest_candidates = (
        rank_v2_candidates({c: normalized[c] for c in latest_allowed if c in normalized}, latest_date, spec)
        if latest_regime in spec["allowed_regimes"] and latest_covered else []
    )
    artifact = {
        "schema_version": 1,
        "model_id": spec["model_id"],
        "generated_at": now.astimezone(timezone.utc).isoformat(),
        "data_end_date": latest_date.strftime("%Y-%m-%d"),
        "spec_fingerprint": build_v2_fingerprint(spec),
        "universe_fingerprint": build_universe_fingerprint(universe),
        "methodology": {
            "point_in_time_universe": complete_universe,
            "universe_coverage_start": spec["backtest_start"],
            "universe_coverage_end": latest_date.strftime("%Y-%m-%d"),
            "signal_sampling": f"every {step} sessions, {holding}-session hold, {sleeves} staggered sleeves",
            "effective_sample_note": "pooled periods overlap; effective_periods = periods / sleeves",
            "entry": "next_session_open",
            "exit": "volatility_scaled_close_stop_or_horizon_close",
            "previously_observed_note": spec.get("observed_windows_note"),
        },
        "design": summarize_v2_window(split["design"], spec),
        "validation": summarize_v2_window(split["validation"], spec),
        "previously_observed": summarize_v2_window(split["previously_observed"], spec),
        "confirmation": summarize_v2_window(split["confirmation"], spec),
        "latest_snapshot": {
            "date": latest_date.strftime("%Y-%m-%d"),
            "regime": latest_regime,
            "candidates": latest_candidates,
            "universe_coverage_complete": latest_covered,
            "execution_allowed": False,
        },
        "trades": trades,
    }
    status = evaluate_v2_artifact(artifact, spec=spec, universe_history=universe, now=now)
    artifact["passed"] = status["evidence_ready"]
    artifact["promotion_reasons"] = status["reasons"]
    artifact["promotion_gates"] = status["gates"]
    return artifact


def _artifact_path(spec: Mapping[str, Any]) -> Path:
    configured = Path(spec["artifact_path"])
    return configured if configured.is_absolute() else PROJECT_ROOT / configured


def write_v2_artifact(artifact: Mapping[str, Any]) -> Path:
    spec = load_v2_spec()
    target = _artifact_path(spec)
    target.parent.mkdir(parents=True, exist_ok=True)
    temp = target.with_name(f"{target.name}.{os.getpid()}.{threading.get_ident()}.tmp")
    with _write_lock:
        try:
            with temp.open("w", encoding="utf-8", newline="\n") as handle:
                json.dump(artifact, handle, ensure_ascii=False, indent=2, allow_nan=False)
                handle.write("\n")
            os.replace(temp, target)
        finally:
            if temp.exists():
                temp.unlink()
    return target


def run_local_v2_validation(*, write: bool = True) -> dict:
    from core_etf_config import CORE_ETF_CODES

    industry_dir = PROJECT_ROOT / "data_lake" / "industry_prices_qfq"
    benchmark_path = PROJECT_ROOT / "data_lake" / "daily_prices" / "000300.SH.parquet"
    frames = {
        code: pd.read_parquet(industry_dir / f"{code}.parquet")
        for code in CORE_ETF_CODES
        if (industry_dir / f"{code}.parquet").exists()
    }
    artifact = run_v2_validation(
        frames, pd.read_parquet(benchmark_path), universe_history=load_industry_universe_history()
    )
    if write:
        write_v2_artifact(artifact)
    return artifact
