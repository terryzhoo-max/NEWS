"""
AlphaCore · 统一日志模块
========================
替代散落各处的 print() 调用，提供:
  - 结构化 JSON 日志 (生产环境)
  - 彩色 console 日志 (开发环境)
  - 统一的日志器命名空间 (ac.xxx)
  - @log_execution_time 装饰器

用法:
    from services.logger import get_logger
    logger = get_logger("warmup")
    logger.info("ERP 预热完成", extra={"erp": 4.5, "status": "success"})
"""

import logging
import time
import functools
import os
import json
from datetime import datetime

# P1-6: 缓存默认 LogRecord 键集合，避免每条日志都创建临时对象
_DEFAULT_LOG_KEYS = frozenset(logging.LogRecord("", 0, "", 0, "", (), None).__dict__.keys()) | {"message", "asctime"}


# ─── 日志级别: 环境变量控制 ───
LOG_LEVEL = os.getenv("AC_LOG_LEVEL", "INFO").upper()
LOG_FORMAT = os.getenv("AC_LOG_FORMAT", "console")  # "console" | "json"


class JsonFormatter(logging.Formatter):
    """生产级 JSON 日志格式 (适配 ELK/Loki)"""
    def format(self, record):
        log_entry = {
            "ts": datetime.fromtimestamp(record.created).isoformat(),
            "level": record.levelname,
            "logger": record.name,
            "msg": record.getMessage(),
            "module": record.module,
            "func": record.funcName,
            "line": record.lineno,
        }
        # 附加 extra 字段
        for key in record.__dict__:
            if key not in _DEFAULT_LOG_KEYS:
                log_entry[key] = record.__dict__[key]
        if record.exc_info and record.exc_info[0]:
            log_entry["exception"] = self.formatException(record.exc_info)
        return json.dumps(log_entry, ensure_ascii=False, default=str)


class ConsoleFormatter(logging.Formatter):
    """开发友好的彩色 console 格式"""
    COLORS = {
        "DEBUG": "\033[36m",     # cyan
        "INFO": "\033[32m",      # green
        "WARNING": "\033[33m",   # yellow
        "ERROR": "\033[31m",     # red
        "CRITICAL": "\033[41m",  # red bg
    }
    RESET = "\033[0m"

    def format(self, record):
        color = self.COLORS.get(record.levelname, "")
        ts = datetime.fromtimestamp(record.created).strftime("%H:%M:%S")
        prefix = f"{color}[{ts}] [{record.levelname[0]}] [{record.name}]{self.RESET}"
        msg = record.getMessage()
        if record.exc_info and record.exc_info[0]:
            msg += "\n" + self.formatException(record.exc_info)
        return f"{prefix} {msg}"


def _setup_handler():
    """创建统一的 StreamHandler (避免重复添加)"""
    handler = logging.StreamHandler()
    if LOG_FORMAT == "json":
        handler.setFormatter(JsonFormatter())
    else:
        handler.setFormatter(ConsoleFormatter())
    return handler


def _setup_file_handler():
    """P4: 文件日志轮转 — 持久化日志用于事后审计"""
    from logging.handlers import RotatingFileHandler
    # 2026-10-23: 允许用 ALPHACORE_LOG_DIR 重定向 (pytest 设为临时目录, 避免测试日志混入生产日志)
    log_dir = os.environ.get("ALPHACORE_LOG_DIR") or os.path.join(
        os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "logs")
    os.makedirs(log_dir, exist_ok=True)
    log_file = os.path.join(log_dir, "alphacore.log")
    handler = RotatingFileHandler(
        log_file, maxBytes=5 * 1024 * 1024,  # 5 MB
        backupCount=5, encoding="utf-8"
    )
    handler.setFormatter(JsonFormatter())  # 文件永远用 JSON 格式
    return handler


# 全局 handler 单例
_handler = _setup_handler()
try:
    _file_handler = _setup_file_handler()
except Exception:
    _file_handler = None  # 文件系统不可用时静默降级


# ── 引擎命名空间统一注册 ──────────────────────────────
# 引擎模块使用 logging.getLogger("alphacore.*") 命名空间。
# 在父 logger 上注册 handler, 所有子 logger 自动继承格式/级别/文件轮转。
def _setup_namespace(ns: str):
    """为指定命名空间的父 logger 注册统一 handler"""
    parent = logging.getLogger(ns)
    if not parent.handlers:
        parent.addHandler(_handler)
        if _file_handler:
            parent.addHandler(_file_handler)
        parent.setLevel(getattr(logging, LOG_LEVEL, logging.INFO))
        parent.propagate = False

_setup_namespace("alphacore")
_setup_namespace("ac")



def get_logger(name: str) -> logging.Logger:
    """获取命名日志器 (统一 ac.xxx 命名空间)

    P1-5 修复: 依赖 namespace 继承机制，不再为子 logger 重复添加 handler。
    ac 父 logger 已在模块初始化时注册了 console + file handler，
    子 logger 通过 propagate 自动继承。

    Args:
        name: 模块简称，如 "warmup", "cache", "reactor", "erp"

    Returns:
        配置好的 Logger 实例
    """
    return logging.getLogger(f"ac.{name}")


def log_execution_time(logger_name: str = "perf"):
    """装饰器: 记录函数执行耗时

    用法:
        @log_execution_time("erp")
        def generate_report():
            ...
    """
    def decorator(func):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            logger = get_logger(logger_name)
            start = time.perf_counter()
            try:
                result = func(*args, **kwargs)
                elapsed = time.perf_counter() - start
                logger.info(f"{func.__name__} 完成 ({elapsed:.2f}s)")
                return result
            except Exception as e:
                elapsed = time.perf_counter() - start
                logger.error(f"{func.__name__} 失败 ({elapsed:.2f}s): {e}")
                raise
        return wrapper
    return decorator
