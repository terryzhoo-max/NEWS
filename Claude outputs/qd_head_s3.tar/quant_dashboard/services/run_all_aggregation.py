"""
AlphaCore · run-all 汇总层 (2026-10-31)
=======================================
只负责"怎么汇总", 不改任何策略引擎的信号算法与参数。

设计原则 (与 docs/superpowers/specs/2026-10-25-personal-analysis-execution-separation.md 一致):
  1. 独立信号源 (MR / DIV / MOM / GEM) 才参与计数、共振和行动信号;
     宏观层 (ERP 旧综合分 / AIAE ETF 池) 已体现在执行目标与子策略权重中, 只作背景, 不再重复投票。
  2. 每个信号源带验证状态; 只有 status == "validated" 才归入"已验证", 其余归入"观察"。
     不拦截信号, 只分层展示。
  3. 不同策略的评分尺度不同, 排序用策略内百分位, 不跨策略直接比较或相加原始分。
  4. 各策略的市场状态标签定义不同 (MR: 沪深300三重条件; MOM: 沪深300 vs MA120 …),
     标签不一致只作说明, 不据此调整仓位。
"""
from __future__ import annotations

from typing import Any, Mapping, Optional

SIGNAL_SLEEVES = ("mr", "div", "mom", "gem")
MACRO_SLEEVES = ("erp", "aiae_etf")
SELL_SIGNALS = frozenset({"sell", "sell_half", "sell_weak"})
SLEEVE_CN = {"mr": "均值回归", "div": "红利趋势", "mom": "动量轮动", "gem": "GEM双动量",
             "erp": "ERP择时", "aiae_etf": "AIAE标的"}

_STATUS_LABEL = {
    "validated": "已验证",
    "insufficient_evidence": "证据不足",
    "rejected": "验证被拒",
    "stale": "验证已过期",
    "unlinked": "影子·未接入验证",
    "unverified": "无验证记录",
    "macro_legacy": "旧规则·仅对照",
    "macro_layer": "宏观层·仅背景",
    "unknown": "状态未知",
}


def _entry(status: str, detail: str) -> dict:
    tier = "verified" if status == "validated" else ("macro" if status.startswith("macro") else "observe")
    return {"status": status, "label": _STATUS_LABEL.get(status, status), "tier": tier, "detail": detail}


def _mr_evidence(mr_regime: Optional[str], mr_lifecycle_fn=None) -> dict:
    if not mr_regime:
        return _entry("unknown", "无均值回归信号, 无法确定当前市场状态")
    try:
        if mr_lifecycle_fn is None:
            from services.strategy_params import get_mr_lifecycle as mr_lifecycle_fn  # noqa: N813
        st = str(mr_lifecycle_fn(mr_regime).get("status") or "unknown")
    except Exception as e:  # 配置读取失败 → 未知, 不当作通过
        return _entry("unknown", f"读取生命周期失败: {e}")
    if st not in _STATUS_LABEL:
        st = "unknown"
    return _entry(st, f"{mr_regime.upper()} 状态参数: {_STATUS_LABEL.get(st, st)}")


def sleeve_evidence(mr_regime: Optional[str], mom_regime: Optional[str], *,
                    mr_lifecycle_fn=None, runtime: Optional[Mapping] = None) -> dict:
    """各信号源的验证状态 (只读配置, 不改变任何验证结论)。"""
    out: dict[str, dict] = {}

    # MR: 读参数生命周期 (含到期降级为 stale); 状态未知 (无 MR 信号) 时不默认按震荡读取
    out["mr"] = _mr_evidence(mr_regime, mr_lifecycle_fn)

    # MOM: 配置中的验证生命周期来自行业 Alpha 模型, 是否适用于动量轮动 V3.1 尚未确认 → 未接入
    ref = None
    if mom_regime:
        try:
            if runtime is None:
                from services.strategy_params import load_runtime_config
                runtime = load_runtime_config()
            ref = (((runtime.get("strategies") or {}).get("momentum") or {}).get("validation") or {}) \
                .get("regime_lifecycle", {}).get(mom_regime.upper())
        except Exception:
            ref = None
    out["mom"] = _entry("unlinked", "行业 Alpha 验证配置在当前状态为 "
                        f"{ref or '未知'}；尚未确认适用于动量轮动 V3.1, 信号不拦截")

    out["div"] = _entry("unverified", "无验证记录")
    out["gem"] = _entry("unverified", "无验证记录")
    out["erp"] = _entry("macro_legacy", "旧综合分信号 (Step3 验证无预测力), 操作口径为 ERP v4 档位")
    out["aiae_etf"] = _entry("macro_layer", "AIAE 档位已体现在执行目标与子策略权重中")
    return out


def _pct_rank(signals: list) -> dict:
    """策略内百分位 (0~1, 分数越高越大); 同分取平均名次。"""
    scored = [(s.get("ts_code") or s.get("code") or "", float(s.get("signal_score") or 0)) for s in signals]
    n = len(scored)
    if n == 0:
        return {}
    if n == 1:
        return {scored[0][0]: 1.0}
    values = sorted(v for _, v in scored)
    out = {}
    for code, v in scored:
        below = sum(1 for x in values if x < v)
        equal = sum(1 for x in values if x == v)
        out[code] = round((below + (equal - 1) / 2) / (n - 1), 4)
    return out


def count_signals(signals_by_sleeve: Mapping[str, list], evidence: Mapping[str, dict]) -> dict:
    """只统计独立信号源; 按验证分层。"""
    per = {}
    tot = {"buy": 0, "sell": 0, "buy_verified": 0, "sell_verified": 0}
    for k in SIGNAL_SLEEVES:
        sigs = signals_by_sleeve.get(k) or []
        b = sum(1 for s in sigs if s.get("signal") == "buy")
        se = sum(1 for s in sigs if s.get("signal") in SELL_SIGNALS)
        per[k] = {"buy": b, "sell": se, "total": len(sigs)}
        tot["buy"] += b
        tot["sell"] += se
        if (evidence.get(k) or {}).get("tier") == "verified":
            tot["buy_verified"] += b
            tot["sell_verified"] += se
    tot["buy_observe"] = tot["buy"] - tot["buy_verified"]
    tot["sell_observe"] = tot["sell"] - tot["sell_verified"]
    tot["verified_sleeves"] = sum(1 for k in SIGNAL_SLEEVES if (evidence.get(k) or {}).get("tier") == "verified")
    tot["signal_sleeves"] = len(SIGNAL_SLEEVES)
    return {"total": tot, "by_sleeve": per, "basis": "independent_sleeves_only"}


def compute_resonance(signals_by_sleeve: Mapping[str, list]) -> dict:
    """独立信号源之间的共振: 同一标的被 ≥2 个独立策略覆盖时比较方向。"""
    maps, ranks = {}, {}
    for k in SIGNAL_SLEEVES:
        sigs = signals_by_sleeve.get(k) or []
        ranks[k] = _pct_rank(sigs)
        m = {}
        for s in sigs:
            code = s.get("ts_code") or s.get("code") or ""
            if code:
                m[code] = s
        maps[k] = m

    codes = set().union(*[set(m) for m in maps.values()]) if maps else set()
    cbuy, csell, div = [], [], []
    for code in codes:
        present = [k for k in SIGNAL_SLEEVES if code in maps[k]]
        if len(present) < 2:
            continue
        sig = {k: (maps[k][code].get("signal") or "hold") if k in present else "-" for k in SIGNAL_SLEEVES}
        buy = sum(1 for k in present if sig[k] == "buy")
        sell = sum(1 for k in present if sig[k] in SELL_SIGNALS)
        name = next((maps[k][code].get("name") for k in present if maps[k][code].get("name")), code)
        pct = [ranks[k].get(code, 0.0) for k in present]
        entry = {"code": code, "name": name, "signals": sig, "covered": len(present),
                 "buy_votes": buy, "sell_votes": sell,
                 "mean_pct_rank": round(sum(pct) / len(pct), 4)}
        if buy >= 2 and buy > sell:
            entry["resonance"] = "strong_buy"
            cbuy.append(entry)
        elif sell >= 2 and sell > buy:
            entry["resonance"] = "strong_sell"
            csell.append(entry)
        elif buy >= 1 and sell >= 1:
            entry["resonance"] = "divergence"
            div.append(entry)
    cbuy.sort(key=lambda e: (-e["buy_votes"], -e["mean_pct_rank"], e["code"]))
    csell.sort(key=lambda e: (-e["sell_votes"], e["mean_pct_rank"], e["code"]))
    div.sort(key=lambda e: e["code"])
    return {"consensus_buy": cbuy, "consensus_sell": csell, "divergence": div,
            "total_overlap": len(cbuy) + len(csell),   # 只含同方向共振
            "divergence_count": len(div),
            "sleeves": list(SIGNAL_SLEEVES), "basis": "independent_sleeves_only"}


def rank_action_signals(signals_by_sleeve: Mapping[str, list], evidence: Mapping[str, dict],
                        n_buy: int = 4, n_sell: int = 4) -> dict:
    """行动信号: 已验证优先, 再按策略内百分位排序 (不跨策略比较原始分)。"""
    buys, sells = [], []
    for k in SIGNAL_SLEEVES:
        sigs = signals_by_sleeve.get(k) or []
        rk = _pct_rank(sigs)
        ev = evidence.get(k) or _entry("unknown", "")
        n = len(sigs)
        for s in sigs:
            code = s.get("ts_code") or s.get("code") or ""
            score = float(s.get("signal_score") or 0)
            # 策略内名次 (按分数从高到低, 并列取最好名次)
            pos = 1 + sum(1 for o in sigs if float(o.get("signal_score") or 0) > score)
            item = {"source": k, "name": s.get("name", ""), "code": code, "signal": s.get("signal"),
                    "signal_score": s.get("signal_score"), "suggested_position": s.get("suggested_position"),
                    "pct_rank": rk.get(code, 0.0), "rank_in_sleeve": pos, "sleeve_size": n,
                    "evidence_status": ev["status"],
                    "evidence_label": ev["label"], "evidence_tier": ev["tier"]}
            if s.get("signal") == "buy":
                buys.append(item)
            elif s.get("signal") in SELL_SIGNALS:
                sells.append(item)
    buys.sort(key=lambda x: (x["evidence_tier"] != "verified", -x["pct_rank"], x["source"], x["code"]))
    sells.sort(key=lambda x: (x["evidence_tier"] != "verified", x["pct_rank"], x["source"], x["code"]))
    return {"buy": buys[:n_buy], "sell": sells[:n_sell],
            "basis": "verified_first_then_within_strategy_percentile"}


def regime_labels(mr: Optional[str], div: Optional[str], mom: Optional[str]) -> dict:
    labels = {"mr": mr, "div": div, "mom": mom}
    known = {v for v in labels.values() if v}
    return {"labels": labels, "consistent": len(known) <= 1,
            "note": "各策略状态定义不同 (MR 三重条件 / MOM MA120 等), 不一致只作说明, 不调整仓位"}


def sleeve_meta(results: Mapping[str, Any], degraded: list) -> dict:
    """各策略结果的计算时间与降级状态。"""
    out = {}
    for k, r in results.items():
        ts = r.get("timestamp") if isinstance(r, Mapping) else None
        status = r.get("status") if isinstance(r, Mapping) else None
        out[k] = {"computed_at": ts, "status": status, "degraded": k in degraded or (k == "aiae_etf" and "aiae" in degraded)}
    return out
