"""JCS 方向评价契约 (F1 修复, 2026-10-27)。

JCS 是"信号一致性/数据健康"综合评分: 一致看多和一致看空都可以得高分,
因此分数本身不是方向, 更不是概率。准确率只能评价写入当日明确保存的方向。

- 方向来源: 写入时刻生产 JCS 各引擎方向 (-1/0/+1) 按 _JCS_WEIGHTS 加权后的净值
  net = Σ wᵢ·dᵢ / Σ wᵢ;  |net| < NEUTRAL_BAND → 0 (中性, 不评价)。
- 评价对象: 沪深300 (000300.SH) T 日收盘 → T+5 交易日收盘的收益符号。
- 历史上没有保存方向的记录 → legacy_direction_unknown, 不评价;
  不允许用当前模型重算当时方向 (会把今天的模型冒充当时的预测)。
- 该评价只衡量"方向符号命中率", 不代表收益、胜率或交易许可。
"""
from __future__ import annotations

from typing import Any, Mapping, Optional

EVAL_VERSION = "jcs-direction-eval-v2"  # v2 (2026-11-01): 净方向改用 JCS V26.0 宏观 4 因子权重 (MR/BOND 移出)
EVAL_HORIZON_DAYS = 5
BENCHMARK = "000300.SH"
DIRECTION_SOURCE = "jcs_engine_weighted_net_direction"
NEUTRAL_BAND = 0.10  # 净方向权重绝对值 < 10% 视为中性; 改动须升级 EVAL_VERSION

STATUS_EVALUATED = "evaluated"
STATUS_NEUTRAL = "neutral_not_scored"
STATUS_FLAT = "flat_return_not_scored"
STATUS_LEGACY = "legacy_direction_unknown"
STATUS_PENDING = "pending"

UNSCORED_STATUSES = (STATUS_NEUTRAL, STATUS_FLAT, STATUS_LEGACY)


def _default_weights() -> Mapping[str, float]:
    from dashboard_modules.decision.jcs import _JCS_WEIGHTS
    return _JCS_WEIGHTS


def derive_signal_direction(directions: Optional[Mapping[str, Any]],
                            weights: Optional[Mapping[str, float]] = None) -> dict:
    """由写入时刻的引擎方向得到净方向。缺失/非法方向按 0 处理 (降低净值, 不猜测)。"""
    weights = weights or _default_weights()
    total = float(sum(weights.values())) or 1.0
    net = 0.0
    for key, w in weights.items():
        raw = (directions or {}).get(key, 0)
        try:
            d = int(raw)
        except (TypeError, ValueError):
            d = 0
        if d not in (-1, 0, 1):
            d = 0
        net += float(w) * d
    net /= total
    direction = 0 if abs(net) < NEUTRAL_BAND else (1 if net > 0 else -1)
    return {"direction": direction, "net_weight": round(net, 4)}


def direction_fields_from_jcs(jcs: Mapping[str, Any],
                              weights: Optional[Mapping[str, float]] = None) -> dict:
    """生成写入 decision_log 的方向/评价元数据列。"""
    derived = derive_signal_direction(jcs.get("directions"), weights)
    v27 = ((jcs.get("shadow") or {}).get("v27") or {})
    return {
        "signal_direction": derived["direction"],
        "signal_net_weight": derived["net_weight"],
        "direction_source": DIRECTION_SOURCE,
        "eval_horizon_days": EVAL_HORIZON_DAYS,
        "eval_version": EVAL_VERSION,
        "eval_status": STATUS_PENDING,
        "model_version": jcs.get("model_version"),
        "v27_direction": v27.get("direction") if v27.get("status") == "ok" else None,
        "v27_confidence": v27.get("confidence") if v27.get("status") == "ok" else None,
    }


def evaluate_direction(direction: Optional[int], market_return: float) -> tuple[str, Optional[int]]:
    """返回 (eval_status, signal_correct)。signal_correct 仅在 evaluated 时为 0/1。"""
    if direction is None:
        return STATUS_LEGACY, None
    if int(direction) == 0:
        return STATUS_NEUTRAL, None
    if market_return == 0:
        return STATUS_FLAT, None
    return STATUS_EVALUATED, 1 if int(direction) * market_return > 0 else 0


def evaluation_meta() -> dict:
    return {
        "eval_version": EVAL_VERSION,
        "horizon_days": EVAL_HORIZON_DAYS,
        "benchmark": BENCHMARK,
        "direction_source": DIRECTION_SOURCE,
        "neutral_band": NEUTRAL_BAND,
        "score_is_direction": False,
        "semantics": "按写入当日保存的净方向评价 T+5 沪深300 涨跌符号; JCS 高分可表示一致看空; "
                     "中性、持平与缺少当时方向的历史记录不计入; 命中率不代表收益或交易许可",
    }
