"""服务启动预热状态 (2026-11-02, 进程内)。

问题: 重启后核心预热 (ERP → AIAE → Rates → Dashboard, 串行) 完成前, /decision/hub 会用残缺缓存现算一次,
合规按"数据缺失"判硬阻断 (AIAE 锁定 / VIX 不可用), 执行目标可能不可用; 该结果再被 SWR 缓存 20 分钟 (周末 40 分钟)。

规则:
  - warming  (预热中, 未超时): 决策中枢 / 合规 / 风险矩阵 / 审计接口不计算、不读旧缓存、不写缓存, 页面显示"数据加载中";
              买入门控默认拒绝。
  - ready    (核心预热全部成功): 正常走缓存。
  - partial  (有核心任务失败, 或 10 分钟超时仍未完成): 按数据缺失处理 — 照常现算 (对应合规规则维持
              "数据缺失即硬阻断", 买入门控随之拒绝), 结果不写缓存; 页面显示"部分数据缺失：XX"; 记日志。
              之后任一缺失任务成功 (定时预热 / 早间补偿) 即自动恢复 ready。
  - not_started (未登记, 如测试或脚本): 按 ready 处理。

状态只存在本进程内存: 不写 Redis, 避免重启后读到上一次进程的状态。
"""
from __future__ import annotations

import threading
import time
from functools import wraps

from services.logger import get_logger

logger = get_logger("ac.warmup_state")

CORE_TASKS = ("ERP", "AIAE", "Rates", "Dashboard")
TIMEOUT_SEC = 600
TASK_LABELS = {
    "ERP": "ERP 估值",
    "AIAE": "AIAE（执行目标 / 合规仓位上限）",
    "Rates": "利率",
    "Dashboard": "总览数据（VIX / 波动预算等）",
}
# 重启前进程留下的决策类缓存 (Redis 模式下会跨进程保留), 启动时清掉, 预热完成后首个请求重算
STALE_KEYS = ("swr_decision_hub", "swr_risk_matrix")

_lock = threading.Lock()
_state: dict = {"started_at": None, "tasks": {}, "timeout_logged": False, "partial_logged": False}


def begin(tasks=CORE_TASKS, now: float | None = None, clear_cache: bool = True) -> None:
    """lifespan 启动时调用: 登记核心任务, 清掉重启前的决策类缓存。"""
    with _lock:
        _state.update(started_at=now if now is not None else time.time(),
                      tasks={t: {"done": False, "ok": None, "error": None} for t in tasks},
                      timeout_logged=False, partial_logged=False)
    if clear_cache:
        try:
            from services.cache_service import cache_manager
            for key in STALE_KEYS:
                cache_manager.delete(key)
        except Exception as e:  # 缓存不可用不影响启动
            logger.warning("清理重启前决策缓存失败: %s", e)
    logger.info("启动预热开始: 核心任务 %s, 超时 %ds", list(tasks), TIMEOUT_SEC)


def mark_done(name: str, ok: bool, error: str | None = None) -> None:
    """核心任务结束 (成功或失败)。未登记的任务名忽略。之后的成功会覆盖之前的失败。"""
    with _lock:
        task = _state["tasks"].get(name)
        if task is None:
            return
        task.update(done=True, ok=bool(ok), error=(str(error)[:200] if error else None))
        if ok:
            _state["partial_logged"] = False
    if not ok:
        logger.warning("核心预热失败 [%s]: %s — 相关数据按缺失处理", name, error)


def track(name: str):
    """装饰预热函数: 正常返回 (且返回值不是 False) 记成功, 抛异常或返回 False 记失败 (异常照常抛出)。"""
    def deco(fn):
        @wraps(fn)
        def wrapper(*args, **kwargs):
            try:
                result = fn(*args, **kwargs)
            except Exception as e:
                mark_done(name, False, e)
                raise
            mark_done(name, result is not False, None if result is not False else "预热未完成")
            return result
        return wrapper
    return deco


def status(now: float | None = None) -> dict:
    """{"phase": not_started|warming|ready|partial, "pending": [...], "failed": [...], "missing": [...], "elapsed_sec"}"""
    now = now if now is not None else time.time()
    with _lock:
        started = _state["started_at"]
        tasks = {k: dict(v) for k, v in _state["tasks"].items()}
    if started is None:
        return {"phase": "not_started", "pending": [], "failed": [], "missing": [], "labels": [], "elapsed_sec": None}
    pending = [k for k, v in tasks.items() if not v["done"]]
    failed = [k for k, v in tasks.items() if v["done"] and not v["ok"]]
    elapsed = round(now - started, 1)
    if pending and elapsed < TIMEOUT_SEC:
        phase, missing = "warming", []
    elif pending or failed:
        phase, missing = "partial", pending + failed
    else:
        phase, missing = "ready", []
    result = {"phase": phase, "pending": pending, "failed": failed, "missing": missing,
              "labels": [TASK_LABELS.get(k, k) for k in missing], "elapsed_sec": elapsed,
              "timeout_sec": TIMEOUT_SEC}
    if phase == "partial":
        _log_partial(result, timed_out=bool(pending))
    return result


def _log_partial(st: dict, timed_out: bool) -> None:
    key = "timeout_logged" if timed_out else "partial_logged"
    with _lock:
        if _state[key]:
            return
        _state[key] = True
    logger.warning("启动预热%s: 部分数据缺失 %s — 合规按数据缺失处理, 决策结果不写缓存",
                   f"超时 ({TIMEOUT_SEC}s)" if timed_out else "未全部成功", st["missing"])


def missing_text(st: dict) -> str:
    return "部分数据缺失：" + "、".join(st.get("labels") or st.get("missing") or [])


def warming_payload(st: dict | None = None) -> dict:
    """预热期统一响应: 不含任何读数。"""
    st = st or status()
    pending = [TASK_LABELS.get(k, k) for k in st.get("pending", [])]
    return {"status": "warming_up", "message": "数据加载中（服务启动预热）",
            "warmup": {**st, "pending_labels": pending}}


def public(st: dict) -> dict:
    """附在响应里的预热状态 (partial 时给页面显示缺失项)。"""
    return {"phase": st["phase"], "missing": st.get("missing", []), "labels": st.get("labels", []),
            "message": missing_text(st) if st["phase"] == "partial" else None}
