"""执行目标 vs 实际仓位 (2026-11-02, 决策中枢复盘标签)。只读已落盘记录, 不计算新口径。

- 执行目标: data_lake/aiae_exec_forward_log.csv (执行层前向记录, 2026-10-30 起; 只在评估日/风险事件日写一行,
  其余交易日沿用最近一次目标)。
- 实际仓位: data_lake/trailing_snapshots/<日期>.json 的 drawdown.invested_pct (跟踪止盈日终快照, 回撤刹车口径)。
  与决策中枢 action_plan.current_position 的分母略有差异 (约 0.1–0.3pp), 页面注明来源。
- 执行层上线前的日期没有执行目标, 返回 None, 不回填。
"""
import csv
import json
import os

_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
LOG_PATH = os.path.join(_ROOT, "data_lake", "aiae_exec_forward_log.csv")
SNAPSHOT_DIR = os.path.join(_ROOT, "data_lake", "trailing_snapshots")


def _num(v):
    try:
        x = float(v)
        return x if x == x else None
    except (TypeError, ValueError):
        return None


def _read_log(path):
    try:
        with open(path, encoding="utf-8-sig", newline="") as f:
            rows = [r for r in csv.DictReader(f) if r.get("trade_date")]
    except FileNotFoundError:
        return []
    rows.sort(key=lambda r: (r["trade_date"], r.get("recorded_at") or ""))
    return rows


def _read_snapshots(directory, days):
    try:
        names = sorted(f for f in os.listdir(directory) if f.endswith(".json"))
    except FileNotFoundError:
        return []
    out = []
    for name in names[-days:]:
        try:
            with open(os.path.join(directory, name), encoding="utf-8") as f:
                snap = json.load(f)
        except Exception:
            continue
        dd = snap.get("drawdown") or {}
        out.append({"date": snap.get("as_of") or name[:-5],
                    "actual": _num(dd.get("invested_pct")),
                    "brake_cap": _num(dd.get("cap_pct"))})
    return out


def build(days=60, log_path=None, snapshot_dir=None):
    log = _read_log(log_path or LOG_PATH)
    snaps = _read_snapshots(snapshot_dir or SNAPSHOT_DIR, max(1, min(int(days), 365)))
    points = []
    for s in snaps:
        target = None
        for r in log:  # 按时间正序, 取当日及之前最后一次目标
            if r["trade_date"] <= s["date"]:
                target = _num(r.get("target"))
        gap = round(s["actual"] - target, 1) if (s["actual"] is not None and target is not None) else None
        points.append({**s, "target": target, "gap": gap})
    events = [{"date": r["trade_date"], "trigger": r.get("trigger"), "target": _num(r.get("target")),
               "actual": _num(r.get("actual")), "risk_events": r.get("risk_events") or ""} for r in log]
    return {
        "status": "success",
        "points": points,
        "events": events,
        "exec_since": log[0]["trade_date"] if log else None,
        "sources": {
            "target": "AIAE 执行层前向记录 (评估日/风险事件日写入, 其余日沿用)",
            "actual": "跟踪止盈日终快照 drawdown.invested_pct (回撤刹车口径)",
        },
    }
