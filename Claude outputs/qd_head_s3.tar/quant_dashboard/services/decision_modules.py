"""决策中枢模块开关 (2026-11-02 精简)。

唯一配置: config/decision_modules.json。enabled=false 只隐藏面板、跳过前端加载;
未列出的模块默认开启; 配置文件缺失或损坏时全部视为开启 (不因配置故障隐藏核心模块)。
"""
import json
import logging
from pathlib import Path

logger = logging.getLogger("alphacore.decision_modules")

CONFIG_PATH = Path(__file__).resolve().parent.parent / "config" / "decision_modules.json"

# 核心链路模块不受开关控制 (执行目标 / 合规 / 跟踪止盈 是已定的唯一出口)
CORE_MODULES = frozenset({"execution", "compliance", "trailing_stop"})


def load_modules(path=None):
    """读取开关配置; 失败返回空配置 (= 全部开启)。"""
    p = Path(path) if path else CONFIG_PATH
    try:
        data = json.loads(p.read_text(encoding="utf-8"))
        modules = data.get("modules")
        if not isinstance(modules, dict):
            raise ValueError("modules 必须是对象")
        for key in CORE_MODULES & set(modules):
            modules[key] = {**modules[key], "enabled": True}
        return {"version": data.get("version"), "review_on": data.get("review_on"), "modules": modules}
    except FileNotFoundError:
        return {"version": None, "review_on": None, "modules": {}}
    except Exception as e:  # 配置损坏不影响页面: 全部开启并记录
        logger.warning(f"decision_modules.json 读取失败, 全部模块按开启处理: {e}")
        return {"version": None, "review_on": None, "modules": {}, "error": str(e)[:200]}


def is_enabled(key, path=None):
    if key in CORE_MODULES:
        return True
    item = load_modules(path)["modules"].get(key)
    return not (isinstance(item, dict) and item.get("enabled") is False)
