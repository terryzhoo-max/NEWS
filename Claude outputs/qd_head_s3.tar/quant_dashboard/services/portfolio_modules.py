"""组合页模块开关 (2026-11-03 精简, docs/PORTFOLIO_SLIMMING_PLAN.md)。

唯一配置: config/portfolio_modules.json。规则与决策中枢开关相同 (services/decision_modules.py):
enabled=false 只隐藏面板、跳过前端加载; 未列出的模块默认开启; 配置缺失或损坏时全部视为开启。
"""
from pathlib import Path

from services.decision_modules import load_modules as _load_modules

CONFIG_PATH = Path(__file__).resolve().parent.parent / "config" / "portfolio_modules.json"


def load_modules(path=None):
    return _load_modules(path or CONFIG_PATH)


def is_enabled(key, path=None):
    item = load_modules(path)["modules"].get(key)
    return not (isinstance(item, dict) and item.get("enabled") is False)
