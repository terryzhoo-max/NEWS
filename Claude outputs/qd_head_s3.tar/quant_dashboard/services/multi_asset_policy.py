"""Versioned policy assumptions, in percentage points; not fitted return forecasts."""
import math
from types import MappingProxyType

POLICY_VERSION = "multi-asset-v2.3"
# 2026-11-01 利率 V2 预注册验证结论 DEMOTE (docs/RATES_V2_VALIDATION_RESULTS.md):
# V2 / 只用趋势 / 现行 V1.5 三个信号样本外均无显著择时能力 → 美债固定 SAA, 利率信号只作背景。
# 若日后有新版本通过新的预注册验证, 把它改回 True 即恢复战术倾斜 (原 fail-closed 契约测试仍保留)。
BOND_TACTICAL_ENABLED = False
BOND_TACTICAL_DISABLED_NOTE = "利率信号未通过样本外验证 (2026-11-01)，美债固定 SAA，信号仅作背景"
SAA_WEIGHTS = MappingProxyType({"equity_cn": 50.0, "bond": 30.0, "gold": 10.0, "cash": 10.0})
BOUNDS = MappingProxyType({"equity_cn": (0.0, 95.0), "bond": (5.0, 35.0),
                          "gold": (0.0, 15.0), "cash": (5.0, 100.0)})
SIGNAL_THRESHOLD = 25.0
# 2026-11-01 (v2.3): 删除 "JCS<40 暂停组合目标" 闸门 —— JCS 定位为宏观环境读数, 不作执行依据。
# 权益方向沿用 V25.3 的固定权重 (含 MR 策略信号), 与 JCS 权重解耦; 方向只作展示, 不改变权益目标
# (权益目标 = AIAE 建议仓位, 受 AIAE 上限约束)。
EQUITY_SIGNAL_WEIGHTS = MappingProxyType({"aiae": 0.325, "erp": 0.225, "vix": 0.175, "mr": 0.175})
MAX_SOURCE_AGE_DAYS = 7  # Daily rates only; H.10 uses its weekly publication calendar.
MAX_RATES_CACHE_AGE_SEC = 21600
H10_INGESTION_GRACE_HOURS = 2  # Operational tolerance after 16:15 NY release, not an official FRED SLA.
GOLD_FACTOR_WEIGHTS = MappingProxyType({"real_rate": 0.40, "dollar": 0.30, "inflation": 0.30})
GOLD_SIGNAL_PARAMS = MappingProxyType({
    "trend_window": 20, "dollar_min_observations": 25,
    "real_rate_full_scale_pct": 2.0, "real_rate_trend_scale_pp": 0.5,
    "dollar_full_scale_change_pct": 3.0,
    "breakeven_center_pct": 2.0, "breakeven_full_scale_pp": 1.0,
    "breakeven_trend_scale_pp": 0.3, "trend_bonus_max_points": 20.0,
})


def finite_number(value, lower, upper):
    return (not isinstance(value, bool) and isinstance(value, (int, float))
            and math.isfinite(value) and lower <= value <= upper)


def signal_direction(signal):
    if signal is None:
        return "unavailable"
    return "bullish" if signal > SIGNAL_THRESHOLD else ("bearish" if signal < -SIGNAL_THRESHOLD else "neutral")


def tactical_weight(asset, signal):
    """Continuous asymmetric tilt around SAA; negative signals never mean shorts."""
    if asset not in ("bond", "gold") or not finite_number(signal, -100, 100):
        raise ValueError("Invalid tactical signal")
    anchor = SAA_WEIGHTS[asset]
    low, high = BOUNDS[asset]
    span = high - anchor if signal >= 0 else anchor - low
    return round(anchor + span * signal / 100.0, 4)


if abs(sum(SAA_WEIGHTS.values()) - 100) > 1e-9:
    raise ValueError("SAA weights must sum to 100")
for _key, _weight in SAA_WEIGHTS.items():
    if not BOUNDS[_key][0] <= _weight <= BOUNDS[_key][1]:
        raise ValueError(f"Invalid SAA/bounds for {_key}")
