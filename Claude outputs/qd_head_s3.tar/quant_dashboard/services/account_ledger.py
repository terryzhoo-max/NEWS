"""
AlphaCore · 整账户现金台账 (方案 B 阶段2A, 2026-10-28)
====================================================

复用 services/trade_import 的解码与版式解析, 把券商导出中的
  · 成交 (买/卖/申赎/中签)       → 交收现金事件 settlement (引用成交台账 key, 不重复存成交)
  · 入金 / 出金                  → deposit / withdrawal   (外部资金流, 不是投资盈亏)
  · 红利 / 利息                  → dividend / interest     (投资收益)
  · 扣税 / 独立费用              → tax / fee               (投资成本)
  · 逆回购划出/划回              → repo                    (账户内部资金转移)
  · 无法归类的资金行             → unclassified            (不计入任何合计, 列入 issues)
记入 data_lake/account_ledger.json (只追加)。

设计约束
--------
1. 事件唯一键 = 行内容指纹 + 同文件内相同行序号; 与文件名无关 → 重复导入/区间重叠的
   两份导出不会重复记账。
2. 成交现金: 有"发生金额"时直接采用 (已含费用, 不再扣费); 没有时 = ∓成交金额 − 费用;
   费用列也缺失则标记 cash_estimated / fees_unknown, 不猜。
3. 更正只追加 corrections (void / replace / enrich), 原事件永不修改。
   enrich (验收修补, 2026-10-29): 同一成交后续来源带来更完整的现金信息 (历史成交 → 交割单),
   按"发生金额 > 金额−费用 > 金额(费用未知)"的完整度只升不降地补全, 同级不一致记为冲突。
4. 只有含"发生金额"列的导出 (交割单/资金流水) 才算"现金覆盖"; 历史成交导出
   只有成交, 其区间内的入出金/分红未知 → 对账报告 insufficient_cash_coverage, 不补造。
5. 账户隐私: 本模块不记录资金账号/股东代码。
6. 覆盖截止日 (2026-11-04, 用户授权按专业判断): 通达信交割单只能导出近 60 天, 截止日即导出日, 但文件
   只列有记录的日子 → 末尾无成交、无资金流的日子按"最后一行"永远算缺口。改为按文件名开头的导出日
   (YYYYMMDD) 推定: 默认覆盖到导出日的前一交易日 (盘中导出当天记录可能不全, 保守);
   用户勾选"收盘后导出"且导入时北京时间已过 15:00 (或导出日早于今天) → 覆盖到导出日当天。
   文件名无日期、日期早于最后一行或晚于今天 → 不推定, 仍按最后一行。来源记录 covered_to /
   covered_basis 留痕; 起始端仍按最早一行 (相邻导出大量重叠, 由前一份覆盖)。
"""
from __future__ import annotations

import hashlib
import json
import os
from collections import Counter
import re
from datetime import date, datetime, timedelta, timezone
from typing import Any, Iterable, Mapping, Optional

from services.logger import get_logger

logger = get_logger("ac.account_ledger")

_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ACCOUNT_LEDGER_PATH = os.path.join(_ROOT, "data_lake", "account_ledger.json")
LEDGER_VERSION = 1
RECONCILE_TOLERANCE = 1.0  # 元; 券商四舍五入差异

EXTERNAL_FLOW_TYPES = ("deposit", "withdrawal")
INCOME_TYPES = ("dividend", "interest")
COST_TYPES = ("tax", "fee")
INTERNAL_TYPES = ("repo",)


def ledger_path_for(trade_ledger_path: Optional[str]) -> str:
    """测试或自定义成交台账路径时, 现金台账放在同一目录。"""
    if trade_ledger_path:
        return os.path.join(os.path.dirname(os.path.abspath(trade_ledger_path)), "account_ledger.json")
    return ACCOUNT_LEDGER_PATH


# ═══════════════════════════════════════════════════════
#  分类
# ═══════════════════════════════════════════════════════

def classify_cash_row(raw_side: str, net_amount: Optional[float], category: str) -> str:
    s = (raw_side or "").strip()
    if category == "repo":
        return "repo"
    if any(k in s for k in ("扣税", "红利税", "股息税", "税款", "补缴")):
        return "tax"
    if any(k in s for k in ("红利", "股息", "派息")):
        return "dividend"
    if any(k in s for k in ("利息", "结息")):
        return "interest"
    if any(k in s for k in ("年费", "管理费", "服务费", "工本费")):
        return "fee"
    if any(k in s for k in ("银行转证券", "银证转入", "转入", "存入")):
        return "deposit"
    if any(k in s for k in ("证券转银行", "银证转出", "转出", "取出")):
        return "withdrawal"
    if any(k in s for k in ("银证转账", "划转", "转账")) and net_amount:
        return "deposit" if net_amount > 0 else "withdrawal"
    return "unclassified"


_EXPECTED_SIGN = {"deposit": 1, "withdrawal": -1, "dividend": 1, "interest": 1, "tax": -1, "fee": -1}


# ═══════════════════════════════════════════════════════
#  事件构造
# ═══════════════════════════════════════════════════════

def _fingerprint(parts: Iterable[Any]) -> str:
    return hashlib.sha256("|".join("" if p is None else str(p) for p in parts).encode("utf-8")).hexdigest()[:24]


def _with_occurrence(rows: list[tuple[str, dict]]) -> list[dict]:
    """同一文件中内容完全相同的行按出现次序编号, 区分真实的重复发生。"""
    seen: Counter = Counter()
    out = []
    for base, ev in rows:
        n = seen[base]
        seen[base] += 1
        ev["event_key"] = f"{base}#{n}"
        out.append(ev)
    return out


def events_from_parse(res, source_file: str, source_hash: str) -> tuple[list[dict], list[str]]:
    """ParseResult → (事件列表, 问题列表)。"""
    issues: list[str] = []
    raw_events: list[tuple[str, dict]] = []
    # 成交以成交台账 key 为准 (与 trade_ledger 去重规则一致, 同 key 只记一次)
    settle_events: dict[str, dict] = {}

    for t in res.trades:
        sign = -1 if t.side == "buy" else 1
        if t.net_amount is not None:
            cash = float(t.net_amount)
            basis = "net_amount"
            if cash and (cash > 0) != (sign > 0):
                issues.append(f"{t.date} {t.ts_code} {t.side}: 发生金额符号与买卖方向不一致, 请核对")
        elif t.fees is not None:
            cash = round(sign * float(t.amount) - float(t.fees), 2)
            basis = "amount_minus_fees"
        else:
            cash = round(sign * float(t.amount), 2)
            basis = "amount_fees_unknown"
        ev = {
            "type": "settlement", "date": t.date, "amount": round(cash, 2),
            "trade_key": t.key, "ts_code": t.ts_code, "side": t.side, "kind": t.kind,
            "fees": t.fees, "fees_unknown": t.fees is None and t.net_amount is None,
            "cash_basis": basis, "cash_estimated": t.net_amount is None,
        }
        settle_events.setdefault("settle:" + _fingerprint(("settlement", t.key)), ev)

    for row in getattr(res, "cash_rows", []):
        net = row.get("net_amount")
        etype = classify_cash_row(row.get("raw_side", ""), net, row.get("category", ""))
        if net is None:
            issues.append(f"第{row.get('line')}行 {row.get('date')} '{row.get('raw_side')}': 缺少发生金额, 未入账")
            continue
        exp = _EXPECTED_SIGN.get(etype)
        if exp and net and (net > 0) != (exp > 0):
            issues.append(f"{row.get('date')} '{row.get('raw_side')}': {etype} 金额符号异常 ({net}), 按原值入账请核对")
        if etype == "unclassified":
            issues.append(f"{row.get('date')} '{row.get('raw_side')}' {net}: 无法归类的资金行, 不计入合计")
        base = _fingerprint(("cash", row.get("date"), row.get("time"), row.get("code"),
                             row.get("raw_side"), net, row.get("qty"), row.get("ref")))
        raw_events.append((base, {
            "type": etype, "date": row.get("date"), "amount": round(float(net), 2),
            "ts_code": row.get("ts_code") or "", "raw_side": row.get("raw_side", ""),
            "time": row.get("time") or None,          # 资金流时点 (TWR 分段用; 缺失 = 未知)
        }))

    events = [dict(ev, event_key=k) for k, ev in settle_events.items()] + _with_occurrence(raw_events)
    for ev in events:
        ev["source_file"] = source_file
        ev["source_sha256"] = source_hash
    return events, issues


# ═══════════════════════════════════════════════════════
#  存储 (只追加)
# ═══════════════════════════════════════════════════════

def load(path: Optional[str] = None) -> dict:
    path = path or ACCOUNT_LEDGER_PATH
    if os.path.exists(path):
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        if isinstance(data, dict) and isinstance(data.get("events"), list):
            return data
        raise ValueError("account_ledger.json 结构无效, 拒绝覆盖")
    return {"version": LEDGER_VERSION, "events": [], "corrections": [], "sources": [], "snapshots": []}


def save(ledger: dict, path: Optional[str] = None) -> None:
    path = path or ACCOUNT_LEDGER_PATH
    os.makedirs(os.path.dirname(path), exist_ok=True)
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(ledger, f, ensure_ascii=False, indent=1)
    os.replace(tmp, path)


def _date_range(res) -> tuple[Optional[str], Optional[str]]:
    dates = [t.date for t in res.trades] + [r["date"] for r in getattr(res, "cash_rows", []) if r.get("date")]
    return (min(dates), max(dates)) if dates else (None, None)


_BASIS_RANK = {"amount_fees_unknown": 1, "amount_minus_fees": 2, "net_amount": 3}
_ENRICH_FIELDS = ("amount", "cash_basis", "cash_estimated", "fees", "fees_unknown")


def _enrich_settlements(ledger: dict, incoming: list[dict], file_name: str, source_hash: str) -> tuple[int, list[str]]:
    """同 key 结算事件: 新来源更完整 → 追加 enrich 更正; 同级金额不一致 → 冲突, 不改动。"""
    eff = {e["event_key"]: e for e in effective_events(ledger)}
    enriched, issues = 0, []
    for ev in incoming:
        cur = eff.get(ev["event_key"])
        if cur is None or ev.get("type") != "settlement" or cur.get("type") != "settlement":
            continue
        r_new, r_cur = _BASIS_RANK.get(ev.get("cash_basis"), 0), _BASIS_RANK.get(cur.get("cash_basis"), 0)
        same = abs(float(ev["amount"]) - float(cur["amount"])) <= RECONCILE_TOLERANCE / 100
        if r_new > r_cur:
            ledger["corrections"].append({
                "event_key": ev["event_key"], "action": "enrich",
                "reason": f"来源 {file_name} 提供更完整的现金信息 ({cur.get('cash_basis')} → {ev.get('cash_basis')})",
                "replacement": {k: ev.get(k) for k in _ENRICH_FIELDS},
                "previous": {k: cur.get(k) for k in _ENRICH_FIELDS},
                "source_file": file_name, "source_sha256": source_hash,
                "at": datetime.now(timezone.utc).isoformat(timespec="seconds")})
            enriched += 1
        elif r_new == r_cur and not same:
            issues.append(f"{ev.get('date')} {ev.get('ts_code')} {ev.get('side')}: 结算金额冲突 "
                          f"(已记 {cur['amount']}, 来源 {file_name} 为 {ev['amount']}), 未改动, 请核对")
    return enriched, issues


_BJ = timezone(timedelta(hours=8))
COVER_ROWS = "rows"                          # 只到文件最后一行
COVER_PREV_DAY = "export_date_prev_day"      # 导出日的前一交易日 (默认)
COVER_AFTER_CLOSE = "export_date_after_close"  # 收盘后导出, 含导出日当天
_NAME_DATE = re.compile(r"^(\d{4})(\d{2})(\d{2})")


def export_date_from_name(file_name: str) -> Optional[str]:
    """文件名开头的导出日 YYYYMMDD (通达信默认命名, 如 20261104交割单查询.txt); 无效返回 None。"""
    m = _NAME_DATE.match(os.path.basename(str(file_name or "")))
    if not m:
        return None
    try:
        return date(int(m.group(1)), int(m.group(2)), int(m.group(3))).isoformat()
    except ValueError:
        return None


def _prev_weekday(d: date) -> date:
    d = d - timedelta(days=1)
    while d.weekday() >= 5:
        d = d - timedelta(days=1)
    return d


def infer_coverage_end(file_name: str, rows_to: Optional[str], after_close: bool = False,
                       now: Optional[datetime] = None) -> tuple[Optional[str], str, list[str]]:
    """含发生金额的导出: 推定入出金覆盖截止日 → (covered_to, basis, notes)。规则见模块说明第 6 条。"""
    notes: list[str] = []
    now_bj = (now or datetime.now(timezone.utc)).astimezone(_BJ)
    today = now_bj.date()
    exp = export_date_from_name(file_name)
    if exp is None:
        notes.append("文件名开头没有导出日期 (YYYYMMDD), 入出金覆盖只算到文件最后一行")
        return rows_to, COVER_ROWS, notes
    exp_d = date.fromisoformat(exp)
    if exp_d > today:
        notes.append(f"文件名日期 {exp} 晚于今天, 不按导出日推定覆盖")
        return rows_to, COVER_ROWS, notes
    if rows_to and exp < rows_to:
        notes.append(f"文件名日期 {exp} 早于文件最后一行 {rows_to}, 不按导出日推定覆盖")
        return rows_to, COVER_ROWS, notes
    if after_close:
        if exp_d < today or now_bj.hour >= 15:
            end, basis = exp_d, COVER_AFTER_CLOSE
        else:
            notes.append("导入时北京时间未到 15:00, 不能确认收盘后导出; 按导出日前一交易日")
            end, basis = _prev_weekday(exp_d), COVER_PREV_DAY
    else:
        end, basis = _prev_weekday(exp_d), COVER_PREV_DAY
    covered = end.isoformat()
    if rows_to and rows_to > covered:        # 文件里已有导出日当天的记录 → 至少到最后一行
        covered, basis = rows_to, COVER_ROWS
    return covered, basis, notes


def _span_end(s: Mapping[str, Any]) -> Optional[str]:
    return s.get("covered_to") or s.get("date_to")


def coverage_segments(ledger: Mapping[str, Any]) -> list[tuple[str, str]]:
    """含发生金额来源的覆盖区间合并 (只隔周末视为连续)。"""
    spans = sorted((s["date_from"], _span_end(s)) for s in ledger.get("sources", [])
                   if s.get("cash_coverage") and s.get("date_from") and _span_end(s))
    out: list[list[str]] = []
    for a, b in spans:
        if out:
            nxt = date.fromisoformat(out[-1][1]) + timedelta(days=1)
            while nxt.weekday() >= 5:
                nxt += timedelta(days=1)
            if date.fromisoformat(a) <= nxt:
                out[-1][1] = max(out[-1][1], b)
                continue
        out.append([a, b])
    return [(a, b) for a, b in out]


def coverage_report(ledger: Mapping[str, Any], since_days: int = 120, now: Optional[datetime] = None) -> dict:
    """导入后提示: 最新覆盖截止日 + 近 since_days 天内的缺口 (超过 60 天的缺口通达信已无法补导)。"""
    segs = coverage_segments(ledger)
    today = (now or datetime.now(timezone.utc)).astimezone(_BJ).date()
    horizon = (today - timedelta(days=since_days)).isoformat()
    gaps = []
    for (a1, b1), (a2, b2) in zip(segs, segs[1:]):
        g_from = (date.fromisoformat(b1) + timedelta(days=1)).isoformat()
        g_to = (date.fromisoformat(a2) - timedelta(days=1)).isoformat()
        if g_to >= horizon:
            gaps.append({"from": g_from, "to": g_to,
                         "recoverable": (today - date.fromisoformat(g_from)).days <= 60})
    return {"covered_to": segs[-1][1] if segs else None, "gaps": gaps}


def record_parse(res, raw: bytes, file_name: str, path: Optional[str] = None, after_close: bool = False,
                 now: Optional[datetime] = None) -> dict:
    """把一次解析结果并入现金台账。重复导入同一内容不改变事件; 同一成交的更完整信息以 enrich 更正补全。
    含发生金额的导出按文件名导出日推定覆盖截止日 (模块说明第 6 条); 重复导入可把截止日只升不降地补上。"""
    source_hash = hashlib.sha256(raw).hexdigest()
    ledger = load(path)
    events, issues = events_from_parse(res, file_name, source_hash)
    existing = {e["event_key"] for e in ledger["events"]}
    added = [e for e in events if e["event_key"] not in existing]
    n_enriched, enrich_issues = _enrich_settlements(
        ledger, [e for e in events if e["event_key"] in existing], file_name, source_hash)
    issues = issues + enrich_issues
    ledger["events"].extend(added)
    ledger["events"].sort(key=lambda e: (e.get("date") or "", e["event_key"]))
    d_from, d_to = _date_range(res)
    has_cash = bool(getattr(res, "has_net_amount", False))
    covered_to, basis, cover_notes = (infer_coverage_end(file_name, d_to, after_close, now) if has_cash
                                      else (d_to, COVER_ROWS, []))
    changed = bool(added or n_enriched)
    now_iso = (now or datetime.now(timezone.utc)).astimezone(timezone.utc).isoformat(timespec="seconds")
    src = next((s for s in ledger["sources"] if s["sha256"] == source_hash), None)
    if src is None:
        changed = True
        ledger["sources"].append({
            "sha256": source_hash, "file": file_name, "date_from": d_from, "date_to": d_to,
            "cash_coverage": has_cash, "covered_to": covered_to, "covered_basis": basis,
            "imported_at": now_iso,
        })
    elif has_cash and covered_to and covered_to > (_span_end(src) or ""):   # 重复导入: 截止日只升不降
        changed = True
        src.update({"covered_to": covered_to, "covered_basis": basis, "coverage_updated_at": now_iso})
    else:
        covered_to, basis = _span_end(src), src.get("covered_basis") or COVER_ROWS
    if changed:                       # 内容未变不重写文件 (重复导入稳定, 也便于发现意外写入)
        save(ledger, path)
    out = {"events_added": len(added), "events_duplicate": len(events) - len(added), "events_enriched": n_enriched,
           "cash_coverage": has_cash, "issues": issues[:50],
           "issue_count": len(issues), "covered_to": covered_to if has_cash else None,
           "covered_basis": basis if has_cash else None, "coverage_notes": cover_notes,
           "coverage": coverage_report(ledger, now=now)}
    logger.info("现金台账: %s 新增 %d 事件, 重复 %d, 问题 %d", file_name, out["events_added"],
                out["events_duplicate"], len(issues))
    return out


def add_correction(event_key: str, action: str, reason: str, replacement: Optional[dict] = None,
                   path: Optional[str] = None) -> dict:
    """追加更正 (void 作废 / replace 以新金额或类型替代 / relabel 只更正来源标签); 原事件保留。"""
    if action not in ("void", "replace", "relabel"):
        raise ValueError("action 必须是 void、replace 或 relabel")
    if not reason:
        raise ValueError("更正必须写明原因")
    ledger = load(path)
    if event_key not in {e["event_key"] for e in ledger["events"]}:
        raise KeyError(f"未找到事件 {event_key}")
    if action == "replace":
        allowed = {"type", "amount", "date"}
        if not replacement or not set(replacement) <= allowed:
            raise ValueError(f"replace 只能修改 {sorted(allowed)}")
    if action == "relabel" and (not replacement or set(replacement) != {"source_file"}):
        raise ValueError("relabel 只能修改 source_file")
    c = {"event_key": event_key, "action": action, "reason": reason, "replacement": replacement,
         "at": datetime.now(timezone.utc).isoformat(timespec="seconds")}
    ledger["corrections"].append(c)
    save(ledger, path)
    return c


def valuation_timing(time_str: Optional[str]) -> str:
    """估值时点: close (≥15:00, 收盘价) / pre_open (<09:15, 实为上一交易日收盘) / intraday / unknown。"""
    t = str(time_str or "").strip().replace(":", "")
    if len(t) < 4 or not t[:4].isdigit():
        return "unknown"
    hhmm = int(t[:4])
    return "close" if hhmm >= 1500 else "pre_open" if hhmm < 915 else "intraday"


def record_balance_snapshot(as_of: str, cash: float, total_asset: Optional[float] = None,
                            source: str = "", path: Optional[str] = None, *,
                            valuation_time: Optional[str] = None, date_basis: str = "unspecified",
                            positions: Optional[Mapping[str, float]] = None,
                            source_sha256: Optional[str] = None) -> dict:
    """记录券商资金快照, 只追加; 同日同值不重复。

    as_of 必须是券商账单的实际日期 (调用方负责, 不得用导入当天替代);
    valuation_time 为账单估值时点 (未知则 None → valuation_timing=unknown);
    recorded_at 为导入时间; positions 为该时点逐只持仓数量 (对账用)。"""
    if not as_of:
        raise ValueError("快照必须提供券商账单实际日期 as_of")
    ledger = load(path)
    snap = {"as_of": as_of, "cash": round(float(cash), 2),
            "total_asset": None if total_asset is None else round(float(total_asset), 2),
            "valuation_time": valuation_time, "valuation_timing": valuation_timing(valuation_time),
            "date_basis": date_basis, "source": source, "source_sha256": source_sha256,
            "positions": dict(positions) if positions is not None else None,
            "recorded_at": datetime.now(timezone.utc).isoformat(timespec="seconds")}
    same = [s for s in ledger["snapshots"] if s["as_of"] == as_of and s["cash"] == snap["cash"]]
    if not same:
        ledger["snapshots"].append(snap)
        ledger["snapshots"].sort(key=lambda s: (s["as_of"], s["recorded_at"]))
        save(ledger, path)
    elif valuation_time and not any(s.get("valuation_time") for s in same):
        # 2026-11-04: 同一份对账单重新导入并填写估值时点 → 只补写时点 (金额不变), 留补写时间
        same[0]["valuation_time"] = valuation_time
        same[0]["valuation_timing"] = valuation_timing(valuation_time)
        same[0]["valuation_time_filled_at"] = snap["recorded_at"]
        save(ledger, path)
    return snap


# ═══════════════════════════════════════════════════════
#  查询与对账
# ═══════════════════════════════════════════════════════

def effective_events(ledger: Mapping[str, Any]) -> list[dict]:
    """应用更正后的事件。enrich 按记录顺序依次补全; 人工 void/replace 以最后一条为准且在补全之后生效。"""
    last: dict[str, dict] = {}
    enrich: dict[str, list] = {}
    relabel: dict[str, dict] = {}
    for c in ledger.get("corrections", []):
        if c["action"] == "enrich":
            enrich.setdefault(c["event_key"], []).append(c)
        elif c["action"] == "relabel":          # 只改来源标签, 不影响 void/replace
            relabel[c["event_key"]] = c
        else:
            last[c["event_key"]] = c
    out = []
    for e in ledger.get("events", []):
        c = last.get(e["event_key"])
        if c and c["action"] == "void":
            continue
        ev = dict(e)
        for en in enrich.get(e["event_key"], []):
            ev.update(en["replacement"])
            ev["enriched"] = True
        if c and c["action"] == "replace":
            ev.update(c["replacement"])
            ev["corrected"] = True
        if e["event_key"] in relabel:
            ev["relabeled_from"] = e.get("source_file")
            ev["source_file"] = relabel[e["event_key"]]["replacement"]["source_file"]
        out.append(ev)
    return out


def summarize(ledger: Mapping[str, Any], date_from: Optional[str] = None, date_to: Optional[str] = None) -> dict:
    """区间 (date_from, date_to] 内各类现金合计。外部资金流与投资损益分开。"""
    totals: dict[str, float] = {}
    n_estimated = 0
    for e in effective_events(ledger):
        d = e.get("date") or ""
        if (date_from and d <= date_from) or (date_to and d > date_to):
            continue
        if e["type"] == "unclassified":
            continue
        totals[e["type"]] = round(totals.get(e["type"], 0.0) + float(e["amount"]), 2)
        n_estimated += bool(e.get("cash_estimated"))
    ext = round(sum(totals.get(t, 0.0) for t in EXTERNAL_FLOW_TYPES), 2)
    income = round(sum(totals.get(t, 0.0) for t in INCOME_TYPES), 2)
    cost = round(sum(totals.get(t, 0.0) for t in COST_TYPES), 2)
    return {"by_type": totals, "net_cash_change": round(sum(totals.values()), 2),
            "external_flows": ext, "income": income, "costs": cost,
            "settlement_estimated_count": n_estimated}


def cash_coverage_ok(ledger: Mapping[str, Any], date_from: str, date_to: str) -> bool:
    """(date_from, date_to] 是否被含发生金额的导出连续覆盖 (按自然日并集判断)。

    来源区间取文件中最早一行的日期 → 覆盖截止日 covered_to (按导出日推定, 见模块说明第 6 条; 旧来源无此字段时
    用最晚一行; 或副本验收时用户声明的导出区间)。只含周末的空档不算缺口
    (周末无交收; 法定节假日不在此豁免, 仍判为覆盖不足, 保守)。"""
    from datetime import date, timedelta

    def skip_weekend(d):
        while d.weekday() >= 5:
            d = d + timedelta(days=1)
        return d

    spans = sorted((s["date_from"], _span_end(s)) for s in ledger.get("sources", [])
                   if s.get("cash_coverage") and s.get("date_from") and _span_end(s))
    need = skip_weekend(date.fromisoformat(date_from) + timedelta(days=1))
    end = date.fromisoformat(date_to)
    if need > end:
        return True
    for a, b in spans:
        a, b = date.fromisoformat(a), date.fromisoformat(b)
        if a > need:
            break
        if b >= need:
            need = skip_weekend(b + timedelta(days=1))
        if need > end:
            return True
    return need > end


def reconcile_cash(ledger: Mapping[str, Any], snap_a: Mapping[str, Any], snap_b: Mapping[str, Any],
                   tolerance: float = RECONCILE_TOLERANCE) -> dict:
    """期初快照现金 + 区间现金事件 = 期末快照现金 ? 差异必须可解释。"""
    a, b = snap_a["as_of"], snap_b["as_of"]
    s = summarize(ledger, a, b)
    expected = round(float(snap_a["cash"]) + s["net_cash_change"], 2)
    diff = round(float(snap_b["cash"]) - expected, 2)
    covered = cash_coverage_ok(ledger, a, b)
    if not covered:
        status = "insufficient_cash_coverage"
        note = "区间内缺少含发生金额的交割单/资金流水, 入出金与分红未知; 差额不能视为盈亏或错误"
    elif abs(diff) <= tolerance:
        status = "reconciled"
        note = "台账推算现金与券商余额一致"
    else:
        status = "unexplained_difference"
        note = "台账已覆盖该区间但仍有差额; 检查未归类资金行、遗漏导出或更正记录"
    unclassified = [e for e in effective_events(ledger)
                    if e["type"] == "unclassified" and a < (e.get("date") or "") <= b]
    return {"from": a, "to": b, "opening_cash": snap_a["cash"], "closing_cash": snap_b["cash"],
            "expected_closing_cash": expected, "difference": diff, "status": status, "note": note,
            "cash_coverage": covered, "summary": s, "unclassified_count": len(unclassified)}


def investment_pnl(start_value: float, end_value: float, ledger: Mapping[str, Any],
                   date_from: str, date_to: str) -> dict:
    """整账户投资损益 = 期末总资产 − 期初总资产 − 净外部资金流 (入金/出金不算盈亏)。"""
    s = summarize(ledger, date_from, date_to)
    return {"start_value": start_value, "end_value": end_value,
            "net_external_flows": s["external_flows"],
            "investment_pnl": round(end_value - start_value - s["external_flows"], 2),
            "cash_coverage": cash_coverage_ok(ledger, date_from, date_to)}
