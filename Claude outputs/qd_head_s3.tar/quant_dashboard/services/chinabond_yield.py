"""
AlphaCore · 中债国债收益率统一数据层 V1.0
==========================================
数据源: AKShare bond_china_yield (底层为中国债券信息网 CCDC)
替代:   Tushare yc_cb (需付费权限 yc_cb)

降级策略:
  Tier 0: AKShare 中债 (免费, 权威, 日频完整历史)
  Tier 1: Tushare yc_cb (如权限恢复自动启用)
  Tier 2: 磁盘缓存 (data_lake/chinabond_yield_10y.parquet)

2026-10-24 修复 (docs/ERP_VALIDATION_STEP1_2.md §2.1):
  - 旧缓存每 ~176 天只有 4 个交易日 (数据源单次行数上限截断); 现按批检查两端覆盖,
    未覆盖段继续请求; Tushare yc_cb 直接带 curve_term=10
  - 缓存出现 >20 天断档 → 自动全量重拉; 支持 start_date 向前补拉 / force_rebuild

消费者:
  - engines/erp_timing_engine.py  → get_yield_10y_history()
  - engines/erp_hk_engine.py      → get_yield_10y_latest()
  - strategies/erp_backtest_data.py → get_yield_10y_history()
"""

import os
import time
import logging
import threading
from datetime import datetime, timedelta
from typing import Optional, Tuple

import pandas as pd

logger = logging.getLogger("ac.chinabond")

# ── 配置 ──
_CACHE_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), "data_lake")
_CACHE_FILE = os.path.join(_CACHE_DIR, "chinabond_yield_10y.parquet")
_LEGACY_CACHE_FILE = os.path.join(_CACHE_DIR, "erp_yield_10y.parquet")

# 中债 10Y (AKShare) 最早可得日 (2026-10-24 实测: 更早区间返回空)。
# 更早的请求一律裁剪到此日, 避免每次缓存过期都空请求 2005 年并误报数据缺口。
EARLIEST_AVAILABLE = "20060301"

# 内存缓存 (线程安全)
_mem_lock = threading.Lock()
_mem_cache: Optional[pd.DataFrame] = None
_mem_ts: float = 0
_MEM_TTL = 1800  # 30 分钟内存 TTL


def _atomic_write_parquet(df: pd.DataFrame, path: str):
    """原子写入 parquet (先写 tmp 再 rename, 防止半写损坏)"""
    tmp = path + ".tmp"
    df.to_parquet(tmp, index=False)
    if os.path.exists(path):
        os.replace(tmp, path)
    else:
        os.rename(tmp, path)


def _fetch_from_akshare(start_date: str, end_date: str) -> Optional[pd.DataFrame]:
    """Tier 0: 从 AKShare 获取中债国债收益率 (底层为中国债券信息网)

    Args:
        start_date: 开始日期 YYYYMMDD
        end_date: 结束日期 YYYYMMDD

    Returns:
        DataFrame with columns ['trade_date', 'yield_10y'] or None on failure
    """
    try:
        import akshare as ak
        df = ak.bond_china_yield(start_date=start_date, end_date=end_date)
        if df is None or df.empty:
            logger.warning("AKShare bond_china_yield 返回空数据")
            return None

        # 列: 曲线名称, 日期, 3月, 6月, 1年, 3年, 5年, 7年, 10年, 30年
        col_name = df.columns[0]   # 曲线名称
        col_date = df.columns[1]   # 日期
        col_10y = '10年'

        if col_10y not in df.columns:
            # 列名可能因版本不同而变化, 尝试位置索引 (第9列)
            col_10y = df.columns[8] if len(df.columns) > 8 else None
            if col_10y is None:
                logger.warning("AKShare 返回数据缺少 10 年期列")
                return None

        # 筛选国债曲线
        gov_mask = df[col_name].astype(str).str.contains('国债')
        gov = df[gov_mask].copy()
        if gov.empty:
            logger.warning("AKShare 数据中未找到国债曲线")
            return None

        # 标准化输出格式 (与 Tushare yc_cb 兼容)
        result = pd.DataFrame({
            'trade_date': pd.to_datetime(gov[col_date]),
            'yield_10y': pd.to_numeric(gov[col_10y], errors='coerce'),
        })
        result = result.dropna(subset=['yield_10y'])

        # 数据质量校验 (10Y 国债正常范围 0.5-8.0%)
        valid_mask = result['yield_10y'].between(0.5, 8.0)
        if not valid_mask.all():
            dropped = (~valid_mask).sum()
            logger.warning("AKShare 数据质量过滤: 丢弃 %d 条异常值", dropped)
            result = result[valid_mask]

        result = result.sort_values('trade_date').reset_index(drop=True)
        logger.info(
            "ChinaBond (AKShare): %d rows, latest=%.4f%% (%s)",
            len(result),
            result.iloc[-1]['yield_10y'] if len(result) > 0 else 0,
            result.iloc[-1]['trade_date'].strftime('%Y-%m-%d') if len(result) > 0 else 'N/A',
        )
        return result
    except ImportError:
        logger.warning("akshare 未安装, 跳过中债通道")
        return None
    except Exception as e:
        logger.warning("AKShare bond_china_yield 异常: %s", e)
        return None


def _fetch_from_tushare(start_date: str, end_date: str) -> Optional[pd.DataFrame]:
    """Tier 1: Tushare yc_cb (如权限恢复自动可用)

    2026-10-24 修复: yc_cb 不带 curve_term 时一次返回整条曲线的全部期限,
    触发单次返回行数上限, 每批只剩开头约 4 个交易日 (见 docs/ERP_VALIDATION_STEP1_2.md §2.1)。
    现在请求端直接限定 curve_term=10; 若接口不认该参数则回退旧调用,
    截断问题由上层 _fetch_range_complete 的覆盖率检查 + 二分拆批兜底。
    """
    try:
        from config import TUSHARE_TOKEN
        import tushare as ts
        ts.set_token(TUSHARE_TOKEN)
        pro = ts.pro_api()

        try:
            df = pro.yc_cb(ts_code='1001.CB', curve_type='0', curve_term=10,
                           start_date=start_date, end_date=end_date)
        except Exception as e:
            if "没有接口" in str(e) or "访问权限" in str(e):
                raise
            logger.debug("yc_cb 不支持 curve_term 参数, 回退整条曲线请求: %s", e)
            df = pro.yc_cb(ts_code='1001.CB', curve_type='0',
                           start_date=start_date, end_date=end_date)
        if df is None or df.empty:
            return None

        df_10y = df[df['curve_term'] == 10.0].copy()
        if df_10y.empty:
            return None

        result = pd.DataFrame({
            'trade_date': pd.to_datetime(df_10y['trade_date'], format='%Y%m%d'),
            'yield_10y': df_10y['yield'].values,
        })
        result = result.sort_values('trade_date').reset_index(drop=True)
        logger.info("Tushare yc_cb: %d rows", len(result))
        return result
    except Exception as e:
        msg = str(e)
        if "没有接口" in msg or "访问权限" in msg:
            logger.debug("Tushare yc_cb 权限不足, 跳过")
        else:
            logger.warning("Tushare yc_cb 异常: %s", e)
        return None


def _read_disk_cache() -> Optional[pd.DataFrame]:
    """Tier 2: 磁盘缓存 (新缓存优先, 旧格式兼容)"""
    for path in [_CACHE_FILE, _LEGACY_CACHE_FILE]:
        if os.path.exists(path):
            try:
                df = pd.read_parquet(path)
                df['trade_date'] = pd.to_datetime(df['trade_date'])
                df = df.sort_values('trade_date').reset_index(drop=True)
                age_hours = (time.time() - os.path.getmtime(path)) / 3600
                logger.info("磁盘缓存命中 (%s): %d rows, %.1f h old",
                            os.path.basename(path), len(df), age_hours)
                return df
            except Exception as e:
                logger.warning("磁盘缓存读取失败 (%s): %s", path, e)
    return None


# ── 防截断拉取 (2026-10-24) ──
# 数据源有单次行数上限时, 一批请求只会返回区间开头 (或结尾) 的几天。
# 对策: 每批返回后检查两端是否覆盖到区间边界, 未覆盖的剩余段继续请求, 直到补齐或数据源不再返回。
_CHUNK_DAYS = 90               # 初始批长度 (原 300 天)
_EDGE_TOLERANCE_DAYS = 4       # 剩余段工作日 ≤ 4 天且无返回时不告警 (节假日)
_MAX_REQUESTS = 2000           # 安全上限
_SLEEP_SEC = 0.5               # 礼貌间隔


_REQUEST_TIMEOUT_SEC = 45      # 单次请求超时 (AKShare 底层 requests 无超时, 会无限挂起)


def _with_timeout(fn, *args, timeout: float = None):
    """在守护线程执行 fn, 超时返回 None。

    用守护线程而非 ThreadPoolExecutor: 后者在解释器退出时会等待挂起的线程, 脚本结束时会卡住。
    """
    box = {}

    def _run():
        try:
            box["v"] = fn(*args)
        except Exception as e:  # 与原函数一致: 异常视为无数据
            logger.warning("10Y 请求异常: %s", e)
            box["v"] = None

    t = threading.Thread(target=_run, daemon=True, name="cb10y-fetch")
    t.start()
    t.join(timeout or _REQUEST_TIMEOUT_SEC)
    if t.is_alive():
        logger.warning("10Y 请求超时 (%ss): %s %s", timeout or _REQUEST_TIMEOUT_SEC,
                       getattr(fn, "__name__", fn), args)
        return None
    return box.get("v")


def _fetch_chunk(s_str: str, e_str: str) -> Optional[pd.DataFrame]:
    """单批拉取: Tier 0 AKShare → Tier 1 Tushare; 两者都可用时取行数多者。"""
    a = _with_timeout(_fetch_from_akshare, s_str, e_str)
    t = None
    expected = len(pd.bdate_range(pd.Timestamp(s_str), pd.Timestamp(e_str)))
    if a is None or a.empty or len(a) < 0.7 * expected:
        t = _with_timeout(_fetch_from_tushare, s_str, e_str)
    candidates = [d for d in (a, t) if d is not None and not d.empty]
    if not candidates:
        return None
    return max(candidates, key=len)


def _fetch_range_complete(start_dt: datetime, end_dt: datetime,
                          chunk_days: int = _CHUNK_DAYS,
                          sleep_sec: float = _SLEEP_SEC,
                          progress=None) -> list:
    """拉取 [start_dt, end_dt] 并处理数据源截断: 未覆盖的头/尾剩余段继续请求。"""
    pending = []
    cur = pd.Timestamp(start_dt).normalize()
    end_ts = pd.Timestamp(end_dt).normalize()
    while cur <= end_ts:
        nxt = min(cur + pd.Timedelta(days=chunk_days - 1), end_ts)
        pending.append((cur, nxt))
        cur = nxt + pd.Timedelta(days=1)
    pending.reverse()

    out, n_req = [], 0
    while pending and n_req < _MAX_REQUESTS:
        s, e = pending.pop()
        n_req += 1
        chunk = _fetch_chunk(s.strftime('%Y%m%d'), e.strftime('%Y%m%d'))
        if sleep_sec:
            time.sleep(sleep_sec)
        if progress is not None:
            n = 0 if chunk is None else len(chunk)
            total = sum(len(c) for c in out) + n
            progress(f"  第{n_req}次请求 {s.date()}~{e.date()} → {n} 天  (累计约 {total} 天)")
        if chunk is None or chunk.empty:
            if len(pd.bdate_range(s, e)) > _EDGE_TOLERANCE_DAYS:
                logger.warning("10Y %s~%s 数据源无返回", s.date(), e.date())
            continue
        chunk = chunk.copy()
        chunk['trade_date'] = pd.to_datetime(chunk['trade_date'])
        chunk = chunk[(chunk['trade_date'] >= s) & (chunk['trade_date'] <= e)]
        if chunk.empty:
            continue
        out.append(chunk)
        first, last = chunk['trade_date'].min(), chunk['trade_date'].max()
        # 尾部/头部还有工作日未覆盖 → 继续请求剩余段 (节假日段会返回空, 自然终止)
        tail_s, head_e = last + pd.Timedelta(days=1), first - pd.Timedelta(days=1)
        if tail_s <= e and len(pd.bdate_range(tail_s, e)) > 0:
            pending.append((tail_s, e))
        if s <= head_e and len(pd.bdate_range(s, head_e)) > 0:
            pending.append((s, head_e))
    if pending:
        logger.warning("10Y 拉取达到请求上限 %d, 剩余 %d 段未拉", _MAX_REQUESTS, len(pending))
    return out


def coverage_stats(df: Optional[pd.DataFrame], calendar: Optional[pd.Series] = None) -> dict:
    """收益率序列相对交易日历 (或工作日) 的覆盖率与最大缺口。"""
    if df is None or df.empty:
        return {"rows": 0, "coverage": 0.0, "max_gap_days": None, "start": None, "end": None}
    d = pd.to_datetime(df['trade_date']).sort_values().drop_duplicates()
    start, end = d.iloc[0], d.iloc[-1]
    if calendar is not None:
        cal = pd.to_datetime(pd.Series(calendar)).drop_duplicates()
        cal = cal[(cal >= start) & (cal <= end)]
        expected = max(1, len(cal))
        hit = int(cal.isin(set(d)).sum())
    else:
        expected = max(1, len(pd.bdate_range(start, end)))
        hit = len(d)
    gaps = d.diff().dt.days.dropna()
    return {
        "rows": int(len(d)),
        "coverage": round(min(1.0, hit / expected), 4),
        "max_gap_days": int(gaps.max()) if len(gaps) else 0,
        "start": start.strftime('%Y-%m-%d'),
        "end": end.strftime('%Y-%m-%d'),
    }


def _cache_is_sparse(df: Optional[pd.DataFrame]) -> bool:
    """缓存是否存在 > 20 天的断档 (历史截断问题的特征)。"""
    if df is None or df.empty:
        return False
    return coverage_stats(df)["max_gap_days"] > 20


def get_yield_10y_history(years: int = 5, start_date: Optional[str] = None,
                          force_rebuild: bool = False, progress=None) -> pd.DataFrame:
    """获取 10Y 国债收益率历史序列 (日频, 带增量更新和三级降级)

    Args:
        years: 历史年数 (未给 start_date 时使用, 默认 5 年)
        start_date: 需要覆盖的最早日期 YYYYMMDD (回测用, 如 '20050101');
                    缓存起点晚于它时自动向前补拉
        force_rebuild: True = 忽略缓存, 从起点全量重拉 (用于修复历史截断缓存)

    Returns:
        DataFrame with columns ['trade_date', 'yield_10y'], sorted by date

    Raises:
        ValueError: 所有数据源均失败且无磁盘缓存
    """
    global _mem_cache, _mem_ts

    end_dt = datetime.now()
    want_start = (datetime.strptime(start_date, '%Y%m%d') if start_date
                  else end_dt - timedelta(days=years * 365))
    want_start = max(want_start, datetime.strptime(EARLIEST_AVAILABLE, '%Y%m%d'))

    # 内存缓存命中 (须覆盖到所需起点)
    if not force_rebuild:
        with _mem_lock:
            if (_mem_cache is not None and (time.time() - _mem_ts) < _MEM_TTL
                    and _mem_cache['trade_date'].min() <= pd.Timestamp(want_start) + pd.Timedelta(days=10)):
                return _mem_cache.copy()

    disk_cache = _read_disk_cache()          # 仅作最终兜底 (即使有断档也比没有强)
    existing = None if force_rebuild else disk_cache
    if existing is not None and _cache_is_sparse(existing):
        logger.warning("10Y 磁盘缓存存在断档 (%s), 全量重拉",
                       coverage_stats(existing))
        existing = None

    # 需要拉取的区间: [want_start, 缓存起点) 的前补段 + (缓存终点, 今天] 的增量段
    ranges = []
    if existing is None or existing.empty:
        ranges.append((want_start, end_dt))
    else:
        first, last = existing['trade_date'].min(), existing['trade_date'].max()
        if first > pd.Timestamp(want_start) + pd.Timedelta(days=10):
            ranges.append((want_start, (first - pd.Timedelta(days=1)).to_pydatetime()))
        if last.strftime('%Y%m%d') < end_dt.strftime('%Y%m%d'):
            ranges.append(((last - pd.Timedelta(days=3)).to_pydatetime(), end_dt))
        if not ranges:
            with _mem_lock:
                _mem_cache = existing
                _mem_ts = time.time()
            return existing.copy()

    all_new = []
    for s, e in ranges:
        all_new.extend(_fetch_range_complete(s, e, progress=progress))

    # 合并增量数据
    if all_new:
        new_df = pd.concat(all_new, ignore_index=True)
        new_df['trade_date'] = pd.to_datetime(new_df['trade_date'])

        if existing is not None and not existing.empty:
            combined = pd.concat([existing, new_df], ignore_index=True)
            combined = combined.drop_duplicates(subset='trade_date', keep='last')
        else:
            combined = new_df

        combined = combined.sort_values('trade_date').reset_index(drop=True)

        # 持久化 (新格式 + 旧格式兼容写入)
        try:
            os.makedirs(_CACHE_DIR, exist_ok=True)
            _atomic_write_parquet(combined, _CACHE_FILE)
            # 同步更新旧格式缓存, 让未改造的代码路径也能受益
            _atomic_write_parquet(combined, _LEGACY_CACHE_FILE)
            logger.info("中债 10Y 缓存已更新: %d rows (latest=%s)",
                        len(combined), combined.iloc[-1]['trade_date'].strftime('%Y-%m-%d'))
        except Exception as e:
            logger.warning("缓存持久化失败 (非致命): %s", e)

        with _mem_lock:
            _mem_cache = combined
            _mem_ts = time.time()
        return combined.copy()

    # Tier 2: 磁盘缓存兜底 (调用方须用 coverage_stats / 数据质量守卫自行判断能否使用)
    if disk_cache is not None and not disk_cache.empty:
        logger.warning("中债在线数据源均失败, 降级到磁盘缓存 (%s)", coverage_stats(disk_cache))
        with _mem_lock:
            _mem_cache = disk_cache
            _mem_ts = time.time()
        return disk_cache.copy()

    raise ValueError("国债收益率数据: 所有数据源均失败且无磁盘缓存")


def get_yield_10y_latest() -> Tuple[float, str]:
    """获取最新 10Y 国债收益率单点值 (供 erp_hk_engine 使用)

    Returns:
        (yield_value, date_str) e.g. (1.7324, '2026-06-16')

    Raises:
        ValueError: 无法获取数据
    """
    # 快速通道: 只拉最近 30 天
    end_str = datetime.now().strftime('%Y%m%d')
    start_str = (datetime.now() - timedelta(days=30)).strftime('%Y%m%d')

    # Tier 0: AKShare
    df = _fetch_from_akshare(start_str, end_str)
    if df is not None and not df.empty:
        latest = df.iloc[-1]
        return float(latest['yield_10y']), latest['trade_date'].strftime('%Y-%m-%d')

    # Tier 1: Tushare
    df = _fetch_from_tushare(start_str, end_str)
    if df is not None and not df.empty:
        latest = df.iloc[-1]
        return float(latest['yield_10y']), latest['trade_date'].strftime('%Y-%m-%d')

    # Tier 2: 磁盘缓存最新值
    cached = _read_disk_cache()
    if cached is not None and not cached.empty:
        latest = cached.iloc[-1]
        return float(latest['yield_10y']), latest['trade_date'].strftime('%Y-%m-%d')

    raise ValueError("CN10Y: 所有数据源均失败")
