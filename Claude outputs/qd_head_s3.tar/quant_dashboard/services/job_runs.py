"""定时任务运行记录与失败告警 (2026-11-04, docs/ETF_CONSTITUENT_FIX_PLAN.md C3)。

背景: 各定时任务的回调内部吞掉异常只写日志, 调度器一律视为成功; 容器随部署重建, docker logs 丢失,
周六成分刷新连续三周未写入无人察觉。

本模块:
  · tracked(job_id, fn): 包装任务, 记录开始 / 结束 / 结果 / 错误摘要到 data_lake/job_runs.json (持久化, 部署不丢)。
    判为失败: ① 抛出异常; ② 运行期间本线程写出 ERROR 级日志 (回调吞掉的异常); ③ 返回 dict 且
    status ∈ {error, failed, degraded} 或 errors 非空。
  · 关键任务 (CRITICAL_JOBS) 失败当天即推送 (同一任务每天 1 次); 其他任务连续失败 ≥ 3 次推送 (每天 1 次)。
  · overdue(): 按调度规则推算"最近一次应运行时间", 之后未成功即为逾期 (审计页 A 区、看门狗使用)。
只记录与告警, 不改变任何任务的行为或判定。
2026-11-04: 任务开关 (services.job_switches, config/job_switches.json) — 被暂停的任务到点不运行、不记失败;
  非关键任务暂停不算逾期; 关键任务暂停仍按逾期计 (审计页警告、看门狗推送), 不当作正常状态。
"""
from __future__ import annotations

import json
import logging
import os
import threading
import time
from datetime import datetime, timedelta
from typing import Any, Callable, Mapping, Optional

logger = logging.getLogger("alphacore.job_runs")

_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
JOB_RUNS_PATH = os.path.join(_ROOT, "data_lake", "job_runs.json")

# 用户 2026-11-04 指定: 失败当天即推送
CRITICAL_JOBS = frozenset({"trailing_stop_daily", "daily_warmup", "constituent_refresh_check",
                           "aiae_fund_position_update", "audit_daily_snapshot"})
JOB_LABELS = {
    "trailing_stop_daily": "跟踪止盈日终 15:50", "daily_warmup": "收盘预热 15:35",
    "constituent_refresh_check": "ETF 成分检查 08:40", "aiae_fund_position_update": "AIAE 基金仓位 16:00",
    "audit_daily_snapshot": "审计历史 16:45", "industry_universe_refresh": "行业ETF周度校验 周六 08:30",
    "morning_warmup": "早间预热 08:30", "daily_report": "日报 16:35", "fred_daily": "FRED 18:30",
    "us_aiae": "美国 AIAE 06:30", "jp_aiae": "日本 AIAE 15:30", "aaii_crawl": "AAII 周五 09:00",
    "swing_guard": "波段守卫 15:40", "industry_forward_monitor": "行业前向证据 15:45",
    "nlp_scan_am": "NLP 情报 09:35", "nlp_scan_pm": "NLP 情报 15:15",
    "aiae_monthly_history": "AIAE 月末历史 每月1日", "strategy_ci_monthly": "策略 CI 每月1日",
    "alert_scan": "告警扫描 每10分钟", "event_monitor": "事件监控 每5分钟", "adaptive_poller": "盘中轮询 每30秒",
    "job_watchdog": "任务看门狗 每30分钟",
}
NONCRITICAL_PUSH_AFTER = 3          # 非关键任务连续失败次数
HISTORY_PER_JOB = 20
INTERVAL_PERSIST_SEC = 600          # 高频任务: 状态不变时最多 10 分钟落盘一次
OVERDUE_GRACE = timedelta(minutes=45)
_FAIL_STATUSES = {"error", "failed", "degraded"}

_lock = threading.Lock()
_state: Optional[dict] = None
_last_persist: dict[str, float] = {}
_triggers: dict[str, Any] = {}      # job_id → APScheduler trigger (进程内, 供逾期推算)


def _load(path: str = None) -> dict:
    global _state
    if _state is None or path:
        try:
            with open(path or JOB_RUNS_PATH, "r", encoding="utf-8") as f:
                data = json.load(f)
            _state = data if isinstance(data, dict) and isinstance(data.get("jobs"), dict) else {"jobs": {}}
        except Exception:
            _state = {"jobs": {}}
    return _state


def _persist(path: str = None) -> None:
    target = path or JOB_RUNS_PATH
    os.makedirs(os.path.dirname(target), exist_ok=True)
    tmp = f"{target}.{os.getpid()}.tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(_state, f, ensure_ascii=False, indent=1)
    os.replace(tmp, target)


class _ThreadErrorCapture(logging.Handler):
    """只收集当前线程的 ERROR 级日志 (回调吞掉异常后写的那一行)。"""

    def __init__(self, thread_id: int):
        super().__init__(level=logging.ERROR)
        self.thread_id = thread_id
        self.messages: list[str] = []

    def emit(self, record: logging.LogRecord) -> None:
        if record.thread == self.thread_id and record.name != logger.name:
            try:
                self.messages.append(record.getMessage()[:200])
            except Exception:
                self.messages.append(str(record.msg)[:200])


def outcome_from_result(result: Any) -> tuple[bool, str]:
    """返回值 → (是否失败, 说明)。"""
    if isinstance(result, Mapping):
        st = str(result.get("status") or "").lower()
        if st in _FAIL_STATUSES:
            return True, f"status={st} {str(result.get('error') or result.get('reason') or '')[:150]}".strip()
        errs = result.get("errors")
        if errs:
            return True, f"部分失败: {str(errs)[:150]}"
    return False, ""


def record(job_id: str, ok: bool, started: datetime, finished: datetime, error: str = "", note: str = "",
           path: str = None) -> dict:
    """写入一次运行结果; 返回该任务的最新汇总。"""
    with _lock:
        st = _load(path)
        job = st["jobs"].setdefault(job_id, {"history": [], "consecutive_failures": 0})
        prev_ok = job.get("last_status") == "ok" if job.get("last_status") else None
        entry = {"started": started.isoformat(timespec="seconds"), "finished": finished.isoformat(timespec="seconds"),
                 "sec": round((finished - started).total_seconds(), 1), "status": "ok" if ok else "failed"}
        if error:
            entry["error"] = error[:300]
        if note:
            entry["note"] = note[:200]
        job["history"] = (job.get("history") or [])[-(HISTORY_PER_JOB - 1):] + [entry]
        job["last_run"] = entry["finished"]
        job["last_status"] = entry["status"]
        if ok:
            job["last_success"] = entry["finished"]
            job["consecutive_failures"] = 0
        else:
            job["last_failure"] = entry["finished"]
            job["last_error"] = entry.get("error", "")
            job["consecutive_failures"] = int(job.get("consecutive_failures") or 0) + 1
        st["updated_at"] = entry["finished"]
        now = time.time()
        changed = prev_ok is None or prev_ok != ok
        if path or not ok or changed or now - _last_persist.get(job_id, 0) >= INTERVAL_PERSIST_SEC:
            try:
                _persist(path)
                _last_persist[job_id] = now
            except Exception as e:  # 记录失败不影响任务本身
                logger.warning("job_runs 写入失败: %s", e)
        return dict(job)


def _should_push(job_id: str, job: Mapping[str, Any], today: str) -> bool:
    if job.get("last_status") != "failed" or job.get("pushed_on") == today:
        return False
    if job_id in CRITICAL_JOBS:
        return True
    return int(job.get("consecutive_failures") or 0) >= NONCRITICAL_PUSH_AFTER


def _mark_pushed(job_id: str, today: str, path: str = None) -> None:
    with _lock:
        st = _load(path)
        st["jobs"].setdefault(job_id, {})["pushed_on"] = today
        try:
            _persist(path)
        except Exception:
            pass


def push_failure(job_id: str, title: str, detail: str) -> None:
    """写告警表 + 多渠道推送 (复用 alert_monitor 通道)。失败只记日志。"""
    try:
        from services import db as ac_db
        ac_db.save_alert(rule_id=f"job_{job_id}", severity="critical" if job_id in CRITICAL_JOBS else "warning",
                         title=title, detail=detail, value=0)
    except Exception as e:
        logger.warning("任务告警写入失败: %s", e)
    try:
        from services.alert_monitor import _push_all_channels
        threading.Thread(target=_push_all_channels,
                         args=([{"icon": "⚠️", "title": title, "detail": detail}],), daemon=True).start()
    except Exception as e:
        logger.warning("任务告警推送失败: %s", e)


def _job_paused(job_id: str) -> Optional[dict]:
    try:
        from services.job_switches import job_paused
        return job_paused(job_id)
    except Exception as e:  # noqa: BLE001 — 开关读取失败按开启处理
        logger.warning("任务开关读取失败 [%s], 按开启处理: %s", job_id, e)
        return None


def tracked(job_id: str, fn: Callable, trigger: Any = None, pusher: Callable = None) -> Callable:
    """包装定时任务: 记录结果, 失败按规则告警。原函数的返回值与异常行为不变。
    任务被开关暂停时不调用原函数、不记录运行 (返回 None)。"""
    if trigger is not None:
        _triggers[job_id] = trigger
    pusher = pusher if pusher is not None else push_failure

    def _run(*args, **kwargs):
        paused = _job_paused(job_id)
        if paused is not None:
            (logger.warning if job_id in CRITICAL_JOBS else logger.info)(
                "定时任务已暂停, 跳过 [%s]%s: %s", job_id, " (关键任务)" if job_id in CRITICAL_JOBS else "",
                paused.get("reason") or "")
            return None
        started = datetime.now()
        cap = _ThreadErrorCapture(threading.get_ident())
        # "ac" / "alphacore" 命名空间不向 root 传播 (services/logger.py), 三处都要挂
        targets = [logging.getLogger(), logging.getLogger("ac"), logging.getLogger("alphacore")]
        for lg in targets:
            lg.addHandler(cap)
        result, exc = None, None
        try:
            result = fn(*args, **kwargs)
        except Exception as e:  # noqa: BLE001
            exc = e
        finally:
            for lg in targets:
                lg.removeHandler(cap)
        failed_by_result, note = outcome_from_result(result)
        if exc is not None:
            ok, err = False, f"{type(exc).__name__}: {exc}"
        elif cap.messages:
            ok, err = False, "；".join(cap.messages[:3])
        elif failed_by_result:
            ok, err = False, note
        else:
            ok, err = True, ""
        try:
            job = record(job_id, ok, started, datetime.now(), error=err)
            today = started.strftime("%Y-%m-%d")
            if _should_push(job_id, job, today):
                label = JOB_LABELS.get(job_id, job_id)
                pusher(job_id, f"定时任务失败: {label}",
                       f"{started:%m-%d %H:%M} 运行失败 (连续 {job.get('consecutive_failures')} 次): {err[:200]}")
                _mark_pushed(job_id, today)
        except Exception as e:  # noqa: BLE001
            logger.warning("job_runs 记录 / 告警异常 [%s]: %s", job_id, e)
        if exc is not None:
            raise exc
        return result

    _run.__name__ = getattr(fn, "__name__", job_id)
    _run.__wrapped__ = fn
    return _run


def wrap_scheduler(scheduler) -> list[str]:
    """把调度器里全部任务包上 tracked (启动前调用)。返回已包装的任务 id。"""
    done = []
    for job in scheduler.get_jobs():
        if getattr(job.func, "__wrapped__", None) is not None:
            continue
        job.modify(func=tracked(job.id, job.func, trigger=job.trigger))
        done.append(job.id)
    return done


def previous_fire(trigger: Any, now: datetime, lookback: timedelta = timedelta(days=35)) -> Optional[datetime]:
    """调度规则下 ≤ now 的最近一次应运行时间 (APScheduler trigger)。"""
    cur = now if now.tzinfo else now.astimezone()          # 无时区 = 本机系统时区
    t, prev, n = cur - lookback, None, 0
    while n < 5000:
        nxt = trigger.get_next_fire_time(prev, t)
        if nxt is None or nxt > cur:
            return prev
        prev, t, n = nxt, nxt + timedelta(seconds=1), n + 1
    return prev


def _parse(ts: Optional[str]) -> Optional[datetime]:
    try:
        return datetime.fromisoformat(ts) if ts else None
    except ValueError:
        return None


def status_rows(now: Optional[datetime] = None, path: str = None) -> list[dict]:
    """每个任务: 最近运行 / 最近成功 / 连续失败 / 是否逾期。逾期 = 最近一次应运行时间 + 45 分钟后仍未成功。"""
    now = now or datetime.now()
    st = _load(path) if path else _load()
    jobs = dict(st.get("jobs") or {})
    rows = []
    for job_id in sorted(set(jobs) | set(_triggers), key=lambda j: (j not in CRITICAL_JOBS, j)):
        j = jobs.get(job_id) or {}
        last_ok = _parse(j.get("last_success"))
        trig = _triggers.get(job_id)
        due = None
        if trig is not None:
            try:
                due = previous_fire(trig, now)
                due = due.astimezone().replace(tzinfo=None) if due is not None else None   # 与记录同为本机时间
            except Exception:
                due = None
        tracked_since = _parse(st.get("tracking_started"))
        overdue = bool(due and now - due > OVERDUE_GRACE and (last_ok is None or last_ok < due)
                       and (tracked_since is None or due > tracked_since))
        paused = _job_paused(job_id)
        if paused is not None and job_id not in CRITICAL_JOBS:
            overdue = False                      # 非关键任务暂停: 不算逾期; 关键任务暂停仍按逾期 (警告 + 推送)
        rows.append({"job_id": job_id, "label": JOB_LABELS.get(job_id, job_id), "critical": job_id in CRITICAL_JOBS,
                     "paused": paused is not None, "pause_reason": (paused or {}).get("reason") or None,
                     "last_run": j.get("last_run"), "last_status": j.get("last_status"),
                     "last_success": j.get("last_success"), "consecutive_failures": int(j.get("consecutive_failures") or 0),
                     "last_error": j.get("last_error") if j.get("last_status") == "failed" else None,
                     "expected_at": due.isoformat(timespec="minutes") if due else None, "overdue": overdue})
    return rows


def mark_tracking_started(now: Optional[datetime] = None, path: str = None) -> None:
    """首次启用运行记录时记下时间 (逾期只从开始追踪之后的应运行时间算起, 避免把启用前的空档误报)。"""
    with _lock:
        st = _load(path)
        if st.get("tracking_started"):        # 只记第一次: 之后服务停机期间错过的运行也要算逾期
            return
        st["tracking_started"] = (now or datetime.now()).isoformat(timespec="seconds")
        try:
            _persist(path)
        except Exception as e:
            logger.warning("job_runs 写入失败: %s", e)


def watchdog(now: Optional[datetime] = None, pusher: Callable = None) -> dict:
    """看门狗 (每 30 分钟): 关键任务逾期未成功 → 推送 (同一任务每天 1 次)。"""
    now = now or datetime.now()
    pusher = pusher if pusher is not None else push_failure
    today = now.strftime("%Y-%m-%d")
    late = [r for r in status_rows(now) if r["critical"] and r["overdue"]]
    pushed = []
    for r in late:
        job = (_load().get("jobs") or {}).get(r["job_id"]) or {}
        if job.get("overdue_pushed_on") == today:
            continue
        pusher(r["job_id"], f"定时任务未运行: {r['label']}",
               (f"关键任务被开关暂停 (config/job_switches.json: {r['pause_reason'] or '未写原因'}); " if r.get("paused") else "")
               + f"应在 {r['expected_at']} 运行, 至今未成功 (最近成功 {r['last_success'] or '无记录'})")
        with _lock:
            _load()["jobs"].setdefault(r["job_id"], {})["overdue_pushed_on"] = today
            try:
                _persist()
            except Exception:
                pass
        pushed.append(r["job_id"])
    return {"overdue": [r["job_id"] for r in late], "pushed": pushed}
