"""Snapshot-bound manual decisions in an independent ledger. No portfolio writes."""
from __future__ import annotations

import json
import sqlite3
import uuid
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path

from services.decision_policy import (ROOT, POLICY_VERSION, decorate_signal, fingerprint,
                                      number, parse_day, get_mode, EXIT_SIGNALS)
from services.market_clock import cn_now

DB_PATH = ROOT / "data_lake" / "analysis_decisions.db"


class DecisionError(ValueError):
    def __init__(self, message, status_code=409):
        super().__init__(message)
        self.status_code = status_code


@contextmanager
def connection():
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(DB_PATH, timeout=10)
    conn.row_factory = sqlite3.Row
    try:
        conn.execute("PRAGMA busy_timeout=10000")
        conn.execute("""CREATE TABLE IF NOT EXISTS analysis_decisions (
            id TEXT PRIMARY KEY, request_id TEXT UNIQUE NOT NULL, request_hash TEXT NOT NULL,
            status TEXT NOT NULL, created_at TEXT NOT NULL, payload TEXT NOT NULL)""")
        conn.execute("""CREATE TABLE IF NOT EXISTS analysis_observations (
            snapshot_id TEXT PRIMARY KEY, created_at TEXT NOT NULL, payload TEXT NOT NULL)""")
        conn.commit()
        yield conn
    finally:
        conn.close()


def load_context(code):
    from services.cache_service import cache_manager
    from services.strategy_params import load_runtime_config, get_mr_lifecycle

    wrapped = cache_manager.get_json("strategy_results", {}).get("mr", {})
    signals = wrapped.get("data", {}).get("signals", []) if isinstance(wrapped, dict) else wrapped
    candidates = [s for s in signals or [] if s.get("ts_code", s.get("code")) == code]
    if len(candidates) != 1 or not candidates[0].get("research_signal"):
        raise DecisionError("参考信号缺失或版本过旧，请先重新运行均值回归分析", 409)
    signal = candidates[0]
    try:
        portfolio = json.loads((ROOT / "data_lake" / "portfolio_store.json").read_text(encoding="utf-8"))
        if not isinstance(portfolio, dict) or not isinstance(portfolio.get("positions"), dict):
            raise ValueError("invalid portfolio")
    except (OSError, ValueError):
        raise DecisionError("持仓快照不可用，请先导入实际持仓", 409)
    market = {"valid": True, "marks": {}}
    try:
        import pandas as pd
        for price_code in dict.fromkeys((code, "000300.SH")):
            path = ROOT / "data_lake" / "daily_prices" / f"{price_code}.parquet"
            before = path.stat()
            frame = pd.read_parquet(path, columns=["trade_date", "close"]).sort_values("trade_date")
            latest = frame.iloc[-1]
            after = path.stat()
            if before.st_mtime_ns != after.st_mtime_ns or before.st_size != after.st_size:
                raise ValueError("price file changed during read")
            mark = {"date": str(latest["trade_date"]), "close": number(latest["close"]),
                    "signature": [after.st_mtime_ns, after.st_size]}
            market["marks"][price_code] = mark
            if mark["close"] is None or mark["close"] <= 0:
                market["valid"] = False
            if price_code == code:
                market["valid"] &= (mark["signature"] == signal.get("source_data_signature")
                                    and parse_day(mark["date"]) == parse_day(signal.get("data_as_of")))
            elif parse_day(mark["date"]) != parse_day(signal.get("market_data_as_of")):
                market["valid"] = False
    except (OSError, ValueError, KeyError, IndexError):
        market["valid"] = False
    return {"signal": signal, "portfolio": portfolio, "runtime": load_runtime_config(), "market": market,
            "lifecycle": get_mr_lifecycle(signal.get("regime", "RANGE"))}


def analysis_signals():
    from services.cache_service import cache_manager
    from services.strategy_params import load_runtime_config, get_mr_lifecycle
    wrapped = cache_manager.get_json("strategy_results", {}).get("mr", {})
    signals = wrapped.get("data", {}).get("signals", []) if isinstance(wrapped, dict) else wrapped
    runtime = load_runtime_config()
    result = []
    for signal in signals or []:
        if signal.get("research_signal"):
            result.append(decorate_signal(signal, runtime=runtime,
                                          lifecycle=get_mr_lifecycle(signal.get("regime", "RANGE"))))
    errors = wrapped.get("data", {}).get("errors", []) if isinstance(wrapped, dict) else []
    for error in errors:
        result.append({"ts_code": error.get("ts_code", error.get("code")), "name": error.get("name"),
                       "research_signal": "error", "signal": "error",
                       "data_status": {"status": "unavailable", "as_of": None,
                                       "detail": "当前行情或指标计算失败，请重新运行分析；历史验证结论未改变"},
                       "evidence": {"status": "unknown", "label": "当前不可评估", "detail": "当前输入异常，原验证记录可在参数面板核对"},
                       "risk_checks": {"status": "blocked", "reasons": ["DATA_UNAVAILABLE"]},
                       "permissions": {"mode": get_mode(), "observe": False, "manual_plan": False, "auto_execute": False}})
    return {"mode": get_mode(), "auto_execute": False, "signals": result,
            "message": "仅人工分析与计划；实际成交请在券商完成后导入" if result else "请先运行均值回归分析以生成参考信号"}


def _model_hash():
    return fingerprint({p: (ROOT / p).read_text(encoding="utf-8") for p in (
        "engines/mean_reversion_engine.py", "services/decision_policy.py", "services/manual_decisions.py")})


def preview_plan(code, amount):
    if isinstance(amount, bool) or not isinstance(amount, int) or amount <= 0 or amount > 100000000:
        raise DecisionError("计划数量必须为有效正整数", 422)
    ctx = load_context(code)
    signal = decorate_signal(ctx["signal"], runtime=ctx["runtime"], lifecycle=ctx["lifecycle"])
    side = "sell" if signal.get("research_signal") in EXIT_SIGNALS else "buy"
    portfolio = ctx["portfolio"]
    # 2026-11-02 项 2: MR 风险类限额 (总仓位 / 单票 / 行业 / MR 敞口) 并入合规, 由买入门控按成交后组合判定;
    # 信号动态单笔上限只显示, 超出时醒目提示 (不拦截)。本函数只保留策略 / 可行性检查。
    dynamic_cap = number(signal.get("dynamic_pos_cap"))
    limits = {"dynamic_pos_cap": dynamic_cap}
    blockers = list(signal["risk_checks"]["reasons"])
    if ctx.get("market", {}).get("valid") is False:
        blockers.append("MARKET_SNAPSHOT_CHANGED")
    price = number(signal.get("close"))
    cash = number(portfolio.get("cash"))
    if cash is not None:
        # 2026-11-02 仓位口径统一: 现金与全站同一取值 (有「可用」用「可用」, 否则「余额」; 冻结不计)
        from services.account_exposure import snapshot_cash
        cash = snapshot_cash(portfolio)[0]
    positions = portfolio.get("positions")
    as_of = parse_day(portfolio.get("import_date"))
    if (cash is None or (cash < 0 and side == "buy") or not isinstance(positions, dict) or as_of is None
            or not 0 <= (cn_now().date() - as_of).days < signal["data_status"]["max_calendar_lag_days"]):
        blockers.append("PORTFOLIO_UNAVAILABLE_OR_STALE")
    mv = current_value = held_amount = 0.0
    for held_code, position in (positions if isinstance(positions, dict) else {}).items():
        if not isinstance(position, dict):
            blockers.append("HOLDING_MARK_UNAVAILABLE")
            continue
        quantity = number(position.get("amount"))
        mark = number(position.get("broker_price"))
        position_day = parse_day(position.get("import_date", portfolio.get("import_date")))
        if (quantity is None or quantity < 0 or mark is None or mark <= 0 or position_day is None
                or not 0 <= (cn_now().date() - position_day).days < signal["data_status"]["max_calendar_lag_days"]):
            blockers.append("HOLDING_MARK_UNAVAILABLE")
            continue
        value = quantity * (price if held_code == code and price is not None else mark)
        mv += value
        if held_code == code:
            current_value = value
            held_amount = quantity
    total = (cash or 0) + mv
    notional = (price or 0) * amount
    change = notional if side == "buy" else -notional
    if total <= 0:
        blockers.append("ACCOUNT_VALUE_UNAVAILABLE")
    denominator = total if total > 0 else 1
    projected = {"total_pct": (mv + change) / denominator * 100,
                 "single_pct": (current_value + change) / denominator * 100}
    if side == "sell" and amount > held_amount:
        blockers.append("INSUFFICIENT_HOLDINGS")
    if side == "buy" and notional > (cash or 0):
        blockers.append("INSUFFICIENT_CASH")
    notices = []
    if side == "buy" and dynamic_cap is not None and projected["single_pct"] > dynamic_cap:
        notices.append({"code": "DYNAMIC_POS_CAP_EXCEEDED", "level": "warning",
                        "detail": (f"计划后单标的 {projected['single_pct']:.1f}% 超出信号动态单笔上限 {dynamic_cap:.1f}%"
                                   f"（只提示，不拦截；风险判定以合规为准）")})
    # Rejected and unknown evidence remain observation-only. No soft acknowledgement bypass.
    if not signal["permissions"]["manual_plan"]:
        blockers.append("OBSERVATION_ONLY")
    # 2026-11-02: 买入计划必须先过合规门控 (合规引擎是唯一风险判定; 硬阻断/不可用 → 拒绝)。卖出计划不经门控。
    if side == "buy":
        from services.compliance_gate import buy_gate
        compliance = buy_gate({"ts_code": code, "name": signal.get("name", code), "notional": notional})
        if not compliance["allowed"]:
            blockers.append(compliance["reason_code"])
    else:
        compliance = {"allowed": True, "reason_code": None, "status": "not_applicable", "blocks": [], "warnings": [],
                      "summary": "卖出/减仓不受合规买入门控限制"}
    blockers = sorted(set(blockers))
    projection_unavailable = bool(set(blockers) & {
        "DATA_UNAVAILABLE", "MARKET_SNAPSHOT_CHANGED", "PORTFOLIO_UNAVAILABLE_OR_STALE",
        "HOLDING_MARK_UNAVAILABLE", "ACCOUNT_VALUE_UNAVAILABLE", "INSUFFICIENT_HOLDINGS", "INSUFFICIENT_CASH",
    })
    proof = {"policy": POLICY_VERSION, "mode": get_mode(), "model": _model_hash(), "market": ctx.get("market"),
             "runtime": ctx["runtime"], "lifecycle": ctx["lifecycle"], "portfolio": portfolio,
             "signal": {k: signal.get(k) for k in ("ts_code", "research_signal", "signal_score", "close", "data_as_of", "regime", "regime_params", "pos_cap", "source_config_hash", "source_model_hash")},
             "evidence": signal["evidence"], "data_status": signal["data_status"],
             "amount": amount, "limits": limits, "blockers": blockers, "day": cn_now().date().isoformat(),
             "compliance": {"status": compliance["status"], "rules": [b["rule_id"] for b in compliance["blocks"]]}}
    return {"snapshot_id": fingerprint(proof), "snapshot": proof, "code": code, "name": signal.get("name", code),
            "amount": amount, "reference_price": price, "reference_as_of": signal["data_status"]["as_of"],
            "notional": round(notional, 2), "held_amount": held_amount,
            "portfolio_as_of": portfolio.get("import_date"), "projected": None if projection_unavailable else projected,
            "limits": limits, "notices": notices, "blockers": blockers, "can_confirm": not blockers,
            "compliance": compliance,
            "evidence": signal["evidence"], "config_revision": ctx["runtime"]["revision"],
            "status": "preview", "side": side, "auto_execute": False,
            "note": "按导入持仓与日线参考价核查，未包含实际券商成交费用；MR敞口按关联标的保守计入，不代表实时可成交数量"}


def _existing(conn, payload):
    row = conn.execute("SELECT request_hash,payload FROM analysis_decisions WHERE request_id=?",
                       (payload["request_id"],)).fetchone()
    if row:
        if row["request_hash"] != fingerprint(payload):
            raise DecisionError("重复请求标识对应不同内容，请重新预览")
        return json.loads(row["payload"])
    return None


def confirm_plan(payload):
    if payload.get("acknowledged") is not True:
        raise DecisionError("请先阅读并明确确认当前计划与证据状态", 422)
    with connection() as conn:
        conn.execute("BEGIN IMMEDIATE")
        try:
            existing = _existing(conn, payload)
            if existing:
                conn.rollback()
                return existing
            preview = preview_plan(payload["code"], payload["amount"])
            if preview["snapshot_id"] != payload["snapshot_id"]:
                raise DecisionError("信号、参数、证据或持仓快照已变化，请重新预览")
            if not preview["can_confirm"]:
                gate = preview.get("compliance") or {}
                if gate.get("allowed") is False:
                    raise DecisionError(f"计划被合规门控拒绝：{gate.get('summary')}")
                raise DecisionError("计划未通过当前证据或风险检查，仅可观察")
            record = {**preview, "id": str(uuid.uuid4()), "status": "planned",
                      "acknowledged": True,
                      "created_at": datetime.now(timezone.utc).isoformat(), "request_id": payload["request_id"]}
            conn.execute("INSERT INTO analysis_decisions VALUES (?,?,?,?,?,?)",
                         (record["id"], payload["request_id"], fingerprint(payload), record["status"],
                          record["created_at"], json.dumps(record, ensure_ascii=False, allow_nan=False)))
            conn.commit()
            return record
        except Exception:
            conn.rollback()
            raise


def record_observation(code, request_id, action, reason=""):
    if action not in {"watch", "declined", "self_directed"}:
        raise DecisionError("无效的观察操作", 422)
    if action == "self_directed" and not reason.strip():
        raise DecisionError("个人自主决定须记录理由", 422)
    payload = {"code": code, "request_id": request_id, "action": action, "reason": reason}
    with connection() as conn:
        conn.execute("BEGIN IMMEDIATE")
        try:
            existing = _existing(conn, payload)
            if existing:
                conn.rollback()
                return existing
            ctx = load_context(code)
            signal = decorate_signal(ctx["signal"], runtime=ctx["runtime"], lifecycle=ctx["lifecycle"])
            record = {**payload, "id": str(uuid.uuid4()), "status": action,
                      "created_at": datetime.now(timezone.utc).isoformat(), "signal": signal,
                      "auto_execute": False, "note": "观察或个人决定记录，不代表订单或成交"}
            conn.execute("INSERT INTO analysis_decisions VALUES (?,?,?,?,?,?)",
                         (record["id"], request_id, fingerprint(payload), action, record["created_at"],
                          json.dumps(record, ensure_ascii=False, allow_nan=False)))
            conn.commit()
            return record
        except Exception:
            conn.rollback()
            raise


def list_records(limit=50):
    if not DB_PATH.exists():
        return []
    with connection() as conn:
        rows = conn.execute("SELECT payload FROM analysis_decisions ORDER BY created_at DESC LIMIT ?", (limit,)).fetchall()
        return [json.loads(row[0]) for row in rows]


def record_signal_observations(signals):
    """Collect all research signals, including rejected/hold signals, without selection bias."""
    with connection() as conn:
        for signal in signals:
            if not signal.get("research_signal") or signal.get("signal") == "error":
                continue
            stable = {k: v for k, v in signal.items() if k not in ("signal_as_of", "permissions")}
            conn.execute("INSERT OR IGNORE INTO analysis_observations VALUES (?,?,?)",
                         (fingerprint(stable), datetime.now(timezone.utc).isoformat(),
                          json.dumps(stable, ensure_ascii=False, allow_nan=False)))
        conn.commit()
