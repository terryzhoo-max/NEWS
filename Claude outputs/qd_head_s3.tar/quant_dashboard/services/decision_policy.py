"""Read-only research, evidence and execution policy for personal analysis."""
from __future__ import annotations

import hashlib
import json
import math
import sqlite3
from contextlib import closing
from datetime import date, datetime
from pathlib import Path

from services.market_clock import cn_now

ROOT = Path(__file__).resolve().parents[1]
POLICY_PATH = ROOT / "config" / "decision_policy.json"
POLICY_VERSION = "personal-analysis-v1"
EXIT_SIGNALS = {"sell", "sell_half", "sell_weak", "stop_loss"}
EVIDENCE_LABELS = {"validated": "验证通过", "insufficient_evidence": "证据不足",
                   "rejected": "验证被拒", "stale": "验证到期", "unknown": "证据待补", "mismatch": "证据不适用"}


def fingerprint(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False,
                                     separators=(",", ":"), allow_nan=False).encode()).hexdigest()


def model_fingerprint(*, engine_hash=None, asset_params=None):
    engine_hash = engine_hash or hashlib.sha256((ROOT / "engines/mean_reversion_engine.py").read_bytes()).hexdigest()
    if asset_params is None:
        try:
            asset_params = json.loads((ROOT / "mr_asset_class_params.json").read_text(encoding="utf-8"))
        except (OSError, ValueError):
            asset_params = {"unavailable": True}
    return fingerprint({"engine": engine_hash, "asset_parameters": asset_params})


def get_mode():
    # Missing/invalid configuration must not reactivate portfolio mutations.
    try:
        policy = json.loads(POLICY_PATH.read_text(encoding="utf-8"))
        if policy.get("schema_version") == 1 and policy.get("mode") == "legacy":
            return "legacy"
    except (OSError, ValueError, AttributeError):
        pass
    return "personal_analysis"


def number(value):
    if isinstance(value, bool):
        return None
    try:
        value = float(value)
        return value if math.isfinite(value) else None
    except (TypeError, ValueError):
        return None


def parse_day(value):
    text = str(value or "")
    try:
        return datetime.strptime(text[:8], "%Y%m%d").date() if text[:8].isdigit() else date.fromisoformat(text[:10])
    except ValueError:
        return None


def validation_run(run_id):
    """Lookup the exact run read-only; never invent metrics from a different run."""
    if not run_id:
        return None
    from services.db.connection import DB_PATH
    path = Path(DB_PATH)
    if not path.exists():
        return None
    try:
        with closing(sqlite3.connect(path.resolve().as_uri() + "?mode=ro", uri=True)) as conn:
            conn.row_factory = sqlite3.Row
            row = conn.execute("SELECT strategy,regime,status,old_params,new_params,old_metrics,new_metrics,quality_gate FROM ci_runs WHERE run_id=?", (run_id,)).fetchone()
            if row is None or row["strategy"] != "mr":
                return None
            use_new = row["status"] == "ACCEPT"
            return {"regime": row["regime"], "params": json.loads(row["new_params" if use_new else "old_params"] or "{}"),
                    "metrics": json.loads(row["new_metrics" if use_new else "old_metrics"] or "{}"),
                    "checks": json.loads(row["quality_gate"] or "[]")}
    except (sqlite3.Error, ValueError):
        return None


def evidence_view(lifecycle, run=None):
    from services.mr_validation import MIN_REGIME_DAYS, MIN_TRADES
    status = lifecycle.get("configured_status", lifecycle.get("status", "unknown"))
    if status not in EVIDENCE_LABELS:
        status = "unknown"
    metrics = run.get("metrics") if isinstance(run, dict) else None
    if not isinstance(metrics, dict):
        metrics = None
    gaps = []
    if metrics:
        for key, threshold, label in (("regime_days", MIN_REGIME_DAYS, "状态交易日"), ("trades", MIN_TRADES, "交易次数")):
            value = number(metrics.get(key))
            if value is not None and value < threshold:
                gaps.append(f"{label} {value:g}/{threshold}")
    detail = "原验证明细待补，不能推测样本缺口" if not metrics else (
        "当前样本门槛对照：" + "；".join(gaps) if gaps else "原验证记录已关联；人工确认不改变验证结论")
    return {"status": status, "label": EVIDENCE_LABELS[status],
            "freshness": "stale" if lifecycle.get("status") == "stale" else "within_review_period",
            "data_through": lifecycle.get("data_through"), "validated_at": lifecycle.get("validated_at"),
            "next_validate_after": lifecycle.get("next_validate_after"),
            "run_id": lifecycle.get("validation_run_id"), "metrics": metrics,
            "detail": detail, "sample_gaps": gaps,
            "minimum_samples": {"regime_days": MIN_REGIME_DAYS, "trades": MIN_TRADES}}


def data_view(signal, *, today=None):
    from config import AUDIT_CONFIG
    today = today or cn_now().date()
    day = parse_day(signal.get("data_as_of"))
    price = number(signal.get("close"))
    max_lag = int(AUDIT_CONFIG.get("stale_data_block_days", 5))
    valid = (day is not None and 0 <= (today - day).days < max_lag
             and price is not None and price > 0
             and signal.get("research_signal") not in (None, "error"))
    return {"status": "available" if valid else "unavailable", "as_of": day.isoformat() if day else None,
            "reference_price": price, "max_calendar_lag_days": max_lag,
            "detail": "日线参考价，非券商实时成交价" if valid else "当前输入缺失、异常或已超过数据时效，需重新运行分析"}


def decorate_signal(signal, *, runtime=None, lifecycle=None):
    """Enrich a copy; legacy signal and effective entry gate remain unchanged."""
    from services.strategy_params import load_runtime_config, get_mr_lifecycle
    runtime = runtime if runtime is not None else load_runtime_config()
    regime = signal.get("regime", "RANGE")
    lifecycle = lifecycle if lifecycle is not None else get_mr_lifecycle(regime)
    run = validation_run(lifecycle.get("validation_run_id"))
    if run and run.get("regime") != regime:
        run = None
    data = data_view(signal)
    evidence = evidence_view(lifecycle, run=run)
    if run and isinstance(run.get("params"), dict):
        state = "RANGE" if regime == "CRASH" else regime
        live = {**runtime["strategies"]["mr"]["regimes"][state]["params"],
                "stop_loss": runtime["strategies"]["mr"]["stop_losses"][regime]}
        verified = run["params"]
        drift = [key for key in live if number(live[key]) is None or number(verified.get(key)) is None
                 or abs(float(live[key]) - float(verified[key])) > 1e-9]
        evidence["binding"] = "mismatch" if drift else "matched"
        evidence["parameter_diffs"] = drift
        if drift:
            evidence["original_status"] = evidence["status"]
            if evidence["status"] != "rejected":
                evidence.update(status="mismatch", label=EVIDENCE_LABELS["mismatch"])
            evidence["detail"] += "；当前参数未被原验证覆盖：" + "、".join(drift)
    else:
        evidence["binding"] = "unknown"
    binding = signal.get("source_config_hash")
    if binding != fingerprint(runtime) or signal.get("source_model_hash") != model_fingerprint():
        data = {**data, "status": "unavailable", "detail": "信号计算参数与当前配置不一致或缺少版本快照，请重新运行分析"}
    if signal.get("regime_data_status") == "unavailable":
        data = {**data, "status": "unavailable", "detail": "市场状态来自降级回退，不能形成当前交易计划"}
    cap = number(runtime["strategies"]["mr"]["position_caps"].get(regime))
    reasons = []
    if data["status"] != "available":
        reasons.append("DATA_UNAVAILABLE")
    action = signal.get("research_signal", "error")
    if action == "buy" and (regime == "CRASH" or cap is None or cap <= 0):
        reasons.append("ENTRY_CAP_ZERO")
    allowed = not reasons and (action in EXIT_SIGNALS or (
        action == "buy" and evidence["status"] in {"validated", "insufficient_evidence", "stale", "mismatch"}))
    return {**signal, "data_status": data, "evidence": evidence,
            "risk_checks": {"status": "blocked" if reasons else "pending_order_review",
                            "reasons": reasons, "regime_cap_pct": cap,
                            "detail": "账户仓位、余额和集中度将在计划预览时按持仓快照检查"},
            "permissions": {"mode": get_mode(), "observe": data["status"] == "available",
                            "manual_plan": allowed, "auto_execute": False,
                            "requires_confirmation": True,
                            "detail": "验证被拒，买入仅供观察；有效退出提示仍可复核" if evidence["status"] == "rejected" else "仅人工决策，确认不代表成交"},
            "config_revision": runtime["revision"], "policy_version": POLICY_VERSION}
