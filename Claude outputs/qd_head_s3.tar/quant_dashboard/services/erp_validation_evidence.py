"""Audit the current engine replay without treating post-selection history as OOS."""
import hashlib
import json
import math
from datetime import date
from pathlib import Path

REPLAY_SOURCE = "data_lake/erp_validation_step3.json"
CURRENT_STRATEGY = "A6_简化后当前实盘(事后选择_不作证据)"
CURRENT_PERIOD = "P2_2024_至今_参与选参"


def current_parameter_hash():
    from engines import erp_params

    erp_params.reload_runtime_params()
    snapshot = {k: getattr(erp_params, k) for k in dir(erp_params) if k.isupper()
                and isinstance(getattr(erp_params, k), (int, float, str, bool, dict, list))}
    return hashlib.sha256(json.dumps(snapshot, sort_keys=True, default=str,
                                     ensure_ascii=False).encode()).hexdigest()[:16]


def _finite(value):
    return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value)


def audit_replay(root, fresh, stale, weight):
    evidence = {
        "source": REPLAY_SOURCE, "live_source": "engines/erp_params.py + strategy_runtime.json",
        "limitations": ["当前简化策略由历史比较后选择；回放属于事后评估，不能作为独立样本外验证"],
        "independent_verification": "直接调用实盘引擎评分方法；未独立核对第二数据源，尚无冻结参数后的独立前瞻验证",
    }
    base = {
        "name": "ERP择时", "evidence_kind": "live_engine_replay",
        "meta": f"证据: {REPLAY_SOURCE} · 绑定: 实盘引擎完整参数哈希 · 权重: {weight:.0%}",
        "explanation": "审计当前实盘回放的参数绑定、截止日期和验证边界。事后选择的简化策略最多判为警告，旧二元优化器不能替代实盘回放。",
        "threshold": f"🟡 参数一致、数据滞后≤{stale}天但缺独立前瞻验证 | 🔴 参数漂移/证据缺失或损坏/数据过期",
    }

    def result(status, score, category, detail):
        return {**base, "status": status, "score": score, "detail": detail, "evidence": evidence,
                "action": "执行 python -m strategies.erp_validation_step3 更新实盘回放；保持参数冻结并积累独立前瞻验证",
                "diagnosis": {"category": category, "summary": detail,
                              "confidence": "配置和现有产物可核对；回放不等于独立前瞻验证",
                              "next_condition": "参数哈希一致、覆盖近期数据，并完成冻结参数后的独立验证"}}

    try:
        data = json.loads((Path(root) / REPLAY_SOURCE).read_text(encoding="utf-8"))
        if not isinstance(data, dict) or not isinstance(data.get("meta"), dict):
            raise ValueError("invalid replay schema")
        meta = data["meta"]
        bounds = meta.get("replay_range")
        if not isinstance(bounds, list) or len(bounds) != 2:
            raise ValueError("missing replay dates")
        start, through = (date.fromisoformat(v) for v in bounds)
        if start > through or through > date.today():
            raise ValueError("invalid replay dates")
        live_hash = current_parameter_hash()
        evidence.update({"generated_at": meta.get("generated_at"), "parameter_hash": live_hash,
                         "evidence_hash": meta.get("param_hash"), "data_through": through.isoformat(),
                         "data_lag_days": (date.today() - through).days,
                         "execution": meta.get("execution"), "replay_range": bounds,
                         "strategy": CURRENT_STRATEGY, "period": CURRENT_PERIOD})
        if meta.get("param_hash") != live_hash:
            return result("fail", 30, "evidence_mismatch", "实盘完整参数哈希与回放证据不一致，须重新回放当前配置")
        perf = data["periods"][CURRENT_PERIOD][CURRENT_STRATEGY]
        excess = perf["vs_同仓位固定"]["excess"]
        ci = excess["ci90"]
        if (not all(_finite(perf.get(k)) for k in ("days", "rebalances", "cagr", "mdd"))
                or perf["days"] < 2 or perf["rebalances"] <= 0
                or not _finite(excess.get("ann_mean")) or not isinstance(ci, list) or len(ci) != 2
                or not all(_finite(v) for v in ci) or ci[0] > ci[1]):
            raise ValueError("incomplete replay metrics")
        evidence["historical_performance"] = perf
    except (OSError, ValueError, TypeError, KeyError, AttributeError):
        return result("fail", 20, "evidence_invalid", "实盘回放证据缺失、损坏或缺少当前策略的日期/质量指标")

    lag = evidence["data_lag_days"]
    if lag > stale:
        return result("fail", max(20, int(60 - (lag - stale) * 0.5)), "evidence_stale",
                      f"当前参数绑定一致，但实盘回放数据滞后 {lag} 天，超过 {stale} 天上限")
    return result("warn", 70, "evidence_quality",
                  f"当前参数哈希一致 · 回放截止 {through} ({lag}天前) · 当前简化策略属事后选择，缺独立前瞻验证"
                  + (f" · 已超过 {fresh} 天新鲜期" if lag > fresh else ""))
