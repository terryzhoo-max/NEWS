"""买入 / 加仓统一合规门控 (2026-11-02)。

规则 (已定, 不得推翻): 合规引擎是唯一风险判定权威。
  - 只拦买入 / 加仓; 卖出 / 减仓不调用本门控, 不受硬阻断限制。
  - 在决策中枢同一份账户快照上, 以 direction="increase" 运行合规引擎
    (按买入方向判定只会比页面结论更严: 回撤刹车、越线禁止加仓、AIAE R4 过热在降仓方向下放行, 在买入方向下阻断)。
  - 有硬阻断 → 拒绝; 合规不可用 (异常 / unknown / 无结论) → 默认拒绝; 仅警告 → 放行并附警告。

调用方: 手动 MR 计划 (services.manual_decisions)、组合优化 (engines.optimizer_engine)、
调仓指令 (engines.rebalance_engine)。
2026-11-04: 非权威环境 (ACCOUNT_AUTHORITY≠server) 第一步即拒绝, reason_code=NON_AUTHORITATIVE。
"""
from __future__ import annotations

from datetime import datetime, timezone
from typing import Optional

from services.logger import get_logger

logger = get_logger("ac.compliance_gate")

HARD_BLOCK = "COMPLIANCE_HARD_BLOCK"
UNAVAILABLE = "COMPLIANCE_UNAVAILABLE"
HOLDINGS_STALE = "HOLDINGS_STALE"


def _rows(items) -> list[dict]:
    rows = []
    for item in items or []:
        if isinstance(item, dict):
            rows.append({"rule_id": item.get("rule_id"), "rule_name": item.get("rule_name"),
                         "detail": item.get("detail")})
    return rows


def _result(allowed, reason_code, status, blocks, warnings, summary, position=None, staleness=None,
            post_trade=None) -> dict:
    return {"allowed": allowed, "reason_code": reason_code, "status": status,
            "direction": "increase", "blocks": blocks, "warnings": warnings, "summary": summary,
            "position": position, "staleness": staleness, "post_trade": post_trade,
            "evaluated_at": datetime.now(timezone.utc).isoformat(timespec="seconds")}


def _position_inputs():
    """2026-11-02 仓位口径统一: 门控用仓位 (两口径相差 > 0.5% 取较高值) + 持仓快照过时检查。"""
    from services import account_exposure as ax
    try:
        exp = ax.current_exposure()
    except Exception as exc:  # pragma: no cover - 防御
        exp = {"status": "unavailable", "pct": None, "reason": str(exc)[:120]}
    pct, note = ax.gate_pct(exp)
    try:
        st = ax.staleness()
    except Exception as exc:  # pragma: no cover - 防御
        st = {"status": "stale", "reason": f"持仓快照检查失败，默认按过时处理：{str(exc)[:80]}", "trades_after": []}
    position = {"pct": exp.get("pct"), "gate_pct": pct, "note": note, "label": exp.get("label"),
                "broker_check": exp.get("broker_check")}
    return position, st


def buy_gate(order: Optional[dict] = None) -> dict:
    """买入 / 加仓前的合规门控。返回 {allowed, reason_code, status, blocks, warnings, summary, ...}。

    order={ts_code, name, notional} (2026-11-02 项 2): 把这笔买入加到当前持仓 (统一口径, 同一分母),
    对成交后组合运行合规 —— 单票、主题穿透、仓位超限都按成交后判定。不传订单 → 按当前组合。"""
    # 2026-11-04: 非权威环境 (本机, ACCOUNT_AUTHORITY≠server) 一律拒绝, 在合规之前、不论合规结论;
    # 两处环境不会同时给出"可以买"。
    from services import account_authority
    if not account_authority.is_authoritative():
        return _result(False, account_authority.NON_AUTHORITATIVE, "non_authoritative", [], [],
                       account_authority.GATE_MESSAGE)
    # 2026-11-02: 启动预热期合规结论未就绪 → 默认拒绝; 部分数据缺失 (预热失败/超时) 时照常现算,
    # 对应合规规则按"数据缺失即硬阻断"处理, 门控随之拒绝
    try:
        from services import warmup_state
        if warmup_state.status()["phase"] == "warming":
            return _result(False, UNAVAILABLE, "warming_up", [], [], "服务启动预热中，合规结论未就绪，默认禁止买入/加仓")
    except Exception:
        pass
    position, st = _position_inputs()
    try:
        from dashboard_modules.decision_engine import compliance_for_direction
        kw = {}
        if position.get("note"):
            kw["current_override"] = position["gate_pct"]
        if order:
            kw["order"] = order
        comp = compliance_for_direction("increase", **kw)
    except Exception as exc:
        logger.warning("合规引擎不可用, 买入门控默认拒绝: %s", exc, exc_info=True)
        return _result(False, UNAVAILABLE, "unknown", [], [],
                       f"合规引擎不可用，默认禁止买入/加仓：{str(exc)[:120]}", position, st)
    if not isinstance(comp, dict):
        return _result(False, UNAVAILABLE, "unknown", [], [], "合规引擎未返回结论，默认禁止买入/加仓", position, st)
    status = comp.get("status")
    blocks, warnings = _rows(comp.get("blocks")), _rows(comp.get("warnings"))
    pt = comp.get("post_trade")
    # 持仓快照: 过时 → 拒绝 (与合规结论并列给出); 盘中提示 → 作为警告附上
    stale_row = {"rule_id": "holdings_snapshot", "rule_name": "持仓快照", "detail": st.get("reason")}
    if st.get("status") == "warn":
        warnings = warnings + [stale_row]
    if position.get("note"):
        warnings = warnings + [{"rule_id": "position_basis", "rule_name": "仓位口径", "detail": position["note"]}]
    if status == "blocked" or blocks:
        names = "；".join(str(b["rule_name"]) for b in blocks) or "未列明"
        extra = f"；{st['reason']}" if st.get("status") == "stale" else ""
        return _result(False, HARD_BLOCK, "blocked", blocks, warnings,
                       f"合规硬阻断 {len(blocks)} 条（{names}），禁止买入/加仓；卖出/减仓不受限{extra}", position, st, pt)
    if status in ("passed", "warning"):
        if st.get("status") == "stale":
            return _result(False, HOLDINGS_STALE, "stale", [stale_row], warnings,
                           f"{st.get('reason')}；导入后再核查买入", position, st, pt)
        return _result(True, None, status, [], warnings,
                       "合规通过" if status == "passed" and not warnings else f"合规警告 {len(warnings)} 条（不阻断）",
                       position, st, pt)
    return _result(False, UNAVAILABLE, status or "unknown", [], warnings,
                   (comp.get("summary") or "合规引擎未返回结论") + "，默认禁止买入/加仓", position, st, pt)
