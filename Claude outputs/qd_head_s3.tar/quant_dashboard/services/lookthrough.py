"""
AlphaCore · 组合穿透 (方案 B 阶段3A, 2026-10-29)
===============================================

把实际持仓拆成"公司 / 行业"暴露:
  · 直接持股按市值计入该公司;
  · ETF 按跟踪指数官方成分权重 × ETF 市值分摊到成分公司 (指数权重近似, 非基金实际持仓);
  · 同一家公司来自多只 ETF 与直接持股时合并 (按 ts_code 归并)。

未知部分绝不当作零风险:
  · ETF 无已核验成分 (过期/缺失/不在研究池且未登记) → 整只 ETF 市值计入 unknown;
  · 成分权重合计不足 100% → 余量全部计入 unknown (验收修补 2026-10-29: 不再忽略 0.5% 以内的小额残余);
  · 权重合计超过 100%: ≤ 100.5% 视为四舍五入/报告口径误差, 按比例缩放到 100% 并标注;
    > 100.5% 视为数据错误, 整只 ETF 计入 unknown (WEIGHTS_EXCEED_100), 不猜测;
  · 守恒: 已知公司敞口 + 未知 = 投入金额 (误差 ≤ 0.01 元)。穿透、集中度、压力情景共用 split_etf_value。
  · 非 A 股股票/ETF 的持仓 (债券、货基、港股等) → 计入 unknown (原因: unsupported_instrument);
  · 现金单列, 不计入未知, 也不分摊到公司。
行业: 只使用本地 stock_list 中已有的行业字段; 缺失的记为"行业未知"。产业链环节暂未建模。
"""
from __future__ import annotations

from collections import defaultdict
from typing import Any, Callable, Iterable, Mapping, Optional

_ETF_PREFIX_SH = ("51", "52", "56", "58")
_ETF_PREFIX_SZ = ("15", "16")
_STOCK_PREFIX = {"SH": ("60", "68"), "SZ": ("00", "30"), "BJ": ("4", "8", "92")}


def classify_instrument(ts_code: str) -> str:
    code, _, market = (ts_code or "").partition(".")
    market = market.upper()
    if market == "SH" and code.startswith(_ETF_PREFIX_SH):
        return "etf"
    if market == "SZ" and code.startswith(_ETF_PREFIX_SZ):
        return "etf"
    if code.startswith(_STOCK_PREFIX.get(market, ())):
        return "stock"
    return "other"


WEIGHT_SUM_TOLERANCE_PCT = 0.5
_CENT = 0.005


def split_etf_value(mv: float, rec: Mapping[str, Any]) -> dict:
    """ETF 市值 → 成分公司金额 + 未知余量 (穿透/集中度/压力共用的唯一口径)。

    返回 {"status": ok|unavailable|rejected, "parts": [(code, name, value, weight_pct)], "residual",
          "residual_reason", "reason", "weight_sum_pct", "weights_scaled", "exposure_basis"}。
    parts 金额之和 + residual = mv。"""
    basis = rec.get("exposure_basis") or "tracking_index_weight"
    cons = rec.get("constituents") or []
    base = {"parts": [], "residual": float(mv), "weight_sum_pct": None, "weights_scaled": False,
            "exposure_basis": basis, "residual_reason": None}
    if rec.get("is_verified") is not True or not cons:
        reason = (list(rec.get("issues") or []) or ["CONSTITUENTS_UNAVAILABLE"])[-1]
        return {**base, "status": "unavailable", "reason": reason, "residual_reason": reason}
    items = [(str(c.get("code") or ""), c.get("name") or "", float(c.get("weight_pct") or 0.0)) for c in cons]
    items = [x for x in items if x[0] and x[2] > 0]
    wsum = sum(w for _, _, w in items)
    if wsum > 100.0 + WEIGHT_SUM_TOLERANCE_PCT:
        return {**base, "status": "rejected", "reason": "WEIGHTS_EXCEED_100",
                "residual_reason": "WEIGHTS_EXCEED_100", "weight_sum_pct": round(wsum, 4)}
    scale = 100.0 / wsum if wsum > 100.0 else 1.0
    parts = [(code, name, mv * w * scale / 100.0, w) for code, name, w in items]
    residual = mv - sum(v for _, _, v, _ in parts)
    residual = 0.0 if abs(residual) <= _CENT else residual
    reason = (("FUND_HOLDINGS_UNDISCLOSED_REMAINDER" if basis == "fund_reported_holdings"
               else "INDEX_WEIGHT_COVERAGE_BELOW_100") if residual > 0 else None)
    return {**base, "status": "ok", "reason": None, "parts": parts, "residual": residual, "residual_reason": reason,
            "weight_sum_pct": round(wsum, 4), "weights_scaled": scale != 1.0}


def build_lookthrough(positions: Iterable[Mapping[str, Any]], *, cash: Optional[float],
                      constituent_lookup: Callable[[str], Mapping[str, Any]],
                      stock_info: Optional[Mapping[str, Mapping[str, Any]]] = None,
                      top: int = 30) -> dict:
    stock_info = stock_info or {}
    companies: dict[str, dict] = {}
    unknown_items: list[dict] = []
    etf_rows: list[dict] = []

    def company(code: str, name: str = "") -> dict:
        if code not in companies:
            info = stock_info.get(code) or {}
            companies[code] = {"code": code, "name": info.get("name") or name or code,
                               "industry": info.get("industry") or None,
                               "direct_value": 0.0, "via_etf_value": 0.0, "sources": []}
        return companies[code]

    invested = 0.0
    for p in positions:
        code = str(p.get("ts_code") or "")
        mv = float(p.get("market_value") or 0.0)
        if mv <= 0:
            continue
        invested += mv
        kind = classify_instrument(code)
        if kind == "stock":
            c = company(code, p.get("name") or "")
            c["direct_value"] += mv
            c["sources"].append({"via": "direct", "value": round(mv, 2)})
            continue
        if kind != "etf":
            unknown_items.append({"ts_code": code, "name": p.get("name"), "value": round(mv, 2),
                                  "reason": "unsupported_instrument"})
            continue
        rec = constituent_lookup(code) or {}
        cons = rec.get("constituents") or []
        row = {"ts_code": code, "name": p.get("name"), "value": round(mv, 2),
               "instrument_name": rec.get("instrument_name") or None,
               "research_label": rec.get("policy_label") or None,
               "tracking_index_code": rec.get("tracking_index_code") or None,
               "tracking_index_name": rec.get("tracking_index_name") or None,
               "weights_as_of": rec.get("as_of"), "age_days": rec.get("age_days"),
               "is_verified": rec.get("is_verified") is True,
               "constituents_complete": rec.get("constituents_complete", bool(cons)),
               "issues": list(rec.get("issues") or []),
               "exposure_basis": rec.get("exposure_basis", "tracking_index_weight"),
               "reported_ann_date": rec.get("reported_ann_date")}
        split = split_etf_value(mv, rec)
        row["weight_sum_pct"] = split["weight_sum_pct"]
        row["weights_scaled"] = split["weights_scaled"]
        if split["status"] != "ok":
            unknown_items.append({"ts_code": code, "name": p.get("name"), "value": round(mv, 2),
                                  "reason": split["reason"]})
            row["mapped_value"] = 0.0
            etf_rows.append(row)
            continue
        mapped = 0.0
        for ccode, cname, v, w in split["parts"]:
            c = company(ccode, cname)
            c["via_etf_value"] += v
            c["sources"].append({"via": code, "weight_pct": w, "value": round(v, 2)})
            mapped += v
        if split["residual"] > 0:
            unknown_items.append({"ts_code": code, "name": p.get("name"), "value": round(split["residual"], 2),
                                  "reason": split["residual_reason"]})
        row["mapped_value"] = round(mapped, 2)
        row["weight_coverage_pct"] = round(mapped / mv * 100, 2) if mv else None
        etf_rows.append(row)

    cash_v = float(cash) if cash is not None else None
    total = invested + (cash_v or 0.0)
    unknown_value = sum(u["value"] for u in unknown_items)

    def pct(v: float) -> Optional[float]:
        return round(v / total * 100, 2) if total > 0 else None

    rows = []
    for c in companies.values():
        tv = c["direct_value"] + c["via_etf_value"]
        rows.append({**c, "direct_value": round(c["direct_value"], 2), "via_etf_value": round(c["via_etf_value"], 2),
                     "total_value": round(tv, 2), "pct_of_total": pct(tv),
                     "overlap": c["direct_value"] > 0 and c["via_etf_value"] > 0 or
                                len({s["via"] for s in c["sources"]}) > 1})
    rows.sort(key=lambda r: -r["total_value"])

    ind = defaultdict(float)
    for r in rows:
        ind[r["industry"] or "行业未知"] += r["total_value"]
    industries = sorted(({"industry": k, "value": round(v, 2), "pct_of_total": pct(v)} for k, v in ind.items()),
                        key=lambda x: -x["value"])

    return {
        "status": "ok" if invested > 0 else "empty",
        "total_value": round(total, 2),
        "invested_value": round(invested, 2),
        "cash": None if cash_v is None else round(cash_v, 2),
        "cash_pct": None if cash_v is None else pct(cash_v),
        "known_lookthrough_value": round(invested - unknown_value, 2),
        "known_lookthrough_pct_of_invested": round((invested - unknown_value) / invested * 100, 2) if invested else None,
        "coverage_complete": unknown_value <= 0.01,
        "conservation_check": round(sum(c["direct_value"] + c["via_etf_value"] for c in companies.values())
                                    + unknown_value - invested, 2),
        "unknown": {"value": round(unknown_value, 2), "pct_of_total": pct(unknown_value),
                    "items": sorted(unknown_items, key=lambda u: -u["value"]),
                    "note": "未知部分不是零风险: 成分过期/缺失、权重覆盖不足或不支持的品种"},
        "companies": rows[:top],
        "company_count": len(rows),
        "overlap_companies": [r["code"] for r in rows if r["overlap"]],
        "industries": industries,
        "etfs": etf_rows,
        "basis": {"exposure_basis": "per_etf",
                  "note": ("ETF 部分优先按跟踪指数官方成分权重近似; 指数权重不可得时改用基金定期报告披露持仓 "
                           "(报告期末时点, 季报多为前十大, 未披露部分计为未知)。口径与日期见各 ETF 的 "
                           "exposure_basis / weights_as_of / reported_ann_date"),
                  "industry_source": "本地 stock_list 行业字段 (缺失记为行业未知)",
                  "chain_segment": "产业链环节暂未建模"},
    }
