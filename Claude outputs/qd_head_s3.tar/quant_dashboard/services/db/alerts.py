"""V21.0 日报缓存 + V21.2 信号预警 + V22.0 审计日志"""

from datetime import datetime
from typing import Optional, List, Dict
from .connection import _get_conn, logger


# ══════════════════════════════════════════════════════════
#  V21.0: 日报缓存 (投委会报告持久化)
# ══════════════════════════════════════════════════════════

def _ensure_daily_reports_table():
    """幂等建表: daily_reports (V21.0 日报缓存)"""
    conn = _get_conn()
    conn.execute("""
        CREATE TABLE IF NOT EXISTS daily_reports (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            date TEXT NOT NULL UNIQUE,
            markdown TEXT NOT NULL,
            summary_json TEXT,
            generated_at TEXT DEFAULT CURRENT_TIMESTAMP
        )
    """)
    conn.execute("CREATE INDEX IF NOT EXISTS idx_reports_date ON daily_reports(date)")
    conn.commit()


def save_daily_report(date: str, markdown: str, summary: dict = None):
    """保存日报 Markdown (按 date UNIQUE 键, 幂等)"""
    import json as _json
    _ensure_daily_reports_table()
    conn = _get_conn()
    now = datetime.now().isoformat()
    summary_str = _json.dumps(summary, ensure_ascii=False) if summary else None
    conn.execute(
        """INSERT INTO daily_reports (date, markdown, summary_json, generated_at)
           VALUES (?, ?, ?, ?)
           ON CONFLICT(date) DO UPDATE SET
             markdown = excluded.markdown,
             summary_json = excluded.summary_json,
             generated_at = excluded.generated_at""",
        (date, markdown, summary_str, now),
    )
    conn.commit()


def get_daily_report(date: str) -> Optional[Dict]:
    """获取指定日期的日报"""
    _ensure_daily_reports_table()
    conn = _get_conn()
    row = conn.execute(
        "SELECT date, markdown, summary_json, generated_at FROM daily_reports WHERE date = ?",
        (date,),
    ).fetchone()
    return dict(row) if row else None


# ═══════════════════════════════════════════════════
#  V21.2: 信号预警持久化
# ═══════════════════════════════════════════════════

def save_alert(rule_id: str, severity: str, title: str, detail: str, value: float):
    """写入预警记录"""
    conn = _get_conn()
    conn.execute(
        """INSERT INTO signal_alerts (rule_id, severity, title, detail, value, created_at)
           VALUES (?, ?, ?, ?, ?, ?)""",
        (rule_id, severity, title, detail, value, datetime.now().isoformat()),
    )
    conn.commit()


def get_recent_alerts(limit: int = 20) -> List[Dict]:
    """获取最近预警列表"""
    conn = _get_conn()
    rows = conn.execute(
        "SELECT id, rule_id, severity, title, detail, value, created_at, acknowledged "
        "FROM signal_alerts ORDER BY created_at DESC LIMIT ?",
        (limit,),
    ).fetchall()
    return [dict(r) for r in rows]


def acknowledge_alert(alert_id: int):
    """标记预警已读"""
    conn = _get_conn()
    conn.execute("UPDATE signal_alerts SET acknowledged = 1 WHERE id = ?", (alert_id,))
    conn.commit()


def get_last_alert_time(rule_id: str) -> Optional[str]:
    """获取某规则最近一次触发的时间 (用于 cooldown 判断)"""
    conn = _get_conn()
    row = conn.execute(
        "SELECT created_at FROM signal_alerts WHERE rule_id = ? ORDER BY created_at DESC LIMIT 1",
        (rule_id,),
    ).fetchone()
    return row["created_at"] if row else None


def get_unread_alert_count() -> int:
    """未读预警数量 (铃铛 badge)"""
    conn = _get_conn()
    row = conn.execute("SELECT COUNT(*) as c FROM signal_alerts WHERE acknowledged = 0").fetchone()
    return row["c"] if row else 0


def ack_all_alerts() -> int:
    """P1-2: 一键全部已读 (事务安全版本), 返回受影响行数"""
    conn = _get_conn()
    cur = conn.execute("UPDATE signal_alerts SET acknowledged = 1 WHERE acknowledged = 0")
    conn.commit()
    return cur.rowcount


# ══════════════════════════════════════════════════════════
#  V22.0: 审计日志持久化
# ══════════════════════════════════════════════════════════

_AUDIT_LOG_NEW_COLUMNS = (("schema_version", "TEXT"), ("trust_status", "TEXT"),
                          ("compliance_status", "TEXT"), ("trigger", "TEXT"))


def _ensure_audit_log_columns(conn):
    """2026-11-02: 审计页拆分为 A 系统可信度 / B 组合合规, 记录口径版本 (幂等迁移)。
    旧记录 schema_version 为空 = 旧"可信度总分"口径 (含风控), 与新记录不可直接比较。"""
    existing = {r[1] for r in conn.execute("PRAGMA table_info(audit_log)").fetchall()}
    for col, typ in _AUDIT_LOG_NEW_COLUMNS:
        if col not in existing:
            conn.execute(f'ALTER TABLE audit_log ADD COLUMN "{col}" {typ}')
    conn.commit()


def save_audit_log(report: dict):
    """持久化审计报告到 audit_log 表 (每日定时或手动保存; 打开审计页不写)。
    新口径: trust_score = A 系统可信度; 组合合规只记状态; 分组得分与否决项写入 summary_json。"""
    import json as _json
    conn = _get_conn()
    _ensure_audit_log_columns(conn)
    trust = report.get("system_trust") or {}
    modules = report.get("modules", {})
    summary = {
        "groups": {k: modules.get(k, {}).get("score") for k in
                   ("data_freshness", "engine_runtime", "param_evidence", "system_status")},
        "veto": (trust.get("veto") or {}).get("items") or [],
        "compliance_summary": (report.get("portfolio_compliance") or {}).get("summary"),
    }
    conn.execute(
        """INSERT INTO audit_log
           (audit_time, trust_score, trust_grade, total_checks,
            pass_count, warn_count, fail_count, elapsed_seconds,
            data_quality_score, strategy_health_score, risk_control_score,
            factor_decay_score, system_status_score, summary_json,
            schema_version, trust_status, compliance_status, "trigger")
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
        (
            report.get("audit_time", ""),
            trust.get("score", 0),
            trust.get("grade", "D"),
            report.get("total_checks", 0),
            report.get("pass_count", 0),
            report.get("warn_count", 0),
            report.get("fail_count", 0),
            report.get("elapsed_seconds", 0),
            None, None, None, None, None,   # 旧五维列不再写入 (口径已变), 分组得分见 summary_json
            _json.dumps(summary, ensure_ascii=False),
            report.get("version"),
            trust.get("status"),
            report.get("compliance_status"),
            report.get("trigger"),
        )
    )
    conn.commit()

    # 保留最近 90 天
    conn.execute("DELETE FROM audit_log WHERE created_at < datetime('now', '-90 days')")
    conn.commit()


def get_audit_history(limit: int = 10) -> list:
    """获取最近 N 次审计记录; schema_version 为空的是旧口径记录 (含风控的可信度总分)。"""
    conn = _get_conn()
    _ensure_audit_log_columns(conn)
    rows = conn.execute(
        "SELECT audit_time, trust_score, trust_grade, fail_count, warn_count, "
        "pass_count, elapsed_seconds, total_checks, schema_version, trust_status, "
        "compliance_status, \"trigger\" "
        "FROM audit_log ORDER BY created_at DESC LIMIT ?",
        (limit,)
    ).fetchall()
    return [dict(r) for r in rows]

def get_audit_trend(schema_version: str, days: int = 90) -> dict:
    """审计趋势 (2026-11-02): 只取与当前口径相同 schema_version 的记录, 每个日期一个点。
    同一天有多条时优先每日定时 (trigger=daily), 否则取当天最后一条手动保存。
    旧口径 (schema_version 为空) 与其他口径版本的记录不参与, 只返回条数供页面说明。"""
    import json as _json
    conn = _get_conn()
    _ensure_audit_log_columns(conn)
    rows = [dict(r) for r in conn.execute(
        "SELECT id, audit_time, trust_score, trust_grade, trust_status, compliance_status, "
        "schema_version, \"trigger\", summary_json FROM audit_log "
        "WHERE created_at >= datetime('now', ?) ORDER BY audit_time, id",
        (f"-{int(days)} days",)).fetchall()]
    legacy = sum(1 for r in rows if not r["schema_version"])
    other = sum(1 for r in rows if r["schema_version"] and r["schema_version"] != schema_version)
    by_day = {}
    for r in rows:
        if r["schema_version"] != schema_version:
            continue
        day = (r["audit_time"] or "")[:10]
        if not day:
            continue
        cur = by_day.get(day)
        # 定时记录优先; 同类记录取当天最后一条 (rows 已按时间升序)
        if cur is None or r["trigger"] == "daily" or cur["trigger"] != "daily":
            by_day[day] = r
    points = []
    for day in sorted(by_day):
        r = by_day[day]
        try:
            summary = _json.loads(r["summary_json"] or "{}")
        except (TypeError, ValueError):
            summary = {}
        points.append({
            "date": day, "audit_time": r["audit_time"], "trigger": r["trigger"],
            "a_score": r["trust_score"], "a_grade": r["trust_grade"],   # 列名沿用 trust_score, 新口径下 = A 系统可信度
            "trust_status": r["trust_status"], "veto": summary.get("veto") or [],
            "compliance_status": r["compliance_status"], "groups": summary.get("groups") or {},
        })
    return {"schema_version": schema_version, "days": int(days), "points": points,
            "excluded_legacy": legacy, "excluded_other_version": other}
