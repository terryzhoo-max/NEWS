"""决策日志 (V16.0: 科学辅助决策模块)"""

from datetime import datetime, timedelta
from typing import Optional, List, Dict
from .connection import _get_conn, logger


def record_decision_evidence(snapshot: dict, jcs: dict) -> str:
    """Append-only evidence; exact repeats share an id and never rewrite history."""
    import hashlib
    import json
    from datetime import timezone
    from services.jcs_validation import model_fingerprint
    inputs = json.dumps(snapshot, sort_keys=True, ensure_ascii=False, allow_nan=False)
    result = json.dumps(jcs, sort_keys=True, ensure_ascii=False, allow_nan=False)
    model_hash = model_fingerprint()
    evidence_id = hashlib.sha256((model_hash + inputs + result).encode()).hexdigest()
    conn = _get_conn()
    conn.execute("INSERT INTO decision_evidence VALUES (?,?,?,?,?,?) ON CONFLICT(evidence_id) DO NOTHING",
                 (evidence_id, jcs["model_version"], model_hash, inputs, result,
                  datetime.now(timezone.utc).isoformat()))
    conn.commit()
    return evidence_id


# ══════════════════════════════════════════════════════════
#  决策日志 (V16.0: 科学辅助决策模块)
# ══════════════════════════════════════════════════════════

def upsert_decision_log(data: dict):
    """插入或更新每日决策快照 (按 date UNIQUE 键, 幂等) — V25.3: 含影子模式"""
    conn = _get_conn()
    now = datetime.now().isoformat()
    conn.execute(
        """INSERT INTO decision_log
           (date, aiae_regime, aiae_v1, erp_score, erp_val, vix_val, mr_regime,
            hub_composite, jcs_score, jcs_level, suggested_position,
            conflict_count, degraded_modules, recorded_at,
            jcs_v4_score, jcs_v6_score, jcs_shadow_delta, gold_signal, bond_signal,
            jcs_v26_score, delta_v26,
            signal_direction, signal_net_weight, direction_source, eval_horizon_days,
            eval_version, eval_status, model_version, v27_direction, v27_confidence)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,
                   ?, ?, ?, ?, ?, ?, ?, ?, ?)
           ON CONFLICT(date) DO UPDATE SET
             aiae_regime = excluded.aiae_regime,
             aiae_v1 = excluded.aiae_v1,
             erp_score = excluded.erp_score,
             erp_val = excluded.erp_val,
             vix_val = excluded.vix_val,
             mr_regime = excluded.mr_regime,
             hub_composite = excluded.hub_composite,
             jcs_score = excluded.jcs_score,
             jcs_level = excluded.jcs_level,
             suggested_position = excluded.suggested_position,
             conflict_count = excluded.conflict_count,
             degraded_modules = excluded.degraded_modules,
             recorded_at = excluded.recorded_at,
             jcs_v4_score = excluded.jcs_v4_score,
             jcs_v6_score = excluded.jcs_v6_score,
             jcs_shadow_delta = excluded.jcs_shadow_delta,
             gold_signal = excluded.gold_signal,
             bond_signal = excluded.bond_signal,
             jcs_v26_score = excluded.jcs_v26_score,
             delta_v26 = excluded.delta_v26,
             -- F1: 方向一经评价 (已有 T+5 收益) 不再被同日重写覆盖
             signal_direction = CASE WHEN decision_log.market_return_5d IS NULL
                                     THEN excluded.signal_direction ELSE decision_log.signal_direction END,
             signal_net_weight = CASE WHEN decision_log.market_return_5d IS NULL
                                      THEN excluded.signal_net_weight ELSE decision_log.signal_net_weight END,
             direction_source = CASE WHEN decision_log.market_return_5d IS NULL
                                     THEN excluded.direction_source ELSE decision_log.direction_source END,
             eval_horizon_days = CASE WHEN decision_log.market_return_5d IS NULL
                                      THEN excluded.eval_horizon_days ELSE decision_log.eval_horizon_days END,
             eval_version = CASE WHEN decision_log.market_return_5d IS NULL
                                 THEN excluded.eval_version ELSE decision_log.eval_version END,
             eval_status = CASE WHEN decision_log.market_return_5d IS NULL
                                THEN excluded.eval_status ELSE decision_log.eval_status END,
             model_version = CASE WHEN decision_log.market_return_5d IS NULL
                                  THEN excluded.model_version ELSE decision_log.model_version END,
             v27_direction = CASE WHEN decision_log.market_return_5d IS NULL
                                  THEN excluded.v27_direction ELSE decision_log.v27_direction END,
             v27_confidence = CASE WHEN decision_log.market_return_5d IS NULL
                                   THEN excluded.v27_confidence ELSE decision_log.v27_confidence END""",
        (
            data.get("date"),
            data.get("aiae_regime"),
            data.get("aiae_v1"),
            data.get("erp_score"),
            data.get("erp_val"),
            data.get("vix_val"),
            data.get("mr_regime"),
            data.get("hub_composite"),
            data.get("jcs_score"),
            data.get("jcs_level"),
            data.get("suggested_position"),
            data.get("conflict_count", 0),
            data.get("degraded_modules", ""),
            now,
            data.get("jcs_v4_score"),
            data.get("jcs_v6_score"),
            data.get("jcs_shadow_delta"),
            data.get("gold_signal"),
            data.get("bond_signal"),
            data.get("jcs_v26_score"),
            data.get("delta_v26"),
            data.get("signal_direction"),
            data.get("signal_net_weight"),
            data.get("direction_source"),
            data.get("eval_horizon_days"),
            data.get("eval_version"),
            data.get("eval_status"),
            data.get("model_version"),
            data.get("v27_direction"),
            data.get("v27_confidence"),
        ),
    )
    conn.commit()


def get_decision_history(days: int = 30) -> List[Dict]:
    """获取最近 N 天的决策日志 (按日期正序)"""
    conn = _get_conn()
    rows = conn.execute(
        "SELECT * FROM decision_log ORDER BY date DESC LIMIT ?", (days,)
    ).fetchall()
    return [dict(r) for r in reversed(rows)]


def cleanup_old_decisions(keep_days: int = 365):
    """清理超过 keep_days 的旧决策记录"""
    conn = _get_conn()
    cutoff = (datetime.now() - timedelta(days=keep_days)).strftime("%Y-%m-%d")
    deleted = conn.execute(
        "DELETE FROM decision_log WHERE date < ?", (cutoff,)
    ).rowcount
    conn.commit()
    if deleted > 0:
        logger.info("清理旧决策记录: 删除 %d 条 (保留 %d 天)", deleted, keep_days)


def backfill_accuracy(date: str, market_return_5d: float):
    """回填 T+5 沪深300 收益, 并按写入当日保存的方向评价 (F1 修复, 2026-10-27)。

    JCS 分数不是方向: 一致看空也可得高分。判定只看 signal_direction:
      +1 且上涨 / -1 且下跌 → 正确 (1); 反向 → 错误 (0)
      0 (中性) / 收益为 0 / 缺少当时方向的历史记录 → 不评价 (signal_correct = NULL)
    缺少方向的记录绝不按当前模型重算。规则见 services/jcs_accuracy.py。
    """
    from services.jcs_accuracy import STATUS_LEGACY, evaluate_direction
    conn = _get_conn()
    row = conn.execute(
        "SELECT signal_direction, eval_status FROM decision_log WHERE date = ?", (date,)
    ).fetchone()
    if not row:
        return
    direction, prior_status = row[0], row[1]
    if direction is None or prior_status == STATUS_LEGACY:
        status, correct = STATUS_LEGACY, None
    else:
        status, correct = evaluate_direction(direction, market_return_5d)
    conn.execute(
        "UPDATE decision_log SET market_return_5d = ?, signal_correct = ?, eval_status = ? "
        "WHERE date = ?",
        (round(market_return_5d, 4), correct, status, date),
    )
    conn.commit()


def get_accuracy_stats() -> Dict:
    """V25.2: 计算信号准确率统计 (含趋势历史 + 连胜/连败)"""
    conn = _get_conn()
    rows = conn.execute(
        "SELECT signal_correct, COUNT(*) as cnt FROM decision_log "
        "WHERE signal_correct IS NOT NULL AND signal_correct >= 0 "
        "GROUP BY signal_correct"
    ).fetchall()
    total, correct = 0, 0
    for r in rows:
        total += r[1]
        if r[0] == 1:
            correct = r[1]
    accuracy = round(correct / total * 100, 1) if total > 0 else None
    # 近10次准确率
    recent = conn.execute(
        "SELECT signal_correct FROM decision_log "
        "WHERE signal_correct IS NOT NULL AND signal_correct >= 0 "
        "ORDER BY date DESC LIMIT 10"
    ).fetchall()
    recent_correct = sum(1 for r in recent if r[0] == 1)
    recent_total = len(recent)
    recent_accuracy = round(recent_correct / recent_total * 100, 1) if recent_total > 0 else None
    # V25.2: 连胜/连败计算
    streak, streak_type = 0, "none"
    if recent:
        first_val = recent[0][0]
        streak_type = "win" if first_val == 1 else "lose"
        for r in recent:
            if r[0] == first_val:
                streak += 1
            else:
                break
    # V25.2: 每日准确率历史 (供趋势图)
    history = conn.execute(
        "SELECT date, jcs_score, signal_correct, market_return_5d, signal_direction FROM decision_log "
        "WHERE signal_correct IS NOT NULL AND signal_correct >= 0 "
        "ORDER BY date ASC LIMIT 60"
    ).fetchall()
    history_list = [
        {"date": r[0], "jcs": r[1], "correct": r[2], "ret5d": r[3], "direction": r[4]}
        for r in history
    ]
    # F1: 披露未计入评价的记录, 避免把"可评价子集"误读为全部记录
    from services.jcs_accuracy import UNSCORED_STATUSES, evaluation_meta
    coverage = {status: 0 for status in UNSCORED_STATUSES}
    for status, cnt in conn.execute(
        "SELECT eval_status, COUNT(*) FROM decision_log WHERE eval_status IS NOT NULL "
        "GROUP BY eval_status"
    ).fetchall():
        if status in coverage:
            coverage[status] = cnt
    coverage["evaluated"] = total
    coverage["awaiting_t5"] = conn.execute(
        "SELECT COUNT(*) FROM decision_log WHERE market_return_5d IS NULL "
        "AND signal_direction IS NOT NULL"
    ).fetchone()[0]
    return {
        "evaluation": evaluation_meta(),
        "coverage": coverage,
        "total_decisions": total,
        "correct_decisions": correct,
        "accuracy_pct": accuracy,
        "recent_10_accuracy": recent_accuracy,
        "recent_10_total": recent_total,
        "has_data": total >= 1,
        "maturity": "mature" if total >= 15 else ("growing" if total >= 5 else "initial"),
        "current_streak": streak,
        "streak_type": streak_type,
        "history": history_list,
        "recent_signals": [r[0] for r in reversed(recent)] if recent else [],
    }



def get_accuracy_by_jcs_level() -> Dict:
    """P3-C: 按 JCS 置信度级别分组的准确率"""
    conn = _get_conn()
    rows = conn.execute(
        "SELECT jcs_level, signal_correct, COUNT(*) as cnt "
        "FROM decision_log "
        "WHERE signal_correct IS NOT NULL AND signal_correct >= 0 "
        "AND jcs_level IS NOT NULL "
        "GROUP BY jcs_level, signal_correct"
    ).fetchall()

    levels = {}
    for level, correct, cnt in rows:
        if level not in levels:
            levels[level] = {"total": 0, "correct": 0}
        levels[level]["total"] += cnt
        if correct == 1:
            levels[level]["correct"] += cnt

    result = {}
    for level in ["high", "medium", "low"]:
        data = levels.get(level, {"total": 0, "correct": 0})
        result[level] = {
            "total": data["total"],
            "correct": data["correct"],
            "accuracy": round(data["correct"] / data["total"] * 100, 1) if data["total"] > 0 else None,
        }
    return result


def get_accuracy_by_regime() -> Dict:
    """P3-C: 按 AIAE Regime 分组的准确率"""
    conn = _get_conn()
    rows = conn.execute(
        "SELECT aiae_regime, signal_correct, COUNT(*) as cnt "
        "FROM decision_log "
        "WHERE signal_correct IS NOT NULL AND signal_correct >= 0 "
        "AND aiae_regime IS NOT NULL "
        "GROUP BY aiae_regime, signal_correct"
    ).fetchall()

    regimes = {}
    regime_labels = {1: "Ⅰ 极冷", 2: "Ⅱ 偏冷", 3: "Ⅲ 中性", 4: "Ⅳ 偏热", 5: "Ⅴ 极热"}
    for regime, correct, cnt in rows:
        if regime not in regimes:
            regimes[regime] = {"total": 0, "correct": 0}
        regimes[regime]["total"] += cnt
        if correct == 1:
            regimes[regime]["correct"] += cnt

    result = {}
    for r in range(1, 6):
        data = regimes.get(r, {"total": 0, "correct": 0})
        result[str(r)] = {
            "regime": r,
            "label": regime_labels.get(r, f"R{r}"),
            "total": data["total"],
            "correct": data["correct"],
            "accuracy": round(data["correct"] / data["total"] * 100, 1) if data["total"] > 0 else None,
        }
    return result


def get_accuracy_rolling(window: int = 30) -> Dict:
    """P3-C: 滚动窗口准确率 (30/60/90日)"""
    conn = _get_conn()
    rows = conn.execute(
        "SELECT date, jcs_score, jcs_level, signal_correct, market_return_5d, "
        "aiae_regime, jcs_v4_score, jcs_v6_score, jcs_shadow_delta "
        "FROM decision_log "
        "WHERE signal_correct IS NOT NULL AND signal_correct >= 0 "
        "ORDER BY date DESC LIMIT ?", (window,)
    ).fetchall()

    if not rows:
        return {"window": window, "total": 0, "accuracy": None, "data": []}

    total = len(rows)
    correct = sum(1 for r in rows if r[3] == 1)
    accuracy = round(correct / total * 100, 1) if total > 0 else None

    data = [{
        "date": r[0], "jcs": r[1], "level": r[2], "correct": r[3],
        "ret5d": r[4], "regime": r[5],
        "v4_score": r[6], "v6_score": r[7], "shadow_delta": r[8],
    } for r in rows]

    return {
        "window": window,
        "total": total,
        "correct": correct,
        "accuracy": accuracy,
        "data": data,
    }


def get_shadow_comparison() -> Dict:
    """V4/V6 影子"准确率"对比已停用 (F1, 2026-10-27)。

    旧实现把 v4/v6 分数 >=50 当作看多来计算准确率, 并据此给出"切换模型"建议;
    JCS 分数不是方向, 该对比与建议没有意义。V4/V6 的方向集合相同, 方向评价见
    get_accuracy_stats()。分数差异仍可在 get_accuracy_rolling() 的 shadow_delta 中查看。
    """
    return {
        "has_data": False,
        "status": "retired_semantics_mismatch",
        "detail": "旧对比把 JCS>=50 视为看多, 与 JCS 评分语义不符, 已停用; 不再提供模型切换建议",
    }


def get_calendar_data(year: int = None, month: int = None) -> List[Dict]:
    """获取月历数据 (每日 JCS + 仓位 + 矛盾数)"""
    conn = _get_conn()
    if year and month:
        prefix = f"{year:04d}-{month:02d}"
        rows = conn.execute(
            "SELECT date, jcs_score, jcs_level, suggested_position, conflict_count, "
            "aiae_regime, market_return_5d, signal_correct "
            "FROM decision_log WHERE date LIKE ? ORDER BY date",
            (prefix + "%",)
        ).fetchall()
    else:
        rows = conn.execute(
            "SELECT date, jcs_score, jcs_level, suggested_position, conflict_count, "
            "aiae_regime, market_return_5d, signal_correct "
            "FROM decision_log ORDER BY date DESC LIMIT 62"
        ).fetchall()
    return [dict(r) for r in rows]
