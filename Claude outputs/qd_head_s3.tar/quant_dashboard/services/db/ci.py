"""P1-3: CI/CD 管道 CRUD

第 0 轮 0a-3 (2026-11-05, docs/ROUND0_CI_EVALUATE_ONLY_PLAN.md 3.4): 批准只记录 (approve_ci_run 只改这一条的
approval_status / approved_at / approval_detail, 且仅当它仍是 PENDING); 读取时现算显示状态
(approval_display: 已生效 / 已被取代 / 待批准（已过期）等), 不写库。
"""

import json
from datetime import datetime, timedelta, timezone
from typing import Optional, List, Dict
from .connection import _get_conn, logger

# 第 0 轮 0a-1: 触发来源的显示文字; 旧记录 (迁移前) 来源为空
TRIGGER_SOURCE_LABELS = {"scheduler": "定时任务", "api": "接口", "direct": "直接调用"}
TRIGGER_SOURCE_UNRECORDED = "未记录（第 0 轮前）"
_JSON_FIELDS = ("old_params", "new_params", "old_metrics", "new_metrics", "quality_gate",
                "trigger_detail", "approval_detail", "validation")


def _json_or_none(value):
    return None if value is None else json.dumps(value, ensure_ascii=False, default=str)


# ══════════════════════════════════════════════════════════
#  P1-3: CI/CD 管道 CRUD
# ══════════════════════════════════════════════════════════

def save_ci_run(run: dict) -> int:
    """保存一条 CI 运行记录"""
    conn = _get_conn()
    cur = conn.execute(
        """INSERT OR REPLACE INTO ci_runs
           (run_id, strategy, regime, status, old_params, new_params,
            old_metrics, new_metrics, quality_gate, diff_summary,
            trigger_source, trigger_detail, batch_id, reason,
            approval_status, approved_at, approval_detail, validation)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
        (
            run["run_id"], run["strategy"], run.get("regime"),
            run["status"],
            json.dumps(run.get("old_params", {}), ensure_ascii=False),
            json.dumps(run.get("new_params", {}), ensure_ascii=False),
            json.dumps(run.get("old_metrics", {}), ensure_ascii=False),
            json.dumps(run.get("new_metrics", {}), ensure_ascii=False),
            json.dumps(run.get("quality_gate", []), ensure_ascii=False),
            run.get("diff_summary", ""),
            run.get("trigger_source"),
            _json_or_none(run.get("trigger_detail")),
            run.get("batch_id"),
            run.get("reason"),
            run.get("approval_status"),
            run.get("approved_at"),
            _json_or_none(run.get("approval_detail")),
            _json_or_none(run.get("validation")),
        )
    )
    conn.commit()
    return cur.lastrowid


def get_ci_history(strategy: Optional[str] = None, limit: int = 20, *,
                   now: Optional[datetime] = None, runtime_config: Optional[dict] = None) -> List[Dict]:
    """查询 CI 运行历史 (第 0 轮 0a-3 起每条加现算的显示状态字段, 原有字段含义不变)"""
    conn = _get_conn()
    if strategy:
        rows = conn.execute(
            "SELECT * FROM ci_runs WHERE strategy = ? ORDER BY created_at DESC LIMIT ?",
            (strategy, limit)
        ).fetchall()
    else:
        rows = conn.execute(
            "SELECT * FROM ci_runs ORDER BY created_at DESC LIMIT ?",
            (limit,)
        ).fetchall()

    results = [_decode_row(r) for r in rows]
    _annotate_display(conn, results, now=now, runtime_config=runtime_config)
    return results


def _decode_row(r) -> Dict:
    d = dict(r)
    for k in _JSON_FIELDS:
        if d.get(k):
            try:
                d[k] = json.loads(d[k])
            except (json.JSONDecodeError, TypeError):
                pass
    src = d.get("trigger_source")
    d["trigger_source_label"] = (TRIGGER_SOURCE_LABELS.get(src, src) if src
                                 else TRIGGER_SOURCE_UNRECORDED)
    return d


# ── 第 0 轮 0a-3: 读取时现算的显示状态 (不写库) ──
PENDING_EXPIRY_DAYS = 35
# 能"取代"较旧 PENDING 的只算做过评估的运行; ERROR / SKIPPED / DISABLED 不说明参数好坏, 不算 (用户 11-05 10:1x 美中)
EVALUATED_STATUSES = ("ACCEPT", "REVALIDATED", "REVIEW", "REJECT", "INSUFFICIENT_EVIDENCE")
# 能"已生效"的只算通过的评估结果 (MR: 运行时 lifecycle 为 validated 且 validation_run_id 一致; ERP: published_run_id 一致)
EFFECTIVE_STATUSES = {"mr": ("ACCEPT", "REVALIDATED"), "erp": ("ACCEPT", "REVIEW")}
APPROVAL_DISPLAY = {
    "effective": "已生效",
    "superseded": "已被取代",
    "expired": "待批准（已过期）",
    "pending": "待批准",
    "approved": "已批准（待仓库提交生效）",
    "not_applicable": "不适用",
    "unrecorded": "未记录（第 0 轮前）",
}


def _parse_created_at(value) -> Optional[datetime]:
    """created_at 为 SQLite CURRENT_TIMESTAMP (UTC, "YYYY-MM-DD HH:MM:SS")。"""
    if not value:
        return None
    try:
        dt = datetime.fromisoformat(str(value).replace(" ", "T"))
    except ValueError:
        return None
    return dt if dt.tzinfo else dt.replace(tzinfo=timezone.utc)


def _is_effective(row: Dict, runtime_config: Optional[dict]) -> bool:
    if not runtime_config:
        return False
    strategy = str(row.get("strategy") or "").lower()
    if row.get("status") not in EFFECTIVE_STATUSES.get(strategy, ()):
        return False
    strategies = runtime_config.get("strategies") or {}
    run_id = row.get("run_id")
    if strategy == "mr":
        regime = str(row.get("regime") or "").upper()
        lc = ((strategies.get("mr") or {}).get("lifecycle") or {}).get(regime) or {}
        return lc.get("status") == "validated" and lc.get("validation_run_id") == run_id
    if strategy == "erp":
        return (strategies.get("erp") or {}).get("published_run_id") == run_id
    return False


def _is_superseded(conn, row: Dict) -> bool:
    """同一策略 / 状态有更新的已评估运行 (按 created_at, 同一秒再按 id)。"""
    regime = row.get("regime")
    sql = ("SELECT 1 FROM ci_runs WHERE strategy = ? AND "
           + ("regime IS NULL" if regime is None else "regime = ?")
           + " AND run_id != ? AND status IN (%s)" % ",".join("?" * len(EVALUATED_STATUSES))
           + " AND (created_at > ? OR (created_at = ? AND id > ?)) LIMIT 1")
    params = [row.get("strategy")] + ([] if regime is None else [regime]) + [row.get("run_id")]
    params += list(EVALUATED_STATUSES) + [row.get("created_at"), row.get("created_at"), row.get("id") or 0]
    return conn.execute(sql, params).fetchone() is not None


def approval_state(conn, row: Dict, *, now: Optional[datetime] = None,
                   runtime_config: Optional[dict] = None) -> Dict:
    """一条记录的显示状态 (不写库)。返回 {key, label, effective, superseded, expired, age_days}。"""
    now = now or datetime.now(timezone.utc)
    created = _parse_created_at(row.get("created_at"))
    age_days = round((now - created).total_seconds() / 86400, 2) if created else None
    effective = _is_effective(row, runtime_config)
    status = row.get("approval_status")
    superseded = status == "PENDING" and _is_superseded(conn, row)
    expired = (status == "PENDING" and created is not None
               and now - created > timedelta(days=PENDING_EXPIRY_DAYS))
    if effective:
        key = "effective"
    elif status == "PENDING":
        key = "superseded" if superseded else ("expired" if expired else "pending")
    elif status == "APPROVED":
        key = "approved"
    elif status == "NOT_APPLICABLE":
        key = "not_applicable"
    else:
        key = "unrecorded"
    return {"key": key, "label": APPROVAL_DISPLAY[key], "effective": effective,
            "superseded": superseded, "expired": bool(expired), "age_days": age_days}


def _load_runtime_config_safely() -> Optional[dict]:
    try:
        from services.strategy_params import load_runtime_config
        return load_runtime_config()
    except Exception as exc:          # 读不到配置时"已生效"无法判定, 不报错
        logger.warning("CI 显示状态: 读取运行时配置失败, 不判定\"已生效\": %s", exc)
        return None


def _annotate_display(conn, rows: List[Dict], *, now=None, runtime_config=None) -> None:
    if not rows:
        return
    cfg = runtime_config if runtime_config is not None else _load_runtime_config_safely()
    for d in rows:
        st = approval_state(conn, d, now=now, runtime_config=cfg)
        d["approval_display"] = st["label"]
        d["approval_display_key"] = st["key"]
        d["is_effective"] = st["effective"]
        d["is_superseded"] = st["superseded"]
        d["is_expired"] = st["expired"]


def get_ci_run(run_id: str) -> Optional[Dict]:
    """按 run_id 取一条 (解码 JSON 列); 不存在返回 None。不加显示状态 (批准接口自己算)。"""
    conn = _get_conn()
    row = conn.execute("SELECT * FROM ci_runs WHERE run_id = ?", (run_id,)).fetchone()
    return _decode_row(row) if row else None


def get_ci_run_state(run_id: str, *, now: Optional[datetime] = None,
                     runtime_config: Optional[dict] = None) -> Optional[Dict]:
    """一条记录 + 现算的显示状态 (批准接口判定 / 拒绝时返回当前状态用)。"""
    conn = _get_conn()
    row = conn.execute("SELECT * FROM ci_runs WHERE run_id = ?", (run_id,)).fetchone()
    if not row:
        return None
    d = _decode_row(row)
    d["_state"] = approval_state(conn, d, now=now, runtime_config=runtime_config)
    return d


def approve_ci_run(run_id: str, approved_at: str, approval_detail: Dict) -> bool:
    """只更新这一条: PENDING → APPROVED, 写 approved_at / approval_detail。
    条件更新 (WHERE approval_status = 'PENDING'), 并发重复批准只有一次成功; 返回是否更新了。"""
    conn = _get_conn()
    cur = conn.execute(
        "UPDATE ci_runs SET approval_status = 'APPROVED', approved_at = ?, approval_detail = ? "
        "WHERE run_id = ? AND approval_status = 'PENDING'",
        (approved_at, _json_or_none(approval_detail), run_id),
    )
    conn.commit()
    return cur.rowcount == 1


def get_ci_latest(strategy: str) -> Optional[Dict]:
    """获取某策略最近一次 CI 结果"""
    results = get_ci_history(strategy=strategy, limit=1)
    return results[0] if results else None


def update_ci_status(run_id: str, new_status: str) -> bool:
    """更新 CI 运行状态 (REVIEW → ACCEPT/REJECT)"""
    conn = _get_conn()
    cur = conn.execute(
        "UPDATE ci_runs SET status = ? WHERE run_id = ?",
        (new_status, run_id)
    )
    conn.commit()
    return cur.rowcount > 0
