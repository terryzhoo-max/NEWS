"""Explicit signal availability and source time; cache refresh is not observation time."""
import math
from datetime import datetime, timezone
from zoneinfo import ZoneInfo

ENGINE_FIELDS = {"aiae": "aiae_regime", "erp": "erp_score", "vix": "vix_val",
                 "mr": "mr_regime", "gold": "gold_signal", "bond": "bond_signal"}
# 2026-11-01 JCS = 宏观环境读数: 必需的宏观因子只有 AIAE/ERP/VIX。
# MR 是策略信号 (移出 JCS); BOND 已降级为背景 (移出 JCS)。两者仍作为读数返回, 但标记 excluded。
CORE_ENGINES = ("aiae", "erp", "vix")
EXCLUDED_ENGINES = {
    "mr": "MR 是策略信号，不属于宏观环境；已移出 JCS，见策略执行总览",
    "bond": "利率信号样本外验证未通过，仅作背景读数；已移出 JCS",
}
# 半衰期按信号自身的变化速度设定: ERP 是慢变量 (估值), 72h 会让一个周末就把估值信号折旧过半。
# 日频数据按"错过的收盘次数"计龄 (1 个交易日 = 24h), 不按自然日或盘中分钟。
HALF_LIFE_HOURS = {"aiae": 360, "erp": 240, "vix": 24, "mr": 48}
# 收盘时点 (当地时间): 收盘后当天的数据才算"已错过"
_CLOSE_HOUR = {"aiae": 15, "erp": 15, "mr": 15, "vix": 16, "gold": 16, "bond": 16}


def finite_number(value):
    if isinstance(value, bool):
        return None
    try:
        value = float(value)
        return value if math.isfinite(value) else None
    except (TypeError, ValueError, OverflowError):
        return None


def signal_states(snapshot):
    states = {}
    for engine, field in ENGINE_FIELDS.items():
        raw = snapshot.get(field)
        value = raw if engine == "mr" else finite_number(raw)
        if engine == "mr":
            valid = isinstance(value, str) and value in {"BULL", "RANGE", "BEAR", "CRASH"}
        else:
            bounds = {"aiae": (1, 5), "erp": (0, 100), "vix": (0.01, 200),
                      "gold": (-100, 100), "bond": (-100, 100)}[engine]
            valid = value is not None and bounds[0] <= value <= bounds[1]
            if engine == "aiae" and valid:
                valid = value.is_integer()
        status = "available" if valid else "missing" if raw is None else "invalid"
        if engine == "aiae" and valid and snapshot.get("decision_locked") is True:
            status = "unavailable"
        states[engine] = {"status": status, "value": value if valid else None,
                          "direction": None, "required": engine in CORE_ENGINES}
    return states


def sanitize_snapshot(snapshot):
    clean = dict(snapshot)
    for engine, state in signal_states(snapshot).items():
        clean[ENGINE_FIELDS[engine]] = state["value"] if state["status"] == "available" else None
    return clean


def macro_snapshot(snapshot):
    """JCS 口径的快照: 无效值置空; 观测时间待核验的读数与被移出的引擎一律置空 (不参与方向/距离分/冲突)。"""
    clean = sanitize_snapshot(snapshot)
    for engine in set(time_unverified_engines(snapshot)) | set(EXCLUDED_ENGINES):
        clean[ENGINE_FIELDS[engine]] = None
    return clean


def time_unverified_engines(snapshot, *, now_ts=None):
    """有数值、但来源观测时间无法核验的引擎 (仅在快照提供 source_provenance 时判定)。"""
    provenance = snapshot.get("source_provenance")
    if not isinstance(provenance, dict):
        return []
    now_ts = datetime.now(timezone.utc).timestamp() if now_ts is None else now_ts
    out = []
    for engine in ENGINE_FIELDS:
        source = provenance.get(engine) or {}
        age, basis = source_age(source.get("observed_at"), engine, now_ts)
        if age < 0 and basis != "observation_date":
            out.append(engine)
    return out


def coverage_for(snapshot, weights):
    states = signal_states(snapshot)
    unverified = set(time_unverified_engines(snapshot))
    # "有效数据" = 数值有效 且 观测时间可核验; 时间未知的读数可展示, 但不计入数据健康
    available = [key for key in weights if states[key]["status"] == "available" and key not in unverified]
    total = sum(weights.values())
    return {"available_count": len(available), "expected_count": len(weights),
            "available_weight_pct": round(100 * sum(weights[k] for k in available) / total, 2) if total else 0,
            "required_available": all(states[k]["status"] == "available" for k in CORE_ENGINES),
            "missing_engines": [key for key in weights if key not in available],
            "time_unverified_engines": [key for key in weights
                                        if key in unverified and states[key]["status"] == "available"],
            "weight_policy": "fixed_weights_no_renormalization"}


def source_age(observed_at, engine, now_ts):
    """Date-only observations retain day precision; future/invalid dates are unusable."""
    try:
        text = str(observed_at or "")
        if len(text) == 8 and text.isdigit():
            text = datetime.strptime(text, "%Y%m%d").date().isoformat()
        dt = datetime.fromisoformat(text.replace("Z", "+00:00"))
        zone = ZoneInfo("America/New_York" if engine in {"vix", "gold", "bond"} else "Asia/Shanghai")
        if len(text) == 10:
            days = (datetime.fromtimestamp(now_ts, zone).date() - dt.date()).days
            return (days * 1440, "observation_date") if days >= 0 else (-1, "future")
        # Naive timestamps carry no demonstrable timezone; do not guess.
        if dt.tzinfo is None:
            return -1, "unknown_timezone"
        age = now_ts - dt.timestamp()
        return (int(age / 60), "observation") if age >= 0 else (-1, "future")
    except (TypeError, ValueError, OverflowError, OSError):
        return -1, "unknown"


def missed_trading_days(observed_at, engine, now_ts):
    """日期型观测之后已发生、但数据里没有的收盘次数 (工作日近似, 未扣除法定节假日)。

    例: 周五收盘数据在周一盘中查看 → 0; 周一收盘后查看 → 1。
    返回 None 表示日期无效/未来/非日期精度。
    """
    try:
        text = str(observed_at or "")
        if len(text) == 8 and text.isdigit():
            text = datetime.strptime(text, "%Y%m%d").date().isoformat()
        if len(text) != 10:
            return None
        obs = datetime.fromisoformat(text).date()
        zone = ZoneInfo("America/New_York" if engine in {"vix", "gold", "bond"} else "Asia/Shanghai")
        now_local = datetime.fromtimestamp(now_ts, zone)
        today = now_local.date()
        if obs > today:
            return None
        missed, day = 0, obs
        from datetime import timedelta
        while True:
            day = day + timedelta(days=1)
            if day > today:
                break
            if day.weekday() >= 5:
                continue
            if day == today and now_local.hour < _CLOSE_HOUR.get(engine, 15):
                break
            missed += 1
        return missed
    except (TypeError, ValueError, OverflowError, OSError):
        return None


def build_signal_decay(snapshot, *, now_ts=None):
    now_ts = datetime.now(timezone.utc).timestamp() if now_ts is None else now_ts
    provenance = snapshot.get("source_provenance") or {}
    result = {}
    for engine, half_life in HALF_LIFE_HOURS.items():
        source = provenance.get(engine) or {}
        age, basis = source_age(source.get("observed_at"), engine, now_ts)
        precise = basis == "observation" and age >= 0
        trading_days = (missed_trading_days(source.get("observed_at"), engine, now_ts)
                        if basis == "observation_date" else None)
        # 统一的"信息年龄": 分钟精度用实际小时; 日期精度用错过的交易日 × 24h
        age_hours = (age / 60 if precise else
                     trading_days * 24.0 if trading_days is not None else None)
        result[engine] = {
            # age_min 只保留分钟精度; 日期型观测绝不伪装成"0 分钟前"
            "label": engine.upper(), "age_min": age if precise else -1, "age_basis": basis,
            "age_calendar_days": age // 1440 if basis == "observation_date" else None,
            "age_trading_days": trading_days,
            "age_hours": round(age_hours, 2) if age_hours is not None else None,
            "precision": "minute" if precise else "trading_day" if trading_days is not None else None,
            "observed_at": source.get("observed_at"), "received_at": source.get("received_at"),
            "half_life_hours": half_life, "is_probability": False,
            "reliability": round(0.5 ** (age_hours / half_life), 4) if age_hours is not None else None,
            "method": "heuristic_time_discount_not_predictive_accuracy",
            "calendar_basis": "weekdays_without_holiday_calendar" if trading_days is not None else None,
        }
    return result


# ═══════════════════════════════════════════════════════
#  数据新鲜度 (验收修补, 2026-10-29): 按来源发布周期判定, 不是"年龄可计算就 ok"
#  max_lag_trading_days = 允许落后的收盘次数 (工作日近似, 未扣法定节假日)。
#  取值依据来源类型的默认设定, 未逐一核对各来源的发布日历:
#    vix  美股日频收盘;  mr  A 股日频收盘;  erp  日频 (依赖国债收益率, 可能晚一日发布);
#    aiae 基金仓位等低频数据 (约月度, 含披露滞后)。
# ═══════════════════════════════════════════════════════
SOURCE_CADENCE = {
    "aiae": {"cycle": "低频 (基金仓位, 约月度含披露滞后)", "max_lag_trading_days": 30},
    "erp": {"cycle": "日频 (A 股收盘 + 国债收益率)", "max_lag_trading_days": 2},
    "vix": {"cycle": "日频 (美股收盘)", "max_lag_trading_days": 1},
    "mr": {"cycle": "日频 (A 股收盘)", "max_lag_trading_days": 1},
}
FRESHNESS_STATUSES = ("ok", "stale", "missing", "future", "unknown")


def _observation_local_date(observed_at, engine):
    text = str(observed_at or "")
    if len(text) == 8 and text.isdigit():
        return datetime.strptime(text, "%Y%m%d").date().isoformat()
    if len(text) == 10:
        return text
    dt = datetime.fromisoformat(text.replace("Z", "+00:00"))
    zone = ZoneInfo("America/New_York" if engine in {"vix", "gold", "bond"} else "Asia/Shanghai")
    return dt.astimezone(zone).date().isoformat()


def freshness_status(item, engine, *, now_ts):
    """→ (status, reason, trading_lag)。status ∈ FRESHNESS_STATUSES。"""
    cad = SOURCE_CADENCE.get(engine, {"max_lag_trading_days": 1})
    observed = item.get("observed_at")
    basis = item.get("age_basis")
    if observed in (None, ""):
        return "missing", "无观测时间", None
    if basis == "future":
        return "future", f"观测时间 {observed} 晚于当前", None
    if basis in ("unknown", "unknown_timezone"):
        return "unknown", "观测时间无法核验 (格式无效或无时区)", None
    lag = item.get("age_trading_days")
    if lag is None:
        try:
            lag = missed_trading_days(_observation_local_date(observed, engine), engine, now_ts)
        except (TypeError, ValueError, OverflowError):
            lag = None
    if lag is None:
        return "unknown", "无法计算落后的交易日数", None
    allowed = cad["max_lag_trading_days"]
    if lag <= allowed:
        return "ok", ("最新收盘" if lag == 0 else f"落后 {lag} 个交易日 (允许 {allowed})"), lag
    return "stale", f"落后 {lag} 个交易日, 超过允许的 {allowed} 个", lag


def build_freshness(decay, *, now_ts=None):
    now_ts = datetime.now(timezone.utc).timestamp() if now_ts is None else now_ts
    out = {}
    for key, item in decay.items():
        status, reason, lag = freshness_status(item, key, now_ts=now_ts)
        cad = SOURCE_CADENCE.get(key, {"cycle": None, "max_lag_trading_days": 1})
        out[key] = {"label": item["label"], "status": status, "status_reason": reason,
                    "age_min": item["age_min"], "age_trading_days": lag,
                    "data_date": item["observed_at"], "age_basis": item["age_basis"],
                    "cycle": cad["cycle"], "max_lag_trading_days": cad["max_lag_trading_days"],
                    "calendar_basis": "weekdays_without_holiday_calendar"}
    return out
