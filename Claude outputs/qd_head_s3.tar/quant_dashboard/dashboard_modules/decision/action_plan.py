"""
AlphaCore · 执行建议 & 警示生成器
====================================
从 decision_engine.py 拆分 (P2-A)

公开 API:
  - generate_action_plan(snapshot, execution, view) → dict   (AIAE 执行层; 不读 JCS)
  - generate_alerts(snapshot) → list
"""

from dashboard_modules.decision.conflicts import _signal_direction


def _position_from_valuation(val: dict) -> float:
    """Use one authoritative account valuation; unknown assets are never zero exposure."""
    import re
    from dashboard_modules.decision.quality import finite_number
    total = finite_number(val.get("total_asset"))
    market_value = finite_number(val.get("market_value"))
    if total is None or total <= 0 or market_value is None or market_value < 0:
        return -1
    repo_value = sum(
        finite_number(p.get("market_value")) or 0
        for p in val.get("positions", [])
        if (p.get("ts_code", "").split('.')[0][:3] in ('131', '204')
            or '逆回购' in p.get("name", "") or re.search(r'GC\d', p.get("name", "")))
    )
    if market_value < repo_value:
        return -1
    return round((market_value - repo_value) / total * 100, 1)


def _get_current_position() -> float:
    """仓位百分比，-1 表示账户敞口不可用。"""
    try:
        from portfolio_engine import get_portfolio_engine
        return _position_from_valuation(get_portfolio_engine().get_valuation())
    except Exception:
        return -1


def _apply_position_gap_note(base_note: str, target: float, current: float) -> str:
    """根据目标仓位与实际仓位的缺口, 在原始 risk_note 基础上追加缺口信息。
    D4修复: 不再替换原始 risk_note, 避免丢失 '严格止损' 等关键风控语义。"""
    if current < 0:
        return base_note
    gap = target - current
    gap_info = (f"模型参考{target:g}%，当前{current:g}%，差额{gap:+.1f}个百分点"
                "（仅用于核对，不构成调仓授权）")
    # 追加而非替换: 保留原始风控语义
    if base_note:
        return f"{base_note} | {gap_info}"
    return gap_info


_ZONE_DIRECTION = {"reduce": "decrease", "pause": "hold", "hold": "hold", "add": "hold"}
_ZONE_LABEL = {"reduce": "必须降仓", "pause": "暂停加仓", "hold": "维持", "add": "允许加仓 · 需策略信号确认"}
_CAP_STEPS = (("aiae", "AIAE 矩阵上限"), ("market", "市场尾部刹车后"), ("portfolio", "组合波动预算"),
              ("drawdown", "组合回撤刹车"))


def _constraints_from_view(view: dict) -> list:
    """上限瀑布 → 约束列表 (只作为执行目标的原因说明, 不是第二个仓位数字)。"""
    from dashboard_modules.decision.quality import finite_number
    steps = {s.get("key"): s for s in (view or {}).get("waterfall") or [] if isinstance(s, dict)}
    out = []
    for key, label in _CAP_STEPS:
        step = steps.get(key)
        value = finite_number((step or {}).get("value"))
        if value is None:
            continue
        out.append({"key": key, "label": label, "value": round(value, 1), "note": (step or {}).get("note"),
                    **({"asof": step["asof"]} if (step or {}).get("asof") else {})})
    if out:
        tightest = min(item["value"] for item in out)
        for item in out:
            item["binding"] = item["value"] == tightest
    return out


def generate_action_plan(snapshot: dict, execution: dict, view: dict = None) -> dict:
    """
    执行候选 = AIAE 执行层 (docs/AIAE_EXECUTION_RULES.md) 的结果。不读取 JCS。

    唯一仓位数字是执行目标 T (有效上限 = AIAE ∧ 市场尾部刹车 ∧ 组合波动预算 ∧ 回撤刹车, 周频评估,
    风险事件当日只向下)。其他上限只作为原因说明 (constraints)。

    返回: action_label / zone / execution_target / current_position / execution_gap /
          reasoning / next_check / constraints / direction (供风控上下文) / execution_status
    """
    from dashboard_modules.decision.quality import finite_number
    execution = execution if isinstance(execution, dict) else {}
    current = finite_number(snapshot.get("current_position"))
    if current is not None and current < 0:
        current = None
    constraints = _constraints_from_view(view or {})
    if execution.get("status") != "ok" or finite_number(execution.get("target_pct")) is None:
        reason = execution.get("reason") or "AIAE 执行层不可用"
        return {"action_label": "执行目标不可用", "zone": None, "execution_status": execution.get("status") or "unavailable",
                "execution_target": None, "effective_cap": None, "current_position": current,
                "execution_gap": None, "reasoning": reason, "next_check": "执行层恢复后重新核验",
                "constraints": constraints, "direction": "unknown", "top_signals": []}
    target = round(float(execution["target_pct"]), 1)
    actual = finite_number(execution.get("actual_pct"))
    current = actual if actual is not None else current
    gap = round(current - target, 1) if current is not None else None
    zone = execution.get("zone")
    next_eval = execution.get("next_eval_date")
    return {
        "action_label": _ZONE_LABEL.get(zone, "执行目标待核验"),
        "zone": zone, "zone_label": execution.get("zone_label"),
        "execution_status": "ok",
        "execution_target": target,
        "effective_cap": finite_number(execution.get("effective_cap_pct")),
        "current_position": current,
        "execution_gap": gap,
        "reasoning": execution.get("instruction") or "",
        # 2026-11-02 首页口径统一 A2: 执行层原文与节奏单独保留 (reasoning 会被最终结论覆盖), 首页直接引用, 不另算
        "execution_instruction": execution.get("instruction") or "",
        "reduce_days": execution.get("reduce_days"),
        "next_check": f"下次例行评估 {next_eval}；风险事件当日只向下调整" if next_eval else "数据或持仓更新后重新核验",
        "next_eval_date": next_eval,
        "trigger": execution.get("trigger"),
        "risk_events": execution.get("risk_events") or [],
        "constraints": constraints,
        "direction": _ZONE_DIRECTION.get(zone, "unknown"),
        "top_signals": [],
    }


def generate_alerts(snapshot: dict) -> list:
    """
    扫描快照，生成市场警报列表。
    只在极端或异常条件下触发，正常市场不产生警报。

    返回: [{type, severity, icon, title, detail, rule}]
    severity: critical / warning / caution
    """
    alerts = []
    vix = snapshot.get("vix_val") or 20
    aiae_regime = snapshot.get("aiae_regime") or 3
    directions = _signal_direction(snapshot)
    degraded = snapshot.get("degraded_modules", [])
    if isinstance(degraded, str):
        degraded = [d.strip() for d in degraded.split(",") if d.strip()]

    # 1. VIX 极端恐慌
    if vix >= 35:
        alerts.append({
            "type": "vix_extreme",
            "severity": "critical",
            "icon": "🚨",
            "title": f"VIX 极端恐慌 ({vix:.1f})",
            "detail": "全球恐慌指数超过 35，触发全策略风控降权",
            "rule": "合规「VIX 紧急刹车」：禁止加仓；仓位以 AIAE 执行目标为准",
        })

    # 2. 流动性熔断
    if snapshot.get("is_circuit_breaker"):
        alerts.append({
            "type": "circuit_breaker",
            "severity": "critical",
            "icon": "🛑",
            "title": "流动性熔断触发",
            "detail": "个股跌停占比超限，市场流动性极度恶化",
            "rule": "流动性异常（背景读数）；仓位以 AIAE 执行目标为准，风险以合规结论为准",
        })

    # 3. 多引擎共振看空 (≥3 个引擎 -1)
    bear_count = sum(1 for d in directions.values() if d == -1)
    if bear_count >= 3:
        bear_names = [k.upper() for k, v in directions.items() if v == -1]
        alerts.append({
            "type": "multi_bear",
            "severity": "warning",
            "icon": "⚠️",
            "title": f"{bear_count} 引擎共振看空",
            "detail": f"{', '.join(bear_names)} 同时发出看空信号",
            "rule": "引擎方向为背景读数，不作执行依据；仓位以 AIAE 执行目标为准，止损以「持仓跟踪止盈」为准",
        })

    # 4. 数据降级警告
    if len(degraded) >= 2:
        alerts.append({
            "type": "data_degraded",
            "severity": "caution",
            "icon": "⚡",
            "title": f"{len(degraded)} 个模块数据降级",
            "detail": f"{', '.join(degraded)} 数据过期，宏观环境读数 (JCS) 可能偏离",
            "rule": "JCS 只作宏观背景，不影响执行目标；等待数据恢复后再参考",
        })

    # 5. AIAE 极度过热
    if aiae_regime >= 5:
        alerts.append({
            "type": "aiae_overheat",
            "severity": "warning",
            "icon": "🔥",
            "title": "市场极度过热 (Ⅴ级)",
            "detail": "AIAE 配置热度达到极端，历史回撤概率最高",
            "rule": "合规「AIAE 过热限制」：禁止建仓；仓位以 AIAE 执行目标为准",
        })

    return alerts
