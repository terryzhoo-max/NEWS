"""
AlphaCore · 快照构建器
========================
从 decision_engine.py 拆分 (P2-A)

核心基础设施: 从缓存组装系统快照，供所有决策模块使用。

公开 API:
  - _parse_erp_value(raw) → float
  - _build_snapshot_from_cache() → dict
"""

import time
from dashboard_modules.decision.quality import finite_number

from services.logger import get_logger
from services.health_status import evaluate_aiae_context

logger = get_logger("ac.decision.snapshot")


def _parse_erp_value(raw) -> float:
    """安全解析 ERP 值: '4.5%' → 4.5, 4.5 → 4.5, None → 4.5"""
    if raw is None:
        return 4.5
    if isinstance(raw, (int, float)):
        return float(raw)
    try:
        return float(str(raw).replace('%', '').strip())
    except (ValueError, TypeError):
        return 4.5


def _build_snapshot_from_cache() -> dict:
    """
    V17.1: 从缓存组装当前系统快照 (不调引擎, 纯读取)

    缓存结构 (由 assemble_response.py 写入):
      data.macro_cards.vix.value          → vix_val (float)
      data.macro_cards.erp.value          → erp_val (字符串 '4.5%', 需解析)
      data.macro_cards.market_temp.hub_factors.{key}.score  → 各因子得分
      data.macro_cards.market_temp.hub_composite             → 综合得分
      data.macro_cards.regime_banner.aiae_cap                → 建议仓位
      data.macro_cards.market_temp.degraded_modules          → 降级模块
    """
    from services.cache_service import cache_manager

    snapshot = {}

    # Dashboard 数据 (V17.1: 修正读取路径, 从 macro_cards.market_temp 读取)
    dashboard = cache_manager.get_json("dashboard_data")
    if dashboard and dashboard.get("data"):
        d = dashboard["data"]
        macro = d.get("macro_cards", {})
        market_temp = macro.get("market_temp", {})
        regime_banner = macro.get("regime_banner", {})

        # VIX — 从 macro_cards.vix.value 读取 (float)
        snapshot["vix_val"] = macro.get("vix", {}).get("value")

        # ERP — value 是字符串 "4.5%", 需解析为浮点数
        erp_raw = macro.get("erp", {}).get("value")
        snapshot["erp_val"] = finite_number(str(erp_raw).replace('%', '').strip())

        # Hub 因子得分 — 从 market_temp.hub_factors 读取
        hub_factors = market_temp.get("hub_factors", {})
        snapshot["erp_score"] = hub_factors.get("erp_value", {}).get("score")
        snapshot["vix_score"] = hub_factors.get("vix_fear", {}).get("score", 50)
        snapshot["liquidity_score"] = hub_factors.get("capital_flow", {}).get("score", 50)
        snapshot["macro_temp_score"] = hub_factors.get("macro_temp", {}).get("score", 50)

        # Hub composite + position
        snapshot["hub_composite"] = market_temp.get("hub_composite", 50)
        snapshot["suggested_position"] = regime_banner.get("aiae_cap")

        # 降级模块
        snapshot["degraded_modules"] = market_temp.get("degraded_modules", [])

        # V17.1: 快照完整性日志
        _real_count = sum(1 for k in ["erp_score", "vix_score", "hub_composite"]
                         if snapshot.get(k) != 50)
        _is_cold = _real_count == 0 and not hub_factors
        if _is_cold:
            logger.warning("快照警告: hub_factors 为空, 可能缓存未预热")
        else:
            logger.debug("快照组装: erp=%.1f vix_s=%.1f comp=%.1f pos=%s",
                         snapshot.get("erp_score") or 0, snapshot.get("vix_score", 0),
                         snapshot.get("hub_composite", 0), snapshot.get("suggested_position"))

        # V20.0: 数据质量透传 — 前端据此决定是否显示冷启动提示
        snapshot["_data_quality"] = {
            "real_sources": _real_count,
            "total_expected": 4,
            "is_cold_start": _is_cold,
        }

    # AIAE 上下文 (V17.5: 扩展完整字段供仪表卡片使用)
    aiae_ctx = cache_manager.get_json("aiae_ctx")
    # Fail closed even when the cache is missing or still uses the legacy schema.
    snapshot["data_quality_score"] = 0
    snapshot["decision_locked"] = True
    snapshot["aiae_fresh"] = False
    snapshot["aiae_age_sec"] = None
    snapshot["aiae_unusable_reason"] = "missing"
    if aiae_ctx:
        snapshot["aiae_regime"] = aiae_ctx.get("regime")
        snapshot["aiae_v1"] = aiae_ctx.get("aiae_v1")
        snapshot["aiae_regime_cn"] = aiae_ctx.get("regime_cn", "中性均衡")
        snapshot["aiae_cap"] = aiae_ctx.get("cap")
        snapshot["aiae_slope"] = aiae_ctx.get("slope", 0)
        snapshot["aiae_slope_dir"] = aiae_ctx.get("slope_direction", "flat")
        # 2026-11-03 (1c 提交 B): 缺数据为 None, 不再用 2.0 / 80 顶替 (只用于展示与日报文字, 不参与判定)
        # 引擎降级 (融资余额 / 市值用缺省值) 时同样不显示: 缺省算出的 2.0 左右与真实值无法区分
        snapshot["margin_heat_fallback"] = bool(aiae_ctx.get("margin_heat_fallback"))
        snapshot["margin_heat"] = None if snapshot["margin_heat_fallback"] else aiae_ctx.get("margin_heat")
        snapshot["margin_heat_date"] = aiae_ctx.get("margin_heat_date")
        snapshot["fund_position"] = aiae_ctx.get("fund_position")
        # C1 Fix: 数据质量评分与决策锁定字段 (机构级合规透传)
        aiae_state = evaluate_aiae_context(aiae_ctx, now_ts=time.time())
        snapshot["data_quality_score"] = aiae_state["data_quality_score"]
        snapshot["decision_locked"] = not aiae_state["usable"]
        snapshot["aiae_fresh"] = aiae_state["fresh"]
        snapshot["aiae_age_sec"] = aiae_state["age_sec"]
        snapshot["aiae_unusable_reason"] = aiae_state["reason"]
        snapshot["aiae_updated_at"] = aiae_ctx.get("updated_at") or aiae_ctx.get("ts")
        snapshot["fund_position_source"] = aiae_ctx.get("fund_position_source", "manual_update")
        snapshot["fund_position_date"] = aiae_ctx.get("fund_position_date", "")
        # V5 dynamic metadata
        snapshot["regime_basis_value"] = aiae_ctx.get("regime_basis_value", aiae_ctx.get("aiae_v1", 22.0))
        snapshot["regime_thresholds"] = aiae_ctx.get("regime_thresholds", [])
        snapshot["regime_mode"] = aiae_ctx.get("regime_mode", "V3_composite")

    # 策略结果
    strategy_results = cache_manager.get_json("strategy_results") or {}
    mr_data = strategy_results.get("mr", {})
    if isinstance(mr_data, dict):
        mr_ov = mr_data.get("data", {}).get("market_overview", {})
        mr_regime = mr_ov.get("regime") if mr_ov else None
    else:
        mr_ov = {}
        mr_regime = None
    snapshot["mr_regime"] = mr_regime

    # V25.3 P3-B: 黄金信号 (从 SWR 缓存读取)
    from datetime import datetime, timezone
    from engines.multi_asset_engine import read_rates_signal
    from services.multi_asset_policy import MAX_RATES_CACHE_AGE_SEC
    from services.source_freshness import gold_result_is_usable
    from services.health_status import _timestamp_age_seconds
    now = datetime.now(timezone.utc)
    gold_envelope = cache_manager.get_json("swr_gold_signal") or {}
    gold_data = gold_envelope.get("data", {}) if isinstance(gold_envelope, dict) else {}
    gold_age = (_timestamp_age_seconds(gold_envelope.get("timestamp"), now.timestamp())
                if isinstance(gold_envelope, dict) else None)
    if (gold_age is not None and gold_age <= MAX_RATES_CACHE_AGE_SEC
            and gold_result_is_usable(gold_data, now=now)):
        snapshot["gold_signal"] = gold_data["gold_signal"]
        snapshot["gold_direction"] = gold_data.get("gold_direction", "neutral")
    else:
        snapshot["gold_signal"] = None
        snapshot["gold_direction"] = None

    # V25.3 P3-B: 国债信号 (从利率引擎缓存读取)
    rates_data = read_rates_signal(cache_manager.get_json("swr_rates"), now=now)
    if rates_data["status"] == "ok":
        from services.multi_asset_policy import signal_direction
        snapshot["bond_signal"] = rates_data["signal"]
        snapshot["bond_direction"] = signal_direction(rates_data["signal"])
    else:
        snapshot["bond_signal"] = None
        snapshot["bond_direction"] = None

    # Per-source provenance: a refresh timestamp is never substituted for the
    # date/time of the underlying observation. Missing dates remain explicit.
    macro = (dashboard or {}).get("data", {}).get("macro_cards", {})
    vix_card = macro.get("vix") or {}
    erp_data = strategy_results.get("erp_timing") or {}
    if isinstance(erp_data, dict):
        erp_data = erp_data.get("data", erp_data)
    erp_current = erp_data.get("current_snapshot", {}) if isinstance(erp_data, dict) else {}
    aiae_ctx = aiae_ctx or {}
    snapshot["source_provenance"] = {
        "aiae": {"observed_at": aiae_ctx.get("fund_position_date") or aiae_ctx.get("trade_date") or aiae_ctx.get("date"),
                 "received_at": aiae_ctx.get("updated_at") or aiae_ctx.get("ts")},
        # erp_score 来自 hub_factors.erp_value, 观测日期必须取同一来源;
        # strategy_results 中并没有 erp_timing 键 (旧路径永远为空), 仅作兼容回退。
        "erp": {"observed_at": (((macro.get("market_temp") or {}).get("hub_factors") or {})
                                .get("erp_value") or {}).get("data_as_of") or erp_current.get("trade_date"),
                "received_at": (dashboard or {}).get("timestamp")
                               or (erp_data.get("updated_at") if isinstance(erp_data, dict) else None)},
        "vix": {"observed_at": vix_card.get("data_as_of") or vix_card.get("trade_date") or vix_card.get("as_of"),
                "received_at": vix_card.get("updated_at")},
        "mr": {"observed_at": mr_ov.get("trade_date") or mr_ov.get("data_as_of"),
               "received_at": mr_data.get("updated_at") if isinstance(mr_data, dict) else None},
        "gold": {"observed_at": gold_data.get("data_as_of"), "received_at": gold_envelope.get("timestamp")},
        "bond": {"observed_at": rates_data.get("data_as_of"), "received_at": None},
    }
    return snapshot
