"""
AlphaCore · 信号矛盾检测器 + 方向解析
=======================================
从 decision_engine.py 拆分 (P2-A)

公开 API:
  - _signal_direction(snapshot) → {engine: direction}
  - compute_conflict_matrix(snapshot) → {conflicts, count, severity}
"""


# 2026-11-01: 美债信号在 JCS 中固定为中性 (键与权重保留, 不改分数结构)。
#   ① 样本外验证未通过 (docs/RATES_V2_VALIDATION_RESULTS.md, 结论 DEMOTE);
#   ② 语义不符: "美债有吸引力"≠"A股看多", 避险期两者常反向;
#   ③ 5% 权重的方向分歧会把 base_agreement 从"全一致"分支打到"混合"分支 (≤30 分), 足以触发多资产 JCS<40 闸门。
#   若日后有新的美债信号通过预注册验证, 且论证了与 A 股方向的关系, 再改回 True。
BOND_DIRECTION_ENABLED = False
BOND_NEUTRAL_REASON = "利率信号样本外验证未通过，且美债吸引力不等于 A 股看多，JCS 中固定为中性"


def _signal_direction(snapshot: dict) -> dict:
    """将各引擎状态映射为方向: +1(看多), 0(中性), -1(看空)
    
    V25.3: 扩展至 6 维 (原4 + gold + bond)
    gold/bond 使用 composite signal 分值映射:
      signal > 25 → +1, signal < -25 → -1, else → 0
    """
    aiae_r = snapshot.get("aiae_regime") or 3        # None → 中性
    erp_s = snapshot.get("erp_score") if snapshot.get("erp_score") is not None else 50
    vix_v = snapshot.get("vix_val") or 20            # None → 中性
    mr_r = snapshot.get("mr_regime") or "RANGE"      # None → 中性

    # 新增: 多资产信号
    gold_sig = snapshot.get("gold_signal")           # [-100, 100] or None
    bond_sig = snapshot.get("bond_signal") if BOND_DIRECTION_ENABLED else None  # 2026-11-01 中性化

    return {
        "aiae": 1 if aiae_r <= 2 else (-1 if aiae_r >= 4 else 0),
        "erp": 1 if erp_s > 55 else (-1 if erp_s < 35 else 0),  # V19.1: 拓宽 (60/40→55/35, A股ERP分布校准)
        "vix": 1 if vix_v < 16 else (-1 if vix_v > 25 else 0),  # P1: 收窄阈值 (A股实证校准)
        "mr": 1 if mr_r == "BULL" else (-1 if mr_r in ("BEAR", "CRASH") else 0),
        # V25.3: 多资产维度 (None → 0 中性, 不影响旧逻辑)
        "gold": (1 if gold_sig > 25 else (-1 if gold_sig < -25 else 0)) if gold_sig is not None else 0,
        "bond": (1 if bond_sig > 25 else (-1 if bond_sig < -25 else 0)) if bond_sig is not None else 0,
    }


def _signal_conviction(snapshot: dict) -> dict:
    """各引擎 → [-1.0, +1.0] 连续信念度 (V26 Signal Conviction Model)

    与 _signal_direction() 的三值化 {-1,0,+1} 不同，连续信念度保留信号强度:
      ±1.0: 极度看多/看空 (引擎读数触及极端区)
      ±0.5: 中度看多/看空
       0.0: 中性 (引擎无方向信号)

    映射原则:
      AIAE:  R1→+1.0 ... R3→0 ... R5→-1.0 (线性, 步长0.5)
      ERP:   score→线性, 中心50, 半宽25 (0→-1, 50→0, 100→+1)
      VIX:   反向线性, 中心20, 半宽10 (10→+1, 20→0, 30→-1)
      MR:    离散 {BULL:+0.8, RANGE:0, BEAR:-0.7, CRASH:-1.0}
      Gold/Bond: 连续信号/50, clamp ±1
    """
    aiae_r = snapshot.get("aiae_regime") if snapshot.get("aiae_regime") is not None else 3
    erp_s  = snapshot.get("erp_score") if snapshot.get("erp_score") is not None else 50
    vix_v  = snapshot.get("vix_val") if snapshot.get("vix_val") is not None else 20
    mr_r   = snapshot.get("mr_regime") or "RANGE"
    gold_sig = snapshot.get("gold_signal")
    bond_sig = snapshot.get("bond_signal") if BOND_DIRECTION_ENABLED else None  # 2026-11-01 中性化

    # AIAE: R1(极冷)=+1, R2=+0.5, R3(中性)=0, R4=-0.5, R5(极热)=-1
    aiae_conv = max(-1.0, min(1.0, (3 - aiae_r) / 2.0))

    # ERP: score 50=中性, >75=强看多, <25=强看空
    erp_conv = max(-1.0, min(1.0, (erp_s - 50) / 25.0))

    # VIX: 20=中性, <10=强看多(无恐慌), >30=强看空(恐慌)
    vix_conv = max(-1.0, min(1.0, (20 - vix_v) / 10.0))

    # MR: 离散→信念度 (BULL 不给满+1, 技术面信号可靠度略低于基本面)
    _mr_map = {"BULL": 0.8, "RANGE": 0.0, "BEAR": -0.7, "CRASH": -1.0}
    mr_conv = _mr_map.get(mr_r, 0.0)

    # Gold/Bond: 连续信号映射 (None → 0 中性, 不干扰核心逻辑)
    gold_conv = max(-1.0, min(1.0, gold_sig / 50.0)) if gold_sig is not None else 0.0
    bond_conv = max(-1.0, min(1.0, bond_sig / 50.0)) if bond_sig is not None else 0.0

    return {
        "aiae": round(aiae_conv, 3),
        "erp":  round(erp_conv, 3),
        "vix":  round(vix_conv, 3),
        "mr":   round(mr_conv, 3),
        "gold": round(gold_conv, 3),
        "bond": round(bond_conv, 3),
    }


def _num(s, key):
    """读数缺失/待核验 (None) 时返回 None: 规则不触发, 不用默认值冒充中性。"""
    v = s.get(key)
    return v if isinstance(v, (int, float)) and not isinstance(v, bool) else None


def _lt(s, key, x):
    v = _num(s, key)
    return v is not None and v < x


def _gt(s, key, x):
    v = _num(s, key)
    return v is not None and v > x


def _ge(s, key, x):
    v = _num(s, key)
    return v is not None and v >= x


def _le(s, key, x):
    v = _num(s, key)
    return v is not None and v <= x


# 宏观因子冲突规则: (因子A条件, 因子B条件, 严重度, 描述, 解读)
# 2026-11-01 JCS 定位为宏观环境读数: 只描述因子之间的分歧, 不给操作建议;
# 涉及 MR (策略信号) 的两条规则已移出 (mr_crash_vs_erp / mr_bull_vs_aiae_hot)。
_CONFLICT_RULES = [
    {
        "id": "aiae_vs_erp_bull",
        "a_check": lambda s: _ge(s, "aiae_regime", 4),
        "b_check": lambda s: _gt(s, "erp_score", 65),
        "severity": "medium",
        "desc": "AIAE 配置偏热 × ERP 估值偏低",
        "action": "资金配置热度与估值吸引力方向相反，宏观信号分歧",
    },
    {
        "id": "aiae_vs_erp_bear",
        "a_check": lambda s: _le(s, "aiae_regime", 2),
        "b_check": lambda s: _lt(s, "erp_score", 35),
        "severity": "medium",
        "desc": "AIAE 配置偏冷 × ERP 估值偏高",
        "action": "配置低迷但估值不便宜，宏观信号分歧",
    },
    {
        "id": "vix_vs_aiae_cold",
        "a_check": lambda s: _ge(s, "vix_val", 30),
        "b_check": lambda s: _le(s, "aiae_regime", 2),
        "severity": "high",
        "desc": "VIX 恐慌 × AIAE 配置偏冷",
        "action": "外部恐慌与本土低配置同时出现，波动环境偏不稳定",
    },
    {
        "id": "vix_vs_erp_bull",
        "a_check": lambda s: _ge(s, "vix_val", 35),
        "b_check": lambda s: _gt(s, "erp_score", 70),
        "severity": "high",
        "desc": "VIX 极端恐慌 × ERP 极度低估",
        "action": "估值处于低位但波动极端，环境不确定性高",
    },
    {
        "id": "all_neutral",
        "a_check": lambda s: all(v == 0 for k, v in _signal_direction(s).items()
                                 if k in ("aiae", "erp", "vix", "gold")),
        "b_check": lambda s: True,
        "severity": "info",
        "desc": "宏观因子均处于中性区间",
        "action": "宏观环境无明确方向",
    },
]


def compute_conflict_matrix(snapshot: dict) -> dict:
    """
    扫描宏观因子冲突规则，返回:
    {
        "conflicts": [{id, severity, desc, action}],
        "conflict_count": int,
        "has_severe": bool,
        "matrix_summary": str
    }
    """
    conflicts = []
    for rule in _CONFLICT_RULES:
        try:
            if rule["a_check"](snapshot) and rule["b_check"](snapshot):
                conflicts.append({
                    "id": rule["id"],
                    "severity": rule["severity"],
                    "desc": rule["desc"],
                    "action": rule["action"],
                })
        except Exception:
            continue

    # V19.3: 排除 info 级别 (如 all_neutral) — 不计入冲突计数和前端 warn 状态
    actionable = [c for c in conflicts if c["severity"] != "info"]
    has_severe = any(c["severity"] == "high" for c in actionable)
    count = len(actionable)

    if count == 0:
        summary = "已到位因子未检出冲突；不代表形成方向共识"
    elif has_severe:
        summary = f"检测到 {count} 个宏观因子冲突（含严重）"
    else:
        summary = f"检测到 {count} 个宏观因子中度冲突"

    return {
        "conflicts": conflicts,
        "conflict_count": count,
        "has_severe": has_severe,
        "matrix_summary": summary,
    }
