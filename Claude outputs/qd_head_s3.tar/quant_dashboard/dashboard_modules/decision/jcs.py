"""
AlphaCore · 宏观环境读数 (JCS) — V26.0 宏观四因子
=====================================================
定位 (2026-11-01 用户确认): JCS = 宏观环境读数。
  - 只描述宏观因子是否方向清晰、数据是否完整; 不输出仓位、不涉及下单权限、不使用操作语言。
  - 执行区 (AIAE 执行目标 / 风控) 不得引用 JCS 分数或等级。
  - 分数不是概率, 也不是方向: 一致看多和一致看空都可以得高分。

公开 API:
  - compute_jcs(snapshot) → {score, level, label, directions, ...}
  - _JCS_WEIGHTS: dict  (宏观 4 因子权重, 合计 1.0)

V26.0 变更 (2026-11-01):
  - MR 移出 (策略信号, 不属宏观环境); BOND 移出 (已降级为背景, 方向本就固定中性)。
  - 剩余因子按 V25.3 原权重等比例归一 (不重新拍权重): AIAE/ERP/VIX/GOLD = .325/.225/.175/.05 ÷ .775。
    "缺失数据不重新分配"的规则不变 —— 这里是结构性移出, 不是数据缺失。
  - 观测时间待核验的因子 (如 VIX 无观测日期) 一律按"未知": 不计方向、不给距离分、不进冲突规则、不计数据健康。
  - 公式结构不变 (基础一致性 60 + 数据健康 20 + 核心共识 20 − 冲突扣分); "全一致"按参与因子数等比例计分。
"""

from dashboard_modules.decision.conflicts import (
    _signal_direction, _signal_conviction, compute_conflict_matrix,
)
from dashboard_modules.decision.quality import (
    coverage_for, signal_states, macro_snapshot, time_unverified_engines, EXCLUDED_ENGINES,
)
from services.jcs_validation import MODEL_VERSION

# V25.3 原始权重 (6 维), 仅作溯源与旧版影子对照
_JCS_WEIGHTS_V25 = {"aiae": 0.325, "erp": 0.225, "vix": 0.175, "mr": 0.175, "gold": 0.05, "bond": 0.05}

# V26.0: 宏观 4 因子, 由 V25.3 等比例归一 (MR/BOND 移出)
_MACRO_KEYS = ("aiae", "erp", "vix", "gold")
_JCS_WEIGHTS = {k: _JCS_WEIGHTS_V25[k] / sum(_JCS_WEIGHTS_V25[x] for x in _MACRO_KEYS) for k in _MACRO_KEYS}

# P2 安全校验: 权重总和必须为 1.0 (防止未来修改时漂移)
assert abs(sum(_JCS_WEIGHTS.values()) - 1.0) < 1e-9, \
    f"JCS 权重总和偏离 1.0: {sum(_JCS_WEIGHTS.values()):.4f}"

# 影子对照: 旧 4 维权重 (含 MR, 仅记录, 不参与任何决策)
_JCS_WEIGHTS_V4 = {
    "aiae": 0.35,
    "erp": 0.25,
    "vix": 0.20,
    "mr": 0.20,
}

# 本版本起算日: 历史 JCS 序列在此断点 (旧版含 MR/BOND, 口径不同), 趋势类统计只用此日之后的记录
MODEL_EPOCH = "2026-11-02"

# 宏观核心因子 (共识加成只看这些; gold 为软信号)
_CORE_CANDIDATES = ("aiae", "erp", "vix", "mr")

# 分级: 描述宏观信号的清晰程度, 不是强弱/多空, 也不是操作建议
_LEVEL_LABELS = {
    "high": ("清晰", "宏观信号清晰：因子方向一致、数据完整"),
    "medium": ("一般", "宏观信号一般：部分因子有方向，或存在分歧"),
    "low": ("模糊", "宏观信号模糊：因子分歧、方向不足或数据不全"),
}

# AIAE Regime → Cap 映射
try:
    import aiae_params as AP
    _is_v5 = getattr(AP, 'V5_ENABLED', False)
    _PM = AP.V5_POSITION_MATRIX if _is_v5 else AP.POSITION_MATRIX
    _REGIME_CAP_MAP = {i+1: _PM["erp_2_4"][i] for i in range(5)}
except Exception:
    _REGIME_CAP_MAP = {1: 85, 2: 70, 3: 50, 4: 25, 5: 5}

_REGIME_CN_MAP = {1: "极度恐慌", 2: "低配置区", 3: "中性均衡", 4: "偏热区域", 5: "极度过热"}


def _recalc_vix_score(vix_val: float) -> float:
    """VIX → 归一化分数 (0-100, 越低越好)"""
    return max(0, min(100, (40 - vix_val) / 40 * 100))


def _recalc_hub_composite(snapshot: dict) -> float:
    """根据 snapshot 各读数重新计算 Hub 复合分"""
    aiae_r = snapshot.get("aiae_regime", 3)
    erp_s = snapshot.get("erp_score", 50)
    vix_v = snapshot.get("vix_val", 20)
    vix_s = _recalc_vix_score(vix_v)

    aiae_score = max(0, min(100, (5 - aiae_r) / 4 * 100))
    return round(aiae_score * 0.4 + erp_s * 0.3 + vix_s * 0.3, 1)


def _level_of(score: float) -> tuple:
    level = "high" if score >= 70 else "medium" if score >= 40 else "low"
    return level, _LEVEL_LABELS[level][1]


def _compute_jcs_with_weights(snapshot: dict, weights: dict, n_core: int = None,
                              unverified=(), original: dict = None) -> dict:
    """
    JCS 计算核心 (可配权重版本, 供正式/影子模式复用)

    Args:
        snapshot: 已按 JCS 口径清洗的快照 (未知/待核验因子为 None)
        weights: 因子权重字典
        n_core: "全一致"满分对应的因子数; 默认 = 参与计权的因子数
        unverified: 观测时间待核验的因子, 视为未知 (不计方向、不给距离分)
        original: 未清洗的原始快照 (用于数据健康/覆盖率的来源时间判定); 缺省用 snapshot
    """
    unverified = set(unverified or ())
    n_core = n_core or len(weights)
    directions = _signal_direction(snapshot)
    directions = {k: (0 if k in unverified else directions.get(k, 0)) for k in weights}

    dir_vals = [directions[k] for k in weights]

    # ── 1. Base Agreement (占 60 分) ──
    active_count = sum(1 for d in dir_vals if d != 0)
    active_dirs = [d for d in dir_vals if d != 0]

    if active_count == 0:
        base_agreement = 30.0
    elif all(d == active_dirs[0] for d in active_dirs):
        # 全一致按参与因子数等比例计分 (全部有方向且一致 = 60)
        base_agreement = 30.0 + active_count * (30.0 / n_core)
    else:
        weighted_sum = sum(directions[k] * weights[k] for k in weights)
        max_weight = sum(weights.values())
        agreement_ratio = abs(weighted_sum) / max_weight if max_weight > 0 else 0
        base_agreement = 10.0 + agreement_ratio * 20.0

    # V19.1: 中性距离加分 (待核验/缺失的读数不给分)
    distance_bonus = 0.0
    vix_v = snapshot.get("vix_val")
    if "vix" in weights and "vix" not in unverified and directions.get("vix", 0) == 0 and vix_v is not None:
        distance_bonus += max(0, (25 - vix_v) / 25) * 2.5
    erp_s = snapshot.get("erp_score")
    if "erp" in weights and "erp" not in unverified and directions.get("erp", 0) == 0 and erp_s is not None:
        distance_bonus += abs(erp_s - 50) / 50 * 2.5
    base_agreement += min(distance_bonus, 5.0)

    # ── 2. Data Health (占 20 分) ──
    coverage = coverage_for(original if original is not None else snapshot, weights)

    degraded = snapshot.get("degraded_modules") or []
    if isinstance(degraded, str):
        degraded = [d.strip() for d in degraded.split(",") if d.strip()]
    degraded_count = len(degraded)

    data_health = max(0.0, 20.0 * coverage["available_weight_pct"] / 100 - degraded_count * 2.0)

    # ── 3. Consensus Bonus (占 20 分) ──
    # 只看核心因子 (gold 为软信号); 全部核心因子有方向且一致 = 20, 否则按 5 分/因子 (≥2 个且一致)
    core = [k for k in _CORE_CANDIDATES if k in weights]
    core_active = [directions[k] for k in core if directions[k] != 0]
    core_active_count = len(core_active)

    if core_active_count == len(core) and core and all(d == core_active[0] for d in core_active):
        consensus_bonus = 20.0
    elif core_active_count >= 2 and all(d == core_active[0] for d in core_active):
        consensus_bonus = core_active_count * 5.0
    else:
        consensus_bonus = 0.0

    # ── 合成 ──
    raw_jcs = base_agreement + data_health + consensus_bonus

    # 冲突扣分 (冲突规则只读已清洗的宏观读数)
    conflicts = compute_conflict_matrix(snapshot)
    penalty_count = conflicts["conflict_count"]
    has_severe = conflicts["has_severe"]

    conflict_penalty = 25.0 if has_severe else penalty_count * 10.0
    raw_jcs -= conflict_penalty

    jcs = round(min(100, max(0, raw_jcs)), 1)
    level, label = _level_of(jcs)

    return {
        "score": jcs,
        "level": level,
        "level_label": _LEVEL_LABELS[level][0],
        "label": label,
        "directions": directions,
        "agreement_pct": min(100.0, round(base_agreement / 60.0 * 100, 1)),
        "data_health": round(data_health, 1),
        "consensus_bonus": round(consensus_bonus, 1),
        "conflict_count": conflicts["conflict_count"],
        "coverage": coverage,
        "components": {"base_agreement": base_agreement, "data_health": data_health,
                       "consensus_bonus": consensus_bonus, "conflict_penalty": conflict_penalty},
    }


def _compute_jcs_v26(snapshot: dict, weights: dict) -> dict:
    """
    V26 Signal Conviction Model — 连续信念度 + 矛盾衰减

    JCS = conviction_score × conflict_decay + data_health

    conviction_score (0-80):
      基准 40 分 (全中性时) + 40 × magnitude^0.7
      magnitude = |加权信念度向量和| / 权重总和
      + direction_bonus: ≥3 核心引擎同向时额外 +2/引擎 (max +8)

    conflict_decay (0.0-1.0):
      = 1 / (1 + severe×3 + medium×1)  Sigmoid 式衰减

    data_health (0-20): 与 V25.3 一致
    """
    convictions = _signal_conviction(snapshot)
    directions = _signal_direction(snapshot)  # 兼容旧 API

    # ── 1. Conviction Score (0-80) ──
    weighted_sum = sum(convictions.get(k, 0) * weights.get(k, 0) for k in weights)
    total_weight = sum(weights.values())
    magnitude = abs(weighted_sum) / total_weight if total_weight > 0 else 0

    # 非线性映射: ^0.7 让弱信号区更敏感, 强信号区适度压缩
    conviction_score = 40.0 + 40.0 * (magnitude ** 0.7)

    # 方向奖励: 核心引擎同向且信念度>0.2 时加分 (替代旧 consensus_bonus)
    same_sign_count = sum(
        1 for k in _CORE_CANDIDATES if k in weights
        if convictions.get(k, 0) * weighted_sum > 0
        and abs(convictions.get(k, 0)) > 0.2
    )
    if same_sign_count >= 3:
        conviction_score += same_sign_count * 2.0  # max +8

    conviction_score = min(80.0, conviction_score)

    # ── 2. Data Health (0-20) ── 保持不变
    coverage = coverage_for(snapshot, weights)
    degraded = snapshot.get("degraded_modules") or []
    if isinstance(degraded, str):
        degraded = [d.strip() for d in degraded.split(",") if d.strip()]
    data_health = max(0.0, 20.0 * coverage["available_weight_pct"] / 100 - len(degraded) * 2.0)

    # ── 3. Conflict Decay (0-1) ──
    conflicts = compute_conflict_matrix(snapshot)
    severe = 1 if conflicts["has_severe"] else 0
    medium = max(0, conflicts["conflict_count"] - severe)
    decay = 1.0 / (1.0 + severe * 3.0 + medium * 1.0)

    # ── 合成 ──
    raw_jcs = conviction_score * decay + data_health
    jcs = round(min(100, max(0, raw_jcs)), 1)

    level, label = _level_of(jcs)

    return {
        "score": jcs,
        "level": level,
        "label": label,
        "directions": directions,
        "convictions": convictions,
        "conviction_score": round(conviction_score, 1),
        "data_health": round(data_health, 1),
        "conflict_decay": round(decay, 3),
        "conflict_count": conflicts["conflict_count"],
        "agreement_pct": round(magnitude * 100, 1),
        "consensus_bonus": 0.0,  # V26 废弃, 保持 API 兼容
    }


def _compute_direction_confidence_v27(original: dict, clean: dict, weights: dict) -> dict:
    """V27 影子模型: 把"方向"和"可信度"拆成两个输出 (不参与生产决策)。

    sᵢ ∈ [-1,+1]  各引擎连续信念度 (复用 V26 _signal_conviction)
    dᵢ ∈ [0,1]    时效折扣; 观测时间无法核验的信号 dᵢ=0 (不参与)
    κ  = Σwᵢdᵢ / Σwᵢ                         覆盖率 (缺失/未核验自动降低)
    D  = κ · Σwᵢdᵢsᵢ / Σwᵢdᵢ                  方向, 覆盖不足时向 0 (中性) 收缩
    σ  = 加权标准差(sᵢ)                         分歧度 ∈ [0,1]
    C  = κ · (1 − σ)                           置信度
    显示分 = 50 + 50·D (50=中性; 看多看空对称, 不再"数据越全分越高")
    """
    from dashboard_modules.decision.quality import build_signal_decay, time_unverified_engines
    states = signal_states(original)
    convictions = _signal_conviction(clean)
    has_provenance = isinstance(original.get("source_provenance"), dict)
    decay = build_signal_decay(original) if has_provenance else {}
    unverified = set(time_unverified_engines(original))
    total = sum(weights.values()) or 1.0
    used, w_eff, s_vals = [], [], []
    for key, w in weights.items():
        if states[key]["status"] != "available" or key in unverified:
            continue
        rel = (decay.get(key) or {}).get("reliability")
        d = 1.0 if rel is None else float(rel)  # 无半衰期定义的引擎 (gold/bond) 视为当期
        if d <= 0:
            continue
        used.append(key)
        w_eff.append(w * d)
        s_vals.append(float(convictions.get(key, 0.0)))
    W = sum(w_eff)
    if W <= 0:
        return {"direction": 0.0, "confidence": 0.0, "coverage": 0.0, "dispersion": None,
                "display_score": 50.0, "engines_used": [], "status": "no_usable_signal",
                "role": "shadow_only_not_used_for_decisions"}
    kappa = W / total
    mean = sum(w * x for w, x in zip(w_eff, s_vals)) / W
    var = sum(w * (x - mean) ** 2 for w, x in zip(w_eff, s_vals)) / W
    sigma = min(1.0, var ** 0.5)
    direction = kappa * mean
    confidence = kappa * (1.0 - sigma)
    return {"direction": round(direction, 3), "confidence": round(confidence, 3),
            "coverage": round(kappa, 3), "dispersion": round(sigma, 3),
            "display_score": round(50 + 50 * direction, 1), "engines_used": used,
            "status": "ok", "role": "shadow_only_not_used_for_decisions",
            "formula": "D=κ·Σwds/Σwd; C=κ·(1-σ)"}


def compute_jcs(snapshot: dict) -> dict:
    """
    V26.0 宏观环境读数 (宏观 4 因子 + 影子对照):

    JCS = clamp(基础一致性 60 + 数据健康 20 + 核心共识 20 − 冲突扣分, 0, 100)

    返回 score / level / level_label / label / directions (仅宏观因子) / signal_states (全部 6 个读数,
    MR/BOND 标记 excluded, 待核验因子标记 time_unverified) / direction_distribution / shadow 等。
    分数与等级只作宏观背景, 不得作为执行依据 (role = macro_environment_reading)。
    """
    from dashboard_modules.decision.quality import sanitize_snapshot
    original = snapshot
    unverified = set(time_unverified_engines(original))
    macro = macro_snapshot(original)
    result = _compute_jcs_with_weights(macro, _JCS_WEIGHTS, unverified=unverified, original=original)

    # 影子对照 (不参与任何决策): 旧 4 维 (含 MR) 与 V26/V27 模型
    legacy = sanitize_snapshot(original)
    v4_result = _compute_jcs_with_weights(legacy, _JCS_WEIGHTS_V4, n_core=4)
    v26_result = _compute_jcs_v26(macro, _JCS_WEIGHTS)

    result["shadow"] = {
        "v4_score": v4_result["score"],
        "v6_score": result["score"],  # 兼容旧字段名: 现为 V26.0 宏观读数
        "delta": round(result["score"] - v4_result["score"], 1),
        "v4_level": v4_result["level"],
        "v26_score": v26_result["score"],
        "v26_level": v26_result["level"],
        "v26_convictions": v26_result.get("convictions", {}),
        "v26_conviction_score": v26_result.get("conviction_score", 0),
        "v26_decay": v26_result.get("conflict_decay", 1.0),
        "delta_v26": round(v26_result["score"] - result["score"], 1),
        # V27 影子: 方向/置信度分离 (30 天以上对照期 + 样本外验证前不得接入仓位)
        "v27": _compute_direction_confidence_v27(original, macro, _JCS_WEIGHTS),
    }

    states = signal_states(original)
    distribution = {"bullish_weight_pct": 0.0, "bearish_weight_pct": 0.0,
                    "neutral_weight_pct": 0.0, "unknown_weight_pct": 0.0}
    for engine, state in states.items():
        if engine in EXCLUDED_ENGINES:
            state.update(excluded=True, excluded_reason=EXCLUDED_ENGINES[engine], weight=0.0)
            continue
        state["weight"] = round(_JCS_WEIGHTS[engine] * 100, 1)
        if state["status"] == "available" and engine in unverified:
            state.update(time_unverified=True)
            category = "unknown"
        elif state["status"] == "available":
            state["direction"] = result["directions"][engine]
            category = {1: "bullish", -1: "bearish", 0: "neutral"}[state["direction"]]
        else:
            category = "unknown"
        distribution[category + "_weight_pct"] += _JCS_WEIGHTS[engine] * 100
    result.update(signal_states=states, direction_distribution=distribution,
                  weights={k: round(v * 100, 1) for k, v in _JCS_WEIGHTS.items()},
                  excluded_engines=dict(EXCLUDED_ENGINES),
                  model_version=MODEL_VERSION, is_probability=False,
                  role="macro_environment_reading", used_for_execution=False,
                  score_semantics="macro_environment_reading_not_probability_not_execution_input",
                  formula="clamp(base_agreement + data_health + consensus_bonus - conflict_penalty, 0, 100)",
                  level_intervals={"low": "[0,40)", "medium": "[40,70)", "high": "[70,100]"})

    return result
