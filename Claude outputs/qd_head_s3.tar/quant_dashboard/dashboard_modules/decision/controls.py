"""Single server-owned final decision. Model suggestions never grant order permission."""
from dashboard_modules.decision.quality import finite_number, build_signal_decay
from services.jcs_validation import validation_status


_STATE_PRIORITY = ("unavailable", "risk_review", "data_unavailable", "research_only")
# 决策契约版本: /hub 路由按此判定缓存是否可用 (改契约只改这里, 路由引用同一常量)
CONTRACT_VERSION = "decision-controls-v2"


def resolve_action_plan(snapshot, candidate, compliance, *, mode):
    """最终执行结论 (服务端唯一出口)。

    - 唯一仓位数字 = AIAE 执行目标 (candidate.execution_target)。其他上限、风控规则只作为原因说明。
    - 不读取 JCS 分数或等级 (2026-11-01: JCS = 宏观环境读数, 不作执行依据)。
    - 状态优先级: 风控不可用 > 风险阻断 > 执行数据不足 > 研究观察。
    - 任何状态下都不授予下单权限。
    """
    validation = validation_status()
    permissions = {"mode": mode, "observe": True, "review_risk": True,
                   "record_trade": True, "increase": False, "decrease": False,
                   "create_order": False, "auto_execute": False,
                   "detail": "研究与风险复核；成交记录不代表订单授权或券商成交"}
    blocks = compliance.get("blocks") or []
    block_names = "；".join(str(item.get("rule_name") or item.get("rule_id")) for item in blocks)
    target = finite_number(candidate.get("execution_target"))
    if target is not None and not 0 <= target <= 100:
        target = None
    current = finite_number(candidate.get("current_position"))
    if current is not None and current < 0:
        current = None
    # 执行依据只有 AIAE: 只核验 AIAE 的数据时效 (宏观背景因子的时效不影响执行结论)
    decay = build_signal_decay(snapshot).get("aiae") or {}
    aiae_time_unknown = decay.get("age_hours") is None
    aiae_stale = (not aiae_time_unknown) and decay["age_hours"] >= decay["half_life_hours"]
    if compliance.get("status") not in {"passed", "warning", "blocked"}:
        state, label = "unavailable", "暂停决策 · 风控不可用"
        reasoning = "风控结果未知，不给出执行结论"
    elif compliance.get("status") == "blocked":
        state, label = "risk_review", "风险阻断 · 优先复核"
        reasoning = "风险规则优先：" + (block_names or "存在未通过的硬性风险规则")
    elif (target is None
          or snapshot.get("decision_locked") is True
          or (snapshot.get("_data_quality") or {}).get("is_cold_start") is True):
        state, label = "data_unavailable", "暂停决策 · 执行数据不足"
        reasoning = candidate.get("reasoning") or "AIAE 执行目标缺失或已被数据质量门锁定"
    elif aiae_time_unknown or aiae_stale:
        state, label = "data_unavailable", "暂停决策 · 核验 AIAE 数据时效"
        reasoning = "AIAE 观测时间无法核验或已超过半衰期"
    else:
        state, label = "research_only", "研究观察 · 不生成订单"
        reasoning = "执行分区：" + (candidate.get("action_label") or "待评估") + "；当前模式及订单链路尚未授予交易权限"
    risk_detail = [str(item.get("detail") or item.get("rule_name") or item.get("rule_id")) for item in blocks]
    gap = round(current - target, 1) if target is not None and current is not None else None
    return {**candidate, "state": state, "action_label": label,
            "reasoning": reasoning,
            "execution_target": target, "current_position": current, "execution_gap": gap,
            "execution_zone": candidate.get("zone"), "execution_zone_label": candidate.get("action_label"),
            # 兼容旧字段: 不再输出模型参考/硬上限/评分等级; position_target 仍为 None (未获订单审批)
            "position_target": None, "position_gap": None,
            "risk_summary": block_names, "risk_detail": risk_detail,
            "risk_note": "；".join(risk_detail),
            "position_basis": "投资组合风险资产市值 / 总资产；排除国债逆回购",
            "target_basis": "AIAE 执行目标 = 有效上限 (AIAE ∧ 市场尾部刹车 ∧ 组合波动预算 ∧ 回撤刹车) 按周评估，风险事件当日只向下；不使用 JCS",
            "permissions": permissions, "model_validation": validation,
            "blocking_rules": blocks, "contract_version": CONTRACT_VERSION}


def invalidate_cached_hub(payload, reason="缓存或断路器降级，需重新核验"):
    """Old success envelopes must not keep a previous execution-looking instruction."""
    import copy
    result = copy.deepcopy(payload)
    if isinstance(result.get("data"), dict):
        result["data"] = invalidate_cached_hub(result["data"], reason)
    if "action_plan" in result:
        plan = result["action_plan"] or {}
        result["action_plan"] = {**plan, "state": "unavailable", "action_label": "暂停决策 · 数据降级",
            "reasoning": reason, "risk_note": reason, "risk_summary": reason, "risk_detail": [reason],
            "position_target": None, "position_gap": None,
            # 撤回后不保留旧的执行分区/约束/评估日, 避免与"暂停"并列显示
            "execution_target": None, "execution_gap": None, "execution_zone": None,
            "execution_zone_label": None, "zone": None, "constraints": [],
            "execution_instruction": None, "reduce_days": None,
            "next_check": "数据恢复后重新核验",
            "permissions": {"increase": False, "decrease": False, "create_order": False,
                            "auto_execute": False, "observe": True, "record_trade": True}}
        result["compliance"] = {"status": "unknown", "summary": reason, "checks": []}
        result["permissions"] = result["action_plan"]["permissions"]
        result["model_validation"] = {"status": "unavailable", "execution_ready": False, "detail": reason}
        if isinstance(result.get("jcs"), dict):
            result["jcs"] = {**result["jcs"], "data_status": "historical_cache",
                             "label": "历史缓存读数，等待重新核验"}
    return result
