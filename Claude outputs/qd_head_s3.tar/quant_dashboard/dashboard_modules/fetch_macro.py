"""
Dashboard Module: 宏观数据抓取 (VIX / CNY)
=========================================
从 main.py 提取，提供 VIX 恐慌指数 + 离岸人民币汇率的抓取。
"""

import requests
import re
import logging
import json
from datetime import datetime, timedelta
from typing import Tuple, Optional
from services.fred_guard import fred_get_series
from services.market_clock import CN_TZ

logger = logging.getLogger("alphacore.fetch_macro")

# ── V6.0: VIX 磁盘降级缓存 ──
import os as _os
from zoneinfo import ZoneInfo as _ZoneInfo
_VIX_CACHE_PATH = _os.path.join(_os.path.dirname(_os.path.dirname(__file__)), "data_lake", "vix_cache.json")

# ── 2026-11-01: VIX 观测日期 (美东交易日 YYYY-MM-DD) ──
# 旧实现只返回数值, 下游 (决策中枢 JCS) 拿不到观测时间, VIX 一直显示"待核验"且不计入。
# 优先用数据源自带的日期 (yfinance / FRED 的序列日期, TradingView 的 bar 时间);
# 实时报价类来源 (TradingView 无时间字段 / CNBC) 按美东最近一个交易时段推定 (工作日近似, 未扣节假日),
# basis 记为 session_derived。磁盘缓存保存观测日期; 旧缓存没有日期时如实留空。
_NY_TZ = _ZoneInfo("America/New_York")
_VIX_OBS_HINT = {"observed_at": None}
_VIX_META = {"observed_at": None, "basis": None, "source": None, "received_at": None}


def _ny_date_from_epoch(ts) -> Optional[str]:
    try:
        ts = float(ts)
        if ts > 1e12:  # 毫秒
            ts /= 1000.0
        return datetime.fromtimestamp(ts, _NY_TZ).date().isoformat()
    except (TypeError, ValueError, OverflowError, OSError):
        return None


def _utc_date_from_epoch(ts) -> Optional[str]:
    """日线 bar 时间戳 (交易日 00:00 UTC) → 交易日日期。"""
    try:
        ts = float(ts)
        if ts > 1e12:
            ts /= 1000.0
        from datetime import timezone as _tz
        return datetime.fromtimestamp(ts, _tz.utc).date().isoformat()
    except (TypeError, ValueError, OverflowError, OSError):
        return None


def _ny_session_date(now: Optional[datetime] = None) -> str:
    """美东最近一个已开盘交易时段的日期 (工作日近似): 周一至周五 09:30 后为当日, 否则回退到上一个工作日。"""
    now = (now or datetime.now(_NY_TZ)).astimezone(_NY_TZ)
    day = now.date()
    if now.weekday() >= 5 or (now.hour, now.minute) < (9, 30):
        day -= timedelta(days=1)
        while day.weekday() >= 5:
            day -= timedelta(days=1)
    return day.isoformat()


def _record_vix_observation(source: str, observed_at: Optional[str], basis: Optional[str]) -> None:
    _VIX_META.update(observed_at=observed_at, basis=basis if observed_at else None, source=source,
                     received_at=datetime.now(_NY_TZ).astimezone().isoformat())


def vix_observation() -> dict:
    """最近一次 VIX 取数的观测元数据: observed_at (美东交易日 YYYY-MM-DD 或 None) / basis / source / received_at (带时区)。"""
    return dict(_VIX_META)


def _take_obs_hint() -> Optional[str]:
    value, _VIX_OBS_HINT["observed_at"] = _VIX_OBS_HINT["observed_at"], None
    return value


def _save_vix_disk(latest: float, prev: float, source: str, observed_at: Optional[str] = None):
    """VIX 成功获取后写入磁盘缓存 (供重启/全源失败时降级)"""
    try:
        payload = {"latest": latest, "prev": prev, "source": source, "observed_at": observed_at,
                   "timestamp": datetime.now().isoformat()}
        tmp = _VIX_CACHE_PATH + ".tmp"
        with open(tmp, 'w') as f:
            json.dump(payload, f)
        _os.replace(tmp, _VIX_CACHE_PATH)
    except Exception as e:
        logger.debug("VIX 磁盘缓存写入失败: %s", e)

def _load_vix_disk(max_age_hours: int = 72) -> Optional[Tuple[float, float]]:
    """从磁盘读取 VIX 缓存 (72h 内有效)"""
    try:
        if not _os.path.exists(_VIX_CACHE_PATH):
            return None
        with open(_VIX_CACHE_PATH) as f:
            data = json.load(f)
        cached_at = datetime.fromisoformat(data["timestamp"])
        age_hours = (datetime.now() - cached_at).total_seconds() / 3600
        if age_hours > max_age_hours:
            logger.debug("VIX 磁盘缓存已过期 (%.1fh > %dh)", age_hours, max_age_hours)
            return None
        logger.info("VIX 从磁盘缓存加载: latest=%.2f, source=%s, age=%.1fh",
                    data["latest"], data.get("source", "?"), age_hours)
        _record_vix_observation("disk:" + str(data.get("source", "?")), data.get("observed_at"),
                                "cached_observation" if data.get("observed_at") else None)
        return data["latest"], data["prev"]
    except Exception as e:
        logger.debug("VIX 磁盘缓存读取失败: %s", e)
        return None


def fetch_vix_for_dashboard() -> Tuple[float, float]:
    """Fetch VIX from observable sources or a bounded last-known-good cache."""
    # V6.0: 周末/节假日直接使用磁盘缓存 (VIX 不更新, 无需请求外部源)
    if datetime.now(CN_TZ).replace(tzinfo=None).weekday() >= 5:  # 周末按北京时间判断
        disk = _load_vix_disk(max_age_hours=96)  # 周末容忍4天
        if disk:
            return disk

    # 1. TradingView
    try:
        _take_obs_hint()
        latest, prev = _fetch_vix_tradingview()
        if latest is not None and prev is not None:
            logger.info(f"VIX successfully fetched from TradingView: latest={latest}, prev={prev}")
            obs, basis = _obs_or_session(_take_obs_hint())
            _record_vix_observation("tradingview", obs, basis)
            _save_vix_disk(latest, prev, "tradingview", observed_at=obs)
            return latest, prev
    except Exception as e:
        logger.warning(f"TradingView VIX fetch failed: {e}")

    # 2. yfinance fallback
    try:
        _take_obs_hint()
        latest, prev = _fetch_vix_yfinance()
        if latest is not None and prev is not None:
            logger.info(f"VIX successfully fetched from yfinance: latest={latest}, prev={prev}")
            obs, basis = _obs_or_session(_take_obs_hint())
            _record_vix_observation("yfinance", obs, basis)
            _save_vix_disk(latest, prev, "yfinance", observed_at=obs)
            return latest, prev
    except Exception as e:
        logger.warning(f"yfinance VIX fetch failed: {e}")

    # 3. FRED fallback
    try:
        from fredapi import Fred
        from config import FRED_API_KEY
        fred = Fred(api_key=FRED_API_KEY)
        s = fred_get_series(
            "VIXCLS",
            lambda: fred.get_series("VIXCLS", observation_start=(datetime.now() - timedelta(days=10))),
        )
        if s is not None and not s.empty:
            s = s.dropna()
            obs = _series_last_date(s)
            _record_vix_observation("fred", obs, "source_date")
            if len(s) >= 2:
                logger.info(f"VIX successfully fetched from FRED: latest={float(s.iloc[-1])}, prev={float(s.iloc[-2])}")
                _save_vix_disk(float(s.iloc[-1]), float(s.iloc[-2]), "fred", observed_at=obs)
                return float(s.iloc[-1]), float(s.iloc[-2])
            logger.info(f"VIX successfully fetched from FRED (single): latest={float(s.iloc[-1])}")
            _save_vix_disk(float(s.iloc[-1]), float(s.iloc[-1]), "fred", observed_at=obs)
            return float(s.iloc[-1]), float(s.iloc[-1])
    except Exception as e:
        logger.warning(f"FRED VIX fetch failed: {e}")

    # 4. CNBC fallback
    try:
        rt = _fetch_vix_cnbc()
        if rt is not None:
            logger.info(f"VIX successfully fetched from CNBC: latest={rt}")
            obs, basis = _obs_or_session(None)
            _record_vix_observation("cnbc", obs, basis)
            _save_vix_disk(rt, rt, "cnbc", observed_at=obs)
            return rt, rt
    except Exception as e:
        logger.warning(f"CNBC VIX fetch failed: {e}")

    # 5. V6.0: 磁盘降级 — 所有外部源失败, 使用最近一次成功值
    disk = _load_vix_disk(max_age_hours=168)  # 容忍7天
    if disk:
        logger.warning("All VIX sources failed, using disk cache fallback")
        return disk

    logger.error("All VIX data sources and bounded caches failed")
    raise RuntimeError("VIX_DATA_UNAVAILABLE")


def _obs_or_session(hint: Optional[str]) -> Tuple[str, str]:
    """有数据源日期用数据源日期, 否则按美东最近交易时段推定。"""
    return (hint, "source_date") if hint else (_ny_session_date(), "session_derived")


def _series_last_date(s) -> Optional[str]:
    try:
        return s.index[-1].date().isoformat()
    except Exception:
        return None


def _fetch_vix_tradingview() -> Tuple[Optional[float], Optional[float]]:
    """Scrape cn.tradingview.com for VIX price and change percent"""
    url = "https://cn.tradingview.com/symbols/CBOE-VIX/"
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
    }
    try:
        response = requests.get(url, headers=headers, timeout=5)
        if response.status_code != 200:
            logger.warning(f"TradingView responded with status code {response.status_code}")
            return None, None
            
        for m in re.finditer(r'<script[^>]*>(.*?)</script>', response.text, re.DOTALL):
            content = m.group(1).strip()
            if not content or '"pro_symbol":"CBOE:VIX"' not in content:
                continue
            try:
                data = json.loads(content)
                for k, v in data.items():
                    if isinstance(v, dict) and "data" in v:
                        data_dict = v["data"]
                        sym_data = data_dict.get("symbol", {})
                        
                        price = None
                        trade = sym_data.get("trade")
                        daily_bar = sym_data.get("daily_bar")
                        if trade and isinstance(trade, dict) and "price" in trade:
                            price = float(trade["price"])
                        elif daily_bar and isinstance(daily_bar, dict) and "close" in daily_bar:
                            price = float(daily_bar["close"])
                        # 观测日期: 优先用成交时间 (实际时刻 → 美东日期); 其次日线 bar 时间。
                        # 注意: TradingView 日线 bar 的 time 是"交易日 00:00 UTC", 必须按 UTC 取日期,
                        # 换算到美东会退回前一天 (2026-11-02 线上发现 10-30 被记成 10-29)。
                        if isinstance(trade, dict) and trade.get("time") is not None:
                            _VIX_OBS_HINT["observed_at"] = _ny_date_from_epoch(trade.get("time"))
                        if not _VIX_OBS_HINT["observed_at"] and isinstance(daily_bar, dict) \
                                and daily_bar.get("time") is not None:
                            _VIX_OBS_HINT["observed_at"] = _utc_date_from_epoch(daily_bar.get("time"))
                                
                        change = None
                        screener_data = data_dict.get("symbol_screener_data")
                        if screener_data and isinstance(screener_data, dict) and "change" in screener_data:
                            change = float(screener_data["change"])
                        else:
                            faq_data = data_dict.get("symbol_faq_data", [])
                            if faq_data and isinstance(faq_data, list):
                                vars_dict = faq_data[0].get("variables", {})
                                change_obj = vars_dict.get("daily_bar_change", {})
                                fields = change_obj.get("fields", [{}])
                                if fields and isinstance(fields, list) and "value" in fields[0]:
                                    change = float(fields[0]["value"])
                                    
                        if price is not None:
                            if change is not None:
                                factor = 1.0 + change / 100.0
                                prev = price / factor if factor != 0 else price
                                return price, prev
                            else:
                                return price, price
            except Exception as e:
                logger.debug(f"Failed to parse script tag JSON in TradingView scraper: {e}")
    except Exception as e:
        logger.warning(f"TradingView fetch HTTP error: {e}")
    return None, None


def _fetch_vix_yfinance() -> Tuple[Optional[float], Optional[float]]:
    """Fetch VIX data from Yahoo Finance"""
    try:
        import yfinance as yf
    except ImportError:
        logger.warning("yfinance is not installed, skipping yfinance VIX fetch")
        return None, None
    ticker = yf.Ticker("^VIX")
    hist = ticker.history(period="5d", timeout=5)
    if hist is not None and not hist.empty and len(hist) >= 1:
        latest = float(hist.iloc[-1]['Close'])
        prev = float(hist.iloc[-2]['Close']) if len(hist) >= 2 else latest
        try:
            idx = hist.index[-1]
            _VIX_OBS_HINT["observed_at"] = (idx.tz_convert(_NY_TZ) if getattr(idx, "tzinfo", None) else idx).date().isoformat()
        except Exception:
            _VIX_OBS_HINT["observed_at"] = None
        return latest, prev
    return None, None


def _fetch_vix_cnbc() -> Optional[float]:
    """CNBC VIX scraper"""
    url = "https://www.cnbc.com/quotes/.VIX"
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36"
    }
    try:
        response = requests.get(url, headers=headers, timeout=5)
        if response.status_code == 200:
            match = re.search(r'"last":"([\d.]+)"', response.text)
            if match:
                return float(match.group(1))
    except Exception as e:
        logger.warning(f"SCRAPER ERROR: {e}")
    return None


# ── V7.0: CNY 磁盘降级缓存 ──
_CNY_CACHE_PATH = _os.path.join(_os.path.dirname(_os.path.dirname(__file__)), "data_lake", "cny_cache.json")
_CNY_MAX_SOURCE_AGE_HOURS = 240  # 10 calendar days, bounded for weekends/holidays
_ECB_DAILY_RATES_URL = "https://www.ecb.europa.eu/stats/eurofxref/eurofxref-daily.xml"


def _cny_observation_age_hours(value) -> Optional[float]:
    """Return source-observation age while handling naive/aware timestamps."""
    try:
        if hasattr(value, "to_pydatetime"):
            observed_at = value.to_pydatetime()
        elif isinstance(value, datetime):
            observed_at = value
        else:
            observed_at = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
        now = datetime.now(observed_at.tzinfo) if observed_at.tzinfo else datetime.now()
        age_hours = (now - observed_at).total_seconds() / 3600
        return age_hours if age_hours >= -6 else None
    except (TypeError, ValueError, OverflowError):
        return None


def _save_cny_disk(rate: float, source: str = "unknown", observed_at=None):
    """CNY 成功获取后写入磁盘缓存"""
    try:
        now_iso = datetime.now().isoformat()
        payload = {
            "rate": rate,
            "timestamp": now_iso,
            "source": source,
            "observed_at": str(observed_at or now_iso),
        }
        tmp = _CNY_CACHE_PATH + ".tmp"
        with open(tmp, 'w') as f:
            json.dump(payload, f)
        _os.replace(tmp, _CNY_CACHE_PATH)
    except Exception as e:
        logger.debug("CNY 磁盘缓存写入失败: %s", e)


def _load_cny_disk(max_age_hours: int = 72) -> Optional[float]:
    """从磁盘读取 CNY 缓存 (72h 内有效)"""
    try:
        if not _os.path.exists(_CNY_CACHE_PATH):
            return None
        with open(_CNY_CACHE_PATH) as f:
            data = json.load(f)
        cached_at = datetime.fromisoformat(data["timestamp"])
        age_hours = (datetime.now() - cached_at).total_seconds() / 3600
        if age_hours > max_age_hours:
            logger.debug("CNY 磁盘缓存已过期 (%.1fh > %dh)", age_hours, max_age_hours)
            return None
        source_age = _cny_observation_age_hours(data.get("observed_at", data["timestamp"]))
        if source_age is None or source_age > _CNY_MAX_SOURCE_AGE_HOURS:
            logger.debug(
                "CNY 源观测已过期 (source_age=%s, max=%dh)",
                f"{source_age:.1f}h" if source_age is not None else "invalid",
                _CNY_MAX_SOURCE_AGE_HOURS,
            )
            return None
        rate = float(data["rate"])
        if not 5.0 < rate < 9.0:
            return None
        logger.info(
            "CNY 从磁盘缓存加载: rate=%.4f, age=%.1fh, source=%s",
            rate,
            age_hours,
            data.get("source", "legacy"),
        )
        return rate
    except Exception as e:
        logger.debug("CNY 磁盘缓存读取失败: %s", e)
        return None


def _fetch_cny_fred() -> Optional[Tuple[float, str]]:
    """Fetch a bounded official USD/CNY observation from FRED (DEXCHUS)."""
    try:
        from fredapi import Fred
        from config import FRED_API_KEY

        fred = Fred(api_key=FRED_API_KEY)
        series = fred_get_series(
            "DEXCHUS",
            lambda: fred.get_series(
                "DEXCHUS",
                observation_start=(datetime.now() - timedelta(days=20)),
            ),
        )
        if series is None or series.empty:
            return None
        series = series.dropna()
        if series.empty:
            return None

        observed_at = series.index[-1]
        source_age = _cny_observation_age_hours(observed_at)
        rate = float(series.iloc[-1])
        if source_age is None or source_age > _CNY_MAX_SOURCE_AGE_HOURS:
            logger.warning("FRED CNY observation stale: age=%s", source_age)
            return None
        if not 5.0 < rate < 9.0:
            logger.warning("FRED CNY value outside validity bounds: %s", rate)
            return None

        observed_iso = (
            observed_at.to_pydatetime().isoformat()
            if hasattr(observed_at, "to_pydatetime")
            else str(observed_at)
        )
        return rate, observed_iso
    except Exception as e:
        logger.warning("FRED CNY fetch failed: %s", e)
        return None


def _fetch_cny_ecb() -> Optional[Tuple[float, str]]:
    """Fetch bounded USD/CNY via the ECB's official EUR reference rates."""
    try:
        from xml.etree import ElementTree

        response = requests.get(
            _ECB_DAILY_RATES_URL,
            timeout=6,
            headers={"User-Agent": "AlphaCore/1.0"},
        )
        response.raise_for_status()
        root = ElementTree.fromstring(response.content)
        observation = next(
            (node for node in root.iter() if node.attrib.get("time")),
            None,
        )
        if observation is None:
            return None

        rates = {
            node.attrib["currency"]: float(node.attrib["rate"])
            for node in observation
            if node.attrib.get("currency") and node.attrib.get("rate")
        }
        usd_per_eur = rates.get("USD")
        cny_per_eur = rates.get("CNY")
        if not usd_per_eur or not cny_per_eur:
            return None

        observed_at = observation.attrib["time"]
        source_age = _cny_observation_age_hours(observed_at)
        if source_age is None or source_age > _CNY_MAX_SOURCE_AGE_HOURS:
            logger.warning("ECB CNY observation stale: age=%s", source_age)
            return None

        rate = cny_per_eur / usd_per_eur
        if not 5.0 < rate < 9.0:
            logger.warning("ECB USD/CNY cross rate outside validity bounds: %s", rate)
            return None
        return rate, observed_at
    except Exception as e:
        logger.warning("ECB CNY fetch failed: %s", e)
        return None


def _cny_disk_observation() -> Optional[Tuple[float, str, str]]:
    """读取磁盘缓存的 (rate, observed_at, source), 校验观测日期与取值范围。"""
    try:
        if not _os.path.exists(_CNY_CACHE_PATH):
            return None
        with open(_CNY_CACHE_PATH) as f:
            data = json.load(f)
        observed_at = str(data.get("observed_at", data.get("timestamp")))
        age = _cny_observation_age_hours(observed_at)
        rate = float(data["rate"])
        if age is None or age > _CNY_MAX_SOURCE_AGE_HOURS or not 5.0 < rate < 9.0:
            return None
        return rate, observed_at, str(data.get("source", "legacy"))
    except Exception:
        return None


def fetch_cny_for_dashboard() -> float:
    """Fetch USD/CNY from an observable source or bounded last-known-good cache."""
    # 1. 周末/节假日直接使用磁盘缓存 (CNY 不更新)
    if datetime.now(CN_TZ).replace(tzinfo=None).weekday() >= 5:  # 周末按北京时间判断
        disk = _load_cny_disk(max_age_hours=96)  # 周末容忍4天
        if disk is not None:
            return disk

    # 2. CNBC API 获取 (超时缩短为 4s 防止卡顿)
    try:
        url = "https://quote.cnbc.com/quote-html-webservice/restQuote/symbolType/symbol?symbols=USD/CNY&requestMethod=itv&noCache=1&partnerId=2&fund=1&exthrs=1&output=json&events=1"
        r = requests.get(url, timeout=4, headers={'User-Agent': 'Mozilla/5.0'})
        if r.status_code == 200:
            quote = r.json().get('FormattedQuoteResult', {}).get('FormattedQuote', [{}])[0]
            raw_rate = quote.get('last')
            if raw_rate not in (None, ""):
                rate = float(str(raw_rate).replace(',', ''))
                if 5.0 < rate < 9.0:
                    logger.info("CNY successfully fetched from CNBC: rate=%.4f", rate)
                    _save_cny_disk(rate, source="cnbc")
                    return rate
                logger.warning("CNBC CNY value outside validity bounds: %s", rate)
    except Exception as e:
        logger.warning("CNBC CNY fetch failed: %s", e)

    # 3. ECB 官方日频参考汇率回退。由 CNY/EUR ÷ USD/EUR 得到 USD/CNY，
    # 严格保留并校验同一观测日期。
    ecb_result = _fetch_cny_ecb()
    if ecb_result is not None:
        rate, observed_at = ecb_result
        logger.info(
            "CNY successfully fetched from ECB reference rates: rate=%.4f, observed_at=%s",
            rate,
            observed_at,
        )
        _save_cny_disk(rate, source="ecb:EUR_REFERENCE", observed_at=observed_at)
        return rate

    # 4. FRED 官方日频汇率回退。严格校验源观测日期，不能把旧值通过
    # 重新写缓存伪装成新数据。
    fred_result = _fetch_cny_fred()
    # ECB 临时超时时, FRED (美方日频, 通常滞后数日) 可能比上一次成功的 ECB 观测更旧。
    # 取观测日期更新的那一个, 避免汇率在新旧观测之间来回跳动。
    if fred_result is not None:
        disk_obs = _cny_disk_observation()
        if disk_obs is not None:
            fred_age = _cny_observation_age_hours(fred_result[1])
            disk_age = _cny_observation_age_hours(disk_obs[1])
            if disk_age is not None and (fred_age is None or disk_age < fred_age):
                logger.info(
                    "CNY: 主源暂不可用, 使用更新的缓存观测 rate=%.4f observed_at=%s (source=%s), 而非更旧的 FRED 观测 %s",
                    disk_obs[0], disk_obs[1], disk_obs[2], fred_result[1],
                )
                return disk_obs[0]
    if fred_result is not None:
        rate, observed_at = fred_result
        logger.info(
            "CNY successfully fetched from FRED DEXCHUS: rate=%.4f, observed_at=%s",
            rate,
            observed_at,
        )
        _save_cny_disk(rate, source="fred:DEXCHUS", observed_at=observed_at)
        return rate

    # 5. 磁盘降级
    disk = _load_cny_disk(max_age_hours=168)  # 容忍7天
    if disk is not None:
        logger.warning("All CNY sources failed, using disk cache fallback")
        return disk

    logger.error("All CNY data sources and bounded caches failed")
    raise RuntimeError("CNY_DATA_UNAVAILABLE")


async def fetch_macro_data(executor) -> Tuple[float, float, float]:
    """异步并行抓取 VIX + CNY → 返回 (latest_vix, prev_vix, latest_cny)"""
    import asyncio
    loop = asyncio.get_running_loop()
    vix_result, cny_result = await asyncio.gather(
        loop.run_in_executor(executor, fetch_vix_for_dashboard),
        loop.run_in_executor(executor, fetch_cny_for_dashboard)
    )
    latest_vix, prev_vix = vix_result
    return latest_vix, prev_vix, cny_result
