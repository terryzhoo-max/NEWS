"""
AlphaCore V21.0 · 投委会日报生成器
====================================
聚合 JCS + AIAE + 矛盾检测 + 全球温度 + 尾部风险,
生成结构化 Markdown 投委会决策简报。

数据源:
  - get_hub_data()        → JCS / 矛盾 / AIAE / 执行建议 / 全球温度
  - compute_risk_matrix() → 尾部风险
  - db.get_decision_history(2) → 昨日快照 (计算 delta)

输出: 标准 Markdown 文本, 可直接粘贴企业微信/邮件
"""

from datetime import datetime
from typing import Optional
from services.logger import get_logger
from version import VERSION_STRING

logger = get_logger("ac.report")

# 星期中文映射
_WEEKDAY_CN = {0: "周一", 1: "周二", 2: "周三", 3: "周四", 4: "周五", 5: "周六", 6: "周日"}

# AIAE Regime 中文
_REGIME_CN = {1: "I级·极度恐慌", 2: "II级·低配置区", 3: "III级·中性均衡", 4: "IV级·偏热区域", 5: "V级·极度过热"}
_REGIME_EMOJI = {1: "🟢", 2: "🔵", 3: "🟡", 4: "🟠", 5: "🔴"}

# JCS 级别中文
# 2026-11-02: JCS = 宏观环境读数, 分级描述清晰度, 不是置信度/强弱
_JCS_LEVEL_CN = {"high": "清晰", "medium": "一般", "low": "模糊"}

# 引擎方向中文
_DIR_CN = {1: "⬆️ 看多", 0: "➡️ 中性", -1: "⬇️ 看空"}


def _safe(val, fmt="{:.1f}", fallback="--"):
    """安全格式化数值"""
    if val is None:
        return fallback
    try:
        return fmt.format(float(val))
    except (ValueError, TypeError):
        return fallback


def _delta_str(now, prev, fmt="{:.1f}", suffix=""):
    """计算并格式化 delta (▲/▼)"""
    if now is None or prev is None:
        return ""
    try:
        d = float(now) - float(prev)
        arrow = "▲" if d > 0 else "▼" if d < 0 else "→"
        return f"{arrow}{abs(d):.1f}{suffix}"
    except (ValueError, TypeError):
        return ""


def _regime_delta(now, prev):
    """Regime 级别变化文案"""
    if now is None or prev is None:
        return ""
    try:
        d = int(prev) - int(now)  # regime 越低越好
        if d > 0:
            return "▲改善"
        elif d < 0:
            return "▼恶化"
        return "→持平"
    except (ValueError, TypeError):
        return ""


def generate_daily_report(date_str: Optional[str] = None) -> dict:
    """
    生成投委会日报

    Args:
        date_str: 指定日期 (YYYY-MM-DD), None 表示今日

    Returns:
        {
            "status": "success",
            "date": "2026-05-03",
            "weekday": "周六",
            "markdown": "完整 Markdown 文本",
            "summary": { 简要数据字典 },
        }
    """
    from dashboard_modules.decision_engine import (
        get_hub_data, compute_risk_matrix
    )
    from services import db as ac_db

    now = datetime.now()
    report_date = date_str or now.strftime("%Y-%m-%d")
    weekday = _WEEKDAY_CN.get(now.weekday(), "")

    # ── 判断: 实时生成 还是 从历史回看 ──
    is_historical = (date_str is not None and date_str != now.strftime("%Y-%m-%d"))

    if is_historical:
        return _generate_historical_report(date_str)

    # ── 实时生成: 从当前缓存组装 ──
    try:
        hub = get_hub_data()
    except Exception as e:
        logger.error("日报生成失败: Hub 数据不可用 — %s", e)
        return {"status": "error", "error": f"Hub 数据不可用: {e}"}

    snapshot = hub.get("snapshot", {})
    jcs = hub.get("jcs", {})
    conflicts = hub.get("conflicts", {})
    action_plan = hub.get("action_plan", {})
    alerts = hub.get("alerts", [])
    global_temp = hub.get("global_temperature", {})

    # 尾部风险
    try:
        risk_matrix = compute_risk_matrix()
        tail_risk = risk_matrix.get("tail_risk", {})
    except Exception:
        tail_risk = {"score": 0, "level": "unknown", "label": "数据不可用"}

    # 昨日快照 (delta 计算)
    history = ac_db.get_decision_history(7)
    prev = None
    if len(history) >= 2:
        prev = history[-2]  # 倒数第二条 = 昨日
    elif len(history) == 1:
        prev = history[-1]

    # ── 拼接 Markdown ──
    md = _build_markdown(
        report_date, weekday, snapshot, jcs, conflicts,
        action_plan, alerts, global_temp, tail_risk, prev
    )

    # 简要摘要 (供前端卡片使用)
    summary = {
        "jcs_score": jcs.get("score"),
        "jcs_level": jcs.get("level"),
        "aiae_regime": snapshot.get("aiae_regime"),
        "execution_target": action_plan.get("execution_target"),   # 2026-11-02 (C8): 唯一仓位数字
        "suggested_position": snapshot.get("suggested_position"),  # 兼容旧字段 (AIAE 矩阵上限, 仅背景)
        "conflict_count": conflicts.get("conflict_count", 0),
        "tail_risk_score": tail_risk.get("score"),
        "tail_risk_level": tail_risk.get("level"),
        "alert_count": len(alerts),
    }

    # 缓存报告到 DB
    _save_report(report_date, md, summary)

    return {
        "status": "success",
        "date": report_date,
        "weekday": weekday,
        "markdown": md,
        "summary": summary,
    }


def _generate_historical_report(date_str: str) -> dict:
    """从 daily_reports 表回看历史日报"""
    from services import db as ac_db

    cached = ac_db.get_daily_report(date_str)
    if cached:
        return {
            "status": "success",
            "date": date_str,
            "weekday": "",
            "markdown": cached["markdown"],
            "summary": {},
            "source": "cached",
        }

    # 从 decision_log 回溯生成 (有限信息)
    history = ac_db.get_decision_history(365)
    target = None
    prev = None
    for i, row in enumerate(history):
        if row.get("date") == date_str:
            target = row
            if i > 0:
                prev = history[i - 1]
            break

    if not target:
        return {"status": "error", "error": f"未找到 {date_str} 的历史决策记录"}

    md = _build_historical_markdown(date_str, target, prev)
    return {
        "status": "success",
        "date": date_str,
        "weekday": "",
        "markdown": md,
        "summary": {},
        "source": "reconstructed",
    }


def _exec_numbers(action_plan: dict) -> tuple:
    """2026-11-02 (C8): 日报仓位只引用 AIAE 执行目标 (唯一仓位数字); 返回 (目标, 当前, 分区)。"""
    ap = action_plan or {}
    def _n(v):
        return float(v) if isinstance(v, (int, float)) else None
    return (_n(ap.get("execution_target")), _n(ap.get("current_position")),
            ap.get("execution_zone_label") or ap.get("zone_label"))


def _position_label(action_plan: dict) -> str:
    """2026-11-02 仓位口径统一: 当前仓位的数据时间 (持仓截至 … 对账单 · 价格 … 收盘)。"""
    return str(((action_plan or {}).get("position_meta") or {}).get("label") or "")


def _build_markdown(date, weekday, snapshot, jcs, conflicts,
                     action_plan, alerts, global_temp, tail_risk, prev) -> str:
    """拼接完整投委会日报 Markdown"""

    jcs_score = jcs.get("score", 0)
    jcs_level = jcs.get("level", "medium")
    regime = snapshot.get("aiae_regime", 3)
    position = snapshot.get("suggested_position", 55)
    conflict_count = conflicts.get("conflict_count", 0)
    tail_score = tail_risk.get("score", 0)
    tail_level = tail_risk.get("level", "low")

    # Delta 计算
    prev_jcs = prev.get("jcs_score") if prev else None
    prev_pos = prev.get("suggested_position") if prev else None
    prev_regime = prev.get("aiae_regime") if prev else None
    prev_conflict = prev.get("conflict_count") if prev else None

    # 尾部风险文案
    tail_label_map = {"low": "✅安全", "medium": "🟡关注", "high": "🔴危险"}
    tail_text = tail_label_map.get(tail_level, tail_level)

    # 决策总结文案 (2026-11-02): 以 AIAE 执行目标为唯一仓位数字, 不再由 JCS 方向推出操作语言
    exec_target = action_plan.get("execution_target")
    exec_zone = action_plan.get("execution_zone_label") or action_plan.get("zone_label")
    state_label = action_plan.get("action_label") or "待核验"
    if isinstance(exec_target, (int, float)):
        decision_text = f"{state_label}；执行分区：{exec_zone or '--'}，AIAE 执行目标 {exec_target:.0f}%"
    else:
        decision_text = f"{state_label}；AIAE 执行目标不可用"

    lines = []
    lines.append(f"# 📊 AlphaCore 每日决策简报")
    lines.append(f"> {date} ({weekday}) · 收盘后自动生成 · V22.0")
    lines.append("")
    lines.append("---")
    lines.append("")

    # ── 执行摘要 ──
    lines.append("## 🎯 执行摘要")
    lines.append("")
    lines.append("| 指标 | 今日 | 昨日 | Δ |")
    lines.append("|------|------|------|---|")
    lines.append(f"| **JCS 宏观读数** | {_safe(jcs_score)} {_JCS_LEVEL_CN.get(jcs_level, '')} | {_safe(prev_jcs)} | {_delta_str(jcs_score, prev_jcs)} |")
    _t, _c, _ = _exec_numbers(action_plan)
    lines.append(f"| **执行目标（唯一仓位数字）** | {_safe(_t, '{:.0f}')}% | -- | 历史见决策中枢复盘标签 |")
    _pl = _position_label(action_plan)
    lines.append(f"| **当前仓位** | {_safe(_c)}%{f'（{_pl}）' if _pl else ''} | -- | -- |")
    lines.append(f"| **AIAE 档位（背景）** | {_REGIME_EMOJI.get(regime, '')} {_REGIME_CN.get(regime, '')} | {_REGIME_CN.get(prev_regime, '--') if prev_regime else '--'} | {_regime_delta(regime, prev_regime)} |")
    lines.append(f"| **尾部风险** | {_safe(tail_score)} {tail_text} | -- | -- |")
    lines.append(f"| **矛盾信号** | {conflict_count} 个 {'✅' if conflict_count == 0 else '⚠️'} | {prev_conflict if prev_conflict is not None else '--'} 个 | {_delta_str(conflict_count, prev_conflict, '{:.0f}')} |")
    lines.append("")
    lines.append(f"**今日决策**: {decision_text}")
    lines.append("")

    # V22.2: AI 叙事分析 (LLM 增强 + 确定性保底)
    narrative_result = _build_narrative(snapshot, jcs, conflicts, tail_risk, prev, global_temp, action_plan=action_plan)
    source_label = narrative_result.get("source", "规则引擎")
    lines.append(f"### 🧠 市场叙事 `{source_label}`")
    lines.append("")
    for para in narrative_result.get("paragraphs", []):
        lines.append(para)
        lines.append("")
    lines.append("")

    # ── 执行建议 ──
    actions = action_plan.get("actions", [])
    if actions:
        lines.append("**执行建议**:")
        for act in actions[:5]:
            lines.append(f"- {act}")
        lines.append("")

    lines.append("---")
    lines.append("")

    # ── 背景读数 (2026-11-02 C8: 原「四引擎信号面板」权重表删除; MR 已移出 JCS; 只列读数, 不作执行依据) ──
    lines.append("## 📡 宏观背景读数（不作执行依据）")
    lines.append("")
    lines.append("| 读数 | 数值 |")
    lines.append("|------|------|")
    aiae_v1 = snapshot.get("aiae_v1")
    erp_val = snapshot.get("erp_val")
    erp_score = snapshot.get("erp_score")
    vix_val = snapshot.get("vix_val")
    lines.append(f"| AIAE 配置比例 | {_safe(aiae_v1)}%（{_REGIME_CN.get(regime, '--')}） |")
    lines.append(f"| ERP 股债性价比 | {_safe(erp_val, '{:.2f}')}%（得分 {_safe(erp_score, '{:.0f}')}） |")
    lines.append(f"| VIX | {_safe(vix_val)} |")
    lines.append(f"| JCS 宏观读数 | {_safe(jcs_score)} {_JCS_LEVEL_CN.get(jcs_level, '')} |")
    lines.append("")

    # ── 矛盾信号 ──
    conflict_list = conflicts.get("conflicts", [])
    if conflict_list:
        lines.append("### ⚠️ 引擎矛盾")
        lines.append("")
        for c in conflict_list:
            sev_icon = "🔴" if c.get("severity") == "high" else "🟡"
            lines.append(f"- {sev_icon} **{c.get('desc', '')}** — {c.get('action', '')}")
        lines.append("")

    lines.append("---")
    lines.append("")

    # ── 风险警告 ──
    lines.append("## ⚠️ 风险与警报")
    lines.append("")
    if not alerts and conflict_count == 0:
        lines.append("- ✅ 零矛盾信号，各引擎间无方向冲突")
        lines.append(f"- ✅ 尾部风险 {_safe(tail_score)} ({tail_text})")
    else:
        for alert in alerts:
            lines.append(f"- {alert.get('icon', '⚠️')} **{alert.get('title', '')}**: {alert.get('detail', '')}")
            lines.append(f"  - {alert.get('rule', '')}")
        if conflict_count == 0:
            lines.append(f"- ✅ 尾部风险 {_safe(tail_score)} ({tail_text})")

    # 融资热度 + 斜率
    margin_heat = snapshot.get("margin_heat")
    slope = snapshot.get("aiae_slope")
    if margin_heat is not None and float(margin_heat) >= 3.5:
        lines.append(f"- 🔥 融资热度 {_safe(margin_heat)}% (警戒 >3.5%)")
    if slope is not None and abs(float(slope)) >= 1.5:
        lines.append(f"- 📐 月环比斜率 {_safe(slope, '{:+.2f}')} (警戒 |±1.5|)")
    lines.append("")

    lines.append("---")
    lines.append("")

    # ── 全球温度 (附录) ──
    markets = global_temp.get("markets", [])
    if markets:
        # 2026-11-02 (C8): 海外只作背景 — 只列读数, 不列建议仓位与操作
        lines.append("## 🌍 全球市场读数（背景，不含仓位或操作建议）")
        lines.append("")
        lines.append("| 市场 | AIAE 配置比例 | 档位 |")
        lines.append("|------|------|------|")
        for m in markets:
            if m.get("status") != "ready" and m.get("status") != "fallback":
                lines.append(f"| {m.get('flag', '')} {m.get('name', '')} | 加载中 | -- |")
                continue
            lines.append(
                f"| {m.get('flag', '')} {m.get('name', '')} "
                f"| {_safe(m.get('aiae_v1'))}% "
                f"| {m.get('emoji', '')} {m.get('regime_cn', '')} |"
            )
        lines.append("")
        lines.append("---")
        lines.append("")

    # ── 合规声明 ──
    data_quality = snapshot.get("_data_quality", {})
    real_sources = data_quality.get("real_sources", 4)
    total_expected = data_quality.get("total_expected", 4)
    report_id = f"RPT-{date.replace('-', '')}-001"

    lines.append("## 📋 合规声明")
    lines.append("")
    lines.append(f"本报告由 {VERSION_STRING} 自动生成，含市场叙事分析。仓位只引用 AIAE 执行目标，风险判定以合规引擎为准；AIAE 档位、JCS、ERP、VIX 与海外读数只作背景。")
    lines.append("所有数据为收盘后快照，不构成投资建议。决策时请结合实际市场情况。")
    lines.append(f"数据质量: {real_sources}/{total_expected} 引擎正常 · 报告 ID: {report_id}")
    lines.append("")

    return "\n".join(lines)


def _build_historical_markdown(date, row, prev) -> str:
    """从 decision_log 行数据回溯生成精简报告"""
    regime = row.get("aiae_regime", 3)
    jcs_score = row.get("jcs_score")
    jcs_level = row.get("jcs_level", "medium")
    position = row.get("suggested_position")
    conflict_count = row.get("conflict_count", 0)

    prev_jcs = prev.get("jcs_score") if prev else None
    prev_pos = prev.get("suggested_position") if prev else None
    prev_regime = prev.get("aiae_regime") if prev else None

    lines = []
    lines.append(f"# 📊 AlphaCore 决策简报 (历史回看)")
    lines.append(f"> {date} · 从决策日志回溯生成")
    lines.append("")
    lines.append("---")
    lines.append("")
    lines.append("## 🎯 执行摘要")
    lines.append("")
    lines.append("| 指标 | 当日 | 前日 | Δ |")
    lines.append("|------|------|------|---|")
    lines.append(f"| **JCS 宏观读数** | {_safe(jcs_score)} {_JCS_LEVEL_CN.get(jcs_level, '')} | {_safe(prev_jcs)} | {_delta_str(jcs_score, prev_jcs)} |")
    lines.append(f"| **AIAE 档位（背景）** | {_REGIME_EMOJI.get(regime, '')} {_REGIME_CN.get(regime, '')} | {_REGIME_CN.get(prev_regime, '--') if prev_regime else '--'} | {_regime_delta(regime, prev_regime)} |")
    lines.append(f"| **矛盾信号** | {conflict_count} 个 | -- | -- |")
    lines.append("")
    lines.append("执行目标历史见决策中枢「复盘」标签（执行层前向记录）；决策日志不含执行目标，本回看不列仓位数字。")
    lines.append("")

    # 原始读数
    lines.append("## 📡 原始读数")
    lines.append("")
    lines.append(f"- ERP Score: {_safe(row.get('erp_score'), '{:.0f}')}")
    lines.append(f"- ERP Value: {_safe(row.get('erp_val'))}%")
    lines.append(f"- VIX: {_safe(row.get('vix_val'))}")
    lines.append(f"- Hub Composite: {_safe(row.get('hub_composite'))}")
    lines.append("")

    # 准确率回填
    ret_5d = row.get("market_return_5d")
    correct = row.get("signal_correct")
    if ret_5d is not None:
        result_icon = "✅" if correct == 1 else ("❌" if correct == 0 else "➖")
        lines.append(f"**T+5 验证**: 市场 5 日收益率 {_safe(ret_5d, '{:+.2%}')} → 信号 {result_icon}")
        lines.append("")

    lines.append("---")
    lines.append("")
    lines.append("*本报告从历史决策日志回溯生成，仅含核心指标，无全球温度和尾部风险数据。*")
    lines.append("")

    return "\n".join(lines)


def _save_report(date_str: str, markdown: str, summary: dict):
    """将日报缓存到 SQLite"""
    try:
        from services import db as ac_db
        ac_db.save_daily_report(date_str, markdown, summary)
        logger.info("日报已缓存: %s (%d 字符)", date_str, len(markdown))
    except Exception as e:
        logger.warning("日报缓存失败 (非致命): %s", e)


def auto_generate_report():
    """
    定时自动生成日报 (由 warmup_pipeline 在交易日 16:35 调用)
    仅在交易日执行，周末跳过。
    """
    now = datetime.now()
    if now.weekday() >= 5:  # 周六/周日
        logger.info("非交易日, 跳过日报自动生成")
        return

    try:
        result = generate_daily_report()
        if result.get("status") == "success":
            logger.info("📄 日报自动生成成功: %s (%d 字符)",
                         result["date"], len(result.get("markdown", "")))
        else:
            logger.warning("日报自动生成返回非成功状态: %s", result)
    except Exception as e:
        logger.error("日报自动生成异常: %s", e)


# ═══════════════════════════════════════════════════════════
#  V22.2: 混合叙事引擎 (LLM 增强 + 确定性保底)
#  优先尝试 LLM 生成专业叙事, 失败/禁用时回退确定性模板。
# ═══════════════════════════════════════════════════════════

def _build_narrative(snapshot: dict, jcs: dict, conflicts: dict,
                     tail_risk: dict, prev: dict,
                     global_temp: dict = None, action_plan: dict = None) -> dict:
    """
    混合叙事入口。返回 {"source": "AI增强"|"规则引擎", "paragraphs": [str]}
    """
    # 1. 尝试 LLM 增强
    if _is_ai_enabled():
        try:
            ai_paras = _generate_ai_narrative(
                snapshot, jcs, conflicts, tail_risk, prev, global_temp, action_plan=action_plan
            )
            if ai_paras and len(ai_paras) >= 2:
                return {"source": "AI 增强", "paragraphs": ai_paras}
        except Exception as e:
            logger.warning("AI 叙事失败, 回退确定性模板: %s", e)

    # 2. 确定性保底
    paras = _build_deterministic_narrative(
        snapshot, jcs, conflicts, tail_risk, prev, action_plan=action_plan
    )
    return {"source": "规则引擎", "paragraphs": paras}


def _build_deterministic_narrative(snapshot: dict, jcs: dict, conflicts: dict,
                                    tail_risk: dict, prev: dict, action_plan: dict = None) -> list:
    """
    V22.0 确定性叙事引擎 (原 _build_narrative)。
    基于 if/else 模板, 零外部依赖, 作为 LLM 失败时的保底。
    """
    paragraphs = []

    jcs_score = jcs.get("score", 50)
    jcs_level = jcs.get("level", "medium")
    directions = jcs.get("directions", {})
    regime = snapshot.get("aiae_regime", 3)
    aiae_v1 = snapshot.get("aiae_v1", 22)
    erp_val = snapshot.get("erp_val", 4.5)
    erp_score = snapshot.get("erp_score", 50)
    vix_val = snapshot.get("vix_val", 20)
    mr_regime = snapshot.get("mr_regime", "RANGE")
    position = snapshot.get("suggested_position", 55)
    conflict_count = conflicts.get("conflict_count", 0)
    tail_score = tail_risk.get("score", 0)

    # 计算方向一致性
    bull_count = sum(1 for d in directions.values() if d == 1)
    bear_count = sum(1 for d in directions.values() if d == -1)
    neutral_count = sum(1 for d in directions.values() if d == 0)
    majority = "bull" if bull_count > bear_count else ("bear" if bear_count > bull_count else "neutral")

    # ── 段落 1: 宏观环境 + 仓位锚 ──
    # 2026-11-02 (C8): 档位描述只写环境, 不写操作 (仓位只引用执行目标)
    regime_desc = {
        1: ("极度恐慌", "配置热度处于冰点，市场情绪极度悲观。"),
        2: ("低配置区", "配置热度偏低，市场情绪谨慎。"),
        3: ("中性均衡", "配置热度处于中性区间，市场既无恐慌也无亢奋。"),
        4: ("偏热区域", "配置热度偏高，市场情绪趋向乐观。"),
        5: ("极度过热", "配置热度处于极端区间。"),
    }
    rd = regime_desc.get(regime, regime_desc[3])

    _t, _c, _zone = _exec_numbers(action_plan)
    exec_txt = ((f"仓位以 AIAE 执行目标 **{_t:.0f}%** 为准" + (f"（当前 {_c:.1f}%，{_zone}）" if _c is not None and _zone else ""))
                if _t is not None else "AIAE 执行目标暂不可用")
    p1 = (
        f"当前市场处于 **{rd[0]}** 状态（背景），AIAE 配置比例 {aiae_v1:.1f}%。{rd[1]}{exec_txt}。"
    )

    # 添加 VIX 状态
    if vix_val > 30:
        p1 += f" VIX 恐慌指数 {vix_val:.1f}，处于极端恐慌区间（合规「VIX 紧急刹车」规则适用）。"
    elif vix_val > 25:
        p1 += f" VIX {vix_val:.1f} 偏高，市场存在一定焦虑情绪。"
    elif vix_val < 16:
        p1 += f" VIX {vix_val:.1f} 处于低波动区间，市场情绪稳定。"
    else:
        p1 += f" VIX {vix_val:.1f} 处于正常区间，市场情绪平稳。"
    paragraphs.append(p1)

    # ── 段落 2: 信号方向 + 矛盾分析 ──
    if conflict_count == 0 and bull_count >= 3:
        p2 = (
            f"宏观因子方向一致：**{bull_count} 个看多**，JCS 宏观读数 {jcs_score:.0f} 分（{_JCS_LEVEL_CN.get(jcs_level, jcs_level)}）。"
            f"ERP 估值 {erp_val:.2f}%（得分 {erp_score:.0f}），"
            + ("处于低估区间，提供较高安全边际。" if erp_score > 55 else
               ("处于高估区间，需警惕估值回归风险。" if erp_score < 35 else "估值中性。"))
        )
    elif conflict_count == 0 and bear_count >= 3:
        p2 = (
            f"宏观因子方向一致：**{bear_count} 个看空**，JCS 宏观读数 {jcs_score:.0f} 分（{_JCS_LEVEL_CN.get(jcs_level, jcs_level)}）。"
            "JCS 只作宏观背景，执行以 AIAE 执行目标为准。"
        )
    elif conflict_count > 0:
        severe = conflicts.get("has_severe", False)
        conflict_desc = conflicts.get("conflicts", [])
        first_conflict = conflict_desc[0].get("desc", "") if conflict_desc else ""
        p2 = (
            f"检测到 **{conflict_count} 个宏观因子冲突**{'（含严重）' if severe else ''}，JCS 宏观读数 {jcs_score:.0f} 分。"
            f"主要冲突：{first_conflict}。"
            f"JCS 只作宏观背景，执行以 AIAE 执行目标为准。"
        )
    else:
        p2 = (
            f"引擎信号方向分散（{bull_count} 看多 / {bear_count} 看空 / {neutral_count} 中性），"
            f"JCS 宏观读数 {jcs_score:.0f} 分（{_JCS_LEVEL_CN.get(jcs_level, jcs_level)}）。"
            f"宏观环境缺乏明确的单边方向（JCS 只作背景，不作执行依据）。"
        )
    paragraphs.append(p2)

    # ── 段落 3: 尾部风险 + 操作提示 ──
    if tail_score >= 60:
        p3 = (
            f"⚠️ **尾部风险偏高**（{tail_score:.0f} 分）。综合集中度、VIX、AIAE 和矛盾信号，"
            f"当前市场环境下行风险显著（启发式读数）。仓位以执行目标为准，止损以「持仓跟踪止盈」为准。"
        )
    elif tail_score >= 30:
        p3 = (
            f"尾部风险 **中等**（{tail_score:.0f} 分），处于可控区间。"
            f"风险判定以合规引擎为准（单票 ≤ 20%、主题集中度等）。"
        )
    else:
        p3 = (
            f"尾部风险 **较低**（{tail_score:.0f} 分），"
            f"组合风险暴露处于较低区间。"
        )

    # Delta 提示 (与前一日对比)
    if prev:
        prev_jcs = prev.get("jcs_score")
        prev_pos = prev.get("suggested_position")
        if prev_jcs is not None and abs(jcs_score - prev_jcs) > 5:
            direction = "上升" if jcs_score > prev_jcs else "下降"
            p3 += f" 较昨日 JCS {direction} {abs(jcs_score - prev_jcs):.0f} 分，宏观信号{'更清晰' if jcs_score > prev_jcs else '更模糊'}。"

    paragraphs.append(p3)

    return paragraphs


# ═══════════════════════════════════════════════════════════
#  V22.2: LLM 叙事增强层
#  Gemini / Claude / GPT 多后端支持, urllib 零依赖调用。
# ═══════════════════════════════════════════════════════════

import os as _rg_os
import json as _rg_json

_AI_CONFIG_PATH = _rg_os.path.join(
    _rg_os.path.dirname(_rg_os.path.dirname(_rg_os.path.abspath(__file__))),
    "config", "ai_config.json"
)


def _load_ai_config() -> dict:
    """加载 AI 配置 (已重构：使用统一的安全配置中心)"""
    from config import get_ai_config
    return get_ai_config()


def _is_ai_enabled() -> bool:
    """检查 AI 叙事是否启用且有有效 Key。
    2026-11-04: AI 服务总开关暂停 (config/job_switches.json ai_services) 时不调用大模型, 日报直接用规则模板。"""
    try:
        from services.job_switches import ai_paused
        if ai_paused() is not None:
            return False
    except Exception:
        pass
    cfg = _load_ai_config()
    if not cfg.get("enable_ai_narrative", False):
        return False
    provider = cfg.get("provider", "gemini")
    key = cfg.get(provider, {}).get("api_key", "")
    return bool(key and len(key) > 10)


def _build_ai_prompt(snapshot: dict, jcs: dict, conflicts: dict,
                     tail_risk: dict, prev: dict,
                     global_temp: dict = None, action_plan: dict = None) -> str:
    """将引擎读数组装为结构化 Prompt"""
    jcs_score = jcs.get("score", 50)
    jcs_level = jcs.get("level", "medium")
    directions = jcs.get("directions", {})
    regime = snapshot.get("aiae_regime", 3)
    aiae_v1 = snapshot.get("aiae_v1", 22)
    erp_val = snapshot.get("erp_val", 4.5)
    vix_val = snapshot.get("vix_val", 20)
    mr_regime = snapshot.get("mr_regime", "RANGE")
    position = snapshot.get("suggested_position", 55)
    conflict_count = conflicts.get("conflict_count", 0)
    tail_score = tail_risk.get("score", 0)

    regime_cn = _REGIME_CN.get(regime, "中性均衡")
    _t, _c, _zone = _exec_numbers(action_plan)
    exec_target_txt = f"{_t:.0f}%" if _t is not None else "不可用"
    exec_current_txt = (f"{_c:.1f}%" + (f" ({_zone})" if _zone else "")
                        + (f"（{_position_label(action_plan)}）" if _position_label(action_plan) else "")
                        ) if _c is not None else "不可用"
    compliance_txt = (action_plan or {}).get("reasoning") or (action_plan or {}).get("action_label") or "不可用"

    bull = sum(1 for d in directions.values() if d == 1)
    bear = sum(1 for d in directions.values() if d == -1)

    ctx = f"""JCS宏观读数 (只作背景, 不作执行依据): {jcs_score:.0f}分 ({_JCS_LEVEL_CN.get(jcs_level, jcs_level)})
AIAE执行目标 (唯一仓位数字): {exec_target_txt}
当前仓位: {exec_current_txt}
合规结论 (唯一风险判定): {compliance_txt}
AIAE配置比例 (背景): {aiae_v1:.1f}%, Regime {regime} ({regime_cn})
ERP股债性价比 (背景): {erp_val:.2f}%
VIX恐慌指数 (背景): {vix_val:.1f}
矛盾信号: {conflict_count}个
尾部风险: {tail_score:.0f}分"""

    # 昨日对比
    delta_ctx = "无昨日数据"
    if prev:
        p_jcs = prev.get("jcs_score")
        p_pos = prev.get("suggested_position")
        p_regime = prev.get("aiae_regime")
        delta_parts = []
        if p_jcs is not None:
            delta_parts.append(f"JCS: {p_jcs:.0f}→{jcs_score:.0f}")
        if p_regime is not None:
            delta_parts.append(f"Regime: R{p_regime}→R{regime}")
        delta_ctx = ", ".join(delta_parts) if delta_parts else "无显著变化"

    # 近期事件
    events_ctx = "近期无重大市场事件"
    try:
        from dashboard_modules.decision_engine import get_recent_events
        events = get_recent_events(5)
        if events:
            events_ctx = "\n".join([
                f"- [{e.get('severity', '')}] {e.get('title', '')}: "
                f"{e.get('detail', '')}"
                for e in events
            ])
    except Exception:
        pass

    # 全球温度
    global_ctx = "全球数据不可用"
    if global_temp:
        markets = global_temp.get("markets", [])
        if markets:
            parts = []
            for m in markets:
                if m.get("status") in ("ready", "fallback"):
                    parts.append(
                        f"{m.get('name', '')}: AIAE={m.get('aiae_v1', '?')}% "
                        f"Regime={m.get('regime_cn', '?')}"
                    )
            global_ctx = "; ".join(parts) if parts else "全球数据加载中"

    prompt = f"""你是 AlphaCore 量化投委会的首席策略师。请根据以下引擎数据，撰写 2-3 段专业的市场分析叙事，供投委会决策简报使用。

要求:
1. 语言专业但不生硬，如同基金经理对投委会的口头汇报
2. 必须引用具体数据 (JCS、AIAE、VIX 等数值)
3. 如果存在引擎矛盾，必须解释矛盾的含义和应对建议
4. 如果有近期市场事件，需整合到分析中
5. 不得给出新的仓位数字、加减仓比例或买卖建议；仓位只能引用上面的 AIAE 执行目标，风险只能引用合规结论；海外与宏观读数只作背景
6. 总字数控制在 300-500 字
7. 每段之间用空行分隔，不要加标题或序号

===== 今日引擎读数 =====
{ctx}

===== 昨日对比 =====
{delta_ctx}

===== 近期市场事件 =====
{events_ctx}

===== 全球市场温度 =====
{global_ctx}"""

    return prompt


def _call_gemini(prompt: str, cfg: dict) -> str:
    """调用 Gemini API (标准库 urllib, 零依赖，带柔性指数退避重试)"""
    import urllib.request
    import time

    gemini_cfg = cfg.get("gemini", {})
    api_key = gemini_cfg.get("api_key", "")
    model = gemini_cfg.get("model", "gemini-2.0-flash")
    timeout = cfg.get("timeout_seconds", 20)
    max_tokens = cfg.get("max_tokens", 1024)

    url = (f"https://generativelanguage.googleapis.com/v1beta/"
           f"models/{model}:generateContent?key={api_key}")

    payload = _rg_json.dumps({
        "contents": [{"parts": [{"text": prompt}]}],
        "generationConfig": {
            "maxOutputTokens": max_tokens,
            "temperature": 0.7,
        }
    }).encode("utf-8")

    req = urllib.request.Request(
        url, data=payload, method="POST",
        headers={"Content-Type": "application/json"}
    )
    
    max_retries = 3
    retry_delay = 2.0
    for attempt in range(max_retries):
        try:
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                result = _rg_json.loads(resp.read().decode("utf-8"))
            
            candidates = result.get("candidates", [])
            if not candidates:
                raise ValueError("Gemini 返回空 candidates")
            parts = candidates[0].get("content", {}).get("parts", [])
            if not parts:
                raise ValueError("Gemini 返回空 parts")
            return parts[0].get("text", "")
        except Exception as e:
            if attempt == max_retries - 1:
                logger.error("Gemini 调用最终失败: %s", e)
                raise e
            logger.warning("Gemini 调用失败: %s。将在 %.1fs 后进行重试 (%d/%d)", 
                           e, retry_delay, attempt + 1, max_retries)
            time.sleep(retry_delay)
            retry_delay *= 2.0


def _call_openai_compatible(prompt: str, cfg: dict, provider: str) -> str:
    """调用 OpenAI 兼容 API (DeepSeek / OpenAI / 其他兼容端点，带柔性指数退避重试)"""
    import urllib.request
    import time

    provider_cfg = cfg.get(provider, {})
    api_key = provider_cfg.get("api_key", "")
    model = provider_cfg.get("model", "deepseek-chat")
    base_url = provider_cfg.get("base_url", "https://api.deepseek.com")
    timeout = cfg.get("timeout_seconds", 30)
    max_tokens = cfg.get("max_tokens", 1024)

    url = f"{base_url.rstrip('/')}/v1/chat/completions"

    payload = _rg_json.dumps({
        "model": model,
        "messages": [
            {"role": "system", "content": "你是一位专业的量化投资策略分析师。"},
            {"role": "user", "content": prompt},
        ],
        "max_tokens": max_tokens,
        "temperature": 0.7,
    }).encode("utf-8")

    req = urllib.request.Request(
        url, data=payload, method="POST",
        headers={
            "Content-Type": "application/json",
            "Authorization": f"Bearer {api_key}",
        }
    )
    
    max_retries = 3
    retry_delay = 2.0
    for attempt in range(max_retries):
        try:
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                result = _rg_json.loads(resp.read().decode("utf-8"))
            
            choices = result.get("choices", [])
            if not choices:
                raise ValueError(f"{provider} 返回空 choices")
            return choices[0].get("message", {}).get("content", "")
        except Exception as e:
            if attempt == max_retries - 1:
                logger.error("%s 调用最终失败: %s", provider, e)
                raise e
            logger.warning("%s 调用失败: %s。将在 %.1fs 后进行重试 (%d/%d)", 
                           provider, e, retry_delay, attempt + 1, max_retries)
            time.sleep(retry_delay)
            retry_delay *= 2.0


def _generate_ai_narrative(snapshot: dict, jcs: dict, conflicts: dict,
                           tail_risk: dict, prev: dict,
                           global_temp: dict = None, action_plan: dict = None) -> list:
    """编排: Prompt构建 → LLM调用 → 段落解析"""
    cfg = _load_ai_config()
    provider = cfg.get("provider", "gemini")

    prompt = _build_ai_prompt(
        snapshot, jcs, conflicts, tail_risk, prev, global_temp, action_plan=action_plan
    )

    # 调用 LLM
    if provider == "gemini":
        raw_text = _call_gemini(prompt, cfg)
    elif provider in ("deepseek", "openai"):
        raw_text = _call_openai_compatible(prompt, cfg, provider)
    else:
        raise ValueError(f"不支持的 LLM 后端: {provider}")

    if not raw_text or len(raw_text) < 50:
        logger.warning("AI 叙事返回文本过短 (%d 字符), 放弃", len(raw_text or ""))
        return []

    # 解析段落 (按空行分段)
    paragraphs = [p.strip() for p in raw_text.split("\n\n") if p.strip()]
    if not paragraphs:
        paragraphs = [p.strip() for p in raw_text.split("\n") if p.strip()]

    logger.info("AI 叙事生成成功 (%s): %d 段, %d 字符",
                provider, len(paragraphs), len(raw_text))
    return paragraphs

