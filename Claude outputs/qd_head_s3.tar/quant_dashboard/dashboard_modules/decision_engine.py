"""
AlphaCore V27.0 Decision Intelligence Hub (Facade)
====================================================
O1 Refactor: 2949L -> ~700L (78% reduction)

All core logic split into dashboard_modules.decision.* subpackage.
This file serves as:
  1. Backward-compatible facade (all external imports unchanged)
  2. Home for aggregation functions that depend on multiple submodules
"""

import copy
import math
import json
from datetime import datetime, timedelta
from typing import Dict, List, Optional
from services.logger import get_logger

logger = get_logger("ac.decision")

try:
    from engines.erp_params import D1_SIGMOID_CENTER as _ERP_CENTER, D1_SIGMOID_K as _ERP_K
except ImportError:
    _ERP_CENTER, _ERP_K = 4.0, 1.5


# ==============================================================
#  Re-export from submodules (backward compatibility)
# ==============================================================

from dashboard_modules.decision.conflicts import (  # noqa: F401,F403
    _signal_direction, _signal_conviction, _CONFLICT_RULES, compute_conflict_matrix,
)

from dashboard_modules.decision.jcs import (  # noqa: F401,F403
    _JCS_WEIGHTS, _JCS_WEIGHTS_V4, _REGIME_CN_MAP, _REGIME_CAP_MAP,
    _recalc_vix_score, _recalc_hub_composite, _compute_jcs_with_weights,
    _compute_jcs_v26, compute_jcs,
)

from dashboard_modules.decision.temperature import (  # noqa: F401,F403
    _GLOBAL_REGIMES, _GLOBAL_GAUGE_BANDS, _REGIME_CAP_LOOKUP,
    _build_global_temperature,
)

from dashboard_modules.decision.snapshot import (  # noqa: F401,F403
    _parse_erp_value, _build_snapshot_from_cache,
)

from dashboard_modules.decision.action_plan import (  # noqa: F401,F403
    _get_current_position, _apply_position_gap_note,
    generate_action_plan, generate_alerts,
)

from dashboard_modules.decision.scenarios import (  # noqa: F401,F403
    SCENARIOS, _SHOCK_NODES, _SHOCK_EDGES, _SHOCK_SOURCES, _SNAPSHOT_DELTA_MAP,
    _build_adjacency, propagate_shock, apply_shock_to_snapshot,
    run_shock_simulation, simulate_scenario,
)

from dashboard_modules.decision.position_path import (  # noqa: F401,F403
    _POSITION_RULES, generate_position_path,
    _estimate_volatility, _estimate_daily_volume,
    estimate_execution_cost, estimate_position_path_costs,
)

from dashboard_modules.decision.events import (  # noqa: F401,F403
    _EVENT_LOG_PATH, _SNAPSHOT_PATH, _MAX_EVENTS, _EVENT_COOLDOWNS,
    _check_event_cooldown, _load_last_snapshot, _save_last_snapshot,
    _load_event_log, _save_event_log,
    detect_market_events, get_recent_events,
)

from dashboard_modules.decision.risk_matrix import (  # noqa: F401,F403
    compute_risk_matrix,
)

from dashboard_modules.decision.accuracy import (  # noqa: F401,F403
    _get_index_close, _get_t5_trade_date, backfill_signal_accuracy,
)

from dashboard_modules.decision.contagion import (  # noqa: F401,F403
    _CONTAGION_INDICES, compute_contagion_matrix,
)


# ==============================================================
#  Aggregation functions (depend on multiple submodules)
# ==============================================================

def _account_inputs():
    """决策中枢与买入门控共用的账户快照: (snapshot, clean, current, positions)。

    current = -1 表示账户敞口不可用。2026-11-02 从 get_hub_data 抽出, 逻辑不变。
    """
    from dashboard_modules.decision.action_plan import _position_from_valuation
    from dashboard_modules.decision.quality import sanitize_snapshot

    snapshot = _build_snapshot_from_cache()
    # Retain raw inputs for diagnostics, but do not let invalid numbers enter
    # direction/conflict or strategy arithmetic.
    clean = sanitize_snapshot(snapshot)
    try:
        from portfolio_engine import get_portfolio_engine
        from services.account_exposure import from_valuation
        valuation = get_portfolio_engine().get_valuation()
        # 2026-11-02 仓位口径统一: 当前仓位与合规权重同一分母 (services.account_exposure)
        exposure = from_valuation(valuation)
        current = exposure["pct"] if exposure.get("pct") is not None else _position_from_valuation(valuation)
        positions = valuation.get("positions", [])
    except Exception:
        current, positions, exposure = -1, [], {"status": "unavailable", "pct": None}
    clean["current_position"] = current
    snapshot["current_position"] = current if current >= 0 else None
    snapshot["position_meta"] = exposure
    return snapshot, clean, current, positions


def _execution_candidate(clean: dict):
    """AIAE 执行层 (与 /portfolio/vol-budget 同源) → (exec_view, execution, candidate)。不读 JCS。"""
    try:
        from services.aiae_execution import current_view_and_execution
        exec_view, execution = current_view_and_execution()
    except Exception as ex:
        logger.warning("AIAE 执行层不可用; 执行结论暂停: %s", ex)
        exec_view, execution = {}, {"status": "error", "reason": "AIAE 执行层不可用"}
    return exec_view, execution, generate_action_plan(clean, execution, exec_view)


def _exec_context(candidate: dict) -> dict:
    """2026-11-02 (B): 合规「仓位超限检查」以执行目标为基准 —— 传入同一次执行层结果, 避免两处取数不一致。
    最严约束只认与执行目标相等的约束 (执行目标周频评估, 可能暂时低于当前有效上限)。"""
    target = candidate.get("execution_target")
    binding = []
    if target is not None:
        for c in candidate.get("constraints") or []:
            try:
                if abs(float(c.get("value")) - float(target)) < 0.05:
                    binding.append(c.get("key"))
            except (TypeError, ValueError):
                continue
    return {"execution_target": target, "execution_binding": binding}


def apply_order(positions: list, current: float, total_asset, order: dict):
    """2026-11-02 项 2: 把一笔买入加到当前持仓 (统一口径, 同一分母; 现金 → 持仓, 总资产不变)。

    返回 (成交后持仓, 成交后仓位%, post_trade 摘要); 无法计算 → (None, None, 原因)。
    """
    import copy
    try:
        notional = float(order.get("notional"))
        total = float(total_asset)
    except (TypeError, ValueError, AttributeError):
        return None, None, "订单金额或账户总资产不可用，无法计算成交后组合"
    if not (notional > 0 and total > 0):
        return None, None, "订单金额或账户总资产无效，无法计算成交后组合"
    code = str(order.get("ts_code") or "")
    add = notional / total * 100
    post = copy.deepcopy(list(positions or []))
    row = next((p for p in post if str(p.get("ts_code") or "") == code), None)
    if row is None:
        row = {"ts_code": code, "name": order.get("name") or code, "weight": 0.0, "market_value": 0.0}
        if order.get("industry"):
            row["industry"] = order["industry"]
        post.append(row)
    row["weight"] = round(float(row.get("weight") or 0.0) + add, 4)
    row["market_value"] = round(float(row.get("market_value") or 0.0) + notional, 2)
    after = round(current + add, 2)
    return post, after, {"ts_code": code, "name": row.get("name"), "notional": round(notional, 2),
                         "add_pct": round(add, 2), "total_pct": after, "single_pct": round(row["weight"], 2)}


def compliance_for_direction(direction: str, *, current_override=None, order=None) -> dict:
    """在决策中枢同一份账户快照上, 按指定操作方向运行合规引擎 (买入门控用, direction="increase")。

    order={ts_code, name, notional} 时按成交后组合判定 (2026-11-02 项 2)。
    账户仓位不可用时返回 status=unknown (调用方按"合规不可用"默认拒绝买入)。
    """
    from engines.compliance_engine import run_compliance_check

    snapshot, clean, current, positions = _account_inputs()
    if current < 0:
        return {"status": "unknown", "summary": "账户仓位不可用，合规无法评估",
                "checks": [], "blocks": [], "warnings": []}
    _view, _execution, candidate = _execution_candidate(clean)
    # 买入门控: 两口径不一致时传入较高值 (services.account_exposure.gate_pct), 不比改前更宽松
    pos = current_override if current_override is not None else current
    meta = snapshot.get("position_meta") or {}
    context = {"direction": direction, "current_position": pos, "position_label": meta.get("label"),
               **_exec_context(candidate)}
    post_trade = None
    if order:
        post_positions, post_pos, post_trade = apply_order(positions, pos, meta.get("total_asset"), order)
        if post_positions is None:
            return {"status": "unknown", "summary": post_trade, "checks": [], "blocks": [], "warnings": []}
        context.update({"current_position": post_pos, "order": order, "pre_positions": positions})
        positions = post_positions
    result = run_compliance_check(clean, positions=positions, context=context)
    if post_trade and isinstance(result, dict):
        theme = next((c for c in result.get("checks") or [] if c.get("rule_id") == "sector_concentration"), {})
        post_trade["themes"] = theme.get("order_themes") or []
        result["post_trade"] = post_trade
    return result


def get_hub_data() -> dict:
    """One account snapshot and one server-owned final decision contract."""
    from datetime import timezone
    from dashboard_modules.decision.controls import resolve_action_plan
    from dashboard_modules.decision.quality import build_freshness, build_signal_decay, macro_snapshot
    from engines.compliance_engine import run_compliance_check
    from services.decision_policy import get_mode

    snapshot, clean, current, positions = _account_inputs()
    # 宏观环境读数 (JCS): 冲突与评分使用同一份宏观口径快照 (MR/BOND 移出, 待核验因子置空)
    conflicts = compute_conflict_matrix(macro_snapshot(snapshot))
    jcs = compute_jcs(snapshot)
    # 执行: 只用 AIAE 执行层 (与 /portfolio/vol-budget 同源), 不读 JCS
    exec_view, execution, candidate = _execution_candidate(clean)
    context = {"direction": candidate.get("direction", "unknown"),
               "current_position": current if current >= 0 else None,
               "position_label": (snapshot.get("position_meta") or {}).get("label"),
               **_exec_context(candidate)}
    compliance = {"status": "unknown", "summary": "account or compliance unavailable", "checks": []}
    if current >= 0:
        try:
            compliance = run_compliance_check(clean, positions=positions, context=context)
        except Exception:
            logger.warning("Compliance unavailable; final decision closed", exc_info=True)
    action_plan = resolve_action_plan(snapshot, candidate, compliance, mode=get_mode())
    # 2026-11-02 仓位口径统一: 当前仓位的数据时间 (全站显示"持仓截至 … · 价格 … 收盘")
    action_plan["position_meta"] = {k: (snapshot.get("position_meta") or {}).get(k)
                                    for k in ("status", "pct", "label", "holdings_as_of", "price_as_of",
                                              "cash_basis", "frozen", "broker_check", "switch_date")}
    decay = build_signal_decay(snapshot)
    # 验收修补 (2026-10-29): 按来源发布周期判定 ok/stale/missing/future/unknown, 不再"年龄可算即 ok"
    freshness = build_freshness(decay)
    dates = sorted({str(item["observed_at"])[:10] for item in decay.values() if item["observed_at"]})
    return {
        "status": "success", "timestamp": datetime.now(timezone.utc).isoformat(),
        "snapshot": snapshot, "conflicts": conflicts, "jcs": jcs,
        "action_plan": action_plan, "permissions": action_plan["permissions"],
        "model_validation": action_plan["model_validation"],
        "alerts": generate_alerts(clean), "compliance": compliance,
        "scenarios": {key: {field: value[field] for field in ("name", "desc", "icon", "severity")}
                      for key, value in SCENARIOS.items()},
        "global_temperature": _build_global_temperature(),
        "data_freshness": freshness, "signal_decay": decay,
        "data_date": dates[-1] if dates else None, "date_consistent": len(dates) <= 1,
        "date_consistency_basis": "different source cadences; dates are not synchronized observations",
        "engine_meta": {key: {"weight": round(_JCS_WEIGHTS.get(key, 0) * 100, 1), **state}
                        for key, state in jcs["signal_states"].items()},
    }


def log_daily_decision():
    """每日收盘快照写入 SQLite (由 warmup_pipeline 调用)"""
    from services import db as ac_db

    snapshot = _build_snapshot_from_cache()
    if not snapshot.get("aiae_regime"):
        logger.warning("决策快照跳过: 缓存数据不完整")
        return

    from dashboard_modules.decision.quality import macro_snapshot
    jcs = compute_jcs(snapshot)
    conflicts = compute_conflict_matrix(macro_snapshot(snapshot))

    data = {
        "date": datetime.now().strftime("%Y-%m-%d"),
        "aiae_regime": snapshot.get("aiae_regime"),
        "aiae_v1": snapshot.get("aiae_v1"),
        "erp_score": snapshot.get("erp_score"),
        "erp_val": snapshot.get("erp_val"),
        "vix_val": snapshot.get("vix_val"),
        "mr_regime": snapshot.get("mr_regime"),
        "hub_composite": snapshot.get("hub_composite"),
        "jcs_score": jcs["score"],
        "jcs_level": jcs["level"],
        "suggested_position": snapshot.get("suggested_position"),
        "conflict_count": conflicts["conflict_count"],
        "degraded_modules": ",".join(snapshot.get("degraded_modules", [])) if isinstance(snapshot.get("degraded_modules"), list) else str(snapshot.get("degraded_modules", "")),
        # V25.3: 影子模式 + 多资产信号
        "jcs_v4_score": jcs.get("shadow", {}).get("v4_score"),
        "jcs_v6_score": jcs.get("shadow", {}).get("v6_score"),
        "jcs_shadow_delta": jcs.get("shadow", {}).get("delta"),
        "gold_signal": snapshot.get("gold_signal"),
        "bond_signal": snapshot.get("bond_signal"),
        # V26: Signal Conviction Model 影子数据
        "jcs_v26_score": jcs.get("shadow", {}).get("v26_score"),
        "delta_v26": jcs.get("shadow", {}).get("delta_v26"),
    }
    # F1: 写入当日即保存方向/评价期限/版本; 准确率只评价这里保存的方向, 不看分数高低
    from services.jcs_accuracy import direction_fields_from_jcs
    data.update(direction_fields_from_jcs(jcs))

    ac_db.upsert_decision_log(data)
    from services.db.decision import record_decision_evidence
    record_decision_evidence(snapshot, jcs)
    ac_db.cleanup_old_decisions(365)

    shadow = jcs.get("shadow", {})
    logger.info("决策快照存档: JCS=%.1f (%s) v26=%.1f delta=%.1f conflicts=%d pos=%s%%",
                jcs["score"], jcs["level"],
                shadow.get("v26_score", 0), shadow.get("delta", 0),
                conflicts["conflict_count"],
                snapshot.get("suggested_position", "?"))



def get_hub_data_with_events() -> dict:
    """
    get_hub_data 的增强版: 额外检测市场事件并附加事件列表。
    供 API 直接调用以原子化获取决策中枢 + 事件。
    """
    result = get_hub_data()

    try:
        snapshot = result.get("snapshot", {})
        if snapshot:
            events = detect_market_events(snapshot)
            result["market_events"] = get_recent_events(10)
            result["new_events_count"] = len(events)
    except Exception as e:
        logger.debug("事件检测异常: %s", e)
        result["market_events"] = []
        result["new_events_count"] = 0

    return result
