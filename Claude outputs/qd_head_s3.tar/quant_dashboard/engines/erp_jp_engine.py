"""
AlphaCore · 日本ERP择时引擎 V1.0
===================================
五维择时信号系统 (日本市场本地化):
  D1: ERP绝对值 (1/PE_TOPIX - 10Y JGB)       — 权重20%  [估值]
  D2: ERP历史分位 (近5年)                       — 权重25%  [估值]
  D3: 日元汇率趋势 (USDJPY方向)                 — 权重30%  [流动性] ← BOJ政策代理
  D4: 日经225实现波动率 (60日)                   — 权重15%  [风险]
  D5: 日元实际利率变化 (JGB-CPI代理)             — 权重10%  [信用/政策]

特殊考量:
  - JGB 10Y ≈ 0.5-1.5% (全球最低无风险利率之一)
  - ERP天然偏高 (因为JGB极低)，历史中位数 ≈ 5.0-6.5%
  - 日元走弱 = BOJ宽松 = 出口利润↑ = 利好股市 (但USDJPY > 155 = 干预风险)

ETF标的: 1306.T (TOPIX) / 1321.T (日经225) / 1577.T (高股息50)
数据源: FRED API (JGB 10Y / NIKKEI225 / DEXJPUS)
"""

import pandas as pd
import numpy as np
import time
import os
from datetime import datetime, timedelta
from typing import Optional

import json
import logging
import threading

# FRED API for all Japan data
from config import FRED_API_KEY
from services.fred_guard import fred_get_series

CACHE_DIR = "data_lake"
os.makedirs(CACHE_DIR, exist_ok=True)
from erp_signal_enhancer import adaptive_weights, multi_timeframe_confirmation, overseas_data_quality
import erp_params

logger = logging.getLogger("alphacore.erp_jp")

# O1: 动态EPS估算配置 (替代硬编码¥2500)
EPS_CONFIG_JP = {
    "base_eps": 2600.0,      # 日经225 EPS 共识中位 (2026Q1)
    "as_of_quarter": "2026Q1",
    "annual_growth": 0.06,   # 年化EPS增长率
}

def _get_dynamic_eps_jp() -> float:
    """基于基准EPS + 时间衰减的动态估算"""
    cfg = EPS_CONFIG_JP
    year = int(cfg["as_of_quarter"][:4])
    quarter = int(cfg["as_of_quarter"][-1])
    base_date = datetime(year, quarter * 3, 1)
    quarters_elapsed = (datetime.now() - base_date).days / 91.25
    adjusted = cfg["base_eps"] * (1 + cfg["annual_growth"]) ** (quarters_elapsed / 4)
    if quarters_elapsed >= 3:
        logger.warning("EPS估算基于%s，已过期%.0f个季度，请更新EPS_CONFIG_JP", cfg['as_of_quarter'], quarters_elapsed)
    return round(adjusted, 1)

_jp_fred = None
def _get_jp_fred():
    global _jp_fred
    if _jp_fred is None:
        try:
            from fredapi import Fred
            _jp_fred = Fred(api_key=FRED_API_KEY)
        except Exception as e:
            logger.warning("FRED init failed: %s", e)
    return _jp_fred

# ===== 线程安全 + SWR 后台缓存 (V26.1: 迁移至统一 EngineCache) =====
from services.engine_cache import EngineCache
_engine_cache = EngineCache("erp_jp", max_workers=3)

def _jp_cached(key, ttl_seconds, fetcher):
    """统一缓存接口 (委托给 EngineCache)"""
    return _engine_cache.get(key, ttl_seconds, fetcher)


ENCYCLOPEDIA_JP = {
    "erp_abs": {
        "title": "日本 ERP (株式リスクプレミアム)",
        "what": "ERP = TOPIX盈利收益率(1/PE) - 10Y JGB收益率。衡量日本股票相对国债的超额回报。",
        "why": "JGB极低(0.5-1.5%), 日本ERP天然偏高(5-7%), 需要用日本自身历史区间判断。",
        "alert": "日本ERP < 4% 意味着估值已不便宜(JGB低但PE也抬高了)。ERP > 7% 是极度低估。",
        "history": "2012年安倍经济学前ERP ~8%(极低估), 2021年泡沫高点ERP ~4%(偏高)。"
    },
    "erp_pct": {
        "title": "ERP 历史分位",
        "what": "过去5年中ERP所处的位置。80%分位 → 日股处于罕见低估区。",
        "why": "日本市场在安倍经济学后PE结构性提升，需用近5年分位避免历史偏差。",
        "alert": "分位 > 75% 是配置窗口。分位 < 25% 说明估值已充分反映。",
    },
    "yen_trend": {
        "title": "日元汇率趋势 (USDJPY)",
        "what": "USDJPY上升 = 日元贬值。反映BOJ货币政策宽松程度和出口竞争力。",
        "why": "日元贬值 → 出口企业利润↑ → 日股(尤其制造业)利好。但过度贬值引发BOJ干预。",
        "alert": "USDJPY > 155是BOJ干预警戒线。USDJPY < 130可能意味BOJ收紧。",
    },
    "volatility": {
        "title": "日经波动率",
        "what": "日经225收益率的60日滚动标准差(年化)。反映日本市场的波动水平。",
        "why": "高波动=不确定性大。但极端恐慌(超高波动)往往对应底部。",
        "alert": "波动率突破30% 历史分位90%以上时，留意逆向买入机会。",
    },
    "rate_env": {
        "title": "日元利率环境",
        "what": "JGB 10Y收益率的3个月变化方向 + USDJPY变化率的组合。反映BOJ政策走向。",
        "why": "JGB走高 = BOJ收紧 = 利空股市。JGB稳定/下行 = 宽松持续 = 利好。",
        "alert": "JGB突破1.5%是重要心理关口，可能引发全球债市联动。",
    }
}


class JPERPTimingEngine:
    """日本ERP择時引擎 V1.1 (Phase 1: P2 EMA持久化 + P3 Sigmoid動量)"""

    VERSION = "1.1"
    REGION = "JP"

    W = {"erp_abs": 0.20, "erp_pct": 0.25, "yen_trend": 0.30, "volatility": 0.15, "rate_env": 0.10}

    SIGNAL_MAP = {
        "strong_buy":  {"label": "Strong Buy",  "label_cn": "強力買い", "position": "80-100%", "color": "#10b981", "emoji": "🟢🟢", "level": 6},
        "buy":         {"label": "Buy",          "label_cn": "買い",     "position": "60-80%",  "color": "#34d399", "emoji": "🟢",   "level": 5},
        "hold":        {"label": "Hold",         "label_cn": "標配保有", "position": "50-70%",  "color": "#3b82f6", "emoji": "🔵",   "level": 4},
        "reduce":      {"label": "Reduce",       "label_cn": "段階縮小", "position": "30-50%",  "color": "#f59e0b", "emoji": "🟡",   "level": 3},
        "underweight": {"label": "Underweight",  "label_cn": "低配防御", "position": "10-30%",  "color": "#f97316", "emoji": "🟠",   "level": 2},
        "cash":        {"label": "Cash",         "label_cn": "清倉観望", "position": "0-10%",   "color": "#ef4444", "emoji": "🔴",   "level": 1},
    }

    ETF_TARGETS = {
        "aggressive": {"name": "TOPIX ETF",       "code": "1306.T", "desc": "日本全市場，弾性最大"},
        "balanced":   {"name": "日経225 ETF",      "code": "1321.T", "desc": "蓝筹核心，攻守兼备"},
        "defensive":  {"name": "高配当50 ETF",     "code": "1577.T", "desc": "高股息防御，稳定分红"},
    }

    def __init__(self):
        # P2: 从磁盘恢复 EMA 状态
        history = self._load_history()
        self._prev_smooth_score = history.get("prev_smooth_score")

    def _load_history(self) -> dict:
        """P2: 从 JSON 加载 EMA 状态"""
        filepath = os.path.join(CACHE_DIR, "erp_jp_daily_history.json")
        if os.path.exists(filepath):
            try:
                with open(filepath, "r", encoding="utf-8") as f:
                    return json.load(f)
            except Exception:
                pass
        return {}

    def _save_history(self, composite: float):
        """P2: 持久化 EMA 状态到 JSON"""
        filepath = os.path.join(CACHE_DIR, "erp_jp_daily_history.json")
        data = {
            "prev_smooth_score": self._prev_smooth_score,
            "last_score": composite,
            "last_date": str(datetime.now().date()),
        }
        tid = threading.get_ident()
        tmp_path = f"{filepath}.{tid}.tmp"
        try:
            with open(tmp_path, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False)
            os.replace(tmp_path, filepath)
        except Exception as e:
            logger.warning("保存状态失败: %s", e)
            if os.path.exists(tmp_path):
                try:
                    os.remove(tmp_path)
                except OSError:
                    pass

    # ========== 数据获取层 (FRED优先) ==========

    def _get_current_pe(self) -> float:
        """三级PE获取策略: FRED NIKKEI225价格估算 → 磁盘缓存 → 硬编码"""
        import json
        pe_cache_file = os.path.join(CACHE_DIR, "erp_jp_current_pe.json")

        # Tier 1: FRED NIKKEI225 最新价格 + EPS估算 (取代yfinance)
        try:
            fred = _get_jp_fred()
            if fred:
                nk = fred_get_series(
                    "NIKKEI225",
                    lambda: fred.get_series("NIKKEI225", observation_start=datetime.now() - timedelta(days=10)),
                    start=datetime.now() - timedelta(days=10),
                )
                if nk is not None and not nk.empty:
                    price = float(nk.dropna().iloc[-1])
                    estimated_eps = _get_dynamic_eps_jp()  # O1: 动态EPS
                    pe = price / estimated_eps
                    pe = max(10, min(35, pe))
                    with open(pe_cache_file, "w") as f:
                        json.dump({"pe": round(pe, 2), "source": "FRED/NIKKEI225", "ts": datetime.now().isoformat()}, f)
                    logger.info("PE from FRED NIKKEI225: %.1fx (price=¥%.0f, est_EPS=¥%.0f)", pe, price, estimated_eps)
                    return float(pe)
        except Exception as e:
            logger.warning("FRED PE failed: %s", e)

        # Tier 2: 磁盘缓存 (7天内有效)
        if os.path.exists(pe_cache_file):
            try:
                with open(pe_cache_file, "r") as f:
                    cached = json.load(f)
                cached_ts = datetime.fromisoformat(cached["ts"])
                if (datetime.now() - cached_ts).days < 7:
                    pe = cached["pe"]
                    logger.info("PE from disk cache: %.1fx (cached %s)", pe, cached['ts'][:10])
                    return float(pe)
            except Exception:
                pass

        logger.warning("PE fallback to 16.0x (all sources failed)")
        return 16.0

    def _fetch_topix_pe_history(self, years: int = 5) -> pd.DataFrame:
        """日経225 PE历史序列 (FRED NIKKEI225価格 + 三級PE獲取)

        V2.1: FRED NIKKEI225 仅返回最近数周数据(~21行)，通过与磁盘缓存
        合并来累积历史记录，确保分位数计算有足够样本量。
        """
        def _fetch():
            cache_file = os.path.join(CACHE_DIR, "erp_jp_topix_history.parquet")
            fred = _get_jp_fred()

            # 先加载旧缓存以追加历史 (FRED NIKKEI225 每次只返回~21行)
            old_df = None
            if os.path.exists(cache_file):
                try:
                    old_df = pd.read_parquet(cache_file)
                except Exception:
                    pass

            if fred:
                try:
                    start_dt = datetime.now() - timedelta(days=years * 365)
                    nk = fred_get_series(
                        "NIKKEI225",
                        lambda: fred.get_series("NIKKEI225", observation_start=start_dt),
                        start=start_dt,
                    )
                    if nk is not None and not nk.empty:
                        nk = nk.dropna()
                        df = pd.DataFrame({
                            "trade_date": nk.index.tz_localize(None) if nk.index.tz else nk.index,
                            "close": nk.values,
                        })
                        # === V2.0: 三级PE获取策略 (替代硬编码16.0) ===
                        current_pe = self._get_current_pe()
                        current_price = df["close"].iloc[-1]
                        current_eps = current_price / current_pe
                        end_dt = datetime.now()
                        eps_list = []
                        for _, row in df.iterrows():
                            m = (end_dt - row["trade_date"]).days / 30
                            eps_list.append(current_eps / (1.06 ** (m / 12)))
                        df["eps"] = eps_list
                        df["pe_ttm"] = df["close"] / df["eps"]
                        df["pe_ttm"] = df["pe_ttm"].clip(8, 40)

                        # V2.1: 与旧缓存合并 — 累积历史数据
                        if old_df is not None and not old_df.empty:
                            combined = pd.concat([old_df, df]).drop_duplicates(
                                subset=["trade_date"], keep="last"
                            ).sort_values("trade_date").reset_index(drop=True)
                            # 保留最近 years*252 行 (防止无限膨胀)
                            max_rows = years * 252
                            if len(combined) > max_rows:
                                combined = combined.tail(max_rows).reset_index(drop=True)
                            df = combined

                        df.to_parquet(cache_file)
                        logger.info("Nikkei PE (FRED): %d rows (new+hist), PE≈%.1f", len(df), current_pe)
                        return df
                except Exception as e:
                    logger.warning("FRED NIKKEI225 error: %s", e)

            if old_df is not None and not old_df.empty:
                logger.info("Nikkei PE: using disk cache (%d rows)", len(old_df))
                return old_df
            raise ValueError("Nikkei data unavailable")
        return _jp_cached("jp_topix_pe", 4 * 3600, _fetch)


    def _fetch_jgb_10y_history(self, years: int = 5) -> pd.DataFrame:
        """10Y JGB (FRED IRLTLT01JPM156N — 月频→日频填充)"""
        def _fetch():
            cache_file = os.path.join(CACHE_DIR, "erp_jp_jgb_10y.parquet")
            fred = _get_jp_fred()

            if fred:
                try:
                    start_dt = datetime.now() - timedelta(days=years * 365)
                    series = fred_get_series(
                        "IRLTLT01JPM156N",
                        lambda: fred.get_series("IRLTLT01JPM156N", observation_start=start_dt),
                        start=start_dt,
                    )
                    if series is not None and not series.empty:
                        df = pd.DataFrame({
                            "trade_date": series.index.tz_localize(None) if series.index.tz else series.index,
                            "yield_10y": series.values,
                        })
                        df = df.dropna()
                        df = df.set_index("trade_date").resample("D").ffill().reset_index()
                        df.to_parquet(cache_file)
                        logger.info("JGB 10Y (FRED): %d rows, latest=%.3f%%", len(df), df['yield_10y'].iloc[-1])
                        return df
                except Exception as e:
                    logger.warning("FRED JGB error: %s", e)

            if os.path.exists(cache_file):
                return pd.read_parquet(cache_file)

            # P0-2: 安全降级 — 不生成随机假数据污染缓存
            raise ValueError("JGB 10Y data unavailable (FRED + disk cache both failed)")
        return _jp_cached("jp_jgb_10y", 4 * 3600, _fetch)

    def _fetch_usdjpy_history(self, years: int = 3) -> pd.DataFrame:
        """USDJPY (FRED DEXJPUS — 日频)"""
        def _fetch():
            cache_file = os.path.join(CACHE_DIR, "erp_jp_usdjpy.parquet")
            fred = _get_jp_fred()

            if fred:
                try:
                    start_dt = datetime.now() - timedelta(days=years * 365)
                    series = fred_get_series(
                        "DEXJPUS",
                        lambda: fred.get_series("DEXJPUS", observation_start=start_dt),
                        start=start_dt,
                    )
                    if series is not None and not series.empty:
                        series = series.dropna()
                        df = pd.DataFrame({
                            "trade_date": series.index.tz_localize(None) if series.index.tz else series.index,
                            "usdjpy": series.values,
                        })
                        df.to_parquet(cache_file)
                        logger.info("USDJPY (FRED): %d rows, latest=%.2f", len(df), df['usdjpy'].iloc[-1])
                        return df
                except Exception as e:
                    logger.warning("FRED DEXJPUS error: %s", e)

            if os.path.exists(cache_file):
                return pd.read_parquet(cache_file)
            raise ValueError("USDJPY data unavailable")
        return _jp_cached("jp_usdjpy", 4 * 3600, _fetch)

    def _fetch_nikkei_history(self, years: int = 5) -> pd.DataFrame:
        """日经225历史 (FRED NIKKEI225)

        V2.1: 与PE历史相同逻辑 — 累积历史数据，解决FRED仅返回近期问题。
        """
        def _fetch():
            cache_file = os.path.join(CACHE_DIR, "erp_jp_nikkei.parquet")
            fred = _get_jp_fred()

            old_df = None
            if os.path.exists(cache_file):
                try:
                    old_df = pd.read_parquet(cache_file)
                except Exception:
                    pass

            if fred:
                try:
                    start_dt = datetime.now() - timedelta(days=years * 365)
                    series = fred_get_series(
                        "NIKKEI225",
                        lambda: fred.get_series("NIKKEI225", observation_start=start_dt),
                        start=start_dt,
                    )
                    if series is not None and not series.empty:
                        series = series.dropna()
                        df = pd.DataFrame({
                            "trade_date": series.index.tz_localize(None) if series.index.tz else series.index,
                            "close": series.values,
                        })
                        # V2.1: 累积历史数据
                        if old_df is not None and not old_df.empty:
                            df = pd.concat([old_df, df]).drop_duplicates(
                                subset=["trade_date"], keep="last"
                            ).sort_values("trade_date").reset_index(drop=True)
                            max_rows = years * 252
                            if len(df) > max_rows:
                                df = df.tail(max_rows).reset_index(drop=True)
                        df.to_parquet(cache_file)
                        return df
                except Exception as e:
                    logger.warning("FRED NIKKEI225 error: %s", e)

            if old_df is not None and not old_df.empty:
                return old_df
            if os.path.exists(cache_file):
                return pd.read_parquet(cache_file)
            raise ValueError("Nikkei data unavailable")
        return _jp_cached("jp_nikkei", 4 * 3600, _fetch)

    # ========== 核心计算层 ==========

    def _valuation_real(self) -> Optional[dict]:
        """P3: 日股真实 ERP 读数 (engines/jp_valuation.py)。失败返回 None, 不影响主流程。"""
        try:
            from engines import jp_valuation
            return jp_valuation.compute()
        except Exception as e:
            logger.warning("JP ERP real failed: %s", e)
            return None

    def _compute_erp_series(self) -> pd.DataFrame:
        """计算 ERP 时间序列。

        P0-1 修复: JGB (IRLTLT01JPM156N) 是月频数据且发布滞后约2个月。
        使用 merge_asof(direction="backward") 替代 pd.merge，
        为每个 PE 日期匹配最近的已知 JGB 利率数据点。
        tolerance=90D 确保滞后不超过3个月。
        """
        pe_df = self._fetch_topix_pe_history()
        jgb_df = self._fetch_jgb_10y_history()

        # 确保按日期排序 (merge_asof 要求)
        pe_sorted = pe_df.sort_values("trade_date").reset_index(drop=True)
        jgb_sorted = jgb_df.sort_values("trade_date").reset_index(drop=True)

        # merge_asof: 每个PE日期 → 向后找最近的JGB数据点 (容忍90天滞后)
        merged = pd.merge_asof(
            pe_sorted, jgb_sorted,
            on="trade_date",
            direction="backward",
            tolerance=pd.Timedelta("90D"),
        )

        merged["yield_10y"] = merged["yield_10y"].ffill().bfill()
        merged = merged.dropna(subset=["pe_ttm", "yield_10y"])

        if merged.empty:
            logger.warning("ERP merge后仍为空: PE范围=%s~%s, JGB范围=%s~%s",
                           pe_sorted['trade_date'].min(), pe_sorted['trade_date'].max(),
                           jgb_sorted['trade_date'].min(), jgb_sorted['trade_date'].max())

        merged = merged[merged["pe_ttm"] > 0].copy()
        merged["earnings_yield"] = 1.0 / merged["pe_ttm"] * 100
        merged["erp"] = merged["earnings_yield"] - merged["yield_10y"]
        return merged.sort_values("trade_date").reset_index(drop=True)

    # ========== 五维评分 ==========

    def _score_d1_erp_absolute(self, erp_val: float) -> tuple:
        """D1: ERP绝对值 (日本阈值: 比中国高~1%, 因为JGB极低)"""
        if erp_val >= 7.0:
            score, desc = 100, f"ERP {erp_val:.2f}% ≥ 7% → 极度低估，历史级机会"
        elif erp_val >= 6.0:
            score, desc = 75 + (erp_val - 6.0) * 25, f"ERP {erp_val:.2f}% 6-7%区间 → 显著低估"
        elif erp_val >= 5.0:
            score, desc = 55 + (erp_val - 5.0) * 20, f"ERP {erp_val:.2f}% 5-6%区间 → 合理偏低"
        elif erp_val >= 4.0:
            score, desc = 35 + (erp_val - 4.0) * 20, f"ERP {erp_val:.2f}% 4-5%区间 → 估值中性"
        elif erp_val >= 3.0:
            score, desc = 15 + (erp_val - 3.0) * 20, f"ERP {erp_val:.2f}% 3-4%区间 → 偏高估"
        else:
            score, desc = max(0, erp_val * 5), f"ERP {erp_val:.2f}% < 3% → 高估"
        return round(min(100, max(0, score)), 1), desc

    def _score_d2_erp_percentile(self, erp_val: float, erp_series: pd.Series) -> tuple:
        """D2: ERP历史分位 (O2: 滚动5年窗口)"""
        window = erp_series.tail(1260)  # O2: ~5年滚动窗口
        pct = (window < erp_val).mean() * 100
        if pct >= 80:   desc = f"近5年{pct:.1f}%分位 → 历史极度低估"
        elif pct >= 60: desc = f"近5年{pct:.1f}%分位 → 偏低估"
        elif pct >= 40: desc = f"近5年{pct:.1f}%分位 → 中性"
        elif pct >= 20: desc = f"近5年{pct:.1f}%分位 → 偏高估"
        else:           desc = f"近5年{pct:.1f}%分位 → 历史极度高估"
        return round(pct, 1), round(pct, 1), desc

    def _score_d3_yen_trend(self) -> tuple:
        """D3: 日元汇率趋势 (USDJPY方向)
        日元贬值(USDJPY↑) = BOJ宽松 + 出口利润↑ = 利好股市
        但 > 155 有干预风险"""
        fx_df = self._fetch_usdjpy_history()
        if fx_df.empty:
            return 50.0, {"current": 0, "direction": "unknown"}, "数据缺失"

        current = float(fx_df["usdjpy"].iloc[-1])
        prev_1m = float(fx_df["usdjpy"].iloc[-22]) if len(fx_df) >= 22 else current
        prev_3m = float(fx_df["usdjpy"].iloc[-63]) if len(fx_df) >= 63 else current

        is_weakening = current > prev_1m  # USDJPY上升 = 日元贬值
        is_3m_weakening = current > prev_3m
        change_3m = ((current - prev_3m) / prev_3m * 100) if prev_3m else 0

        yen_info = {
            "current": round(current, 2),
            "prev_month": round(prev_1m, 2),
            "3m_ago": round(prev_3m, 2),
            "direction": "weakening" if is_weakening else "strengthening",
            "3m_direction": "weakening" if is_3m_weakening else "strengthening",
            "change_3m_pct": round(change_3m, 2),
        }

        # === B4优化: 干预风险区更激进降分 ===
        if current > 160:
            score = 15  # 极度贬值→BOJ强制干预概率极高
            desc = f"USDJPY {current:.1f} > 160 → 极度贬值! BOJ强制干预迫在眉睫"
        elif current > 155:
            score = 25  # 过度贬值→BOJ干预风险高
            desc = f"USDJPY {current:.1f} > 155 → 日元过度贬值! BOJ干预警戒"
        elif current > 145 and is_3m_weakening:
            score = 65
            desc = f"USDJPY {current:.1f}，日元持续贬值 → 出口利好但需警惕"
        elif 135 <= current <= 145:
            score = 75
            desc = f"USDJPY {current:.1f} 温和弱势 → 最佳出口竞争力区间"
        elif 125 <= current < 135:
            score = 55
            desc = f"USDJPY {current:.1f} → 日元中性偏强"
        elif current < 125 and not is_3m_weakening:
            score = 25
            desc = f"USDJPY {current:.1f} < 125 → 日元大幅升值，出口承压"
        else:
            score = 50
            desc = f"USDJPY {current:.1f} → 中性"

        # 趋势加减分
        if is_3m_weakening and current <= 155:
            score = min(100, score + 10)
        elif not is_3m_weakening and current < 140:
            score = max(0, score - 10)

        return round(min(100, max(0, score)), 1), yen_info, desc

    def _score_d4_volatility(self) -> tuple:
        """D4: 日经225 实现波动率"""
        nk_df = self._fetch_nikkei_history()
        if nk_df.empty or len(nk_df) < 60:
            return 50.0, {"current": 0, "pct": 50, "regime": "normal"}, "数据不足"

        returns = nk_df["close"].pct_change().dropna()
        vol_60d = float(returns.rolling(60).std().iloc[-1] * np.sqrt(252) * 100)
        vol_series = returns.rolling(60).std().dropna() * np.sqrt(252) * 100
        vol_pct = (vol_series < vol_60d).mean() * 100

        if vol_pct >= 90:
            score, regime = 15, "extreme_panic"
            desc = f"日经波动率{vol_60d:.1f}%({vol_pct:.0f}%分位) → 极端恐慌"
        elif vol_pct >= 70:
            score, regime = 35, "high"
            desc = f"日经波动率{vol_60d:.1f}%({vol_pct:.0f}%分位) → 波动偏高"
        elif vol_pct >= 30:
            score, regime = 70, "normal"
            desc = f"日经波动率{vol_60d:.1f}%({vol_pct:.0f}%分位) → 正常"
        else:
            score, regime = 85, "calm"
            desc = f"日经波动率{vol_60d:.1f}%({vol_pct:.0f}%分位) → 市场平稳"

        vol_info = {"current": round(vol_60d, 1), "pct": round(vol_pct, 1), "regime": regime}
        return round(score, 1), vol_info, desc

    def _score_d5_rate_env(self) -> tuple:
        """D5: 日本利率环境 (JGB方向 + USDJPY变化率)"""
        jgb_df = self._fetch_jgb_10y_history()
        fx_df = self._fetch_usdjpy_history()

        jgb_now = float(jgb_df["yield_10y"].iloc[-1]) if not jgb_df.empty else 0.8
        jgb_3m = float(jgb_df["yield_10y"].iloc[-63]) if len(jgb_df) >= 63 else jgb_now

        jgb_rising = jgb_now > jgb_3m + 0.1  # JGB上升超0.1% = 收紧
        jgb_falling = jgb_now < jgb_3m - 0.05

        fx_now = float(fx_df["usdjpy"].iloc[-1]) if not fx_df.empty else 150
        fx_3m = float(fx_df["usdjpy"].iloc[-63]) if len(fx_df) >= 63 else fx_now
        fx_change = ((fx_now - fx_3m) / fx_3m * 100) if fx_3m else 0

        rate_info = {
            "jgb_now": round(jgb_now, 3),
            "jgb_3m_ago": round(jgb_3m, 3),
            "jgb_direction": "rising" if jgb_rising else ("falling" if jgb_falling else "stable"),
            "usdjpy_change_3m": round(fx_change, 2),
        }

        # JGB上升 = BOJ收紧 = 利空
        if jgb_now > 1.5:
            score = 20
            desc = f"JGB {jgb_now:.3f}% > 1.5% → BOJ收紧信号，利空权益"
        elif jgb_rising:
            score = 35
            desc = f"JGB {jgb_now:.3f}% 上行中 → BOJ渐进收紧"
        elif jgb_falling:
            score = 80
            desc = f"JGB {jgb_now:.3f}% 下行 → BOJ维持/加大宽松"
        elif jgb_now < 0.5:
            score = 85
            desc = f"JGB {jgb_now:.3f}% 极低 → 超宽松环境"
        else:
            score = 60
            desc = f"JGB {jgb_now:.3f}% 稳定 → 政策中性"

        return round(min(100, max(0, score)), 1), rate_info, desc

    # ========== 买卖规则引擎 ==========

    # O7: ERP動量修正 — P3: Sigmoid 連続映射
    def _erp_momentum_modifier(self, erp_series) -> tuple:
        if len(erp_series) < 63:
            return 0, "データ不足"
        current = float(erp_series.iloc[-1])
        past = float(erp_series.iloc[-63])
        if abs(past) < 0.01:
            return 0, "基準値過小"
        momentum_pct = (current - past) / abs(past) * 100
        import math
        scale = erp_params.O7_MOMENTUM_SCALE
        k = erp_params.O7_MOMENTUM_K
        x = max(-30, min(30, momentum_pct))
        mod = scale * (2.0 / (1.0 + math.exp(-k * x)) - 1.0)
        mod = round(mod, 1)
        if mod > 0:
            desc = f"ERP 3月動量+{momentum_pct:.0f}% → 価値回帰({mod:+.1f})"
        elif mod < 0:
            desc = f"ERP 3月動量{momentum_pct:.0f}% → 估値悪化({mod:+.1f})"
        else:
            desc = f"ERP 3月動量{momentum_pct:+.0f}% → 中性"
        return mod, desc

    # O8: EMA平滑 — P2: α参数中心読取, 状態持久化
    def _smooth_composite(self, raw_score: float) -> float:
        if self._prev_smooth_score is None:
            self._prev_smooth_score = raw_score
            return raw_score
        alpha = erp_params.O8_EMA_ALPHA
        smooth = alpha * raw_score + (1 - alpha) * self._prev_smooth_score
        self._prev_smooth_score = smooth
        return round(smooth, 1)

    def _generate_trade_rules(self, score, dims, snap) -> dict:
        erp = snap.get("erp_value", 5.0)
        vol_info = dims.get("volatility", {}).get("vol_info", {})
        vol_regime = vol_info.get("regime", "normal")
        vol_pct = vol_info.get("pct", 50)
        yen_info = dims.get("yen_trend", {}).get("yen_info", {})
        usdjpy = yen_info.get("current", 150)
        rate_info = dims.get("rate_env", {}).get("rate_info", {})
        jgb = rate_info.get("jgb_now", 0.8)

        d1s = dims.get("erp_abs", {}).get("score", 50)
        d2s = dims.get("erp_pct", {}).get("score", 50)
        d3s = dims.get("yen_trend", {}).get("score", 50)

        bullish_count = sum([d1s >= 60, d2s >= 60, d3s >= 60])
        bearish_count = sum([d1s < 35, d2s < 35, d3s < 35])

        resonance = "none"
        if bullish_count >= 3: resonance = "bullish_resonance"
        elif bearish_count >= 3: resonance = "bearish_resonance"
        elif bullish_count >= 1 and bearish_count >= 1: resonance = "divergence"

        if score >= 80 and resonance == "bullish_resonance": signal_key = "strong_buy"
        elif score >= 70: signal_key = "buy"
        elif score >= 55: signal_key = "hold"
        elif score >= 40: signal_key = "reduce"
        elif score >= 25: signal_key = "underweight"
        else: signal_key = "cash"

        if vol_regime == "extreme_panic" and erp >= 5.0:
            if signal_key in ("hold", "reduce"): signal_key = "buy"

        signal = self.SIGNAL_MAP[signal_key]

        if signal_key in ("strong_buy", "buy"):
            etf_advice = [
                {"etf": self.ETF_TARGETS["balanced"], "ratio": "50%", "reason": "核心配置"},
                {"etf": self.ETF_TARGETS["aggressive"], "ratio": "30%", "reason": "弹性进攻"},
                {"etf": self.ETF_TARGETS["defensive"], "ratio": "20%", "reason": "安全垫"},
            ]
        elif signal_key == "hold":
            etf_advice = [
                {"etf": self.ETF_TARGETS["balanced"], "ratio": "40%", "reason": "核心底仓"},
                {"etf": self.ETF_TARGETS["defensive"], "ratio": "40%", "reason": "防御为主"},
                {"etf": self.ETF_TARGETS["aggressive"], "ratio": "20%", "reason": "保留弹性"},
            ]
        else:
            etf_advice = [
                {"etf": self.ETF_TARGETS["defensive"], "ratio": "60%", "reason": "防御优先"},
                {"etf": self.ETF_TARGETS["balanced"], "ratio": "30%", "reason": "保留底仓"},
                {"etf": self.ETF_TARGETS["aggressive"], "ratio": "10%", "reason": "观察仓"},
            ]

        # === B1: 动态高亮 ===
        take_profit = [
            {"trigger": "ERP 回落至 4.0% 以下", "action": "减仓20%", "type": "valuation",
             "triggered": bool(erp < 4.0), "current": f"ERP={erp:.2f}%"},
            {"trigger": "USDJPY < 130 (日元大幅升值)", "action": "减仓30%", "type": "yen",
             "triggered": bool(usdjpy < 130), "current": f"USDJPY={usdjpy:.1f}"},
            {"trigger": "综合得分跌破 50", "action": "降至标配", "type": "score_drop",
             "triggered": bool(score < 50), "current": f"得分={score:.0f}"},
        ]

        stop_loss = [
            {"trigger": "ERP ≥ 8% (极端低估)", "action": "逆向加仓20%", "type": "contrarian_buy", "color": "#10b981",
             "triggered": bool(erp >= 8.0), "current": f"ERP={erp:.2f}%"},
            {"trigger": "日经波动率90%分位+ERP>5%", "action": "恐慌+低估=加仓", "type": "contrarian_vol", "color": "#10b981",
             "triggered": bool(vol_pct >= 90 and erp > 5.0), "current": f"波动={vol_pct:.0f}%,ERP={erp:.2f}%"},
            {"trigger": "ERP < 3% (日本罕见高估)", "action": "硬止损: 清仓", "type": "hard_stop", "color": "#ef4444",
             "triggered": bool(erp < 3.0), "current": f"ERP={erp:.2f}%"},
            {"trigger": "JGB > 2.0% (BOJ急收紧)", "action": "降至20%以下", "type": "rate_shock", "color": "#ef4444",
             "triggered": bool(jgb > 2.0), "current": f"JGB={jgb:.3f}%"},
        ]

        return {
            "signal_key": signal_key, "signal": signal, "resonance": resonance,
            "resonance_label": {"bullish_resonance": "🟢 三维共振看多", "bearish_resonance": "🔴 三维共振看空",
                                "divergence": "🟡 信号分歧", "none": "⚪ 中性"}[resonance],
            "etf_advice": etf_advice, "take_profit": take_profit, "stop_loss": stop_loss,
        }

    # ========== 警示系统 ==========

    def _generate_alerts(self, score, erp, pct, yen_info, vol_info, rate_info) -> list:
        alerts = []
        usdjpy = yen_info.get("current", 150)
        jgb = rate_info.get("jgb_now", 0.8)

        if erp < 3.0:
            alerts.append({"level": "danger", "icon": "🔴", "text": f"ERP {erp:.2f}% < 3%, 日股罕见高估", "pulse": True})
        if usdjpy > 155:
            alerts.append({"level": "danger", "icon": "🔴", "text": f"USDJPY {usdjpy:.1f} > 155! BOJ干预风险", "pulse": True})
        if jgb > 1.5:
            alerts.append({"level": "danger", "icon": "🔴", "text": f"JGB {jgb:.3f}% > 1.5%, BOJ加速收紧", "pulse": True})

        if 3.0 <= erp < 4.5:
            alerts.append({"level": "warning", "icon": "🟡", "text": f"ERP {erp:.2f}% 偏低(日本标准)"})
        if 150 < usdjpy <= 155:
            alerts.append({"level": "warning", "icon": "🟡", "text": f"USDJPY {usdjpy:.1f} 接近干预警戒线"})

        if erp >= 7.0:
            alerts.append({"level": "opportunity", "icon": "🟢", "text": f"ERP {erp:.2f}% ≥ 7% 历史级低估!", "pulse": True})
        if pct >= 80:
            alerts.append({"level": "opportunity", "icon": "🟢", "text": f"分位{pct:.1f}% 历史低估区"})

        return alerts if alerts else [{"level": "normal", "icon": "⚪", "text": "无特殊警示"}]

    # ========== 诊断卡片 ==========

    def _build_diagnosis(self, erp, pe, jgb, pct, yen_info, vol_info, rate_info, trade) -> list:
        cards = []
        usdjpy = yen_info.get("current", 150)
        signal = trade["signal"]

        if erp >= 5.5:
            cards.append({"type": "success", "title": "估值 · 低估", "text": f"TOPIX PE {pe:.1f}x, ERP={erp:.2f}%。JGB {jgb:.3f}% 极低→ 日股性价比突出。"})
        elif erp >= 4.0:
            cards.append({"type": "info", "title": "估值 · 中性", "text": f"PE {pe:.1f}x, ERP={erp:.2f}% 日本标准中性区间。"})
        else:
            cards.append({"type": "warning", "title": "估值 · 偏高", "text": f"PE {pe:.1f}x, ERP {erp:.2f}% 低于日本历史中位数。"})

        if pct >= 70:
            cards.append({"type": "success", "title": "分位 · 低估", "text": f"{pct:.0f}%分位。"})
        elif pct >= 40:
            cards.append({"type": "info", "title": "分位 · 中性", "text": f"{pct:.0f}%分位。"})
        else:
            cards.append({"type": "warning", "title": "分位 · 偏贵", "text": f"仅{pct:.0f}%分位。"})

        if 135 <= usdjpy <= 150:
            cards.append({"type": "success", "title": "日元 · 甜蜜区", "text": f"USDJPY {usdjpy:.1f}，温和弱势，出口利好最大。"})
        elif usdjpy > 150:
            cards.append({"type": "warning", "title": "日元 · 过度贬值", "text": f"USDJPY {usdjpy:.1f}，干预风险上升。"})
        else:
            cards.append({"type": "info", "title": "日元 · 偏强", "text": f"USDJPY {usdjpy:.1f}，出口竞争力受压。"})

        vol_regime = vol_info.get("regime", "normal")
        if vol_regime in ("extreme_panic", "high"):
            cards.append({"type": "warning", "title": "波动率 · 异常", "text": "日经波动显著放大。"})
        else:
            cards.append({"type": "success", "title": "波动率 · 正常", "text": "市场波动可控。"})

        jgb_dir = rate_info.get("jgb_direction", "stable")
        jgb_now = rate_info.get("jgb_now", 0.8)
        if jgb_dir == "rising":
            cards.append({"type": "warning", "title": "利率 · 上行", "text": f"JGB {jgb_now:.3f}% 上行中，BOJ渐进收紧。"})
        else:
            cards.append({"type": "success", "title": "利率 · 宽松", "text": f"JGB {jgb_now:.3f}% 稳定/下行。"})

        etf_text = " / ".join([f"{e['etf']['name']}{e['ratio']}" for e in trade.get("etf_advice", [])])
        cards.append({"type": "info", "title": f"操作 · {signal['label_cn']}", "text": f"{trade['resonance_label']}。仓位{signal['position']}。配置: {etf_text}。"})

        return cards

    # ========== 信号融合 ==========

    def compute_signal(self) -> dict:
        try:
            erp_df = self._compute_erp_series()
            if erp_df.empty:
                return self._fallback_signal("ERP序列为空")

            latest = erp_df.iloc[-1]
            erp_val = float(latest["erp"])
            pe_ttm = float(latest["pe_ttm"])
            yield_10y = float(latest["yield_10y"])

            d1_score, d1_desc = self._score_d1_erp_absolute(erp_val)
            d2_score, d2_pct, d2_desc = self._score_d2_erp_percentile(erp_val, erp_df["erp"])
            d3_score, yen_info, d3_desc = self._score_d3_yen_trend()
            d4_score, vol_info, d4_desc = self._score_d4_volatility()
            d5_score, rate_info, d5_desc = self._score_d5_rate_env()

            # O10: 权重自适应
            vol_regime = vol_info.get("regime", "normal")
            # 2026-10-31 P0: 海外引擎修正器未经验证, 默认停用 (erp_params.OVERSEAS_MODIFIERS_ENABLED)
            aw = adaptive_weights(self.W, "volatility", vol_regime) if erp_params.OVERSEAS_MODIFIERS_ENABLED else dict(self.W)

            composite = round(
                d1_score * aw["erp_abs"] + d2_score * aw["erp_pct"] +
                d3_score * aw["yen_trend"] + d4_score * aw["volatility"] +
                d5_score * aw["rate_env"], 1
            )

            # O7: ERP动量修正
            momentum_mod, momentum_desc = self._erp_momentum_modifier(erp_df["erp"])
            if erp_params.OVERSEAS_MODIFIERS_ENABLED:
                composite = round(min(100, max(0, composite + momentum_mod)), 1)

            # O11: 多时间框架确认
            mtf = multi_timeframe_confirmation(erp_df["erp"], composite)
            if erp_params.OVERSEAS_MODIFIERS_ENABLED:  # 多时框标签仍展示, 不再加减分
                composite = round(min(100, max(0, composite + mtf["confidence_mod"])), 1)

            # O8: EMA平滑
            if erp_params.OVERSEAS_MODIFIERS_ENABLED:
                composite = self._smooth_composite(composite)

            snap = {
                "pe_ttm": round(pe_ttm, 2), "yield_10y": round(yield_10y, 4),
                "earnings_yield": round(1.0 / pe_ttm * 100, 2), "erp_value": round(erp_val, 2),
                "erp_percentile": round(d2_pct, 1), "trade_date": latest["trade_date"].strftime("%Y-%m-%d"),
            }
            snap["data_quality"] = overseas_data_quality("JP")
            # P3: 真实数据读数 (JPX 加权 PER + 财务省 JGB 10Y); 不分位、不分档。数据缺失时为 None, 页面回退到"仅读数"
            real = self._valuation_real()
            snap["valuation_real"] = real
            if real:
                snap["data_quality"] = {
                    "grade": "real_data", "grade_cn": "真实PE",
                    "eps_source": "jpx_weighted_per", "eps_source_cn": f"{real['per_basis']} ({real['per_month']})",
                    "history_synthetic": False, "rate_basis": f"{real['rate_basis']} {real['jgb_date']}",
                    "note": real["note"], "eps_stale": real["per_stale"] or real["jgb_stale"],
                }

            dims = {
                "erp_abs":    {"score": d1_score, "weight": self.W["erp_abs"], "label": "ERP絶対値", "desc": d1_desc},
                "erp_pct":    {"score": d2_score, "weight": self.W["erp_pct"], "label": "ERP分位", "desc": d2_desc, "percentile": d2_pct},
                "yen_trend":  {"score": d3_score, "weight": self.W["yen_trend"], "label": "日元趋势", "desc": d3_desc, "yen_info": yen_info},
                "volatility": {"score": d4_score, "weight": self.W["volatility"], "label": "日経波動率", "desc": d4_desc, "vol_info": vol_info},
                "rate_env":   {"score": d5_score, "weight": self.W["rate_env"], "label": "利率環境", "desc": d5_desc, "rate_info": rate_info},
                "erp_momentum": {"score": momentum_mod, "weight": 0, "label": "ERP动量", "desc": momentum_desc},
            }

            trade = self._generate_trade_rules(composite, dims, snap)
            alerts = self._generate_alerts(composite, erp_val, d2_pct, yen_info, vol_info, rate_info)
            diagnosis = self._build_diagnosis(erp_val, pe_ttm, yield_10y, d2_pct, yen_info, vol_info, rate_info, trade)

            # P2: 持久化 EMA 状态
            self._save_history(composite)

            return {
                "status": "success", "region": "JP",
                "adaptive_weights": aw,  # O10
                "multi_timeframe": mtf,  # O11
                "current_snapshot": snap, "signal": {
                    "score": composite, "key": trade["signal_key"],
                    "label": trade["signal"]["label_cn"], "position": trade["signal"]["position"],
                    "color": trade["signal"]["color"], "emoji": trade["signal"]["emoji"],
                },
                "dimensions": dims, "trade_rules": trade,
                "alerts": alerts, "diagnosis": diagnosis, "encyclopedia": ENCYCLOPEDIA_JP,
            }
        except Exception as e:
            logger.error("JP ERP compute_signal 降級: %s", e, exc_info=True)
            return self._fallback_signal(str(e))

    def get_erp_chart_data(self) -> dict:
        try:
            erp_df = self._compute_erp_series()
            sampled = erp_df.iloc[::3].copy()
            erp_mean = float(erp_df["erp"].mean())
            erp_std = float(erp_df["erp"].std())
            return {
                "status": "success",
                "dates": sampled["trade_date"].dt.strftime("%Y-%m-%d").tolist(),
                "erp": sampled["erp"].round(2).tolist(),
                "pe_ttm": sampled["pe_ttm"].round(2).tolist(),
                "yield_10y": sampled["yield_10y"].round(2).tolist(),
                "stats": {
                    "mean": round(erp_mean, 2), "std": round(erp_std, 2),
                    "overweight_line": round(erp_mean + 0.5 * erp_std, 2),
                    "underweight_line": round(erp_mean - 0.5 * erp_std, 2),
                    "current": round(float(erp_df["erp"].iloc[-1]), 2),
                }
            }
        except Exception as e:
            return {"status": "error", "message": str(e)}

    def generate_report(self) -> dict:
        signal = self.compute_signal()
        chart = self.get_erp_chart_data()
        return {**signal, "chart": chart, "engine_version": self.VERSION, "region": self.REGION, "updated_at": datetime.now().isoformat()}

    def _fallback_signal(self, reason):
        # Fallback 降級數據 — 必須包含前端 renderRegionPanel() 所需的完整嵌套結構:
        #   yen_trend.yen_info  → USD/JPY 卡片
        #   volatility.vol_info → 日経波動率 卡片
        #   rate_env.rate_info  → 利率環境 卡片
        #   trade_rules.etf_advice / take_profit / stop_loss → 買賣信号中枢
        fallback_erp = 5.6
        fallback_pe = 15.5
        fallback_jgb = 0.85
        fallback_usdjpy = 143.0
        fallback_vol = 18.0

        fallback_dims = {
            "erp_abs":    {"score": 50, "weight": self.W["erp_abs"],    "label": "ERP絶対値", "desc": f"ERP {fallback_erp:.2f}% (降級推定)"},
            "erp_pct":    {"score": 50, "weight": self.W["erp_pct"],    "label": "ERP分位",   "desc": "降級: 分位不可用", "percentile": 50.0},
            "yen_trend":  {"score": 50, "weight": self.W["yen_trend"],  "label": "日元趋势",  "desc": f"USDJPY {fallback_usdjpy:.1f} (降級推定)",
                           "yen_info": {"current": fallback_usdjpy, "prev_month": fallback_usdjpy, "3m_ago": fallback_usdjpy,
                                        "direction": "stable", "3m_direction": "stable", "change_3m_pct": 0.0}},
            "volatility": {"score": 50, "weight": self.W["volatility"], "label": "日経波動率", "desc": f"波動率 {fallback_vol:.1f}% (降級推定)",
                           "vol_info": {"current": fallback_vol, "pct": 50.0, "regime": "normal"}},
            "rate_env":   {"score": 50, "weight": self.W["rate_env"],   "label": "利率環境",  "desc": f"JGB {fallback_jgb:.3f}% (降級推定)",
                           "rate_info": {"jgb_now": fallback_jgb, "jgb_3m_ago": fallback_jgb,
                                         "jgb_direction": "stable", "usdjpy_change_3m": 0.0}},
        }

        fallback_trade = {
            "signal_key": "hold", "signal": self.SIGNAL_MAP["hold"],
            "resonance": "none", "resonance_label": "⚪ 降級",
            "etf_advice": [
                {"etf": self.ETF_TARGETS["balanced"],  "ratio": "40%", "reason": "核心底仓(降級)"},
                {"etf": self.ETF_TARGETS["defensive"], "ratio": "40%", "reason": "防御為主(降級)"},
                {"etf": self.ETF_TARGETS["aggressive"],"ratio": "20%", "reason": "弾性保留(降級)"},
            ],
            "take_profit": [
                {"trigger": f"ERP 回落至 4.0% 以下", "action": "減倉20%", "type": "valuation",
                 "triggered": bool(fallback_erp < 4.0), "current": f"ERP={fallback_erp:.2f}%"},
                {"trigger": f"USDJPY < 130 (日元大幅升値)", "action": "減倉30%", "type": "yen",
                 "triggered": bool(fallback_usdjpy < 130), "current": f"USDJPY={fallback_usdjpy:.1f}"},
                {"trigger": "綜合得分跌破 50", "action": "降至標配", "type": "score_drop",
                 "triggered": False, "current": "得分=60(降級)"},
            ],
            "stop_loss": [
                {"trigger": "ERP ≥ 8% (極端低估)", "action": "逆向加倉20%", "type": "contrarian_buy", "color": "#10b981",
                 "triggered": bool(fallback_erp >= 8.0), "current": f"ERP={fallback_erp:.2f}%"},
                {"trigger": f"ERP < 3% (日本罕見高估)", "action": "硬止損: 清倉", "type": "hard_stop", "color": "#ef4444",
                 "triggered": bool(fallback_erp < 3.0), "current": f"ERP={fallback_erp:.2f}%"},
                {"trigger": f"JGB > 2.0% (BOJ急收緊)", "action": "降至20%以下", "type": "rate_shock", "color": "#ef4444",
                 "triggered": bool(fallback_jgb > 2.0), "current": f"JGB={fallback_jgb:.3f}%"},
            ],
        }

        return {
            "status": "fallback", "region": "JP", "message": f"数据异常: {reason}",
            "current_snapshot": {
                "pe_ttm": fallback_pe, "yield_10y": fallback_jgb,
                "earnings_yield": round(1.0 / fallback_pe * 100, 2),
                "erp_value": fallback_erp, "erp_percentile": 55.0,
                "trade_date": datetime.now().strftime("%Y-%m-%d"),
            },
            "signal": {"score": 50, "key": "unavailable", "label": "数据不可用", "position": "—", "color": "#64748b", "emoji": ""},
            "dimensions": fallback_dims,
            "trade_rules": fallback_trade,
            "alerts": [{"level": "warning", "icon": "🟡", "text": f"⚠️ 降級模式: {reason}"}],
            "diagnosis": [{"type": "warning", "title": "降級模式", "text": f"FRED數據源不可用: {reason}。面板顯示推定值，不代表實時市場狀態。"}],
            "encyclopedia": ENCYCLOPEDIA_JP,
        }


_jp_engine = None
def get_jp_erp_engine() -> JPERPTimingEngine:
    global _jp_engine
    if _jp_engine is None:
        _jp_engine = JPERPTimingEngine()
    return _jp_engine


if __name__ == "__main__":
    engine = JPERPTimingEngine()
    print("=== JP ERP Timing Engine V1.0 Self-Test ===")
    report = engine.generate_report()
    if report.get("status") == "success":
        snap = report["current_snapshot"]
        sig = report["signal"]
        print(f"TOPIX PE: {snap['pe_ttm']} | JGB 10Y: {snap['yield_10y']}% | ERP: {snap['erp_value']}%")
        print(f"分位: {snap['erp_percentile']}% | 得分: {sig['score']} | {sig['emoji']} {sig['label']} ({sig['position']})")
        for d, v in report["dimensions"].items():
            print(f"  {v['label']}: {v['score']} ({v.get('desc','')})")
    else:
        print(f"Fallback: {report.get('message')}")
