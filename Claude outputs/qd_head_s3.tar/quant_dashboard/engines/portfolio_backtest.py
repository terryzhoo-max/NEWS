"""
AlphaCore V5.0 · 子策略配额 · ETF 持有收益代理回测
============================================================
研究用途: 观察 V5 配额矩阵在 ETF 持有收益代理上的历史表现。

⚠ 口径 (2026-10-27 F2 修复, 版本 BACKTEST_VERSION):
  · 收益来自 ETF 月末复权收盘 (fund_daily × fund_adj, 含分红) 收益, 是"持有对应 ETF"的代理,
    不是 MR / 动量 / GEM / ERP 等子策略的真实交易业绩。
  · 时序: t 月末才能得到的 AIAE regime / 仓位上限, 只作用于 t+1 月收益;
    无前月信号的首月不参与评价。
  · 数据性质逐资产标注 (real / synthetic); 合成收益只在 allow_synthetic=True 时生成,
    仅用于演示与软件测试, 结果标记 synthetic_demo_only, 不写入结果文件。
  · 缺失资产不再用固定年化收益填补; 只评价全部资产都有真实收益的月份。
  · 结果 is_performance_evidence 恒为 False: 本代理回测不能作为策略有效性证据。
  · 已知未解决: aiae_true_history 的历史数据是否存在事后修订未核查 (见实施记录)。

旧版 (同月信号 × 同月收益、静默合成回退、固定收益填充) 的结果文件读取时标记
evidence_status = invalidated_legacy, 原内容保留。

ETF 代理:
  · mr  → 沪深300ETF (510300)    · div → 红利低波100 (515100)
  · mom → 创业板ETF (159915)     · gem → 黄金ETF (518880)
  · erp → 国债ETF (511010)

用法: python engines/portfolio_backtest.py
"""

import sys
import os
import json
import numpy as np
import pandas as pd
from datetime import datetime, timezone

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


BACKTEST_VERSION = "portfolio-proxy-v2.1-lagged-signal-adj"
V5_KEY = "V5配额_ETF持有代理"

SOURCE_REAL = "real_tushare_fund_daily_x_fund_adj"
SOURCE_SYNTHETIC = "synthetic_seed42_demo_only"

# ═══════════════════════════════════════════════════════
#  子策略 ETF 代理标的 (不是子策略本身)
# ═══════════════════════════════════════════════════════

STRATEGY_PROXY = {
    "mr":  {"code": "510300.SH", "name": "沪深300ETF"},
    "div": {"code": "515100.SH", "name": "红利低波100"},
    "mom": {"code": "159915.SZ", "name": "创业板ETF"},
    "gem": {"code": "518880.SH", "name": "黄金ETF"},
    "erp": {"code": "511010.SH", "name": "国债ETF"},
}
ASSETS = list(STRATEGY_PROXY)

# 现金收益率 (年化, 假设值)
CASH_RATE = 0.02

_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def _cache_paths():
    base = os.path.join(_ROOT, "data_lake", "portfolio_backtest_returns")
    return base + ".parquet", base + ".provenance.json"


def _results_path():
    return os.path.join(_ROOT, "portfolio_backtest_results.json")


def _prev_month(month: str) -> str:
    y, m = int(month[:4]), int(month[5:7])
    y, m = (y - 1, 12) if m == 1 else (y, m - 1)
    return f"{y:04d}-{m:02d}"


# ═══════════════════════════════════════════════════════
#  月收益数据
# ═══════════════════════════════════════════════════════

def _fetch_monthly_returns(start_month: str = "2018-01", allow_synthetic: bool = False):
    """返回 (returns_df, provenance{asset: source}, error)。

    只接受带来源记录 (provenance sidecar) 的缓存; 旧缓存没有来源记录, 无法确认是否含
    固定收益填充, 因此忽略 (不删除) 并重新获取。获取失败时默认返回错误, 不合成。
    """
    cache_path, prov_path = _cache_paths()
    if os.path.exists(cache_path) and os.path.exists(prov_path):
        try:
            with open(prov_path, "r", encoding="utf-8") as f:
                meta = json.load(f)
            df = pd.read_parquet(cache_path)
            if meta.get("version") == BACKTEST_VERSION and len(df) > 12:
                print(f"[代理回测] 使用带来源记录的缓存: {len(df)} 月")
                return df, dict(meta["provenance"]), None
        except Exception as e:  # 损坏的缓存视为不可用
            print(f"[代理回测] 缓存不可用: {e}")

    try:
        df, prov = _fetch_from_tushare(start_month)
        os.makedirs(os.path.dirname(cache_path), exist_ok=True)
        df.to_parquet(cache_path)
        with open(prov_path, "w", encoding="utf-8") as f:
            json.dump({"version": BACKTEST_VERSION, "provenance": prov,
                       "fetched_at": datetime.now(timezone.utc).isoformat()},
                      f, ensure_ascii=False, indent=2)
        return df, prov, None
    except Exception as e:
        if not allow_synthetic:
            print(f"[代理回测] 真实行情不可用 ({e}); 未启用合成数据, 不生成结果")
            return None, None, f"真实行情不可用: {e}"
        print(f"[代理回测] 真实行情不可用 ({e}); allow_synthetic=True, 生成演示用合成收益")
        df = _generate_synthetic_returns(start_month)
        return df, {k: SOURCE_SYNTHETIC for k in ASSETS}, None


def _fetch_paged(fn, ts_code: str, start_date: str, end_date: str) -> pd.DataFrame:
    """按年分段请求, 避免单次返回条数上限截断历史。"""
    frames = []
    for year in range(int(start_date[:4]), int(end_date[:4]) + 1):
        s = max(start_date, f"{year}0101")
        e = min(end_date, f"{year}1231")
        df = fn(ts_code=ts_code, start_date=s, end_date=e)
        if df is not None and not df.empty:
            frames.append(df)
    if not frames:
        return pd.DataFrame()
    return pd.concat(frames, ignore_index=True).drop_duplicates("trade_date")


def _monthly_adjusted_returns(daily: pd.DataFrame, adj: pd.DataFrame) -> pd.Series:
    """日线收盘 × 复权因子 → 月末复权价 → 月收益。缺少某日复权因子则该日不用 (不猜)。"""
    m = daily[["trade_date", "close"]].merge(adj[["trade_date", "adj_factor"]], on="trade_date", how="inner")
    m = m.dropna().sort_values("trade_date")
    m["adj_close"] = m["close"].astype(float) * m["adj_factor"].astype(float)
    m["month"] = m["trade_date"].astype(str).str[:4] + "-" + m["trade_date"].astype(str).str[4:6]
    return m.groupby("month")["adj_close"].last().pct_change().dropna()


def _fetch_from_tushare(start_month: str, api=None):
    """从 Tushare 获取 ETF 复权月收益 (fund_daily × fund_adj); 缺失资产保持缺失。

    不使用 ts.pro_bar: 当前安装版本 asset='FD' 时 freq='M' 无分支 (UnboundLocalError →
    'ERROR.'), 且 adj 仅对股票生效, 基金只会得到未复权价格 (分红被算成下跌)。
    """
    if api is None:
        import tushare as ts
        from config import TUSHARE_TOKEN
        ts.set_token(TUSHARE_TOKEN)
        api = ts.pro_api()

    # 需要 start_month 前一个月的月末价来计算 start_month 的收益
    start_date = _prev_month(start_month).replace("-", "") + "01"
    end_date = datetime.now().strftime("%Y%m%d")

    all_returns, prov = {}, {}
    for key, proxy in STRATEGY_PROXY.items():
        code = proxy["code"]
        try:
            daily = _fetch_paged(api.fund_daily, code, start_date, end_date)
            if daily.empty:
                prov[key] = "missing_daily"
                print(f"  [MISSING] {proxy['name']}({code}): 无日线 (保持缺失)")
                continue
            adj = _fetch_paged(api.fund_adj, code, start_date, end_date)
            if adj.empty:
                prov[key] = "missing_adj_factor"
                print(f"  [MISSING] {proxy['name']}({code}): 无复权因子, 拒绝使用未复权价格 (保持缺失)")
                continue
            rets = _monthly_adjusted_returns(daily, adj)
            all_returns[key] = rets
            prov[key] = SOURCE_REAL
            print(f"  [OK] {proxy['name']}({code}): {len(rets)} 月 ({rets.index.min()}~{rets.index.max()})")
        except Exception as e:
            prov[key] = "fetch_error"
            print(f"  [MISSING] {proxy['name']}({code}): {type(e).__name__}: {e} (保持缺失)")

    if not all_returns:
        raise ValueError(f"全部 ETF 行情获取失败: {prov}")
    result = pd.DataFrame(all_returns).reindex(columns=ASSETS)
    result.index.name = 'month'
    result = result.sort_index()
    result = result[result.index >= start_month]
    return result, prov


def _generate_synthetic_returns(start_month: str) -> pd.DataFrame:
    """合成收益 (正态, seed=42)。仅用于演示和软件测试, 不得作为业绩证据。"""
    params = {
        "mr":  (0.006, 0.065),
        "div": (0.008, 0.040),
        "mom": (0.005, 0.085),
        "gem": (0.004, 0.035),
        "erp": (0.0025, 0.008),
    }
    months = pd.date_range(start_month + "-01", datetime.now(), freq='MS')
    month_strs = [m.strftime("%Y-%m") for m in months]
    rng = np.random.default_rng(42)
    data = {key: rng.normal(mu, sigma, len(month_strs)) for key, (mu, sigma) in params.items()}
    df = pd.DataFrame(data, index=month_strs)
    df.index.name = 'month'
    print(f"[代理回测] 合成收益矩阵: {len(df)} 月 (seed=42, demo only)")
    return df


# ═══════════════════════════════════════════════════════
#  组合模拟 (纯函数)
# ═══════════════════════════════════════════════════════

def _metrics(navs, rets, n_months):
    n_years = n_months / 12
    cagr = navs[-1] ** (1 / n_years) - 1 if n_years > 0 and navs[-1] > 0 else 0
    peak, mdd = 1.0, 0.0
    for n in navs:
        peak = max(peak, n)
        mdd = max(mdd, (peak - n) / peak)
    sd = np.std(rets) if len(rets) > 2 else 0
    sharpe = (np.mean(rets) / sd) * np.sqrt(12) if sd > 0 else 0
    return {
        "final_nav": round(navs[-1], 4),
        "cagr_pct": round(cagr * 100, 2),
        "mdd_pct": round(mdd * 100, 2),
        "sharpe": round(float(sharpe), 2),
        "calmar": round(cagr / mdd, 2) if mdd > 0 else 0,
        "win_rate": round(sum(1 for r in rets if r > 0) / len(rets) * 100, 1) if rets else 0,
        "months": n_months,
    }


def simulate(signals_by_month: dict, returns: pd.DataFrame, provenance: dict,
             alloc_table: dict = None) -> dict:
    """signals_by_month: {"YYYY-MM": {"regime", "cap"(0-1), "aiae"}} — 该月月末得到的信号。
    returns: 行为收益月份、列为资产的月收益。t 月收益只使用 t-1 月末信号。"""
    if alloc_table is None:
        from engines.aiae_params import SUB_STRATEGY_ALLOC as alloc_table

    eligible, excluded_missing, excluded_no_signal = [], 0, 0
    for month in sorted(returns.index):
        row = returns.loc[month, ASSETS] if all(a in returns.columns for a in ASSETS) else None
        if row is None or row.isna().any():
            excluded_missing += 1
            continue
        if _prev_month(month) not in signals_by_month:
            excluded_no_signal += 1
            continue
        eligible.append(month)
    # 只取连续区间: 从第一个可评价月份起遇到缺口即截断, 避免把断档拼成一条净值
    window = []
    for month in eligible:
        if window and _prev_month(month) != window[-1]:
            break
        window.append(month)

    if len(window) < 12:
        return {"status": "error", "error": f"可评价的连续月份仅 {len(window)} 个 (需≥12)",
                "version": BACKTEST_VERSION, "is_performance_evidence": False}

    names = {V5_KEY: "V5 配额 · ETF 持有收益代理（非子策略实盘）",
             "等权20%": "五只代理 ETF 等权（基准）",
             "纯沪深300": "沪深300ETF 持有（基准）",
             "纯红利低波": "红利低波100 持有（基准）"}
    nav = {k: 1.0 for k in names}
    series = {k: [] for k in names}
    rets_hist = {k: [] for k in names}
    detail = []

    for month in window:
        sig_month = _prev_month(month)
        sig = signals_by_month[sig_month]
        regime, cap = sig["regime"], float(sig["cap"])
        ret = returns.loc[month]
        alloc = alloc_table.get(regime, alloc_table[3])
        alloc_sum = sum(alloc.values())
        w = {k: alloc.get(k, 0) / alloc_sum * cap for k in ASSETS}
        cash_pct = max(0.0, 1.0 - sum(w.values()))
        month_ret = {
            V5_KEY: sum(w[k] * float(ret[k]) for k in ASSETS) + cash_pct * CASH_RATE / 12,
            "等权20%": sum(0.2 * float(ret[k]) for k in ASSETS),
            "纯沪深300": float(ret["mr"]),
            "纯红利低波": float(ret["div"]),
        }
        for k, r in month_ret.items():
            nav[k] *= (1 + r)
            rets_hist[k].append(r)
            series[k].append({"month": month, "nav": round(nav[k], 4)})
        detail.append({
            "month": month,
            "signal_month": sig_month,
            "aiae_simple": round(float(sig.get("aiae", float("nan"))), 1),
            "regime": regime,
            "cap": round(cap * 100, 0),
            "weights": {k: round(v * 100, 1) for k, v in w.items()},
            "cash_pct": round(cash_pct * 100, 1),
            "returns": {"V5": round(month_ret[V5_KEY] * 100, 2),
                        "EQ": round(month_ret["等权20%"] * 100, 2),
                        "300": round(month_ret["纯沪深300"] * 100, 2),
                        "DIV": round(month_ret["纯红利低波"] * 100, 2)},
        })

    results = {}
    for k in names:
        results[k] = {**_metrics([s["nav"] for s in series[k]], rets_hist[k], len(window)),
                      "label": names[k], "nav_series": series[k]}

    regime_stats = {}
    for r in range(1, 6):
        r_months = [d for d in detail if d["regime"] == r]
        if r_months:
            regime_stats[f"R{r}"] = {
                "months": len(r_months),
                "avg_return": round(float(np.mean([d["returns"]["V5"] for d in r_months])), 2),
                "avg_cap": round(float(np.mean([d["cap"] for d in r_months])), 0),
            }

    sources = set(provenance.get(k) for k in ASSETS)
    if sources == {SOURCE_REAL}:
        grade = "research_proxy"
    elif SOURCE_SYNTHETIC in sources:
        grade = "synthetic_demo_only"
    else:
        grade = "incomplete_provenance"

    return {
        "status": "success",
        "version": BACKTEST_VERSION,
        "evidence_grade": grade,
        "is_performance_evidence": False,
        "return_basis": "strategy_backtest",
        "return_basis_label": "策略/代理回测（规则回放，非账户业绩）",
        "period": f"{window[0]} ~ {window[-1]}",
        "total_months": len(window),
        "methodology": {
            "signal_timing": "t 月末 AIAE regime/仓位上限 → 仅作用于 t+1 月收益",
            "return_basis": "ETF 月末复权收盘(fund_daily×fund_adj, 含分红再投资) 的持有代理; 未计交易成本、滑点与申赎限制",
            "cash_rate_annual": CASH_RATE,
            "not_strategy_track_record": True,
            "proxies": {k: STRATEGY_PROXY[k]["code"] for k in ASSETS},
            "known_gaps": ["AIAE 历史输入是否含事后修订数据未核查"],
        },
        "data_provenance": {k: provenance.get(k) for k in ASSETS},
        "coverage": {"excluded_months_missing_returns": excluded_missing,
                     "excluded_months_no_prior_signal": excluded_no_signal,
                     "truncated_after_gap": len(eligible) - len(window)},
        "strategies": results,
        "regime_analysis": regime_stats,
        "monthly_detail": detail[-6:],
        "monthly_detail_all": detail,
        "generated_at": datetime.now().isoformat(),
    }


# ═══════════════════════════════════════════════════════
#  入口
# ═══════════════════════════════════════════════════════

def _load_signals(start_month: str) -> dict:
    """每月月末的 V5 regime/仓位上限 (来自 aiae_true_history 月末快照)。"""
    from engines.aiae_engine import get_aiae_engine
    engine = get_aiae_engine()
    pq_path = os.path.join(_ROOT, "data_lake", "aiae_true_history.parquet")
    history = pd.read_parquet(pq_path)
    # 需要 start_month 前一个月的信号来决定 start_month 的仓位
    history = history[history['month'] >= _prev_month(start_month)].copy()
    out = {}
    for _, row in history.iterrows():
        regime = engine.classify_regime(25.0, None, aiae_simple=row['aiae_simple'])
        erp_tier = row.get('erp_tier', 'erp_4_6')
        if pd.isna(erp_tier) or not erp_tier:
            erp_tier = 'erp_4_6'
        cap = engine.get_position_from_matrix(regime, erp_tier, aiae_value=row['aiae_simple']) / 100.0
        out[row['month']] = {"regime": regime, "cap": cap, "aiae": float(row['aiae_simple'])}
    return out


def run_portfolio_backtest(start_month: str = "2018-01", allow_synthetic: bool = False,
                           save: bool = True) -> dict:
    """执行 V5 配额 ETF 代理回测。只有全部为真实行情的结果才写入结果文件。"""
    signals = _load_signals(start_month)
    print(f"[代理回测] 月末信号: {len(signals)} 月")
    returns, provenance, err = _fetch_monthly_returns(start_month, allow_synthetic=allow_synthetic)
    if returns is None:
        return {"status": "data_unavailable", "error": err, "version": BACKTEST_VERSION,
                "is_performance_evidence": False}
    output = simulate(signals, returns, provenance)
    output.pop("monthly_detail_all", None)
    if save and output.get("status") == "success" and output["evidence_grade"] == "research_proxy":
        with open(_results_path(), 'w', encoding='utf-8') as f:
            json.dump(output, f, ensure_ascii=False, indent=2)
        print(f"\n[代理回测] 结果已保存: {_results_path()}")
    return output


def load_backtest_results(path: str = None) -> dict:
    """读取结果文件; 非当前版本 (含旧版同月信号结果) 标记为失效证据, 原内容保留。"""
    with open(path or _results_path(), "r", encoding="utf-8") as f:
        data = json.load(f)
    data["is_performance_evidence"] = False
    if data.get("version") != BACKTEST_VERSION:
        data["evidence_status"] = "invalidated_legacy"
        data["evidence_note"] = ("旧版联合回测: 同月月末信号作用于同月收益(时序偏差)、行情失败时可能静默"
                                 "使用合成收益、缺失资产以固定收益填充; 仅保留供追溯, 不得作为策略有效性证据")
    else:
        data["evidence_status"] = "current_proxy_research_only"
    return data


def print_summary(result: dict):
    """打印回测摘要"""
    if result.get("status") != "success":
        print(f"回测未完成: {result.get('error')}")
        return
    print("\n" + "=" * 65)
    print(f"  V5 配额 · ETF 持有代理回测 | {result['period']} ({result['total_months']}月)")
    print(f"  数据: {result['evidence_grade']} · 非子策略实盘 · 非业绩证据")
    print("=" * 65)
    print(f"{'策略':<16} {'终值':>6} {'CAGR':>7} {'MDD':>7} {'Sharpe':>7} {'Calmar':>7} {'胜率':>6}")
    print("-" * 65)
    for name, s in result["strategies"].items():
        print(f"{name:<16} {s['final_nav']:>6.2f} {s['cagr_pct']:>6.1f}% "
              f"{s['mdd_pct']:>6.1f}% {s['sharpe']:>7.2f} {s['calmar']:>7.2f} {s['win_rate']:>5.1f}%")
    print("\n  Regime 分析 (按决定仓位的前月末信号):")
    for rk, rv in result.get("regime_analysis", {}).items():
        print(f"    {rk}: {rv['months']}月, 月均收益={rv['avg_return']:.2f}%, 平均仓位={rv['avg_cap']:.0f}%")
    print("=" * 65)


if __name__ == "__main__":
    print_summary(run_portfolio_backtest("2018-01"))
