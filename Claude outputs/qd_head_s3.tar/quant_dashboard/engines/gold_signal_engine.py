"""
AlphaCore · 黄金宏观信号引擎 V2.0
=====================================
基于 FRED 数据的黄金择时三维信号系统:

  D1: 实际利率 (TIPS 10Y) — 权重 40%
      实际利率 ↓ → 黄金 ↑ (持有成本下降)
  D2: 美元指数代理 (DXY via FRED Trade Weighted USD) — 权重 30%
      美元走弱 → 黄金 ↑
  D3: 通胀预期 (10Y Breakeven = DGS10 - DFII10) — 权重 30%
      通胀预期 ↑ → 黄金 ↑ (对冲需求)

输出:
  - gold_signal: 综合信号 [-100, 100], 正值看多黄金
  - gold_direction: "bullish" / "neutral" / "bearish"
  - components: 三维子信号明细
  - suggested_allocation: 独立黄金战术目标 (0-15%，失效时 None；组合还需统一预算约束)

数据源: FRED API (DFII10 / DTWEXBGS / DGS10)
"""

import numpy as np
import pandas as pd
import os
import threading
from datetime import datetime, timedelta, timezone
from typing import Optional, Dict

from services.logger import get_logger
from services.fred_guard import fred_get_series
from services.multi_asset_policy import (
    GOLD_FACTOR_WEIGHTS, GOLD_SIGNAL_PARAMS, SIGNAL_THRESHOLD, tactical_weight, signal_direction,
)
from services.source_freshness import evaluate_source_freshness, h10_release_window, GOLD_SOURCES

logger = get_logger("ac.gold_signal")

# FRED API
try:
    from config import FRED_API_KEY
except ImportError:
    FRED_API_KEY = os.environ.get("FRED_API_KEY", "")

CACHE_DIR = "data_lake"
os.makedirs(CACHE_DIR, exist_ok=True)

# ── FRED 初始化 (复用 rates_strategy_engine 模式) ──
_fred_instance = None
_fred_lock = threading.Lock()

def _get_fred():
    global _fred_instance
    if _fred_instance is None:
        with _fred_lock:
            if _fred_instance is None:
                try:
                    from fredapi import Fred
                    _fred_instance = Fred(api_key=FRED_API_KEY)
                except Exception as e:
                    logger.warning("FRED init failed: %s", e)
    return _fred_instance


# ═══════════════════════════════════════════════════
#  FRED 数据获取 (带磁盘缓存兜底)
# ═══════════════════════════════════════════════════

# V26.1: 迁移至统一 EngineCache
from services.engine_cache import EngineCache
_gold_engine_cache = EngineCache("gold_signal", max_workers=2)


def _fetch_fred_series(series_id: str, lookback_days: int = 365, *, now=None) -> Optional[pd.Series]:
    """获取 FRED 数据序列, 委托 EngineCache 管理 TTL + SWR"""
    cache_key = f"gold_{series_id}"
    now = now or datetime.now(timezone.utc)
    memory_key = cache_key
    disk_ttl_hours = None
    cache_path = os.path.join(CACHE_DIR, f"{cache_key}.json")
    if series_id == "DTWEXBGS":
        window = h10_release_window(now)
        memory_key += "_" + window["expected_observation_date"]
        cutoff = datetime.fromisoformat(window["current_release_deadline_at"])
        disk_ttl_hours = min(6.0, max(0.0, (now - cutoff).total_seconds() / 3600))
        # A known missed batch must be retried through the global guard, not re-read
        # from a recently copied but obsolete FRED disk cache for another six hours.
        if os.path.exists(cache_path):
            try:
                local = _clean_series(pd.read_json(cache_path, typ="series"), now=now)
                observed = local.index[-1].date().isoformat() if local is not None else None
                if not evaluate_source_freshness(series_id, observed, now=now)["usable"]:
                    disk_ttl_hours = 0.0
            except Exception:
                disk_ttl_hours = 0.0

    def _fetch():
        fred = _get_fred()
        data = None

        if fred:
            try:
                start = (datetime.now() - timedelta(days=lookback_days)).strftime("%Y-%m-%d")
                data = fred_get_series(
                    series_id,
                    lambda: fred.get_series(series_id, observation_start=start),
                    disk_ttl_hours=disk_ttl_hours,
                    start=start,
                )
                data = data.dropna()

                # 写入磁盘缓存
                data.to_json(cache_path, date_format="iso")
                logger.debug("FRED %s: %d 条数据已缓存", series_id, len(data))
            except Exception as e:
                logger.warning("FRED %s 获取失败: %s", series_id, e)

        # 兜底: 磁盘缓存
        if data is None:
            if os.path.exists(cache_path):
                try:
                    data = pd.read_json(cache_path, typ="series")
                    logger.info("FRED %s: 使用磁盘缓存 (%d 条)", series_id, len(data))
                except Exception:
                    pass

        if data is None:
            raise ValueError(f"FRED {series_id}: 无可用数据")
        return data

    data = _gold_engine_cache.get(memory_key, 4 * 3600, _fetch)
    if series_id == "DTWEXBGS":
        cleaned = _clean_series(data, now=now)
        observed = cleaned.index[-1].date().isoformat() if cleaned is not None else None
        if not evaluate_source_freshness(series_id, observed, now=now)["usable"]:
            # Bounded retry; clicks do not unconditionally force upstream requests.
            data = _gold_engine_cache.get(memory_key, 300, _fetch)
    return data


# ═══════════════════════════════════════════════════
#  三维信号计算
# ═══════════════════════════════════════════════════

def _real_rate_signal(dfii10: pd.Series, *, now=None) -> Dict:
    """
    D1: 实际利率信号
    逻辑: 实际利率越低, 黄金越有吸引力
    映射: [-2, 2] → [100, -100] (线性插值)
    """
    dfii10 = _clean_series(dfii10, now=now)
    window = GOLD_SIGNAL_PARAMS["trend_window"]
    if dfii10 is None or len(dfii10) < window:
        return {"score": 0, "label": "数据不足", "value": None, "ma20": None}
    
    current = float(dfii10.iloc[-1])
    ma20 = float(dfii10.tail(window).mean())
    
    # 实际利率 → 信号: 负利率=看多黄金, 正利率=看空
    # 映射: -2% → +100, 0% → 0, +2% → -100
    score = np.clip(-current / GOLD_SIGNAL_PARAMS["real_rate_full_scale_pct"] * 100, -100, 100)
    
    # 趋势加成: 实际利率下降趋势 → 额外加分
    trend = current - ma20
    bonus_cap = GOLD_SIGNAL_PARAMS["trend_bonus_max_points"]
    trend_bonus = np.clip(-trend / GOLD_SIGNAL_PARAMS["real_rate_trend_scale_pp"] * bonus_cap, -bonus_cap, bonus_cap)
    score = np.clip(score + trend_bonus, -100, 100)
    
    if score > SIGNAL_THRESHOLD:
        label = "实际利率偏低, 利好黄金"
    elif score < -SIGNAL_THRESHOLD:
        label = "实际利率偏高, 利空黄金"
    else:
        label = "实际利率中性"
    
    return {
        "score": round(float(score), 1),
        "label": label,
        "value": round(current, 3),
        "ma20": round(ma20, 3),
    }


def _dollar_signal(dtwex: pd.Series, *, now=None) -> Dict:
    """
    D2: 美元强弱信号
    逻辑: 美元走弱 → 黄金走强 (负相关)
    使用 20 日动量: 当前 vs 20 日前
    """
    dtwex = _clean_series(dtwex, now=now)
    if dtwex is None or len(dtwex) < GOLD_SIGNAL_PARAMS["dollar_min_observations"] or (dtwex <= 0).any():
        return {"score": 0, "label": "数据不足", "value": None, "change_20d": None}
    
    current = float(dtwex.iloc[-1])
    prev_20d = float(dtwex.iloc[-(GOLD_SIGNAL_PARAMS["trend_window"] + 1)])
    
    change_pct = (current - prev_20d) / prev_20d * 100 if prev_20d > 0 else 0
    
    # 美元走弱(change<0) → 看多黄金(score>0)
    score = np.clip(-change_pct / GOLD_SIGNAL_PARAMS["dollar_full_scale_change_pct"] * 100, -100, 100)
    
    if score > SIGNAL_THRESHOLD:
        label = "美元走弱, 利好黄金"
    elif score < -SIGNAL_THRESHOLD:
        label = "美元走强, 利空黄金"
    else:
        label = "美元中性"
    
    return {
        "score": round(float(score), 1),
        "label": label,
        "value": round(current, 2),
        "change_20d": round(change_pct, 2),
    }


def _inflation_signal(dgs10: pd.Series, dfii10: pd.Series, *, now=None) -> Dict:
    """
    D3: 通胀预期信号
    逻辑: Breakeven = 名义利率 - 实际利率 = 隐含通胀预期
    通胀预期 ↑ → 黄金对冲需求 ↑
    """
    dgs10, dfii10 = _clean_series(dgs10, now=now), _clean_series(dfii10, now=now)
    if dgs10 is None or dfii10 is None:
        return {"score": 0, "label": "数据不足", "breakeven": None, "ma20": None}
    
    # 对齐日期 (使用 inner join 对齐)
    combined = pd.DataFrame({"dgs10": dgs10, "dfii10": dfii10}).dropna()
    window = GOLD_SIGNAL_PARAMS["trend_window"]
    if len(combined) < window:
        return {"score": 0, "label": "数据不足", "breakeven": None, "ma20": None}
    
    breakeven = combined["dgs10"] - combined["dfii10"]
    current_be = float(breakeven.iloc[-1])
    ma20_be = float(breakeven.tail(window).mean())
    
    # 通胀预期映射: 2.0% → 0, >3.0% → +100, <1.0% → -100
    score = np.clip((current_be - GOLD_SIGNAL_PARAMS["breakeven_center_pct"])
                    / GOLD_SIGNAL_PARAMS["breakeven_full_scale_pp"] * 100, -100, 100)
    
    # 趋势加成
    trend = current_be - ma20_be
    bonus_cap = GOLD_SIGNAL_PARAMS["trend_bonus_max_points"]
    trend_bonus = np.clip(trend / GOLD_SIGNAL_PARAMS["breakeven_trend_scale_pp"] * bonus_cap, -bonus_cap, bonus_cap)
    score = np.clip(score + trend_bonus, -100, 100)
    
    if score > SIGNAL_THRESHOLD:
        label = "通胀预期升温, 利好黄金"
    elif score < -SIGNAL_THRESHOLD:
        label = "通胀预期降温, 利空黄金"
    else:
        label = "通胀预期中性"
    
    return {
        "score": round(float(score), 1),
        "label": label,
        "breakeven": round(current_be, 3),
        "ma20": round(ma20_be, 3),
    }


# ═══════════════════════════════════════════════════
#  综合信号 + 配置建议
# ═══════════════════════════════════════════════════

_WEIGHTS = dict(GOLD_FACTOR_WEIGHTS)


def _clean_series(series, *, now=None):
    """Daily FRED observations: finite numeric values, unique sorted dates."""
    if series is None or not isinstance(series, pd.Series) or series.empty:
        return None
    if not isinstance(series.index, pd.DatetimeIndex):
        return None
    result = pd.to_numeric(series, errors="coerce").replace([np.inf, -np.inf], np.nan).dropna()
    result = result.copy()
    result.index = pd.to_datetime(result.index, utc=True).tz_convert(None).normalize()
    result = result[~result.index.isna()]
    result = result[~result.index.duplicated(keep="last")].sort_index()
    if result.empty or result.index[-1].date() > (now or datetime.now(timezone.utc)).date():
        return None
    return result


def compute_gold_signal(*, now=None) -> Dict:
    """Heuristic macro score with source dates and explicit abstention on bad data."""
    now = now or datetime.now(timezone.utc)
    sources, errors = {}, {}
    for series_id in ("DFII10", "DTWEXBGS", "DGS10"):
        try:
            sources[series_id] = _clean_series(_fetch_fred_series(series_id, 365), now=now)
            if sources[series_id] is None:
                errors[series_id] = "有效日频观测缺失或包含未来日期"
        except Exception as exc:
            sources[series_id] = None
            errors[series_id] = f"数据请求失败（{type(exc).__name__}）"
            logger.warning("Gold source %s unavailable: %s", series_id, exc)
    real, dollar, nominal = (sources[k] for k in ("DFII10", "DTWEXBGS", "DGS10"))
    components = {"real_rate": _real_rate_signal(real, now=now), "dollar": _dollar_signal(dollar, now=now),
                  "inflation": _inflation_signal(nominal, real, now=now)}
    aligned = nominal.index.intersection(real.index) if nominal is not None and real is not None else []
    dates = {"real_rate": real.index[-1].date().isoformat() if real is not None else None,
             "dollar": dollar.index[-1].date().isoformat() if dollar is not None else None,
             "inflation": aligned[-1].date().isoformat() if len(aligned) else None}
    coverage = 0.0
    warnings, unavailable = [], []
    for key, comp in components.items():
        freshness = evaluate_source_freshness(GOLD_SOURCES[key], dates[key], now=now)
        valid = ((comp.get("value") is not None or comp.get("breakeven") is not None)
                 and freshness["usable"])
        comp.update(weight=_WEIGHTS[key], data_as_of=dates[key],
                    data_status="ok" if valid else "unavailable", freshness=freshness,
                    source_id=GOLD_SOURCES[key])
        if valid:
            coverage += _WEIGHTS[key]
            comp["contribution"] = round(comp["score"] * _WEIGHTS[key], 1)
            comp["direction"] = signal_direction(comp["score"])
            comp["direction_cn"] = {"bullish": "利好", "bearish": "利空", "neutral": "中性"}[comp["direction"]]
            if freshness["status"] in ("publication_lag", "release_grace"):
                warnings.append(f"{GOLD_SOURCES[key]}：{freshness['reason']}")
        else:
            reason = freshness["reason"] if not freshness["usable"] else "有效历史不足"
            unavailable.append(f"{GOLD_SOURCES[key]}：{reason}")
            comp.update(score=None, contribution=None, direction="unavailable", direction_cn="数据不足",
                        unusable_reason=reason,
                        label={"real_rate": "实际利率：数据不可用", "dollar": "美元强弱：数据不可用",
                               "inflation": "通胀预期：数据不可用"}[key])
    usable = coverage >= 1 - 1e-9
    available = [c["contribution"] for c in components.values() if c["contribution"] is not None]
    # Sum the exact displayed contributions, so the attribution reconciles to 0.1.
    composite = round(sum(available), 1) if available else None
    direction = signal_direction(composite) if usable else "neutral"
    return {
        "status": "success" if usable else ("degraded" if available else "error"),
        "gold_signal": composite if usable else None, "partial_signal": composite if not usable else None,
        "gold_direction": direction,
        "gold_direction_cn": ({"bullish": "看多黄金", "bearish": "看空黄金", "neutral": "黄金中性"}[direction]
                              if usable else "数据不足"),
        "suggested_allocation": round(tactical_weight("gold", composite), 1) if usable else None,
        "allocation_label": "SAA 锚定的连续战术配置" if usable else "暂无有效目标",
        "components": components, "weights": dict(_WEIGHTS), "parameters": dict(GOLD_SIGNAL_PARAMS),
        "data_as_of": min(dates.values()) if all(dates.values()) else None,
        "quality": {"usable": usable, "coverage": round(coverage, 2), "source_errors": errors,
                    "warnings": warnings, "unavailable_reasons": unavailable},
        "model_version": "gold-macro-v2.1", "calibration_status": "heuristic_unvalidated",
        "timestamp": now.isoformat(),
    }
