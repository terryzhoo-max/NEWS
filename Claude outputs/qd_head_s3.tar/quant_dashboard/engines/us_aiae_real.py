"""
AlphaCore · 美股真实 AIAE (海外 AIAE P1, 见 docs/AIAE_GLOBAL_OPTIMIZATION_PLAN.md)
==================================================================================
替代 aiae_us_engine 中"总市值 / M2"代理口径。只输出估值背景, 不输出仓位。

定义 (Livermore 2013, Aggregate Investor Allocation to Equities):
  AIAE = E / (E + L)
  E = 非金融企业股票负债市值 (NCBEILQ027S) + 国内金融部门股票负债市值 (FBCELLQ027S)
  L = 家庭与非营利 (TCMILBSHNO) + 非金融企业 (TCMILBSNNCB) + 联邦政府 (FGTCMDODNS)
      + 州与地方政府 (SLGTCMDODNS) 的"债务证券与贷款"负债
  数据: 美联储 Z.1 资金流量表, FRED 季度序列, 单位均为百万美元 (2026-11-01 逐个核实), 1945Q4 起。
  未计入外国部门借款 (原文作为可选项); 影响整体水平, 不影响分位与回归的相对比较。

读数
  1. 季末实测: 最近一个 6 个序列都有值的季度。
  2. 实时估算 (nowcast): E 按季末以来标普 500 涨跌外推; L 按过去 4 个季度的年化增速外推。
  3. 分位: 当前值在严格早于当前季度的全部实测季度中的位置 (扩展窗口, 与 A 股 V6-A 同法)。
  4. 隐含 10 年实际年化总回报: 用"截至今天已完整实现"的 (AIAE_t, 未来 10 年实际总回报) 配对做 OLS,
     代入当前值。目标收益取 Shiller 实际总回报价格 (data/shiller_us_monthly.csv 的 real_tr_price)。
     注意: 配对按季度重叠, 独立的 10 年窗口很少 (约 n/40 个), R² 与残差不能当作显著性证据。

档位 (偏低/中性/偏高) 不在本阶段给出: 阈值须先在 P2 预登记 (docs/AIAE_GLOBAL_PREREGISTRATION.md, 待写)。
"""

from __future__ import annotations

import logging
import os
from typing import Dict, Optional

import numpy as np
import pandas as pd

logger = logging.getLogger("alphacore.us_aiae_real")

SERIES_E = ("NCBEILQ027S", "FBCELLQ027S")
SERIES_L = ("TCMILBSHNO", "TCMILBSNNCB", "FGTCMDODNS", "SLGTCMDODNS")
SERIES_ALL = SERIES_E + SERIES_L

PARAMS = {
    "version": "us-aiae-real-1.0",
    "start": "1951-10-01",        # 与 Livermore 原文一致, 从 1951Q4 起
    "min_history_q": 80,          # 至少 20 年历史才给出分位
    "horizon_years": 10,
    "min_pairs": 80,              # 回归至少 80 个季度配对 (约 2 个独立窗口)
    "stale_days": 200,            # 最近实测季度末距今超过 200 天 → 标记过期 (正常发布滞后约 70~160 天)
    "debt_growth_lookback_q": 4,
}

_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CSV_PATH = os.path.join(_ROOT, "data", "us_aiae_z1_quarterly.csv")
SHILLER_PATH = os.path.join(_ROOT, "data", "shiller_us_monthly.csv")

ANCHORS = {  # 只用于展示与核对数量级, 不参与计算
    "2000Q1": "互联网泡沫顶部",
    "2007Q3": "金融危机前",
    "2009Q1": "金融危机底部",
    "2021Q4": "2021 年高点",
}


# ───────────────────────── 数据 ─────────────────────────

def frame_from_series(series: Dict[str, pd.Series]) -> pd.DataFrame:
    """FRED 序列字典 → 季度 DataFrame (索引为季末日期)。FRED 季度日期为季初 (如 2026-04-01 = 2026Q2)。"""
    df = pd.DataFrame({k: pd.Series(v, dtype=float) for k, v in series.items()})
    df.index = pd.to_datetime(df.index).to_period("Q").to_timestamp(how="end").normalize()
    df = df.groupby(level=0).last().sort_index()
    return df


def load_z1(path: str = CSV_PATH) -> pd.DataFrame:
    """读取 _dev_tools/update_us_aiae_z1.py 生成的 CSV。列: date (FRED 季初日期) + 6 个序列代码 (百万美元)。"""
    raw = pd.read_csv(path, dtype={"date": str})
    raw = raw.set_index("date")
    return frame_from_series({c: pd.to_numeric(raw[c], errors="coerce") for c in SERIES_ALL})


def aiae_history(df: pd.DataFrame, p: dict = PARAMS) -> pd.DataFrame:
    """季度 AIAE 实测序列 (%)。只保留 6 个序列齐全的季度。"""
    missing = [c for c in SERIES_ALL if c not in df.columns]
    if missing:
        raise ValueError(f"Z.1 数据缺少序列: {missing}")
    full = df[list(SERIES_ALL)].dropna()
    h = pd.DataFrame(index=full.index)
    h["E"] = full[list(SERIES_E)].sum(axis=1)
    h["L"] = full[list(SERIES_L)].sum(axis=1)
    h["aiae"] = h["E"] / (h["E"] + h["L"]) * 100.0
    start = pd.Timestamp(p["start"]).to_period("Q").to_timestamp(how="end").normalize()
    return h[h.index >= start]


def load_shiller(path: str = SHILLER_PATH) -> Optional[pd.DataFrame]:
    try:
        df = pd.read_csv(path, dtype={"month": str})
    except FileNotFoundError:
        return None
    df["date"] = pd.PeriodIndex(df["month"], freq="M").to_timestamp(how="end").normalize()
    df = df.set_index("date").sort_index()
    for c in ("price", "real_tr_price"):
        if c in df.columns:
            df[c] = pd.to_numeric(df[c], errors="coerce")
    return df


# ───────────────────────── 档位 (P2 预登记, docs/AIAE_GLOBAL_PREREGISTRATION.md) ─────────────────────────

TIER_PARAMS = {
    "version": "us-aiae-tier-1.0",
    "high_pct": 70.0,      # 分位 ≥ 70 → 偏高 (贵)
    "low_pct": 30.0,       # 分位 ≤ 30 → 偏低 (便宜)
    "buffer_pct": 5.0,     # 回档缓冲
    "min_history_q": 80,
}
TIER_CN = {"high": "偏高", "neutral": "中性", "low": "偏低"}
# P2 结果 (docs/AIAE_GLOBAL_P2_RESULTS.md): R1 (档位显著性) 与 R2 (门控增量) 均未通过 → 不显示档位, 警示不使用 AIAE
TIERS_ENABLED = False
VALIDATION_NOTE = "预登记检验未通过 (档位差异 Newey-West t=1.04 < 2; 作为警示前提使回撤变差), 只显示读数与分位"


def next_tier(prev: Optional[str], pct: Optional[float], p: dict = TIER_PARAMS) -> Optional[str]:
    if pct is None or (isinstance(pct, float) and np.isnan(pct)):
        return prev
    hi, lo, buf = p["high_pct"], p["low_pct"], p["buffer_pct"]
    if pct >= hi:
        return "high"
    if pct <= lo:
        return "low"
    if prev == "high" and pct > hi - buf:
        return "high"
    if prev == "low" and pct < lo + buf:
        return "low"
    return "neutral"


def expanding_pct(x: pd.Series, min_n: int) -> pd.Series:
    """每个季度在严格早于它的季度中的分位; 历史不足 min_n 为 NaN。"""
    vals = x.to_numpy(float)
    out = np.full(len(vals), np.nan)
    for i in range(len(vals)):
        if i >= min_n:
            out[i] = pct_rank(pd.Series(vals[:i]), vals[i])
    return pd.Series(out, index=x.index)


def tier_history(hist: pd.DataFrame, p: dict = TIER_PARAMS) -> pd.DataFrame:
    """季度实测的扩展分位与档位 (无后视)。"""
    out = pd.DataFrame(index=hist.index)
    out["aiae"] = hist["aiae"]
    out["pct"] = expanding_pct(hist["aiae"], p["min_history_q"])
    tiers, prev = [], None
    for v in out["pct"].to_numpy(float):
        prev = next_tier(prev, None if np.isnan(v) else float(v), p)
        tiers.append(prev)
    out["tier"] = pd.Series(tiers, index=out.index, dtype=object)
    return out


# ───────────────────────── 计算 ─────────────────────────

def pct_rank(past: pd.Series, value: float) -> Optional[float]:
    past = past.dropna()
    if not len(past):
        return None
    return float((np.sum(past < value) + 0.5 * np.sum(past == value)) / len(past) * 100.0)


def forward_real_returns(dates: pd.DatetimeIndex, real_tr: pd.Series, years: int) -> pd.Series:
    """每个季末起未来 `years` 年的实际总回报年化 (%)。目标月份无数据时为 NaN。"""
    tr = real_tr.dropna()
    out = {}
    for d in dates:
        m0 = d.to_period("M").to_timestamp(how="end").normalize()
        m1 = (d.to_period("M") + years * 12).to_timestamp(how="end").normalize()
        if m0 in tr.index and m1 in tr.index and tr[m0] > 0:
            out[d] = ((tr[m1] / tr[m0]) ** (1.0 / years) - 1.0) * 100.0
        else:
            out[d] = np.nan
    return pd.Series(out, dtype=float)


def fit_implied_return(hist: pd.DataFrame, fwd: pd.Series, value: float,
                       as_of: pd.Timestamp, p: dict = PARAMS) -> Optional[dict]:
    """用截至 as_of 已完整实现的配对做 OLS: fwd = a + b·AIAE。配对不足返回 None。"""
    y = fwd.reindex(hist.index)
    end_ok = (hist.index.to_period("M") + p["horizon_years"] * 12).to_timestamp(how="end").normalize() <= as_of
    mask = y.notna() & end_ok
    x, yy = hist.loc[mask, "aiae"].to_numpy(float), y[mask].to_numpy(float)
    n = len(x)
    if n < p["min_pairs"]:
        return None
    b, a = np.polyfit(x, yy, 1)
    resid = yy - (a + b * x)
    ss_tot = float(np.sum((yy - yy.mean()) ** 2))
    extrapolated = bool(value > x.max() or value < x.min())
    return {
        "implied_10y_real": round(float(a + b * value), 2),
        # 当前值超出回归样本的 AIAE 范围时为线性外推, 数值不可靠 (2026-11 实测: 59.4 vs 样本上限 52.7)
        "extrapolated": extrapolated,
        "x_range": [round(float(x.min()), 1), round(float(x.max()), 1)],
        "intercept": round(float(a), 3),
        "slope": round(float(b), 4),
        "resid_sd": round(float(np.std(resid, ddof=2)), 2),
        "r2_in_sample": round(1.0 - float(np.sum(resid ** 2)) / ss_tot, 3) if ss_tot > 0 else None,
        "n_pairs": int(n),
        "independent_windows": round(n / (4 * p["horizon_years"]), 1),
        "sample": f"{hist.index[mask][0]:%Y}Q{hist.index[mask][0].quarter}–{hist.index[mask][-1]:%Y}Q{hist.index[mask][-1].quarter}",
        "note": "配对按季度重叠, R² 与残差偏乐观, 不作显著性证据",
    }


def nowcast(hist: pd.DataFrame, as_of: pd.Timestamp, price_q_end: Optional[float],
            price_now: Optional[float], p: dict = PARAMS) -> Optional[dict]:
    """季末实测 → 今天的估算。价格缺失时返回 None (只展示季末实测)。"""
    if not price_q_end or not price_now or price_q_end <= 0:
        return None
    last = hist.iloc[-1]
    q_end = hist.index[-1]
    days = max(0, (as_of - q_end).days)
    lb = p["debt_growth_lookback_q"]
    g = (last["L"] / hist["L"].iloc[-1 - lb]) ** (1.0 / (lb / 4.0)) - 1.0 if len(hist) > lb else 0.0
    e_now = last["E"] * price_now / price_q_end
    l_now = last["L"] * (1.0 + g) ** (days / 365.25)
    return {
        "aiae": round(float(e_now / (e_now + l_now) * 100.0), 2),
        "price_change_pct": round((price_now / price_q_end - 1.0) * 100.0, 2),
        "debt_growth_annual_pct": round(float(g) * 100.0, 2),
        "days_since_quarter_end": int(days),
    }


def _qlabel(ts: pd.Timestamp) -> str:
    return f"{ts.year}Q{ts.quarter}"


def latest_reading(hist: pd.DataFrame, as_of: Optional[pd.Timestamp] = None,
                   shiller: Optional[pd.DataFrame] = None,
                   price_q_end: Optional[float] = None, price_now: Optional[float] = None,
                   price_basis: Optional[str] = None, p: dict = PARAMS) -> dict:
    as_of = pd.Timestamp(as_of or pd.Timestamp.today()).normalize()
    hist = hist[hist.index <= as_of]
    q_end = hist.index[-1]
    measured = float(hist["aiae"].iloc[-1])
    nc = nowcast(hist, as_of, price_q_end, price_now, p)
    current = nc["aiae"] if nc else measured

    # 分位: 当前值 vs 严格早于"当前"季度的实测值 (nowcast 时为最近实测季度及之前)
    past = hist["aiae"] if nc else hist["aiae"].iloc[:-1]
    pct = pct_rank(past, current) if len(past) >= p["min_history_q"] else None

    reg = None
    if shiller is not None and "real_tr_price" in shiller.columns:
        fwd = forward_real_returns(hist.index, shiller["real_tr_price"], p["horizon_years"])
        reg = fit_implied_return(hist, fwd, current, as_of, p)

    # 影子档位 (P2 预登记检验未通过, 不显示, 只写前向日志供复盘)
    th = tier_history(hist)
    prev_tier = th["tier"].dropna()
    prev_tier = prev_tier.iloc[-1] if nc and len(prev_tier) else (prev_tier.iloc[-2] if len(prev_tier) > 1 else None)
    shadow_tier = next_tier(prev_tier, pct) if pct is not None else None

    anchors = []
    for q, label in ANCHORS.items():
        ts = pd.Period(q, freq="Q").to_timestamp(how="end").normalize()
        if ts in hist.index:
            anchors.append({"quarter": q, "label": label, "aiae": round(float(hist.loc[ts, "aiae"]), 1)})

    stale_days = (as_of - q_end).days
    return {
        "version": p["version"],
        "as_of": str(as_of.date()),
        "aiae": round(float(current), 2),
        "basis": "nowcast" if nc else "measured",
        "measured": {"quarter": _qlabel(q_end), "aiae": round(measured, 2),
                     "equity_trillion": round(float(hist["E"].iloc[-1]) / 1e6, 1),
                     "debt_trillion": round(float(hist["L"].iloc[-1]) / 1e6, 1)},
        "nowcast": dict(nc, price_basis=price_basis) if nc else None,
        "z1_stale": bool(stale_days > p["stale_days"]),
        "days_since_quarter_end": int(stale_days),
        "pct": None if pct is None else round(pct, 1),
        "history": {"start": _qlabel(hist.index[0]), "quarters": int(len(past)),
                    "median": round(float(past.median()), 1), "min": round(float(past.min()), 1),
                    "max": round(float(past.max()), 1)},
        "implied_return": reg,
        "anchors": anchors,
        "tier": None,
        "shadow_tier": shadow_tier,
        "tier_note": VALIDATION_NOTE,
        "definition": "AIAE = 股票市值 / (股票市值 + 家庭·企业·联邦·州地方债务), 美联储 Z.1",
        "role": "background",
        "note": "估值背景, 不作仓位依据",
    }


def price_pair_from_daily(spx_daily: Optional[pd.Series], q_end: pd.Timestamp,
                          as_of: Optional[pd.Timestamp] = None):
    """(季末收盘, as_of 当日或之前最新收盘) — 季末取当日或之前最后一个交易日。"""
    if spx_daily is None:
        return None, None
    s = pd.Series(spx_daily).dropna()
    if s.empty:
        return None, None
    s.index = pd.to_datetime(s.index)
    s = s.sort_index()
    if as_of is not None:
        s = s[s.index <= as_of]
    base = s[s.index <= q_end]
    if base.empty:
        return None, None
    return float(base.iloc[-1]), float(s.iloc[-1])


def price_pair_from_shiller(shiller: Optional[pd.DataFrame], q_end: pd.Timestamp,
                            as_of: Optional[pd.Timestamp] = None):
    """无日频价格时的退路: Shiller 月均价 (季末所在月 vs as_of 之前最后一个完整月份)。"""
    if shiller is None or "price" not in shiller.columns:
        return None, None
    px = shiller["price"].dropna()
    if as_of is not None:
        px = px[px.index <= as_of]
    m0 = q_end.to_period("M").to_timestamp(how="end").normalize()
    if m0 not in px.index or px.index[-1] <= m0:
        return None, None
    return float(px[m0]), float(px.iloc[-1])


def compute(z1: Optional[pd.DataFrame] = None, spx_daily: Optional[pd.Series] = None,
            as_of=None, path: Optional[str] = None, shiller_path: Optional[str] = None) -> Optional[dict]:
    """便捷入口。z1 缺省时读 CSV; 任何失败返回 None (调用方显示"不可用")。"""
    try:
        df = z1 if z1 is not None else load_z1(path or CSV_PATH)
        hist = aiae_history(df)
        if hist.empty:
            return None
        as_of_ts = pd.Timestamp(as_of or pd.Timestamp.today()).normalize()
        shiller = load_shiller(shiller_path or SHILLER_PATH)
        q_end = hist[hist.index <= as_of_ts].index[-1]
        p0, p1 = price_pair_from_daily(spx_daily, q_end, as_of_ts)
        basis = "S&P 500 日收盘"
        if p0 is None:
            p0, p1 = price_pair_from_shiller(shiller, q_end, as_of_ts)
            basis = "S&P 500 月均价 (Shiller)"
        return latest_reading(hist, as_of_ts, shiller, p0, p1, basis if p0 else None)
    except FileNotFoundError:
        logger.warning("Z.1 CSV 不存在: %s (运行 _dev_tools/update_us_aiae_z1.py 生成)", path or CSV_PATH)
    except Exception as e:  # noqa: BLE001 — 估值背景失败不影响主流程
        logger.warning("美股真实 AIAE 计算失败: %s", e, exc_info=True)
    return None
