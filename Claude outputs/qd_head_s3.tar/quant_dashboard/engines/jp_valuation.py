"""
AlphaCore · 日股 ERP 真实读数 (海外 ERP P3, 见 docs/ERP_GLOBAL_OPTIMIZATION_PLAN.md)
==================================================================================
替代 erp_jp_engine 中"日经估算 EPS + FRED 月频 JGB (滞后约 2 个月)"的读数。只输出数值, 不分位、不分档。

PE    : JPX 月度 PER, 合并 · 加权平均 · 市场整体 (2022-04 起 Prime, 之前东证一部)
        仓库文件 data/jpx_per_monthly.csv (由 _dev_tools/update_jpx_per_csv.py 每月更新)
10Y   : 财务省 (MOF) 国债收益率 10 年
        优先实时取 MOF 当月 CSV; 失败时用仓库快照 data/jgb10y_daily.csv (由 _dev_tools/update_jgb_csv.py 更新)
ERP   : 100 / PER − JGB 10Y (名义; 日本无足够长的通胀挂钩国债序列, 不做实际利率换算)

不分位/不分档的原因: JPX 加权 PER 只有 2013 年以来的电子数据, 且 1999–2024 基本处于零利率时期,
与当前利率环境不同, 分位会机械偏向"极贵"。
"""

from __future__ import annotations

import io
import logging
import os
import re
from datetime import date
from typing import Optional

import pandas as pd

logger = logging.getLogger("alphacore.jp_valuation")

_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
JPX_CSV = os.path.join(_ROOT, "data", "jpx_per_monthly.csv")
JGB_CSV = os.path.join(_ROOT, "data", "jgb10y_daily.csv")
MOF_CURRENT_URL = "https://www.mof.go.jp/jgbs/reference/interest_rate/jgbcm.csv"
MOF_ALL_URL = "https://www.mof.go.jp/jgbs/reference/interest_rate/data/jgbcm_all.csv"

PARAMS = {
    "version": "jp-erp-real-1.0",
    "per_stale_months": 2,   # JPX 每月第 1 个营业日发布上月末数据; 超过 2 个月未更新 → 过期
    "jgb_stale_days": 10,    # 快照回退时, JGB 超过 10 天 → 过期
    "fetch_timeout": 8,
}

_ERA = {"S": 1925, "H": 1988, "R": 2018}  # 昭和 / 平成 / 令和 元年 = 基数 + 1
_SEG_CN = {"prime": "Prime", "first_section": "东证一部"}


# ───────────────────────── 解析 ─────────────────────────

def parse_era_date(s: str) -> Optional[pd.Timestamp]:
    """'R8.10.1' / 'H31.4.26' / 'S49.9.24' 或西历 '2026/10/01' → Timestamp。"""
    s = str(s).strip()
    m = re.fullmatch(r"([SHR])(\d{1,2})\.(\d{1,2})\.(\d{1,2})", s)
    if m:
        era, y, mo, d = m.groups()
        return pd.Timestamp(year=_ERA[era] + int(y), month=int(mo), day=int(d))
    if not s or s.lower() == "nan":
        return None
    try:
        ts = pd.Timestamp(s.replace("/", "-"))
    except (ValueError, TypeError):
        return None
    return None if pd.isna(ts) else ts


def parse_mof_csv(raw: bytes) -> pd.Series:
    """MOF jgbcm.csv / jgbcm_all.csv → 10 年期收益率日序列 (%)。"""
    text = None
    for enc in ("cp932", "utf-8-sig", "utf-8"):
        try:
            text = raw.decode(enc)
            break
        except UnicodeDecodeError:
            continue
    if text is None:
        raise ValueError("无法解码 MOF CSV")
    lines = text.splitlines()
    hdr = next(i for i, ln in enumerate(lines) if "10年" in ln and ("基準日" in ln or "Date" in ln or ln.count(",") > 5))
    df = pd.read_csv(io.StringIO("\n".join(lines[hdr:])), dtype=str)
    date_col = df.columns[0]
    ten = next(c for c in df.columns if str(c).strip() in ("10年", "10Y"))
    out = {}
    for d, v in zip(df[date_col], df[ten]):
        ts = parse_era_date(d)
        try:
            val = float(str(v).strip())
        except ValueError:
            continue
        if ts is not None and val == val:  # 排除 NaN
            out[ts] = val
    s = pd.Series(out, dtype=float).sort_index()
    if s.empty:
        raise ValueError("MOF CSV 中没有 10 年期数据")
    return s


# ───────────────────────── 数据 ─────────────────────────

def load_per(path: str = None) -> pd.DataFrame:
    return pd.read_csv(path or JPX_CSV, dtype={"month": str})


def fetch_mof_current(timeout: float = None) -> Optional[pd.Series]:
    try:
        import requests
        r = requests.get(MOF_CURRENT_URL, timeout=timeout or PARAMS["fetch_timeout"])
        r.raise_for_status()
        return parse_mof_csv(r.content)
    except Exception as e:  # noqa: BLE001 — 取不到就回退到快照
        logger.warning("MOF 当月 JGB 获取失败: %s", e)
        return None


_REAL_FETCH = fetch_mof_current


def load_jgb_snapshot(path: str = None) -> Optional[pd.Series]:
    p = path or JGB_CSV
    if not os.path.exists(p):
        return None
    df = pd.read_csv(p)
    s = pd.Series(df["jgb10y"].astype(float).values, index=pd.to_datetime(df["date"]))
    return s.sort_index()


def latest_jgb10y(fetch: bool = True, snapshot_path: str = None) -> Optional[dict]:
    # 测试环境不联网 (pytest 会设置 PYTEST_CURRENT_TEST); 需要时由测试显式 monkeypatch fetch_mof_current
    if os.environ.get("PYTEST_CURRENT_TEST") and fetch_mof_current is _REAL_FETCH:
        fetch = False
    live = fetch_mof_current() if fetch else None
    if live is not None and not live.empty:
        return {"value": float(live.iloc[-1]), "date": live.index[-1], "source": "mof_live"}
    snap = load_jgb_snapshot(snapshot_path)
    if snap is not None and not snap.empty:
        return {"value": float(snap.iloc[-1]), "date": snap.index[-1], "source": "mof_snapshot"}
    return None


# ───────────────────────── 当前读数 ─────────────────────────

def compute(fetch: bool = True, as_of: Optional[pd.Timestamp] = None,
            per_path: str = None, jgb_snapshot_path: str = None, p: dict = PARAMS) -> Optional[dict]:
    """返回日股真实 ERP 读数; PER 或 JGB 任一缺失时返回 None (调用方回退到"仅读数")。"""
    try:
        per = load_per(per_path).dropna(subset=["per_weighted"])
        jgb = latest_jgb10y(fetch, jgb_snapshot_path)
        if per.empty or jgb is None:
            return None
        last = per.iloc[-1]
        as_of = pd.Timestamp(as_of or date.today()).normalize()
        per_month = pd.Period(last["month"], freq="M")
        per_age = (as_of.to_period("M") - per_month).n
        jgb_age = (as_of - pd.Timestamp(jgb["date"]).normalize()).days
        pe = float(last["per_weighted"])
        ey = 100.0 / pe
        erp = ey - jgb["value"]
        seg = _SEG_CN.get(str(last["segment"]), str(last["segment"]))
        return {
            "version": p["version"],
            "as_of": str(as_of.date()),
            "erp": round(erp, 2),
            "pe": round(pe, 1),
            "ey": round(ey, 2),
            "per_month": str(per_month),
            "per_age_months": int(per_age),
            "per_stale": bool(per_age > p["per_stale_months"]),
            "per_basis": f"JPX {seg} 加权PER (合并, 实绩)",
            "jgb10y": round(jgb["value"], 3),
            "jgb_date": str(pd.Timestamp(jgb["date"]).date()),
            "jgb_source": jgb["source"],
            "jgb_stale": bool(jgb["source"] != "mof_live" and jgb_age > p["jgb_stale_days"]),
            "rate_basis": "JGB 10Y 名义 (财务省)",
            "pct": None, "tier": None,
            "role": "background",
            "note": "真实数据读数; 样本短且利率体制变化, 不显示分位、不分档",
        }
    except FileNotFoundError:
        logger.warning("JPX PER CSV 不存在: %s", per_path or JPX_CSV)
    except Exception as e:  # noqa: BLE001
        logger.warning("日股 ERP 真实读数失败: %s", e, exc_info=True)
    return None
