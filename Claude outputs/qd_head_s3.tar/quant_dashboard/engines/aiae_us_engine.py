"""
AlphaCore · 美股 AIAE 宏观仓位管控引擎 V1.0
=============================================
核心思想: US_AIAE = 美国投资者把多少比例的钱放在了股票里
  - 比例极高 → 市场过热，减仓
  - 比例极低 → 市场冰点，加仓

三因子构成 (V1.1 权重):
  US_AIAE_Core = Wilshire5000 / (Wilshire5000 + Fed M2)  [60%]  月频
  Margin Heat  = NYSE Margin Debt / Wilshire5000 MktCap   [20%]  季频
  AAII Spread  = AAII Bull% - Bear% (散户情绪)             [20%]  周频/手动

五档状态 (美股校准, 比A股上移3-4%):
  Ⅰ <15%   → 90-95%   极度恐慌
  Ⅱ 15-20% → 70-85%   低配置区
  Ⅲ 20-27% → 50-65%   中性均衡
  Ⅳ 27-34% → 25-40%   偏热区域
  Ⅴ >34%   → 0-15%    极度过热

数据源: FRED API (Wilshire5000, M2, Margin proxy) + AAII公开数据
交叉验证: US_AIAE × US ERP 仓位矩阵
"""

import pandas as pd
import numpy as np
import time
import os
import json
import logging

from datetime import datetime, timedelta
from typing import Optional, Dict, List, Tuple
from config import FRED_API_KEY as CONFIG_FRED_API_KEY
from services.fred_guard import fred_get_series, should_retry_fred_error

FRED_API_KEY = os.environ.get("FRED_API_KEY", CONFIG_FRED_API_KEY)
CACHE_DIR = "data_lake"
os.makedirs(CACHE_DIR, exist_ok=True)
_logger = logging.getLogger("alphacore.aiae_us")

# ===== 频率感知 TTL 常量 (V1.1 优化) =====
TTL_M2       = 14 * 86400   # 14天 (M2 月频数据)
TTL_MARGIN   = 30 * 86400   # 30天 (Margin Debt 季频数据)
TTL_AAII     = 3  * 86400   # 3天  (AAII 周频, 配合定时爬取)

def _get_wilshire_ttl() -> int:
    """Wilshire5000 智能TTL: 工作日4h / 周末24h"""
    return 86400 if datetime.now().weekday() >= 5 else 14400

# ===== 工业级重试装饰器 (统一至 services.retry) =====
from services.retry import retry_with_backoff as _retry_base

def retry_with_backoff(max_retries=3, base_delay=2.0):
    """FRED 错误过滤版重试 (向后兼容 wrapper)"""
    return _retry_base(max_retries=max_retries, base_delay=base_delay,
                       error_filter=should_retry_fred_error)

# ===== 原子性文件写入 =====
def atomic_write_json(data, filepath):
    tmp_path = filepath + ".tmp"
    try:
        with open(tmp_path, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        os.replace(tmp_path, filepath)
    except Exception as e:
        if os.path.exists(tmp_path):
            os.remove(tmp_path)
        raise e

# ===== 线程安全 TTL 缓存 (V26.1: 迁移至统一 EngineCache) =====
from services.engine_cache import EngineCache
_engine_cache = EngineCache("aiae_us", max_workers=3)
_bg_executor = _engine_cache._executor  # 复用缓存线程池做并行数据获取

def _log(msg: str, level: str = "INFO"):
    ts_str = datetime.now().strftime("%H:%M:%S.%f")[:-3]
    try:
        print(f"[{ts_str}] [{level}] [US-AIAE] {msg}")
    except UnicodeEncodeError:
        safe_msg = msg.encode('ascii', errors='replace').decode('ascii')
        print(f"[{ts_str}] [{level}] [US-AIAE] {safe_msg}")

def _cached(key: str, ttl_seconds: int, fetcher):
    """统一缓存接口 (委托给 EngineCache)"""
    return _engine_cache.get(key, ttl_seconds, fetcher)


# FRED API helper
_fred = None
def _get_fred():
    global _fred
    if _fred is None:
        try:
            import socket
            # P1: 注入 socket 超时, 将 TCP 连接等待从 21s (Windows默认) 压缩到 10s
            _prev_timeout = socket.getdefaulttimeout()
            socket.setdefaulttimeout(10)
            from fredapi import Fred
            _fred = Fred(api_key=FRED_API_KEY)
            socket.setdefaulttimeout(_prev_timeout)
        except Exception as e:
            _log(f"FRED init failed: {e}", "ERROR")
    return _fred


# ===== 历史基准数据 (回测验证) =====
# 校准锚点 (各数据点通过 MktCap/M2 比值反推，与实际市场状态交叉验证过)
# ratio→AIAE 映射: ratio 0.8→10%, 3.0→45% (线性区间)
HISTORICAL_SNAPSHOTS = [
    {"date": "2000-03-24", "aiae": 43.5, "spy_after_1y": -26,  "label": "互联网泡沫顶部"},  # MktCap/M2≈3.06
    {"date": "2002-10-09", "aiae": 18.2, "spy_after_1y": 34,   "label": "互联网崩溃底部"},  # MktCap/M2≈1.29
    {"date": "2007-10-09", "aiae": 35.8, "spy_after_1y": -37,  "label": "金融危机前顶部"},  # MktCap/M2≈2.07
    {"date": "2009-03-09", "aiae": 12.5, "spy_after_1y": 68,   "label": "GFC底部 666点"},   # MktCap/M2≈0.96
    {"date": "2018-12-24", "aiae": 19.8, "spy_after_1y": 31,   "label": "加息恐慌底部"},    # MktCap/M2≈1.75
    {"date": "2020-03-23", "aiae": 14.8, "spy_after_1y": 75,   "label": "COVID底部"},       # MktCap/M2≈1.38
    {"date": "2021-11-19", "aiae": 37.2, "spy_after_1y": -19,  "label": "科技泡沫顶部"},    # MktCap/M2≈2.29
    {"date": "2022-10-12", "aiae": 19.5, "spy_after_1y": 22,   "label": "加息底部"},        # MktCap/M2≈1.50
    {"date": "2026-04-10", "aiae": None,  "spy_after_1y": None, "label": "当前状态"},         # 由引擎实时计算
]

# ===== 五档状态定义 (美股校准) =====
REGIMES_US = {
    1: {"name": "Ⅰ · EXTREME FEAR", "cn": "极度恐慌", "range": "<15%",
        "color": "#10b981", "emoji": "🟢", "position": "90-95%", "pos_min": 90, "pos_max": 95,
        "action": "满配进攻", "desc": "历史级机会, 分3批建仓"},
    2: {"name": "Ⅱ · LOW ALLOCATION", "cn": "低配置区", "range": "15-20%",
        "color": "#3b82f6", "emoji": "🔵", "position": "70-85%", "pos_min": 70, "pos_max": 85,
        "action": "标准建仓", "desc": "耐心持有, 不因波动减仓"},
    3: {"name": "Ⅲ · NEUTRAL", "cn": "中性均衡", "range": "20-27%",
        "color": "#eab308", "emoji": "🟡", "position": "50-65%", "pos_min": 50, "pos_max": 65,
        "action": "均衡持有", "desc": "有纪律地持有, 到了就卖"},
    4: {"name": "Ⅳ · GETTING HOT", "cn": "偏热区域", "range": "27-34%",
        "color": "#f97316", "emoji": "🟠", "position": "25-40%", "pos_min": 25, "pos_max": 40,
        "action": "系统减仓", "desc": "每周减5%总仓位"},
    5: {"name": "Ⅴ · EUPHORIA", "cn": "极度过热", "range": ">34%",
        "color": "#ef4444", "emoji": "🔴", "position": "0-15%", "pos_min": 0, "pos_max": 15,
        "action": "清仓防守", "desc": "3天内完成清仓"},
}

# ===== US_AIAE × US_ERP 仓位矩阵 =====
POSITION_MATRIX_US = {
    "erp_gt5":  [95, 85, 70, 45, 20],
    "erp_3_5":  [90, 80, 65, 40, 15],
    "erp_1_3":  [85, 70, 55, 30, 10],
    "erp_lt1":  [75, 60, 40, 20,  5],
}

# ===== 子策略配额矩阵 (美股ETF: SPY/QQQ/SCHD) =====
SUB_STRATEGY_ALLOC_US = {
    1: {"spy": 40, "qqq": 35, "schd": 25},
    2: {"spy": 40, "qqq": 30, "schd": 30},
    3: {"spy": 35, "qqq": 25, "schd": 40},
    4: {"spy": 25, "qqq": 10, "schd": 65},
    5: {"spy": 10, "qqq":  0, "schd": 90},
}

# ===== AAII Sentiment 配置 (手动更新 + 自动爬取) =====
AAII_SENTIMENT_FILE = os.path.join(CACHE_DIR, "aaii_sentiment.json")

# 默认值: 近3年AAII Bull-Bear Spread中位数约 +5%
DEFAULT_AAII = {
    "bull_pct": 35.0,
    "bear_pct": 30.0,
    "neutral_pct": 35.0,
    "spread": 5.0,
    "date": "2026-03-27",
    "source": "default",
}


# ===== 美股真实 AIAE (海外 AIAE P1, engines/us_aiae_real.py) =====
TTL_AIAE_REAL = 12 * 3600
_Z1_START = datetime(1945, 10, 1)
_Z1_LIVE_CACHE = os.path.join(CACHE_DIR, "us_aiae_z1_live.csv")


def _fetch_z1_live():
    """CSV 缺失或过期时, 用 FRED 实时拉取 6 个 Z.1 序列 (全历史); 成功则写 data_lake 缓存。"""
    import pandas as _pd
    from engines import us_aiae_real as _r
    fred = _get_fred()
    if not fred:
        return None
    out = {}
    for sid in _r.SERIES_ALL:
        s = fred_get_series(sid, lambda sid=sid: fred.get_series(sid, observation_start=_Z1_START), start=_Z1_START)
        if s is None or len(s) == 0:
            return None
        out[sid] = s
    df = _pd.DataFrame(out)
    df.index = _pd.to_datetime(df.index).strftime("%Y-%m-%d")
    df.index.name = "date"
    try:
        df.to_csv(_Z1_LIVE_CACHE)
    except Exception as e:
        _log(f"Z.1 实时缓存写入失败: {e}", "WARN")
    return _r.frame_from_series(out)


_US_AIAE_FWD_LOG = os.path.join(CACHE_DIR, "us_aiae_forward_log.csv")
_US_AIAE_FWD_COLS = ["date", "aiae", "basis", "measured_quarter", "measured_aiae", "pct", "shadow_tier", "z1_source"]


def _append_us_aiae_forward_log(res: Dict, path: Optional[str] = None) -> bool:
    """P2 影子期前向记录: 每日一行, 同日不重复写。失败不影响读数。"""
    import csv
    path = path or _US_AIAE_FWD_LOG
    day = datetime.now().strftime("%Y-%m-%d")
    try:
        if os.path.exists(path):
            with open(path, encoding="utf-8") as f:
                if any(line.startswith(day + ",") for line in f):
                    return False
        new = not os.path.exists(path)
        with open(path, "a", encoding="utf-8", newline="") as f:
            w = csv.writer(f)
            if new:
                w.writerow(_US_AIAE_FWD_COLS)
            w.writerow([day, res.get("aiae"), res.get("basis"), (res.get("measured") or {}).get("quarter"),
                        (res.get("measured") or {}).get("aiae"), res.get("pct"), res.get("shadow_tier"),
                        res.get("z1_source")])
        return True
    except Exception as e:
        _log(f"US AIAE 前向日志写入失败: {e}", "WARN")
        return False


def get_us_aiae_real(force: bool = False) -> Optional[Dict]:
    """美股真实 AIAE 读数 (估值背景)。优先仓库 CSV; 过期/缺失时实时拉 FRED; 全部失败返回 None。"""
    def _compute():
        import pandas as _pd
        from engines import us_aiae_real as _r
        z1, src = None, None
        try:
            z1, src = _r.load_z1(), "repo_csv"
        except FileNotFoundError:
            pass
        except Exception as e:
            _log(f"Z.1 CSV 读取失败: {e}", "WARN")
        stale = True
        if z1 is not None:
            last_q = z1[list(_r.SERIES_ALL)].dropna().index.max()
            stale = (_pd.Timestamp.today() - last_q).days > _r.PARAMS["stale_days"]
        if z1 is None or stale:
            try:
                live = _fetch_z1_live()
                if live is not None:
                    z1, src = live, "fred_live"
            except Exception as e:
                _log(f"Z.1 FRED 实时拉取失败: {e}", "WARN")
        if z1 is None and os.path.exists(_Z1_LIVE_CACHE):
            try:
                z1, src = _r.load_z1(_Z1_LIVE_CACHE), "data_lake_cache"
            except Exception:
                pass
        if z1 is None:
            return {"status": "unavailable", "reason": "Z.1 数据不可用 (运行 _dev_tools/update_us_aiae_z1.py)"}
        spx = None
        fred = _get_fred()
        if fred:
            try:
                start = datetime.now() - timedelta(days=400)
                spx = fred_get_series("SP500", lambda: fred.get_series("SP500", observation_start=start), start=start)
            except Exception as e:
                _log(f"SP500 获取失败, nowcast 改用 Shiller 月均价: {e}", "WARN")
        res = _r.compute(z1=z1, spx_daily=spx)
        if res is None:
            return {"status": "unavailable", "reason": "计算失败"}
        res["status"] = "success"
        res["z1_source"] = src
        _append_us_aiae_forward_log(res)
        return res

    if force:
        _engine_cache.invalidate_prefix("us_aiae_real")
    return _cached("us_aiae_real", TTL_AIAE_REAL, _compute)


class AIAEUSEngine:
    """美股 AIAE 宏观仓位管控引擎 V1.0"""

    VERSION = "1.0"
    REGION = "US"

    # === 上月 AIAE 缓存文件路径 (用于动态斜率计算) ===
    _PREV_AIAE_FILE = os.path.join(CACHE_DIR, "aiae_us_prev_month.json")

    def __init__(self):
        self._aaii_data = self._load_aaii_sentiment()

    # ========== 数据获取层 ==========

    def _fetch_wilshire5000_market_cap(self) -> Dict:
        """获取 Wilshire 5000 指数值 (代理美股总市值)
        V1.4: 增强 fallback 链, 适配中国云服务器 (yfinance 不可用) 环境
        Fallback 链: yfinance → Stooq CSV (中国可访问) → FRED 季频 → 磁盘缓存(永不失效) → 硬编码
        """
        def _fetch():
            cache_file = os.path.join(CACHE_DIR, "aiae_us_wilshire.json")

            # === 常量 ===
            _VTI_SCALE = 203.4  # ^W5000 / VTI ≈ 203.4 (2026-04-27 锚点)
            _WILSHIRE_MIN = 10000   # 低于此值100%为异常数据
            _WILSHIRE_MAX = 200000  # 高于此值100%为异常数据
            _MKTCAP_MIN_T = 10.0   # 美股总市值不可能低于 $10T

            def _validate_and_save(latest_val, trade_date_str, source, raw_price=None):
                """统一校验+保存逻辑"""
                if latest_val < _WILSHIRE_MIN or latest_val > _WILSHIRE_MAX:
                    _log(f"⛔ Wilshire ({source}) 值 {latest_val:.0f} 超出合理范围, 跳过", "ERROR")
                    return None
                market_cap_trillion = round(latest_val / 1000, 2)
                if market_cap_trillion < _MKTCAP_MIN_T:
                    _log(f"⛔ Wilshire ({source}) 隐含市值 ${market_cap_trillion}T < ${_MKTCAP_MIN_T}T, 跳过", "ERROR")
                    return None
                result = {
                    "trade_date": trade_date_str,
                    "wilshire_index": round(latest_val, 2),
                    "market_cap_trillion_usd": market_cap_trillion,
                    "source": source,
                    "fetched_at": datetime.now().isoformat()
                }
                if raw_price is not None:
                    result["raw_price"] = round(raw_price, 2)
                atomic_write_json(result, cache_file)
                _log(f"Wilshire5000 ({source}): {latest_val:.0f} (≈${market_cap_trillion}T)")
                return result

            # === Tier 1: yfinance ^W5000 / VTI (需要翻墙, 本地环境可用) ===
            for sym, is_index in [("^W5000", True), ("VTI", False)]:
                try:
                    import yfinance as yf
                    df = yf.download(sym, period="3mo", progress=False, auto_adjust=False)
                    if df is not None and not df.empty:
                        close_col = df["Close"]
                        if hasattr(close_col, "columns"):
                            close_col = close_col.iloc[:, 0]
                        raw_price = float(close_col.dropna().iloc[-1])
                        latest_date = df.index[-1]
                        latest_val = raw_price if is_index else raw_price * _VTI_SCALE
                        # ^W5000 返回 VTI 量级时自动校正
                        if is_index and 50 < latest_val < 1000:
                            _log(f"⚠️ ^W5000 返回 VTI 量级值 {raw_price:.2f}, 自动校正", "WARN")
                            latest_val = raw_price * _VTI_SCALE
                        result = _validate_and_save(latest_val, latest_date.strftime("%Y-%m-%d"),
                                                   f"yfinance_{sym.replace('^','')}", raw_price)
                        if result:
                            return result
                except Exception as e:
                    _log(f"yfinance {sym} error: {e}", "WARN")

            # === Tier 2: Stooq CSV API (中国可访问, 无需翻墙) ===
            # stooq.com 提供免费历史数据 CSV, 在中国大陆可直接访问
            for stooq_sym, is_etf in [("^spx", False), ("spy.us", True)]:
                try:
                    import urllib.request
                    import csv
                    import io
                    # SPX (S&P500) → 乘以系数换算为 Wilshire 估计值
                    # 2026-04-28 实测锚点: W5000=71303, SPX=7139 → SPX_SCALE=10.0
                    # SPY=711.69 → SPY_SCALE=100.2
                    _SPX_SCALE = 10.0
                    _SPY_SCALE = 100.2

                    url = f"https://stooq.com/q/l/?s={stooq_sym}&f=sd2t2ohlcv&h&e=csv"
                    req = urllib.request.Request(url, headers={
                        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)",
                    })
                    with urllib.request.urlopen(req, timeout=10) as resp:
                        raw = resp.read().decode('utf-8')

                    reader = csv.DictReader(io.StringIO(raw))
                    for row in reader:
                        close_str = row.get("Close", "").strip()
                        date_str = row.get("Date", "").strip()
                        if close_str and close_str != "N/D" and date_str:
                            price = float(close_str)
                            scale = _SPY_SCALE if is_etf else _SPX_SCALE
                            wilshire_est = price * scale
                            result = _validate_and_save(wilshire_est, date_str,
                                                       f"stooq_{stooq_sym.replace('^','')}", price)
                            if result:
                                return result
                        break  # 只需要第一行
                except Exception as e:
                    _log(f"Stooq {stooq_sym} error: {e}", "WARN")

            # === Tier 3: FRED 季频总市值 (需要 API Key) ===
            fred = _get_fred()
            if fred:
                try:
                    from datetime import timedelta as _td
                    @retry_with_backoff(max_retries=2, base_delay=2.0)
                    def _call_fred():
                        return fred_get_series(
                            "BOGZ1FL073164003Q",
                            lambda: fred.get_series(
                                "BOGZ1FL073164003Q",
                                observation_start=datetime.now() - _td(days=400),
                            ),
                            start=datetime.now() - _td(days=400),
                        )
                    series = _call_fred()
                    if series is not None and not series.empty:
                        series = series.dropna()
                        latest_val = float(series.iloc[-1])
                        market_cap_trillion = round(latest_val / 1000000, 2)
                        if market_cap_trillion >= _MKTCAP_MIN_T:
                            wilshire_approx = round(market_cap_trillion * 1000, 2)
                            result = {
                                "trade_date": series.index[-1].strftime("%Y-%m-%d"),
                                "wilshire_index": wilshire_approx,
                                "market_cap_trillion_usd": market_cap_trillion,
                                "source": "fred_quarterly",
                                "fetched_at": datetime.now().isoformat()
                            }
                            atomic_write_json(result, cache_file)
                            _log(f"Wilshire (FRED quarterly proxy): ≈${market_cap_trillion}T", "WARN")
                            return result
                        else:
                            _log(f"⛔ FRED quarterly MktCap=${market_cap_trillion}T < ${_MKTCAP_MIN_T}T", "ERROR")
                except Exception as e:
                    _log(f"FRED quarterly proxy error: {e}", "WARN")
            else:
                _log("FRED API 不可用 (FRED_API_KEY 未配置或 fredapi 未安装)", "WARN")

            # === Tier 4: 磁盘缓存 (V1.4: 永不失效, 宁用旧数据不用硬编码) ===
            if os.path.exists(cache_file):
                try:
                    with open(cache_file, 'r', encoding='utf-8') as f:
                        cached = json.load(f)
                    cached_mktcap = cached.get("market_cap_trillion_usd", 0)
                    cached_wilshire = cached.get("wilshire_index", 0)
                    if cached_mktcap >= _MKTCAP_MIN_T and _WILSHIRE_MIN <= cached_wilshire <= _WILSHIRE_MAX:
                        cached["source"] = cached.get("source", "disk_cache") + "_stale"
                        cached["is_stale_cache"] = True
                        _log(f"⚠️ Wilshire: 所有在线源失败, 使用磁盘缓存 (${cached_mktcap}T, 源={cached.get('source')})", "WARN")
                        return cached
                    else:
                        _log(f"⛔ 磁盘缓存数据异常: MktCap=${cached_mktcap}T, Wilshire={cached_wilshire}", "ERROR")
                except Exception as e:
                    _log(f"磁盘缓存读取失败: {e}", "ERROR")

            # === Tier 5: 终极 fallback (V1.4: 更新为 $68T 中位估计 + 醒目标记) ===
            _log("⛔ Wilshire: 所有数据源+磁盘缓存全部失败, 使用硬编码 $68T (2026-04估计中位值)", "ERROR")
            _log("💡 解决方案: 1) 确保服务器有 .env 文件(含FRED_API_KEY)  2) 从本地 SCP 拷贝 data_lake/aiae_us_wilshire.json", "ERROR")
            return {
                "trade_date": datetime.now().strftime("%Y-%m-%d"),
                "wilshire_index": 68000,
                "market_cap_trillion_usd": 68.0,
                "source": "hardcoded_fallback",
                "fetched_at": datetime.now().isoformat(),
                "is_fallback": True
            }

        return _cached("us_aiae_wilshire", _get_wilshire_ttl(), _fetch)

    def _fetch_us_m2(self) -> Dict:
        """获取美国 M2 货币供应 (FRED M2SL, 月频)"""
        def _fetch():
            cache_file = os.path.join(CACHE_DIR, "aiae_us_m2.json")
            fred = _get_fred()
            if fred:
                try:
                    start_dt = datetime.now() - timedelta(days=180)
                    @retry_with_backoff(max_retries=2, base_delay=1.0)
                    def _call_fred():
                        return fred_get_series(
                            "M2SL",
                            lambda: fred.get_series("M2SL", observation_start=start_dt),
                            start=start_dt,
                        )
                    series = _call_fred()
                    if series is not None and not series.empty:
                        series = series.dropna()
                        latest = float(series.iloc[-1])
                        # M2SL 单位: Billions of Dollars
                        m2_trillion = round(latest / 1000, 2)
                        result = {
                            "month": series.index[-1].strftime("%Y-%m"),
                            "m2_billions": round(latest, 1),
                            "m2_trillion_usd": m2_trillion,
                            "fetched_at": datetime.now().isoformat()
                        }
                        atomic_write_json(result, cache_file)
                        _log(f"US M2: ${m2_trillion}T")
                        return result
                except Exception as e:
                    _log(f"FRED M2SL error: {e}", "WARN")

            if os.path.exists(cache_file):
                with open(cache_file, 'r', encoding='utf-8') as f:
                    return json.load(f)

            return {
                "month": "2026-02", "m2_billions": 21500,
                "m2_trillion_usd": 21.5,
                "fetched_at": datetime.now().isoformat(), "is_fallback": True
            }

        return _cached("us_aiae_m2", TTL_M2, _fetch)

    def _fetch_us_margin_debt(self) -> Dict:
        """获取美股融资余额代理 (FRED BOGZ1FL663067003Q 或降级估算)"""
        def _fetch():
            cache_file = os.path.join(CACHE_DIR, "aiae_us_margin.json")
            fred = _get_fred()
            if fred:
                try:
                    # 尝试 FINRA Margin Debt 代理序列
                    start_dt = datetime.now() - timedelta(days=400)
                    @retry_with_backoff(max_retries=2, base_delay=1.0)
                    def _call_fred():
                        return fred_get_series(
                            "BOGZ1FL663067003Q",
                            lambda: fred.get_series("BOGZ1FL663067003Q", observation_start=start_dt),
                            start=start_dt,
                        )
                    series = _call_fred()
                    if series is not None and not series.empty:
                        series = series.dropna()
                        latest = float(series.iloc[-1])
                        # 单位: Millions of Dollars
                        margin_trillion = round(latest / 1000000, 4)
                        result = {
                            "date": series.index[-1].strftime("%Y-%m-%d"),
                            "margin_millions": round(latest, 0),
                            "margin_trillion_usd": margin_trillion,
                            "fetched_at": datetime.now().isoformat()
                        }
                        atomic_write_json(result, cache_file)
                        _log(f"US Margin: ${margin_trillion}T")
                        return result
                except Exception as e:
                    _log(f"FRED margin proxy error: {e}", "WARN")

            if os.path.exists(cache_file):
                with open(cache_file, 'r', encoding='utf-8') as f:
                    return json.load(f)

            # 降级: 2024-2026 NYSE Margin Debt 约 $700-800B
            return {
                "date": datetime.now().strftime("%Y-%m-%d"),
                "margin_millions": 750000,
                "margin_trillion_usd": 0.75,
                "fetched_at": datetime.now().isoformat(), "is_fallback": True
            }

        return _cached("us_aiae_margin", TTL_MARGIN, _fetch)

    def _load_aaii_sentiment(self) -> Dict:
        """加载 AAII 散户情绪数据 (自动爬取 + 手动文件 + 过期自动刷新)"""
        if os.path.exists(AAII_SENTIMENT_FILE):
            try:
                with open(AAII_SENTIMENT_FILE, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                # V1.1: 检查文件年龄，超过 TTL_AAII(3天) 自动重爬
                file_age = time.time() - os.path.getmtime(AAII_SENTIMENT_FILE)
                if file_age > TTL_AAII:
                    _log(f"AAII 文件过期 ({file_age/86400:.1f}天), 尝试自动重爬...", "INFO")
                    crawled = self._crawl_aaii_sentiment()
                    if crawled:
                        return crawled
                    _log("AAII 重爬失败, 继续使用旧数据", "WARN")
                _log(f"AAII Sentiment loaded: spread={data.get('spread', 0):.1f}% ({data.get('date', '?')})")
                return data
            except Exception:
                pass

        # 尝试自动爬取
        crawled = self._crawl_aaii_sentiment()
        if crawled:
            return crawled

        _log("AAII: 使用默认中性值", "WARN")
        return DEFAULT_AAII.copy()

    def _crawl_aaii_sentiment(self) -> Optional[Dict]:
        """获取散户情绪数据 (多源 fallback)
        V1.2: AAII 网站反爬严格(403), 新增 FRED UMich 消费者信心指数作为代理
        Fallback 链: AAII 网页 → FRED UMCSENT → 磁盘缓存 → 默认值

        映射逻辑 (UMich → AAII Spread):
          UMich 范围 50~100, 均值≈75
          AAII Spread 范围 -30~+30, 均值≈+5
          spread = (umich - 75) / 25 × 30 + 5
        """
        # === 方案1: 直接爬 AAII (保留, 万一恢复) ===
        try:
            import urllib.request
            import re
            url = "https://www.aaii.com/sentimentsurvey"
            req = urllib.request.Request(url, headers={
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
                "Accept": "text/html",
                "Accept-Language": "en-US,en;q=0.9",
            })
            with urllib.request.urlopen(req, timeout=8) as resp:
                html = resp.read().decode('utf-8', errors='replace')
            bull_m = re.search(r'Bullish[:\s]*?([\d.]+)\s*%', html, re.IGNORECASE)
            bear_m = re.search(r'Bearish[:\s]*?([\d.]+)\s*%', html, re.IGNORECASE)
            neut_m = re.search(r'Neutral[:\s]*?([\d.]+)\s*%', html, re.IGNORECASE)
            if bull_m and bear_m:
                bull = float(bull_m.group(1))
                bear = float(bear_m.group(1))
                neutral = float(neut_m.group(1)) if neut_m else (100 - bull - bear)
                spread = bull - bear
                data = {
                    "bull_pct": round(bull, 1), "bear_pct": round(bear, 1),
                    "neutral_pct": round(neutral, 1), "spread": round(spread, 1),
                    "date": datetime.now().strftime("%Y-%m-%d"), "source": "aaii_crawl"
                }
                atomic_write_json(data, AAII_SENTIMENT_FILE)
                _log(f"AAII crawled: Bull={bull:.1f}% Bear={bear:.1f}% Spread={spread:.1f}%")
                return data
        except Exception as e:
            _log(f"AAII crawl failed: {e}", "DEBUG")

        # === 方案2: FRED UMich Consumer Sentiment (月频, 零反爬) ===
        try:
            fred = _get_fred()
            if fred:
                series = fred_get_series(
                    "UMCSENT",
                    lambda: fred.get_series(
                        "UMCSENT",
                        observation_start=datetime.now() - timedelta(days=90),
                    ),
                    start=datetime.now() - timedelta(days=90),
                )
                if series is not None and not series.empty:
                    series = series.dropna()
                    umich = float(series.iloc[-1])
                    umich_date = series.index[-1].strftime("%Y-%m-%d")
                    # 线性映射: UMich [50, 100] → AAII Spread [-25, +35]
                    spread = (umich - 75) / 25 * 30 + 5
                    spread = max(-30.0, min(30.0, spread))
                    bull = round(35 + spread / 2, 1)
                    bear = round(35 - spread / 2, 1)
                    neutral = round(100 - bull - bear, 1)
                    data = {
                        "bull_pct": bull, "bear_pct": bear,
                        "neutral_pct": neutral, "spread": round(spread, 1),
                        "date": umich_date, "source": "fred_umcsent",
                        "umich_raw": round(umich, 1),
                    }
                    atomic_write_json(data, AAII_SENTIMENT_FILE)
                    _log(f"AAII (UMich proxy): {umich:.1f} → spread={spread:.1f}% ({umich_date})")
                    return data
        except Exception as e:
            _log(f"FRED UMich fallback failed: {e}", "WARN")

        return None

    def _effective_aaii_spread(self) -> float:
        """2026-10-23: 情绪因子可信度加权.

        effective = 中性先验(+5) + (原始spread - 5) × 可信度
          来源可信度: AAII 实爬/手动 = 1.0; UMich 代理 = 0 (2026-11-01 起; 消费者信心 ≠ 投资者情绪)
          新鲜度衰减: ≤30天 = 1.0, 30~90天线性降到 0, >90天 = 0 (完全回归中性)
        例: UMich 代理 (-23.0) → 可信度 0 → 有效 spread = +5.0 (中性)
        """
        d = self._aaii_data or {}
        raw = float(d.get("spread", 5.0))
        src = d.get("source", "default")
        # 2026-11-01 海外 AIAE P0: 密歇根消费者信心 ≠ 投资者情绪, 代理可信度 0.5 → 0 (读数仍保留展示)
        src_w = {"aaii_crawl": 1.0, "manual": 1.0, "fred_umcsent": 0.0}.get(src, 0.0)
        try:
            age = (datetime.now() - datetime.strptime(d.get("date", ""), "%Y-%m-%d")).days
        except Exception:
            age = 999
        fresh_w = 1.0 if age <= 30 else max(0.0, 1.0 - (age - 30) / 60.0)
        rel = src_w * fresh_w
        eff = 5.0 + (raw - 5.0) * rel
        d["effective_spread"] = round(eff, 1)
        d["reliability"] = round(rel, 2)
        d["age_days"] = age
        if rel < 0.999:
            _log(f"AAII 情绪可信度={rel:.2f} (source={src}, {age}天前) → 有效spread {raw:.1f}→{eff:.1f}", "WARN")
        return eff

    def update_aaii_sentiment(self, bull_pct: float, bear_pct: float, neutral_pct: float = None):
        """手动更新 AAII 情绪数据"""
        if neutral_pct is None:
            neutral_pct = 100 - bull_pct - bear_pct
        data = {
            "bull_pct": round(bull_pct, 1),
            "bear_pct": round(bear_pct, 1),
            "neutral_pct": round(neutral_pct, 1),
            "spread": round(bull_pct - bear_pct, 1),
            "date": datetime.now().strftime("%Y-%m-%d"),
            "source": "manual"
        }
        atomic_write_json(data, AAII_SENTIMENT_FILE)
        self._aaii_data = data
        _log(f"AAII 手动更新: spread={data['spread']:.1f}%")

    # ========== 核心计算层 ==========

    def compute_aiae_core(self, mktcap_trillion: float, m2_trillion: float) -> float:
        """
        US_AIAE_Core = MktCap / M2 比值 → 归一化到 AIAE 标度

        V1.4 优化: 区间从 [0.7, 2.6] → [0.7, 3.2]
        原因: 2025-2026 美股 MktCap/M2 ratio 突破 3.0, 旧上限 2.6 导致
              Core 长期钳制在 45% 天花板, 丧失区分 Ⅳ/Ⅴ 级的能力.
              上限 3.2 覆盖 2000 互联网泡沫 (ratio≈3.06) + 10% 余量.

        历史锚点:
          ratio=0.7  (极端底部余量)      → AIAE=10%  (Ⅰ级恐慌区间)
          ratio=3.2  (覆盖互联网泡沫+余量)→ AIAE=45%  (Ⅴ级过热区间)

        线性映射: AIAE = 10 + (ratio - 0.7) / (3.2 - 0.7) × 35
        """
        if m2_trillion <= 0:
            return 25.0

        # V1.3: 输入合理性校验
        if mktcap_trillion < 10.0:
            _log(f"⛔ compute_aiae_core: MktCap=${mktcap_trillion}T 不合理 (< $10T), 使用中性默认值 25%", "ERROR")
            return 25.0

        ratio = mktcap_trillion / m2_trillion

        # V1.3: ratio 合理性校验 (历史范围 0.8-3.2, < 0.3 说明数据异常)
        if ratio < 0.3:
            _log(f"⛔ MktCap/M2 ratio={ratio:.3f} 不合理 (MktCap=${mktcap_trillion}T, M2=${m2_trillion}T), 使用中性默认值 25%", "ERROR")
            return 25.0

        # V1.4: 线性归一化: [0.7, 3.2] → [10%, 45%]
        aiae_core = 10.0 + (ratio - 0.7) / (3.2 - 0.7) * 35.0
        return round(max(5.0, min(50.0, aiae_core)), 2)

    def compute_margin_heat(self, margin_trillion: float, mktcap_trillion: float) -> float:
        """Margin Heat = Margin Debt / Total MktCap × 100
        V1.3: 增加上限钳制, 防止异常 MktCap 导致的荒谬比值
        """
        if mktcap_trillion <= 0:
            return 1.5
        heat = margin_trillion / mktcap_trillion * 100
        # V1.3: Margin/MktCap 历史范围 0.5-2.5%, 超过5%说明分母(MktCap)异常
        if heat > 5.0:
            _log(f"⚠️ MarginHeat={heat:.2f}% 异常偏高 (margin=${margin_trillion}T, mktcap=${mktcap_trillion}T), 钳制为1.5%", "ERROR")
            return 1.5
        return round(heat, 2)

    def compute_us_aiae_v1(self, aiae_core: float, margin_heat: float, aaii_spread: float) -> float:
        """
        US AIAE V1.1 融合
        = 0.60 × AIAE_Core + 0.20 × Margin_归一化 + 0.20 × AAII_归一化

        V1.1 优化:
        - Core 权重 50→60%: 核心基本面指标信噪比最高, 应占主导
        - AAII 权重 30→20%: 散户调查(~300人/周)单次读数噪音大, 降低干扰
        - Margin 归一化上限 3.5→2.5%: 2020后 margin/mktcap 一般在1.0-1.8%, 旧上限稀释信号

        归一化区间与 AIAE_Core 新范围 (5-50%) 对齐:
        Margin heat: 0.5-2.5% → 8-36% AIAE等效
        AAII spread: -30 ~ +30 → 8-38% AIAE等效
        """
        # Margin归一化: 0.5-2.5% → 8-36%
        m_norm = 8 + (margin_heat - 0.5) / (2.5 - 0.5) * (36 - 8)
        m_norm = max(8.0, min(36.0, m_norm))

        # AAII归一化: -30 ~ +30 → 8-38%
        s_norm = 8 + (aaii_spread - (-30)) / (30 - (-30)) * (38 - 8)
        s_norm = max(8.0, min(38.0, s_norm))

        return round(0.60 * aiae_core + 0.20 * m_norm + 0.20 * s_norm, 2)

    # ========== 五档判定层 ==========

    def classify_regime(self, aiae_value: float) -> int:
        """V1.1: 五档阈值微调, Ⅳ/Ⅴ 降低 1-2pp 以匹配 Core 灵敏度提升"""
        if aiae_value < 15:
            return 1
        elif aiae_value < 20:
            return 2
        elif aiae_value < 27:
            return 3
        elif aiae_value < 34:
            return 4
        else:
            return 5

    def compute_slope(self, current: float, previous: float) -> Dict:
        if previous is None or previous == 0:
            return {"slope": 0, "direction": "flat", "signal": None}
        slope = current - previous
        direction = "rising" if slope > 0 else ("falling" if slope < 0 else "flat")
        signal = None
        if slope > 2.0:
            signal = {"type": "accel_up", "text": "US AIAE 加速上行", "level": "warning"}
        elif slope < -2.0:
            signal = {"type": "accel_down", "text": "US AIAE 加速下行", "level": "opportunity"}
        return {"slope": round(slope, 2), "direction": direction, "signal": signal}

    def _load_prev_aiae(self) -> Optional[float]:
        """上个自然月的 AIAE (2026-11-01 数据质量审计 #9: 原实现取"上一次调用的值", 斜率变成相邻调用之差)"""
        from services.monthly_value_store import load_prev_month
        try:
            return load_prev_month(self._PREV_AIAE_FILE)
        except Exception:
            return None

    def _save_current_aiae(self, aiae_v1: float):
        """记录当月 AIAE (同月多次调用只保留最后一次), 供下个月计算斜率"""
        from services.monthly_value_store import save_month_value
        try:
            save_month_value(self._PREV_AIAE_FILE, aiae_v1, writer=atomic_write_json)
        except Exception as e:
            _log(f"月度AIAE保存失败: {e}", "WARN")

    def classify_erp_level(self, erp_value: float) -> str:
        if erp_value >= 5.0:
            return "erp_gt5"
        elif erp_value >= 3.0:
            return "erp_3_5"
        elif erp_value >= 1.0:
            return "erp_1_3"
        else:
            return "erp_lt1"

    def get_position_from_matrix(self, regime: int, erp_level: str) -> int:
        row = POSITION_MATRIX_US.get(erp_level, POSITION_MATRIX_US["erp_1_3"])
        idx = min(regime - 1, 4)
        return row[idx]

    def allocate_sub_strategies(self, regime: int, total_position: int) -> Dict:
        alloc = SUB_STRATEGY_ALLOC_US.get(regime, SUB_STRATEGY_ALLOC_US[3])
        return {
            "spy":  {"name": "S&P 500 (SPY)", "pct": alloc["spy"],  "position": round(total_position * alloc["spy"] / 100, 1)},
            "qqq":  {"name": "Nasdaq-100 (QQQ)", "pct": alloc["qqq"],  "position": round(total_position * alloc["qqq"] / 100, 1)},
            "schd": {"name": "高股息 (SCHD)", "pct": alloc["schd"], "position": round(total_position * alloc["schd"] / 100, 1)},
        }

    # ========== 信号系统 ==========

    def generate_signals(self, aiae_value: float, regime: int, slope_info: Dict, margin_heat: float) -> List[Dict]:
        signals = []
        ri = REGIMES_US[regime]
        signals.append({
            "type": "main", "level": ri["emoji"],
            "text": f"{ri['cn']}信号 · US AIAE={aiae_value:.1f}% · {ri['action']}",
            "color": ri["color"]
        })

        if slope_info.get("signal"):
            s = slope_info["signal"]
            signals.append({"type": "slope", "level": s["level"], "text": s["text"],
                          "color": "#f59e0b" if s["level"] == "warning" else "#10b981"})

        if margin_heat > 2.5:
            signals.append({"type": "margin", "level": "warning",
                          "text": f"Margin Debt 占比 {margin_heat:.1f}% 偏高", "color": "#f97316"})
        elif margin_heat < 0.8:
            signals.append({"type": "margin", "level": "opportunity",
                          "text": f"Margin Debt 占比 {margin_heat:.1f}% 极低, 杠杆出清", "color": "#10b981"})

        aaii = self._aaii_data
        spread = aaii.get("effective_spread", aaii.get("spread", 0))
        if spread > 20:
            signals.append({"type": "sentiment", "level": "warning",
                          "text": f"AAII 极度乐观 spread={spread:.0f}%, 警惕回调", "color": "#ef4444"})
        elif spread < -15:
            signals.append({"type": "sentiment", "level": "opportunity",
                          "text": f"AAII 极度悲观 spread={spread:.0f}%, 逆向机会", "color": "#10b981"})

        return signals

    # ========== 历史走势数据 ==========

    def get_chart_data(self) -> Dict:
        dates = [s["date"] for s in HISTORICAL_SNAPSHOTS]
        values = [s["aiae"] for s in HISTORICAL_SNAPSHOTS]
        labels = [s["label"] for s in HISTORICAL_SNAPSHOTS]
        bands = [
            {"name": "Ⅰ上限", "value": 15, "color": "#10b981"},
            {"name": "Ⅱ上限", "value": 20, "color": "#3b82f6"},
            {"name": "Ⅲ上限", "value": 27, "color": "#eab308"},
            {"name": "Ⅳ上限", "value": 34, "color": "#f97316"},
        ]
        return {
            "dates": dates, "values": values, "labels": labels,
            "bands": bands,
            "stats": {"mean": 24.0, "min": 12.5, "max": 43.5,
                      "current": values[-1] if values else 25.0}
        }

    # ========== 交叉验证 ==========

    def _get_us_erp_value(self) -> float:
        self._erp_fallback = False  # 2026-11-01 审计 #6/#13: 记录 ERP 是否降级
        try:
            from engines.erp_us_engine import get_us_erp_engine
            engine = get_us_erp_engine()
            signal = engine.compute_signal()
            if signal.get("status") == "success":
                return signal["current_snapshot"].get("erp_value", 2.0)
        except Exception as e:
            _log(f"US ERP引擎读取失败, 降级2.0%: {e}", "WARN")
        self._erp_fallback = True
        return 2.0

    def _cross_validate(self, regime: int, erp_value: float) -> Dict:
        erp_level = self.classify_erp_level(erp_value)

        if regime <= 2 and erp_value >= 5.0:
            confidence, verdict, color = 5, "极强买入 · 双因子共振", "#10b981"
        elif regime <= 2 and erp_value >= 3.0:
            confidence, verdict, color = 5, "强买入", "#10b981"
        elif regime <= 2 and erp_value >= 1.0:
            confidence, verdict, color = 4, "标准买入", "#34d399"
        elif regime <= 2 and erp_value < 1.0:
            confidence, verdict, color = 3, "谨慎买入 · ERP偏低", "#eab308"
        elif regime == 3 and erp_value >= 3.0:
            confidence, verdict, color = 3, "谨慎乐观", "#34d399"
        elif regime == 3 and 1.0 <= erp_value < 3.0:
            confidence, verdict, color = 3, "中性", "#94a3b8"
        elif regime == 3 and erp_value < 1.0:
            confidence, verdict, color = 3, "中性偏谨慎", "#eab308"
        elif regime == 4 and erp_value >= 3.0:
            confidence, verdict, color = 2, "矛盾信号 · 以AIAE为准", "#f97316"
        elif regime == 4 and erp_value < 3.0:
            confidence, verdict, color = 4, "强减仓", "#ef4444"
        elif regime == 5 and erp_value < 1.0:
            confidence, verdict, color = 5, "全面撤退", "#ef4444"
        else:
            confidence, verdict, color = 4, "清仓 · ERP未确认底部", "#ef4444"

        return {
            "aiae_regime": regime, "erp_value": erp_value, "erp_level": erp_level,
            "confidence": confidence, "confidence_stars": "⭐" * confidence,
            "verdict": verdict, "color": color,
        }

    # ========== 完整报告 ==========

    def generate_report(self) -> Dict:
        t0 = time.time()
        try:
            # P0 fix: 使用模块级线程池, 避免 with 块 shutdown(wait=True) 吞掉 timeout
            try:
                f_mkt = _bg_executor.submit(self._fetch_wilshire5000_market_cap)
                f_m2 = _bg_executor.submit(self._fetch_us_m2)
                f_margin = _bg_executor.submit(self._fetch_us_margin_debt)
                mkt_data = f_mkt.result(timeout=45)
                m2_data = f_m2.result(timeout=45)
                margin_data = f_margin.result(timeout=45)
            except (RuntimeError, TimeoutError):
                # 线程池 shutdown 或 FRED 超时 → 降级同步 (内部有磁盘缓存 fallback)
                _log("并行获取超时或线程池不可用, 降级同步获取", "WARN")
                mkt_data = self._fetch_wilshire5000_market_cap()
                m2_data = self._fetch_us_m2()
                margin_data = self._fetch_us_margin_debt()
            _log(f"数据获取完成 ({time.time()-t0:.1f}s)")

            mktcap = mkt_data.get("market_cap_trillion_usd", 52.0)
            m2 = m2_data.get("m2_trillion_usd", 21.5)
            margin_t = margin_data.get("margin_trillion_usd", 0.75)

            aiae_core = self.compute_aiae_core(mktcap, m2)
            margin_heat = self.compute_margin_heat(margin_t, mktcap)
            aaii_spread = self._effective_aaii_spread()
            aiae_v1 = self.compute_us_aiae_v1(aiae_core, margin_heat, aaii_spread)

            regime = self.classify_regime(aiae_v1)
            regime_info = REGIMES_US[regime]

            # 斜率计算: 优先使用磁盘缓存的动态上月值
            prev_aiae = self._load_prev_aiae()
            slope_info = self.compute_slope(aiae_v1, prev_aiae)
            # 保存本次值供下月使用
            self._save_current_aiae(aiae_v1)

            # 2026-11-01 海外 AIAE P1: 不再读取 ERP、不再计算仓位矩阵 / ETF 配额 / 交叉验证 (审计 #27 关闭)
            from services.aiae_quality import assess as _assess_quality
            from services.overseas_aiae_background import removed_position, removed_cross_validation
            quality = _assess_quality({"市值": mkt_data, "M2": m2_data, "融资": margin_data})
            signals = self.generate_signals(aiae_v1, regime, slope_info, margin_heat)
            chart_data = self.get_chart_data()
            cross_validation = removed_cross_validation()
            aiae_real = get_us_aiae_real()

            _log(f"报告完成 ({time.time()-t0:.1f}s) | 代理AIAE={aiae_v1}% Regime={regime} | 真实AIAE={(aiae_real or {}).get('aiae')}")

            return {
                "status": "success",
                "data_quality_score": quality["data_quality_score"],
                "decision_locked": quality["decision_locked"],
                "data_warnings": quality["data_warnings"],
                "engine_version": self.VERSION,
                "region": self.REGION,
                "updated_at": datetime.now().isoformat(),
                "latency_ms": round((time.time()-t0)*1000),

                "current": {
                    "aiae_core": aiae_core,
                    "aiae_v1": aiae_v1,
                    "regime": regime,
                    "regime_info": regime_info,
                    "market_cap_trillion": mktcap,
                    "m2_trillion": m2,
                    "margin_heat": margin_heat,
                    "aaii_sentiment": self._aaii_data,
                    "slope": slope_info,
                },

                "position": removed_position(regime),

                "signals": signals,
                "cross_validation": cross_validation,
                "chart": chart_data,
                "regimes": REGIMES_US,
                # P1: 真实 AIAE (美联储 Z.1) — 美股估值背景以此为准; 上面的 aiae_v1 为旧代理口径, 仅作对照
                "aiae_real": aiae_real,

                "raw_data": {
                    "mkt": mkt_data,
                    "m2": m2_data,
                    "margin": margin_data,
                    "aaii": self._aaii_data,
                }
            }

        except Exception as e:
            _log(f"generate_report 异常: {e}", "ERROR")
            _logger.debug("Traceback", exc_info=True)
            return self._fallback_report(str(e))

    def _fallback_report(self, reason: str) -> Dict:
        return {
            "status": "fallback",
            "message": reason,
            "engine_version": self.VERSION,
            "region": self.REGION,
            "updated_at": datetime.now().isoformat(),
            "current": {
                "aiae_core": 25.0, "aiae_v1": 24.5, "regime": 3,
                "regime_info": REGIMES_US[3],
                "market_cap_trillion": 52.0, "m2_trillion": 21.5,
                "margin_heat": 1.5, "aaii_sentiment": DEFAULT_AAII,
                "slope": {"slope": 0, "direction": "flat", "signal": None},
            },
            "position": __import__("services.overseas_aiae_background", fromlist=["x"]).removed_position(3),
            "signals": [{"type": "fallback", "level": "warning",
                        "text": f"数据降级: {reason}", "color": "#f59e0b"}],
            "cross_validation": __import__("services.overseas_aiae_background", fromlist=["x"]).removed_cross_validation(),
            "chart": self.get_chart_data(),
            "regimes": REGIMES_US,
            "raw_data": {},
        }

    def refresh(self):
        """清除内存缓存, 下次 generate_report 时强制从数据源重新获取"""
        _engine_cache.invalidate_prefix("us_aiae_")  # 含 us_aiae_real
        self._aaii_data = self._load_aaii_sentiment()
        _log("缓存已清除")


# ===== 引擎单例 =====
_us_aiae_instance = None

def get_us_aiae_engine() -> AIAEUSEngine:
    global _us_aiae_instance
    if _us_aiae_instance is None:
        _us_aiae_instance = AIAEUSEngine()
    return _us_aiae_instance


# ===== 自检 =====
if __name__ == "__main__":
    import sys
    if sys.platform == 'win32':
        sys.stdout.reconfigure(encoding='utf-8', errors='replace')

    engine = AIAEUSEngine()
    print("=== US AIAE Engine V1.0 Self-Test ===")
    report = engine.generate_report()
    if report.get("status") in ("success", "fallback"):
        c = report["current"]
        print(f"AIAE_Core: {c['aiae_core']}% | AIAE_V1: {c['aiae_v1']}%")
        print(f"Regime: {c['regime']} ({c['regime_info']['cn']})")
        print(f"MktCap: ${c['market_cap_trillion']}T | M2: ${c['m2_trillion']}T")
        print(f"Margin Heat: {c['margin_heat']}% | AAII Spread: {c['aaii_sentiment'].get('spread', 0)}%")
        r = report.get("aiae_real") or {}
        print(f"Real AIAE (Z.1): {r.get('aiae')}% · 分位 {r.get('pct')} · {r.get('basis')} · {r.get('z1_source')}")
        cv = report["cross_validation"]
        print(f"Cross-Validation: {cv['verdict']} [{'*'*cv['confidence']}]")
        for s in report["signals"]:
            print(f"  > {s['text']}")
        print(f"\n--- Latency: {report.get('latency_ms', '?')}ms | Status: {report['status']} ---")
    else:
        print(f"Failed: {report.get('message')}")
