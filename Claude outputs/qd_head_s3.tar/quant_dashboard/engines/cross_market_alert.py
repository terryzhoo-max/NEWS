"""
AlphaCore · 跨市场 AIAE 联动预警引擎 V1.0
==========================================
监测四市场 (中/美/港/日) AIAE 状态联动, 生成跨市场风险传导预警。

传导系数为经验设定值, 未经回归验证 (原注释"基于历史相关性回归"不实, 2026-11-01 更正)。

V1.1 2026-11-01 (海外 AIAE P0, docs/AIAE_GLOBAL_OPTIMIZATION_PLAN.md):
  - 海外档位是代理口径、未经回测, 只作背景: 告警只陈述状态, 不再给出
    "降低A股仓位 / 清仓海外 / 全面降仓 / 超配A股" 等操作指令;
  - 删除"历史上100%后跌"等无出处的断言;
  - 档位为 None (缺数据 / 降级 / 锁定) 的市场不参与规则, 不再默认按 Ⅲ 档计算。
V1.0 2026-05-26
"""

import threading
from datetime import datetime
from typing import Dict, List, Optional


def _log(msg: str, level: str = "INFO"):
    ts_str = datetime.now().strftime("%H:%M:%S.%f")[:-3]
    print(f"[{ts_str}] [{level}] [CROSS_MKT] {msg}")


# 跨市场传导系数 (经验设定, 未经验证; 仅展示)
CONTAGION_VALIDATED = False
CONTAGION_NOTE = "经验设定值, 未经回归验证"
BACKGROUND_ACTION = "背景信息, 不构成 A 股操作建议"
CONTAGION_MATRIX = {
    ("US", "CN"): 0.45,
    ("US", "HK"): 0.72,
    ("HK", "CN"): 0.35,
    ("JP", "CN"): 0.15,
    ("JP", "HK"): 0.20,
    ("US", "JP"): 0.30,
}

REGION_NAMES = {"CN": "A股", "US": "美股", "JP": "日股", "HK": "港股"}


class CrossMarketAlertEngine:
    """跨市场 AIAE 联动预警引擎"""

    VERSION = "1.1"

    def __init__(self):
        _log(f"CrossMarketAlertEngine V{self.VERSION} 初始化")

    def scan_alerts(self, regimes: Dict[str, int], aiae_values: Dict[str, float] = None) -> List[Dict]:
        """
        扫描跨市场联动告警。
        
        Args:
            regimes: {"CN": 3, "US": 4, "HK": 2, "JP": 3}
            aiae_values: {"CN": 21.5, "US": 28.0, "HK": 12.0, "JP": 17.0} (可选)
        
        Returns:
            告警列表, 按严重度排序
        """
        if not regimes:
            return []

        alerts = []
        cn, us, hk, jp = (regimes.get(k) for k in ("CN", "US", "HK", "JP"))
        known = [r for r in (cn, us, hk, jp) if isinstance(r, int)]

        def _ok(*vals):
            return all(isinstance(v, int) for v in vals)

        def _add(aid, severity, title, message, source, target, coef):
            alerts.append({
                "id": aid, "severity": severity, "emoji": "", "title": title, "message": message,
                "source": source, "target": target, "contagion_coef": coef,
                "contagion_validated": CONTAGION_VALIDATED,
                "action": BACKGROUND_ACTION,
            })

        if _ok(us, cn) and us >= 4 and cn <= 3:
            _add("us_overheat_cn_neutral", "warning", "美股估值读数偏高",
                 f"美股代理读数 R{us}, A股 R{cn}; 美股回调时 A股可能受外部情绪影响", "US", "CN",
                 CONTAGION_MATRIX.get(("US", "CN")))
        if _ok(us, cn) and us <= 2 and cn >= 4:
            _add("us_cold_cn_hot", "info", "美股偏冷 · A股偏热",
                 f"美股代理读数 R{us}, A股 R{cn}, 两地温度背离", "US", "CN",
                 CONTAGION_MATRIX.get(("US", "CN")))
        if _ok(hk) and hk >= 5:
            _add("hk_euphoria", "warning", "港股读数极高",
                 f"港股代理读数 R{hk}", "HK", "CN", CONTAGION_MATRIX.get(("HK", "CN")))
        elif _ok(hk) and hk <= 1:
            _add("hk_extreme_fear", "info", "港股读数极低",
                 f"港股代理读数 R{hk}", "HK", "CN", CONTAGION_MATRIX.get(("HK", "CN")))
        hot = sum(1 for r in known if r >= 4)
        if hot >= 3:
            _add("global_overheat", "warning", "多市场读数同时偏高",
                 f"{len(known)} 个有数据的市场中 {hot} 个 R≥4", "GLOBAL", "ALL", None)
        cold = sum(1 for r in known if r <= 2)
        if cold >= 3:
            _add("global_freeze", "info", "多市场读数同时偏低",
                 f"{len(known)} 个有数据的市场中 {cold} 个 R≤2", "GLOBAL", "ALL", None)
        if _ok(us) and us >= 5:
            _add("us_euphoria_global", "warning", "美股读数处于最高档",
                 f"美股代理读数 R{us} (总市值/M2 口径, 档位未经回测)", "US", "GLOBAL", None)
        if _ok(cn, us) and cn <= 2 and us >= 4:
            _add("cn_cold_us_hot_divergence", "info", "中美温度分化",
                 f"A股 R{cn} vs 美股代理读数 R{us}", "DIVERGENCE", "CN", None)

        # 按严重度排序: critical > warning > opportunity > info
        severity_order = {"critical": 0, "warning": 1, "opportunity": 2, "info": 3}
        alerts.sort(key=lambda x: severity_order.get(x["severity"], 9))

        _log(f"跨市场扫描完成: CN={cn} US={us} HK={hk} JP={jp} → {len(alerts)} 条背景提示")
        return alerts

    def get_contagion_matrix(self) -> Dict:
        """返回传导矩阵 (供前端可视化)"""
        return {
            "matrix": {f"{s}→{t}": c for (s, t), c in CONTAGION_MATRIX.items()},
            "regions": list(REGION_NAMES.keys()),
            "region_names": REGION_NAMES,
            "validated": CONTAGION_VALIDATED,
            "note": CONTAGION_NOTE,
        }


# ===== 引擎单例 =====
_cross_instance = None
_cross_lock = threading.Lock()


def get_cross_alert_engine() -> CrossMarketAlertEngine:
    global _cross_instance
    if _cross_instance is None:
        with _cross_lock:
            if _cross_instance is None:
                _cross_instance = CrossMarketAlertEngine()
    return _cross_instance


# ===== 自检 =====
if __name__ == "__main__":
    import sys
    if sys.platform == 'win32':
        sys.stdout.reconfigure(encoding='utf-8', errors='replace')

    print("=" * 60)
    print("  Cross-Market Alert Engine V1.0 · Self-Test")
    print("=" * 60)

    engine = CrossMarketAlertEngine()

    # 场景1: 美股过热 + A股中性
    print("\n[场景1] 美股过热 + A股中性")
    alerts = engine.scan_alerts({"CN": 3, "US": 4, "HK": 2, "JP": 3})
    for a in alerts:
        print(f"  {a['emoji']} [{a['severity']}] {a['title']}")
        print(f"     {a['message']}")

    # 场景2: 全球同步过热
    print("\n[场景2] 全球同步过热")
    alerts = engine.scan_alerts({"CN": 4, "US": 5, "HK": 4, "JP": 3})
    for a in alerts:
        print(f"  {a['emoji']} [{a['severity']}] {a['title']}")

    # 场景3: 全球冰点
    print("\n[场景3] 全球同步冰点")
    alerts = engine.scan_alerts({"CN": 1, "US": 2, "HK": 1, "JP": 2})
    for a in alerts:
        print(f"  {a['emoji']} [{a['severity']}] {a['title']}")

    # 场景4: 无告警
    print("\n[场景4] 全部中性 (无告警)")
    alerts = engine.scan_alerts({"CN": 3, "US": 3, "HK": 3, "JP": 3})
    print(f"  告警数: {len(alerts)}")

    print(f"\n{'='*60}")
