"""
AlphaCore · A 股 ERP 仓位规则 v4 (2026-10-30 冻结)
===================================================
规则在检验之前一次写死, 参数哈希固定在 PARAM_HASH; 任何参数改动都会让
tests/test_erp_allocation_v4.py 失败 —— 改参数 = 新版本, 必须重新登记并重新做一次性检验。

依据:
  - docs/ERP_VALIDATION_STEP3_CONCLUSIONS.md: ERP 原始值有预测力, 4 年分位与综合分没有;
    O16 趋势门控不增加超额, 只增加换手。
  - data_lake/erp_allocation_research.json: ERP 原始值分档 (raw_6) 在各区间超额为正。
  - 2026-10-30 拆分: 当日 ERP 6.13% 中, E/P 约在历史中位 (全历史 53% 分位),
    10Y 国债 1.64% 处于有数据以来最低 —— ERP 偏高几乎全部来自利率走低。
    分档阈值 2.5~6.5% 是在 10Y ≥ 2.5% 的年代形成的, 低利率下直接套用会结构性偏多。

四条规则 (只作用于沪深300 这类大盘 β 仓位, 不用于行业 / 主题 ETF):
  1. 利率正常化: ERP_adj = E/P − max(10Y, 2.5%)
     (10Y 不低于 2.5% 时 ERP_adj = ERP, 规则与 raw_6 完全相同)
  2. 分档:   ERP_adj 按 2.5/3.5/4.5/5.5/6.5% 分档 → 10/25/45/65/80/90%
  3. 建仓节奏: 每周最后一个交易日评估一次。目标下降立即执行;
             目标上升时, 若 PE 双均线空头 (PE < MA60 且 < MA120) 每次最多 +5pp
             (0 → 65% 约 13 周 ≈ 3 个月), 否则一步到位
  4. 执行:   实际仓位与目标偏离 ≥ 15pp 才调仓 (由成交模拟 / 人工执行负责)

已知局限: 2010–2023 年 10Y 几乎一直 ≥ 2.5%, 规则 1 在历史上基本不触发,
         回测无法检验它的好坏 —— 它是基于经济逻辑的保险条款, 不是回测得出的结论。

展示用分位 (不参与仓位计算) 口径: 截至当日的扩展窗口 (含当日), (历史 < 当日值) 的占比 × 100, 与 erp_zones 同一定义;
         至少 1008 个有效观测才给出数值, 否则为 NaN。无后视。
"""
from __future__ import annotations

import bisect
import hashlib
import json

import numpy as np
import pandas as pd

PARAMS = {
    "version": "v4.0",
    "frozen_on": "2026-10-30",
    "erp_thresholds": [2.5, 3.5, 4.5, 5.5, 6.5],
    "positions": [0.10, 0.25, 0.45, 0.65, 0.80, 0.90],
    "y10_floor": 2.5,
    "pct_min_history": 1008,
    "trend_ma_short": 60,
    "trend_ma_long": 120,
    "bear_step_per_eval": 0.05,
    "eval_freq": "W-FRI",
    "rebalance_band": 0.15,
}

PARAM_HASH = "c7394ad81cfb167c"   # 冻结于 2026-10-30, 与 PARAMS 一一对应

# 检验状态 (不属于参数, 不进哈希)。2026-10-30 一次性检验: 弱通过, 见 docs/ERP_V4_PREREGISTRATION.md
STATUS = "弱通过·前向观察中"


def param_hash(params: dict | None = None) -> str:
    p = PARAMS if params is None else params
    blob = json.dumps(p, sort_keys=True, ensure_ascii=False, separators=(",", ":"))
    return hashlib.sha256(blob.encode("utf-8")).hexdigest()[:16]


# ══════════════════════════════════════════════════════════════
# 基础计算
# ══════════════════════════════════════════════════════════════

def tier_position(erp: pd.Series) -> pd.Series:
    """规则 1: ERP(%) → 分档仓位。ERP 缺失时为 NaN。"""
    th = PARAMS["erp_thresholds"]
    pos = PARAMS["positions"]
    s = pd.to_numeric(erp, errors="coerce").astype(float)
    idx = np.searchsorted(np.asarray(th, dtype=float), s.to_numpy(), side="right")
    out = pd.Series(np.asarray(pos, dtype=float)[np.clip(idx, 0, len(pos) - 1)], index=s.index)
    return out.where(s.notna())


def expanding_pct(s: pd.Series, min_periods: int | None = None) -> pd.Series:
    """截至当日 (含) 的扩展窗口分位: (历史 < 当日值) 的占比 × 100。无后视。"""
    minp = PARAMS["pct_min_history"] if min_periods is None else int(min_periods)
    v = pd.to_numeric(s, errors="coerce").astype(float).to_numpy()
    out = np.full(len(v), np.nan)
    seen = []                     # 已出现的有效值 (有序)
    for i, x in enumerate(v):
        if np.isnan(x):
            continue
        bisect.insort(seen, x)
        if len(seen) >= minp:
            out[i] = bisect.bisect_left(seen, x) / len(seen) * 100.0
    return pd.Series(out, index=s.index)


def trend_status(pe: pd.Series) -> pd.Series:
    """与 ERPTimingEngine._compute_position_layer 同一定义: PE 相对 MA60 / MA120。"""
    ws, wl = PARAMS["trend_ma_short"], PARAMS["trend_ma_long"]
    p = pd.to_numeric(pe, errors="coerce").astype(float)
    ma_s = p.rolling(ws, min_periods=ws).mean()
    ma_l = p.rolling(wl, min_periods=wl).mean()
    out = pd.Series("neutral", index=p.index, dtype=object)
    out[(p > ma_s) & (p > ma_l)] = "bullish"
    out[p < ma_s] = "weak"
    out[(p < ma_s) & (p < ma_l)] = "bearish"
    out[ma_l.isna() | ma_s.isna()] = "insufficient_data"
    return out


def eval_days(index: pd.DatetimeIndex) -> pd.Series:
    """每个评估周期 (默认按周, 周五为界) 的最后一个交易日 = True。"""
    idx = pd.DatetimeIndex(index)
    per = idx.to_period(PARAMS["eval_freq"])
    last = pd.Series(idx, index=idx).groupby(per).transform("max")
    return pd.Series(idx == last.to_numpy(), index=idx)


# ══════════════════════════════════════════════════════════════
# 主函数
# ══════════════════════════════════════════════════════════════

def target_series(df: pd.DataFrame, guard: bool = True, staging: bool = True,
                  trend: pd.Series | None = None) -> pd.DataFrame:
    """df: DatetimeIndex, 列 erp(%) / pe_ttm。返回逐日中间量与目标仓位。

    guard = 规则 1 (利率正常化), staging = 规则 3; 两者只供诊断 (消融), 冻结规则 = 都为 True。
    trend 可传入外部趋势序列 (例如回放 CSV 的 trend_status) 以保证与实盘回放同口径。
    """
    d = pd.DataFrame(index=pd.DatetimeIndex(df.index))
    d["erp"] = pd.to_numeric(df["erp"], errors="coerce").astype(float).to_numpy()
    d["pe_ttm"] = pd.to_numeric(df["pe_ttm"], errors="coerce").astype(float).to_numpy()
    d["ep"] = 100.0 / d["pe_ttm"].where(d["pe_ttm"] > 0)
    d["y10"] = d["ep"] - d["erp"]
    d["ep_pct"] = expanding_pct(d["ep"])
    d["y10_pct"] = expanding_pct(d["y10"])
    d["erp_pct"] = expanding_pct(d["erp"])
    floor = PARAMS["y10_floor"] if guard else -np.inf
    d["erp_adj"] = d["ep"] - np.maximum(d["y10"], floor)
    d["guard_on"] = d["y10"] < floor                               # 利率正常化生效
    d["base"] = tier_position(d["erp"])                             # 未正常化的分档 (对照)
    d["guarded"] = tier_position(d["erp_adj"])                      # 规则 1+2 的分档仓位

    d["trend"] = trend.reindex(d.index).to_numpy() if trend is not None else trend_status(d["pe_ttm"]).to_numpy()
    d["eval_day"] = eval_days(d.index).to_numpy()

    step = PARAMS["bear_step_per_eval"]
    target = np.full(len(d), np.nan)
    staged_flag = np.zeros(len(d), dtype=bool)
    S = np.nan
    for i, (g, tr, ev) in enumerate(zip(d["guarded"].to_numpy(), d["trend"].to_numpy(),
                                        d["eval_day"].to_numpy())):
        if ev and not np.isnan(g):
            if np.isnan(S) or g <= S or not staging or tr != "bearish":
                S = g
            else:
                S = min(g, S + step)
                staged_flag[i] = S < g
        target[i] = S
    d["target"] = target
    d["staging_active"] = staged_flag
    return d


STALE_TRADING_DAYS = 3     # 数据截至日之后已过去的工作日数 > 此值 → 判为陈旧 (节假日可能误报)


def trigger_map(erp_adj: float, y10: float, pe: float) -> dict:
    """在 10Y 不变的前提下, 沪深300 PE 到哪里会让分档变化 (由规则直接反推, 不是预测)。

    ERP_adj = 100/PE − max(10Y, floor) → 升档需要 ERP_adj ≥ 上一档阈值, 即 PE ≤ 100/(阈值 + y_eff)。
    """
    th = PARAMS["erp_thresholds"]
    pos = PARAMS["positions"]
    if erp_adj is None or np.isnan(erp_adj) or y10 is None or np.isnan(y10):
        return {"available": False}
    y_eff = max(float(y10), PARAMS["y10_floor"])
    k = int(np.searchsorted(np.asarray(th, dtype=float), erp_adj, side="right"))
    out = {"available": True, "tier_index": k, "y10_effective": round(y_eff, 2),
           "pe_current": round(float(pe), 2), "up": None, "down": None}
    if k < len(th):
        pe_up = 100.0 / (th[k] + y_eff)
        out["up"] = {"pe_at_or_below": round(pe_up, 2), "position_pct": round(pos[k + 1] * 100),
                     "erp_adj_at_or_above": th[k],
                     "pe_change_pct": round((pe_up / pe - 1) * 100, 1)}
    if k > 0:
        pe_dn = 100.0 / (th[k - 1] + y_eff)
        out["down"] = {"pe_above": round(pe_dn, 2), "position_pct": round(pos[k - 1] * 100),
                       "erp_adj_below": th[k - 1],
                       "pe_change_pct": round((pe_dn / pe - 1) * 100, 1)}
    return out


def next_eval_date(as_of: pd.Timestamp) -> str:
    """下一个评估日 (周五; 不识别节假日, 前端标注"约")。as_of 本身是周五时取下一周。"""
    d = pd.Timestamp(as_of).normalize()
    days = (4 - d.weekday()) % 7 or 7
    return str((d + pd.Timedelta(days=days)).date())


def freshness(as_of: pd.Timestamp, today: pd.Timestamp | None = None) -> dict:
    t = pd.Timestamp(today or pd.Timestamp.now()).normalize()
    a = pd.Timestamp(as_of).normalize()
    lag = int(np.busday_count(np.datetime64((a + pd.Timedelta(days=1)).date()),
                              np.datetime64((t + pd.Timedelta(days=1)).date()))) if t > a else 0
    return {"as_of": str(a.date()), "weekdays_since": lag, "stale": lag > STALE_TRADING_DAYS}


def latest_snapshot(erp_df: pd.DataFrame, today: pd.Timestamp | None = None) -> dict:
    """实盘用: erp_df 为引擎 _compute_erp_series() 的结果 (trade_date / pe_ttm / erp)。

    页面、前向记录、提醒都只读这里的结果 (单一事实来源), 前端不做任何计算。
    """
    df = erp_df.copy()
    df["trade_date"] = pd.to_datetime(df["trade_date"])
    df = df.dropna(subset=["erp", "pe_ttm"]).set_index("trade_date").sort_index()
    t = target_series(df)
    last = t.iloc[-1]
    as_of = t.index[-1]

    def _r(x, nd=1):
        return None if x is None or (isinstance(x, float) and np.isnan(x)) else round(float(x), nd)

    target = _r(last["target"] * 100 if not np.isnan(last["target"]) else np.nan)
    tier = _r(last["guarded"] * 100 if not np.isnan(last["guarded"]) else np.nan)
    return {
        "version": PARAMS["version"],
        "param_hash": param_hash(),
        "status": STATUS,
        "erp": _r(last["erp"], 2),
        "erp_adj": _r(last["erp_adj"], 2),
        "y10_floor": PARAMS["y10_floor"],
        "ep": _r(last["ep"], 2),
        "y10": _r(last["y10"], 2),
        "pe_ttm": _r(last["pe_ttm"], 2),
        "erp_pct": _r(last["erp_pct"]),
        "ep_pct": _r(last["ep_pct"]),
        "y10_pct": _r(last["y10_pct"]),
        "history_start": str(df.index.min().date()),
        "history_days": int(len(df)),
        "raw_tier_position_pct": _r(last["base"] * 100 if not np.isnan(last["base"]) else np.nan),
        "tier_position_pct": tier,
        "guard_on": bool(last["guard_on"]),
        "trend": str(last["trend"]),
        "target_position_pct": target,
        "pending_increase": bool(target is not None and tier is not None and target < tier),
        "staging_active": bool(t["staging_active"].iloc[-1] or
                               (last["trend"] == "bearish" and last["target"] < last["guarded"])),
        "rebalance_band_pct": round(PARAMS["rebalance_band"] * 100),
        "ladder": {"thresholds": list(PARAMS["erp_thresholds"]),
                   "positions_pct": [round(x * 100) for x in PARAMS["positions"]]},
        "triggers": trigger_map(float(last["erp_adj"]), float(last["y10"]), float(last["pe_ttm"])),
        "next_eval_date": next_eval_date(as_of),
        "freshness": freshness(as_of, today),
        "scope": "仅适用于沪深300 类大盘仓位，不用于芯片 / 科创 ETF",
    }
