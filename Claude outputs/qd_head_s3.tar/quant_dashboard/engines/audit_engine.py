# -*- coding: utf-8 -*-
"""
AlphaCore 深度审计引擎 (2026-11-02 口径修正)
回答两个问题:
  A. 系统可信吗? —— 数据质量 · 策略健康 (MR/DIV/MOM/GEM) · 因子 · 系统状态
  B. 组合是否违反已定风险规则? —— 只读取合规引擎在决策中枢快照上的结果, 本页不自带风险阈值
只读: 不下单、不写交易阻断; 审计历史只在每日定时任务或手动"保存审计"时写入。
旧执行器 (audit_enforcer: 自动强平 / 交易阻断文件 / 静音降级) 已于 2026-11-02 退役。
"""
import os
import json
import time
import glob
import re
import random
import math
import traceback
import pandas as pd
import numpy as np
from datetime import datetime, timedelta

# ── 日志初始化 (带安全兜底) ──
try:
    from services.logger import get_logger
    logger = get_logger("ac.audit")
except ImportError:
    import logging
    logging.basicConfig(level=logging.INFO)
    logger = logging.getLogger("ac.audit")

# ── 路径常量 ──
BASE_DIR = os.path.dirname(os.path.abspath(__file__))       # engines/
PROJECT_ROOT = os.path.dirname(BASE_DIR)                    # quant_dashboard/
DATA_LAKE = os.path.join(PROJECT_ROOT, "data_lake")
DAILY_DIR = os.path.join(DATA_LAKE, "daily_prices")
FINA_DIR  = os.path.join(DATA_LAKE, "financials")

# V6.8: 各辅助策略"覆盖实盘参数"的验证证据 (而非实盘不读取的优化器输出)
OPTIMIZATION_FILES = {
    "红利趋势": "dividend_regime_validation.json",
    "行业动量": "config/industry_validation.json",
}

# 2026-11-02 方案 B: 删除"可信度总分"权重 (数据35/策略25/风控20/因子10/系统10, 把组合风险混入系统可信度);
# 系统可信度改为四项等权 (TRUST_GROUPS), 组合合规单独呈现不打分。

# ── V5.0: 从 config.py 加载审计阈值 (消灭硬编码) ──
def _load_audit_cfg():
    try:
        from config import AUDIT_CONFIG
        return dict(AUDIT_CONFIG)
    except ImportError:
        return {
            "daily_stale_warn_days": 3,
            "daily_stale_fail_days": 5, "fina_fresh_days": 90,
            "erp_stale_warn_days": 3, "erp_stale_fail_days": 7,
            "rates_stale_warn_days": 3, "rates_stale_fail_days": 7,
            "strategy_fresh_days": 30, "strategy_stale_days": 60,
        }

# V5.0: 模块加载时立即读取配置 (全局单例)
AUDIT_CFG = _load_audit_cfg()

# V6.5: Tushare 探测结果内存级缓存
_TS_CHECK_CACHE = None


def _today_str():
    from services.market_clock import CN_TZ
    return datetime.now(CN_TZ).strftime("%Y%m%d")


# V6.6: 交易日历自维护 (替代硬编码假期列表)
# 优先从 data_lake/trading_calendar.json 加载 Tushare trade_cal 缓存
# 缓存未命中时降级到硬编码假期列表 (兜底)
_CN_HOLIDAYS_2026 = {
    (1,1),(1,2),(1,3),           # 元旦
    (1,26),(1,27),(1,28),(1,29),(1,30),(1,31),(2,1),  # 春节
    (4,4),(4,5),(4,6),           # 清明
    (5,1),(5,2),(5,3),(5,4),(5,5),  # 劳动节
    (5,31),(6,1),(6,2),          # 端午
    (9,25),(9,26),(9,27),        # 中秋
    (10,1),(10,2),(10,3),(10,4),(10,5),(10,6),(10,7),  # 国庆
}

_TRADING_CAL_CACHE = None

def _load_trading_calendar():
    """V6.6: 从 data_lake/trading_calendar.json 加载交易日集合。
    缓存格式: ["20260102", "20260103", ...] (仅开市日)
    由 data_manager.py 每日同步时写入。
    """
    global _TRADING_CAL_CACHE
    if _TRADING_CAL_CACHE is not None:
        return _TRADING_CAL_CACHE
    cal_path = os.path.join(DATA_LAKE, "trading_calendar.json")
    if os.path.exists(cal_path):
        try:
            with open(cal_path, "r", encoding="utf-8") as f:
                _TRADING_CAL_CACHE = set(json.load(f))
            return _TRADING_CAL_CACHE
        except Exception:
            pass
    return None  # 降级到硬编码

def _is_trading_day(dt):
    """V6.6: 交易日判定 — 优先用日历缓存, 降级到周末+假期过滤"""
    cal = _load_trading_calendar()
    if cal is not None:
        return dt.strftime("%Y%m%d") in cal
    # 降级: 周末 + 硬编码假期兜底
    if dt.weekday() >= 5:
        return False
    if (dt.month, dt.day) in _CN_HOLIDAYS_2026:
        return False
    return True


def _last_trading_day():
    """获取最近一个交易日 (今天15:00后算今天, 否则算昨天)"""
    from services.market_clock import CN_TZ
    now = datetime.now(CN_TZ).replace(tzinfo=None)  # A 股收盘 15:00 为北京时间
    target = now if now.hour >= 15 else now - timedelta(days=1)
    while not _is_trading_day(target):
        target -= timedelta(days=1)
    return target


def _stale_days(date_str):
    """计算距今交易日天数 (排除周末+法定假日, 避免周末误报)"""
    try:
        clean = str(date_str).replace("-", "")[:8]
        dt = datetime.strptime(clean, "%Y%m%d")
        # 计算自然日差
        from services.market_clock import CN_TZ
        cn_today = datetime.now(CN_TZ).replace(tzinfo=None)
        cal_days = (cn_today - dt).days
        if cal_days <= 0:
            return 0
        # 快速路径: 1-2 自然日 → 计算精确交易日
        trading_days = 0
        cursor = dt + timedelta(days=1)
        end = cn_today
        # 限制循环上限防止极端值卡死
        max_iter = min(cal_days, 400)
        for _ in range(max_iter):
            if cursor > end:
                break
            if _is_trading_day(cursor):
                trading_days += 1
            cursor += timedelta(days=1)
        return trading_days
    except Exception:
        return 999


def _grade(score):
    if score >= 85:
        return "A"
    elif score >= 70:
        return "B"
    elif score >= 55:
        return "C"
    else:
        return "D"


# ═══════════════════════════════════════════════════════
#  模块 1: 数据质量审计
# ═══════════════════════════════════════════════════════
def audit_data_quality():
    """
    检查: 日线新鲜度, 财务数据时效, ERP缓存, FRED利率, 缺失率, 异常值
    返回: {score, checks: [...], summary}
    """
    checks = []
    scores = []

    # ── 1.1 日线数据新鲜度 ──
    daily_files = glob.glob(os.path.join(DAILY_DIR, "*.parquet"))
    if daily_files:
        latest_dates = []
        stale_count = 0
        # V7.0: 蒙特卡洛随机抽样，消除排序带来的幸存者偏差
        sampled_daily = random.sample(daily_files, min(len(daily_files), 30))
        for f in sampled_daily:
            try:
                df = pd.read_parquet(f, columns=["trade_date"])
                if not df.empty:
                    max_d = str(df["trade_date"].max())
                    latest_dates.append(max_d)
                    if _stale_days(max_d) > AUDIT_CFG.get("daily_stale_warn_days", 3):
                        stale_count += 1
            except:
                stale_count += 1

        if latest_dates:
            newest = max(latest_dates)
            days = _stale_days(newest)
            s = max(0, 100 - days * 15)  # 每过期1天扣15分
            scores.append(s)
            _warn_d = AUDIT_CFG.get("daily_stale_warn_days", 3)
            _fail_d = AUDIT_CFG.get("daily_stale_fail_days", 5)
            status = "pass" if days <= 1 else ("warn" if days <= _warn_d else "fail")
            checks.append({
                "name": "日线数据新鲜度",
                "status": status,
                "detail": f"最新: {newest[:4]}-{newest[4:6]}-{newest[6:8]} ({days}天前)",
                "meta": f"共 {len(daily_files)} 个标的, {stale_count} 个过期",
                "score": s,
                "explanation": "日线行情是所有策略信号的基础输入。过期数据意味着均值回归的偏离度、动量排名、红利趋势判断全部基于陈旧信息，产生的买卖信号不可信。",
                "threshold": "🟢 ≤1天: 信号实时可靠 | 🟡 2-3天: 可能错过关键转折 | 🔴 >3天: 策略输出不可用",
                "action": "执行 python data_manager.py 或等待每日 15:35 自动同步",
            })
        else:
            scores.append(0)
            checks.append({"name": "日线数据新鲜度", "status": "fail", "detail": "无有效数据", "score": 0, "explanation": "日线行情是所有策略信号的基础输入。无数据则所有策略引擎无法运行。", "threshold": "🟢 ≤1天 | 🟡 2-3天 | 🔴 >3天/无数据", "action": "执行 python data_manager.py 拉取日线数据"})
    else:
        scores.append(0)
        checks.append({"name": "日线数据新鲜度", "status": "fail", "detail": "目录为空", "score": 0, "explanation": "日线行情是所有策略信号的基础输入。数据目录为空意味着系统从未初始化。", "threshold": "🟢 ≤1天 | 🟡 2-3天 | 🔴 >3天/空目录", "action": "首次部署需执行 python data_manager.py 初始化数据湖"})

    # ── 1.2 财务数据时效 ──
    fina_files = glob.glob(os.path.join(FINA_DIR, "*.parquet"))
    if fina_files:
        fina_latest = []
        # V7.0: 蒙特卡洛随机抽样，消除排序带来的幸存者偏差
        sampled_fina = random.sample(fina_files, min(len(fina_files), 10))
        for f in sampled_fina:
            try:
                df = pd.read_parquet(f)
                if not df.empty and "ann_date" in df.columns:
                    fina_latest.append(str(df["ann_date"].max()))
            except:
                pass
        if fina_latest:
            newest_fina = max(fina_latest)
            days_fina = _stale_days(newest_fina)
            _fina_fresh = AUDIT_CFG.get("fina_fresh_days", 90)
            # 财务数据季度更新, N天内算正常
            s = 100 if days_fina <= _fina_fresh else max(0, 100 - (days_fina - _fina_fresh))
            status = "pass" if days_fina <= _fina_fresh else ("warn" if days_fina <= _fina_fresh * 2 else "fail")
            scores.append(s)
            checks.append({
                "name": "财务指标时效",
                "status": status,
                "detail": f"最新公告: {newest_fina[:4]}-{newest_fina[4:6]}-{newest_fina[6:8]} ({days_fina}天前)",
                "meta": f"共 {len(fina_files)} 只股票财务数据",
                "score": s,
                "explanation": "ROE、EPS、净利润率等基本面因子来源于季报。财报每季度更新一次(1/4/7/10月)，90天内均属正常周期。超期意味着在用上个季度的财务画像选股。",
                "threshold": "🟢 ≤90天: 当季有效 | 🟡 91-180天: 跨季度，精度下降 | 🔴 >180天: 基本面因子失真",
                "action": "执行 python sync_dividend_data.py 或等待季报窗口后自动同步",
            })
        else:
            scores.append(50)
            checks.append({"name": "财务指标时效", "status": "warn", "detail": "无有效财务数据", "score": 50, "explanation": "基本面因子依赖季报数据，无有效数据将导致红利策略和因子分析无法正常运行。", "threshold": "🟢 ≤90天 | 🟡 91-180天 | 🔴 >180天/无数据", "action": "执行 python sync_dividend_data.py 拉取财务数据"})
    else:
        scores.append(30)
        checks.append({"name": "财务指标时效", "status": "warn", "detail": "财务目录为空", "score": 30, "explanation": "基本面因子依赖季报数据，目录为空意味着红利策略和因子分析模块无法运行。", "threshold": "🟢 ≤90天 | 🟡 91-180天 | 🔴 空目录", "action": "首次部署需执行 python data_manager.py 初始化财务数据"})

    # ── 1.3 ERP 缓存新鲜度 ──
    # V7.2: 只检查核心高频 ERP 文件 (PE/Yield/Rates)
    # 排除低频历史数据 (M1/history/score) 避免月度数据误报
    # 2026-11-02: 另排除一次性研究产物 (erp_allocation_price.parquet 等: 只由离线研究脚本生成, 线上不刷新),
    # 否则本机会因研究文件"7 天未更新"把 ERP 缓存误判为失败 (服务器上无此文件, 同一代码判通过)。
    _ERP_SKIP_PATTERNS = ("_history", "_score", "_m1_", "_current_pe", "_allocation_", "_research", "_validation")
    all_erp_files = glob.glob(os.path.join(DATA_LAKE, "erp_*.parquet"))
    erp_files = [f for f in all_erp_files
                 if not any(p in os.path.basename(f) for p in _ERP_SKIP_PATTERNS)]
    # 如果过滤后无文件则回退到全量
    if not erp_files:
        erp_files = all_erp_files
    if erp_files:
        erp_ages = []
        for f in erp_files:
            mtime = os.path.getmtime(f)
            age_days = (time.time() - mtime) / 86400
            erp_ages.append(age_days)
        max_age = max(erp_ages)
        s = max(0, 100 - int(max_age) * 10)
        _erp_warn = AUDIT_CFG.get("erp_stale_warn_days", 3)
        _erp_fail = AUDIT_CFG.get("erp_stale_fail_days", 7)
        status = "pass" if max_age <= _erp_warn else ("warn" if max_age <= _erp_fail else "fail")
        scores.append(s)
        checks.append({
            "name": "ERP 缓存新鲜度",
            "status": status,
            "detail": f"最旧核心缓存: {max_age:.1f} 天前",
            "meta": f"共 {len(erp_files)} 个核心 ERP 文件 (排除 {len(all_erp_files) - len(erp_files)} 个低频历史)",
            "score": s,
            "explanation": "ERP(股权风险溢价)是股债性价比的核心指标，由全市场PE和10年国债收益率计算。过期数据会导致宏观择时引擎的仓位建议失准。仅检查核心高频文件 (PE-TTM/Yield/Rates)，M1等月度数据不纳入新鲜度判定。",
            "threshold": "🟢 ≤3天: 择时信号可靠 | 🟡 4-7天: 信号参考性下降 | 🔴 >7天: 择时建议不可用",
            "action": "重启服务器触发 ERP 预热，或等待每日 15:35 自动刷新",
        })
    else:
        scores.append(0)
        checks.append({"name": "ERP 缓存新鲜度", "status": "fail", "detail": "无 ERP 数据", "score": 0, "explanation": "无 ERP 数据将导致宏观择时引擎无法计算股债性价比，仓位建议缺失核心锚点。", "threshold": "🟢 ≤3天 | 🟡 4-7天 | 🔴 无数据", "action": "重启服务器或手动执行 erp_timing_engine.py 生成缓存"})

    # ── 1.4 FRED 利率数据 ──
    rates_files = glob.glob(os.path.join(DATA_LAKE, "rates_*.parquet"))
    if rates_files:
        rates_ages = []
        for f in rates_files:
            mtime = os.path.getmtime(f)
            age_days = (time.time() - mtime) / 86400
            rates_ages.append(age_days)
        max_age = max(rates_ages)
        s = max(0, 100 - int(max_age) * 8)
        # P1修复: FRED 阈值从 AUDIT_CFG 读取 (消除硬编码 3/7 天)
        _rates_warn = AUDIT_CFG.get("rates_stale_warn_days", 3)
        _rates_fail = AUDIT_CFG.get("rates_stale_fail_days", 7)
        status = "pass" if max_age <= _rates_warn else ("warn" if max_age <= _rates_fail else "fail")
        scores.append(s)
        checks.append({
            "name": "FRED 利率数据",
            "status": status,
            "detail": f"最旧: {max_age:.1f} 天前",
            "meta": f"共 {len(rates_files)} 个利率序列",
            "score": s,
            "explanation": "美联储FRED数据库提供美债收益率曲线(2Y/10Y/30Y)，是全球资产定价的锚。利率变化直接影响ERP计算、海外策略择时和跨市场配置权重。",
            "threshold": "🟢 ≤3天: 利率曲线实时 | 🟡 4-7天: 可能错过利率拐点 | 🔴 >7天: 海外策略失去参照",
            "action": "等待每日 18:30 自动刷新(北京时间)，或手动执行利率数据同步",
        })
    else:
        scores.append(0)
        checks.append({"name": "FRED 利率数据", "status": "fail", "detail": "无利率数据", "score": 0, "explanation": "无美债利率数据将导致ERP计算缺失利率端，海外策略模块完全瘫痪。", "threshold": "🟢 ≤3天 | 🟡 4-7天 | 🔴 无数据", "action": "检查网络连通性后执行利率数据同步脚本"})

    # ── 1.5 数据完整性与异常值抽检 ──
    if daily_files:
        # V7.0: 随机抽样 5 只股票进行多样本联合质量抽检，防止单股偏误与脏数据漏网
        sample_size = min(len(daily_files), 5)
        sampled_files = random.sample(daily_files, sample_size)
        total_rows_all = 0
        total_bad_rows = 0
        zero_vol_all = 0
        bad_price_all = 0
        read_success = 0
        sample_names = []
        
        for f in sampled_files:
            try:
                df = pd.read_parquet(f)
                if df.empty:
                    continue
                read_success += 1
                sample_names.append(os.path.basename(f))
                
                rows = len(df)
                total_rows_all += rows
                
                # 初始化本文件异常行掩码
                bad_mask = pd.Series(False, index=df.index)
                
                # 1. 零成交行数
                if "vol" in df.columns:
                    vol_mask = (df["vol"] == 0)
                    zero_vol_all += vol_mask.sum()
                    bad_mask |= vol_mask
                
                # 2. 负价格/零价格
                price_cols = [c for c in ["open", "high", "low", "close"] if c in df.columns]
                for col in price_cols:
                    p_mask = (df[col] <= 0)
                    bad_price_all += p_mask.sum()
                    bad_mask |= p_mask
                
                # 3. 未除权价格跳空巨震 (单日涨跌幅绝对值 > 31%, 且成交量 > 0)
                if "close" in df.columns:
                    close_prev = df["close"].shift(1)
                    jump_mask = (df["close"] / close_prev - 1).abs() > 0.31
                    if "vol" in df.columns:
                        jump_mask &= (df["vol"] > 0)
                    bad_price_all += jump_mask.sum()
                    bad_mask |= jump_mask
                
                total_bad_rows += bad_mask.sum()
            except Exception:
                pass
                
        if read_success > 0:
            total_rows_all = max(total_rows_all, 1)
            anomaly_pct = total_bad_rows / total_rows_all * 100
            s = max(0, 100 - int(anomaly_pct * 10))
            status = "pass" if anomaly_pct < 1 else ("warn" if anomaly_pct < 5 else "fail")
            scores.append(s)
            checks.append({
                "name": "数据完整性与异常值",
                "status": status,
                "detail": f"异常占比: {total_bad_rows}/{total_rows_all} ({anomaly_pct:.1f}%) [零成交:{zero_vol_all}行, 价格异常:{bad_price_all}行]",
                "meta": f"联合抽检 {read_success} 只样本: {', '.join(sample_names[:3])}",
                "score": s,
                "explanation": "零成交日(停牌)、非正价格(脏数据)或未除权跳空巨幅异动(单日变动>31%)会严重带偏量化因子的统计分布。使用多样本联合抽查，可以全面覆盖脏数据盲区。",
                "threshold": "🟢 <1%: 数据完整干净 | 🟡 1-5%: 少量偏误 | 🔴 >5%: 存在严重脏数据",
                "action": "执行数据清洗脚本, 剔除退市/长期停牌股，并重新拉取未复权异常数据",
            })
        else:
            scores.append(0)
            checks.append({
                "name": "数据完整性与异常值",
                "status": "fail",
                "detail": "多样本抽检全部失败",
                "score": 0,
                "explanation": "随机选择 of 5 只股票 Parquet 文件均无法正确读取，这提示底层数据湖格式可能发生大面积损坏。",
                "threshold": "🟢 <1% | 🟡 1-5% | 🔴 全部损坏",
                "action": "检查 Parquet 库依赖或清空 data_lake/ 重新同步"
            })

    # ── V22.0: 新增数据完整性检查 ──
    # 资产参数矩阵
    param_path = os.path.join(PROJECT_ROOT, "mr_asset_class_params.json")
    if os.path.exists(param_path):
        try:
            with open(param_path, 'r', encoding='utf-8') as f:
                acp = json.load(f)
            classes = [k for k in acp if not k.startswith("_")]
            scores.append(100 if len(classes) >= 3 else 80)
            checks.append({
                "name": "V22.0 资产参数矩阵",
                "status": "pass" if len(classes) >= 3 else "warn",
                "detail": f"{len(classes)} 类资产参数就绪 ({', '.join(classes[:4])})",
                "score": 100 if len(classes) >= 3 else 80,
                "explanation": "资产类别差异化参数矩阵是信号评分系统的核心。缺失时引擎回退到旧版通用参数，信号无法按波动率自适应调整。",
                "threshold": "🟢 ≥3类就绪 | 🔴 缺失",
                "action": "检查 mr_asset_class_params.json 文件完整性",
            })
        except Exception:
            scores.append(40)
            checks.append({"name": "V22.0 资产参数矩阵", "status": "fail", "detail": "JSON 解析失败", "score": 40, "explanation": "参数文件格式损坏。", "action": "从 git 恢复 mr_asset_class_params.json"})
    else:
        scores.append(30)
        checks.append({"name": "V22.0 资产参数矩阵", "status": "fail", "detail": "文件不存在", "score": 30, "explanation": "V22.0 核心配置文件缺失, 引擎将使用旧版通用参数。", "action": "运行 python 重新生成参数文件"})

    # 市场事件日志健康
    event_log = os.path.join(DATA_LAKE, "market_events.json")
    if os.path.exists(event_log):
        try:
            size = os.path.getsize(event_log)
            events_ok = size < 5 * 1024 * 1024  # < 5MB
            scores.append(100 if events_ok else 70)
            checks.append({
                "name": "V22.0 事件日志健康",
                "status": "pass" if events_ok else "warn",
                "detail": f"{size/1024:.0f}KB" + (" (正常)" if events_ok else " (偏大, 建议清理)"),
                "score": 100 if events_ok else 70,
                "explanation": "市场事件日志记录 VIX 跳变、Regime 切换等突变。过大说明事件记录频率异常或清理机制失效。",
                "threshold": "🟢 <5MB | 🟡 5-10MB | 🔴 >10MB",
                "action": "删除 data_lake/market_events.json 重置日志" if not events_ok else None,
            })
        except Exception:
            pass

    # ── ETF 成分 (合规穿透) 与持仓 ETF 登记表 (2026-11-03 docs/ETF_CONSTITUENT_FIX_PLAN.md C1) ──
    # 只作读数: 不带 score, 不参与 A 区评分 (评分规则不变)。按名称归类或 ≤10 天过期时标"警告"。
    try:
        checks.append(_constituent_readout())
    except Exception as e:  # noqa: BLE001
        checks.append({"name": "ETF 成分（合规穿透）", "status": "warn", "detail": f"读取失败: {str(e)[:80]}"})

    final_score = int(np.mean(scores)) if scores else 0
    return {
        "module": "data_quality",
        "label": "📡 数据质量",
        "score": final_score,
        "grade": _grade(final_score),
        "checks": checks,
    }


# ═══════════════════════════════════════════════════════
#  V6.8 辅助策略证据审计
#  原则: 时效性只对"覆盖实盘参数"的证据有意义。
#    - 证据参数 ≠ 实盘参数 → 证据不适用 (30, fail)
#    - 证据适用 → 按证据数据截止日的滞后天数做 TTL 线性衰减
#    - 证据质量为负 (样本外跑输 / 分状态无增益) → 最高 70 (warn)
# ═══════════════════════════════════════════════════════
def _constituent_readout() -> dict:
    """ETF 成分快照与登记表读数 (C1)。持仓 ETF 中按名称归类 (非穿透) 或权重即将过期的, 状态为 warn。"""
    from services.industry_constituents import constituent_health
    h = constituent_health()
    reg = h.get("registry") or {}
    etfs = h.get("held_etfs") or []
    fb = h.get("name_fallback") or []
    soon = [e for e in etfs if e.get("verified") and e.get("days_left") is not None and e["days_left"] <= 10]
    parts = []
    if etfs:
        parts.append(f"持仓 ETF {len(etfs)} 只: 可穿透 {len(etfs) - len(fb)} 只" + (f", 按名称归类(非穿透) {len(fb)} 只 ({'、'.join(fb)})" if fb else ""))
    dates = sorted({e["weights_as_of"] for e in etfs if e.get("weights_as_of")})
    if dates:
        parts.append(f"权重日期 {'/'.join(dates)}")
    if soon:
        parts.append("即将过期: " + "、".join(f"{e['ts_code']} 剩 {e['days_left']} 天" for e in soon))
    parts.append(f"快照获取于 {str(h.get('retrieved_at') or '--')[:16]}")
    if reg.get("status") == "ok":
        parts.append(f"登记表 {reg.get('path')} · 修改于 {reg.get('modified_at')} · 指纹 {reg.get('sha256')} · {reg.get('valid_count')} 只")
    else:
        parts.append(f"登记表{'缺失' if reg.get('status') == 'missing' else '无法读取'} ({reg.get('path')})")
    return {
        "name": "ETF 成分（合规穿透）",
        "status": "warn" if (fb or soon or reg.get("status") != "ok") else "info",
        "detail": "；".join(parts),
        "explanation": "合规主题集中度按 ETF 成分穿透计算; 成分缺失或过期的 ETF 按名称整只归类 (更严, 非穿透)。"
                       "登记表 (data_lake/ 或 config/lookthrough_extra_etfs.json) 不进 git, 本机与服务器各自一份, 比对指纹可发现不一致。",
        "threshold": "权重超过 45 天视为过期; 剩 ≤10 天或有持仓 ETF 按名称归类时为警告 (只读, 不计分)",
        "readout": h,
    }


def _ttl_score(age_days, fresh, stale):
    if age_days <= fresh:
        return 100, "pass"
    if age_days <= stale:
        return int(100 - (age_days - fresh) / (stale - fresh) * 40), "warn"
    return max(20, int(60 - (age_days - stale) * 0.5)), "fail"


def _param_diffs(live, evidence, keys):
    """返回 [(key, live, evidence)] 不一致列表; 缺失视为不一致。"""
    diffs = []
    for k in keys:
        lv = (live or {}).get(k)
        ev = (evidence or {}).get(k)
        try:
            same = lv is not None and ev is not None and abs(float(lv) - float(ev)) < 1e-9
        except (TypeError, ValueError):
            same = lv == ev
        if not same:
            diffs.append((k, lv, ev))
    return diffs


def _parse_day(value):
    s = str(value or "").strip()
    for fmt, n in (("%Y-%m-%d", 10), ("%Y%m%d", 8)):
        try:
            return datetime.strptime(s[:n], fmt).date()
        except ValueError:
            continue
    return None


def _audit_dividend_evidence(fresh, stale, w):
    name = "红利趋势"
    fn = OPTIMIZATION_FILES[name]
    fp = os.path.join(PROJECT_ROOT, fn)
    run_cmd = "在项目根目录执行 python -m strategies.dividend_backtest_engine regime --refresh-data，用最新前复权行情重做分状态验证"
    base = {
        "name": name,
        "meta": f"证据: {fn} · 绑定: dividend_trend_engine.REGIME_PARAMS · 权重: {int(w*100)}%",
        "explanation": "红利趋势实盘使用代码内固定的四状态参数 (REGIME_PARAMS)。只有覆盖这套参数、且用近期行情做过的分状态验证才能证明它仍然有效；优化器输出的另一套参数实盘并不读取。",
        "threshold": f"🟢 证据覆盖实盘参数且数据滞后≤{fresh}天 | 🟡 {fresh+1}-{stale}天或证据质量偏弱 | 🔴 >{stale}天/参数不一致/缺失",
    }
    if not os.path.exists(fp):
        return {**base, "status": "fail", "score": 30, "detail": "无分状态验证证据", "action": run_cmd}
    try:
        with open(fp, "r", encoding="utf-8") as f:
            data = json.load(f)
    except Exception:
        return {**base, "status": "fail", "score": 20, "detail": "验证证据损坏 (JSON解析失败)", "action": run_cmd}

    rr = data.get("regime_results") or {}
    if "regime_results" in data and (
        not isinstance(rr, dict)
        or set(rr) != {"BEAR", "BULL", "RANGE_1", "RANGE_2"}
        or any(not isinstance(v, dict) or v.get("error") for v in rr.values())
        or data.get("total_count") != 4
    ):
        return {**base, "status": "fail", "score": 30,
                "detail": "分状态验证区间不完整，不能用最新文件日期替代缺失的验证覆盖", "action": run_cmd}
    ev_params = data.get("params") or {
        "BEAR": (rr.get("BEAR") or {}).get("adaptive_params"),
        "RANGE": (rr.get("RANGE_2") or rr.get("RANGE_1") or {}).get("adaptive_params"),
        "BULL": (rr.get("BULL") or {}).get("adaptive_params"),
    }
    keys = ("ma_trend", "rsi_buy", "rsi_sell", "bias_buy", "bias_sell", "ma_defend")
    binding = "一致"
    try:
        from engines.dividend_trend_engine import REGIME_PARAMS as live_params
    except Exception as exc:
        live_params = None
        binding = f"未校验({type(exc).__name__})"
    if live_params is not None:
        bad = {
            st: _param_diffs(live_params.get(st), ev_params.get(st), keys)
            for st in ("BEAR", "RANGE", "BULL")
        }
        bad = {st: d for st, d in bad.items() if d}
        if bad:
            desc = "; ".join(
                f"{st}: " + ", ".join(f"{k} 实盘{lv}/证据{ev}" for k, lv, ev in d[:2])
                for st, d in bad.items()
            )
            return {**base, "status": "fail", "score": 30,
                    "detail": f"证据参数与实盘不一致，证据不适用 · {desc}",
                    "action": "实盘参数已变更但未重新验证: " + run_cmd}

    data_through = _parse_day(data.get("data_through"))
    if data_through is None:
        ends = [_parse_day(str(v.get("period", "")).split("~")[-1])
                for v in rr.values() if isinstance(v, dict) and v.get("period")]
        ends = [d for d in ends if d]
        data_through = max(ends) if ends else None
    if data_through is None:
        return {**base, "status": "fail", "score": 30, "detail": "证据缺少数据截止日期", "action": run_cmd}

    lag = max(0, (datetime.now().date() - data_through).days)
    s, status = _ttl_score(lag, fresh, stale)
    detail = f"证据数据截止: {data_through} ({lag}天前) · 参数绑定: {binding}"
    wins, total = data.get("win_count"), data.get("total_count")
    if total:
        detail += f" · 分状态参数胜出 {wins}/{total}"
        if not wins:
            s = min(s, 70)
            if status == "pass":
                status = "warn"
    if live_params is None:
        s = min(s, 80)
        if status == "pass":
            status = "warn"
    methodology = data.get("methodology") or {}
    if methodology.get("production_equivalent") is False:
        s = min(s, 70)
        if status == "pass":
            status = "warn"
        detail += " · 仅固定分期参数比较，未复现完整实盘决策"
    action = None if status == "pass" else run_cmd
    if total and not wins:
        action = (action + "；" if action else "") + "分状态参数在所有区间均未优于统一参数，复核是否应回退为统一 RANGE 参数"
    return {**base, "status": status, "score": s, "detail": detail, "action": action}


def _audit_momentum_evidence(fresh, stale, w):
    name = "行业动量"
    from services.industry_validation import load_industry_validation_status

    st = load_industry_validation_status()
    reasons = list(st.get("reasons") or [])
    stage = st.get("stage")
    ready = bool(st.get("ready"))
    try:
        from services.strategy_params import load_runtime_config
        max_age = load_runtime_config()["strategies"]["momentum"]["validation"]["max_artifact_age_days"]
    except Exception:
        max_age = "?"
    base = {
        "name": name,
        "meta": f"证据: {OPTIMIZATION_FILES[name]} (industry_validation 门控) · 权重: {int(w*100)}%",
        "explanation": "行业动量的实盘执行由 industry_validation 证据门控 (fail-closed)：证据过期、数据滞后或未通过晋升门槛时禁止执行。审计复用同一套判定，保证与引擎一致。",
        "threshold": "🟢 已晋升(全部门槛通过) | 🟡 证据新鲜但未晋升(闸门关闭) | 🔴 证据过期/数据滞后/缺失",
        "action": "在行业页面重新运行验证 (POST /industry-validation/run)，或执行 python -c \"from services.industry_validation import run_local_industry_validation as r; r()\"",
    }
    data_end = st.get("data_end_date") or "未知"
    lag = st.get("data_lag_days")
    age = st.get("artifact_age_days")
    detail = f"数据截止: {data_end}" + (f" ({lag}天前)" if lag is not None else "")
    if age is not None:
        detail += f" · 证据生成 {age:.0f}天前 (上限{max_age}天)"
    if stage in ("missing", "invalid"):
        return {**base, "status": "fail", "score": 20, "detail": f"验证证据{'缺失' if stage == 'missing' else '损坏'}"}
    stale_flags = {"VALIDATION_ARTIFACT_STALE", "VALIDATION_DATA_STALE"} & set(reasons)
    if stale_flags:
        return {**base, "status": "fail", "score": 40,
                "detail": detail + " · 证据过期，执行闸门关闭"}
    if ready:
        return {**base, "status": "pass", "score": 100, "detail": detail + " · 已晋升", "action": None}
    shown = ", ".join(reasons[:3]) + (" …" if len(reasons) > 3 else "")
    return {**base, "status": "warn", "score": 70,
            "detail": detail + f" · 未晋升(闸门关闭): {shown}",
            "action": "证据新鲜但未达晋升门槛，无需紧急处理；持续影子观察，待指标达标后再晋升"}


def _score_mr_lifecycle(mr_lifecycle, position_caps=None):
    """
    均值回归三态生命周期评分 (V6.7)。

    以引擎真实的新开仓闸门 allow_new_entries 为准, 而非仅凭 position_cap 推断:
      - validated 且允许开仓                 → 100 (pass)
      - 未验证, 但闸门已关闭且未过复验期     → 70  (受控停用 / 等待复验, warn)
        (rejected / insufficient_evidence, 或 position_cap=0)
      - stale (复验期已过仍未复验)            → 40  (fail, 需立即复验)
      - 未验证却允许新开仓 (裸跑)             → 20  (fail)
    """
    position_caps = position_caps or {}
    entries = {}
    for state, item in (mr_lifecycle or {}).items():
        status = item.get("status", "")
        # get_mr_lifecycle 会给出 allow_new_entries; 缺失时按引擎规则推导
        allow = item.get("allow_new_entries", status == "validated")
        cap = position_caps.get(state, 100)
        if status == "validated" and allow:
            s = 100
        elif allow and cap != 0:
            s = 20                      # 未验证却放行新开仓 → 真正的风险
        elif status == "stale":
            s = 40                      # 复验已逾期
        elif status in ("rejected", "insufficient_evidence") or cap == 0:
            s = 70                      # fail-closed, 等待下次复验
        else:
            s = 0                       # 未知状态
        entries[state] = (s, item)

    complete = set(entries) == {"BEAR", "RANGE", "BULL"}
    score = min((s for s, _ in entries.values()), default=0)
    if not complete:
        score = min(score, 40)
    validated_count = sum(1 for s, _ in entries.values() if s == 100)

    if complete and validated_count == 3:
        status = "pass"
    elif complete and score >= 60:
        status = "warn"
    else:
        status = "fail"

    parts = []
    for state in sorted(entries):
        s, item = entries[state]
        seg = f"{state}={item.get('status')}@{item.get('data_through', 'unknown')}"
        if s == 70:
            nva = str(item.get("next_validate_after", ""))[:10]
            seg += f"(闸门关闭{', ' + nva + '复验' if nva else ''})"
        parts.append(seg)
    detail = f"{validated_count}/3 状态有效 · " + "; ".join(parts)

    if status == "pass":
        action = None
    elif any(s in (20, 0) for s, _ in entries.values()):
        action = "立即将未验证状态的 position_cap 设为 0 或修复生命周期, 禁止未验证参数开仓"
    elif any(s == 40 for s, _ in entries.values()) or not complete:
        action = "执行均值回归 dry-run 验证，并仅发布通过证据门槛的状态"
    else:
        due = sorted(
            str(item.get("next_validate_after", ""))[:10]
            for s, item in entries.values() if s == 70 and item.get("next_validate_after")
        )
        action = (
            f"无需紧急处理：引擎已禁止未验证状态新开仓。"
            f"{'最早复验日 ' + due[0] + '，届时' if due else ''}执行 dry-run 验证并发布通过证据门槛的状态"
        )
    return {"score": score, "status": status, "detail": detail,
            "action": action, "validated_count": validated_count}


# ═══════════════════════════════════════════════════════
#  模块 2: 策略健康 (2026-11-02 口径修正)
#  只评独立信号源 MR / DIV / MOM / GEM, 等权 25%。
#  ERP / AIAE 是背景读数, 不作为策略参与健康打分 (ERP v4 只在系统状态里做"引擎/前向记录"检查)。
#  验证状态以执行总览同一来源 services.run_all_aggregation.sleeve_evidence 为准;
#  旧证据文件 (红利/行业动量) 仍读取, 与执行总览状态取较严者, 不得把旧审计的 fail 洗成 warn。
# ═══════════════════════════════════════════════════════
STRATEGY_SLEEVES = (("mr", "均值回归"), ("div", "红利趋势"), ("mom", "动量轮动"), ("gem", "GEM双动量"))
SLEEVE_WEIGHT = 0.25   # 等权: 无交易占比数据依据, 不再手写权重

# 执行总览的验证状态 → 审计状态/分数 (只有 validated 才算通过)
_EVIDENCE_SCORE = {
    "validated": ("pass", 100),
    "insufficient_evidence": ("warn", 70),
    "unverified": ("warn", 60),
    "unlinked": ("warn", 60),
    "unknown": ("warn", 50),
    "rejected": ("fail", 40),
    "stale": ("fail", 40),
}
_STATUS_RANK = {"pass": 0, "warn": 1, "fail": 2}


def _current_sleeve_evidence():
    """与策略页执行总览同源: 优先读 run-all 发布的结果 (含当前 MR/MOM 状态), 否则用同一函数现算。"""
    from services import run_all_aggregation as agg
    try:
        from services.cache_service import cache_manager
        cached = cache_manager.get_json("sleeve_evidence")
        if isinstance(cached, dict) and isinstance(cached.get("evidence"), dict):
            return cached["evidence"], cached.get("as_of"), "run_all"
    except Exception:
        pass
    return agg.sleeve_evidence(None, None), None, "computed"


def _regime_integrity():
    """MR 三态参数完整性 (原 'Regime 三态参数' 检查, 并入 MR: 不完整时 MR 直接失败)。"""
    required = {"N_trend", "rsi_period", "rsi_buy", "rsi_sell", "bias_buy"}
    fp = os.path.join(PROJECT_ROOT, "config", "strategy_runtime.json")
    if not os.path.exists(fp):
        return 0, ["权威运行时参数文件不存在"]
    try:
        with open(fp, "r", encoding="utf-8") as f:
            data = json.load(f)
    except Exception:
        return 0, ["strategy_runtime.json 解析失败"]
    mr = (data.get("strategies") or {}).get("mr") or {}
    regimes, stops = mr.get("regimes") or {}, mr.get("stop_losses") or {}
    ok, issues = 0, []
    for name in ("BULL", "RANGE", "BEAR"):
        block = regimes.get(name) or {}
        params = block.get("params", block) if isinstance(block, dict) else {}
        missing = required - set(params or {})
        if not params:
            issues.append(f"{name}: 空配置")
        elif missing:
            issues.append(f"{name}: 缺少 {', '.join(sorted(missing))}")
        elif name not in stops:
            issues.append(f"{name}: 缺少统一止损参数")
        else:
            ok += 1
    return ok, issues


def _stricter(a: dict, b: dict) -> dict:
    """两个 {status, score} 取较严 (状态更差者; 同状态取低分)。"""
    ra, rb = _STATUS_RANK.get(a["status"], 2), _STATUS_RANK.get(b["status"], 2)
    if ra != rb:
        return a if ra > rb else b
    return a if a["score"] <= b["score"] else b


def audit_strategy_health():
    evidence, ev_as_of, ev_source = _current_sleeve_evidence()
    ev_src_label = "执行总览 run-all" if ev_source == "run_all" else "run_all_aggregation.sleeve_evidence (现算)"
    checks = []

    for key, name in STRATEGY_SLEEVES:
        ev = evidence.get(key) or {"status": "unknown", "label": "状态未知", "detail": ""}
        st, sc = _EVIDENCE_SCORE.get(ev.get("status"), ("warn", 50))
        primary = {"status": st, "score": sc}
        meta = f"验证状态来源: {ev_src_label}{(' @ ' + str(ev_as_of)) if ev_as_of else ''} · 权重: 25%"
        detail = f"执行总览: {ev.get('label')} — {ev.get('detail') or '—'}"
        extra = {}

        if key == "mr":
            if ev.get("status") == "unknown":
                # 无当前 MR 信号 → 执行总览无法确定当前状态; 由下方三态生命周期 (覆盖全部状态) 判定, 不额外降级
                primary = {"status": "pass", "score": 100}
            # MR 额外核查全部三态生命周期 (未验证却放行新开仓 = 失败) + 参数完整性; 取较严
            try:
                from services.strategy_params import get_all_mr_lifecycle, load_runtime_config
                try:
                    caps = load_runtime_config().get("strategies", {}).get("mr", {}).get("position_caps", {})
                except Exception:
                    caps = {}
                life = _score_mr_lifecycle(get_all_mr_lifecycle(), caps)
                lifecycle = {"status": life["status"], "score": life["score"]}
                detail += f" · 三态生命周期: {life['detail']}"
                extra["action"] = life["action"]
            except Exception as exc:
                lifecycle = {"status": "fail", "score": 0}
                detail += f" · 运行时生命周期不可用: {exc}"
                extra["action"] = "修复 strategy_runtime.json 生命周期后重新验证"
            ok, issues = _regime_integrity()
            integrity = {"status": "pass" if ok == 3 else "fail", "score": 100 if ok == 3 else (40 if ok else 20)}
            detail += f" · 三态参数 {ok}/3 完整" + (f" ({'; '.join(issues)})" if issues else "")
            res = _stricter(_stricter(primary, lifecycle), integrity)
            meta = "来源: 执行总览验证状态 + strategy_runtime.json runtime lifecycle · 权重: 25%"
            extra["explanation"] = (
                "均值回归按执行总览的验证状态, 并额外核查三个市场状态的参数生命周期与参数完整性, 三者取较严。"
                "未验证状态由引擎 allow_new_entries 闸门禁止新开仓 (受控停用); 未验证却放行新开仓、验证过期或参数缺失判为失败。")
            extra["threshold"] = "🟢 已验证且三态有效 | 🟡 未验证但闸门已关闭 | 🔴 验证过期/闸门未关闭/参数缺失"
        elif key in ("div", "mom"):
            legacy_fn = _audit_dividend_evidence if key == "div" else _audit_momentum_evidence
            legacy_name = "红利趋势" if key == "div" else "行业动量"
            try:
                fresh, stale = ((AUDIT_CFG.get("strategy_fresh_days_div", 90), AUDIT_CFG.get("strategy_stale_days_div", 180))
                                if key == "div" else
                                (AUDIT_CFG.get("strategy_fresh_days_mom", 60), AUDIT_CFG.get("strategy_stale_days_mom", 90)))
                legacy = legacy_fn(fresh, stale, SLEEVE_WEIGHT)
            except Exception as exc:
                legacy = {"status": "fail", "score": 0, "detail": f"证据审计异常: {str(exc)[:80]}"}
            res = _stricter(primary, {"status": legacy.get("status", "fail"), "score": legacy.get("score", 0)})
            detail += f" · 旧证据文件({legacy_name}): {legacy.get('detail', '—')}"
            for k in ("diagnosis", "evidence"):
                if legacy.get(k) is not None:
                    extra[k] = legacy[k]
            extra["action"] = legacy.get("action")
            extra["explanation"] = ("验证状态以执行总览为准; 旧证据文件仍读取作补充, 两者取较严 —— "
                                    "旧审计判为失败的不会因口径调整变成警告。")
            extra["threshold"] = "🟢 执行总览已验证且旧证据有效 | 🟡 证据不足/未接入验证 | 🔴 验证被拒/过期/证据失效"
        else:
            res = primary
            extra["explanation"] = "GEM 双动量为独立信号源, 目前无验证记录; 信号照常展示但只归入观察。"
            extra["threshold"] = "🟢 已验证 | 🟡 无验证记录 | 🔴 验证被拒/过期"
            extra["action"] = None if st == "pass" else "按预注册流程补做样本外验证后再归入已验证"

        checks.append({"name": name, "sleeve": key, "status": res["status"], "score": res["score"],
                       "detail": detail, "meta": meta, "evidence_status": ev.get("status"), **extra})

    weights = [SLEEVE_WEIGHT] * len(checks)
    total_w = sum(weights)
    weighted_exact = sum(c["score"] * w for c, w in zip(checks, weights)) / total_w
    weighted_score = int(weighted_exact)
    final_score = weighted_score
    applied_rules, circuit_breaker = [], None

    # 失败数断路器 (保留原规则): 防止均值掩盖结构性问题
    fail_count = sum(1 for c in checks if c["status"] == "fail")
    cap = 50 if fail_count >= 3 else (65 if fail_count >= 2 else None)
    if cap is not None and final_score > cap:
        circuit_breaker = {"reason": f"{fail_count}项检查失败", "cap": cap, "original": final_score}
        applied_rules.append({"rule": "fail_count_cap", "reason": circuit_breaker["reason"],
                              "before": final_score, "after": cap})
        final_score = cap
    # 核心路径联锁 (保留原规则): MR 不及格时模块不得及格
    mr_score = next(c["score"] for c in checks if c["sleeve"] == "mr")
    if mr_score < 60 and final_score >= 60:
        if not circuit_breaker:
            circuit_breaker = {"reason": "核心路径联锁", "cap": 59, "original": final_score}
        applied_rules.append({"rule": "critical_path_interlock", "reason": "核心路径联锁",
                              "before": final_score, "after": 59})
        final_score = 59

    module_weight = TRUST_GROUP_WEIGHT
    result = {
        "module": "strategy_health",
        "label": "⚙️ 策略健康",
        "score": final_score,
        "grade": _grade(final_score),
        "checks": checks,
        "diagnosis": {
            "summary": (
                f"{fail_count} 项检查失败。只评独立信号源 MR/DIV/MOM/GEM 的验证与参数控制; "
                "失败表示证据或控制条件未通过, 不等同于当前市场方向或策略信号失效。" if fail_count else
                ("无失败项; 未验证的信号源只归入观察。" if any(c["status"] == "warn" for c in checks) else
                 "四个信号源均已验证; 这不等于已独立证明策略未来有效。")),
            "scope": "验证状态与策略页执行总览同源; ERP/AIAE 为背景读数, 不参与本模块打分。",
        },
        "score_audit": {
            "formula": "Σ(检查得分 × 25%) ÷ 100% (等权)",
            "rounding": "int 向下取整",
            "weight_total": round(total_w, 6),
            "weighted_exact": round(weighted_exact, 4),
            "weighted_score": weighted_score,
            "final_score": final_score,
            "module_weight": module_weight,
            "overall_contribution": round(final_score * module_weight, 4),
            "contributions": [
                {"name": c["name"], "score": c["score"], "weight": w,
                 "weighted": round(c["score"] * w / total_w, 4)}
                for c, w in zip(checks, weights)
            ],
            "applied_rules": applied_rules,
        },
    }
    if circuit_breaker:
        result["circuit_breaker"] = circuit_breaker
    return result


# ═══════════════════════════════════════════════════════
#  组合读数辅助: 实时估值 (相关性集中度补充读数用)
# ═══════════════════════════════════════════════════════
def _get_live_portfolio():
    """
    尝试从 portfolio_engine 获取实时估值 (含真实价格/盈亏)。
    若引擎不可用，则降级为成本估算 (fallback)。
    返回: (pos_list, cash, total_asset, is_live, risk_metrics, market_value)
    market_value: 券商参考市值 (导入当日) 或 Tushare 重算市值 (隔日)
    """
    # ── 优先: 调用 portfolio_engine 单例 (真实价格) ──
    try:
        from portfolio_engine import get_portfolio_engine
        engine = get_portfolio_engine()
        val = engine.get_valuation()
        pos_list = val.get("positions", [])
        cash = val.get("cash", 0)
        total_asset = val.get("total_asset", 0)
        market_value = val.get("market_value", 0)

        # 2026-11-04: 删除 calculate_risk_metrics 调用 —— 唯一调用方 (_compliance_checks) 丢弃该返回值, 属白算
        # (拉 120 日行情); 返回值位置保留为 None, 签名不变 (docs/PORTFOLIO_SLIMMING_PLAN.md 第 9 节登记)
        return pos_list, cash, total_asset, True, None, market_value
    except Exception as e:
        print(f"[Audit] portfolio_engine 不可用, 降级为成本估算: {e}")

    # ── 降级: 从 JSON 手动解析 (成本估算) ──
    pf_path = os.path.join(PROJECT_ROOT, "data_lake", "portfolio_store.json")
    if not os.path.exists(pf_path):
        return [], 0, 0, False, None, 0
    try:
        with open(pf_path, "r", encoding="utf-8") as f:
            pf = json.load(f)
        positions_raw = pf.get("positions", {})
        cash = pf.get("cash", 0)
        pos_list = []
        if isinstance(positions_raw, dict):
            for code, info in positions_raw.items():
                amt = info.get("amount", 0)
                cost = info.get("cost", 0)
                mv = amt * cost
                pos_list.append({
                    "ts_code": code,
                    "name": info.get("name", code),
                    "amount": amt,
                    "cost": cost,
                    "price": cost,
                    "market_value": mv,
                    "pnl": 0,
                    "pnl_pct": 0,
                    "weight": 0,
                    "industry": "未知",
                })
        total_mv = sum(p.get("market_value", 0) for p in pos_list)
        total_asset = cash + total_mv
        for p in pos_list:
            p["weight"] = round(p["market_value"] / max(total_asset, 1) * 100, 2)
        return pos_list, cash, total_asset, False, None, total_mv
    except Exception:
        return [], 0, 0, False, None, 0


# ═══════════════════════════════════════════════════════
#  V6.9 相关性集中度 (Correlation-Cluster Concentration)
#  行业标签无法识别"标签不同、同涨同跌"的敞口 (如 半导体/PCB/科创50)。
#  方法: 近 N 日日收益相关矩阵 → 平均连接层次聚类 (簇间平均ρ≥阈值才合并)
#        → 以最大相关簇占总资产比例评分; 附有效独立敞口数与分散比。
# ═══════════════════════════════════════════════════════
def _load_daily_returns(codes, window=120):
    """从本地 data_lake/daily_prices 读取收盘价并计算日收益 (不调用外部 API)。"""
    frames = {}
    for code in codes:
        fp = os.path.join(PROJECT_ROOT, "data_lake", "daily_prices", f"{code}.parquet")
        if not os.path.exists(fp):
            continue
        try:
            df = pd.read_parquet(fp, columns=["trade_date", "close"])
        except Exception:
            continue
        df["trade_date"] = pd.to_datetime(df["trade_date"].astype(str).str[:8], format="%Y%m%d", errors="coerce")
        s = df.dropna().drop_duplicates("trade_date").set_index("trade_date")["close"].sort_index()
        frames[code] = s
    if not frames:
        return pd.DataFrame()
    prices = pd.DataFrame(frames).sort_index().iloc[-(window + 1):]
    rets = prices.pct_change(fill_method=None).iloc[1:]
    # 剔除超出涨跌幅限制的单日跳变 (送转/除权未复权造成的伪收益)
    return rets.mask(rets.abs() > 0.205)


def _correlation_clusters(returns, weights, threshold=0.6, min_obs=60):
    """
    纯函数: 平均连接层次聚类。
    returns: DataFrame(日期 × 代码); weights: {代码: 占总资产%}
    返回 dict: clusters [(codes, weight, avg_rho)], n_eff, div_ratio, covered, uncovered
    """
    codes = [c for c in weights if c in returns.columns and returns[c].count() >= min_obs]
    uncovered = [c for c in weights if c not in codes]
    if not codes:
        return {"clusters": [], "n_eff": None, "div_ratio": None, "covered": [], "uncovered": uncovered}
    corr = returns[codes].corr(min_periods=min_obs)

    def rho(a, b):
        v = corr.at[a, b]
        return float(v) if pd.notna(v) else 0.0   # 数据不足的配对视为不相关, 不强行合并

    clusters = [[c] for c in codes]
    while len(clusters) > 1:
        best, pair = -2.0, None
        for i in range(len(clusters)):
            for j in range(i + 1, len(clusters)):
                avg = float(np.mean([rho(a, b) for a in clusters[i] for b in clusters[j]]))
                if avg > best:
                    best, pair = avg, (i, j)
        if best < threshold:
            break
        i, j = pair
        clusters[i] = clusters[i] + clusters[j]
        del clusters[j]

    out = []
    for cl in clusters:
        w = sum(weights[c] for c in cl)
        pairs = [rho(a, b) for k, a in enumerate(cl) for b in cl[k + 1:]]
        out.append((sorted(cl, key=lambda c: -weights[c]), w, float(np.mean(pairs)) if pairs else 1.0))
    for c in uncovered:   # 无数据持仓单独成簇 (保守: 不与他人合并, 但计入权重)
        out.append(([c], weights[c], None))
    out.sort(key=lambda x: -x[1])

    total = sum(x[1] for x in out) or 1.0
    n_eff = 1.0 / sum((x[1] / total) ** 2 for x in out)

    div_ratio = None
    try:
        w_vec = np.array([weights[c] for c in codes], dtype=float)
        w_vec = w_vec / w_vec.sum()
        cov = returns[codes].cov(min_periods=min_obs).fillna(0.0).values
        vols = np.sqrt(np.clip(np.diag(cov), 0, None))
        port_vol = float(np.sqrt(max(w_vec @ cov @ w_vec, 0)))
        if port_vol > 0:
            div_ratio = float(w_vec @ vols / port_vol)
    except Exception:
        pass
    return {"clusters": out, "n_eff": n_eff, "div_ratio": div_ratio,
            "covered": codes, "uncovered": uncovered}


# ═══════════════════════════════════════════════════════
#  模块 3: 风控合规 (2026-11-02 口径修正)
#  本页不再自带任何风险阈值。判定 = 合规引擎在决策中枢同一快照上的运行结果
#  (与 decision.html 风险栏、create_order 权限同一份 compliance 对象)。
#  附加读数 (不判定、不计分): 账户回撤口径、止损执行状态、相关性集中度。
# ═══════════════════════════════════════════════════════
DECISION_PAGE_STOP_LINK = "decision.html#trailing-stop-panel"

_SEVERITY_LABEL = {"hard_block": "硬阻断", "soft_warn": "软警告", "info": "提示"}
DECREASE_EXEMPT_PREFIX = "减仓操作, 不受限制"   # compliance_engine 对减仓方向的豁免说明 (越线禁止加仓 / 回撤刹车)
_COMPLIANCE_MODULE_SCORE = {"passed": 100, "warning": 70, "blocked": 40}




def _load_decision_hub():
    """读取决策中枢快照 (与 /api/v1/decision/hub 同一 SWR 缓存与契约校验; 陈旧/契约不符时合规结果撤回为 unknown)。"""
    from services.cache_service import stale_while_revalidate, adaptive_fresh_ttl
    from dashboard_modules.decision_engine import get_hub_data_with_events
    from dashboard_modules.decision.controls import invalidate_cached_hub, CONTRACT_VERSION
    from services import warmup_state
    # 2026-11-02: 与 /decision/hub 同一预热规则 — 预热期由路由层直接返回"数据加载中"; 部分数据缺失时现算不缓存
    st = warmup_state.status()
    if st["phase"] == "warming":
        return warmup_state.warming_payload(st)
    if st["phase"] == "partial":
        hub = get_hub_data_with_events()
        hub["warmup"] = warmup_state.public(st)
        if (hub.get("action_plan") or {}).get("contract_version") != CONTRACT_VERSION:
            hub = invalidate_cached_hub(hub)
        return hub
    hub = stale_while_revalidate("swr_decision_hub", get_hub_data_with_events,
                                 fresh_ttl=adaptive_fresh_ttl(300, "decision"), stale_ttl=3600)
    if (hub.get("_cache") or {}).get("stale"):
        # 陈旧缓存的合规结论已被撤回; 审计需要当前结论 → 同步重算一次 (与决策页同一函数), 不使用陈旧结果
        hub = get_hub_data_with_events()
    if (hub.get("action_plan") or {}).get("contract_version") != CONTRACT_VERSION:
        hub = invalidate_cached_hub(hub)
    return hub


def _rule_descriptions():
    try:
        from engines.compliance_engine import COMPLIANCE_RULES
        return {r.id: r.description for r in COMPLIANCE_RULES}
    except Exception:
        return {}


def _basis_note_suffix(rule: dict) -> str:
    """2026-11-04 C2: 主题集中度附口径说明 (按名称归类 / 穿透后行业未知), 与组合页、决策中枢同一字符串。"""
    note = ((rule or {}).get("metrics") or {}).get("basis_note")
    return f" · 口径：{note}" if rule.get("rule_id") == "sector_concentration" and note else ""


def _compliance_checks(compliance: dict) -> list:
    """合规引擎每条规则 → 一条审计检查。hard_block 未通过 = fail, soft_warn 未通过 = warn。"""
    desc = _rule_descriptions()
    out = []
    for r in compliance.get("checks") or []:
        sev = r.get("severity", "")
        passed = bool(r.get("passed"))
        errored = r.get("evaluation_status") == "error"
        exempt = passed and str(r.get("detail") or "").startswith(DECREASE_EXEMPT_PREFIX)
        if errored:
            status, score = "fail", 0
        elif exempt:
            # 合规引擎按"本次候选操作=减仓"放行; 这不代表组合状态正常 → 只读, 状态见下方读数行
            status, score = "info", None
        elif passed:
            status, score = "pass", 100
        elif sev == "hard_block":
            status, score = "fail", 40
        elif sev == "soft_warn":
            status, score = "warn", 70
        else:
            status, score = "info", None
        out.append({
            "name": r.get("rule_name") or r.get("rule_id"),
            "rule_id": r.get("rule_id"),
            "source": "compliance_engine",
            "severity": sev,
            "status": status,
            "score": score,
            "detail": (r.get("detail") or "") + _basis_note_suffix(r),
            "meta": f"合规引擎 · {_SEVERITY_LABEL.get(sev, sev)} · {r.get('rule_id')}"
                    + (" · 规则执行异常" if errored else "")
                    + (" · 本次候选操作为减仓, 规则豁免 (不等于组合未触发; 见账户回撤/止损执行读数)" if exempt else ""),
            "explanation": desc.get(r.get("rule_id")) or "",
            "action": None if passed else "以决策中枢执行目标与合规结论为准处理; 本页只读不下单",
        })
    return out


def _drawdown_readout():
    """账户回撤读数 (只读): 与合规引擎刹车规则同一份 drawdown_brake 发布结果。"""
    from services.risk_state import drawdown_brake
    b = drawdown_brake()   # 与执行层、合规引擎同一来源 (缓存 → 日终快照)
    source = {"cache": "缓存", "eod_snapshot": "跟踪止盈日终快照"}.get((b or {}).get("source"), "—")
    basis_note = ("口径: 剔除出入金的风险资产时间加权净值 (TWR), 追加资金不会稀释回撤; "
                  "高水位取全历史 (未设基准)")
    if not isinstance(b, dict) or b.get("dd") is None:
        return {"name": "账户回撤 (只读)", "status": "info", "score": None, "source": "drawdown_service",
                "detail": "暂无组合回撤发布结果 (跟踪止盈日终尚未提交)", "meta": basis_note,
                "explanation": "回撤是否触发刹车由合规引擎「组合回撤刹车」规则判定; 本行只展示读数与口径。"}
    if b.get("basis") == "baseline":
        basis_note = basis_note.replace("高水位取全历史 (未设基准)", "高水位自用户设定的回撤基准日起算")
    dd = abs(float(b.get("dd") or 0))
    tier = b.get("tier") or 0
    detail = f"当前回撤 {dd:.1%} · " + (f"{b.get('label') or f'第{tier}档'} · 仓位上限 {b.get('cap_pct')}%" if tier else "未触发刹车")
    return {"name": "账户回撤 (只读)", "status": "info", "score": None, "source": "drawdown_service",
            "tier": tier, "dd": -dd, "as_of": b.get("as_of"),
            "detail": detail, "meta": f"{basis_note} · 截至 {b.get('as_of') or '—'} · 来源: {source}",
            "explanation": ("账户真实回撤, 不是回测回撤。是否触发刹车与降仓上限由合规引擎「组合回撤刹车」规则判定 "
                            "(上方规则行), 降仓目标以 AIAE 执行目标为准。")}


def _stop_execution_readout():
    """止损执行状态 (只读): 跟踪止盈引擎 RED=已触发未执行, LEGACY=跟踪前已越线未决策。执行入口在决策页。"""
    from services.risk_state import trailing_report
    rep = trailing_report()   # 与合规引擎同一来源 (缓存 → 日终快照)
    base = {"name": "止损执行状态 (只读)", "status": "info", "score": None, "source": "trailing_stop_service",
            "link": DECISION_PAGE_STOP_LINK,
            "explanation": ("止损/止盈由跟踪止盈引擎判定, 规则要求次一交易日开盘执行。执行路径: 券商端卖出 → 导入成交 → "
                            "台账自动核对计入执行纪律; 其他账户的成交在跟踪止盈面板手动确认。本页不下单。"),
            "action": "到决策中枢 · 跟踪止盈面板处理"}
    source = {"cache": "缓存", "eod_snapshot": "跟踪止盈日终快照"}.get((rep or {}).get("source"), "—")
    if not isinstance(rep, dict) or not isinstance(rep.get("positions"), list):
        return {**base, "detail": "暂无跟踪止盈日终结果", "meta": "数据: trailing_stop_report / trailing_snapshots"}
    red = [p for p in rep["positions"] if p.get("status") == "RED"]
    legacy = [p for p in rep["positions"] if p.get("status") == "LEGACY"]
    names = lambda xs: "、".join(p.get("name") or p.get("ts_code") or "?" for p in xs[:4]) + (" 等" if len(xs) > 4 else "")
    if not red and not legacy:
        detail = "无已触发未执行的止损"
    else:
        parts = []
        if red:
            parts.append(f"{len(red)} 只已触发未执行: {names(red)}")
        if legacy:
            parts.append(f"{len(legacy)} 只跟踪前已越线待决策: {names(legacy)}")
        detail = " · ".join(parts)
    return {**base, "detail": detail, "meta": f"跟踪止盈日终 · 截至 {rep.get('as_of') or '—'} · 来源: {source}",
            "red": [p.get("ts_code") for p in red], "legacy": [p.get("ts_code") for p in legacy]}


def _correlation_readout():
    """相关性集中度 (补充读数, 不判定): 识别标签不同但同涨同跌的持仓。"""
    thr = AUDIT_CFG.get("corr_cluster_threshold", 0.6)
    win = AUDIT_CFG.get("corr_window_days", 120)
    base = {"name": "相关性集中度 (补充读数)", "status": "info", "score": None, "source": "audit_engine",
            "explanation": (f"近{win}日收益相关性做层次聚类, 平均相关≥{thr}的持仓视为同一风险敞口。"
                            "本行只作补充参考, 不判定、不计分; 集中度红线以合规引擎「主题集中度」为准。")}
    try:
        pos_list, _, total_asset, _, _, _ = _get_live_portfolio()
        w_map, name_map = {}, {}
        for p in pos_list:
            code = p.get("ts_code", "")
            pname = p.get("name", code)
            if not code or code.split(".")[0].startswith(("131", "204")) or "逆回购" in pname:
                continue
            w = p.get("weight", 0) or p.get("market_value", 0) / max(total_asset, 1) * 100
            if w > 0:
                w_map[code] = w_map.get(code, 0) + w
                name_map[code] = pname
        if not w_map:
            return {**base, "detail": "无风险资产持仓", "meta": ""}
        res = _correlation_clusters(_load_daily_returns(list(w_map), win), w_map, thr, min_obs=max(20, win // 2))
        top_codes, top_w, top_rho = res["clusters"][0]
        names = "、".join(name_map[c] for c in top_codes[:4]) + (f" 等{len(top_codes)}只" if len(top_codes) > 4 else "")
        rho = f"簇内平均ρ={top_rho:.2f}" if top_rho is not None and len(top_codes) > 1 else "单一持仓"
        meta = [f"{len(res['clusters'])}个相关簇", f"有效独立敞口≈{res['n_eff']:.1f}组"]
        if res["uncovered"]:
            meta.append(f"无行情数据 {len(res['uncovered'])}只 单独计")
        return {**base, "detail": f"最大相关簇: {names} 占总资产 {top_w:.1f}% ({rho})", "meta": " · ".join(meta)}
    except Exception as exc:
        return {**base, "detail": f"无法计算: {str(exc)[:60]}", "meta": "依赖本地日线行情"}


def audit_risk_control(hub: dict = None):
    try:
        hub = hub if hub is not None else _load_decision_hub()
        hub_error = None
    except Exception as exc:
        hub, hub_error = {}, str(exc)[:100]
    compliance = (hub or {}).get("compliance") or {"status": "unknown", "checks": []}
    status = compliance.get("status") or "unknown"
    checks = _compliance_checks(compliance)
    if status not in _COMPLIANCE_MODULE_SCORE or not checks:
        checks.insert(0, {
            "name": "合规引擎结果", "source": "compliance_engine", "status": "fail", "score": 0,
            "detail": hub_error or compliance.get("summary") or "决策快照中没有可用的合规结果",
            "meta": "合规引擎未在当前快照上运行 / 快照陈旧已撤回",
            "explanation": "无法读取合规结论时, 风控不能视为通过 (fail-closed)。",
            "action": "打开决策中枢刷新快照; 若仍不可用, 检查账户估值与 AIAE 执行层",
        })
        status = "unknown"
    checks += [_drawdown_readout(), _stop_execution_readout(), _correlation_readout()]
    score = _COMPLIANCE_MODULE_SCORE.get(status, 0)
    status_label = {"passed": "通过", "warning": "警告", "blocked": "阻断", "unknown": "不可用"}[status]
    return {
        "module": "risk_control",
        "label": "🛡️ 风控合规",
        "score": score,
        "grade": _grade(score),
        "checks": checks,
        "compliance_status": status,
        "compliance_status_label": status_label,
        "compliance_summary": compliance.get("summary"),
        "snapshot": {
            "source": "decision_hub",
            "timestamp": (hub or {}).get("timestamp"),
            "decision_state": ((hub or {}).get("action_plan") or {}).get("state"),
            "create_order": ((hub or {}).get("permissions") or {}).get("create_order"),
        },
        "diagnosis": {
            "summary": f"合规引擎结论: {status_label}。本页不自带风险阈值, 规则与判定均来自合规引擎 (与决策中枢同一快照)。",
            "scope": "组合合规只显示合规引擎结论 (通过/警告/阻断/不可用), 不打分, 不进入系统可信度的平均。",
        },
    }


# ═══════════════════════════════════════════════════════
#  模块 4: 因子衰减审计 (轻量版 — 基于文件元数据)
# ═══════════════════════════════════════════════════════
def audit_factor_decay():
    """
    轻量审计: 检查因子分析相关文件的可用性
    深度审计需要调用 /api/v1/factor-analysis, 由前端按需触发
    """
    checks = []
    scores = []

    # 检查因子分析器是否可导入
    try:
        from engines.factor_analyzer import FactorAnalyzer
        fa = FactorAnalyzer()
        scores.append(100)
        checks.append({
            "name": "因子引擎可用性",
            "status": "pass",
            "detail": "FactorAnalyzer 模块加载正常",
            "score": 100,
            "explanation": "FactorAnalyzer 是多因子体系的核心计算引擎，负责 IC 值计算、因子排名、衰减分析等。无法加载意味着整个因子分析模块睢痪。",
            "threshold": "🟢 可加载: 因子分析可用 | 🔴 导入失败: 因子分析瘫痪",
            "action": "检查 factor_analyzer.py 是否存在且依赖库完整",
        })
    except Exception as e:
        scores.append(0)
        checks.append({
            "name": "因子引擎可用性",
            "status": "fail",
            "detail": f"导入失败: {str(e)[:60]}",
            "score": 0,
            "explanation": "FactorAnalyzer 无法加载，可能是 Python 文件缺失或依赖库未安装。整个因子分析页面将无法使用。",
            "threshold": "🟢 可加载 | 🔴 导入失败",
            "action": "确认 factor_analyzer.py 存在并检查 pip install requirements.txt",
        })

    # 检查因子需要的数据是否存在
    daily_count = len(glob.glob(os.path.join(DAILY_DIR, "*.parquet")))
    fina_count = len(glob.glob(os.path.join(FINA_DIR, "*.parquet")))

    s = 100 if daily_count >= 30 and fina_count >= 10 else (60 if daily_count >= 10 else 20)
    scores.append(s)
    checks.append({
        "name": "因子数据覆盖",
        "status": "pass" if s >= 80 else ("warn" if s >= 50 else "fail"),
        "detail": f"日线: {daily_count}只, 财务: {fina_count}只",
        "meta": "建议: 日线≥30只, 财务≥10只",
        "score": s,
        "explanation": "因子分析需要足够的样本覆盖才能产生统计显著的结果。日线<30只时因子排名不稳定，财务<10只时基本面因子暂光不充分。",
        "threshold": "🟢 日线≥30+财务≥10: 充分覆盖 | 🟡 日线≥10: 勉强可用 | 🔴 <10: 结果不可靠",
        "action": "执行 python data_manager.py 扩大样本池",
    })

    # V8.0: 因子可用性真实验证 (双通道随机抽样 + NaN 穿透校验)
    factor_types = {
        "基本面": ["roe", "eps", "netprofit_margin", "bps", "debt_to_assets"],
        "技术面": ["momentum_20d", "volatility_20d", "turnover_rate"],
    }
    total_factors = sum(len(v) for v in factor_types.values())

    # 1. 基本面财务数据验证
    fina_files = glob.glob(os.path.join(FINA_DIR, "*.parquet"))
    fina_ok_ratio = 0.0
    fina_checks_run = 0
    if fina_files:
        sampled_fina = random.sample(fina_files, min(len(fina_files), 3))
        for f in sampled_fina:
            try:
                df = pd.read_parquet(f)
                required_cols = {"roe", "eps", "bps"}
                found_cols = required_cols.intersection(set(df.columns))
                if len(found_cols) >= 2:
                    non_nan_sum = 0
                    for col in found_cols:
                        total_cnt = len(df)
                        non_nan_sum += df[col].notna().sum() / max(total_cnt, 1)
                    avg_non_nan = non_nan_sum / len(found_cols)
                    fina_ok_ratio += avg_non_nan
                fina_checks_run += 1
            except Exception:
                pass
    fina_score_ratio = fina_ok_ratio / max(fina_checks_run, 1)

    # 2. 技术面日线数据验证
    daily_files = glob.glob(os.path.join(DAILY_DIR, "*.parquet"))
    daily_ok_ratio = 0.0
    daily_checks_run = 0
    if daily_files:
        sampled_daily = random.sample(daily_files, min(len(daily_files), 3))
        for f in sampled_daily:
            try:
                df = pd.read_parquet(f)
                required_cols = {"vol", "close", "pct_chg"}
                found_cols = required_cols.intersection(set(df.columns))
                if len(found_cols) >= 2:
                    non_nan_sum = 0
                    for col in found_cols:
                        total_cnt = len(df)
                        non_nan_sum += df[col].notna().sum() / max(total_cnt, 1)
                    avg_non_nan = non_nan_sum / len(found_cols)
                    daily_ok_ratio += avg_non_nan
                daily_checks_run += 1
            except Exception:
                pass
    daily_score_ratio = daily_ok_ratio / max(daily_checks_run, 1)

    # 3. 计分逻辑
    fina_valid = (fina_score_ratio >= 0.50) if fina_checks_run > 0 else False
    daily_valid = (daily_score_ratio >= 0.90) if daily_checks_run > 0 else False

    if fina_valid and daily_valid:
        s = 95
        status = "pass"
        detail = f"基本面(可用率{fina_score_ratio*100:.0f}%) + 技术面(可用率{daily_score_ratio*100:.0f}%) 验证通过"
    elif fina_count >= 10 and daily_count >= 30:
        s = 60
        status = "warn"
        detail = f"因子定义就绪但数据不达标 [基本面可用率:{fina_score_ratio*100:.0f}%, 技术面可用率:{daily_score_ratio*100:.0f}%]"
    else:
        s = 30
        status = "fail"
        detail = "因子定义就绪 · 样本数据不足，无法完成基本验证"

    scores.append(s)
    checks.append({
        "name": "因子池可用性",
        "status": status,
        "detail": detail,
        "meta": f"随机抽检 {fina_checks_run}只财务 + {daily_checks_run}只日线Parquet",
        "score": s,
        "explanation": "多因子分析需要数据湖中不仅有字段列，还要求列中没有大面积空值(NaN)。基本面财务数据非空率须≥50%，技术面交易日线非空率须≥90%。",
        "threshold": "🟢 基本面≥50%+技术面≥90%: 因子高可用 | 🟡 字段存在但空值过多: 降级警告 | 🔴 字段缺失/文件破损",
        "action": "运行数据同步或重新计算技术面因子，填充 NaN 缺失值",
    })

    final_score = int(np.mean(scores)) if scores else 0
    return {
        "module": "factor_decay",
        "label": "📈 因子衰减",
        "score": final_score,
        "grade": _grade(final_score),
        "checks": checks,
        "deep_audit_available": True,
    }


# ═══════════════════════════════════════════════════════
#  模块 5: 系统状态审计
# ═══════════════════════════════════════════════════════
def audit_system_status():
    global _TS_CHECK_CACHE
    checks = []
    scores = []

    # ── 5.1 Tushare API 连通性 ──
    now_ts = time.time()
    use_cache = False
    if _TS_CHECK_CACHE is not None:
        cache_age = now_ts - _TS_CHECK_CACHE.get("timestamp", 0)
        if cache_age < 120:
            use_cache = True

    if use_cache:
        latency = _TS_CHECK_CACHE["latency"]
        s = _TS_CHECK_CACHE["score"]
        status = _TS_CHECK_CACHE["status"]
        detail = _TS_CHECK_CACHE["detail"]
        if " (缓存读取)" not in detail:
            detail += " (缓存读取)"
        scores.append(s)
        checks.append({
            "name": "Tushare API",
            "status": status,
            "detail": detail,
            "score": s,
            "explanation": _TS_CHECK_CACHE.get("explanation", ""),
            "threshold": _TS_CHECK_CACHE.get("threshold", ""),
            "action": _TS_CHECK_CACHE.get("action", ""),
        })
    else:
        import requests
        original_post = requests.post
        try:
            def timeout_patched_post(url, **kwargs):
                kwargs['timeout'] = 2.5
                if 'api.waditu.com' in url or 'api.tushare.pro' in url:
                    url = 'http://api.tushare.pro'
                    try:
                        from services.tushare_limiter import tushare_limiter
                        tushare_limiter.acquire()
                    except Exception:
                        pass
                return original_post(url, **kwargs)
                
            requests.post = timeout_patched_post
            
            import tushare as ts
            pro = ts.pro_api()
            t0 = time.time()
            cal = pro.trade_cal(exchange='SSE', start_date='20260101', end_date='20260110')
            latency = (time.time() - t0) * 1000
            s = 100 if latency < 2000 else (70 if latency < 5000 else 40)
            status = "pass" if latency < 3000 else "warn"
            detail = f"连通 · 延迟 {latency:.0f}ms"
            explanation = "Tushare 是全部A股数据的入口，提供日线、财务、交易日历等。API离线意味着所有数据同步停止，系统将逐渐依赖过期缓存。延迟>3秒可能是网络问题或 API 配额耗尽。"
            threshold = "🟢 <2秒: 正常 | 🟡 2-5秒: 偏慢 | 🔴 >5秒/连接失败: 系统瘫痪"
            action = "检查网络连接和 Tushare Token 是否过期"
            
            scores.append(s)
            checks.append({
                "name": "Tushare API",
                "status": status,
                "detail": detail,
                "score": s,
                "explanation": explanation,
                "threshold": threshold,
                "action": action,
            })
            
            _TS_CHECK_CACHE = {
                "timestamp": now_ts,
                "latency": latency,
                "score": s,
                "status": status,
                "detail": detail,
                "explanation": explanation,
                "threshold": threshold,
                "action": action,
            }
        except Exception as e:
            s = 0
            status = "fail"
            detail = f"连接失败: {str(e)[:50]}"
            explanation = "Tushare API 无法连接，所有数据同步停止。可能是网络问题、Token 过期或 Tushare 服务器维护。"
            threshold = "🟢 <2秒 | 🟡 2-5秒 | 🔴 连接失败"
            action = "检查网络 + config.py 中的 Tushare Token"
            
            scores.append(s)
            checks.append({
                "name": "Tushare API",
                "status": status,
                "detail": detail,
                "score": s,
                "explanation": explanation,
                "threshold": threshold,
                "action": action,
            })
            
            _TS_CHECK_CACHE = {
                "timestamp": now_ts,
                "latency": 999999.0,
                "score": s,
                "status": status,
                "detail": detail,
                "explanation": explanation,
                "threshold": threshold,
                "action": action,
            }
        finally:
            requests.post = original_post

    # ── 5.2 数据湖统计 ──
    total_files = 0
    total_size = 0
    for root, dirs, files in os.walk(DATA_LAKE):
        for f in files:
            fp = os.path.join(root, f)
            total_files += 1
            total_size += os.path.getsize(fp)

    size_mb = total_size / (1024 * 1024)
    s = 100 if total_files >= 50 else (70 if total_files >= 20 else 40)
    scores.append(s)
    checks.append({
        "name": "数据湖容量",
        "status": "pass" if total_files >= 30 else "warn",
        "detail": f"{total_files} 个文件 · {size_mb:.1f} MB",
        "score": s,
        "explanation": "数据湖存储所有日线、财务、ERP、利率等原始数据。文件数反映数据覆盖面，容量反映历史深度。<20个文件说明初始化不完全。",
        "threshold": "🟢 ≥50个: 充分覆盖 | 🟡 20-49个: 基本可用 | 🔴 <20个: 初始化不完全",
        "action": "执行 python data_manager.py 扩大数据湖覆盖范围",
    })

    # ── 5.3 关键 Python 模块 ──
    required_modules = [
        ("pandas", "pd"),
        ("numpy", "np"),
        ("tushare", "ts"),
    ]
    missing = []
    for mod_name, _ in required_modules:
        try:
            __import__(mod_name)
        except ImportError:
            missing.append(mod_name)

    s = 100 if not missing else max(0, 100 - len(missing) * 30)
    scores.append(s)
    checks.append({
        "name": "依赖库完整性",
        "status": "pass" if not missing else "fail",
        "detail": "全部就绪" if not missing else f"缺失: {', '.join(missing)}",
        "score": s,
        "explanation": "pandas/numpy/tushare 是核心计算引擎的基础依赖。任一缺失都会导致策略引擎、因子分析、数据同步等核心功能无法运行。",
        "threshold": "🟢 全部就绪: 系统正常 | 🔴 有缺失: 必须安装",
        "action": "执行 pip install -r requirements.txt 补全依赖",
    })

    # ── 5.4 ECharts 前端资源 ──
    echarts_path = os.path.join(PROJECT_ROOT, "static", "vendor", "echarts.min.js")
    if os.path.exists(echarts_path):
        esize = os.path.getsize(echarts_path) / 1024
        scores.append(100)
        checks.append({
            "name": "ECharts 引擎",
            "status": "pass",
            "detail": f"就绪 ({esize:.0f} KB)",
            "score": 100,
            "explanation": "ECharts 是前端图表渲染引擎，驱动仪表盘、雷达图、K线等所有可视化。缺失将导致全部图表无法渲染。",
            "threshold": "🟢 文件存在: 可视化正常 | 🔴 缺失: 图表全部睢痪",
            "action": "从 CDN 下载 echarts.min.js 放置于项目根目录",
        })
    else:
        scores.append(30)
        checks.append({"name": "ECharts 引擎", "status": "fail", "detail": "文件不存在", "score": 30, "explanation": "ECharts 文件缺失，全部图表将无法渲染。", "threshold": "🟢 存在 | 🔴 缺失", "action": "从 CDN 下载 echarts.min.js"})

    # ── 5.5 服务器运行检测 ──
    scores.append(100)
    checks.append({
        "name": "服务进程",
        "status": "pass",
        "detail": f"运行中 · 审计时间 {datetime.now().strftime('%H:%M:%S')}",
        "score": 100,
        "explanation": "后端服务进程存活 = API 可达，所有前端页面可正常加载数据。若服务崩溃则整个 Dashboard 无法使用。",
        "threshold": "🟢 运行中: 系统正常 | 🔴 崩溃: 无法访问",
        "action": "运行 python main.py 或双击 启动服务器.bat",
    })

    # ── V22.0: 新模块就绪检查 ──
    v22_modules = [
        ("compliance_engine", "预交易合规引擎"),
        ("drift_monitor", "策略漂移监控"),
    ]
    for mod_name, mod_label in v22_modules:
        try:
            __import__(f"engines.{mod_name}")
            scores.append(100)
            checks.append({
                "name": f"V22.0 {mod_label}",
                "status": "pass",
                "detail": f"模块 {mod_name} 就绪",
                "score": 100,
                "explanation": f"{mod_label}是 V22.0 新增的生产级风控模块。离线不影响核心数据流，但会失去预交易合规检查和策略漂移预警能力。",
                "threshold": "🟢 就绪: 正常 | 🔴 缺失: 失去风控增强",
            })
        except ImportError:
            scores.append(60)
            checks.append({
                "name": f"V22.0 {mod_label}",
                "status": "warn",
                "detail": f"模块 {mod_name} 未加载",
                "score": 60,
                "explanation": f"{mod_label}未正确加载。请检查 engines/{mod_name}.py 文件是否存在。",
                "threshold": "🟢 就绪 | 🔴 缺失",
                "action": f"检查 engines/{mod_name}.py 文件完整性",
            })

    # ── V22.0: 事件日志文件 ── (os already imported at module level)
    event_log = os.path.join(DATA_LAKE, "market_events.json")
    snapshot_file = os.path.join(DATA_LAKE, "event_last_snapshot.json")
    for fpath, fname in [(event_log, "市场事件日志"), (snapshot_file, "事件快照")]:
        if os.path.exists(fpath):
            try:
                size = os.path.getsize(fpath)
                scores.append(100)
                checks.append({
                    "name": f"V22.0 {fname}",
                    "status": "pass",
                    "detail": f"{fname} 就绪 ({size} bytes)",
                    "score": 100,
                    "explanation": f"{fname}是 V22.0 动态事件驱动引擎的持久化文件。",
                    "threshold": "🟢 就绪 | 🔴 缺失",
                })
            except Exception:
                pass

    # ── 账户数据环境 (2026-11-04 权威环境收尾): 权威 / 非权威, 只读, 不带 score, 不参与评分 ──
    try:
        checks.append(_authority_readout())
    except Exception as e:  # noqa: BLE001
        checks.append({"name": "账户数据环境", "status": "warn", "detail": f"读取失败: {str(e)[:80]}"})

    # ── 定时任务最近成功时间 (2026-11-04 C3): 只读, 不带 score, 不参与评分 ──
    try:
        checks.append(_job_runs_readout())
    except Exception as e:  # noqa: BLE001
        checks.append({"name": "定时任务运行", "status": "warn", "detail": f"读取失败: {str(e)[:80]}"})

    final_score = int(np.mean(scores)) if scores else 0
    return {
        "module": "system_status",
        "label": "🖥️ 系统状态",
        "score": final_score,
        "grade": _grade(final_score),
        "checks": checks,
    }



def _authority_readout() -> dict:
    """当前环境是权威 / 非权威 (services/account_authority)。ACCOUNT_AUTHORITY 未设置为警告; 只读不计分。"""
    from services import account_authority as aa
    st = aa.status(include_account=False)
    a = st["authority"]
    if a == aa.SERVER:
        detail = f"权威 · {aa.ENV_VAR}=server · 账户数据在此导入"
    elif a == aa.LOCAL:
        detail = f"非权威 · {aa.ENV_VAR}=local · 导入 / 清零 / 账户写入关闭, 买入门控拒绝, 不对外推送; 执行建议以服务器为准"
    else:
        detail = f"非权威 · {aa.ENV_VAR} 未设置（按非权威处理）· 服务器必须在 .env 写 {aa.ENV_VAR}=server"
    return {
        "name": "账户数据环境",
        "status": "warn" if a == aa.UNSET else "info",
        "detail": detail,
        "authority": a,
        "authoritative": st["authoritative"],
        "explanation": "服务器为权威环境, 账本以服务器导入的对账单和成交为准。非权威环境 (本机) 拒绝导入与账户写入, "
                       "买入门控一律拒绝, 不向外推送。环境由环境变量 ACCOUNT_AUTHORITY 决定, 未设置按非权威处理。",
        "threshold": "未设置为警告 (只读, 不计分)",
    }


def _job_runs_readout() -> dict:
    """各定时任务最近成功时间 (C3, services/job_runs)。关键任务失败 / 逾期为"警告"; 只读不计分。"""
    from services.job_runs import status_rows
    rows = status_rows()
    crit = [r for r in rows if r["critical"]]
    # 2026-11-04: 非关键任务被开关暂停 → 单列"已暂停", 不算异常; 关键任务被暂停 → 警告 (不当作正常的"已暂停")
    paused_other = [r for r in rows if r.get("paused") and not r["critical"]]
    bad = [r for r in rows if not (r.get("paused") and not r["critical"])
           and (r["last_status"] == "failed" or r["overdue"] or r.get("paused"))]
    bad_crit = [r for r in bad if r["critical"]]

    def fmt(r):
        if r["last_success"]:
            t = r["last_success"][5:16].replace("T", " ")
        else:
            t = "从未成功" if r["last_status"] == "failed" else "无记录"
        flags = []
        if r.get("paused"):
            flags.append("已暂停（关键任务不应暂停）" if r["critical"] else "已暂停")
        if r["last_status"] == "failed":
            flags.append("最近失败")
        elif r["overdue"]:
            flags.append("逾期")
        return f"{r['label']} {t}{' · ' + ' · '.join(flags) if flags else ''}"
    parts = ["关键: " + "；".join(fmt(r) for r in crit)] if crit else ["尚无运行记录"]
    others = [r for r in bad if not r["critical"]]
    if others:
        parts.append("其他异常: " + "；".join(fmt(r) for r in others))
    if paused_other:
        parts.append("已暂停: " + "；".join(f"{r['label']}（{r.get('pause_reason') or '未写原因'}）" for r in paused_other))
    return {
        "name": "定时任务运行",
        "status": "warn" if bad_crit else "info",
        "detail": "。".join(parts),
        "explanation": "记录于 data_lake/job_runs.json (部署不丢)。失败 = 抛异常 / 运行中写出 ERROR 日志 / 返回失败状态; "
                       "逾期 = 按调度规则应运行后 45 分钟仍未成功。关键任务失败当天推送, 其他任务连续失败 3 次推送 (均每天 1 次)。"
                       "暂停开关见 config/job_switches.json: 非关键任务暂停单列、不算逾期; 关键任务被暂停为警告并按逾期推送。",
        "threshold": "关键任务失败、逾期或被暂停为警告 (只读, 不计分)",
        "readout": rows,
    }


def _expected_record_day():
    """最近一个应已完成记录的交易日: 收盘预热 15:35 后才算当天, 留到 16:00。"""
    from services.market_clock import CN_TZ
    now = datetime.now(CN_TZ).replace(tzinfo=None)
    day = _last_trading_day()
    if day.date() == now.date() and now.hour < 16:
        day -= timedelta(days=1)
        while not _is_trading_day(day):
            day -= timedelta(days=1)
    return day


# ── 一票否决项阈值 (单一来源; 页面"否决规则"说明读 system_trust.veto_rules) ──
# 只有 ERP v4 前向记录有容忍区: 收盘预热偶尔未跑到, 缺 1 个交易日属正常延迟 → 警告, 不否决;
# 连续缺 ≥2 个交易日视为断档 → 否决。AIAE 新鲜度与合规引擎运行无容忍区 (通过 / 否决)。
ERP_V4_GAP_TOLERANCE_DAYS = 1   # gap ≤ 1: 警告 (容忍)
ERP_V4_GAP_VETO_DAYS = ERP_V4_GAP_TOLERANCE_DAYS + 1   # gap ≥ 2: 否决 (断档); 容忍区与否决区相接, 无空档
VETO_RULES = (
    {"name": "AIAE 数据新鲜度", "pass": "存在、未锁定且在新鲜期内",
     "warn": None, "veto": "缺失 / 过期 / 质量闸门锁定 / 读取失败"},
    {"name": "合规引擎运行", "pass": "当前决策快照有结论 (通过/警告/阻断均可)",
     "warn": None, "veto": "无结论 (未运行 / 快照陈旧已撤回)"},
    {"name": "ERP v4 前向记录", "pass": "最近应记录交易日已记录",
     "warn": f"缺 {ERP_V4_GAP_TOLERANCE_DAYS} 个交易日 (正常延迟, 容忍, 不否决)",
     "veto": f"连续缺 ≥{ERP_V4_GAP_VETO_DAYS} 个交易日 (断档) / 无记录 / 读取失败"},
)
# A 系统可信度状态分界 (未触发否决时按四项均分判定)
TRUST_PASS_MIN = 85
TRUST_WARN_MIN = 70


def _erp_v4_forward_check():
    """ERP v4 规则 (线上口径) 的前向记录是否连续。ERP 只是背景读数, 这里只查引擎是否在按日记录。"""
    import csv
    path = os.path.join(DATA_LAKE, "erp_v4_forward_log.csv")
    start = "2026-10-30"
    base = {
        "name": "ERP v4 前向记录",
        "explanation": ("ERP 为 v4 规则 (背景读数, 不输出仓位、不参与策略打分)。v4 每个交易日记录一次首见读数, "
                        "作为预注册的前向样本; 断档意味着引擎未运行或记录失败, 前向样本出现缺口。"),
        "threshold": "🟢 最近交易日已记录 | 🟡 缺 1 个交易日 | 🔴 连续缺 ≥2 个交易日 (断档) / 无记录",
        "action": "启动服务让 15:35 收盘预热运行, 或打开策略页 ERP 模块触发记录 (同日只记一次, 不回填)",
    }
    try:
        if os.path.exists(path):
            with open(path, encoding="utf-8-sig", newline="") as f:
                dates = sorted({(r.get("trade_date") or "").strip() for r in csv.DictReader(f)} - {""})
        else:
            dates = []
    except Exception as exc:
        return {**base, "status": "fail", "score": 0, "detail": f"前向记录读取失败: {str(exc)[:60]}"}
    if not dates:
        return {**base, "status": "fail", "score": 0, "gap_trading_days": None,
                "detail": "data_lake/erp_v4_forward_log.csv 无记录"}
    last = datetime.strptime(dates[-1], "%Y-%m-%d")
    expected = _expected_record_day()
    gap, cur = 0, last + timedelta(days=1)
    while cur.date() <= expected.date():
        if _is_trading_day(cur):
            gap += 1
        cur += timedelta(days=1)
    missing_total, cur = 0, datetime.strptime(start, "%Y-%m-%d")
    have = set(dates)
    while cur.date() <= expected.date():
        if _is_trading_day(cur) and cur.strftime("%Y-%m-%d") not in have:
            missing_total += 1
        cur += timedelta(days=1)
    status, score = ("pass", 100) if gap == 0 else (
        ("warn", 70) if gap <= ERP_V4_GAP_TOLERANCE_DAYS else ("fail", 30))
    detail = (f"最近记录 {dates[-1]}" + (f" · 距应记录日 {expected:%Y-%m-%d} 缺 {gap} 个交易日" if gap else " · 已覆盖最近交易日"))
    return {**base, "status": status, "score": score, "gap_trading_days": gap, "detail": detail,
            "meta": f"自 {start} 起共 {len(dates)} 个记录日 · 历史缺口 {missing_total} 个交易日 · data_lake 不入 git, 只统计本机"}


def _aiae_freshness_check():
    """AIAE V6-A (线上口径) 上下文是否新鲜可用 —— 全站唯一仓位数字的输入, 一票否决项。"""
    base = {
        "name": "AIAE 数据新鲜度",
        "explanation": ("AIAE 执行目标是全站唯一的仓位数字。AIAE 上下文缺失、过期或被质量闸门锁定时, "
                        "执行目标不可信, 系统可信度直接判失败 (不参与平均)。V5 影子不在此检查。"),
        "threshold": "🟢 存在、未锁定且在新鲜期内 | 🔴 缺失 / 过期 / 质量锁定",
        "action": "检查 AIAE 预热日志 (启动/每日预热), 或打开策略页 AIAE 模块触发刷新",
    }
    try:
        from services.cache_service import cache_manager
        from services.health_status import evaluate_aiae_context
        ctx = cache_manager.get_json("aiae_ctx")
        st = evaluate_aiae_context(ctx, now_ts=time.time())
    except Exception as exc:
        return {**base, "status": "fail", "score": 0, "detail": f"AIAE 上下文读取失败: {str(exc)[:60]}"}
    reason_cn = {"missing": "缓存缺失", "decision_locked": "质量闸门锁定", "stale": "已过期",
                 "timestamp_missing_or_invalid": "时间戳缺失/无效"}
    age = st.get("age_sec")
    age_txt = f"{age / 3600:.1f} 小时前更新" if age is not None else "更新时间未知"
    mode = (ctx or {}).get("regime_mode") or "—"
    meta = f"口径: {mode} · 质量分 {st.get('data_quality_score')} · 新鲜期 {int(st.get('max_age_sec') or 0) // 3600} 小时"
    if st.get("usable"):
        return {**base, "status": "pass", "score": 100, "detail": f"可用 · {age_txt} · 档位 R{(ctx or {}).get('regime')}", "meta": meta}
    return {**base, "status": "fail", "score": 0,
            "detail": f"不可用: {reason_cn.get(st.get('reason'), st.get('reason'))} · {age_txt}", "meta": meta}


def _compliance_run_check(risk_module: dict):
    """合规引擎是否在当前决策快照上运行并给出结论 —— 一票否决项。"""
    status = (risk_module or {}).get("compliance_status") or "unknown"
    ok = status in _COMPLIANCE_MODULE_SCORE
    snap = (risk_module or {}).get("snapshot") or {}
    return {
        "name": "合规引擎运行",
        "status": "pass" if ok else "fail", "score": 100 if ok else 0,
        "detail": (f"已在决策快照上运行 · 结论: {(risk_module or {}).get('compliance_status_label')}" if ok
                   else "当前决策快照没有可用的合规结论 (未运行 / 快照陈旧已撤回)"),
        "meta": f"快照时间 {snap.get('timestamp') or '—'}",
        "explanation": "组合合规判定的唯一来源。没有合规结论时, 系统不可信, 且组合合规显示'不可用'。",
        "threshold": "🟢 有结论 (通过/警告/阻断均可) | 🔴 无结论",
        "action": None if ok else "打开决策中枢刷新快照; 若仍不可用, 检查账户估值与 AIAE 执行层",
    }


# ═══════════════════════════════════════════════════════
#  综合审计入口 (只读) —— 2026-11-02 方案 B: A/B 分开呈现、分开打分
#    A. 系统可信度 = 数据新鲜度 / 引擎运行 / 参数证据 / 系统状态 四项等权;
#       一票否决: AIAE 数据过期 · 合规引擎未运行 · ERP v4 前向记录断档 (不参与平均)
#    B. 组合合规 = 合规引擎结论 (通过/警告/阻断/不可用), 不打分、不进 A 的平均
# ═══════════════════════════════════════════════════════
AUDIT_SCHEMA_VERSION = "audit-2026.11.02-B"
TRUST_GROUPS = (
    ("data_freshness", "数据新鲜度"),
    ("engine_runtime", "引擎运行"),
    ("param_evidence", "参数证据"),
    ("system_status", "系统状态"),
)
TRUST_GROUP_WEIGHT = 0.25
_ENGINE_CHECK_NAMES = {"V22.0 预交易合规引擎", "V22.0 策略漂移监控"}   # 从系统状态并入引擎运行


def _mean_score(checks):
    vals = [c["score"] for c in checks if isinstance(c.get("score"), (int, float))]
    return int(np.mean(vals)) if vals else 0


def _safe(key, label, fn):
    try:
        return fn()
    except Exception as e:
        return {"module": key, "label": label, "score": 0, "grade": "D",
                "checks": [{"name": "执行异常", "status": "fail", "detail": str(e)[:100], "score": 0}]}


def _trust_status(score: int) -> str:
    return "pass" if score >= TRUST_PASS_MIN else ("warn" if score >= TRUST_WARN_MIN else "fail")


def run_full_audit():
    """只读审计: 不写交易阻断、不写审计历史 (历史见 save_audit_snapshot)。"""
    start = time.time()
    dq = _safe("data_quality", "数据新鲜度", audit_data_quality)
    sh = _safe("strategy_health", "参数证据", audit_strategy_health)
    rc = _safe("risk_control", "组合合规", audit_risk_control)
    fd = _safe("factor_decay", "因子", audit_factor_decay)
    ss = _safe("system_status", "系统状态", audit_system_status)
    if "compliance_status" not in rc:
        rc.update({"compliance_status": "unknown", "compliance_status_label": "不可用"})

    engine_checks = list(fd.get("checks", [])) + [c for c in ss.get("checks", []) if c.get("name") in _ENGINE_CHECK_NAMES]
    system_checks = [c for c in ss.get("checks", []) if c.get("name") not in _ENGINE_CHECK_NAMES]
    groups = {
        "data_freshness": {**dq, "module": "data_freshness", "label": "📡 数据新鲜度"},
        "engine_runtime": {"module": "engine_runtime", "label": "⚙️ 引擎运行", "checks": engine_checks,
                           "score": _mean_score(engine_checks)},
        "param_evidence": {**sh, "module": "param_evidence", "label": "🧪 参数证据"},
        "system_status": {**ss, "module": "system_status", "label": "🖥️ 系统状态", "checks": system_checks,
                          "score": _mean_score(system_checks)},
    }
    for g in groups.values():
        g["grade"] = _grade(g["score"])
        g["weight"] = TRUST_GROUP_WEIGHT

    vetoes = [_aiae_freshness_check(), _compliance_run_check(rc), _erp_v4_forward_check()]
    vetoed = [v["name"] for v in vetoes if v["status"] == "fail"]
    trust_score = int(sum(groups[k]["score"] * TRUST_GROUP_WEIGHT for k, _ in TRUST_GROUPS))
    trust_status = "fail" if vetoed else _trust_status(trust_score)
    trust = {
        "score": trust_score,
        "grade": _grade(trust_score),
        "status": trust_status,
        "status_label": ("失败 · 一票否决" if vetoed else {"pass": "可信", "warn": "需关注", "fail": "不可信"}[trust_status]),
        "veto": {"triggered": bool(vetoed), "items": vetoed},
        "vetoes": vetoes,
        "weights": {k: TRUST_GROUP_WEIGHT for k, _ in TRUST_GROUPS},
        "formula": "四项等权平均; 一票否决项任一失败则直接判失败, 否决项不参与平均",
        "veto_rules": [dict(r) for r in VETO_RULES],
        "status_rules": {"pass": f"≥{TRUST_PASS_MIN}", "warn": f"{TRUST_WARN_MIN}–{TRUST_PASS_MIN - 1}",
                         "fail": f"<{TRUST_WARN_MIN}"},
    }
    compliance = {**rc, "module": "portfolio_compliance", "label": "🛡️ 组合合规"}
    for k in ("score", "grade"):
        compliance.pop(k, None)   # B 不打分

    modules = {**groups, "portfolio_compliance": compliance}
    all_checks = vetoes + [c for m in modules.values() for c in m.get("checks", [])]
    fail_count = sum(1 for c in all_checks if c.get("status") == "fail")
    warn_count = sum(1 for c in all_checks if c.get("status") == "warn")
    info_count = sum(1 for c in all_checks if c.get("status") == "info")
    return {
        "system_trust": trust,
        "portfolio_compliance": {
            "status": rc.get("compliance_status"),
            "status_label": rc.get("compliance_status_label"),
            "summary": rc.get("compliance_summary"),
            "snapshot": rc.get("snapshot"),
        },
        "modules": modules,
        "total_checks": len(all_checks),
        "pass_count": len(all_checks) - fail_count - warn_count - info_count,
        "warn_count": warn_count,
        "fail_count": fail_count,
        "info_count": info_count,
        "compliance_status": rc.get("compliance_status"),
        "audit_time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "elapsed_seconds": round(time.time() - start, 2),
        "read_only": True,
        "version": AUDIT_SCHEMA_VERSION,
    }


def save_audit_snapshot(report: dict = None, trigger: str = "manual") -> dict:
    """写入审计历史 (每日定时任务或页面"保存审计"按钮)。打开页面不写。"""
    from services import warmup_state
    if warmup_state.status()["phase"] == "warming":   # 2026-11-02: 预热期不写, 避免把"数据缺失"记成否决项
        return {"saved": False, "reason": "warming_up", "trigger": trigger}
    report = report or run_full_audit()
    from services.db import save_audit_log
    save_audit_log({**report, "trigger": trigger})
    trust = report.get("system_trust") or {}
    return {"saved": True, "audit_time": report.get("audit_time"), "trust_score": trust.get("score"),
            "trust_status": trust.get("status"), "compliance_status": report.get("compliance_status"),
            "trigger": trigger, "version": report.get("version")}


if __name__ == "__main__":
    report = run_full_audit()
    t = report["system_trust"]
    print(f"A 系统可信度: {t['score']}/100 · {t['status_label']} · 否决: {t['veto']['items'] or '无'}")
    print(f"B 组合合规: {report['portfolio_compliance']['status_label']}")
    for key, mod in report["modules"].items():
        print(f"\n  {mod['label']}: {mod.get('score', '—')}")
        for c in mod["checks"]:
            icon = {"pass": "✅", "warn": "⚠️", "info": "ℹ️"}.get(c["status"], "❌")
            print(f"    {icon} {c['name']}: {c.get('detail', '')}")
