"""
AlphaCore · 港股ERP择时引擎 V1.0
===================================
五维择时信号系统 (港股本地化):
  D1: ERP绝对值 (1/PE - 混合无风险利率)          — 权重20%  [估值]
  D2: ERP历史分位 (近5年)                         — 权重25%  [估值]
  D3: 南向资金净流入方向 (陆→港增量引擎)          — 权重30%  [流动性] ← 最关键因子
  D4: VHSI恐慌/HSI实现波动率                      — 权重15%  [风险]
  D5: 港美利差 (US10Y − CN10Y)                    — 权重10%  [跨境资金]

特殊考量:
  - 港股无风险利率 = 0.6×US10Y + 0.4×CN10Y (混合锚)
  - HSI PE 历史中位数 ≈ 10-12x (金融地产拖累)
  - HSTECH PE 历史中位数 ≈ 20-30x (科技成长)
  - 南向资金是港股的"边际定价力量"

双轨模式:
  market="HSI"    → 恒生指数 (蓝筹宽基)
  market="HSTECH" → 恒生科技指数 (成长科技)

ETF标的:
  HSI:    159920.SZ(恒生ETF) / 513090.SH(港股证券ETF)
  HSTECH: 513130.SH(恒生科技ETF) / 513180.SH(恒生科技ETF)
  红利:   159545.SZ(恒生红利低波ETF)

数据源: CNBC实时报价 + FRED API (US10Y/CN10Y)
"""

import pandas as pd
import numpy as np
import time
import os
import json
from datetime import datetime, timedelta
from typing import Optional, Dict

import logging
import threading

from config import FRED_API_KEY
from services.fred_guard import fred_get_series
CACHE_DIR = "data_lake"
os.makedirs(CACHE_DIR, exist_ok=True)
from erp_signal_enhancer import adaptive_weights, multi_timeframe_confirmation, overseas_data_quality
import erp_params

logger = logging.getLogger("alphacore.erp_hk")

# O1: 动态EPS估算配置 (替代MARKET_CONFIG中的硬编码eps_est)
EPS_CONFIG_HK = {
    "HSI": {"base_eps": 2300.0, "as_of_quarter": "2026Q1", "annual_growth": 0.08},
    "HSTECH": {"base_eps": 220.0, "as_of_quarter": "2026Q1", "annual_growth": 0.15},
}

def _get_dynamic_eps_hk(market: str) -> float:
    """动态EPS估算: 基准 + 季度衰减"""
    cfg = EPS_CONFIG_HK.get(market, EPS_CONFIG_HK["HSI"])
    year = int(cfg["as_of_quarter"][:4])
    quarter = int(cfg["as_of_quarter"][-1])
    base_date = datetime(year, quarter * 3, 1)
    quarters_elapsed = (datetime.now() - base_date).days / 91.25
    adjusted = cfg["base_eps"] * (1 + cfg["annual_growth"]) ** (quarters_elapsed / 4)
    if quarters_elapsed >= 3:
        logger.warning("%s EPS估算基于%s，已过期%.0f个季度", market, cfg['as_of_quarter'], quarters_elapsed)
    return round(adjusted, 1)

# FRED API
_hk_fred = None
def _get_hk_fred():
    global _hk_fred
    if _hk_fred is None:
        try:
            from fredapi import Fred
            _hk_fred = Fred(api_key=FRED_API_KEY)
        except Exception as e:
            logger.warning("FRED init failed: %s", e)
    return _hk_fred

# ===== 线程安全 + SWR 后台缓存 (V26.1: 迁移至统一 EngineCache) =====
from services.engine_cache import EngineCache
_engine_cache = EngineCache("erp_hk", max_workers=3)

def _hk_cached(key, ttl_seconds, fetcher):
    """统一缓存接口 (委托给 EngineCache)"""
    return _engine_cache.get(key, ttl_seconds, fetcher)


# ===== 南向资金持久化 =====
SOUTHBOUND_FILE = os.path.join(CACHE_DIR, "hk_southbound_flow.json")

DEFAULT_SOUTHBOUND = {
    "weekly_net_buy_billion_rmb": 15.0,
    "monthly_net_buy_billion_rmb": 60.0,
    "cumulative_12m_billion_rmb": 350.0,
    "direction": "inflow",
    "date": "2026-04-01",
    "source": "default",
}


# ===== 规则百科 =====
ENCYCLOPEDIA_HK = {
    "erp_abs": {
        "title": "HK ERP (Equity Risk Premium)",
        "what": "ERP = Earnings Yield (1/PE) − 混合无风险利率(0.6×US10Y + 0.4×CN10Y)。衡量港股相对无风险资产的超额回报。",
        "why": "港股ERP天然偏高(因金融地产低PE)。HSI历史中位数ERP≈6-8%，HSTECH≈3-5%。",
        "alert": "HSI ERP<4% = 偏高估(罕见)。HSI ERP>10% = 极端恐慌底部。",
        "history": "2022年10月HSI 14800点时ERP≈12%(极度低估)，2021年2月HSI 31000时ERP≈4%(偏高)。"
    },
    "erp_pct": {
        "title": "ERP 历史分位",
        "what": "过去5年中有多少比例的交易日ERP比今天低。80%分位 → 港股极罕见低估。",
        "why": "港股波动极大，分位比绝对值更可靠。注意2022年极端行情会拉高分位的参考范围。",
        "alert": "分位>80% 是黄金坑。分位<20% 港股估值已充分定价。",
    },
    "southbound": {
        "title": "南向资金 (陆→港)",
        "what": "内地投资者通过港股通买入港股的净资金流。正数=净买入=增量资金入港。",
        "why": "南向资金占港股日成交约15-25%，是港股最大的增量资金来源。持续大额净买入=看涨信号。",
        "alert": "月净买入>200亿=强劲流入(2024年特征)。连续5日净卖出=短期风险。",
    },
    "vhsi": {
        "title": "VHSI / 恒生波动率",
        "what": "恒生波动率指数(类似VIX)。反映港股期权隐含波动率，正常区间15-25。",
        "why": "VHSI>35 = 恐慌抛售(逆向机会)。VHSI<15 = 市场自满(警惕回调)。",
        "alert": "VHSI突破40是历史级恐慌(如2022年10月)，往往对应底部区域。",
    },
    "rate_spread": {
        "title": "港美利差 (US10Y − CN10Y)",
        "what": "美国10年国债减去中国10年国债收益率。利差扩大=资金倾向流出港股回到美元资产。",
        "why": "港币挂钩美元，美债收益率上升→资金回流美国→港股承压。利差缩窄=港股估值修复动力。",
        "alert": "利差>2.5%是警戒线(2023年特征)。利差<1%=港股资金面宽松。",
    }
}


class HKERPTimingEngine:
    """港股ERP择时引擎 V1.1 · 双轨模式(HSI/HSTECH) (Phase 1: P2 EMA持久化 + P3 Sigmoid动量)"""

    VERSION = "1.1"
    REGION = "HK"

    # 五维权重
    W = {"erp_abs": 0.20, "erp_pct": 0.25, "southbound": 0.30, "vhsi": 0.15, "rate_spread": 0.10}

    # 信号映射
    SIGNAL_MAP = {
        "strong_buy":  {"label": "Strong Buy",  "label_cn": "强力买入", "position": "80-100%", "color": "#10b981", "emoji": "🟢🟢", "level": 6},
        "buy":         {"label": "Buy",          "label_cn": "买入",     "position": "60-80%",  "color": "#34d399", "emoji": "🟢",   "level": 5},
        "hold":        {"label": "Hold",         "label_cn": "标配持有", "position": "50-70%",  "color": "#3b82f6", "emoji": "🔵",   "level": 4},
        "reduce":      {"label": "Reduce",       "label_cn": "逐步减仓", "position": "30-50%",  "color": "#f59e0b", "emoji": "🟡",   "level": 3},
        "underweight": {"label": "Underweight",  "label_cn": "低配防御", "position": "10-30%",  "color": "#f97316", "emoji": "🟠",   "level": 2},
        "cash":        {"label": "Cash",         "label_cn": "清仓观望", "position": "0-10%",   "color": "#ef4444", "emoji": "🔴",   "level": 1},
    }

    # 市场配置
    MARKET_CONFIG = {
        "HSI": {
            "ticker": "^HSI",
            "name": "恒生指数",
            "pe_fallback": 10.5,
            "pe_range": (6, 25),
            "erp_thresholds": {"extreme_low": 10.0, "low": 8.0, "mid_low": 6.0, "mid": 4.0, "high": 3.0},
            "eps_est": 2200.0,  # HSI近似EPS (2025-26年)
            "etf_targets": {
                "aggressive": {"name": "恒生ETF", "code": "159920.SZ", "desc": "HSI蓝筹宽基"},
                "balanced":   {"name": "港股证券ETF", "code": "513090.SH", "desc": "港股券商弹性"},
                "defensive":  {"name": "恒生红利低波ETF", "code": "159545.SZ", "desc": "高股息防御"},
            },
        },
        "HSTECH": {
            "ticker": "^HSTECH",
            "name": "恒生科技指数",
            "pe_fallback": 22.0,
            "pe_range": (10, 80),
            "erp_thresholds": {"extreme_low": 6.0, "low": 5.0, "mid_low": 3.5, "mid": 2.0, "high": 1.0},
            "eps_est": 200.0,  # HSTECH近似EPS
            "etf_targets": {
                "aggressive": {"name": "恒生科技ETF", "code": "513130.SH", "desc": "HSTECH核心弹性"},
                "balanced":   {"name": "恒生科技ETF华泰", "code": "513180.SH", "desc": "HSTECH备选"},
                "defensive":  {"name": "恒生红利低波ETF", "code": "159545.SZ", "desc": "高股息防御"},
            },
        },
    }

    def __init__(self, market: str = "HSI"):
        assert market in self.MARKET_CONFIG, f"Invalid market: {market}"
        self.market = market
        self.cfg = self.MARKET_CONFIG[market]
        self._southbound = self._load_southbound()
        # P2: 从磁盘恢复 EMA 状态 (消除重启跳变)
        ema_hist = self._load_ema_history()
        self._prev_smooth_score = ema_hist.get("prev_smooth_score")

    def _load_ema_history(self) -> dict:
        """P2: 从 JSON 加载 EMA 状态"""
        filepath = os.path.join(CACHE_DIR, f"erp_hk_{self.market.lower()}_daily_history.json")
        if os.path.exists(filepath):
            try:
                with open(filepath, "r", encoding="utf-8") as f:
                    return json.load(f)
            except Exception:
                pass
        return {}

    def _save_ema_history(self, composite: float):
        """P2: 持久化 EMA 状态到 JSON (线程安全原子写入)"""
        filepath = os.path.join(CACHE_DIR, f"erp_hk_{self.market.lower()}_daily_history.json")
        data = {
            "prev_smooth_score": self._prev_smooth_score,
            "last_score": composite,
            "last_date": str(datetime.now().date()),
        }
        tid = threading.get_ident()
        tmp_path = f"{filepath}.{tid}.tmp"
        try:
            with open(tmp_path, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False)
            os.replace(tmp_path, filepath)
        except Exception as e:
            logger.warning("保存状态失败 (%s): %s", self.market, e)
            if os.path.exists(tmp_path):
                try:
                    os.remove(tmp_path)
                except OSError:
                    pass

    # ========== 南向资金管理 ==========

    def _fetch_southbound_tushare(self) -> Optional[Dict]:
        """Tushare moneyflow_hsgt 自动拉取南向资金 (T+1盘后数据)

        2026-10-23: 改用 services.southbound_flow 统一源 (与 aiae_hk_engine 同口径),
        自动识别累计/当日语义与百万/亿单位, 12M 窗口改为真实 ~245 个交易日
        (原实现 limit=40 只覆盖约 2 个月, 却标注为 cumulative_12m)。
        """
        try:
            from services.southbound_flow import fetch_southbound_flow
            result = fetch_southbound_flow()
            if not result:
                return None
            with open(SOUTHBOUND_FILE, 'w', encoding='utf-8') as f:
                json.dump(result, f, ensure_ascii=False, indent=2)
            logger.info("南向资金(Tushare自动): weekly=%+.1f亿, monthly=%+.1f亿 (%s)",
                        result["weekly_net_buy_billion_rmb"], result["monthly_net_buy_billion_rmb"], result["date"])
            return result
        except Exception as e:
            logger.warning("Tushare南向拉取失败: %s", e)
            return None

    def _load_southbound(self) -> Dict:
        """三级南向资金加载: Tushare自动 → JSON缓存 → 默认值"""
        
        # Tier 1: Tushare 自动拉取 (TTL 6小时, 避免频繁调用)
        cache_fresh = False
        if os.path.exists(SOUTHBOUND_FILE):
            try:
                mtime = os.path.getmtime(SOUTHBOUND_FILE)
                cache_age_hours = (time.time() - mtime) / 3600
                cache_fresh = cache_age_hours < 6  # 6小时内视为新鲜
            except Exception:
                pass
        
        if not cache_fresh:
            tushare_data = self._fetch_southbound_tushare()
            if tushare_data:
                return tushare_data
        
        # Tier 2: JSON 缓存 (手动更新或上次Tushare拉取的)
        if os.path.exists(SOUTHBOUND_FILE):
            try:
                with open(SOUTHBOUND_FILE, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                src = data.get('source', 'unknown')
                logger.info("南向资金(缓存/%s): weekly=%.1f亿", src, data.get('weekly_net_buy_billion_rmb', 0))
                return data
            except Exception:
                pass
        
        # Tier 3: 默认值
        logger.warning("南向资金: 使用默认值")
        return DEFAULT_SOUTHBOUND.copy()

    def update_southbound(self, weekly_net: float, monthly_net: float = None, cumulative_12m: float = None):
        """手动更新南向资金数据"""
        data = self._southbound.copy()
        data["weekly_net_buy_billion_rmb"] = round(weekly_net, 1)
        if monthly_net is not None:
            data["monthly_net_buy_billion_rmb"] = round(monthly_net, 1)
        if cumulative_12m is not None:
            data["cumulative_12m_billion_rmb"] = round(cumulative_12m, 1)
        data["direction"] = "inflow" if weekly_net > 0 else "outflow"
        data["date"] = datetime.now().strftime("%Y-%m-%d")
        data["source"] = "manual"
        with open(SOUTHBOUND_FILE, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        self._southbound = data
        logger.info("南向资金更新: weekly=%.1fB", weekly_net)

    # ========== 数据获取层 ==========

    def _get_current_pe(self) -> float:
        """三级PE获取: CNBC实时价格+EPS估算 → 磁盘缓存 → 硬编码"""
        pe_cache_file = os.path.join(CACHE_DIR, f"erp_hk_{self.market.lower()}_pe.json")

        # Tier 1: CNBC 实时价格 → PE = Price / EPS_est
        try:
            cnbc_sym = ".HSI" if self.market == "HSI" else ".HSTECH"
            cnbc_url = f"https://quote.cnbc.com/quote-html-webservice/restQuote/symbolType/symbol?symbols={cnbc_sym}&requestMethod=itv&noCache=1&partnerId=2&fund=1&exthrs=1&output=json&events=1"
            r = __import__('requests').get(cnbc_url, timeout=10, headers={'User-Agent': 'Mozilla/5.0'})
            quote = r.json().get('FormattedQuoteResult', {}).get('FormattedQuote', [{}])[0]
            price_str = quote.get('last', '0').replace(',', '')
            price = float(price_str)
            if price > 1000:
                pe = price / _get_dynamic_eps_hk(self.market)  # O1: 动态EPS
                pe_min, pe_max = self.cfg["pe_range"]
                pe = max(pe_min, min(pe_max, pe))
                with open(pe_cache_file, "w") as f:
                    json.dump({"pe": round(pe, 2), "price": price, "source": f"cnbc/{cnbc_sym}", "ts": datetime.now().isoformat()}, f)
                logger.info("%s PE from CNBC: %.1fx (price=%.0f)", self.market, pe, price)
                return float(pe)
        except Exception as e:
            logger.warning("CNBC PE failed: %s", e)

        # Tier 2: 磁盘缓存
        if os.path.exists(pe_cache_file):
            try:
                with open(pe_cache_file, "r") as f:
                    cached = json.load(f)
                cached_ts = datetime.fromisoformat(cached["ts"])
                if (datetime.now() - cached_ts).days < 7:
                    pe = cached["pe"]
                    logger.info("%s PE from cache: %.1fx", self.market, pe)
                    return float(pe)
            except Exception:
                pass

        # Tier 3: 硬编码兜底
        logger.warning("%s PE fallback: %sx", self.market, self.cfg['pe_fallback'])
        return self.cfg["pe_fallback"]

    def _fetch_price_history(self, years: int = 5) -> pd.DataFrame:
        """港股指数价格历史 (CNBC实时 + 磁盘缓存 + Bootstrap合成)"""
        def _fetch():
            cache_file = os.path.join(CACHE_DIR, f"erp_hk_{self.market.lower()}_history.parquet")

            # Tier 1: 磁盘缓存 (parquet)
            if os.path.exists(cache_file):
                try:
                    cached_df = pd.read_parquet(cache_file)
                    cache_age_days = (datetime.now() - pd.Timestamp(cached_df['trade_date'].iloc[-1])).days
                    if cache_age_days < 3:  # 3天内直接用缓存
                        logger.info("%s: using disk cache (%d rows, %dd old)", self.market, len(cached_df), cache_age_days)
                        return cached_df
                except Exception:
                    pass

            # Tier 2: CNBC 实时价格 + Bootstrap 合成历史
            try:
                cnbc_sym = ".HSI" if self.market == "HSI" else ".HSTECH"
                cnbc_url = f"https://quote.cnbc.com/quote-html-webservice/restQuote/symbolType/symbol?symbols={cnbc_sym}&requestMethod=itv&noCache=1&partnerId=2&fund=1&exthrs=1&output=json&events=1"
                r = __import__('requests').get(cnbc_url, timeout=10, headers={'User-Agent': 'Mozilla/5.0'})
                quote = r.json().get('FormattedQuoteResult', {}).get('FormattedQuote', [{}])[0]
                price_str = quote.get('last', '0').replace(',', '')
                cnbc_price = float(price_str)
                if cnbc_price > 1000:
                    logger.info("%s: CNBC price=%.0f, generating synthetic history", self.market, cnbc_price)
                    n_days = years * 252
                    dates = pd.bdate_range(end=datetime.now(), periods=n_days)
                    daily_vol = 0.015 if self.market == "HSI" else 0.020
                    daily_drift = 0.03 / 252
                    np.random.seed(42)
                    prices = [cnbc_price]
                    for _ in range(n_days - 1):
                        ret = daily_drift + daily_vol * np.random.randn()
                        prices.append(max(prices[-1] / (1 + ret), 1000))
                    prices.reverse()
                    current_pe = self._get_current_pe()
                    current_eps = cnbc_price / current_pe
                    eps_growth = 0.08 if self.market == "HSI" else 0.15
                    end_dt = datetime.now()
                    eps_list = [current_eps / ((1 + eps_growth) ** ((end_dt - d).days / 30 / 12)) for d in dates]
                    df = pd.DataFrame({"trade_date": dates, "close": prices, "eps": eps_list})
                    df["pe_ttm"] = (df["close"] / df["eps"]).clip(*self.cfg["pe_range"])
                    df.to_parquet(cache_file)
                    logger.info("%s: bootstrapped %d rows from CNBC, PE≈%.1f", self.market, n_days, current_pe)
                    return df
            except Exception as e:
                logger.warning("CNBC bootstrap failed: %s", e)

            # Tier 3: 旧磁盘缓存 (任意年龄)
            if os.path.exists(cache_file):
                logger.warning("%s: using stale disk cache", self.market)
                return pd.read_parquet(cache_file)

            raise ValueError(f"{self.market} data unavailable")
        return _hk_cached(f"hk_{self.market.lower()}_price", 4 * 3600, _fetch)

    def _fetch_us10y_history(self, years: int = 5) -> pd.DataFrame:
        """US 10Y Treasury (复用FRED DGS10)"""
        def _fetch():
            cache_file = os.path.join(CACHE_DIR, "erp_hk_us10y.parquet")
            fred = _get_hk_fred()
            if fred:
                try:
                    start_dt = datetime.now() - timedelta(days=years * 365)
                    series = fred_get_series(
                        "DGS10",
                        lambda: fred.get_series("DGS10", observation_start=start_dt),
                        start=start_dt,
                    )
                    if series is not None and not series.empty:
                        series = series.dropna()
                        df = pd.DataFrame({
                            "trade_date": series.index.tz_localize(None) if series.index.tz else series.index,
                            "us10y": series.values,
                        })
                        df.to_parquet(cache_file)
                        logger.info("US10Y: %d rows, latest=%.2f%%", len(df), df['us10y'].iloc[-1])
                        return df
                except Exception as e:
                    logger.warning("FRED DGS10 error: %s", e)
            if os.path.exists(cache_file):
                logger.info("US10Y: using disk cache")
                return pd.read_parquet(cache_file)
            # Fallback: try US ERP engine's or Rates engine's cache
            for alt_file in [os.path.join(CACHE_DIR, "erp_us_treasury_10y.parquet"),
                             os.path.join(CACHE_DIR, "rates_dgs10.parquet")]:
                if os.path.exists(alt_file):
                    try:
                        alt_df = pd.read_parquet(alt_file)
                        # Normalize column name to 'us10y'
                        for col in alt_df.columns:
                            if col != 'trade_date' and col != 'us10y':
                                alt_df = alt_df.rename(columns={col: 'us10y'})
                                break
                        if 'us10y' in alt_df.columns and 'trade_date' in alt_df.columns:
                            logger.info("US10Y: fallback to %s", os.path.basename(alt_file))
                            return alt_df[['trade_date', 'us10y']]
                    except Exception:
                        pass
            # Last resort: generate synthetic constant series
            logger.warning("US10Y: all sources failed, using 4.3%% constant")
            dates = pd.date_range(end=datetime.now(), periods=years * 252, freq="B")
            df = pd.DataFrame({"trade_date": dates, "us10y": np.full(len(dates), 4.3)})
            return df
        return _hk_cached("hk_us10y", 4 * 3600, _fetch)

    def _fetch_cn10y_history(self, years: int = 5) -> pd.DataFrame:
        """CN 10Y 数据源优先级 (P1审计修正):
        Tier 0: Tushare CN10Y (最准确, 直接获取中国10年期国债)
        Tier 1: CNBC 实时中国10Y国债 (次优, 实时但单点)
        Tier 2: FRED INTDSRCNM193N (央行贴现率 ≈ 2.9%, 非真实CN10Y!)
        Tier 3: 磁盘缓存
        Tier 4: 硬编码 1.70%

        ⚠️ 审计发现: FRED INTDSRCNM193N ≈ 2.91% 而真实CN10Y ≈ 1.70%,
           偏差 1.21% 导致 blended_rf 被高估 0.48%, HK ERP 被系统性低估。
        """
        def _fetch():
            cache_file = os.path.join(CACHE_DIR, "erp_hk_cn10y.parquet")

            # Tier 0: AKShare 中债 (免费, 权威, 中国债券信息网直接源)
            try:
                from services.chinabond_yield import get_yield_10y_latest
                cn10y_val, cn10y_date = get_yield_10y_latest()
                if 0.5 < cn10y_val < 8.0:
                    logger.info("CN10Y from ChinaBond (AKShare): %.4f%% (%s)", cn10y_val, cn10y_date)
                    dates = pd.date_range(end=datetime.now(), periods=years * 252, freq="B")
                    df = pd.DataFrame({"trade_date": dates, "cn10y": np.full(len(dates), cn10y_val)})
                    df.to_parquet(cache_file)
                    return df
            except Exception as e:
                logger.info("ChinaBond CN10Y 异常, 降级到 Tushare: %s", e)

            # Tier 1: Tushare 直接获取中国10年期国债收益率 (需 yc_cb 权限)
            try:
                from config import TUSHARE_TOKEN
                import tushare as _ts
                _ts.set_token(TUSHARE_TOKEN)
                pro = _ts.pro_api()
                end_date = datetime.now().strftime('%Y%m%d')
                start_date = (datetime.now() - timedelta(days=30)).strftime('%Y%m%d')
                df_yc = pro.yc_cb(ts_code='1001.CB', curve_type='0',
                                  start_date=start_date, end_date=end_date)
                if df_yc is not None and not df_yc.empty:
                    # 筛选10年期
                    df_10y = df_yc[df_yc['curve_term'] == 10.0]
                    if not df_10y.empty:
                        cn10y_val = float(df_10y.iloc[0]['yield'])
                        if 0.5 < cn10y_val < 8.0:
                            logger.info("CN10Y from Tushare: %.2f%%", cn10y_val)
                            dates = pd.date_range(end=datetime.now(), periods=years * 252, freq="B")
                            df = pd.DataFrame({"trade_date": dates, "cn10y": np.full(len(dates), cn10y_val)})
                            df.to_parquet(cache_file)
                            return df
            except Exception as e:
                # P0-YC: 权限不足时降为 INFO，不再产生 WARNING 噪音
                msg = str(e)
                if "没有接口" in msg or "访问权限" in msg:
                    logger.info("Tushare CN10Y: yc_cb 权限不足，降级到 CNBC/FRED 通道")
                else:
                    logger.warning("Tushare CN10Y error: %s", e)

            # Tier 2: CNBC 实时中国10Y国债 (准确, 实时)
            try:
                import requests, re
                url = "https://www.cnbc.com/quotes/CN10Y-CN"
                r = requests.get(url, timeout=8, headers={'User-Agent': 'Mozilla/5.0'})
                if r.status_code == 200:
                    match = re.search(r'"last":"([\d.]+)"', r.text)
                    if match:
                        cn10y_val = float(match.group(1))
                        if 0.5 < cn10y_val < 8.0:
                            logger.info("CN10Y from CNBC: %.2f%% (Tier 1)", cn10y_val)
                            dates = pd.date_range(end=datetime.now(), periods=years * 252, freq="B")
                            df = pd.DataFrame({"trade_date": dates, "cn10y": np.full(len(dates), cn10y_val)})
                            df.to_parquet(cache_file)
                            return df
            except Exception as e:
                logger.warning("CNBC CN10Y error: %s", e)

            # Tier 3: FRED INTDSRCNM193N (央行贴现率, ⚠️ 非真实CN10Y, 偏高~1.2%)
            fred = _get_hk_fred()
            if fred:
                try:
                    start_dt = datetime.now() - timedelta(days=years * 365)
                    series = fred_get_series(
                        "INTDSRCNM193N",
                        lambda: fred.get_series("INTDSRCNM193N", observation_start=start_dt),
                        start=start_dt,
                    )
                    if series is not None and not series.empty:
                        df = pd.DataFrame({
                            "trade_date": series.index.tz_localize(None) if series.index.tz else series.index,
                            "cn10y": series.values,
                        })
                        df = df.dropna()
                        df = df.set_index("trade_date").resample("D").ffill().reset_index()
                        # ⚠️ 审计修正: 贴现率 → CN10Y估算 (下调1.0%近似真实CN10Y)
                        df["cn10y"] = (df["cn10y"] - 1.0).clip(lower=0.5)
                        df.to_parquet(cache_file)
                        logger.info("CN10Y proxy (INTDSRCNM193N-1.0%%): %d rows, adjusted=%.2f%%", len(df), df['cn10y'].iloc[-1])
                        return df
                except Exception as e:
                    logger.warning("FRED INTDSRCNM193N error: %s", e)

            # Tier 4: 磁盘缓存 (任何年龄)
            if os.path.exists(cache_file):
                logger.info("CN10Y: using disk cache")
                return pd.read_parquet(cache_file)

            # Tier 5: 硬编码 (更新为当前市场水平)
            logger.warning("CN10Y fallback: 1.70%%")
            dates = pd.date_range(end=datetime.now(), periods=years * 252, freq="B")
            df = pd.DataFrame({"trade_date": dates, "cn10y": np.full(len(dates), 1.70)})
            df.to_parquet(cache_file)
            return df
        return _hk_cached("hk_cn10y", 4 * 3600, _fetch)

    def _fetch_hsi_volatility(self) -> Dict:
        """HSI 实现波动率 (60日滚动)"""
        try:
            price_df = self._fetch_price_history()
            if len(price_df) < 60:
                return {"current": 20.0, "pct": 50, "regime": "normal"}
            returns = price_df["close"].pct_change().dropna()
            vol_60d = float(returns.rolling(60).std().iloc[-1] * np.sqrt(252) * 100)
            vol_series = returns.rolling(60).std().dropna() * np.sqrt(252) * 100
            vol_pct = float((vol_series < vol_60d).mean() * 100)

            if vol_pct >= 90:
                regime = "extreme_panic"
            elif vol_pct >= 70:
                regime = "high"
            elif vol_pct >= 30:
                regime = "normal"
            else:
                regime = "calm"

            return {"current": round(vol_60d, 1), "pct": round(vol_pct, 1), "regime": regime}
        except Exception as e:
            logger.warning("volatility calc error: %s", e)
            return {"current": 22.0, "pct": 50, "regime": "normal"}

    # ========== 核心计算层 ==========

    def _fetch_dfii10_series(self) -> Optional[pd.Series]:
        """美国 10Y 实际利率日度序列 (2003 起)。与美股引擎共用 fred_guard 缓存键 DFII10_FROM2003。"""
        def _fetch():
            fred = _get_hk_fred()
            if not fred:
                return None
            try:
                s = fred_get_series(
                    "DFII10_FROM2003",
                    lambda: fred.get_series("DFII10", observation_start=datetime(2003, 1, 1)),
                    disk_ttl_hours=12,
                    start=datetime(2003, 1, 1),
                )
                if s is not None and not s.dropna().empty:
                    return s.dropna()
            except Exception as e:
                logger.warning("FRED DFII10 error: %s", e)
            return None
        return _hk_cached("hk_dfii10_series", 6 * 3600, _fetch)

    def _fetch_dfii10_latest(self) -> Optional[float]:
        """美国 10Y 实际利率最新值。"""
        s = self._fetch_dfii10_series()
        return float(s.iloc[-1]) if s is not None and len(s) else None

    def _valuation_real(self, pe_estimated: Optional[float]) -> Optional[dict]:
        """P4: 港股 ERP 读数 (engines/hk_valuation.py)。失败返回 None, 不影响主流程。"""
        try:
            from engines import hk_valuation
            return hk_valuation.compute(self.market, self._fetch_dfii10_latest(), pe_estimated)
        except Exception as e:
            logger.warning("HK ERP real failed: %s", e)
            return None

    def _compute_erp_series(self) -> pd.DataFrame:
        """计算港股ERP时间序列 (混合无风险利率锚)"""
        price_df = self._fetch_price_history()
        us10y_df = self._fetch_us10y_history()
        cn10y_df = self._fetch_cn10y_history()

        # Normalize trade_date to date-only (midnight) to prevent merge mismatch
        for df in [price_df, us10y_df, cn10y_df]:
            df["trade_date"] = pd.to_datetime(df["trade_date"]).dt.normalize()

        # 合并
        merged = pd.merge(price_df, us10y_df, on="trade_date", how="left")
        merged = pd.merge(merged, cn10y_df, on="trade_date", how="left")
        merged = merged.sort_values("trade_date")
        merged["us10y"] = merged["us10y"].ffill().bfill()
        merged["cn10y"] = merged["cn10y"].ffill().bfill()
        merged = merged.dropna(subset=["pe_ttm", "us10y", "cn10y"])
        merged = merged[merged["pe_ttm"] > 0].copy()

        # 混合无风险利率: 0.6×US10Y + 0.4×CN10Y
        merged["blended_rf"] = 0.6 * merged["us10y"] + 0.4 * merged["cn10y"]
        merged["earnings_yield"] = 1.0 / merged["pe_ttm"] * 100
        merged["erp"] = merged["earnings_yield"] - merged["blended_rf"]
        return merged.sort_values("trade_date").reset_index(drop=True)

    # ========== 五维评分 ==========

    def _score_d1_erp_absolute(self, erp_val: float) -> tuple:
        """D1: ERP绝对值 (港股阈值: HSI偏高, HSTECH偏低)"""
        t = self.cfg["erp_thresholds"]
        if erp_val >= t["extreme_low"]:
            score, desc = 100, f"ERP {erp_val:.2f}% ≥ {t['extreme_low']}% → 极度低估，历史级机会"
        elif erp_val >= t["low"]:
            score = 75 + (erp_val - t["low"]) / (t["extreme_low"] - t["low"]) * 25
            desc = f"ERP {erp_val:.2f}% {t['low']}-{t['extreme_low']}%区间 → 显著低估"
        elif erp_val >= t["mid_low"]:
            score = 55 + (erp_val - t["mid_low"]) / (t["low"] - t["mid_low"]) * 20
            desc = f"ERP {erp_val:.2f}% {t['mid_low']}-{t['low']}%区间 → 合理偏低"
        elif erp_val >= t["mid"]:
            score = 35 + (erp_val - t["mid"]) / (t["mid_low"] - t["mid"]) * 20
            desc = f"ERP {erp_val:.2f}% {t['mid']}-{t['mid_low']}%区间 → 估值中性"
        elif erp_val >= t["high"]:
            score = 15 + (erp_val - t["high"]) / (t["mid"] - t["high"]) * 20
            desc = f"ERP {erp_val:.2f}% {t['high']}-{t['mid']}%区间 → 偏高估"
        else:
            score = max(0, erp_val * 5)
            desc = f"ERP {erp_val:.2f}% < {t['high']}% → 高估"
        return round(min(100, max(0, score)), 1), desc

    def _score_d2_erp_percentile(self, erp_val: float, erp_series: pd.Series) -> tuple:
        """D2: ERP历史分位 (O2: 滚动5年窗口)"""
        window = erp_series.tail(1260)  # O2: ~5年滚动窗口
        pct = (window < erp_val).mean() * 100
        if pct >= 80:   desc = f"近5年{pct:.1f}%分位 → 历史极度低估"
        elif pct >= 60: desc = f"近5年{pct:.1f}%分位 → 偏低估"
        elif pct >= 40: desc = f"近5年{pct:.1f}%分位 → 估值中性"
        elif pct >= 20: desc = f"近5年{pct:.1f}%分位 → 偏高估"
        else:           desc = f"近5年{pct:.1f}%分位 → 历史极度高估"
        return round(pct, 1), round(pct, 1), desc

    def _score_d3_southbound(self) -> tuple:
        """D3: 南向资金流 (陆→港增量引擎) — O4: 带数据新鲜度守卫"""
        sb = self._southbound
        weekly = sb.get("weekly_net_buy_billion_rmb", 0)
        monthly = sb.get("monthly_net_buy_billion_rmb", 0)
        cumulative = sb.get("cumulative_12m_billion_rmb", 0)

        # O4: 数据新鲜度检测
        data_date = sb.get("date", "2020-01-01")
        try:
            days_old = (datetime.now() - datetime.strptime(data_date, "%Y-%m-%d")).days
        except Exception:
            days_old = 999

        sb_info = {
            "weekly": round(weekly, 1),
            "monthly": round(monthly, 1),
            "cumulative_12m": round(cumulative, 1),
            "direction": sb.get("direction", "unknown"),
            "date": sb.get("date", "unknown"),
            "stale": days_old > 7,  # O4: 标记过期
            "days_old": days_old,
        }

        # O4: 数据超过7天→降级为中性分数，避免使用过期数据误导
        if days_old > 7:
            score = 50
            desc = f"⚠️ 南向数据已过期{days_old}天 → 采用中性估值"
            return round(score, 1), sb_info, desc

        # 正常评分逻辑
        if weekly > 50:
            score = 95
            desc = f"南向周净买{weekly:.0f}亿 → 极强流入, 资金加速入港"
        elif weekly > 20:
            score = 80
            desc = f"南向周净买{weekly:.0f}亿 → 持续流入"
        elif weekly > 5:
            score = 65
            desc = f"南向周净买{weekly:.0f}亿 → 温和流入"
        elif weekly > -5:
            score = 50
            desc = f"南向周净买{weekly:.0f}亿 → 资金中性"
        elif weekly > -20:
            score = 30
            desc = f"南向周净卖{abs(weekly):.0f}亿 → 资金流出"
        else:
            score = 10
            desc = f"南向周净卖{abs(weekly):.0f}亿 → 大幅撤退!"

        # 月度趋势加分
        if monthly > 100:
            score = min(100, score + 10)
            desc += " (月度强劲)"
        elif monthly < -50:
            score = max(0, score - 10)
            desc += " (月度恶化)"

        return round(min(100, max(0, score)), 1), sb_info, desc

    def _score_d4_vhsi(self) -> tuple:
        """D4: VHSI/恒生波动率"""
        vol_info = self._fetch_hsi_volatility()
        vol = vol_info["current"]
        vol_pct = vol_info["pct"]
        regime = vol_info["regime"]

        if vol >= 40:
            score = 10
            desc = f"港股波动率{vol:.1f}% → 极端恐慌! 逆向窗口"
        elif vol >= 30:
            score = 25
            desc = f"港股波动率{vol:.1f}% → 高恐慌"
        elif vol >= 25:
            score = 40
            desc = f"港股波动率{vol:.1f}% → 偏高"
        elif vol >= 18:
            score = 75
            desc = f"港股波动率{vol:.1f}% → 正常区间"
        elif vol >= 14:
            score = 85
            desc = f"港股波动率{vol:.1f}% → 低波动, 适合配置"
        else:
            score = 50
            desc = f"港股波动率{vol:.1f}% → 极低, 市场自满"

        return round(score, 1), vol_info, desc

    def _score_d5_rate_spread(self) -> tuple:
        """D5: 港美利差 (US10Y − CN10Y)"""
        try:
            us10y_df = self._fetch_us10y_history()
            cn10y_df = self._fetch_cn10y_history()
            us10y = float(us10y_df["us10y"].iloc[-1])
            cn10y = float(cn10y_df["cn10y"].iloc[-1])
        except Exception:
            us10y, cn10y = 4.3, 2.3

        spread = us10y - cn10y
        us10y_3m = float(us10y_df["us10y"].iloc[-63]) if len(us10y_df) >= 63 else us10y
        cn10y_3m = float(cn10y_df["cn10y"].iloc[-63]) if len(cn10y_df) >= 63 else cn10y
        spread_3m = us10y_3m - cn10y_3m
        trend = "narrowing" if spread < spread_3m else "widening"

        spread_info = {
            "us10y": round(us10y, 2),
            "cn10y": round(cn10y, 2),
            "spread": round(spread, 2),
            "spread_3m_ago": round(spread_3m, 2),
            "trend": trend,
        }

        # 利差缩窄 = 利好港股 → 高分
        if spread < 0.5:
            score = 90
            desc = f"港美利差仅{spread:.1f}% → 极利好港股"
        elif spread < 1.0:
            score = 75
            desc = f"港美利差{spread:.1f}% → 资金面宽松"
        elif spread < 1.5:
            score = 60
            desc = f"港美利差{spread:.1f}% → 中性"
        elif spread < 2.5:
            score = 35
            desc = f"港美利差{spread:.1f}% → 偏紧, 资金外流压力"
        else:
            score = 15
            desc = f"港美利差{spread:.1f}% → 极紧! 资金大幅回流美元"

        if trend == "narrowing":
            score = min(100, score + 8)
            desc += " (利差收窄中)"
        elif trend == "widening":
            score = max(0, score - 8)
            desc += " (利差走阔中)"

        return round(min(100, max(0, score)), 1), spread_info, desc

    # ========== 买卖规则引擎 ==========

    # O7: ERP动量修正 — P3: Sigmoid 连续映射
    def _erp_momentum_modifier(self, erp_series) -> tuple:
        if len(erp_series) < 63:
            return 0, "数据不足"
        current = float(erp_series.iloc[-1])
        past = float(erp_series.iloc[-63])
        if abs(past) < 0.01:
            return 0, "基准值过小"
        momentum_pct = (current - past) / abs(past) * 100
        import math
        scale = erp_params.O7_MOMENTUM_SCALE
        k = erp_params.O7_MOMENTUM_K
        x = max(-30, min(30, momentum_pct))
        mod = scale * (2.0 / (1.0 + math.exp(-k * x)) - 1.0)
        mod = round(mod, 1)
        if mod > 0:
            desc = f"ERP 3月动量+{momentum_pct:.0f}% → 价值回归({mod:+.1f})"
        elif mod < 0:
            desc = f"ERP 3月动量{momentum_pct:.0f}% → 估值恶化({mod:+.1f})"
        else:
            desc = f"ERP 3月动量{momentum_pct:+.0f}% → 中性"
        return mod, desc

    # O8: EMA平滑 — P2: α参数中心读取, 状态持久化
    def _smooth_composite(self, raw_score: float) -> float:
        if self._prev_smooth_score is None:
            self._prev_smooth_score = raw_score
            return raw_score
        alpha = erp_params.O8_EMA_ALPHA
        smooth = alpha * raw_score + (1 - alpha) * self._prev_smooth_score
        self._prev_smooth_score = smooth
        return round(smooth, 1)

    def _generate_trade_rules(self, score, dims, snap) -> dict:
        erp = snap.get("erp_value", 5.0)
        vol_info = dims.get("vhsi", {}).get("vol_info", {})
        vol_regime = vol_info.get("regime", "normal")
        sb_info = dims.get("southbound", {}).get("sb_info", {})
        spread_info = dims.get("rate_spread", {}).get("spread_info", {})

        d1s = dims.get("erp_abs", {}).get("score", 50)
        d2s = dims.get("erp_pct", {}).get("score", 50)
        d3s = dims.get("southbound", {}).get("score", 50)

        bullish_count = sum([d1s >= 60, d2s >= 60, d3s >= 60])
        bearish_count = sum([d1s < 35, d2s < 35, d3s < 35])

        resonance = "none"
        if bullish_count >= 3: resonance = "bullish_resonance"
        elif bearish_count >= 3: resonance = "bearish_resonance"
        elif bullish_count >= 1 and bearish_count >= 1: resonance = "divergence"

        if score >= 80 and resonance == "bullish_resonance": signal_key = "strong_buy"
        elif score >= 70: signal_key = "buy"
        elif score >= 55: signal_key = "hold"
        elif score >= 40: signal_key = "reduce"
        elif score >= 25: signal_key = "underweight"
        else: signal_key = "cash"

        # 逆向修正: 波动极端+低估
        t = self.cfg["erp_thresholds"]
        if vol_regime == "extreme_panic" and erp >= t["mid_low"]:
            if signal_key in ("hold", "reduce"): signal_key = "buy"

        signal = self.SIGNAL_MAP[signal_key]
        etf_targets = self.cfg["etf_targets"]

        if signal_key in ("strong_buy", "buy"):
            etf_advice = [
                {"etf": etf_targets["aggressive"], "ratio": "50%", "reason": "核心配置"},
                {"etf": etf_targets["balanced"],   "ratio": "30%", "reason": "弹性进攻"},
                {"etf": etf_targets["defensive"],  "ratio": "20%", "reason": "安全垫"},
            ]
        elif signal_key == "hold":
            etf_advice = [
                {"etf": etf_targets["aggressive"], "ratio": "35%", "reason": "核心底仓"},
                {"etf": etf_targets["defensive"],  "ratio": "40%", "reason": "防御为主"},
                {"etf": etf_targets["balanced"],   "ratio": "25%", "reason": "保留弹性"},
            ]
        else:
            etf_advice = [
                {"etf": etf_targets["defensive"],  "ratio": "60%", "reason": "防御优先"},
                {"etf": etf_targets["aggressive"], "ratio": "25%", "reason": "保留底仓"},
                {"etf": etf_targets["balanced"],   "ratio": "15%", "reason": "观察仓"},
            ]

        weekly_sb = sb_info.get("weekly", 0)
        take_profit = [
            {"trigger": f"ERP 回落至 {t['mid']}% 以下", "action": "减仓30%", "type": "valuation",
             "triggered": bool(erp < t["mid"]), "current": f"ERP={erp:.2f}%"},
            {"trigger": "南向资金连续5日净卖出", "action": "减仓20%", "type": "southbound",
             "triggered": bool(weekly_sb < -10), "current": f"周净买={weekly_sb:.0f}亿"},
            {"trigger": f"综合得分跌破 45", "action": "降至标配", "type": "score_drop",
             "triggered": bool(score < 45), "current": f"得分={score:.0f}"},
        ]

        stop_loss = [
            {"trigger": f"ERP ≥ {t['extreme_low']}% (极端低估)", "action": "逆向加仓20%", "type": "contrarian_buy", "color": "#10b981",
             "triggered": bool(erp >= t["extreme_low"]), "current": f"ERP={erp:.2f}%"},
            {"trigger": "波动率90%分位+低估", "action": "恐慌+低估=加仓", "type": "contrarian_vol", "color": "#10b981",
             "triggered": bool(vol_info.get("pct", 50) >= 90 and erp > t["mid_low"]), "current": f"波动={vol_info.get('pct', 50):.0f}%"},
            {"trigger": f"ERP < {t['high']}% (高估)", "action": "硬止损: 清仓", "type": "hard_stop", "color": "#ef4444",
             "triggered": bool(erp < t["high"]), "current": f"ERP={erp:.2f}%"},
            {"trigger": "港美利差 > 3.0%", "action": "降至20%以下", "type": "rate_crisis", "color": "#ef4444",
             "triggered": bool(spread_info.get("spread", 2.0) > 3.0), "current": f"利差={spread_info.get('spread', 2.0):.1f}%"},
        ]

        return {
            "signal_key": signal_key, "signal": signal, "resonance": resonance,
            "resonance_label": {"bullish_resonance": "🟢 三维共振看多", "bearish_resonance": "🔴 三维共振看空",
                                "divergence": "🟡 信号分歧", "none": "⚪ 中性"}[resonance],
            "etf_advice": etf_advice, "take_profit": take_profit, "stop_loss": stop_loss,
        }

    # ========== 警示系统 ==========

    def _generate_alerts(self, score, erp, pct, sb_info, vol_info, spread_info) -> list:
        alerts = []
        t = self.cfg["erp_thresholds"]
        weekly_sb = sb_info.get("weekly", 0)
        spread = spread_info.get("spread", 2.0)
        vol = vol_info.get("current", 20)

        if erp < t["high"]:
            alerts.append({"level": "danger", "icon": "🔴", "text": f"{self.market} ERP {erp:.2f}% < {t['high']}%, 港股高估", "pulse": True})
        if spread > 2.5:
            alerts.append({"level": "danger", "icon": "🔴", "text": f"港美利差{spread:.1f}%飙升, 资金外流压力大", "pulse": True})
        if vol >= 35:
            alerts.append({"level": "danger", "icon": "🔴", "text": f"恒生波动率{vol:.0f} 极端恐慌!", "pulse": True})
        if weekly_sb < -30:
            alerts.append({"level": "danger", "icon": "🔴", "text": f"南向资金周净卖出{abs(weekly_sb):.0f}亿, 大幅撤退", "pulse": True})

        if t["high"] <= erp < t["mid"]:
            alerts.append({"level": "warning", "icon": "🟡", "text": f"{self.market} ERP {erp:.2f}% 偏低"})
        if 2.0 < spread <= 2.5:
            alerts.append({"level": "warning", "icon": "🟡", "text": f"港美利差{spread:.1f}% 偏紧"})

        if erp >= t["low"]:
            alerts.append({"level": "opportunity", "icon": "🟢", "text": f"{self.market} ERP {erp:.2f}% ≥ {t['low']}% 显著低估!", "pulse": True})
        if pct >= 80:
            alerts.append({"level": "opportunity", "icon": "🟢", "text": f"分位{pct:.1f}% 历史级低估"})
        if weekly_sb > 50:
            alerts.append({"level": "opportunity", "icon": "🟢", "text": f"南向资金强劲流入 {weekly_sb:.0f}亿/周"})

        return alerts if alerts else [{"level": "normal", "icon": "⚪", "text": "当前无特殊警示"}]

    # ========== 诊断卡片 ==========

    def _build_diagnosis(self, erp, pe, rf, pct, sb_info, vol_info, spread_info, trade) -> list:
        cards = []
        t = self.cfg["erp_thresholds"]
        signal = trade["signal"]

        if erp >= t["mid_low"]:
            cards.append({"type": "success", "title": "估值 · 低估", "text": f"{self.market} PE {pe:.1f}x, ERP={erp:.2f}%。混合利率{rf:.2f}%。"})
        elif erp >= t["mid"]:
            cards.append({"type": "info", "title": "估值 · 中性", "text": f"PE {pe:.1f}x, ERP={erp:.2f}%。"})
        else:
            cards.append({"type": "danger", "title": "估值 · 高估", "text": f"PE {pe:.1f}x, ERP仅{erp:.2f}%。"})

        if pct >= 70:
            cards.append({"type": "success", "title": "分位 · 便宜", "text": f"ERP {pct:.0f}%分位。"})
        elif pct >= 40:
            cards.append({"type": "info", "title": "分位 · 中性", "text": f"ERP {pct:.0f}%分位。"})
        else:
            cards.append({"type": "warning", "title": "分位 · 偏贵", "text": f"ERP仅{pct:.0f}%分位。"})

        weekly_sb = sb_info.get("weekly", 0)
        if weekly_sb > 20:
            cards.append({"type": "success", "title": "南向 · 流入", "text": f"周净买{weekly_sb:.0f}亿，增量资金入港。"})
        elif weekly_sb > -5:
            cards.append({"type": "info", "title": "南向 · 中性", "text": f"周净买{weekly_sb:.0f}亿。"})
        else:
            cards.append({"type": "warning", "title": "南向 · 流出", "text": f"周净卖出{abs(weekly_sb):.0f}亿。"})

        vol = vol_info.get("current", 20)
        if vol >= 30:
            cards.append({"type": "warning", "title": "波动率 · 高", "text": f"恒生波动率{vol:.0f}%。"})
        else:
            cards.append({"type": "success", "title": "波动率 · 正常", "text": f"恒生波动率{vol:.0f}%。"})

        spread = spread_info.get("spread", 2.0)
        if spread > 2.0:
            cards.append({"type": "warning", "title": "利差 · 偏紧", "text": f"港美利差{spread:.1f}%。"})
        else:
            cards.append({"type": "success", "title": "利差 · 宽松", "text": f"港美利差{spread:.1f}%。"})

        etf_text = " / ".join([f"{e['etf']['name']}{e['ratio']}" for e in trade.get("etf_advice", [])])
        cards.append({"type": "info", "title": f"操作 · {signal['label_cn']}", "text": f"{trade['resonance_label']}。仓位{signal['position']}。配置: {etf_text}。"})

        return cards

    # ========== 信号融合 ==========

    def compute_signal(self) -> dict:
        try:
            erp_df = self._compute_erp_series()
            if erp_df.empty:
                return self._fallback_signal("ERP序列为空")

            latest = erp_df.iloc[-1]
            erp_val = float(latest["erp"])
            pe_ttm = float(latest["pe_ttm"])
            blended_rf = float(latest["blended_rf"])

            d1_score, d1_desc = self._score_d1_erp_absolute(erp_val)
            d2_score, d2_pct, d2_desc = self._score_d2_erp_percentile(erp_val, erp_df["erp"])
            d3_score, sb_info, d3_desc = self._score_d3_southbound()
            d4_score, vol_info, d4_desc = self._score_d4_vhsi()
            d5_score, spread_info, d5_desc = self._score_d5_rate_spread()

            # O10: 权重自适应
            vol_regime = vol_info.get("regime", "normal")
            # 2026-10-31 P0: 海外引擎修正器未经验证, 默认停用 (erp_params.OVERSEAS_MODIFIERS_ENABLED)
            aw = adaptive_weights(self.W, "vhsi", vol_regime) if erp_params.OVERSEAS_MODIFIERS_ENABLED else dict(self.W)

            composite = round(
                d1_score * aw["erp_abs"] + d2_score * aw["erp_pct"] +
                d3_score * aw["southbound"] + d4_score * aw["vhsi"] +
                d5_score * aw["rate_spread"], 1
            )

            # O7: ERP动量修正
            momentum_mod, momentum_desc = self._erp_momentum_modifier(erp_df["erp"])
            if erp_params.OVERSEAS_MODIFIERS_ENABLED:
                composite = round(min(100, max(0, composite + momentum_mod)), 1)

            # O11: 多时间框架确认
            mtf = multi_timeframe_confirmation(erp_df["erp"], composite)
            if erp_params.OVERSEAS_MODIFIERS_ENABLED:  # 多时框标签仍展示, 不再加减分
                composite = round(min(100, max(0, composite + mtf["confidence_mod"])), 1)

            # O8: EMA平滑
            if erp_params.OVERSEAS_MODIFIERS_ENABLED:
                composite = self._smooth_composite(composite)

            snap = {
                "pe_ttm": round(pe_ttm, 2), "blended_rf": round(blended_rf, 4),
                "earnings_yield": round(1.0 / pe_ttm * 100, 2), "erp_value": round(erp_val, 2),
                "erp_percentile": round(d2_pct, 1), "trade_date": latest["trade_date"].strftime("%Y-%m-%d"),
                "market": self.market,
            }
            snap["data_quality"] = overseas_data_quality("HK")
            # P4: 利率改为美国 10Y 实际利率 (港币挂钩美元); PE 优先用恒生指数公司公布值。不分位、不分档
            real = self._valuation_real(pe_ttm)
            snap["valuation_real"] = real
            if real:
                snap["data_quality"] = {
                    "grade": "real_data" if real["pe_source"] == "published" else "reading_only",
                    "grade_cn": real["grade_cn"],
                    "eps_source": real["pe_source"],
                    "eps_source_cn": real["pe_basis"] + (f" ({real['pe_date']})" if real["pe_date"] else ""),
                    "history_synthetic": real["pe_source"] != "published",
                    "rate_basis": real["rate_basis"], "note": real["note"], "eps_stale": real["pe_stale"],
                }

            dims = {
                "erp_abs":      {"score": d1_score, "weight": self.W["erp_abs"], "label": "ERP绝对值", "desc": d1_desc},
                "erp_pct":      {"score": d2_score, "weight": self.W["erp_pct"], "label": "ERP历史分位", "desc": d2_desc, "percentile": d2_pct},
                "southbound":   {"score": d3_score, "weight": self.W["southbound"], "label": "南向资金", "desc": d3_desc, "sb_info": sb_info},
                "vhsi":         {"score": d4_score, "weight": self.W["vhsi"], "label": "恒生波动率", "desc": d4_desc, "vol_info": vol_info},
                "rate_spread":  {"score": d5_score, "weight": self.W["rate_spread"], "label": "港美利差", "desc": d5_desc, "spread_info": spread_info},
                "erp_momentum": {"score": momentum_mod, "weight": 0, "label": "ERP动量", "desc": momentum_desc},
            }

            trade = self._generate_trade_rules(composite, dims, snap)
            alerts = self._generate_alerts(composite, erp_val, d2_pct, sb_info, vol_info, spread_info)
            diagnosis = self._build_diagnosis(erp_val, pe_ttm, blended_rf, d2_pct, sb_info, vol_info, spread_info, trade)

            # P2: 持久化 EMA 状态
            self._save_ema_history(composite)

            return {
                "status": "success", "region": "HK", "market": self.market,
                "adaptive_weights": aw,  # O10
                "multi_timeframe": mtf,  # O11
                "current_snapshot": snap, "signal": {
                    "score": composite, "key": trade["signal_key"],
                    "label": trade["signal"]["label_cn"], "position": trade["signal"]["position"],
                    "color": trade["signal"]["color"], "emoji": trade["signal"]["emoji"],
                },
                "dimensions": dims, "trade_rules": trade,
                "alerts": alerts, "diagnosis": diagnosis, "encyclopedia": ENCYCLOPEDIA_HK,
            }
        except Exception as e:
            logger.error("HK ERP compute_signal 降级 [%s]: %s", self.market, e, exc_info=True)
            return self._fallback_signal(str(e))

    def _real_erp_chart(self) -> Optional[dict]:
        """2026-11-01: 有真实月度 PE 历史 (data/hk_pe_monthly.csv) 时, 用 PE − DFII10 画月度走势, 替代合成历史。"""
        try:
            from engines import hk_valuation
            h = hk_valuation.erp_history(self.market, self._fetch_dfii10_series())
            if h is None:
                return None
            return {
                "status": "success", "basis": "real",
                "basis_note": "月度 · PE-TTM (理杏仁, 成分股总市值加权) − 美国 10Y 实际利率 (DFII10)",
                "dates": h["date"].dt.strftime("%Y-%m-%d").tolist(),
                "erp": h["erp"].round(2).tolist(),
                "pe_ttm": h["pe"].round(2).tolist(),
                "rate": h["rate"].round(2).tolist(),
                "stats": {"current": round(float(h["erp"].iloc[-1]), 2), "months": int(len(h)),
                          "start": h["date"].iloc[0].strftime("%Y-%m")},
            }
        except Exception as e:  # noqa: BLE001
            logger.warning("HK real ERP chart failed [%s]: %s", self.market, e)
            return None

    def get_erp_chart_data(self) -> dict:
        real = self._real_erp_chart()
        if real:
            return real
        try:
            erp_df = self._compute_erp_series()
            sampled = erp_df.iloc[::3].copy()
            erp_mean = float(erp_df["erp"].mean())
            erp_std = float(erp_df["erp"].std())
            return {
                "status": "success",
                "dates": sampled["trade_date"].dt.strftime("%Y-%m-%d").tolist(),
                "erp": sampled["erp"].round(2).tolist(),
                "pe_ttm": sampled["pe_ttm"].round(2).tolist(),
                "blended_rf": sampled["blended_rf"].round(2).tolist(),
                "stats": {
                    "mean": round(erp_mean, 2), "std": round(erp_std, 2),
                    "overweight_line": round(erp_mean + 0.5 * erp_std, 2),
                    "underweight_line": round(erp_mean - 0.5 * erp_std, 2),
                    "current": round(float(erp_df["erp"].iloc[-1]), 2),
                }
            }
        except Exception as e:
            return {"status": "error", "message": str(e)}

    def generate_report(self) -> dict:
        signal = self.compute_signal()
        chart = self.get_erp_chart_data()
        return {
            **signal, "chart": chart,
            "engine_version": self.VERSION, "region": self.REGION,
            "market": self.market, "updated_at": datetime.now().isoformat(),
        }

    def _fallback_signal(self, reason):
        # Fallback 降級數據 — 必須包含前端 renderRegionPanel() 所需的完整嵌套結構
        fb_pe = self.cfg["pe_fallback"]
        fb_rf = 3.5
        fb_erp = round(1.0 / fb_pe * 100 - fb_rf, 2)
        fb_vol = 22.0
        fb_sb_weekly = 0.0
        fb_spread = 2.0
        etf_targets = self.cfg["etf_targets"]

        fallback_dims = {
            "erp_abs":      {"score": 50, "weight": self.W["erp_abs"],      "label": "ERP绝对值",  "desc": f"ERP {fb_erp:.2f}% (降级推定)"},
            "erp_pct":      {"score": 50, "weight": self.W["erp_pct"],      "label": "ERP历史分位", "desc": "降级: 分位不可用", "percentile": 50.0},
            "southbound":   {"score": 50, "weight": self.W["southbound"],   "label": "南向资金",   "desc": "降级: 南向数据不可用",
                             "sb_info": {"weekly": fb_sb_weekly, "monthly": 0.0, "cumulative_12m": 0.0,
                                         "direction": "unknown", "date": "unknown", "stale": True, "days_old": 999}},
            "vhsi":         {"score": 50, "weight": self.W["vhsi"],         "label": "恒生波动率", "desc": f"波动率{fb_vol:.1f}% (降级推定)",
                             "vol_info": {"current": fb_vol, "pct": 50.0, "regime": "normal"}},
            "rate_spread":  {"score": 50, "weight": self.W["rate_spread"],  "label": "港美利差",   "desc": f"利差{fb_spread:.1f}% (降级推定)",
                             "spread_info": {"us10y": 4.3, "cn10y": 2.3, "spread": fb_spread,
                                             "spread_3m_ago": fb_spread, "trend": "unknown"}},
        }

        fallback_trade = {
            "signal_key": "hold", "signal": self.SIGNAL_MAP["hold"],
            "resonance": "none", "resonance_label": "⚪ 降级",
            "etf_advice": [
                {"etf": etf_targets["aggressive"], "ratio": "35%", "reason": "核心底仓(降级)"},
                {"etf": etf_targets["defensive"],  "ratio": "40%", "reason": "防御为主(降级)"},
                {"etf": etf_targets["balanced"],   "ratio": "25%", "reason": "保留弹性(降级)"},
            ],
            "take_profit": [
                {"trigger": "ERP 回落至估值中性以下", "action": "减仓30%", "type": "valuation",
                 "triggered": False, "current": f"ERP={fb_erp:.2f}%(降级)"},
                {"trigger": "综合得分跌破 45", "action": "降至标配", "type": "score_drop",
                 "triggered": False, "current": "得分=50(降级)"},
            ],
            "stop_loss": [
                {"trigger": "ERP 极端低估", "action": "逆向加仓20%", "type": "contrarian_buy", "color": "#10b981",
                 "triggered": False, "current": f"ERP={fb_erp:.2f}%(降级)"},
                {"trigger": "港美利差 > 3.0%", "action": "降至20%以下", "type": "rate_crisis", "color": "#ef4444",
                 "triggered": bool(fb_spread > 3.0), "current": f"利差={fb_spread:.1f}%(降级)"},
            ],
        }

        return {
            "status": "fallback", "region": "HK", "market": self.market,
            "message": f"数据异常: {reason}",
            "current_snapshot": {
                "pe_ttm": fb_pe, "blended_rf": fb_rf,
                "earnings_yield": round(1.0 / fb_pe * 100, 2),
                "erp_value": fb_erp, "erp_percentile": 50.0,
                "trade_date": datetime.now().strftime("%Y-%m-%d"),
                "market": self.market,
            },
            "signal": {"score": 50, "key": "unavailable", "label": "数据不可用", "position": "—", "color": "#64748b", "emoji": ""},
            "dimensions": fallback_dims,
            "trade_rules": fallback_trade,
            "alerts": [{"level": "warning", "icon": "🟡", "text": f"⚠️ 降级模式: {reason}"}],
            "diagnosis": [{"type": "warning", "title": "降级模式", "text": f"数据源不可用: {reason}。面板显示推定值，不代表实时市场状态。"}],
            "encyclopedia": ENCYCLOPEDIA_HK,
        }


# ===== 引擎工厂 =====
_hk_engines = {}

def get_hk_erp_engine(market: str = "HSI") -> HKERPTimingEngine:
    global _hk_engines
    if market not in _hk_engines:
        _hk_engines[market] = HKERPTimingEngine(market=market)
    return _hk_engines[market]


# ===== 自检 =====
if __name__ == "__main__":
    import sys
    if sys.platform == 'win32':
        sys.stdout.reconfigure(encoding='utf-8', errors='replace')

    for mkt in ["HSI", "HSTECH"]:
        print(f"\n=== HK ERP Engine V1.0 [{mkt}] Self-Test ===")
        engine = HKERPTimingEngine(market=mkt)
        report = engine.generate_report()
        if report.get("status") in ("success", "fallback"):
            snap = report["current_snapshot"]
            sig = report["signal"]
            print(f"PE: {snap['pe_ttm']}x | RF: {snap['blended_rf']}% | ERP: {snap['erp_value']}%")
            print(f"分位: {snap['erp_percentile']}% | 得分: {sig['score']} | {sig['emoji']} {sig['label']} ({sig['position']})")
            for d, v in report.get("dimensions", {}).items():
                print(f"  {v['label']}: {v['score']} ({v.get('desc', '')[:60]})")
        else:
            print(f"Failed: {report.get('message')}")
