"""Pure multi-asset assembly: source checks -> signals -> constrained targets.

No holdings, returns or covariance are available here. Outputs are model targets,
not orders, risk parity, expected returns or a measured hedge of A-share risk.
"""
import copy
import math
from datetime import datetime, timezone

from services.health_status import _timestamp_age_seconds
from services.source_freshness import evaluate_source_freshness, gold_result_is_usable, gold_source_diagnostics
from services import multi_asset_policy as _policy
from services.multi_asset_policy import (
    BOUNDS, SAA_WEIGHTS, POLICY_VERSION, EQUITY_SIGNAL_WEIGHTS,
    MAX_RATES_CACHE_AGE_SEC, finite_number, signal_direction, tactical_weight,
)


def observation_is_fresh(value, now):
    """Compatibility helper for US daily-rate sources."""
    return evaluate_source_freshness("DGS10", value, now=now)["usable"]


def read_rates_signal(cached, *, now=None):
    """Decode the actual /strategy/rates SWR envelope, never infer from defaults."""
    now = now or datetime.now(timezone.utc)
    invalid = {"status": "unavailable", "signal": None, "data_as_of": None,
               "reason": "美债信号缺失、失效或数据日期不可验证"}
    if not isinstance(cached, dict):
        return invalid
    age = _timestamp_age_seconds(cached.get("timestamp"), now.timestamp())
    payload = cached.get("data")
    if age is None or age > MAX_RATES_CACHE_AGE_SEC or not isinstance(payload, dict):
        return invalid
    report = payload.get("data")
    if payload.get("status") != "success" or not isinstance(report, dict) or report.get("error"):
        return invalid
    signal_payload = report.get("signal")
    score = signal_payload.get("score") if isinstance(signal_payload, dict) else None
    date = report.get("data_as_of")
    quality = report.get("quality", {})
    if (not finite_number(score, 0, 100) or not observation_is_fresh(date, now)
            or not isinstance(quality, dict) or quality.get("usable") is not True):
        return invalid
    return {"status": "ok", "signal": round((score - 50) * 2, 1),
            "data_as_of": date, "reason": None, "cache_age_seconds": age}


def _project_budget(requested, caps, lows=None):
    """Euclidean projection with floors/caps; excess goes to the cash reserve."""
    keys = ("equity_cn", "bond", "gold")
    lows = dict(lows) if lows else {k: BOUNDS[k][0] for k in keys}
    weights = {k: min(caps[k], max(lows[k], requested[k])) for k in keys}
    budget = 100 - BOUNDS["cash"][0]
    binding = []
    if sum(weights.values()) > budget:
        binding.append("cash:minimum")
        lo, hi = 0.0, max(requested[k] - lows[k] for k in keys)
        for _ in range(80):
            shift = (lo + hi) / 2
            total = sum(min(caps[k], max(lows[k], requested[k] - shift)) for k in keys)
            if total > budget:
                lo = shift
            else:
                hi = shift
        weights = {k: min(caps[k], max(lows[k], requested[k] - hi)) for k in keys}
    binding.extend(f"{k}:cap" for k in keys
                   if requested[k] > caps[k] and abs(weights[k] - caps[k]) < 1e-8)
    binding.extend(f"{k}:minimum" for k in keys
                   if requested[k] > lows[k] and abs(weights[k] - lows[k]) < 1e-8)
    # Floor, rather than independently round up, so the liquidity floor survives.
    units = {k: math.floor(weights[k] * 10 + 1e-8) for k in keys}
    result = {k: units[k] / 10 for k in keys}
    result["cash"] = (1000 - sum(units.values())) / 10
    return result, binding


def build_multi_asset_allocation(snapshot, jcs, gold, rates_cache, *, now=None):
    now = now or datetime.now(timezone.utc)
    snapshot, jcs, gold = (x if isinstance(x, dict) else {} for x in (snapshot, jcs, gold))
    reasons = []
    rate = read_rates_signal(rates_cache, now=now)
    cap, desired = snapshot.get("aiae_cap"), snapshot.get("suggested_position")
    equity_ok = (snapshot.get("decision_locked") is False and snapshot.get("aiae_fresh") is True
                 and finite_number(cap, 0, 100) and finite_number(desired, 0, 100))
    if not equity_ok:
        reasons.append("权益数据失效或 AIAE 决策已锁定")
    # Direction comes from core equity convictions (fixed weights, decoupled from JCS); JCS 分数不作闸门。
    shadow = jcs.get("shadow")
    shadow = shadow if isinstance(shadow, dict) else {}
    convictions = jcs.get("equity_convictions") or jcs.get("convictions") or shadow.get("v26_convictions") or {}
    convictions = convictions if isinstance(convictions, dict) else {}
    core = tuple(EQUITY_SIGNAL_WEIGHTS)
    if not all(finite_number(convictions.get(k), -1, 1) for k in core):
        equity_ok = False
        reasons.append("权益方向信号不完整")
    eq_signal = (round(100 * sum(convictions[k] * EQUITY_SIGNAL_WEIGHTS[k] for k in core)
                       / sum(EQUITY_SIGNAL_WEIGHTS[k] for k in core), 1) if equity_ok else None)
    gold_quality = gold.get("quality")
    gold_quality = gold_quality if isinstance(gold_quality, dict) else {}
    gold_diagnostics = gold_source_diagnostics(gold, now=now)
    gold_ok = gold_result_is_usable(gold, now=now)
    if not gold_ok:
        detail = gold_diagnostics["reasons"] or gold_quality.get("unavailable_reasons", [])
        reasons.append("黄金目标暂停：" + "；".join(detail) if detail else "黄金数据缺失、过期或有效因子不足")
    bond_tactical = _policy.BOND_TACTICAL_ENABLED  # 运行时读取, 便于测试切换
    if rate["status"] != "ok" and bond_tactical:
        reasons.append(rate["reason"])

    def asset(label, icon, signal, valid, date=None):
        direction = signal_direction(signal if valid else None)
        return {"label": label, "icon": icon, "signal": signal if valid else None,
                "direction": direction,
                "direction_cn": {"bullish": "看多", "bearish": "看空", "neutral": "中性",
                                 "unavailable": "数据不足"}[direction],
                "data_status": "ok" if valid else "unavailable", "data_as_of": date,
                "allocation": None, "allocation_label": "暂无有效目标"}

    assets = {
        "equity_cn": asset("A股权益", "📈", eq_signal, equity_ok, snapshot.get("aiae_updated_at")),
        "bond": asset("美债", "📋", rate["signal"], rate["status"] == "ok", rate["data_as_of"]),
        "gold": asset("黄金", "🥇", gold.get("gold_signal"), gold_ok, gold.get("data_as_of")),
        "cash": asset("现金", "💵", None, True),
    }
    assets["cash"].update(direction="not_applicable", direction_cn="流动性储备")
    assets["bond"].update(tactical_enabled=bond_tactical,
                          background_only=not bond_tactical,
                          tactical_note=None if bond_tactical else _policy.BOND_TACTICAL_DISABLED_NOTE)
    assets["equity_cn"].update(cap=cap if finite_number(cap, 0, 100) else None)
    assets["gold"]["components"] = copy.deepcopy(gold.get("components", {}))
    assets["gold"]["quality"] = copy.deepcopy(gold_quality)
    assets["gold"]["source_diagnostics"] = gold_diagnostics
    assets["gold"]["partial_signal"] = gold.get("partial_signal") if not gold_ok else None
    assets["gold"]["availability_reason"] = "；".join(gold_diagnostics["reasons"] or gold_quality.get("unavailable_reasons", []))
    if gold_ok:
        for key, state in gold_diagnostics["sources"].items():
            assets["gold"]["components"][key]["freshness"] = state
    weights, binding = {}, []
    if not reasons:
        bond_target = tactical_weight("bond", rate["signal"]) if bond_tactical else SAA_WEIGHTS["bond"]
        requested = {"equity_cn": desired, "bond": bond_target,
                     "gold": tactical_weight("gold", gold["gold_signal"])}
        caps = {k: BOUNDS[k][1] for k in requested}
        caps["equity_cn"] = min(caps["equity_cn"], cap)
        lows = {k: BOUNDS[k][0] for k in requested}
        if not bond_tactical:  # 固定 SAA: 美债上下限都锁在锚点, 预算紧张时由权益/黄金让出
            lows["bond"] = caps["bond"] = SAA_WEIGHTS["bond"]
        weights, binding = _project_budget(requested, caps, lows)
        for key, item in assets.items():
            weight = weights[key]
            item.update(allocation=weight, saa_weight=SAA_WEIGHTS[key],
                        active_weight=round(weight - SAA_WEIGHTS[key], 1),
                        unconstrained_allocation=requested.get(key),
                        allocation_label=f"SAA {SAA_WEIGHTS[key]:g}% · 偏离 {weight - SAA_WEIGHTS[key]:+.1f}pp")
        if not bond_tactical:
            assets["bond"]["allocation_label"] += " · 固定 SAA (利率信号仅背景)"
    return {"status": "degraded" if reasons else "success", "assets": assets,
            "saa_weights": dict(SAA_WEIGHTS), "policy_version": POLICY_VERSION,
            "equity_signal_weights": dict(EQUITY_SIGNAL_WEIGHTS),
            "decision_locked": bool(reasons), "allocation_basis": "model_target",
            "model_validation": "heuristic_pending_out_of_sample_validation",
            "warnings": list(gold_quality.get("warnings", [])),
            "constraints": {"reasons": reasons, "binding": binding,
                            "min_cash_pct": BOUNDS["cash"][0],
                            "bounds": {k: list(v) for k, v in BOUNDS.items()},
                            "total_pct": round(sum(weights.values()), 1) if weights else None},
            "timestamp": now.isoformat(), "auto_execute": False}


def invalidate_targets(result, reason):
    """Preserve historical signals while revoking all portfolio targets."""
    result = copy.deepcopy(result)
    result.update(status="degraded", decision_locked=True)
    constraints = result.setdefault("constraints", {})
    constraints["total_pct"] = None
    reasons = constraints.setdefault("reasons", [])
    if reason not in reasons:
        reasons.append(reason)
    for item in result.get("assets", {}).values():
        item.update(allocation=None, active_weight=None, unconstrained_allocation=None,
                    allocation_label="暂无有效目标")
    return result


def recheck_cached_targets(result, aiae_ctx, rates_cache, *, now=None):
    """Cached success cannot bypass a later safety lock, lower cap or source expiry."""
    from services.health_status import evaluate_aiae_context
    now = now or datetime.now(timezone.utc)
    if not isinstance(result, dict) or not result.get("assets"):
        return result
    state = evaluate_aiae_context(aiae_ctx, now_ts=now.timestamp())
    cap = aiae_ctx.get("cap") if isinstance(aiae_ctx, dict) else None
    equity_weight = result.get("assets", {}).get("equity_cn", {}).get("allocation")

    def revoke_source(current, key, reason):
        current = invalidate_targets(current, reason)
        item = current["assets"].get(key)
        if item:
            item.update(signal=None, data_status="unavailable", direction="unavailable",
                        direction_cn="数据不足", availability_reason=reason)
        return current

    if not state["usable"] and result["assets"].get("equity_cn", {}).get("data_status") == "ok":
        result = revoke_source(result, "equity_cn", "AIAE 安全状态已变化，等待重新计算")
    elif not result.get("decision_locked") and (not finite_number(cap, 0, 100)
                                                or not finite_number(equity_weight, 0, cap)):
        result = invalidate_targets(result, "AIAE 仓位上限已变化，等待重新计算")
    if (_policy.BOND_TACTICAL_ENABLED
            and read_rates_signal(rates_cache, now=now)["status"] != "ok"
            and result["assets"].get("bond", {}).get("data_status") == "ok"):
        result = revoke_source(result, "bond", "美债数据已失效，等待重新计算")
    gold_asset = result.get("assets", {}).get("gold", {})
    gold_payload = dict(gold_asset, status="success", gold_signal=gold_asset.get("signal"))
    if gold_asset.get("data_status") == "ok" and not gold_result_is_usable(gold_payload, now=now):
        diagnostics = gold_source_diagnostics(gold_payload, now=now)
        result = revoke_source(result, "gold", "黄金来源已失效：" + "；".join(diagnostics["reasons"]))
        gold_asset = result["assets"]["gold"]
        gold_asset["source_diagnostics"] = diagnostics
        coverage, subtotal = 0.0, []
        for key, source in diagnostics["sources"].items():
            comp = gold_asset["components"][key]
            comp["freshness"] = source
            if source["usable"]:
                coverage += comp.get("weight", 0)
                if finite_number(comp.get("contribution"), -100, 100):
                    subtotal.append(comp["contribution"])
            else:
                comp.update(data_status="unavailable", score=None, contribution=None,
                            direction="unavailable", direction_cn="数据不足", unusable_reason=source["reason"])
        gold_asset["partial_signal"] = round(sum(subtotal), 1) if subtotal else None
        gold_asset["quality"].update(usable=False, coverage=round(coverage, 2))
    if result.get("_cache", {}).get("stale"):
        result = invalidate_targets(result, "组合结果为旧缓存，等待刷新后恢复目标")
    return result
