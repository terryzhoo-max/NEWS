"""
AlphaCore · 美股 ERP 估值锚 V2 (海外 ERP P1, 见 docs/ERP_GLOBAL_OPTIMIZATION_PLAN.md)
=====================================================================================
替代 erp_us_engine 中"估算 EPS + 合成历史"的 ERP 读数。只输出估值背景, 不输出仓位。

L1 估值锚
  ERP_real = TTM 盈利收益率 (Shiller E / P) − 10Y 实际利率
  10Y 实际利率 = FRED DFII10 (TIPS, 2003-01 起, 月均值); 2003 年以前用代理值拼接:
                 10Y 名义利率 − 过去 10 年 CPI 年化通胀
  (不全程用代理: 2026 年代理值比 DFII10 低约 1 个百分点, 因过去 10 年通胀被 2021–23 年抬高)
  校验列: CAPE 超额收益率 = 1/CAPE − 同一实际利率 (只展示)
  分位: 扩展窗口 (只用严格早于当月的历史)

L2 状态门控 (只决定是否升级为"外部风险警示", 不改档位)
  趋势: S&P 500 收盘价低于 200 日均线
  信用: HY OAS 近 3 个月上升 ≥ 0.5 个百分点

L3 三档 + 缓冲带
  分位 ≥ 70 → 偏便宜; 分位 ≤ 30 → 偏贵; 其余中性
  回档需越过缓冲: 偏便宜在分位 < 65 时才回中性, 偏贵在分位 > 35 时才回中性

参数在 PARAMS 中预先写定 (见 docs/ERP_GLOBAL_PREREGISTRATION.md), 不做调参。
"""

from __future__ import annotations

import logging
import os
from typing import Optional

import numpy as np
import pandas as pd

logger = logging.getLogger("alphacore.us_valuation")

PARAMS = {
    "version": "us-erp-v2.0",
    "infl_years": 10,             # 实际利率代理: 过去 10 年 CPI 年化通胀
    "min_history_months": 240,    # 至少 20 年历史才给出分位
    "cheap_pct": 70.0,
    "expensive_pct": 30.0,
    "buffer_pct": 5.0,
    "trend_ma_days": 200,
    "credit_widen_pp": 0.5,
    "eps_stale_months": 6,        # EPS 最新月份距今超过 6 个月 → 标记过期
}

CSV_PATH = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                        "data", "shiller_us_monthly.csv")

TIER_CN = {"cheap": "偏便宜", "neutral": "中性", "expensive": "偏贵"}


# ───────────────────────── 数据 ─────────────────────────

def load_monthly(path: str = CSV_PATH) -> pd.DataFrame:
    """读取精简版 Shiller 月度数据 (由 _dev_tools/update_shiller_csv.py 从 ie_data.xls 生成)。

    列: month (YYYY-MM), price, dividend, earnings, cpi, gs10, real_tr_price, cape
    """
    df = pd.read_csv(path, dtype={"month": str})
    df["date"] = pd.PeriodIndex(df["month"], freq="M").to_timestamp(how="end").normalize()
    df = df.set_index("date").sort_index()
    for c in ["price", "dividend", "earnings", "cpi", "gs10", "real_tr_price", "cape"]:
        if c in df.columns:
            df[c] = pd.to_numeric(df[c], errors="coerce")
    return df


def real_rate_proxy(gs10: pd.Series, cpi: pd.Series, years: int) -> pd.Series:
    """10Y 名义利率 − 过去 `years` 年 CPI 年化通胀 (百分比)。"""
    months = years * 12
    infl = ((cpi / cpi.shift(months)) ** (1.0 / years) - 1.0) * 100.0
    return gs10 - infl


def _expanding_pct(x: pd.Series, min_n: int) -> pd.Series:
    """每个点在严格早于它的历史中的分位 (0–100); 历史不足 min_n 时为 NaN。"""
    vals = x.to_numpy(dtype=float)
    out = np.full(len(vals), np.nan)
    hist: list = []
    for i, v in enumerate(vals):
        if np.isnan(v):
            continue
        if len(hist) >= min_n:
            arr = np.asarray(hist)
            out[i] = (np.sum(arr < v) + 0.5 * np.sum(arr == v)) / len(arr) * 100.0
        hist.append(v)
    return pd.Series(out, index=x.index)


def _next_tier(prev: Optional[str], pct: float, p: dict = PARAMS) -> Optional[str]:
    """带缓冲带的三档切换。"""
    if pct is None or np.isnan(pct):
        return prev
    cheap, exp, buf = p["cheap_pct"], p["expensive_pct"], p["buffer_pct"]
    if pct >= cheap:
        return "cheap"
    if pct <= exp:
        return "expensive"
    if prev == "cheap" and pct >= cheap - buf:
        return "cheap"
    if prev == "expensive" and pct <= exp + buf:
        return "expensive"
    return "neutral"


def assign_tiers(pct: pd.Series, p: dict = PARAMS) -> pd.Series:
    tiers, prev = [], None
    for v in pct.to_numpy(dtype=float):
        prev = _next_tier(prev, v, p)
        tiers.append(prev)
    return pd.Series(tiers, index=pct.index, dtype=object)


def to_monthly(daily: Optional[pd.Series]) -> Optional[pd.Series]:
    """日频序列 → 月均值, 索引为月末 (与 load_monthly 对齐)。"""
    if daily is None or len(daily) == 0:
        return None
    s = pd.Series(daily).dropna()
    s.index = pd.to_datetime(s.index)
    m = s.groupby(s.index.to_period("M")).mean()
    m.index = m.index.to_timestamp(how="end").normalize()
    return m


def build_history(df: pd.DataFrame, dfii10_monthly: Optional[pd.Series] = None,
                  p: dict = PARAMS) -> pd.DataFrame:
    """月度 ERP_real 历史、扩展分位与档位。只使用有实际 EPS 的月份。

    dfii10_monthly: DFII10 月均值 (月末索引); 有值的月份覆盖代理值。缺省时全程用代理 (离线验证用)。
    """
    h = pd.DataFrame(index=df.index)
    h["price"] = df["price"]
    h["eps"] = df["earnings"]
    h["ey"] = df["earnings"] / df["price"] * 100.0
    h["gs10"] = df["gs10"]
    h["real_rate"] = real_rate_proxy(df["gs10"], df["cpi"], p["infl_years"])
    h["rr_source"] = np.where(h["real_rate"].notna(), "proxy", None)
    if dfii10_monthly is not None and len(dfii10_monthly):
        tips = dfii10_monthly.reindex(h.index)
        h.loc[tips.notna(), "real_rate"] = tips[tips.notna()]
        h.loc[tips.notna(), "rr_source"] = "dfii10"
    h["erp"] = h["ey"] - h["real_rate"]
    if "cape" in df.columns:
        h["cape"] = df["cape"]
        h["cape_erp"] = 100.0 / df["cape"] - h["real_rate"]
    h = h.dropna(subset=["erp"])
    h["pct"] = _expanding_pct(h["erp"], p["min_history_months"])
    h["tier"] = assign_tiers(h["pct"], p)
    return h


# ───────────────────────── 当前读数 ─────────────────────────

def latest_reading(
    df: pd.DataFrame,
    hist: pd.DataFrame,
    price_now: Optional[float] = None,
    gs10_now: Optional[float] = None,
    as_of: Optional[pd.Timestamp] = None,
    dfii10_now: Optional[float] = None,
    below_ma200: Optional[bool] = None,
    credit_change_3m: Optional[float] = None,
    p: dict = PARAMS,
) -> dict:
    """用最新价格/名义利率 + 最近一期实际 EPS 与 CPI 算当前 ERP_real, 与月度历史比较。

    price_now / gs10_now 缺省时使用 CSV 最后一行 (月度口径)。
    """
    as_of = pd.Timestamp(as_of or pd.Timestamp.today()).normalize()

    eps_rows = df["earnings"].dropna()
    eps_month = eps_rows.index[-1]
    eps = float(eps_rows.iloc[-1])

    price = float(price_now) if price_now else float(df["price"].dropna().iloc[-1])
    price_source = "live" if price_now else "csv"
    gs10 = float(gs10_now) if gs10_now is not None else float(df["gs10"].dropna().iloc[-1])

    cpi = df["cpi"].dropna()
    months = p["infl_years"] * 12
    infl = ((cpi.iloc[-1] / cpi.iloc[-1 - months]) ** (1.0 / p["infl_years"]) - 1.0) * 100.0
    proxy_rate = gs10 - infl
    real_rate = float(dfii10_now) if dfii10_now is not None else proxy_rate

    ey = eps / price * 100.0
    erp = ey - real_rate

    past = hist["erp"].dropna()
    past = past[past.index < as_of.to_period("M").to_timestamp()]  # 严格早于当月
    pct = float((np.sum(past < erp) + 0.5 * np.sum(past == erp)) / len(past) * 100.0) if len(past) else None

    prev_tier = hist["tier"].dropna()
    prev_tier = prev_tier[prev_tier.index < as_of.to_period("M").to_timestamp()]
    prev = prev_tier.iloc[-1] if len(prev_tier) else None
    tier = _next_tier(prev, pct if pct is not None else np.nan, p)

    cape_erp = None
    if "cape" in df.columns and df["cape"].notna().any():
        cape_erp = round(float(100.0 / float(df["cape"].dropna().iloc[-1]) - real_rate), 2)

    eps_age = (as_of.to_period("M") - eps_month.to_period("M")).n
    credit_widening = (credit_change_3m is not None and credit_change_3m >= p["credit_widen_pp"])
    warning = bool(tier == "expensive" and (bool(below_ma200) or credit_widening))

    reasons = []
    if below_ma200:
        reasons.append("标普500 低于 200 日均线")
    if credit_widening:
        reasons.append(f"HY 利差 3 个月上升 {credit_change_3m:.2f} 个百分点")

    return {
        "version": p["version"],
        "as_of": str(as_of.date()),
        "erp": round(float(erp), 2),
        "ey_ttm": round(ey, 2),
        "pe_ttm": round(price / eps, 1),
        "eps_ttm": round(eps, 2),
        "eps_month": eps_month.strftime("%Y-%m"),
        "eps_age_months": int(eps_age),
        "eps_stale": bool(eps_age > p["eps_stale_months"]),
        "price": round(price, 2),
        "price_source": price_source,
        "gs10": round(gs10, 2),
        "infl_10y": round(float(infl), 2),
        "real_rate": round(float(real_rate), 2),
        "real_rate_basis": "DFII10 (TIPS)" if dfii10_now is not None else f"代理: 10Y 名义 − 过去{p['infl_years']}年CPI年化",
        "real_rate_proxy": round(float(proxy_rate), 2),
        "cape_erp": cape_erp,
        "pct": None if pct is None else round(pct, 1),
        "history_start": past.index[0].strftime("%Y-%m") if len(past) else None,
        "history_months": int(len(past)),
        "median_erp": round(float(past.median()), 2) if len(past) else None,
        "tier": tier,
        "tier_cn": TIER_CN.get(tier, "--"),
        "gate": {
            "below_ma200": below_ma200,
            "credit_change_3m": None if credit_change_3m is None else round(float(credit_change_3m), 2),
            "external_risk_warning": warning,
            "reasons": reasons,
        },
        "role": "background",
        "note": "估值背景, 不作仓位依据",
    }


def compute(price_now=None, gs10_now=None, as_of=None, dfii10_daily: Optional[pd.Series] = None,
            below_ma200=None, credit_change_3m=None, path: Optional[str] = None) -> Optional[dict]:
    """便捷入口: CSV 不存在或读取失败时返回 None (调用方回退到 P0 的"仅读数")。

    dfii10_daily: DFII10 日频序列 (2003 年起); 历史按月均值拼接, 当前值取最后一个观测。
    """
    try:
        df = load_monthly(path or CSV_PATH)
        tips_m = to_monthly(dfii10_daily)
        dfii10_now = float(pd.Series(dfii10_daily).dropna().iloc[-1]) if tips_m is not None else None
        hist = build_history(df, tips_m)
        return latest_reading(df, hist, price_now, gs10_now, as_of, dfii10_now,
                              below_ma200, credit_change_3m)
    except FileNotFoundError:
        logger.warning("Shiller CSV 不存在: %s", path)
    except Exception as e:  # noqa: BLE001 — 估值背景失败不影响主流程
        logger.warning("美股 ERP v2 计算失败: %s", e, exc_info=True)
    return None
