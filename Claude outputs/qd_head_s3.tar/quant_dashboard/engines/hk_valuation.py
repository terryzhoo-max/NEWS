"""
AlphaCore · 港股 ERP 读数 (海外 ERP P4, 见 docs/ERP_GLOBAL_OPTIMIZATION_PLAN.md)
==============================================================================
替代 erp_hk_engine 中"估算 EPS + 0.6×US10Y + 0.4×CN10Y 混合利率 + 合成价格历史"的读数。只输出数值, 不分位、不分档。

利率: 美国 10Y 实际利率 (FRED DFII10)。港币挂钩美元, 机构通常以美债为港股无风险利率锚;
      用实际利率与美股 V2 同口径 (盈利收益率本身是实际量)。
PE  : data/hk_pe_monthly.csv 中的月度 PE (每月更新一次)。2026-11-01 起 HSI 用理杏仁 PE-TTM
      (成分股总市值加权, 2003-01 起, 由 _dev_tools/update_hk_pe_csv.py 导入); 也兼容手动录入的公布值。
      没有 60 天内的数值时, 回退到引擎的估算 PE, 并标记"仅读数"。
ERP : 100 / PE − DFII10
历史: erp_history() 按月给出 ERP 走势 (每月末 PE 对应当日或之前最近的 DFII10), 只画图, 不算分位。
"""

from __future__ import annotations

import logging
import os
from datetime import date
from typing import Optional

import pandas as pd

logger = logging.getLogger("alphacore.hk_valuation")

_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PE_CSV = os.path.join(_ROOT, "data", "hk_pe_monthly.csv")

PARAMS = {
    "version": "hk-erp-real-1.0",
    "pe_max_age_days": 60,   # 公布 PE 超过 60 天视为不可用, 回退估算
}

_MARKET_CN = {"HSI": "恒生指数", "HSTECH": "恒生科技指数"}


def load_published_pe(market: str, path: str = None) -> Optional[dict]:
    p = path or PE_CSV
    if not os.path.exists(p):
        return None
    df = pd.read_csv(p, dtype={"market": str, "source": str})
    df = df[df["market"].str.upper() == market.upper()].dropna(subset=["pe"])
    if df.empty:
        return None
    df["date"] = pd.to_datetime(df["date"])
    row = df.sort_values("date").iloc[-1]
    return {"pe": float(row["pe"]), "date": row["date"], "source": str(row.get("source", ""))}


def _basis(market: str, source: str) -> str:
    if str(source).startswith("lixinger"):
        return f"{_MARKET_CN.get(market, market)} PE-TTM (理杏仁, 成分股总市值加权)"
    return f"{_MARKET_CN.get(market, market)} 公布市盈率"


def erp_history(market: str, dfii10: Optional[pd.Series], pe_path: str = None,
                min_months: int = 24) -> Optional[pd.DataFrame]:
    """月度 ERP 历史: date, pe, rate, erp。PE 或利率历史不足时返回 None。"""
    try:
        p = pe_path or PE_CSV
        if dfii10 is None or not os.path.exists(p):
            return None
        df = pd.read_csv(p, dtype={"market": str, "source": str})
        df = df[df["market"].str.upper() == market.upper()].dropna(subset=["pe"])
        if len(df) < min_months:
            return None
        df["date"] = pd.to_datetime(df["date"])
        df = df.sort_values("date")[["date", "pe"]]
        r = dfii10.dropna().sort_index()
        r.index = pd.to_datetime(r.index)
        rates = r.rename("rate").reset_index().rename(columns={r.index.name or "index": "date"})
        rates.columns = ["date", "rate"]
        m = pd.merge_asof(df, rates.sort_values("date"), on="date", direction="backward",
                          tolerance=pd.Timedelta("10D")).dropna(subset=["rate"])
        if len(m) < min_months:
            return None
        m["erp"] = 100.0 / m["pe"] - m["rate"]
        return m.reset_index(drop=True)
    except Exception as e:  # noqa: BLE001
        logger.warning("港股 ERP 历史失败: %s", e, exc_info=True)
        return None


def compute(market: str, dfii10_now: Optional[float], pe_estimated: Optional[float] = None,
            as_of: Optional[pd.Timestamp] = None, pe_path: str = None, p: dict = PARAMS) -> Optional[dict]:
    """DFII10 缺失时返回 None (调用方保持 P0 读数)。PE 优先用公布值, 否则用估算值。"""
    try:
        if dfii10_now is None:
            return None
        as_of = pd.Timestamp(as_of or date.today()).normalize()
        pub = load_published_pe(market, pe_path)
        pub_ok = pub is not None and (as_of - pub["date"]).days <= p["pe_max_age_days"]
        if pub_ok:
            pe, pe_source, pe_date = pub["pe"], "published", str(pub["date"].date())
            basis = _basis(market, pub["source"])
        elif pe_estimated:
            pe, pe_source, pe_date = float(pe_estimated), "estimated", None
            basis = "估算EPS (基数×增速外推)"
        else:
            return None
        ey = 100.0 / pe
        erp = ey - float(dfii10_now)
        return {
            "version": p["version"],
            "market": market,
            "as_of": str(as_of.date()),
            "erp": round(erp, 2),
            "pe": round(pe, 2),
            "ey": round(ey, 2),
            "pe_source": pe_source,
            "pe_date": pe_date,
            "pe_basis": basis,
            "pe_stale": bool(pub is not None and not pub_ok),
            "rate": round(float(dfii10_now), 2),
            "rate_basis": "美国 10Y 实际利率 (DFII10, 港币挂钩美元)",
            "yield_label": "REAL 10Y",
            "grade_cn": "真实PE" if pub_ok else "仅读数",
            "pct": None, "tier": None,
            "role": "background",
            "note": "不显示分位、不分档" + ("" if pub_ok else "; PE 为估算值"),
        }
    except Exception as e:  # noqa: BLE001
        logger.warning("港股 ERP 读数失败: %s", e, exc_info=True)
        return None
