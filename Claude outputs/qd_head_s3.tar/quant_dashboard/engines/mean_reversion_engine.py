"""
AlphaCore · 均值回归 V4.2 自适应参数引擎
==========================================
特性：
- 按实时 Regime 动态加载三套专属参数
- 无需重启服务器（读取 config/strategy_runtime.json）
- BULL 状态：均值回归仓位上限 35%，超跌补仓逻辑
- 60天自动重优化检测
- V4.2 新增：RSI动量方向（Δ RSI₅）+ K线形态识别（7维度100分制）
"""

import pandas as pd
import numpy as np
import tushare as ts
import json
import os
import time
import traceback
import hashlib
from pathlib import Path
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor, as_completed

# ===== 工业级重试装饰器 (统一至 services.retry) =====
from services.retry import retry_with_backoff
from services.health_status import evaluate_aiae_context
from services.strategy_params import (
    get_all_mr_lifecycle,
    get_all_mr_params as _runtime_all_mr_params,
    get_mr_lifecycle,
    get_mr_params,
    get_position_cap,
    get_regime_rules,
    get_score_gate,
    load_runtime_config,
)

from config import TUSHARE_TOKEN
from services.price_adjust import forward_adjust_daily as _forward_adjust
DAILY_PRICE_DIR = "data_lake/daily_prices"
_LOADED_ENGINE_HASH = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()

# 默认回退参数（若 JSON 不存在）
# stop_loss：正数表示止损幅度，如 0.05 = 浮亏 > 5% 触发止损（V4.3统一正数约定）
FALLBACK_PARAMS = _runtime_all_mr_params()

# ═══════════════════════════════════════════════════════════
#  V22.0: 资产类别分类 + 差异化参数加载
# ═══════════════════════════════════════════════════════════

# 资产类别定义
_ASSET_CLASS_RULES = [
    # (类别键, 名称, 判断函数)
    ("broad_etf", "宽基ETF", lambda code, name: (
        code in ("510300.SH", "510500.SH", "512100.SH", "159915.SZ", "159949.SZ",
                 "588000.SH", "588220.SH", "159781.SZ") or
        ("沪深300" in name or "中证500" in name or "中证1000" in name or
         "创业板" in name or "科创50" in name or "科创100" in name)
    )),
    ("overseas_etf", "海外ETF", lambda code, name: (
        code in ("513500.SH", "513100.SH", "513520.SH", "513530.SH",
                 "513130.SH", "513180.SH", "513950.SH", "513120.SH",
                 "513090.SH", "159545.SZ", "513970.SH") or
        ("标普" in name or "纳指" in name or "日经" in name or
         "恒生" in name or "港股通" in name or "海外" in name)
    )),
    ("individual_stock", "个股", lambda code, name: (
        code.endswith((".SZ", ".SH")) and not code.startswith(("51", "56", "58", "15"))
    )),
]
# 其余默认为 sector_etf

def _classify_asset(code: str, name: str = "") -> str:
    """自动识别标的产品类别"""
    for class_key, class_label, check_fn in _ASSET_CLASS_RULES:
        if check_fn(code, name):
            return class_key
    return "sector_etf"  # 默认行业ETF


def _load_asset_params():
    """加载 V22.0 资产类别差异化参数矩阵"""
    import json, os
    path = os.path.join(os.path.dirname(__file__), "..", "mr_asset_class_params.json")
    # 标准化路径
    path = os.path.normpath(path)
    if not os.path.exists(path):
        path = "mr_asset_class_params.json"  # fallback to CWD
    try:
        with open(path, 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception:
        return {}


# 模块级缓存
_ASSET_PARAMS_CACHE = None


def get_asset_params(code: str, regime: str, name: str = "") -> dict:
    """
    V22.0: 按资产类别 + Regime 获取差异化参数。

    返回: {rsi_period, rsi_buy, rsi_sell, bias_buy, bias_sell,
           stop_loss, take_profit_t1, take_profit_t2,
           trailing_stop_atr_mult, time_stop_days, entry_gate, N_trend, ...}
    """
    global _ASSET_PARAMS_CACHE
    if _ASSET_PARAMS_CACHE is None:
        _ASSET_PARAMS_CACHE = _load_asset_params()

    asset_class = _classify_asset(code, name)
    regime_key = regime.upper() if regime else "RANGE"
    if regime_key not in ("BULL", "RANGE", "BEAR", "CRASH"):
        regime_key = "RANGE"

    # 尝试从资产类别参数矩阵读取
    try:
        class_params = _ASSET_PARAMS_CACHE.get(asset_class, {})
        regime_params = class_params.get(regime_key)
        if regime_params and isinstance(regime_params, dict) and "rsi_buy" in regime_params:
            return regime_params
    except Exception:
        pass

    # Fallback: 旧版通用参数
    return FALLBACK_PARAMS.get(regime_key, FALLBACK_PARAMS["RANGE"])


def get_asset_class_label(code: str, name: str = "") -> str:
    """返回资产类别中文标签"""
    class_map = {
        "individual_stock": "个股",
        "sector_etf": "行业ETF",
        "broad_etf": "宽基ETF",
        "overseas_etf": "海外ETF",
    }
    return class_map.get(_classify_asset(code, name), "行业ETF")


def dynamic_position_cap(code: str, name: str = "", regime: str = "RANGE") -> float:
    """
    V22.0: 动态仓位上限 = 基础上限 × σ基准/σ资产 × Regime系数

    从日线 parquet 读取实际波动率，自动缩放仓位。
    高波动资产 → 降仓；低波动资产 → 提仓（不超过基础上限 1.3x）。
    """
    asset_class = _classify_asset(code, name)
    params = get_asset_params(code, regime, name)
    base_cap = params.get("_max_pos_base", 12)
    if isinstance(base_cap, dict):
        base_cap = base_cap.get("default", 12)
    base_cap = float(base_cap)

    # 估算年化波动率
    annual_vol = _estimate_annual_vol(code)
    vol_baseline = params.get("_vol_baseline", 20)
    if isinstance(vol_baseline, dict):
        vol_baseline = 20
    vol_baseline = float(vol_baseline)

    vol_scale = vol_baseline / max(annual_vol, 8)  # 最小波动 8%
    vol_scale = max(0.4, min(vol_scale, 1.3))

    # Regime 系数
    regime_scale = {"BULL": 1.0, "RANGE": 0.85, "BEAR": 0.6, "CRASH": 0.0}
    rs = regime_scale.get(regime, 0.85)

    return round(min(base_cap * vol_scale * rs, 25), 1)  # 上限 25%


def _estimate_annual_vol(code: str) -> float:
    """从 parquet 日线估算年化波动率"""
    import os
    try:
        fpath = f"data_lake/daily_prices/{code}.parquet"
        if not os.path.exists(fpath):
            return 30  # 默认 30%
        df = _forward_adjust(pd.read_parquet(fpath))   # 2026-10-31: 拆分日不再算作 -50% 收益
        if "close" not in df.columns or len(df) < 20:
            return 30
        returns = df["close"].pct_change().dropna().tail(60)
        daily_vol = float(returns.std())
        return round(daily_vol * (252 ** 0.5) * 100, 1)
    except Exception:
        return 30


def compute_atr_trailing_stop(code: str, current_price: float,
                              entry_price: float, regime: str = "RANGE") -> dict:
    """
    V22.0: ATR 动态追踪止盈。

    返回: {atr_value, trailing_stop_price, stop_pct, multiplier}
    """
    import os
    try:
        fpath = f"data_lake/daily_prices/{code}.parquet"
        if not os.path.exists(fpath):
            return _atr_fallback(current_price, entry_price)
        df = _forward_adjust(pd.read_parquet(fpath))   # 2026-10-31: 拆分缺口不计入 ATR
        if len(df) < 15:
            return _atr_fallback(current_price, entry_price)

        # 计算 14 日 ATR
        high = df["high"] if "high" in df.columns else df["close"]
        low = df["low"] if "low" in df.columns else df["close"]
        close_prev = df["close"].shift(1)
        tr = pd.concat([
            high - low,
            (high - close_prev).abs(),
            (low - close_prev).abs(),
        ], axis=1).max(axis=1)
        atr = float(tr.tail(14).mean())

        multi = {"BULL": 2.0, "RANGE": 2.5, "BEAR": 3.0, "CRASH": 3.5}.get(regime, 2.5)
        stop_price = current_price - multi * atr
        # V5.2: stop_pct 基于建仓价计算浮盈保护 (entry_price=current_price时退化为原行为)
        ref_price = entry_price if entry_price > 0 else current_price
        stop_pct = round((stop_price / ref_price - 1) * 100, 1)
        unrealized_pnl = round((current_price / ref_price - 1) * 100, 1) if ref_price > 0 else 0.0

        return {
            "atr_value": round(atr, 3),
            "trailing_stop_price": round(stop_price, 2),
            "stop_pct": stop_pct,
            "unrealized_pnl": unrealized_pnl,
            "atr_multiplier": multi,
            "method": "ATR(14)",
        }
    except Exception:
        return _atr_fallback(current_price, entry_price)


def _atr_fallback(price, entry, stop_pct=-8.0):
    """ATR 不可用时的固定百分比回退"""
    return {
        "atr_value": 0,
        "trailing_stop_price": round(price * (1 + stop_pct / 100), 2),
        "stop_pct": stop_pct,
        "atr_multiplier": 2.5,
        "method": "fixed_pct",
    }


MR_POOL = [
    {"code": "510500.SH", "name": "中证500ETF",      "max_pos": 15, "defensive": False},
    {"code": "512100.SH", "name": "中证1000ETF",     "max_pos": 15, "defensive": False},
    {"code": "510300.SH", "name": "沪深300ETF",      "max_pos": 15, "defensive": True},
    {"code": "159915.SZ", "name": "创业板ETF",        "max_pos": 10, "defensive": False},
    {"code": "159949.SZ", "name": "创业板50ETF",      "max_pos": 10, "defensive": False},
    {"code": "588000.SH", "name": "科创50ETF",        "max_pos": 10, "defensive": False},
    {"code": "159781.SZ", "name": "科创创业ETF",      "max_pos": 8,  "defensive": False},
    {"code": "512480.SH", "name": "半导体ETF",        "max_pos": 8,  "defensive": False},
    {"code": "588200.SH", "name": "科创芯片ETF",      "max_pos": 7,  "defensive": False},
    {"code": "159995.SZ", "name": "芯片ETF",          "max_pos": 7,  "defensive": False},
    {"code": "159516.SZ", "name": "半导体设备ETF",    "max_pos": 6,  "defensive": False},
    {"code": "588220.SH", "name": "科创100ETF",       "max_pos": 8,  "defensive": False},
    {"code": "515000.SH", "name": "科技ETF",          "max_pos": 6,  "defensive": False},
    {"code": "515070.SH", "name": "人工智能AIETF",    "max_pos": 6,  "defensive": False},
    {"code": "159819.SZ", "name": "人工智能ETF",      "max_pos": 6,  "defensive": False},
    {"code": "515880.SH", "name": "通信ETF",          "max_pos": 6,  "defensive": False},
    {"code": "562500.SH", "name": "机器人ETF",        "max_pos": 5,  "defensive": False},
    {"code": "512400.SH", "name": "有色金属ETF",      "max_pos": 6,  "defensive": False},
    {"code": "516160.SH", "name": "新能源ETF",        "max_pos": 7,  "defensive": False},
    {"code": "515790.SH", "name": "光伏ETF",          "max_pos": 7,  "defensive": False},
    {"code": "562550.SH", "name": "绿电ETF",          "max_pos": 5,  "defensive": False},
    {"code": "159870.SZ", "name": "化工ETF",          "max_pos": 5,  "defensive": False},
    {"code": "512560.SH", "name": "军工ETF",          "max_pos": 7,  "defensive": True},
    {"code": "159218.SZ", "name": "卫星ETF",          "max_pos": 5,  "defensive": False},
    {"code": "159326.SZ", "name": "电网设备ETF",      "max_pos": 5,  "defensive": True},
    {"code": "159869.SZ", "name": "游戏ETF",          "max_pos": 5,  "defensive": False},
    {"code": "159851.SZ", "name": "金融科技ETF",      "max_pos": 5,  "defensive": False},
    {"code": "159941.SZ", "name": "纳指ETF",          "max_pos": 8,  "defensive": True},
    {"code": "513500.SH", "name": "标普500ETF",       "max_pos": 8,  "defensive": True},
    {"code": "515100.SH", "name": "红利低波100ETF",   "max_pos": 5,  "defensive": True},
    {"code": "159545.SZ", "name": "恒生红利低波ETF",  "max_pos": 5,  "defensive": True},
    {"code": "513130.SH", "name": "恒生科技ETF",      "max_pos": 5,  "defensive": False},
    {"code": "513970.SH", "name": "恒生消费ETF",      "max_pos": 5,  "defensive": False},
    {"code": "513090.SH", "name": "香港证券ETF",      "max_pos": 5,  "defensive": False},
    {"code": "513120.SH", "name": "港股创新药ETF",    "max_pos": 5,  "defensive": False},
]


# ─── 动态参数加载（运行时，无需重启） ─────────────────────────────────────────

def load_regime_params(regime: str = None) -> dict:
    """从版本化运行时配置读取 MR 参数。"""
    if regime:
        return get_mr_params(regime)
    runtime = load_runtime_config()
    mr = runtime["strategies"]["mr"]
    return {
        "regimes": {
            state: {"params": get_mr_params(state)}
            for state in ("BEAR", "RANGE", "BULL")
        },
        "next_optimize_after": mr.get("next_optimize_after"),
        "revision": runtime["revision"],
    }


def needs_reoptimize() -> bool:
    """Return true when any tradable regime lacks effective validation."""
    try:
        return any(
            lifecycle["status"] != "validated"
            for lifecycle in get_all_mr_lifecycle().values()
        )
    except Exception:
        return True


def get_all_regime_params() -> dict:
    """返回三态完整参数摘要（供API和前端使用）"""
    runtime = load_runtime_config()
    lifecycle = get_all_mr_lifecycle()
    return {
        state: {
            "params": get_mr_params(state),
            "optimized_at": lifecycle[state]["validated_at"],
            "lifecycle": lifecycle[state],
            "pos_cap": get_position_cap("mr", state, as_ratio=True),
            "score_gate": get_score_gate("mr", state),
            "revision": runtime["revision"],
        }
        for state in ("BEAR", "RANGE", "BULL")
    }


# ─── 市场状态识别（统一算法，与信号评分系统保持一致） ────────────────────────

def _classify_regime_from_series(close_arr) -> dict:
    """
    统一 Regime 分类算法（所有模块公用）：
      - CRASH: 3日跌幅 > 7%
      - BULL:  close > MA120 AND slope5 > 0 AND ret20 > 0%
      - RANGE: close > MA120（均线走平）OR（close < MA120 AND ret5 > +3%，超跌反弹）
      - BEAR:  close < MA120 AND ret5 <= 3%
    """
    import numpy as np
    close = np.array(close_arr, dtype=float)
    n = len(close)
    rules = get_regime_rules()
    ma_period = int(rules["ma_period"])
    slope_days = int(rules["slope_days"])

    # CRASH 检测
    ret3 = (close[-1] / close[-4] - 1) if n >= 4 else 0
    is_crash = ret3 < float(rules["crash_return_3d"])

    ma120 = close[-ma_period:].mean() if n >= ma_period else close.mean()
    ma60  = close[-60:].mean()  if n >= 60  else close.mean()
    ma120_s = np.array([
        close[max(0, i - ma_period + 1):i + 1].mean()
        for i in range(max(0, n - slope_days - 1), n)
    ])
    slope5 = float(np.polyfit(np.arange(len(ma120_s), dtype=float), ma120_s, 1)[0]) \
             if len(ma120_s) >= 2 else 0.0
    ret5_ratio = float(close[-1] / close[-6] - 1) if n >= 6 else 0.0
    ret20_ratio = float(close[-1] / close[-21] - 1) if n >= 21 else 0.0
    ret5 = ret5_ratio * 100
    ret20 = ret20_ratio * 100
    cur   = float(close[-1])
    above = cur > ma120

    if is_crash:
        regime, regime_cn, rc, ri = "CRASH", "崩盘警戒", "#ef4444", "🚨"
    elif above and slope5 > 0 and ret20_ratio > float(rules["bull_return_20d_min"]):
        regime, regime_cn, rc, ri = "BULL",  "牛市",    "#10b981", "🟢"
    elif above:
        regime, regime_cn, rc, ri = "RANGE", "震荡市",  "#fbbf24", "🟡"
    elif not above and ret5_ratio > float(rules["rebound_return_5d_min"]):
        regime, regime_cn, rc, ri = "RANGE", "震荡反弹","#fb923c", "🟠"
    else:
        regime, regime_cn, rc, ri = "BEAR",  "熊市",    "#ef4444", "🔴"

    return {
        "regime":       regime,
        "regime_cn":    regime_cn,
        "regime_color": rc,
        "regime_icon":  ri,
        "ma60":         round(float(ma60), 2),
        "ma120":        round(float(ma120), 2),
        "slope5":       round(float(slope5), 4),
        "ret5":         round(float(ret5), 2),
        "ret20":        round(float(ret20), 2),
        "above_ma120":  bool(above),   # ← 强制转为 Python bool，避免 numpy.bool_ 序列化失败
        "ma_period":    ma_period,
        "slope_days":   slope_days,
    }


@retry_with_backoff(retries=3, backoff_in_seconds=2)
def detect_regime() -> dict:
    """
    实时识别市场状态（CSI300 指数，000300.SH）
    使用统一三重条件算法，与信号评分系统 /api/v1/market/regime 完全一致。
    加入了指数退避重试，防止网络抖动导致的误判。
    返回：{"regime": ..., "params": {...}, "pos_cap": ..., "score_gate": ...}
    """
    try:
        pro = ts.pro_api(token=TUSHARE_TOKEN)

        end_dt   = datetime.now().strftime("%Y%m%d")
        start_dt = (datetime.now() - pd.Timedelta(days=300)).strftime("%Y%m%d")

        df = pro.index_daily(ts_code="000300.SH", start_date=start_dt, end_date=end_dt,
                             fields="trade_date,close,pct_chg")
        if df is None or df.empty:
            raise ValueError("000300.SH 数据为空")

        df = df.sort_values("trade_date").reset_index(drop=True)
        close_arr = df["close"].astype(float).values

        info    = _classify_regime_from_series(close_arr)
        regime  = info["regime"]
        lifecycle = get_mr_lifecycle(regime)
        params  = load_regime_params(regime)
        pos_cap = get_position_cap("mr", regime, as_ratio=True)
        score_gate = get_score_gate("mr", regime)

        # ── V6.0: AIAE 宏观约束穿透 ──
        # 读取 AIAE 缓存的 matrix_position 和 MR 子策略配额
        # 用 min() 约束: 只可能压低仓位, 不会放大
        aiae_cap_info = ""
        try:
            from services.cache_service import cache_manager
            from aiae_params import SUB_STRATEGY_ALLOC
            aiae_ctx = cache_manager.get_json("aiae_ctx")
            aiae_state = evaluate_aiae_context(aiae_ctx, now_ts=time.time())
            if aiae_state["usable"] and aiae_ctx.get("regime"):
                aiae_regime = aiae_ctx.get("regime", 3)
                matrix_pos = aiae_ctx.get("cap", 55)  # AIAE 总仓位建议
                mr_alloc_pct = SUB_STRATEGY_ALLOC.get(aiae_regime, {}).get("mr", 25) / 100.0
                aiae_mr_cap = matrix_pos * mr_alloc_pct / 100.0  # 转为小数
                if aiae_mr_cap < pos_cap:
                    aiae_cap_info = f"AIAE R{aiae_regime}约束: {pos_cap*100:.0f}%→{aiae_mr_cap*100:.0f}%"
                    pos_cap = aiae_mr_cap
            elif aiae_state["present"]:
                aiae_cap_info = f"AIAE约束未采用: {aiae_state['reason']}"
        except Exception:
            pass  # 缓存不可用时降级为纯 Regime 行为

        return {
            "regime":      regime,
            "regime_cn":   info["regime_cn"],
            "regime_color": info["regime_color"],
            "regime_icon": info["regime_icon"],
            "params":      params,
            "pos_cap":     pos_cap,
            "score_gate":  score_gate,
            "aiae_cap_info": aiae_cap_info,     # V6.0: AIAE 约束详情
            "csi300":      round(float(close_arr[-1]), 2),
            "ma120":       info["ma120"],
            "ma60":        info["ma60"],
            "slope5":      info["slope5"],
            "ret5":        info["ret5"],
            "ret20":       info["ret20"],
            "above_ma120": info["above_ma120"],
            "parameter_lifecycle": lifecycle["status"],
            "allow_new_entries": lifecycle["allow_new_entries"],
            "lifecycle_reason": lifecycle["reason"],
            "parameter_data_through": lifecycle["data_through"],
            "market_data_as_of": str(df["trade_date"].iloc[-1]),
            "needs_reoptimize": needs_reoptimize(),
        }
    except Exception as e:
        lifecycle = get_mr_lifecycle("RANGE")
        return {
            "regime":     "RANGE",
            "regime_cn":  "震荡市",
            "params":     get_mr_params("RANGE"),
            "pos_cap":    get_position_cap("mr", "RANGE", as_ratio=True),
            "score_gate": get_score_gate("mr", "RANGE"),
            "parameter_lifecycle": lifecycle["status"],
            "allow_new_entries": False,
            "lifecycle_reason": lifecycle["reason"],
            "parameter_data_through": lifecycle["data_through"],
            "needs_reoptimize": True,
            "error":      str(e),
        }



# ─── 核心策略计算 ─────────────────────────────────────────────────────────────

def calculate_indicators(df: pd.DataFrame, regime_info: dict = None) -> dict:
    close  = df["close"]
    volume = df["vol"] if "vol" in df.columns else df["volume"]

    # V4.2: regime_info 可外部注入，避免循环内重复调用 API
    if regime_info is None:
        regime_info = detect_regime()
    p = regime_info["params"]
    N = p.get("N_trend", 90)
    rsi_p = p.get("rsi_period", 14)

    ma20 = close.rolling(20).mean()
    ma_n = close.rolling(N).mean()   # 趋势均线（Regime专属）
    boll_std   = close.rolling(20).std()
    boll_upper = ma20 + 2 * boll_std
    boll_lower = ma20 - 2 * boll_std
    boll_diff  = boll_upper - boll_lower
    
    # 修复除零错误：当波动为 0 时，boll_diff可能为0甚至NaN
    percent_b  = np.where(
        boll_diff > 1e-6,
        (close - boll_lower) / np.where(boll_diff > 1e-6, boll_diff, 1e-6),
        0.5
    )

    # RSI（Wilder 平滑，用 Regime 指定周期）
    delta    = close.diff(1)
    gain     = delta.where(delta > 0, 0.0)
    loss     = -delta.where(delta < 0, 0.0)
    avg_gain = gain.ewm(span=rsi_p, min_periods=rsi_p, adjust=False).mean()
    avg_loss = loss.ewm(span=rsi_p, min_periods=rsi_p, adjust=False).mean()
    rs       = avg_gain / avg_loss.replace(0, 0.001)
    rsi      = 100 - (100 / (1 + rs))

    # 保留 RSI(3) 辅助展示
    avg_g3 = gain.rolling(3).mean()
    avg_l3 = loss.rolling(3).mean()
    rsi_3  = 100 - (100 / (1 + avg_g3 / avg_l3.replace(0, 0.001)))

    # BIAS 相对趋势均线
    bias      = (close - ma_n) / ma_n * 100
    deviation = ((close - ma20) / ma20).abs() * 100

    vol_ma5   = volume.rolling(5).mean()
    vol_ratio = (volume / vol_ma5.replace(0, 1)).clip(0, 10)

    # V4.2 新增 ①：RSI 5日动量斜率（判断超卖是否开始反转）
    rsi_slope5 = 0.0
    if len(rsi.dropna()) >= 6:
        rsi_slope5 = float(rsi.iloc[-1] - rsi.iloc[-6])

    # V4.2 新增 ②：K线形态识别（锤子线 / 十字星 / 下影线）
    kline_pattern = "neutral"
    kline_score_val = 0
    if "open" in df.columns and "high" in df.columns and "low" in df.columns:
        lw = df.iloc[-1]
        rng = lw["high"] - lw["low"]
        if rng > 1e-6:
            body_ratio   = abs(lw["open"] - lw["close"]) / rng
            lower_shadow = (min(lw["open"], lw["close"]) - lw["low"]) / rng
            if lower_shadow >= 0.6 and body_ratio <= 0.3:
                kline_pattern = "hammer";    kline_score_val = 5
            elif lower_shadow >= 0.4:
                kline_pattern = "shadow";    kline_score_val = 3
            elif body_ratio <= 0.15:
                kline_pattern = "doji";      kline_score_val = 2

    latest = df.iloc[-1]
    return {
        "close":           float(latest["close"]),
        "ma20":            float(ma20.iloc[-1]) if not ma20.isnull().all() else 0,
        "ma_n":            float(ma_n.iloc[-1]) if not ma_n.isnull().all() else 0,
        "ma60":            float(close.rolling(60).mean().iloc[-1]),
        "boll_upper":      float(boll_upper.iloc[-1]) if not boll_upper.isnull().all() else 0,
        "boll_lower":      float(boll_lower.iloc[-1]) if not boll_lower.isnull().all() else 0,
        "percent_b":       float(percent_b[-1]) if hasattr(percent_b, '__len__') else 0,
        "rsi":             float(rsi.iloc[-1]) if not rsi.isnull().all() else 50,
        "rsi_3":           float(rsi_3.iloc[-1]) if not rsi_3.isnull().all() else 50,
        "rsi_slope5":      round(rsi_slope5, 2),          # V4.2 新增
        "bias":            float(bias.iloc[-1]) if not bias.isnull().all() else 0,
        "deviation":       float(deviation.iloc[-1]) if not deviation.isnull().all() else 0,
        "vol_ratio":       float(vol_ratio.iloc[-1]) if not vol_ratio.isnull().all() else 1,
        "kline_pattern":   kline_pattern,                  # V4.2 新增
        "kline_score":     kline_score_val,                # V4.2 新增
        "regime":          regime_info["regime"],
        "regime_params":   p,
        "pos_cap":         regime_info["pos_cap"],
        "score_gate":      regime_info["score_gate"],
        "needs_reopt":     regime_info.get("needs_reoptimize", False),
        "parameter_lifecycle": regime_info.get("parameter_lifecycle", "stale"),
        "allow_new_entries": regime_info.get("allow_new_entries", False),
        "lifecycle_reason": regime_info.get("lifecycle_reason", "lifecycle_missing"),
        "parameter_data_through": regime_info.get("parameter_data_through"),
    }


def _sigmoid_score(x, center, steepness, max_score):
    """V4.3 通用Sigmoid映射：center=半分位, steepness=斜率（正值=越小x越高分）"""
    return float(max_score / (1 + np.exp(steepness * (x - center))))


def calculate_score(indicators: dict, code: str = "", name: str = "") -> dict:
    """
    V22.0 评分：7维度100分制 · Sigmoid连续映射 · 资产类别差异化参数

    升级：
      - ① ~ ⑥ Sigmoid 连续函数（V4.3）
      - V22.0: 按资产类别（个股/行业ETF/宽基ETF/海外ETF）使用差异化阈值
    """
    # V22.0: 优先使用资产类别差异化参数
    regime = indicators.get("regime", "RANGE")
    p = get_asset_params(code, regime, name) if code else indicators.get("regime_params", FALLBACK_PARAMS["RANGE"])
    rsi_buy_opt  = p.get("rsi_buy", 40)
    bias_buy_opt = p.get("bias_buy", -2.0)

    rsi        = indicators["rsi"]
    bias       = indicators["bias"]
    pb         = indicators["percent_b"]
    vr         = indicators["vol_ratio"]
    close      = indicators["close"]
    ma_n       = indicators["ma_n"]
    rsi_slope5 = indicators.get("rsi_slope5", 0.0)
    kline_sc   = indicators.get("kline_score", 0)

    # ① RSI 超卖深度（0-25）—— Sigmoid：以 rsi_buy_opt+5 为中心，RSI越低分越高
    s1 = _sigmoid_score(rsi, center=rsi_buy_opt + 5, steepness=0.3, max_score=25)

    # ② RSI 动量方向（0-15）—— 反向Sigmoid：slope越大越好（底部反转信号）
    s2 = float(15 / (1 + np.exp(-1.5 * (rsi_slope5 - 1.5))))

    # ③ BIAS 乖离率（0-20）—— Sigmoid：以 bias_buy_opt*0.6 为中心，BIAS越负分越高
    s3 = _sigmoid_score(bias, center=bias_buy_opt * 0.6, steepness=0.8, max_score=20)

    # ④ 布林带 %B（0-15）—— Sigmoid：%B越低分越高
    s4 = _sigmoid_score(pb, center=0.25, steepness=8.0, max_score=15)

    # ⑤ 成交量信号（0-10）—— V型Sigmoid：恐慌放量 OR 绝望缩量都给高分
    s5_high = float(10 / (1 + np.exp(-3.0 * (vr - 1.8))))   # 放量信号
    s5_low  = float(10 / (1 + np.exp(5.0 * (vr - 0.55))))   # 缩量信号
    s5_mid  = 3.0 if 0.8 <= vr <= 1.3 else 0.0               # 平量中性
    s5 = max(s5_high, s5_low, s5_mid)

    # ⑥ 趋势位置（0-10）—— Sigmoid：close vs ma_n 的百分比偏离
    trend_pct = (close / ma_n - 1) * 100 if ma_n > 0 else 0
    s6 = float(10 / (1 + np.exp(-1.5 * (trend_pct + 1))))

    # ⑦ K线形态（0-5）—— 保持离散（形态分类天然离散）
    s7 = min(5, kline_sc)

    total = min(100, round(s1 + s2 + s3 + s4 + s5 + s6 + s7))

    return {
        "total":       total,
        "breakdown": {
            "rsi_depth":   round(s1, 1),   # ① RSI超卖深度
            "rsi_momentum":round(s2, 1),   # ② RSI动量方向
            "bias":        round(s3, 1),   # ③ BIAS乖离率
            "boll":        round(s4, 1),   # ④ 布林带%B
            "volume":      round(s5, 1),   # ⑤ 成交量
            "trend":       round(s6, 1),   # ⑥ 趋势位置
            "kline":       round(s7, 1),   # ⑦ K线形态
        }
    }


def generate_research_signal(indicators: dict, score: int) -> str:
    """
    V4.3 信号生成 — score 为总分整数，从 Regime 专属参数读取阈值
    升级：trend_ok 按 Regime 差异化宽度 + stop_loss 正负兼容
    """
    import math
    try:
        if (not all(math.isfinite(float(indicators[k])) for k in ("close", "ma20", "ma_n", "rsi", "bias", "percent_b"))
                or not math.isfinite(float(score)) or min(indicators["close"], indicators["ma20"], indicators["ma_n"]) <= 0):
            return "error"
    except (KeyError, TypeError, ValueError):
        return "error"
    p = indicators.get("regime_params", FALLBACK_PARAMS["RANGE"])

    close    = indicators["close"]
    ma20     = indicators["ma20"]
    ma_n     = indicators["ma_n"]
    rsi      = indicators["rsi"]
    bias     = indicators["bias"]
    pb       = indicators["percent_b"]
    regime   = indicators.get("regime", "RANGE")
    score_gate = indicators.get("score_gate", 68)

    rsi_buy  = p["rsi_buy"]
    rsi_sell = p["rsi_sell"]
    bias_buy = p["bias_buy"]
    sl       = abs(p.get("stop_loss", 0.07))   # V4.3: abs() 兼容正负号

    # V4.3: stop_loss 统一用 abs 比较
    cost_price = indicators.get("cost_price")
    if cost_price and cost_price > 0:
        ret = (close / cost_price) - 1
        if ret <= -sl:
            return "stop_loss"

    # Exit paths always remain active, even when entry parameters are stale.
    if rsi >= rsi_sell:
        return "sell"

    if close >= ma20 and pb > 0.6:
        return "sell_half"

    if score < score_gate * 0.75:
        return "sell_weak"

    # CRASH and a weak BULL score block entries only after all exits were checked.
    if regime == "CRASH":
        return "no_entry"
    if regime == "BULL" and score < score_gate:
        return "hold"

    # V4.3: trend_ok 按 Regime 差异化宽度
    #   BEAR: 允许5%偏离（熊市超跌是主战场，不能过滤掉）
    #   RANGE: 标准（必须站上均线）
    #   BULL: 收紧（必须站上均线2%以上，确认趋势后才做回归）
    if regime == "BEAR":
        trend_ok = close > ma_n * 0.95
    elif regime == "BULL":
        trend_ok = close > ma_n * 1.02
    else:
        trend_ok = close > ma_n

    if trend_ok and (rsi <= rsi_buy or bias <= bias_buy) and score >= score_gate:
        return "buy"

    return "hold"


def generate_signal(indicators: dict, score: int) -> str:
    research = generate_research_signal(indicators, score)
    if research == "buy" and not indicators.get("allow_new_entries", False):
        return "no_entry"
    return research


def _fetch_and_calc_mr(code, regime_info, start_date, end_date, pro):
    """并发拉取与计算单只ETF的原子函数"""
    try:
        cache_file = f"data_lake/daily_prices/{code}.parquet"
        df = None
        # 尝试API获取
        try:
            df = pro.fund_daily(ts_code=code, start_date=start_date, end_date=end_date)
            if df is not None and not df.empty:
                # 2026-10-31: fund_daily 为未复权价; 按交易所 pre_close 前复权后再计算与缓存,
                # 份额拆分不再伪造均线乖离/暴跌 (最新价不变, 原始价保留在 raw_close)
                df = _forward_adjust(df.sort_values("trade_date").reset_index(drop=True))
                os.makedirs(os.path.dirname(cache_file), exist_ok=True)
                df.to_parquet(cache_file) # 缓存
        except Exception as api_e:
            # API失败，尝试本地缓存托底
            if os.path.exists(cache_file):
                df = _forward_adjust(pd.read_parquet(cache_file))
            else:
                raise ValueError(f"无API数据且无本地缓存: {api_e}")
                
        if df is None or df.empty:
            return {"ts_code": code, "signal": "error", "error": "数据为空"}

        name = next((e["name"] for e in MR_POOL if e["code"] == code), code)
        source_stat = os.stat(cache_file)
        source_data_signature = [source_stat.st_mtime_ns, source_stat.st_size]
        indicators  = calculate_indicators(df, regime_info=regime_info)
        score_dict  = calculate_score(indicators, code=code, name=name)  # V22.0: 资产类别差异化
        score       = score_dict["total"]
        breakdown   = score_dict["breakdown"]
        signal      = generate_signal(indicators, score)
        research_signal = generate_research_signal(indicators, score)
        from services.decision_policy import model_fingerprint
        source_model_hash = model_fingerprint(engine_hash=_LOADED_ENGINE_HASH,
                                             asset_params=_ASSET_PARAMS_CACHE or {})

        name = next((e["name"] for e in MR_POOL if e["code"] == code), code)

        # V22.0: 动态仓位 + ATR 追踪止盈
        regime = indicators.get("regime", "RANGE")
        dyn_cap = dynamic_position_cap(code, name, regime)
        # V5.2: 从持仓缓存读取实际建仓成本价 (无持仓时退化为当前价)
        _entry_price = indicators["close"]
        try:
            from services.cache_service import cache_manager as _cm
            _portfolio = _cm.get_json("portfolio_store", {})
            for _h in _portfolio.get("holdings", []):
                if _h.get("code", "").startswith(code.split(".")[0]):
                    _entry_price = float(_h.get("cost_price", indicators["close"]))
                    break
        except Exception:
            pass
        atr_stop = compute_atr_trailing_stop(code, indicators["close"],
                                             _entry_price, regime)

        return {
            "ts_code":       code,
            "name":          name,
            "signal":        signal,
            "research_signal": research_signal,
            "data_as_of": str(df["trade_date"].iloc[-1]),
            "signal_as_of": datetime.now().isoformat(),
            "source_config_hash": regime_info.get("source_config_hash"),
            "source_model_hash": source_model_hash,
            "source_data_signature": source_data_signature,
            "market_data_as_of": regime_info.get("market_data_as_of"),
            "regime_data_status": "unavailable" if regime_info.get("error") else "available",
            "parameter_lifecycle": indicators.get("parameter_lifecycle", "stale"),
            "allow_new_entries": indicators.get("allow_new_entries", False),
            "lifecycle_reason": indicators.get("lifecycle_reason", "lifecycle_missing"),
            "parameter_data_through": indicators.get("parameter_data_through"),
            "signal_score":  score,
            "score_breakdown": breakdown,
            "rsi":           round(indicators["rsi"], 1),
            "rsi_3":         round(indicators["rsi_3"], 1),
            "rsi_slope5":    round(indicators.get("rsi_slope5", 0), 2),
            "kline_pattern": indicators.get("kline_pattern", "neutral"),
            "bias":          round(indicators["bias"], 2),
            "percent_b":     round(indicators["percent_b"], 3),
            "vol_ratio":     round(indicators["vol_ratio"], 2),
            "close":         round(indicators["close"], 3),
            "ma20":          round(indicators["ma20"], 3),
            "ma_n":          round(indicators["ma_n"], 3),
            "regime":        regime,
            "regime_params": indicators["regime_params"],
            "pos_cap":       indicators["pos_cap"],
            # V22.0: 动态仓位 + ATR 追踪止盈
            "dynamic_pos_cap": round(dyn_cap, 1),
            "asset_class":     get_asset_class_label(code, name),
            "atr_trailing":    atr_stop,
            "score_gate":    indicators["score_gate"],
            "needs_reopt":   indicators["needs_reopt"],
        }
    except Exception as e:
        name = next((e["name"] for e in MR_POOL if e["code"] == code), code)
        return {
            "ts_code": code, "name": name,
            "signal": "error", "signal_score": 0,
            "error": str(e),
        }

def run_strategy(ts_codes: list = None, regime_override: str = None) -> list:
    """主策略入口 — V5.0 并发版本"""
    pro = ts.pro_api(token=TUSHARE_TOKEN)

    pool = ts_codes if ts_codes else [e["code"] for e in MR_POOL]
    results = []
    end_date   = datetime.now().strftime("%Y%m%d")
    start_date = "20230101"

    from services.strategy_params import load_runtime_config
    from services.decision_policy import fingerprint
    initial_config_hash = fingerprint(load_runtime_config())
    # V4.2: Regime 只识别一次
    regime_info = detect_regime()
    regime_info["source_config_hash"] = initial_config_hash

    # V5.0: 使用线程池并发抓取与计算
    with ThreadPoolExecutor(max_workers=10) as executor:
        futures = [executor.submit(_fetch_and_calc_mr, code, regime_info, start_date, end_date, pro) for code in pool]
        for future in as_completed(futures):
            results.append(future.result())

    if fingerprint(load_runtime_config()) != initial_config_hash:
        for result in results:
            result["regime_data_status"] = "unavailable"
    return sorted(results, key=lambda x: x.get("signal_score", 0), reverse=True)
