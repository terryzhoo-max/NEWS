"""
AlphaCore V22.0 · 预交易合规检查引擎 (Pre-Trade Compliance Engine)
==================================================================
从"展示风控"升级为"执行风控" — 每个交易决策在输出前必须通过合规检查。

规则类型:
  - hard_block: 硬阻断 — 该操作在当前市场环境下被系统禁止
  - soft_warn:  软警告 — 操作可以执行但需谨慎
  - info:       提示    — 仅供参考

规则来源: V3.0 策略协议 + V19.1 风控护栏 + V21.2 预警阈值
"""

from dataclasses import dataclass, field
from typing import Callable, Optional
from dashboard_modules.decision.quality import finite_number


@dataclass
class ComplianceRule:
    id: str
    name: str
    severity: str  # "hard_block" | "soft_warn" | "info"
    description: str
    check_fn: Callable  # (snapshot, positions, context) -> (passed: bool, detail: str)

    def check(self, snapshot: dict, positions: list = None, context: dict = None) -> dict:
        """执行检查, 返回 {passed, detail, rule_id, severity}"""
        try:
            passed, detail = self.check_fn(snapshot, positions, context)
            evaluation_status = "evaluated"
        except Exception as e:
            passed, detail = False, f"规则执行异常，未通过校验: {e}"
            evaluation_status = "error"
        return {
            "rule_id": self.id,
            "rule_name": self.name,
            "severity": self.severity,
            "passed": passed,
            "detail": detail,
            "evaluation_status": evaluation_status,
        }


# ═══════════════════════════════════════════════════════════
#  规则定义
# ═══════════════════════════════════════════════════════════

# 单一发行人限额 (个股) 与单只基金限额 (ETF) 分开: ETF 本身是一篮子成分股, 没有单一发行人风险;
# 它的集中度风险由"主题集中度"规则按穿透后的主题统计。
SINGLE_STOCK_CAP_PCT = 20.0
SINGLE_FUND_CAP_PCT = 35.0


def _is_fund(position) -> bool:
    try:
        from services.concentration import _is_etf
        return _is_etf(str(position.get("ts_code") or position.get("code") or ""))
    except Exception:
        return False


def _check_single_stock_cap(snapshot, positions, ctx):
    """单一个股 ≤ 20%、单只 ETF ≤ 35% (硬阻断)"""
    if not positions:
        if ((ctx or {}).get("current_position") or 0) > 0:
            return False, "账户有风险资产敞口但缺少持仓明细，无法核验单票集中度"
        return True, "无持仓数据"
    over = []
    for p in positions:
        w = finite_number(p.get("weight"))
        if w is None or w < 0:
            return False, "持仓权重缺失或无效，无法核验单票限额"
        fund = _is_fund(p)
        cap = SINGLE_FUND_CAP_PCT if fund else SINGLE_STOCK_CAP_PCT
        if w > cap:
            kind = "ETF" if fund else "个股"
            over.append(f"{p.get('name', p.get('ts_code', '?'))} {w:.1f}% (>{kind}上限{cap:g}%)")
    if over:
        pre = "成交后" if (ctx or {}).get("order") else ""
        return False, f"{pre}超配标的: {', '.join(over[:3])}"
    return True, f"个股 ≤ {SINGLE_STOCK_CAP_PCT:g}%，ETF ≤ {SINGLE_FUND_CAP_PCT:g}%"


THEME_LIMIT_PCT = 40.0
THEME_DANGER_PCT = 60.0


# 2026-11-04 C2: 按名称归类 (非穿透) 的原因 → 中文
FALLBACK_REASON_LABELS = {
    "CONSTITUENT_ETF_NOT_FOUND": "未登记成分",
    "CONSTITUENT_SNAPSHOT_MISSING": "成分快照缺失",
    "SNAPSHOT_MISSING": "成分快照缺失",
    "CONSTITUENT_SNAPSHOT_INVALID": "成分快照无效",
    "SNAPSHOT_INVALID": "成分快照无效",
    "CONSTITUENT_SNAPSHOT_INTEGRITY_FAILED": "成分快照校验失败",
    "INDEX_WEIGHT_STALE": "成分权重过期",
    "FUND_HOLDINGS_STALE": "基金持仓过期",
    "CONSTITUENT_LOOKUP_ERROR": "成分查询失败",
    "CONSTITUENTS_UNAVAILABLE": "成分不可用",
    "WEIGHTS_EXCEED_100": "成分权重合计超过 100%",
    "INDEX_WEIGHT_COVERAGE_BELOW_100": "成分权重未覆盖部分",
    "FUND_HOLDINGS_UNDISCLOSED_REMAINDER": "基金报告未披露部分",
    "KEYWORD_BASIS": "配置为按名称归类",
}
# 只是权重未覆盖的余量 (成分本身可用), 与"整只按名称归类"分开列示
PARTIAL_FALLBACK_REASONS = {"INDEX_WEIGHT_COVERAGE_BELOW_100", "FUND_HOLDINGS_UNDISCLOSED_REMAINDER"}


def _fallback_reason(row_basis: str) -> Optional[str]:
    """theme_rows 的 basis → 按名称归类的原因码; 非名称归类 → None。个股 / override / 宽基固收不算。"""
    b = str(row_basis or "")
    if b.startswith("etf_name_fallback:"):
        return b.split(":", 1)[1] or "CONSTITUENTS_UNAVAILABLE"
    if b == "etf_name":
        return "KEYWORD_BASIS"
    return None


def _theme_analysis(positions) -> dict:
    """持仓 → 主题拆分 + 口径明细 (2026-11-04 C2)。

    返回 {"buckets": {主题: 占账户%}, "name_fallback": [...], "unknown_industry": [...], "basis": ...}。
    buckets 与原 _theme_buckets 完全相同 (判定口径不变); 另两项只把同一组 theme_rows 的来源带出:
      · name_fallback: 未穿透、按 ETF 名称归类的部分 (按 ETF 汇总; whole=整只未穿透, 否则为权重未覆盖余量);
      · unknown_industry: 穿透到公司但行业表无行业的部分 (按 ETF 汇总), 不计入任何主题。"""
    overrides, exempt, basis = {}, {"宽基指数", "固收现金"}, "lookthrough"
    try:
        from services import concentration as cc
        cfg = cc.load_concentration_config()
        overrides = cfg.get("theme_overrides") or {}       # 与主题集中度面板同一份手工归类
        exempt |= set(cfg.get("exempt_themes") or []) | {cc.UNKNOWN_INDUSTRY_THEME}
        basis = "keyword" if str(cfg.get("classification_basis") or "").lower() == "keyword" else "lookthrough"
    except Exception:
        cc = None
    holdings, own_industry = [], {}
    for p in positions:
        code = str(p.get("ts_code") or p.get("code") or "")
        holdings.append({"ts_code": code, "name": p.get("name", ""), "value": finite_number(p.get("weight")) or 0.0})
        if p.get("industry"):
            own_industry[code] = p["industry"]
    out = {"buckets": {}, "name_fallback": [], "unknown_industry": [], "basis": basis}
    buckets = out["buckets"]
    if cc is None:
        for h in holdings:
            theme = own_industry.get(h["ts_code"]) or "未分类"
            buckets[theme] = buckets.get(theme, 0.0) + h["value"]
        out["basis"] = "unavailable"
        return out
    industry_map = {**(cc.cached_industry_map() if basis == "lookthrough" else {}), **own_industry}
    fb, unk = {}, {}
    for r in cc.theme_rows(holdings, industry_map, overrides, basis=basis):
        reason = _fallback_reason(r.get("basis"))
        if reason:
            e = fb.setdefault(r["ts_code"], {"ts_code": r["ts_code"], "name": r.get("name", r["ts_code"]),
                                             "pct": 0.0, "theme": r["theme"], "reasons": set(),
                                             "exempt": r["theme"] in exempt})
            e["pct"] += r["value"]
            e["reasons"].add(reason)
        if r["theme"] == cc.UNKNOWN_INDUSTRY_THEME:
            e = unk.setdefault(r["ts_code"], {"ts_code": r["ts_code"], "name": r.get("name", r["ts_code"]), "pct": 0.0})
            e["pct"] += r["value"]
        if r["theme"] in exempt:
            continue
        buckets[r["theme"]] = buckets.get(r["theme"], 0.0) + r["value"]
    out["buckets"] = {k: round(v, 4) for k, v in buckets.items()}
    for e in fb.values():
        reasons = sorted(e.pop("reasons"))
        e["whole"] = not set(reasons) <= PARTIAL_FALLBACK_REASONS
        e["reason"] = reasons[0] if len(reasons) == 1 else ",".join(reasons)
        e["reason_label"] = "、".join(FALLBACK_REASON_LABELS.get(x, x) for x in reasons)
        e["pct"] = round(e["pct"], 2)
    out["name_fallback"] = sorted(fb.values(), key=lambda x: -x["pct"])
    out["unknown_industry"] = sorted(({**e, "pct": round(e["pct"], 2)} for e in unk.values()), key=lambda x: -x["pct"])
    return out


def _theme_buckets(positions):
    """持仓 → {主题: 权重% (占账户)}。宽基与固收不受主题上限约束。

    口径与主题集中度面板一致 (services.concentration.theme_rows, 配置 classification_basis):
      · lookthrough (默认, 2026-10-29 用户决定): ETF 按已核验成分拆到公司 → 行业 → 主题;
        成分不可用或未披露余量按 ETF 名称关键词保守回退 (不当作零暴露);
      · keyword: ETF 按名称整只归类。个股按行业映射。阈值不随口径变化。"""
    return _theme_analysis(positions)["buckets"]


def _unknown_total(analysis) -> float:
    return round(sum(e["pct"] for e in (analysis or {}).get("unknown_industry") or []), 2)


def unknown_crossing(top_pct: float, unknown_pct: float) -> Optional[float]:
    """2026-11-04 C2 规则: 穿透值未超阈值, 而 穿透值 + 行业未知 超过 → 返回被跨过的阈值 (60 优先), 否则 None。

    行业未知按最坏情况全部计入最大主题; 只用于"至少警告", 不升级为硬阻断。"""
    adj = (top_pct or 0.0) + (unknown_pct or 0.0)
    for th in (THEME_DANGER_PCT, THEME_LIMIT_PCT):
        if top_pct <= th < adj:
            return th
    return None


def order_themes(positions, ctx) -> list:
    """2026-11-02 项 2: 买入订单 (成交后检查) 新增暴露的主题 → [(主题, 成交后占账户%)]。

    只在 direction=increase 且上下文带订单与成交前持仓 (ctx.order / ctx.pre_positions) 时计算; 否则 []。"""
    c = ctx or {}
    if c.get("direction") != "increase" or not c.get("order") or c.get("pre_positions") is None:
        return []
    post = _theme_buckets(positions or [])
    pre = _theme_buckets(c.get("pre_positions") or [])
    return sorted(((t, v) for t, v in post.items() if v - pre.get(t, 0.0) > 1e-6), key=lambda x: -x[1])


def _order_theme_breach(positions, ctx):
    """买入方向: 成交后订单所在主题 > 40% → (主题, 占比), 硬阻断 (规则原文"禁止新增该主题")。"""
    for theme, pct in order_themes(positions, ctx):
        if pct > THEME_LIMIT_PCT:
            return theme, pct
    return None


def _check_sector_concentration(snapshot, positions, ctx):
    """单一主题 (ETF 穿透成分, 不可用时按名称回退; 个股按行业) ≤ 40% 软警告, > 60% 硬阻断;
    买入订单 (成交后检查) 使所在主题 > 40% → 硬阻断。
    2026-11-04 C2: 穿透值未超 40% / 60%, 而 穿透值 + 行业未知 超过 → 至少软警告 (判定只多不少)。"""
    if not positions:
        return True, "无持仓数据"
    analysis = _theme_analysis(positions)
    buckets = analysis["buckets"]
    unknown = _unknown_total(analysis)
    unk_note = f"（另有穿透后行业未知 {unknown:.1f}%）" if unknown >= 0.05 else ""
    if not buckets:
        if unknown > THEME_LIMIT_PCT:
            return False, f"穿透后行业未知 {unknown:.1f}% > {THEME_LIMIT_PCT:.0f}%：无法确认主题集中度，按警告处理，核对成分行业"
        return True, "无受主题上限约束的持仓"
    theme, pct = max(buckets.items(), key=lambda x: x[1])
    pre = "成交后" if (ctx or {}).get("order") else ""
    if pct > THEME_DANGER_PCT:
        return False, (f"{pre}「{theme}」主题占账户 {pct:.0f}% > {THEME_DANGER_PCT:.0f}% 严重集中: "
                       f"禁止新增该主题, 按分批路径降至 {THEME_LIMIT_PCT:.0f}% 以内{unk_note}")
    breach = _order_theme_breach(positions, ctx)
    if breach:
        return False, (f"成交后「{breach[0]}」主题占账户 {breach[1]:.0f}% > {THEME_LIMIT_PCT:.0f}% 红线: "
                       f"禁止新增该主题{unk_note}")
    if pct > THEME_LIMIT_PCT:
        crossed = unknown_crossing(pct, unknown)
        extra = (f"；穿透值 + 行业未知 {pct + unknown:.1f}% > {crossed:.0f}%，核对成分行业" if crossed else unk_note)
        return False, f"「{theme}」主题集中度 {pct:.0f}% > {THEME_LIMIT_PCT:.0f}% 红线, 禁止新增该主题{extra}"
    crossed = unknown_crossing(pct, unknown)
    if crossed:
        return False, (f"{pre}「{theme}」主题穿透 {pct:.1f}% 未超 {THEME_LIMIT_PCT:.0f}%，但穿透后行业未知 {unknown:.1f}%，"
                       f"合计 {pct + unknown:.1f}% > {crossed:.0f}%：按警告处理，核对成分行业后再新增该主题")
    if pct > 30:
        return True, f"「{theme}」主题 {pct:.0f}%, 接近 {THEME_LIMIT_PCT:.0f}% 红线，谨慎增持{unk_note}"
    return True, f"主题分散度正常{unk_note}"


def theme_metrics(positions) -> Optional[dict]:
    """主题集中度的结构化读数 (2026-11-02 首页口径统一 A1): 与 _check_sector_concentration 同一份 _theme_buckets。

    只是把判定所用的数字原样带出, 供首页 / 决策中枢 / 审计页直接读取, 不参与判定、不另设阈值。
    分母 = 账户总资产 (positions[*].weight), 宽基 / 固收 / 无行业数据部分不计入主题上限。
    无持仓或计算失败 → None。
    """
    if not positions:
        return None
    try:
        analysis = _theme_analysis(positions)
    except Exception:
        return None
    buckets = analysis["buckets"]
    ranked = sorted(buckets.items(), key=lambda x: x[1], reverse=True)
    top_theme, top_pct = ranked[0] if ranked else (None, 0.0)
    if top_pct > THEME_DANGER_PCT:
        level = "hard_block"
    elif top_pct > THEME_LIMIT_PCT:
        level = "breach"
    elif top_pct > 30:
        level = "near"
    else:
        level = "ok"
    return {
        "basis": "account",
        "basis_label": "占账户",
        "top_theme": top_theme,
        "top_pct": round(top_pct, 1),
        "limit_pct": THEME_LIMIT_PCT,
        "danger_pct": THEME_DANGER_PCT,
        "level": level,
        "themes": [{"theme": t, "pct": round(p, 1)} for t, p in ranked[:5]],
        # 2026-11-04 C2: 口径明细 (只读, 与判定同一组 theme_rows)
        **_basis_readout(analysis, top_pct),
    }


def _basis_readout(analysis, top_pct) -> dict:
    """name_fallback / unknown_industry 读数 + 一行说明 (组合页 / 决策中枢 / 审计页 / 首页共用同一字符串)。"""
    fb = analysis.get("name_fallback") or []
    unk = analysis.get("unknown_industry") or []
    unknown = _unknown_total(analysis)
    whole = [e for e in fb if e["whole"]]
    partial = [e for e in fb if not e["whole"]]
    crossed = unknown_crossing(top_pct, unknown)
    parts = []
    if analysis.get("basis") == "keyword":
        parts.append("配置为按名称归类，非穿透")
    elif whole:
        parts.append("按名称归类，非穿透：" + "，".join(
            f"{e['name']} {e['pct']:.1f}%（{e['reason_label']}{'，宽基不计入上限' if e['exempt'] else ''}）" for e in whole))
    else:
        parts.append("持仓 ETF 均按成分穿透")
    partial_pct = round(sum(e["pct"] for e in partial), 2)
    if partial_pct >= 0.05:
        parts.append(f"成分权重未覆盖部分 {partial_pct:.1f}% 按名称归类")
    if unk:
        parts.append("穿透后行业未知 " + f"{unknown:.1f}%：" + "，".join(f"{e['name']} {e['pct']:.1f}%" for e in unk))
    else:
        parts.append("穿透后行业未知 0%")
    if crossed:
        parts.append(f"穿透值 + 行业未知 {top_pct + unknown:.1f}% > {crossed:.0f}%，至少警告")
    return {
        "classification_basis": analysis.get("basis"),
        "name_fallback": fb,
        "name_fallback_pct": round(sum(e["pct"] for e in whole), 2),
        "unknown_industry": unk,
        "unknown_industry_pct": unknown,
        "unknown_adjusted_pct": round(top_pct + unknown, 1),
        "unknown_warn": bool(crossed),
        "basis_note": "；".join(parts),
    }


class _ThemeConcentrationRule(ComplianceRule):
    """> 40% 软警告; > 60% 升级为硬阻断 (与单票/仓位上限同级)。"""

    def check(self, snapshot: dict, positions: list = None, context: dict = None) -> dict:
        try:
            top = max(_theme_buckets(positions or []).values(), default=0.0)
            breach = _order_theme_breach(positions, context)
        except Exception:
            top, breach = 0.0, None
        self.severity = "hard_block" if (top > THEME_DANGER_PCT or breach) else "soft_warn"
        result = super().check(snapshot, positions, context)
        try:
            themes = order_themes(positions, context)
        except Exception:
            themes = []
        if themes:
            result["order_themes"] = [{"theme": t, "pct": round(p, 1)} for t, p in themes]
        # A1: 附带结构化读数 (与判定同源), 首页等页面直接读取; 判定逻辑不变
        result["metrics"] = theme_metrics(positions or [])
        return result


def _aiae_regime(snapshot):
    """AIAE 档位 1–5 (整数); 缺失 / 非数 / 越界 → None。不默认 R3。"""
    raw = (snapshot or {}).get("aiae_regime")
    if isinstance(raw, bool):
        return None
    v = finite_number(raw)
    if v is None or v != int(v) or not 1 <= v <= 5:
        return None
    return int(v)


def _check_aiae_overheat(snapshot, positions, ctx):
    """AIAE ≥ R4 时禁止新建仓 (硬阻断)。

    2026-11-03: 档位缺失 / 无效时不再默认 R3 放行 (fail open)。加仓方向按阻断处理, 与预热期、买入门控
    "数据缺失即不放行买入"一致; 减仓 / 持有方向不受限 (缺失只是读数不可用, 不构成减仓障碍)。"""
    if snapshot.get("decision_locked") is True:
        return False, "AIAE 数据缺失、陈旧或质量不足，决策已锁定"
    direction = ctx.get("direction", "hold") if ctx else "hold"
    regime = _aiae_regime(snapshot)
    if regime is None:
        if direction == "increase":
            return False, "AIAE 档位缺失或无效，无法核验过热限制：禁止加仓（不按 R3 默认放行）"
        return True, "AIAE 档位缺失或无效；减仓 / 持有不受此规则限制"
    if regime >= 5:
        return False, f"AIAE V级极度过热, 全面禁止建仓. 当前仓位上限 15%"
    if regime >= 4 and direction == "increase":
        return False, f"AIAE IV级偏热, 禁止加仓. 仅允许减仓或持有"
    if regime >= 4:
        return True, f"AIAE R{regime} 偏热, 允许减仓但禁止加仓"
    return True, f"AIAE R{regime}, 无建仓限制"


TOTAL_POSITION_CAP_PCT = 95.0  # 2026-11-02 项 2 (c): 仓位上限 = min(执行目标 + 10pp, 95%)
POSITION_TOLERANCE_PP = 10.0   # 与执行层 reduce_band_pp 一致: 超出执行目标 > 10pp 即"必须降仓"
_BINDING_LABEL = {"aiae": "AIAE 矩阵上限", "market": "市场尾部刹车", "portfolio": "组合波动预算", "drawdown": "回撤刹车"}


def _exec_target_info(ctx) -> dict:
    """执行目标与其最严约束 (2026-11-02 B: 仓位超限检查的判定基准)。

    优先用调用方传入的同一次执行层结果 (决策中枢 / 买入门控: context.execution_target / execution_binding),
    否则读执行层状态 (services.aiae_execution.load_state) 并按回撤刹车 / 波动预算上限比对最严约束。
    返回 {"target": float|None, "binding": [key...], "aiae_cap": float|None}
    """
    ctx = ctx or {}
    target = finite_number(ctx.get("execution_target"))
    binding = [k for k in (ctx.get("execution_binding") or []) if k in _BINDING_LABEL]
    if target is None:
        try:
            from services.aiae_execution import load_state
            target = finite_number((load_state() or {}).get("target"))
        except Exception:
            target = None
    if target is not None and not binding:
        try:
            from services import risk_state
            dd = finite_number((risk_state.drawdown_brake() or {}).get("cap_pct"))
            vb = finite_number((risk_state.vol_budget() or {}).get("max_equity_pct"))
            if dd is not None and abs(dd - target) < 0.05:
                binding = ["drawdown"]
            elif vb is not None and abs(vb - target) < 0.05:
                binding = ["portfolio"]
        except Exception:
            pass
    aiae_cap = finite_number(ctx.get("aiae_cap"))
    return {"target": target, "binding": binding, "aiae_cap": aiae_cap}


def _binding_text(binding) -> str:
    names = [_BINDING_LABEL[k] for k in binding if k in _BINDING_LABEL]
    return f"（受{'、'.join(names)}约束）" if names else ""


def _check_position_vs_cap(snapshot, positions, ctx):
    """仓位超限检查 (硬阻断): 当前实际仓位不得超过 min(AIAE 执行目标 + 10pp, 95%)。

    2026-11-02 项 2 (c): 上限补 95% 总仓位封顶 (原 MR 预览 TOTAL_CAP 并入合规); 买入门控传入订单时按成交后仓位判定。

    2026-11-02 (B, 用户决定): 判定基准由"AIAE 矩阵上限"改为"AIAE 执行目标"(= 矩阵上限 ∧ 市场尾部刹车 ∧
    组合波动预算 ∧ 回撤刹车, 周频评估、风险事件当日只向下), 与全站唯一仓位数字一致; 容差 10pp 与执行层
    "必须降仓"分区一致。执行目标不可用 → 不通过 (不回退到矩阵上限或其他数字)。
    与「组合回撤刹车」规则不重复阻断: 页面按执行方向判定时, 超出 > 10pp 为降仓方向 (回撤规则放行),
    ≤ 10pp 时本规则通过 (回撤规则在非降仓方向阻断)。
    """
    # 获取当前实际仓位 (口径不变: 决策中枢传入的账户仓位; 未传入时现取)
    current_pos = (ctx or {}).get("current_position")
    actual_pos = current_pos
    if current_pos is None:
        try:
            from portfolio_engine import get_portfolio_engine
            from dashboard_modules.decision.action_plan import _position_from_valuation
            actual_pos = _position_from_valuation(get_portfolio_engine().get_valuation())
        except Exception:
            pass
    pos_to_check = finite_number(actual_pos if actual_pos is not None else current_pos)
    if pos_to_check is None or pos_to_check < 0:
        return False, "实际仓位不可用，不能用模型建议仓位替代账户敞口"

    # 先核验账户敞口, 再核验执行目标 (两者缺任何一个都不通过)
    info = _exec_target_info(ctx)
    target = info["target"]
    if target is None:
        return False, "AIAE 执行目标不可用，无法完成仓位上限检查（不回退到矩阵上限）"
    if not 0 <= target <= 100:
        return False, "AIAE 执行目标无效，无法完成仓位上限检查"

    head = f"AIAE 执行目标 {target:.0f}%{_binding_text(info['binding'])}"
    # 2026-11-02 仓位口径统一: 标注当前仓位的数据时间
    _lbl = (ctx or {}).get("position_label")
    plabel = f"（{_lbl}）" if _lbl else ""
    overshoot = pos_to_check - target
    word = "成交后仓位" if (ctx or {}).get("order") else "当前仓位"
    if overshoot <= POSITION_TOLERANCE_PP and pos_to_check > TOTAL_POSITION_CAP_PCT:
        return False, (f"{head}。{word} {pos_to_check:.0f}%{plabel} 超出总仓位上限 {TOTAL_POSITION_CAP_PCT:.0f}%"
                       f"（取 执行目标 + {POSITION_TOLERANCE_PP:.0f}pp 与 {TOTAL_POSITION_CAP_PCT:.0f}% 的较低值），禁止加仓")
    if overshoot > POSITION_TOLERANCE_PP:
        # 机构做法: 分批降仓, 不一次性砍仓; 节奏统一以执行层为准 (分 3–5 个交易日)
        return False, (f"{head}。{word} {pos_to_check:.0f}%{plabel} 超出执行目标 {overshoot:.0f}pp，禁止加仓；"
                       f"按执行目标分批降仓 (分 3–5 个交易日; 优先减与其他持仓重叠度最高、流动性最好的部分)")
    if overshoot > 0:
        return True, f"{head}。{word} {pos_to_check:.0f}%{plabel} 略超执行目标 {overshoot:.0f}pp（容差 {POSITION_TOLERANCE_PP:.0f}pp 内）"
    return True, f"{head}。{word} {pos_to_check:.0f}%{plabel} 在执行目标以内"


class _PositionVsTargetRule(ComplianceRule):
    """硬阻断; 唯一例外 (保持现有配置不变): 最严约束只有「组合波动预算」且波动预算未设为强制
    (vol_targeting.portfolio.enforce_in_compliance=false) 时按软警告, 与「组合波动预算」规则同级。"""

    def check(self, snapshot: dict, positions: list = None, context: dict = None) -> dict:
        try:
            binding = _exec_target_info(context)["binding"]
        except Exception:
            binding = []
        only_budget = bool(binding) and set(binding) == {"portfolio"}
        self.severity = "soft_warn" if (only_budget and not _vol_budget_enforced()) else "hard_block"
        return super().check(snapshot, positions, context)


# 2026-11-01: 已删除 "JCS 置信度门槛" 规则 (_check_jcs_threshold)。
# JCS 定位为宏观环境读数, 执行区与风控不得以 JCS 分数/等级作为依据。


def _check_vix_emergency(snapshot, positions, ctx):
    """VIX > 35 时全组合降至 30% 以下 (硬阻断)"""
    vix = finite_number(snapshot.get("vix_val"))
    if vix is None or vix <= 0:
        return False, "VIX 原始读数不可用，不能当作正常波动通过紧急刹车检查"
    if vix > 35:
        return False, f"VIX {vix:.0f} > 35 极端恐慌, 仓位强制上限 30%. 仅允许减仓至线内."
    if vix > 30:
        return False, f"VIX {vix:.0f} > 30 恐慌, 仓位上限 30%. 暂停所有加仓操作."
    return True, f"VIX {vix:.0f}, 无紧急限制"


def _check_min_holdings(snapshot, positions, ctx):
    """最少持仓 5 只标的 (信息提示)"""
    if not positions:
        return True, "无持仓数据"
    count = len(positions)
    if count < 3:
        return True, f"仅 {count} 只持仓, 集中度风险极高. 建议分散至 ≥ 5 只."
    if count < 5:
        return True, f"{count} 只持仓, 接近最低分散要求 (≥ 5). 考虑增加标的."
    return True, f"{count} 只持仓, 分散化满足要求"


def _vol_budget_enforced() -> bool:
    try:
        from services.portfolio_vol import load_portfolio_vol_config
        return bool(load_portfolio_vol_config().get("enforce_in_compliance", False))
    except Exception:
        return False


def _check_vol_budget(snapshot, positions, ctx):
    """组合波动预算: 当前权益仓位 vs 目标波动对应的最大仓位.

    数据来自 Dashboard 构建时缓存的 vol_budget (或 context/snapshot 直接传入)。
    超出 10pp 以上判为不通过; 严重级别由 vol_targeting.portfolio.enforce_in_compliance 决定。
    """
    vb = (ctx or {}).get("vol_budget") or snapshot.get("vol_budget")
    if vb is None:
        # 缓存 → 当场重算 (services.risk_state); 服务重启后不再按"无数据"放行
        from services.risk_state import vol_budget
        vb = vol_budget()
    if not isinstance(vb, dict) or vb.get("max_equity_pct") is None or vb.get("invested_pct") is None:
        return True, "无组合波动预算数据, 跳过检查"
    try:
        invested = float(vb["invested_pct"])
        max_eq = float(vb["max_equity_pct"])
        pvol = float(vb.get("portfolio_vol") or 0) * 100
        tvol = float(vb.get("target_vol") or 0) * 100
    except (TypeError, ValueError):
        return True, "组合波动预算数据无效, 跳过检查"
    excess = invested - max_eq
    if excess > 10:
        return False, (f"组合年化波动 {pvol:.0f}% > 目标 {tvol:.0f}%: 当前仓位 {invested:.0f}% "
                       f"超出波动预算上限 {max_eq:.0f}% 达 {excess:.0f}pp. 禁止加仓, 按减仓草案分批降低.")
    if excess > 0:
        return True, f"仓位 {invested:.0f}% 略超波动预算上限 {max_eq:.0f}% ({excess:.0f}pp), 不宜加仓"
    return True, f"组合年化波动 {pvol:.0f}% 在目标 {tvol:.0f}% 以内"


class _VolBudgetRule(ComplianceRule):
    """严重级别随配置切换: 用户确认目标波动后 (enforce_in_compliance=true) 升级为硬阻断."""

    def check(self, snapshot: dict, positions: list = None, context: dict = None) -> dict:
        self.severity = "hard_block" if _vol_budget_enforced() else "soft_warn"
        return super().check(snapshot, positions, context)


def _trailing_breaches(snapshot, ctx):
    rep = (ctx or {}).get("trailing_stop") or snapshot.get("trailing_stop")
    if rep is None:
        # 缓存 → 日终快照 (services.risk_state); 服务重启后不再按"无数据"放行加仓
        from services.risk_state import trailing_report
        rep = trailing_report()
    if not isinstance(rep, dict) or not isinstance(rep.get("positions"), list):
        return None
    red = [p for p in rep["positions"] if p.get("status") == "RED"]
    legacy = [p for p in rep["positions"] if p.get("status") == "LEGACY"]
    return red, legacy


def _check_stop_breach_no_add(snapshot, positions, ctx):
    """越过止损线的持仓禁止加仓 (跟踪止盈引擎: RED 已触发未执行 / LEGACY 跟踪前越线未决策)。"""
    # 2026-11-01: 上游方向词为 increase/decrease/hold; 旧代码只认 sell/reduce, 导致减仓也被判阻断
    if ctx and ctx.get("direction") in ("sell", "reduce", "decrease"):
        return True, "减仓操作, 不受限制 (刹车上限已计入 AIAE 执行目标)"
    res = _trailing_breaches(snapshot, ctx)
    if res is None:
        return True, "无跟踪止盈数据, 跳过检查"
    red, legacy = res
    names = lambda xs: ", ".join(p.get("name", p.get("ts_code", "?")) for p in xs[:4])
    if red:
        return False, f"已触发止损未执行: {names(red)} — 先执行卖出, 禁止对其加仓"
    if legacy:
        return False, f"跟踪前已越线、尚未决策: {names(legacy)} — 先止损或重新基准化, 期间禁止加仓"
    return True, "无越线持仓"


class _StopBreachRule(ComplianceRule):
    """有已触发未执行 (RED) → 硬阻断; 仅有遗留待决 (LEGACY) → 软警告。"""

    def check(self, snapshot: dict, positions: list = None, context: dict = None) -> dict:
        res = None
        try:
            res = _trailing_breaches(snapshot, context)
        except Exception:
            pass
        self.severity = "hard_block" if (res and res[0]) else "soft_warn"
        return super().check(snapshot, positions, context)


def _drawdown_brake_state(snapshot, ctx):
    b = (ctx or {}).get("drawdown_brake") or snapshot.get("drawdown_brake")
    if b is None:
        # 缓存 → 日终快照 (services.risk_state); 与执行层同一来源
        from services.risk_state import drawdown_brake
        b = drawdown_brake()
    return b if isinstance(b, dict) and b.get("tier") is not None else None


def _dd_lag(b):
    try:
        from services.drawdown_service import is_stale
        return is_stale(b)
    except Exception:
        return None


class _DrawdownBrakeRule(ComplianceRule):
    """档位 ≥1 → 硬阻断; 数据过期 (>3 个交易日) → 软警告 (不因数据缺失而静默放行, 也不因此硬阻断)。"""

    def check(self, snapshot: dict, positions: list = None, context: dict = None) -> dict:
        b = None
        try:
            b = _drawdown_brake_state(snapshot, context)
        except Exception:
            pass
        lag = _dd_lag(b) if b else None
        self.severity = "soft_warn" if (lag is not None and lag > 3) else "hard_block"
        return super().check(snapshot, positions, context)


def _check_drawdown_brake(snapshot, positions, ctx):
    """组合级回撤刹车: 剔除资金进出的组合净值自高点回撤 ≥ 12% 起分档降仓上限, 期间禁止新增买入。"""
    # 2026-11-01: 上游方向词为 increase/decrease/hold; 旧代码只认 sell/reduce, 导致减仓也被判阻断
    if ctx and ctx.get("direction") in ("sell", "reduce", "decrease"):
        return True, "减仓操作, 不受限制 (刹车上限已计入 AIAE 执行目标)"
    b = _drawdown_brake_state(snapshot, ctx)
    if b is None:
        return True, "无组合回撤数据, 跳过检查"
    lag = _dd_lag(b)
    if lag is not None and lag > 3:
        return False, f"组合回撤数据已 {lag} 个交易日未更新 (截至 {b.get('as_of')}), 刹车状态不可信 — 请先「同步并重算」"
    dd = abs(b.get("dd") or 0)
    if not b.get("tier"):
        return True, f"组合回撤 {dd:.1%}, 未触发刹车"
    msg = f"组合回撤 {dd:.1%} · {b.get('label')} — 仓位上限 {b.get('cap_pct')}%, 回撤恢复前禁止新增买入"
    if b.get("reduce_value"):
        msg += f"; 当前 {b.get('invested_pct')}%, 需先降仓约 ¥{b['reduce_value']:,.0f}"
    return False, msg


# ── 规则集 ──
COMPLIANCE_RULES = [
    ComplianceRule("single_stock_cap", "单票仓位上限", "hard_block",
                   "单一个股不得超过 20%，单只 ETF 不得超过 35%", _check_single_stock_cap),
    _ThemeConcentrationRule("sector_concentration", "主题集中度", "soft_warn",
                   "单一主题 (ETF 按穿透成分, 成分不可用时按名称回退; 个股按行业) 不得超过 40%，超过 60% 硬阻断; 买入使所在主题超过 40% 硬阻断", _check_sector_concentration),
    ComplianceRule("aiae_overheat", "AIAE 过热限制", "hard_block",
                   "AIAE ≥ R4 时禁止新建仓位", _check_aiae_overheat),
    _PositionVsTargetRule("position_vs_cap", "仓位超限检查", "hard_block",
                   "当前实际仓位不得超过 min(AIAE 执行目标 + 10pp, 95%) (执行目标不可用即不通过)", _check_position_vs_cap),
    ComplianceRule("vix_emergency", "VIX 紧急刹车", "hard_block",
                   "VIX > 30 时仓位强制上限 30%", _check_vix_emergency),
    ComplianceRule("min_holdings", "最低分散持仓", "info",
                   "持仓标的数 ≥ 5 只以分散尾部风险", _check_min_holdings),
    _VolBudgetRule("vol_budget", "组合波动预算", "soft_warn",
                   "当前仓位不得超过目标波动对应的最大仓位 10pp", _check_vol_budget),
    _StopBreachRule("stop_breach_no_add", "越线禁止加仓", "soft_warn",
                    "跌破跟踪止损线的持仓, 执行或决策前禁止加仓", _check_stop_breach_no_add),
    _DrawdownBrakeRule("drawdown_brake", "组合回撤刹车", "hard_block",
                   "组合净值回撤 ≥12/20/28% 分档降仓上限至 75/50/25%, 期间禁止加仓", _check_drawdown_brake),
]


# ═══════════════════════════════════════════════════════════
#  合规检查入口
# ═══════════════════════════════════════════════════════════

def run_compliance_check(snapshot: dict, positions: list = None,
                         context: dict = None) -> dict:
    """
    执行全部合规规则检查 (当前 9 条; 2026-11-01 删除 JCS 门槛)。

    参数:
      snapshot: 当前市场快照
      positions: 持仓列表 [{ts_code, name, weight, industry, ...}]
      context: 操作上下文 {direction, current_position, ...} (不含 JCS)

    返回:
    {
        "status": "passed" / "blocked" / "warning",
        "passed_count": int,
        "failed_count": int,
        "warn_count": int,
        "checks": [{rule_id, rule_name, severity, passed, detail}],
        "blocks": [仅 hard_block 且 failed 的规则],
        "summary": str,
    }
    """
    if positions is None:
        try:
            from portfolio_engine import get_portfolio_engine
            pe = get_portfolio_engine()
            val = pe.get_valuation()
            positions = val.get("positions", [])
        except Exception:
            positions = []

    results = []
    for rule in COMPLIANCE_RULES:
        results.append(rule.check(snapshot, positions, context))

    failed = [r for r in results if not r["passed"]]
    hard_blocks = [r for r in failed if r["severity"] == "hard_block"]
    soft_warns = [r for r in failed if r["severity"] == "soft_warn"]

    if hard_blocks:
        status = "blocked"
        summary = f"🛑 {len(hard_blocks)} 条硬阻断: " + "; ".join(
            r["rule_name"] for r in hard_blocks[:3])
    elif soft_warns:
        status = "warning"
        summary = f"⚠️ {len(soft_warns)} 条警告: " + "; ".join(
            r["rule_name"] for r in soft_warns[:3])
    else:
        status = "passed"
        summary = f"🟢 全部 {len(results)} 条合规规则审查通过"

    return {
        "status": status,
        "passed_count": len(results) - len(failed),
        "failed_count": len(failed),
        "warn_count": len(soft_warns),
        "checks": results,
        "blocks": [r for r in failed if r["severity"] == "hard_block"],
        "warnings": [r for r in failed if r["severity"] == "soft_warn"],
        "summary": summary,
    }
