"""
AlphaCore · 持仓偏差分析引擎 V1.0
===================================
对比实盘持仓 vs AIAE 仓位建议, 量化偏差并生成调仓建议。

核心功能:
  1. 总仓位偏差: 实际仓位 vs AIAE 矩阵建议仓位
  2. ETF 占比: 宽基+行业 ETF 占持仓市值 (2026-10-30 起; 原为 AIAE 8 只 ETF 池覆盖度)
  3. 单票集中度告警: >10% 预警, >15% 警告, >20% 红线
  4. 首批减仓候选: 占比>10% AND (浮盈>30% OR regime>=4)
  5. 实盘健康度: 限额监控 (红黄绿, 等级取最差) + 质量分 (2026-10-31, docs/AIAE_MONITOR_LIMITS.md)

V1.0 2026-05-26
"""

import os
import json
import math
import threading
from datetime import datetime, timedelta
from typing import Optional, Dict, List

CACHE_DIR = "data_lake"

# AIAE ETF 核心标的池 (与 aiae_engine.py AIAE_ETF_POOL 保持一致)
AIAE_ETF_POOL = [
    {"ts_code": "510300.SH", "name": "沪深300ETF"},
    {"ts_code": "510050.SH", "name": "上证50ETF"},
    {"ts_code": "510500.SH", "name": "中证500ETF"},
    {"ts_code": "159915.SZ", "name": "创业板ETF"},
    {"ts_code": "512100.SH", "name": "中证1000ETF"},
    {"ts_code": "510880.SH", "name": "红利ETF"},
    {"ts_code": "515100.SH", "name": "红利低波100"},
    {"ts_code": "159905.SZ", "name": "深红利ETF"},
]
AIAE_ETF_CODES = {e["ts_code"] for e in AIAE_ETF_POOL}

# 集中度阈值
CONCENTRATION_WARNING = 10.0    # >10% 预警
CONCENTRATION_ALERT = 15.0      # >15% 警告
CONCENTRATION_REDLINE = 20.0    # >20% 审计红线

# 减仓候选触发条件
REDUCTION_MIN_PCT = 10.0        # 最低占比阈值
REDUCTION_MIN_PNL = 30.0        # 最低浮盈率阈值
REDUCTION_REGIME_TRIGGER = 4    # 档位触发阈值

# 持仓数据新鲜度 (2026-10-30): portfolio_store.json 只在页面导入「资金股份查询」时更新,
# 超过此工作日数未导入即判为陈旧; 账户台账有更新的快照时一并提示。
PORTFOLIO_STALE_WEEKDAYS = 2


def _log(msg: str, level: str = "INFO"):
    ts_str = datetime.now().strftime("%H:%M:%S.%f")[:-3]
    print(f"[{ts_str}] [{level}] [DEVIATION] {msg}")


class PositionDeviationEngine:
    """实盘持仓 vs AIAE 建议偏差分析引擎"""

    VERSION = "1.0"

    def __init__(self):
        _log(f"PositionDeviationEngine V{self.VERSION} 初始化")

    def load_portfolio(self) -> Optional[dict]:
        """加载最新 portfolio_store.json"""
        fp = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "data_lake", "portfolio_store.json")
        if not os.path.exists(fp):
            _log(f"portfolio_store.json 不存在", "WARN")
            return None
        try:
            with open(fp, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception as e:
            _log(f"portfolio 读取失败: {e}", "ERROR")
            return None

    def compute_deviation(self, portfolio: dict = None, aiae_report: dict = None,
                          today: Optional[str] = None, ledger_snapshot: Optional[dict] = None,
                          exec_state: Optional[dict] = None, cost_loaders: Optional[tuple] = None,
                          theme_loader=None) -> dict:
        """
        计算实盘持仓与 AIAE 建议的全面偏差分析。
        
        Args:
            portfolio: portfolio_store.json 格式数据, 为 None 时自动加载
            aiae_report: AIAE generate_report() 输出, 为 None 时仅做持仓分析
        
        Returns:
            含总仓位偏差、ETF覆盖度、集中度告警、减仓候选、健康度评分
        """
        if portfolio is None:
            portfolio = self.load_portfolio()
        if portfolio is None:
            return {"status": "error", "message": "无法加载持仓数据"}

        positions = portfolio.get("positions", {})
        cash = portfolio.get("cash", 0)
        total_asset = portfolio.get("broker_total_asset", 0)
        total_mv = portfolio.get("broker_ref_market_value", 0)

        # 2026-10-23: 总资产自洽校验.
        # 通达信导出的「资产」字段口径不稳定: 有时 = 参考市值 + 可用, 有时 = 参考市值 + 余额
        # (当日卖出资金只进入「可用」不进「余额」). 例: 10-23 导出 资产=1,472,315 ≈ 市值+18 元,
        # 漏掉了 50,105 元可用资金, 使实际仓位被算成 100.0% (真实 96.7%).
        # 规则: 以 持仓市值合计 + 可用资金 为准; 券商字段只在两者差异 <0.5% 时采用。
        pos_mv = sum(p.get("broker_market_value", 0) for p in positions.values())
        if pos_mv > 0:
            total_mv = pos_mv
        computed_asset = total_mv + cash
        if total_asset <= 0 or (computed_asset > 0 and abs(total_asset - computed_asset) / computed_asset > 0.005):
            if total_asset > 0:
                _log(f"券商总资产 {total_asset:,.0f} 与 市值+可用 {computed_asset:,.0f} 不一致, 采用后者", "WARN")
            total_asset = computed_asset

        # 1. 实际仓位
        actual_position_pct = (total_mv / total_asset * 100) if total_asset > 0 else 0

        # 2. AIAE 建议仓位
        suggested_position = None
        regime = None
        base_suggested = None
        vol_overlay = None
        if aiae_report and aiae_report.get("position"):
            base_suggested = aiae_report["position"].get("matrix_position")
            suggested_position = base_suggested
            regime = aiae_report.get("current", {}).get("regime")
            # Vol overlay V2: 建议仓位 = AIAE 矩阵 × 市场尾部刹车系数
            try:
                from services.vol_regime import get_vol_overlay, apply_vol_overlay_to_cap
                vol_overlay = get_vol_overlay()
                adj = apply_vol_overlay_to_cap(base_suggested, vol_overlay)
                if adj is not None:
                    suggested_position = adj
            except Exception as e:
                _log(f"波动率系数不可用, 建议仓位保持 AIAE 原值: {e}", "WARN")

        # 2b. 组合波动预算 (按持仓结构, 非择时)
        vol_budget = None
        try:
            from services.portfolio_vol import compute_portfolio_vol, load_portfolio_vol_config
            vol_budget = compute_portfolio_vol(positions, total_asset, cfg=load_portfolio_vol_config())
        except Exception as e:
            _log(f"组合波动预算计算失败 (非致命): {e}", "WARN")

        # 3. 仓位偏差
        position_gap = None
        if suggested_position is not None:
            position_gap = round(actual_position_pct - suggested_position, 1)

        # 3b. 执行层目标 (2026-10-31): 面板主显示 "实际 − 执行目标", 分区与 docs/AIAE_EXECUTION_RULES.md 一致
        effective_cap = (
            round(min(float(suggested_position), float(vol_budget["max_equity_pct"])), 1)
            if suggested_position is not None and vol_budget and vol_budget.get("max_equity_pct") is not None
            else suggested_position
        )
        execution_target = self._execution_target(actual_position_pct, exec_state)

        # 3c. 达到目标的交易成本 (事前估算; 优先执行层目标, 无则用 AIAE 建议)
        execution_cost = None
        try:
            from services import trade_cost
            if execution_target:
                cost_target, cost_basis = execution_target["target_pct"], "exec_target"
            else:
                cost_target, cost_basis = suggested_position, "aiae_suggested"
            pl, al = cost_loaders if cost_loaders else self._default_cost_loaders()
            execution_cost = trade_cost.estimate_reduction_plan(
                positions, total_asset, actual_position_pct, cost_target, basis=cost_basis,
                days=3, days_label=self._exec_reduce_days(), price_loader=pl, amount_loader=al)
        except Exception as e:
            _log(f"交易成本估算失败 (非致命): {e}", "WARN")

        # 4. AIAE ETF 覆盖度
        etf_coverage = self._compute_etf_coverage(positions)

        # 5. 单票集中度分析
        concentration = self._compute_concentration(positions, total_asset)

        # 6. 首批减仓候选
        reduction_candidates = self._find_reduction_candidates(
            positions, total_asset, regime
        )

        # 7. 持仓结构分类
        structure = self._classify_structure(positions, total_asset)

        # 7b. 持仓数据新鲜度 (导入日 vs 今天, 以及是否有更新的账户台账快照)
        data_freshness = self._data_freshness(portfolio.get("import_date"), today, ledger_snapshot)

        # 8. 健康度评分
        theme = self._theme_concentration(portfolio, theme_loader)
        health = self._compute_health_score(
            actual_position_pct, suggested_position,
            etf_coverage, concentration, aiae_report,
            positions=positions, data_freshness=data_freshness,
            execution_target=execution_target, theme=theme,
        )

        result = {
            "status": "success",
            "engine_version": self.VERSION,
            "computed_at": datetime.now().isoformat(),

            "portfolio_summary": {
                "total_asset": round(total_asset, 2),
                "total_market_value": round(total_mv, 2),
                "cash": round(cash, 2),
                "holding_count": len(positions),
                "import_date": portfolio.get("import_date", "unknown"),
            },

            "position_deviation": {
                "actual_pct": round(actual_position_pct, 1),
                "suggested_pct": suggested_position,
                "base_suggested_pct": base_suggested,
                "vol_factor": (vol_overlay or {}).get("factor"),
                "vol_status": (vol_overlay or {}).get("status"),
                "effective_cap_pct": effective_cap,
                "gap": position_gap,
                "gap_severity": self._classify_gap_severity(position_gap),
                "regime": regime,
            },

            "execution_target": execution_target,
            "execution_cost": execution_cost,
            "etf_coverage": etf_coverage,
            "concentration": concentration,
            "reduction_candidates": reduction_candidates,
            "structure": structure,
            "health_score": health,
            "theme_concentration": ({k: theme.get(k) for k in ("level", "top_theme", "top_pct", "limit_pct", "danger_pct",
                                                               "effective_themes", "text", "classification_basis")}
                                    if theme and theme.get("status") == "ok" else None),
            "vol_budget": vol_budget,
            "data_freshness": data_freshness,
        }

        _log(f"偏差分析完成: 仓位={actual_position_pct:.1f}% "
             f"(建议{suggested_position}%, 偏差{position_gap}pt) "
             f"ETF占比={etf_coverage['coverage_pct']:.0f}% "
             f"健康度={health['score']}")
        if data_freshness.get("stale"):
            newer = data_freshness.get("newer_ledger_snapshot")
            _log(f"持仓数据截至 {data_freshness.get('import_date')} (已 {data_freshness.get('weekdays_since')} 个工作日未导入)"
                 + (f"; 账户台账 {newer['as_of']} 快照显示仓位约 {newer['implied_position_pct']}%" if newer and newer.get('implied_position_pct') is not None else "")
                 + " → 偏差结果可能失真, 请导入最新资金股份查询", "WARN")
        return result

    # ────────── 执行层目标 / 成本数据源 ──────────

    @staticmethod
    def _execution_target(actual_pct: float, exec_state: Optional[dict]) -> Optional[dict]:
        """执行层当前目标 (aiae_exec_state.json) 与偏差分区; 无状态时返回 None。"""
        if not exec_state or exec_state.get("target") is None:
            return None
        try:
            from engines import aiae_params as AP
            from datetime import date as _date
            from services.aiae_execution import classify_zone, next_eval_date, _instruction, _to_date, _week
            p = AP.EXEC_PARAMS
            target = float(exec_state["target"])
            gap = round(actual_pct - target, 1)
            zone = classify_zone(gap, p)
            today = _date.today()
            last_eval = _to_date(exec_state.get("last_eval_date"))
            nxt = next_eval_date(today, last_eval is not None and _week(last_eval) == _week(today), int(p["eval_weekday"]))
            return {
                "target_pct": round(target, 1),
                "gap": gap,
                "zone": zone,
                "instruction": _instruction(zone, target, gap, nxt, p),   # 与决策页执行层同一措辞
                "next_eval_date": nxt.isoformat(),
                "bands": {k: p[k] for k in ("reduce_band_pp", "pause_band_pp", "add_band_pp")},
                "reduce_days": p.get("reduce_days"),
                "last_change": exec_state.get("last_change"),
                "last_trigger": exec_state.get("last_trigger"),
                "last_eval_date": exec_state.get("last_eval_date"),
                "staging_active": bool(exec_state.get("staging_active")),
                "params_version": p.get("version"),
            }
        except Exception as e:
            _log(f"执行层目标读取失败 (非致命): {e}", "WARN")
            return None

    @staticmethod
    def _theme_concentration(portfolio: dict, theme_loader=None) -> Optional[dict]:
        """主题集中度: 复用 services/concentration (穿透口径, 阈值来自 strategy_runtime.json, 与决策页同一规则)。
        theme_loader: 测试注入 (portfolio → 结果); 默认读本地行业表与成分数据。失败返回 None (L3 记为无数据)。"""
        try:
            if theme_loader is not None:
                return theme_loader(portfolio)
            from services import concentration as C
            return C.compute_concentration(portfolio, C.cached_industry_map(), C.load_concentration_config())
        except Exception as e:
            _log(f"主题集中度不可用 (非致命): {e}", "WARN")
            return None

    @staticmethod
    def _exec_reduce_days() -> str:
        try:
            from engines import aiae_params as AP
            return str(AP.EXEC_PARAMS.get("reduce_days", "3-5"))
        except Exception:
            return "3-5"

    @staticmethod
    def _default_cost_loaders() -> tuple:
        from services.portfolio_vol import default_price_loader, default_amount_loader
        return default_price_loader, default_amount_loader

    # ────────── 持仓数据新鲜度 ──────────

    @staticmethod
    def _weekdays_between(d0: str, d1: str) -> Optional[int]:
        """d0 之后到 d1 (含) 的工作日数; 日期无法解析时返回 None。"""
        try:
            a = datetime.strptime(str(d0)[:10], "%Y-%m-%d").date()
            b = datetime.strptime(str(d1)[:10], "%Y-%m-%d").date()
        except (TypeError, ValueError):
            return None
        n, d = 0, a
        while d < b:
            d += timedelta(days=1)
            if d.weekday() < 5:
                n += 1
        return n

    def _latest_ledger_snapshot(self) -> Optional[dict]:
        try:
            from services import account_ledger
            snaps = account_ledger.load().get("snapshots") or []
            return snaps[-1] if snaps else None
        except Exception as e:
            _log(f"账户台账快照读取失败 (非致命): {e}", "WARN")
            return None

    def _data_freshness(self, import_date: Optional[str], today: Optional[str] = None,
                        ledger_snapshot: Optional[dict] = None) -> dict:
        today = today or datetime.now().strftime("%Y-%m-%d")
        age = self._weekdays_between(import_date, today) if import_date else None
        snap = ledger_snapshot if ledger_snapshot is not None else self._latest_ledger_snapshot()
        newer = None
        if snap and import_date and str(snap.get("as_of", "")) > str(import_date)[:10]:
            ta, cash = snap.get("total_asset"), snap.get("cash")
            implied = None
            if ta and cash is not None and float(ta) > 0:
                implied = round((float(ta) - float(cash)) / float(ta) * 100, 1)
            newer = {"as_of": snap.get("as_of"), "cash": cash, "total_asset": ta,
                     "implied_position_pct": implied,
                     "holding_count": len(snap["positions"]) if isinstance(snap.get("positions"), dict) else None}
        stale = (age is None) or (age > PORTFOLIO_STALE_WEEKDAYS) or (newer is not None)
        return {"import_date": import_date, "today": today, "weekdays_since": age,
                "stale": bool(stale), "stale_threshold_weekdays": PORTFOLIO_STALE_WEEKDAYS,
                "newer_ledger_snapshot": newer}

    # ────────── ETF 覆盖度 ──────────

    def _compute_etf_coverage(self, positions: dict) -> dict:
        """ETF 占比 (2026-10-30 改): 宽基 ETF + 行业 ETF 市值 / 持仓总市值。

        原口径是"持有 AIAE 指定 8 只宽基/红利 ETF 中的几只", 对以行业 ETF 为主的组合恒为 0,
        与投资风格不匹配。新口径衡量的是"分散化工具占比": ETF 越多, 单票风险越低。
        分母用持仓市值 (不含现金), 避免现金多少影响这一项。黄金/商品 ETF 不计入。
        健康度 etf_coverage 分 = ETF 占比 (0-100)。原 8 只 ETF 池的持有情况保留在 aiae_pool_* 字段。
        """
        structure = self._classify_structure(positions, 1.0)   # 只取分类与市值, 占比另算
        total_mv = sum(p.get("broker_market_value", 0) for p in positions.values())
        broad_v = structure["broad_etf"]["value"]
        sector_v = structure["sector_etf"]["value"]
        etf_v = broad_v + sector_v
        share = (etf_v / total_mv * 100) if total_mv > 0 else 0.0

        held, missing = [], []
        for etf in AIAE_ETF_POOL:
            code = etf["ts_code"]
            if code in positions:
                held.append({"ts_code": code, "name": etf["name"],
                             "market_value": positions[code].get("broker_market_value", 0)})
            else:
                missing.append({"ts_code": code, "name": etf["name"]})
        pool_pct = len(held) / len(AIAE_ETF_POOL) * 100 if AIAE_ETF_POOL else 0

        return {
            "metric": "etf_share",
            "coverage_pct": round(share, 1),                # 健康度使用: ETF 占持仓市值 %
            "etf_share_pct": round(share, 1),
            "etf_value": round(etf_v, 2),
            "etf_count": structure["broad_etf"]["count"] + structure["sector_etf"]["count"],
            "broad_etf_pct": round(broad_v / total_mv * 100, 1) if total_mv > 0 else 0.0,
            "sector_etf_pct": round(sector_v / total_mv * 100, 1) if total_mv > 0 else 0.0,
            "verdict": "充分" if share >= 60 else ("部分" if share >= 30 else "偏低"),
            # 旧口径 (AIAE 8 只 ETF 池), 仅供参考
            "aiae_pool_coverage_pct": round(pool_pct, 1),
            "held_count": len(held),
            "total_count": len(AIAE_ETF_POOL),
            "held": held,
            "missing": missing,
        }

    # ────────── 单票集中度 ──────────

    def _compute_concentration(self, positions: dict, total_asset: float) -> dict:
        """单票集中度分析, 按占比排序"""
        if total_asset <= 0:
            return {"alerts": [], "max_pct": 0, "positions": []}

        pos_list = []
        for code, pos in positions.items():
            mv = pos.get("broker_market_value", 0)
            pct = mv / total_asset * 100 if total_asset > 0 else 0
            pnl_pct = pos.get("broker_pnl_pct", 0)
            name = pos.get("name", code)

            severity = "normal"
            if pct > CONCENTRATION_REDLINE:
                severity = "redline"
            elif pct > CONCENTRATION_ALERT:
                severity = "alert"
            elif pct > CONCENTRATION_WARNING:
                severity = "warning"

            pos_list.append({
                "ts_code": code,
                "name": name,
                "market_value": round(mv, 2),
                "pct": round(pct, 2),
                "pnl_pct": round(pnl_pct, 2),
                "severity": severity,
            })

        pos_list.sort(key=lambda x: x["pct"], reverse=True)

        alerts = [p for p in pos_list if p["severity"] != "normal"]
        max_pct = pos_list[0]["pct"] if pos_list else 0

        return {
            "positions": pos_list[:10],  # Top 10
            "alerts": alerts,
            "alert_count": len(alerts),
            "max_pct": round(max_pct, 2),
            "max_name": pos_list[0]["name"] if pos_list else "",
            "verdict": "正常" if not alerts else (
                "红线违规" if any(a["severity"] == "redline" for a in alerts) else "预警"
            ),
        }

    # ────────── 首批减仓候选 ──────────

    def _find_reduction_candidates(self, positions: dict, total_asset: float,
                                    regime: int = None) -> dict:
        """
        识别首批减仓候选:
          条件: 占比 > 10% AND (浮盈率 > 30% OR regime >= 4)
          优先级 = 占比 × 0.6 + 浮盈率 × 0.004
        """
        if total_asset <= 0:
            return {"candidates": [], "count": 0}

        candidates = []
        for code, pos in positions.items():
            mv = pos.get("broker_market_value", 0)
            pct = mv / total_asset * 100
            pnl_pct = pos.get("broker_pnl_pct", 0)
            name = pos.get("name", code)

            # 触发条件
            pct_trigger = pct > REDUCTION_MIN_PCT
            pnl_trigger = pnl_pct > REDUCTION_MIN_PNL
            regime_trigger = regime is not None and regime >= REDUCTION_REGIME_TRIGGER

            if pct_trigger and (pnl_trigger or regime_trigger):
                reasons = []
                if pnl_trigger:
                    reasons.append(f"浮盈 {pnl_pct:+.1f}% (>{REDUCTION_MIN_PNL}%)")
                if regime_trigger:
                    reasons.append(f"AIAE Ⅳ-Ⅴ级 (regime={regime})")
                if pct > CONCENTRATION_ALERT:
                    reasons.append(f"集中度 {pct:.1f}% (>{CONCENTRATION_ALERT}%)")

                priority = pct * 0.6 + max(pnl_pct, 0) * 0.004
                candidates.append({
                    "ts_code": code,
                    "name": name,
                    "pct": round(pct, 2),
                    "pnl_pct": round(pnl_pct, 2),
                    "market_value": round(mv, 2),
                    "priority": round(priority, 3),
                    "reasons": reasons,
                    "tag": "🔴 首批减仓候选",
                })

        candidates.sort(key=lambda x: x["priority"], reverse=True)

        return {
            "candidates": candidates,
            "count": len(candidates),
            "total_value": round(sum(c["market_value"] for c in candidates), 2),
        }

    # ────────── 持仓结构分类 ──────────

    def _classify_structure(self, positions: dict, total_asset: float) -> dict:
        """将持仓分为: 个股 / 宽基ETF / 行业ETF / 港股 / 其他"""
        categories = {
            "individual_stocks": {"count": 0, "value": 0, "items": []},
            "broad_etf": {"count": 0, "value": 0, "items": []},
            "sector_etf": {"count": 0, "value": 0, "items": []},
            "hk_stocks": {"count": 0, "value": 0, "items": []},
            "gold_commodity": {"count": 0, "value": 0, "items": []},
            "other": {"count": 0, "value": 0, "items": []},
        }

        BROAD_ETF_KEYWORDS = ["300ETF", "500ETF", "50ETF", "创业板", "科创50", "1000ETF"]
        GOLD_KEYWORDS = ["黄金", "gold"]

        for code, pos in positions.items():
            name = pos.get("name", "")
            mv = pos.get("broker_market_value", 0)

            if code.startswith("0") and len(code) == 8 and ".HK" in code:
                cat = "hk_stocks"
            elif ".HK" in code:
                cat = "hk_stocks"
            elif any(k in name for k in GOLD_KEYWORDS):
                cat = "gold_commodity"
            elif any(k in name for k in BROAD_ETF_KEYWORDS):
                cat = "broad_etf"
            elif code.startswith("15") or code.startswith("51") or code.startswith("56") or code.startswith("58"):
                cat = "sector_etf"
            else:
                cat = "individual_stocks"

            categories[cat]["count"] += 1
            categories[cat]["value"] += mv
            categories[cat]["items"].append({"code": code, "name": name, "value": round(mv, 2)})

        # 计算占比
        for cat_data in categories.values():
            cat_data["value"] = round(cat_data["value"], 2)
            cat_data["pct"] = round(cat_data["value"] / total_asset * 100, 1) if total_asset > 0 else 0

        return categories

    # ────────── 健康度评分 ──────────

    def _compute_health_score(self, actual_pct: float, suggested_pct: float,
                               etf_coverage: dict, concentration: dict,
                               aiae_report: dict = None,
                               positions: dict = None,
                               data_freshness: dict = None,
                               execution_target: Optional[dict] = None,
                               theme: Optional[dict] = None) -> dict:
        """
        实盘健康度 V2 (2026-10-31, 规则见 docs/AIAE_MONITOR_LIMITS.md): 限额监控 + 质量分。

        硬限额 (红黄绿, 等级取最差一项; 数据缺失 = 灰, 不算绿):
          L1 仓位 − 执行层目标   绿 ≤5pp / 黄 5–10pp / 红 >10pp (无执行目标时相对 AIAE 建议, 同阈值)
          L2 单票占总资产        绿 ≤10% / 黄 10–20% / 红 >20%
          L3 主题集中度          复用 services/concentration (穿透口径, 占权益 >40% 黄 / >60% 红, 与决策页同一规则)
          L5 持仓数据新鲜度      ≤2 个工作日且无更新台账 → 绿, 否则红
        观察项 (不计入等级): L4 β 敞口 vs 预算 —— 由前端读取 /aiae/beta_exposure 填入, 12 周复核后再定。
        等级: 任一红 → D; 无红有黄 → C; 全绿 → 质量分 ≥80 为 A, 否则 B; 有灰无红黄 → 最高 B。
        质量分 (0–100, 仅参考): 可用项的平均 —— 分散度 (N_eff=1/HHI, 3→0, 10→100)、主题分散 (100−最大主题占权益%)、
          执行纪律 (跟踪止盈 T+1 执行率; 无事件 = 无数据, 不给默认分)、数据质量 (100−25×过期告警, 持仓陈旧时 ≤40)。
        """
        limits = []

        def add(lid, name, status, value_text, rule, value=None):
            limits.append({"id": lid, "name": name, "status": status, "value": value,
                           "value_text": value_text, "rule": rule, "graded": True})

        # L1 仓位偏差
        if execution_target and execution_target.get("gap") is not None:
            g, basis = float(execution_target["gap"]), f"执行目标 {execution_target['target_pct']:.0f}%"
        elif suggested_pct is not None:
            g, basis = float(actual_pct) - float(suggested_pct), f"AIAE 建议 {float(suggested_pct):.0f}% (执行目标不可用)"
        else:
            g, basis = None, None
        if g is None:
            add("L1", "仓位偏差", "unknown", "无目标", "相对执行目标 >10pp 红 / 5–10pp 黄")
        else:
            st = "red" if g > 10 else ("yellow" if g > 5 else "green")
            add("L1", "仓位偏差", st, f"{g:+.1f}pp vs {basis}", "相对执行目标 >10pp 红 / 5–10pp 黄 (低于目标不算越限)", round(g, 1))

        # L2 单票
        max_pct = concentration.get("max_pct")
        if positions and max_pct is not None:
            st = "red" if max_pct > CONCENTRATION_REDLINE else ("yellow" if max_pct > CONCENTRATION_WARNING else "green")
            add("L2", "单票集中度", st, f"{concentration.get('max_name', '')} {max_pct:.1f}%",
                f"占总资产 >{CONCENTRATION_REDLINE:.0f}% 红 / >{CONCENTRATION_WARNING:.0f}% 黄", round(max_pct, 1))
        else:
            add("L2", "单票集中度", "unknown", "无持仓", f"占总资产 >{CONCENTRATION_REDLINE:.0f}% 红")

        # L3 主题集中度 (复用决策页同一规则)
        if theme and theme.get("status") == "ok":
            lv = theme.get("level")
            st = {"danger": "red", "warning": "yellow", "ok": "green"}.get(lv, "unknown")
            tp = theme.get("top_pct")
            vt = f"{theme.get('top_theme') or '—'} {tp:.0f}% (占权益)" if tp is not None else (theme.get("text") or "—")
            add("L3", "主题集中度", st, vt,
                f"单一主题占权益 >{theme.get('limit_pct', 40):.0f}% 黄 / >{theme.get('danger_pct', 60):.0f}% 红 (穿透口径, 同决策页)",
                tp)
        else:
            add("L3", "主题集中度", "unknown", "主题数据不可用", "单一主题占权益 >40% 黄 / >60% 红")

        # L5 数据新鲜度
        if data_freshness:
            stale = bool(data_freshness.get("stale"))
            wd = data_freshness.get("weekdays_since")
            vt = f"截至 {data_freshness.get('import_date') or '未知'}" + (f" ({wd} 个工作日)" if wd is not None else "")
            if data_freshness.get("newer_ledger_snapshot"):
                vt += " · 台账有更新快照"
            add("L5", "持仓数据", "red" if stale else "green", vt,
                f"超过 {PORTFOLIO_STALE_WEEKDAYS} 个工作日未导入或台账有更新 → 红", wd)
        else:
            add("L5", "持仓数据", "unknown", "无新鲜度信息", f"超过 {PORTFOLIO_STALE_WEEKDAYS} 个工作日 → 红")

        # L4 β 观察项 (前端填值)
        limits.insert(3, {"id": "L4", "name": "β 敞口", "status": "pending", "value": None,
                          "value_text": "见 β 调整后敞口", "rule": "观察期: 只提示, 不计入等级 (12 周复核后再定)",
                          "graded": False})

        graded = [l for l in limits if l["graded"]]
        n = {s: sum(1 for l in graded if l["status"] == s) for s in ("red", "yellow", "green", "unknown")}

        # 质量分
        q = {}
        if positions:
            mvs = [float(p.get("broker_market_value", 0) or 0) for p in positions.values()]
            tot = sum(mvs)
            if tot > 0:
                n_eff = 1.0 / sum((m / tot) ** 2 for m in mvs if m > 0)
                q["diversification"] = {"score": round(max(0.0, min(1.0, (n_eff - 3) / 7)) * 100),
                                        "value_text": f"有效持仓数 {n_eff:.1f}"}
        if theme and theme.get("status") == "ok" and theme.get("top_pct") is not None:
            q["theme_diversity"] = {"score": round(max(0.0, 100 - float(theme["top_pct"]))),
                                    "value_text": f"最大主题占权益 {float(theme['top_pct']):.0f}%"}
        disc = None
        try:
            from services.trailing_stop_service import get_discipline_score
            disc = get_discipline_score()
        except Exception:
            disc = None
        q["discipline"] = ({"score": int(min(100, max(0, disc))), "value_text": "止盈/止损触发后 T+1 执行率"}
                           if disc is not None else {"score": None, "value_text": "近期无触发事件 (无数据)"})
        if aiae_report is not None or data_freshness:
            dq = 100 - 25 * len((aiae_report or {}).get("stale_data_warnings", [])) if aiae_report is not None else 60
            dq = max(0, dq)
            if data_freshness and data_freshness.get("stale"):
                dq = min(dq, 40)
            q["data_quality"] = {"score": dq, "value_text": "数据过期告警 / 持仓新鲜度"}
        avail = [v["score"] for v in q.values() if v.get("score") is not None]
        quality = round(sum(avail) / len(avail)) if avail else None

        if n["red"]:
            grade, verdict = "D", f"{n['red']} 项限额红灯"
        elif n["yellow"]:
            grade, verdict = "C", f"{n['yellow']} 项限额黄灯"
        elif n["unknown"]:
            grade, verdict = "B", f"{n['unknown']} 项限额无数据"
        else:
            grade = "A" if (quality or 0) >= 80 else "B"
            verdict = "限额全部达标"

        return {
            "version": "limits-1.0",
            "score": quality,                      # 质量分 (仅参考); 等级由限额决定
            "grade": grade,
            "verdict": verdict,
            "limit_counts": n,
            "limits": limits,
            "quality": q,
            "breakdown": {k: v.get("score") for k, v in q.items()},
        }

    # ────────── 辅助 ──────────

    def _classify_gap_severity(self, gap: float) -> str:
        if gap is None:
            return "unknown"
        abs_gap = abs(gap)
        if abs_gap <= 5:
            return "normal"
        elif abs_gap <= 10:
            return "warning"
        elif abs_gap <= 15:
            return "alert"
        else:
            return "critical"


# ===== 引擎单例 =====
_dev_instance = None
_dev_lock = threading.Lock()


def get_deviation_engine() -> PositionDeviationEngine:
    global _dev_instance
    if _dev_instance is None:
        with _dev_lock:
            if _dev_instance is None:
                _dev_instance = PositionDeviationEngine()
    return _dev_instance


# ===== 自检 =====
if __name__ == "__main__":
    import sys
    if sys.platform == 'win32':
        sys.stdout.reconfigure(encoding='utf-8', errors='replace')

    print("=" * 60)
    print("  Position Deviation Engine V1.0 · Self-Test")
    print("=" * 60)

    engine = PositionDeviationEngine()

    # 加载实盘数据
    portfolio = engine.load_portfolio()
    if not portfolio:
        print("✗ portfolio_store.json 未找到")
        sys.exit(1)

    # 不需要 AIAE report, 仅做持仓分析
    result = engine.compute_deviation(portfolio)

    print(f"\n{'─'*40}")
    print(f"  持仓数: {result['portfolio_summary']['holding_count']}")
    print(f"  总资产: ¥{result['portfolio_summary']['total_asset']:,.0f}")
    print(f"  仓位: {result['position_deviation']['actual_pct']:.1f}%")
    print(f"{'─'*40}")

    # ETF 覆盖度
    etf = result["etf_coverage"]
    print(f"\n  ETF 占比: {etf['coverage_pct']:.0f}% ({etf['etf_count']} 只, 宽基 {etf['broad_etf_pct']:.0f}% / 行业 {etf['sector_etf_pct']:.0f}%) [{etf['verdict']}]")

    # 集中度
    conc = result["concentration"]
    print(f"\n  最大持仓: {conc['max_name']} ({conc['max_pct']:.1f}%) [{conc['verdict']}]")
    for a in conc["alerts"][:3]:
        print(f"    ⚠️ {a['name']}: {a['pct']:.1f}% [{a['severity']}]")

    # 减仓候选
    red = result["reduction_candidates"]
    if red["candidates"]:
        print(f"\n  🔴 首批减仓候选: {red['count']} 只 (合计 ¥{red['total_value']:,.0f})")
        for c in red["candidates"]:
            print(f"    {c['name']}: 占比{c['pct']:.1f}% 浮盈{c['pnl_pct']:+.1f}%")
            for r in c["reasons"]:
                print(f"      → {r}")

    # 健康度
    h = result["health_score"]
    print(f"\n  健康度评分: {h['score']} ({h['grade']})")
    for k, v in h["breakdown"].items():
        print(f"    {k}: {v} (×{h['weights'][k]:.0%})")

    print(f"\n{'='*60}")
