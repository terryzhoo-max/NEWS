"""
AlphaCore · NLP 情报 API 路由 (P2-C)
======================================
/api/v1/intelligence/scan      POST  手动触发新闻扫描
/api/v1/intelligence/latest    GET   获取最新情报
/api/v1/intelligence/history   GET   查询历史事件
"""

import asyncio
from concurrent.futures import ThreadPoolExecutor
from fastapi import APIRouter, Query
from typing import Optional
from services.logger import get_logger
from services import db as ac_db

logger = get_logger("intelligence.api")
router = APIRouter(prefix="/api/v1/intelligence", tags=["Intelligence"])

_nlp_executor = ThreadPoolExecutor(max_workers=1, thread_name_prefix="nlp")


def _content_as_of(data: dict):
    """情报内容的时间 (北京时间 MM-DD HH:MM): 缓存的 scan_time (本地时间), 否则事件最晚 created_at (SQLite UTC)。"""
    from datetime import datetime, timezone, timedelta
    st = (data or {}).get("scan_time")
    if st:
        try:
            return datetime.fromisoformat(str(st)).strftime("%m-%d %H:%M")
        except ValueError:
            pass
    stamps = [e.get("created_at") for e in (data or {}).get("events") or [] if isinstance(e, dict) and e.get("created_at")]
    if not stamps:
        return None
    try:
        utc = datetime.strptime(max(stamps)[:19], "%Y-%m-%d %H:%M:%S").replace(tzinfo=timezone.utc)
        return utc.astimezone(timezone(timedelta(hours=8))).strftime("%m-%d %H:%M")
    except ValueError:
        return None


def _paused_block(data: dict):
    """AI 服务暂停时的说明 (首页显示"已暂停 · 内容截至 MM-DD HH:MM", 旧内容不冒充实时)。"""
    from services.job_switches import ai_paused
    p = ai_paused()
    if p is None:
        return None
    as_of = _content_as_of(data)
    return {**p, "content_as_of": as_of,
            "label": f"已暂停 · 内容截至 {as_of}" if as_of else "已暂停 · 暂无内容"}


@router.post("/scan")
async def trigger_scan():
    """手动触发 NLP 新闻扫描 (非阻塞, 后台执行)"""
    from engines.news_intelligence import scan_news, get_latest_intelligence

    paused = _paused_block(get_latest_intelligence())
    if paused is not None:
        return {"status": "paused", "message": paused["message"], "paused": paused}

    try:
        loop = asyncio.get_event_loop()
        result = await loop.run_in_executor(_nlp_executor, scan_news)
        return {"status": "success", "data": result}
    except Exception as e:
        logger.error("[NLP API] 扫描异常: %s", e)
        return {"status": "error", "message": str(e)}


@router.get("/latest")
async def get_latest():
    """获取最新情报 (缓存优先)"""
    from engines.news_intelligence import get_latest_intelligence

    try:
        result = get_latest_intelligence()
        paused = _paused_block(result)
        if paused is not None:
            result = {**result, "paused": paused}
        return {"status": "success", "data": result}
    except Exception as e:
        return {"status": "error", "message": str(e)}


@router.get("/history")
async def get_history(
    category: Optional[str] = Query(None, description="筛选: macro/industry/stock/risk"),
    limit: int = Query(20, ge=1, le=100),
):
    """查询历史事件"""
    try:
        events = ac_db.get_news_events(category=category, limit=limit)
        return {"status": "success", "data": events, "total": len(events)}
    except Exception as e:
        return {"status": "error", "message": str(e)}
