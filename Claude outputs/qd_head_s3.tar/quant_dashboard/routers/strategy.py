"""
AlphaCore · 策略 API 路由
==========================
Batch 7 架构解耦: 从 main.py 提取全部策略 API

包含:
  - /api/v1/strategy (均值回归)
  - /api/v1/dividend_strategy (红利趋势)
  - /api/v1/momentum_strategy (动量轮动)
  - /api/v1/erp_strategy (ERP择时)
  - /api/v1/aiae_strategy (AIAE ETF信号)
  - /api/v1/strategy/run-all (五策略并行 + 共振 + 风险覆盖)
"""

import asyncio
import threading
from datetime import datetime as _dt
from concurrent.futures import ThreadPoolExecutor

from fastapi import APIRouter, Query
from services.logger import get_logger

logger = get_logger("strategy")

from mean_reversion_engine import run_strategy
from dividend_trend_engine import run_dividend_strategy
from momentum_rotation_engine import run_momentum_strategy
from engines.dual_momentum_engine import run_gem_strategy
from erp_timing_engine import get_erp_engine
from aiae_engine import get_aiae_engine
from services.cache_service import cache_manager, stale_while_revalidate, adaptive_fresh_ttl
# P0-4: 使用统一的策略缓存写入锁 (与 dashboard_builder / main.py 共享同一实例)
from services.dashboard_builder import _STRATEGY_LOCK

router = APIRouter(prefix="/api/v1", tags=["strategy"])
executor = ThreadPoolExecutor(max_workers=10)


# ─────────────────────────────────────────────
# ERP 标的池定义
# ─────────────────────────────────────────────
ERP_TARGET_POOL = [
    {"ts_code": "510300.SH", "name": "沪深300ETF", "style": "核心宽基"},
    {"ts_code": "510500.SH", "name": "中证500ETF", "style": "中盘成长"},
    {"ts_code": "510880.SH", "name": "红利ETF",    "style": "防御红利"},
    {"ts_code": "510900.SH", "name": "H股ETF",     "style": "港股宽基"},
]


# ═══════════════════════════════════════════════
#  单策略 API
# ═══════════════════════════════════════════════

# ── V22.0: 信号参数对比 (旧通用 vs 新资产分类) ──

@router.get("/strategy/signal-compare")
async def signal_compare():
    """
    对比新旧参数系统的信号差异。
    使用缓存的 MR 信号数据 + 资产类别参数重新评分。
    """
    try:
        from services.cache_service import cache_manager
        from engines.mean_reversion_engine import (
            calculate_score, get_asset_params, get_asset_class_label,
            FALLBACK_PARAMS, MR_POOL,
        )

        cached = cache_manager.get_json("strategy_results", {})
        mr_data = cached.get("mr", {})
        if isinstance(mr_data, dict):
            signals = mr_data.get("data", {}).get("buy_signals", []) + \
                      mr_data.get("data", {}).get("hold_signals", []) + \
                      mr_data.get("data", {}).get("sell_signals", [])
        else:
            signals = []

        if not signals:
            return {"status": "error", "message": "无缓存 MR 信号, 请先运行策略"}

        comparison = []
        for s in signals[:25]:  # 最多 25 只
            code = s.get("ts_code") or s.get("code", "")
            name = s.get("name", "")
            regime = s.get("regime", "RANGE")

            # 当前信号分数
            old_score = s.get("signal_score") or s.get("score", 0)

            # 用新参数重算评分 (基于现有指标值的理论分数)
            # 注意: 这里用现有指标近似估算, 非完整重新计算
            try:
                asset_class = get_asset_class_label(code, name)
                new_params = get_asset_params(code, regime, name)
                old_params = FALLBACK_PARAMS.get(regime, FALLBACK_PARAMS["RANGE"])

                # 关键参数差异
                rsi_buy_old = old_params.get("rsi_buy", 40)
                rsi_buy_new = new_params.get("rsi_buy", 40)
                bias_buy_old = old_params.get("bias_buy", -2.0)
                bias_buy_new = new_params.get("bias_buy", -2.0)
                stop_old = f'{old_params.get("stop_loss", 0.07)*100:.0f}%'
                stop_new = f'{new_params.get("stop_loss", 0.08)*100:.0f}%'

                rsi_val = s.get("rsi", 50)
                # RSI 阈值越紧 → 信号越难触发 → 当前分数理论降低
                rsi_delta = (rsi_buy_old - rsi_buy_new) * (-0.3)  # 粗略映射
                bias_val = s.get("bias", 0)
                bias_delta = (abs(bias_buy_old) - abs(bias_buy_new)) * 1.5

                new_score_est = min(100, max(0, round(old_score + rsi_delta + bias_delta)))
                score_delta = round(new_score_est - old_score, 1)

                comparison.append({
                    "code": code,
                    "name": name,
                    "asset_class": asset_class,
                    "regime": regime,
                    "old_score": old_score,
                    "new_score_est": new_score_est,
                    "score_delta": score_delta,
                    "rsi_buy_old": rsi_buy_old,
                    "rsi_buy_new": rsi_buy_new,
                    "bias_buy_old": bias_buy_old,
                    "bias_buy_new": bias_buy_new,
                    "stop_loss_old": stop_old,
                    "stop_loss_new": stop_new,
                })
            except Exception:
                comparison.append({
                    "code": code, "name": name, "error": "计算异常",
                })

        # 统计
        improved = sum(1 for c in comparison if c.get("score_delta", 0) > 3)
        worsened = sum(1 for c in comparison if c.get("score_delta", 0) < -3)
        changed = sum(1 for c in comparison if abs(c.get("score_delta", 0)) > 3)

        return {
            "status": "success",
            "total": len(comparison),
            "improved": improved,
            "worsened": worsened,
            "unchanged": len(comparison) - changed,
            "comparison": comparison,
        }
    except Exception as e:
        logger.error(f"Signal Compare Error: {e}", exc_info=True)
        return {"status": "error", "message": str(e)}


@router.get("/strategy")
async def get_strategy(refresh: bool = False):
    """均值回归策略详情 — V4.2 含缓存优化"""
    from dashboard_modules.run_strategies import wrap_mr_results
    cached = cache_manager.get_json("strategy_results", {}).get("mr")
    if cached and not refresh:
        if isinstance(cached, dict) and "status" in cached:
            return cached
        return wrap_mr_results(cached)
    raw = await asyncio.get_running_loop().run_in_executor(executor, run_strategy)
    wrapped = wrap_mr_results(raw)
    with _STRATEGY_LOCK:
        _sr = cache_manager.get_json("strategy_results", {})
        _sr["mr"] = wrapped
        cache_manager.set_json("strategy_results", _sr, ttl_seconds=86400)
    return wrapped


@router.get("/dividend_strategy")
async def get_dividend_strategy(regime: str = None):
    """红利增强策略详情 V3.1 · 含缓存优化"""
    if regime and regime not in ("BULL", "RANGE", "BEAR", "CRASH"):
        return {"status": "error", "message": f"无效 regime: {regime}"}
    if not regime:
        cached = cache_manager.get_json("strategy_results", {}).get("div")
        if cached:
            return cached
    result = await asyncio.get_running_loop().run_in_executor(
        executor, lambda: run_dividend_strategy(regime=regime)
    )
    if not regime and isinstance(result, dict) and result.get("status") == "success":
        with _STRATEGY_LOCK:
            _sr = cache_manager.get_json("strategy_results", {})
            _sr["div"] = result
            cache_manager.set_json("strategy_results", _sr, ttl_seconds=86400)
    return result


@router.get("/momentum_strategy")
async def get_momentum_strategy():
    """行业动量策略详情 — V3.1 含缓存写回"""
    cached = cache_manager.get_json("strategy_results", {}).get("mom")
    if cached:
        return cached
    result = await asyncio.get_running_loop().run_in_executor(executor, run_momentum_strategy)
    # V3.1: 写回缓存，供页面自动加载和后续请求复用
    if isinstance(result, dict) and result.get("status") == "success":
        with _STRATEGY_LOCK:
            _sr = cache_manager.get_json("strategy_results", {})
            _sr["mom"] = result
            cache_manager.set_json("strategy_results", _sr, ttl_seconds=86400)
    return result


# ─────────────────────────────────────────────
# GEM 双重动量策略 (第 1.5 层战术资产配置)
# ─────────────────────────────────────────────
_GEM_SWR_KEY = "swr_gem_strategy"
_GEM_FRESH_TTL = 1800   # 30 分钟内直接返回缓存 (GEM 月度调仓, 不需要秒级)
_GEM_STALE_TTL = 21600  # 6 小时过期容忍 (Tushare 限频, 避免重复调用)


def _run_gem_strategy() -> dict:
    """GEM 策略执行包装 (与其他策略统一格式)"""
    try:
        result = run_gem_strategy()
        # 同步写入 strategy_results 缓存 (供 run-all / decision hub 读取)
        with _STRATEGY_LOCK:
            _sr = cache_manager.get_json("strategy_results", {})
            _sr["gem"] = result
            cache_manager.set_json("strategy_results", _sr, ttl_seconds=86400)
        return result
    except Exception as e:
        logger.error(f"GEM Strategy Error: {e}", exc_info=True)
        return {"status": "error", "message": str(e)}


@router.get("/gem_strategy")
async def get_gem_strategy_api(refresh: int = 0):
    """双重动量策略信号 (GEM) — 第 1.5 层战术资产配置

    生产级接口:
      - SWR 三级缓存 (Fresh 30min / Stale 6h / Miss 同步计算)
      - ?refresh=1 强制跳过缓存重新计算
      - 计算结果同时写入 strategy_results (供 run-all / decision hub 联动)
    """
    # ?refresh=1 → 清除 SWR 缓存, 强制重算
    if refresh:
        from services.cache_service import swr_clear
        swr_clear(_GEM_SWR_KEY)
        # 同时清除 strategy_results 中的 gem 缓存
        with _STRATEGY_LOCK:
            _sr = cache_manager.get_json("strategy_results", {})
            _sr.pop("gem", None)
            cache_manager.set_json("strategy_results", _sr, ttl_seconds=86400)

    # 优先检查 strategy_results 缓存 (run-all 写入的)
    cached = cache_manager.get_json("strategy_results", {}).get("gem")
    if cached and not refresh:
        if isinstance(cached, dict) and cached.get("status") == "success":
            return cached

    # SWR 三级缓存
    return await asyncio.get_running_loop().run_in_executor(
        executor,
        lambda: stale_while_revalidate(_GEM_SWR_KEY, _run_gem_strategy, adaptive_fresh_ttl(1800, 'strategy'), _GEM_STALE_TTL)
    )


# ─────────────────────────────────────────────
# ERP 宏观择时策略
# ─────────────────────────────────────────────
def _unavailable(reason: str) -> dict:
    """2026-11-01 数据质量审计 #3/#10: 引擎降级或决策锁定时不生成任何 ETF 信号 (fail closed)。
    run-all 汇总会把 status=unavailable 记入 degraded_strategies。"""
    return {"status": "unavailable", "message": reason,
            "data": {"signals": [], "market_overview": {}}}


def _run_erp_strategy() -> dict:
    """ERP策略执行：获取宏观评分 → 对标的池ETF生成标准化信号"""
    try:
        engine = get_erp_engine()
        report = engine.compute_signal()
        if report.get("status") == "fallback":
            return _unavailable(f"ERP 引擎降级, 不生成信号: {report.get('message', '数据异常')}")
        if report.get("status") != "success":
            return {"status": "error", "message": report.get("message", "ERP引擎异常")}

        score = report["signal"]["score"]
        snap = report["current_snapshot"]
        dims = report["dimensions"]

        if score >= 55:
            std_signal = "buy"
        elif score <= 40:
            std_signal = "sell"
        else:
            std_signal = "hold"

        pos_map = {"buy": 80, "hold": 50, "sell": 0}
        base_pos = pos_map.get(std_signal, 50)

        signals = []
        for etf in ERP_TARGET_POOL:
            signals.append({
                "name": etf["name"], "ts_code": etf["ts_code"],
                "code": etf["ts_code"].split(".")[0],
                "signal": std_signal, "signal_score": round(score),
                "suggested_position": base_pos if std_signal == "buy" else 0,
                "style": etf["style"],
                "erp_abs": snap.get("erp_value", 0),
                "erp_pct": snap.get("erp_percentile", 0),
                "m1_yoy": dims.get("m1_trend", {}).get("m1_info", {}).get("current", 0),
                "pe_vol": dims.get("volatility", {}).get("vol_info", {}).get("current_vol", 0),
                "scissor": dims.get("credit", {}).get("credit_info", {}).get("scissor", 0),
            })

        buy_count = sum(1 for s in signals if s["signal"] == "buy")
        sell_count = sum(1 for s in signals if s["signal"] == "sell")

        return {
            "status": "success", "timestamp": _dt.now().isoformat(),
            "data": {
                "signals": signals,
                "market_overview": {
                    "composite_score": round(score),
                    "signal_key": std_signal,
                    "signal_label": report["signal"]["label"],
                    "buy_count": buy_count, "sell_count": sell_count,
                    "total_suggested_pos": sum(s["suggested_position"] for s in signals if s["signal"] == "buy"),
                },
            },
        }
    except Exception as e:
        logger.error(f"ERP Strategy Error: {e}", exc_info=True)
        return {"status": "error", "message": str(e)}


@router.get("/erp_strategy")
async def get_erp_strategy():
    """ERP宏观择时策略实时信号"""
    return await asyncio.get_running_loop().run_in_executor(executor, _run_erp_strategy)


# ─────────────────────────────────────────────
# AIAE 宏观仓位管控策略
# ─────────────────────────────────────────────
def _run_aiae_strategy() -> dict:
    """AIAE策略执行：获取AIAE五档判定 → 对ETF标的池生成标准化信号"""
    try:
        engine = get_aiae_engine()
        report = engine.generate_report()

        if report.get("status") == "fallback":
            return _unavailable(f"AIAE 引擎降级, 不生成信号: {report.get('message', '数据异常')}")
        if report.get("status") != "success":
            return {"status": "error", "message": "AIAE引擎异常"}
        if report.get("decision_locked"):
            return _unavailable(f"AIAE 数据质量不足 (得分 {report.get('data_quality_score')}), 决策锁定, 不生成信号")

        regime = report["current"]["regime"]
        regime_info = report["current"]["regime_info"]
        aiae_v1 = report["current"]["aiae_v1"]
        matrix_pos = report["position"]["matrix_position"]

        signals = engine.generate_etf_signals(regime, matrix_position=matrix_pos)

        erp_score_for_weights = None
        erp_score_source = None
        try:
            erp_eng = get_erp_engine()
            erp_sig = erp_eng.compute_signal()
            if erp_sig.get("status") == "success":
                # 2026-10-30: 与首页市场温度同一口径 — ERP v4 分档仓位 (旧综合分在 Step3 验证中无预测力);
                # v4 不可用时退回旧综合分, 并在 erp_score_source 标明
                _v4 = (erp_sig.get("current_snapshot") or {}).get("allocation_v4") or {}
                if _v4.get("tier_position_pct") is not None:
                    erp_score_for_weights = float(_v4["tier_position_pct"])
                    erp_score_source = "v4_tier"
                else:
                    erp_score_for_weights = erp_sig["signal"].get("score", None)
                    erp_score_source = "legacy_score" if erp_score_for_weights is not None else None
        except Exception:
            pass

        run_all_weights, erp_tier = engine.get_run_all_weights(regime, erp_score_for_weights)

        buy_count = sum(1 for s in signals if s["signal"] == "buy")
        sell_count = sum(1 for s in signals if s["signal"] == "sell")

        return {
            "status": "success", "timestamp": _dt.now().isoformat(),
            "data": {
                "signals": signals,
                "market_overview": {
                    "aiae_value": aiae_v1, "regime": regime,
                    "regime_cn": regime_info["cn"], "matrix_position": matrix_pos,
                    "buy_count": buy_count, "sell_count": sell_count,
                    "composite_score": max(10, 100 - (regime - 1) * 20),
                    "erp_score_for_weights": erp_score_for_weights,
                    "erp_tier": erp_tier,
                    # P1-b (2026-10-30): ERP 只在 AIAE 矩阵计一次; 关闭时 erp_tier 恒为 neutral, 不代表 ERP 观点
                    "erp_score_source": erp_score_source,
                    "erp_tier_mode": ("erp_score" if getattr(__import__("aiae_params"), "RUN_ALL_ERP_TIER_ENABLED", True)
                                      else "disabled_dedup"),
                },
                "run_all_weights": run_all_weights,
                "erp_tier": erp_tier,
                "aiae_report": report,
            },
        }
    except Exception as e:
        logger.error(f"AIAE Strategy Error: {e}", exc_info=True)
        # 2026-10-31: 不再用写死的读数 (AIAE 22.0% / Ⅲ档 / 矩阵 55% / 5 只买入) 冒充实时结果;
        # 引擎失败就如实返回不可用, 由前端显示"AIAE 不可用"。
        return {
            "status": "unavailable", "timestamp": _dt.now().isoformat(), "message": str(e),
            "data": {
                "signals": [],
                "market_overview": {
                    "aiae_value": None, "regime": None, "regime_cn": None,
                    "matrix_position": None, "buy_count": 0, "sell_count": 0,
                },
                "run_all_weights": None,
            },
        }


@router.get("/aiae_strategy")
async def get_aiae_strategy():
    """AIAE ETF标的池实时信号"""
    return await asyncio.get_running_loop().run_in_executor(executor, _run_aiae_strategy)


# ═══════════════════════════════════════════════
#  五策略并行 + 共振分析 + 风险覆盖
# ═══════════════════════════════════════════════

def _extract_signals_normalized(strategy_type: str, raw_result) -> list:
    """从各策略原始返回中提取标准化信号列表"""
    if isinstance(raw_result, dict) and "data" in raw_result:
        return raw_result["data"].get("signals", [])
    if strategy_type == "mr" and isinstance(raw_result, list):
        return [s for s in raw_result if s.get("signal") != "error"]
    return []


# 2026-10-31: 原 _compute_resonance 已由 services/run_all_aggregation.compute_resonance 取代
#   (只在独立信号源之间投票, 宏观层不重复计数, 共振数不含分歧)。


def _compute_risk_overlay(all_signals):
    """候选买入信号的板块分布 (仅说明)。
    2026-10-31: 删除波动率预警 — 没有任何策略输出 vol_30d / annualized_vol, 该分支恒为空;
    账户真实风险见 /api/v1/aiae/deviation。"""
    sector_counts = {}

    for s in all_signals:
        group = s.get("group", s.get("sector", "unknown"))
        if group and group != "unknown":
            sector_counts[group] = sector_counts.get(group, 0) + 1

    top_sector = max(sector_counts, key=sector_counts.get) if sector_counts else "N/A"
    top_ratio = round(sector_counts.get(top_sector, 0) / max(len(all_signals), 1) * 100) if sector_counts else 0

    return {
        "concentration": {
            "top_sector": top_sector, "ratio": f"{top_ratio}%",
            "sectors": dict(sorted(sector_counts.items(), key=lambda x: x[1], reverse=True)[:5]),
        },
    }


@router.get("/strategy/run-all")
async def run_all_strategies_api(override_cap: int = Query(default=None, ge=0, le=100)):
    """V5.0 六策略并行执行 (MR+DIV+MOM+GEM+ERP+AIAE_ETF) + 汇总层 (2026-10-31)

    汇总只针对独立信号源 (MR/DIV/MOM/GEM), 并标注各自验证状态; 宏观层只作背景。
    不再输出自算总仓位 — 仓位以 AIAE 执行目标为准。override_cap 参数保留兼容, 已不再生效。
    """
    loop = asyncio.get_running_loop()

    try:
        # ── 并行执行6策略 ──
        mr_task   = loop.run_in_executor(executor, run_strategy)
        div_task  = loop.run_in_executor(executor, lambda: run_dividend_strategy(regime=None))
        mom_task  = loop.run_in_executor(executor, run_momentum_strategy)
        gem_task  = loop.run_in_executor(executor, _run_gem_strategy)
        erp_task  = loop.run_in_executor(executor, _run_erp_strategy)
        aiae_task = loop.run_in_executor(executor, _run_aiae_strategy)

        results = await asyncio.gather(
            mr_task, div_task, mom_task, gem_task, erp_task, aiae_task,
            return_exceptions=True,
        )

        # ── V5.2: 错误隔离 — 异常策略降级为空结果，不阻塞其他策略 ──
        _FALLBACK = {"status": "error", "data": {"signals": [], "market_overview": {}}}
        degraded = []
        _names = ["mr", "div", "mom", "gem", "erp", "aiae"]
        sanitized = []
        for i, (sname, r) in enumerate(zip(_names, results)):
            if isinstance(r, Exception):
                logger.error(f"策略 {sname} 执行异常(已隔离): {r}")
                degraded.append(sname)
                sanitized.append(_FALLBACK.copy())
            else:
                sanitized.append(r)
        mr_raw, div_raw, mom_raw, gem_raw, erp_raw, aiae_raw = sanitized

        from dashboard_modules.run_strategies import wrap_mr_results
        mr_result = wrap_mr_results(mr_raw) if isinstance(mr_raw, list) else mr_raw
        div_result, mom_result, gem_result, erp_result, aiae_result = div_raw, mom_raw, gem_raw, erp_raw, aiae_raw

        with _STRATEGY_LOCK:
            _sr = cache_manager.get_json("strategy_results", {})
            _sr["mr"] = mr_result; _sr["div"] = div_result; _sr["mom"] = mom_result
            _sr["gem"] = gem_result; _sr["erp"] = erp_result; _sr["aiae"] = aiae_result
            _sr["_cached_at"] = _dt.now().isoformat()
            cache_manager.set_json("strategy_results", _sr, ttl_seconds=86400)  # 24h TTL

        # 提取标准化信号
        mr_signals   = _extract_signals_normalized("mr", mr_result)
        div_signals  = _extract_signals_normalized("div", div_result)
        mom_signals  = _extract_signals_normalized("mom", mom_result)
        gem_signals  = _extract_signals_normalized("gem", gem_result)
        erp_signals  = _extract_signals_normalized("erp", erp_result)
        aiae_signals = _extract_signals_normalized("aiae_etf", aiae_result)

        # ── 2026-10-31 汇总层 (services/run_all_aggregation.py) ──
        # 只汇总独立信号源 MR/DIV/MOM/GEM; ERP 旧综合分与 AIAE ETF 池属于宏观层, 只作背景不再投票。
        # 各信号源带验证状态, 不拦截信号, 只分层。总仓位以 AIAE 执行目标为准 (/api/v1/aiae/deviation),
        # 本接口不再输出自算仓位 (旧 total_position 及其 MA Cap / 地板 / 一致性折扣参数链均未经验证, 已移除)。
        from services import run_all_aggregation as agg

        signals_by_sleeve = {"mr": mr_signals, "div": div_signals, "mom": mom_signals, "gem": gem_signals,
                             "erp": erp_signals, "aiae_etf": aiae_signals}

        # 全局指标
        div_ov  = div_result.get("data", {}).get("market_overview", {}) if isinstance(div_result, dict) else {}
        mom_ov  = mom_result.get("data", {}).get("market_overview", {}) if isinstance(mom_result, dict) else {}
        aiae_ov = aiae_result.get("data", {}).get("market_overview", {}) if isinstance(aiae_result, dict) else {}

        mr_regime = mr_signals[0].get("regime") if mr_signals else None   # 无 MR 信号 → 状态未知, 不默认震荡
        div_regime = div_result.get("data", {}).get("regime_params", {}).get("regime") if isinstance(div_result, dict) else None
        mom_regime = mom_ov.get("regime")

        # 返回了"出错/不可用"状态 (而非抛异常) 的策略同样计入降级, 供页面提示
        for _name, _res in (("mr", mr_result), ("div", div_result), ("mom", mom_result), ("gem", gem_result),
                            ("erp", erp_result), ("aiae", aiae_result)):
            if isinstance(_res, dict) and _res.get("status") in ("error", "unavailable") and _name not in degraded:
                degraded.append(_name)

        evidence = agg.sleeve_evidence(mr_regime, mom_regime)
        try:   # 2026-11-02: 发布给审计页策略健康读取, 保证两处验证状态同源
            cache_manager.set_json("sleeve_evidence", {"evidence": evidence, "mr_regime": mr_regime,
                                                        "mom_regime": mom_regime, "as_of": _dt.now().isoformat(timespec="seconds")},
                                   ttl_seconds=86400)
        except Exception:
            pass
        signal_counts = agg.count_signals(signals_by_sleeve, evidence)
        resonance = agg.compute_resonance(signals_by_sleeve)
        action_signals = agg.rank_action_signals(signals_by_sleeve, evidence)
        regime_info = agg.regime_labels(mr_regime, div_regime, mom_regime)
        meta = agg.sleeve_meta({"mr": mr_result, "div": div_result, "mom": mom_result, "gem": gem_result,
                                "erp": erp_result, "aiae_etf": aiae_result}, degraded)

        # 候选信号的板块分布 (仅独立信号源; 账户真实风险见 /api/v1/aiae/deviation)
        risk_overlay = _compute_risk_overlay(
            [s for k in agg.SIGNAL_SLEEVES for s in signals_by_sleeve[k] if s.get("signal") == "buy"])
        risk_overlay["basis"] = "candidate_signals"

        # 子策略权重 (AIAE×ERP 矩阵, 仅展示) 与买入信号平均建议仓位
        def _avg_confidence(signals_list):
            buy_sigs = [s for s in signals_list if s.get("signal") == "buy"]
            if not buy_sigs:
                return 0.0
            positions = [s.get("suggested_position", 0) or 0 for s in buy_sigs]
            return sum(positions) / len(positions)

        aiae_ok = isinstance(aiae_result, dict) and aiae_result.get("status") == "success"
        aiae_regime = aiae_ov.get("regime") if aiae_ok else None
        # 权重表依赖 AIAE 档位; AIAE 不可用时不展示权重, 不再按默认 Ⅲ 档猜
        w = aiae_result.get("data", {}).get("run_all_weights") if aiae_ok else None
        erp_tier = aiae_result.get("data", {}).get("erp_tier", "neutral") if aiae_ok else "neutral"

        consistency = "high" if regime_info["consistent"] else "medium"

        return {
            "status": "success", "timestamp": _dt.now().isoformat(),
            "data": {
                "global": {
                    "regime": mr_regime,
                    "position_source": "aiae_execution_target",   # 仓位见 /api/v1/aiae/deviation.execution_target
                    "override_cap_ignored": override_cap is not None,
                    "total_buy": signal_counts["total"]["buy"], "total_sell": signal_counts["total"]["sell"],
                    "signal_counts": signal_counts,
                    "evidence": evidence,
                    "consistency": consistency, "regime_map": regime_info["labels"],
                    "regime_labels": regime_info,
                    "strategy_count": 6,
                    "degraded_strategies": degraded,
                    "confidence": {
                        "mr": round(_avg_confidence(mr_signals)), "div": round(_avg_confidence(div_signals)),
                        "mom": round(_avg_confidence(mom_signals)), "gem": round(_avg_confidence(gem_signals)),
                        "erp": round(_avg_confidence(erp_signals)), "aiae_etf": round(_avg_confidence(aiae_signals)),
                    },
                    "weights": w,
                    "weights_note": "AIAE×ERP 联合权重表, 未经验证, 仅展示",
                    "aiae": {
                        "available": aiae_ok,
                        "regime": aiae_regime, "regime_cn": aiae_ov.get("regime_cn") if aiae_ok else None,
                        "aiae_value": aiae_ov.get("aiae_value") if aiae_ok else None,
                        "erp_tier": erp_tier,
                    },
                },
                "strategies": {
                    "mr": mr_result.get("data", mr_result) if isinstance(mr_result, dict) else {"signals": mr_signals},
                    "div": div_result.get("data", div_result) if isinstance(div_result, dict) else {"signals": div_signals},
                    "mom": mom_result.get("data", mom_result) if isinstance(mom_result, dict) else {"signals": mom_signals},
                    "gem": gem_result.get("data", gem_result) if isinstance(gem_result, dict) else {"signals": gem_signals},
                    "erp": erp_result.get("data", erp_result) if isinstance(erp_result, dict) else {"signals": erp_signals},
                    "aiae_etf": aiae_result.get("data", aiae_result) if isinstance(aiae_result, dict) else {"signals": aiae_signals},
                },
                "sleeve_meta": meta,
                "action_signals": action_signals,
                "resonance": resonance,
                "risk_overlay": risk_overlay,
            },
        }
    except Exception as e:
        import traceback
        logger.error(f"RUN-ALL 异常: {traceback.format_exc()}")
        return {"status": "error", "message": str(e)}
