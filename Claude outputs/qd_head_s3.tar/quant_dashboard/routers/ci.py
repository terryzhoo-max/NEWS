"""
AlphaCore · 策略 CI/CD API 路由 (P1-3)
========================================
/api/v1/ci/run         POST  手动触发 CI (只评估不发布; reason 必填)
/api/v1/ci/history     GET   查看历史 CI 记录 (0a-3 起含现算显示状态 approval_display)
/api/v1/ci/latest/{s}  GET   某策略最近一次 CI
/api/v1/ci/accept/{id} POST  人工批准: 只记录批准 + 返回参数补丁与审阅摘要 (0a-3), 不写任何配置文件

第 0 轮 0a-1 (2026-11-05, docs/ROUND0_CI_EVALUATE_ONLY_PLAN.md 3.1 / 3.2): 本路由不再发布任何参数。
第 0 轮 0a-3 (2026-11-05, 方案 3.4): 批准流程 A —— 参数经仓库提交、推送部署后生效;
补丁须先列给用户, 用户针对该 run_id 明确同意后才提交 (固定规则 9)。
"""

import asyncio
import uuid
from concurrent.futures import ThreadPoolExecutor
from fastapi import APIRouter, HTTPException, Query, Request
from pydantic import BaseModel, constr
from typing import Optional
from services.logger import get_logger
from services import db as ac_db
from services import write_log as _wl

logger = get_logger("ci.api")
router = APIRouter(prefix="/api/v1/ci", tags=["CI/CD"])

_ci_executor = ThreadPoolExecutor(max_workers=1, thread_name_prefix="ci")


class CIRunRequest(BaseModel):
    strategy: str = "all"       # "all" | "mr" | "erp"
    regime: Optional[str] = None  # MR 专用: "BEAR" | "RANGE" | "BULL"
    # 第 0 轮 0a-1: 触发理由必填, 去掉首尾空格后 2–200 字; 缺失或长度不符 → 422
    reason: constr(strip_whitespace=True, min_length=2, max_length=200)


_HEADER_MAX = 200


def _cut(value):
    return value[:_HEADER_MAX] if value else None


def _request_source(request: Request) -> dict:
    """请求来源 (/ci/run 与 /ci/accept 共用)。只记请求头里的来源信息与一个认证结果标记,
    不读取、不保存任何令牌值 (X-API-Key / Authorization 一概不碰)。"""
    from services import auth_middleware as _am

    h = request.headers
    return {
        "path": request.url.path,
        "client_host": request.client.host if request.client else None,
        "x_forwarded_for": _cut(h.get("x-forwarded-for")),
        "user_agent": _cut(h.get("user-agent")),
        "origin": _cut(h.get("origin")),
        "referer": _cut(h.get("referer")),
        "caller": _cut(h.get("x-ac-caller")),      # 前端 / curl 自带的调用方标记 (可选)
        # 能走到这里说明已过 ApiKeyMiddleware: 配了令牌 = 校验通过; 没配 = 开发模式免认证 (生产模式已被 503 拦下)
        "auth": "ok" if _am.API_SECRET_KEY else "not_required",
    }


def _api_trigger(request: Request, req: CIRunRequest) -> dict:
    """接口来源: 请求来源 + strategy / regime; reason 单独一列。"""
    detail = _request_source(request)
    detail["strategy"] = req.strategy
    detail["regime"] = req.regime
    return {"source": "api", "detail": detail, "reason": req.reason}


# ── POST /ci/run — 手动触发 CI ──
@router.post("/run")
async def trigger_ci(req: CIRunRequest, request: Request):
    """
    手动触发 CI 管道 (只评估不发布; 在 CI 线程池执行, 请求等待结果返回)
    注意: 全量优化耗时可能 5-30 分钟
    """
    from services.strategy_pipeline import run_full_ci, run_mr_ci, run_erp_ci

    trig = _api_trigger(request, req)
    # 第 0 轮 0a-4: batch_id 在这里生成 (流水线 resolve_trigger 沿用传入的 batch_id), 写操作日志同步记下
    trig["batch_id"] = uuid.uuid4().hex[:12]
    _wl.attach(request, kind="ci_run", strategy=req.strategy, regime=req.regime, reason=req.reason,
               batch_id=trig["batch_id"])
    logger.info("[CI API] 手动触发: strategy=%s regime=%s reason=%s client=%s",
                req.strategy, req.regime, req.reason, trig["detail"]["client_host"])

    def _run():
        if req.strategy == "all":
            return run_full_ci(trigger=trig)
        elif req.strategy == "mr":
            return run_mr_ci(regime=req.regime, trigger=trig)
        elif req.strategy == "erp":
            return run_erp_ci(trigger=trig)
        else:
            raise ValueError(f"Unknown strategy: {req.strategy}")

    try:
        loop = asyncio.get_event_loop()
        result = await loop.run_in_executor(_ci_executor, _run)
        _wl.attach(request, result="completed")
        return {"status": "success", "data": result}
    except Exception as e:
        logger.error("[CI API] 执行异常: %s", e)
        _wl.attach(request, result="error", error_code=type(e).__name__)
        raise HTTPException(status_code=500, detail=str(e))


# ── GET /ci/history — 查看历史 ──
@router.get("/history")
async def get_ci_history(
    strategy: Optional[str] = Query(None, description="筛选策略: mr / erp"),
    limit: int = Query(20, ge=1, le=100),
):
    """获取 CI 运行历史"""
    try:
        rows = ac_db.get_ci_history(strategy=strategy, limit=limit)
        return {"status": "success", "data": rows, "total": len(rows)}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# ── GET /ci/latest/{strategy} — 最近一次 CI ──
@router.get("/latest/{strategy}")
async def get_ci_latest(strategy: str):
    """获取某策略最近一次 CI 结果"""
    result = ac_db.get_ci_latest(strategy)
    if not result:
        return {"status": "success", "data": None, "message": f"无 {strategy} CI 记录"}
    return {"status": "success", "data": result}


# ── POST /ci/accept/{run_id} — 人工批准 (第 0 轮 0a-3: 批准流程 A) ──
NOTE_MIN, NOTE_MAX = 2, 200
SUPPORTED_VALIDATION_SCHEMAS = (1,)
# 拒绝 (409) 的原因码; 都不改记录, 返回当前状态
REJECT_MESSAGES = {
    "not_pending": "这条记录不是待批准 (PENDING) 状态, 不能批准",
    "strategy_not_approvable": ("ERP 记录不能批准: ERP CI 不产出冻结样本外验证 (validation 为空), "
                                "且 ERP_CI_AUTO_OPTIMIZE=False (10-24 起停用)"),
    "validation_missing": "没有冻结样本外验证结果 (validation 为空或缺 schema_version, 如迁移前的旧记录), 不当作通过",
    "validation_schema_unsupported": "validation 的 schema_version 不受支持",
    "superseded": "同一策略 / 状态已有更新的评估运行, 这条已被取代",
    "expired": "待批准超过 35 天, 已过期",
    "patch_invalid": "按当前运行时配置算参数补丁时校验不通过",
    "concurrent_update": "批准期间记录状态已变 (可能重复提交), 本次未改记录",
}


def _bad_request(code: str, message: str):
    raise HTTPException(status_code=400, detail={"code": code, "message": message})


def _current_state(rec: dict) -> dict:
    st = rec.get("_state") or {}
    return {"run_id": rec.get("run_id"), "strategy": rec.get("strategy"), "regime": rec.get("regime"),
            "status": rec.get("status"), "approval_status": rec.get("approval_status"),
            "approved_at": rec.get("approved_at"), "approval_display": st.get("label")}


def _reject(code: str, rec: dict, extra: Optional[str] = None):
    message = REJECT_MESSAGES[code] + (f": {extra}" if extra else "")
    logger.warning("[CI] 批准被拒: run_id=%s code=%s", rec.get("run_id"), code)
    raise HTTPException(status_code=409, detail={"code": code, "message": message,
                                                 "current": _current_state(rec)})


def _parse_accept_body(raw: bytes, run_id: str) -> str:
    """请求体 {confirm_run_id, note}: confirm_run_id 须与路径一致, note 去首尾空格后 2–200 字; 否则 400。"""
    import json as _json
    try:
        body = _json.loads(raw.decode("utf-8")) if raw else None
    except (UnicodeDecodeError, ValueError):
        _bad_request("invalid_json", "请求体须为 JSON: {\"confirm_run_id\": ..., \"note\": ...}")
    if not isinstance(body, dict):
        _bad_request("invalid_body", "请求体须为 JSON 对象: {\"confirm_run_id\": ..., \"note\": ...}")
    confirm = body.get("confirm_run_id")
    if not isinstance(confirm, str) or confirm != run_id:
        _bad_request("confirm_run_id_mismatch", "confirm_run_id 须与路径中的 run_id 完全一致")
    note = body.get("note")
    note = note.strip() if isinstance(note, str) else ""
    if not (NOTE_MIN <= len(note) <= NOTE_MAX):
        _bad_request("note_invalid", f"note 必填, 去掉首尾空格后 {NOTE_MIN}–{NOTE_MAX} 字")
    return note


def _eligibility(rec: dict) -> Optional[str]:
    """批准前的判定, 返回拒绝原因码 (None = 可批准)。顺序: 状态 → 策略 → 验证 → 取代 → 过期。"""
    if rec.get("approval_status") != "PENDING":
        return "not_pending"
    if str(rec.get("strategy") or "").lower() != "mr":
        return "strategy_not_approvable"
    validation = rec.get("validation")
    if not isinstance(validation, dict) or not validation or "schema_version" not in validation:
        return "validation_missing"
    if validation.get("schema_version") not in SUPPORTED_VALIDATION_SCHEMAS:
        return "validation_schema_unsupported"
    st = rec.get("_state") or {}
    if st.get("superseded"):
        return "superseded"
    if st.get("expired"):
        return "expired"
    return None


_UNCHANGED = "不变"
_LIFECYCLE_KEYS = ("status", "validated_at", "data_through", "validation_run_id", "next_validate_after")
_KPI_KEYS = (("sharpe", "Sharpe"), ("max_dd", "MaxDD"), ("calmar", "Calmar"),
             ("trades", "交易次数"), ("regime_days", "状态天数"))


def _param_rows(before: dict, after: dict) -> list:
    rows = []
    for name in list(before) + [k for k in after if k not in before]:
        b, a = before.get(name), after.get(name)
        changed = b != a
        rows.append({"name": name, "before": b, "after": a, "changed": changed,
                     "label": f"{b} → {a}" if changed else _UNCHANGED})
    return rows


def _kpi(metrics) -> dict:
    metrics = metrics if isinstance(metrics, dict) else {}
    return {label: metrics.get(key) for key, label in _KPI_KEYS}


def build_review(rec: dict, base: dict, updated: dict, patch: dict, *, approved_at: str, note: str) -> dict:
    """审阅摘要 (方案 3.4 字段原样), 供会话原样列给用户; 只读 rec / 两份配置, 不写任何东西。"""
    regime = str(rec.get("regime") or "").upper()
    mr_b = base["strategies"]["mr"]
    mr_a = updated["strategies"]["mr"]
    params = _param_rows(dict(mr_b["regimes"][regime]["params"]), dict(mr_a["regimes"][regime]["params"]))
    sl_b, sl_a = mr_b["stop_losses"].get(regime), mr_a["stop_losses"].get(regime)
    params.append({"name": "stop_loss", "before": sl_b, "after": sl_a, "changed": sl_b != sl_a,
                   "label": f"{sl_b} → {sl_a}" if sl_b != sl_a else _UNCHANGED})
    lc_b = mr_b["lifecycle"].get(regime) or {}
    lc_a = mr_a["lifecycle"].get(regime) or {}
    validation = rec.get("validation") or {}
    return {
        "run_id": rec.get("run_id"),
        "strategy": rec.get("strategy"),
        "regime": rec.get("regime"),
        "status": rec.get("status"),
        "created_at": rec.get("created_at"),
        "trigger_source": rec.get("trigger_source"),
        "params": params,
        "lifecycle": {"before": {k: lc_b.get(k) for k in _LIFECYCLE_KEYS},
                      "after": {k: lc_a.get(k) for k in _LIFECYCLE_KEYS}},
        "validation": {
            "method": validation.get("method"),
            "oos_start": validation.get("oos_start"),
            "data_through": validation.get("data_through"),
            "decision": validation.get("decision"),
            "reason": validation.get("reason"),
            "incumbent": _kpi(validation.get("incumbent")),
            "challenger": _kpi(validation.get("challenger")),
        },
        "quality_gate": [
            {"rule": g.get("rule"), "expected": g.get("expected"), "actual": g.get("actual"),
             "passed": g.get("passed")}
            for g in (rec.get("quality_gate") or []) if isinstance(g, dict)
        ],
        "revision": {"before": base.get("revision"), "after": updated.get("revision"),
                     "published_by": updated.get("published_by")},
        "approved_at": approved_at,
        "note": note,
        "effect": ("只记录批准, 未改任何配置文件。参数经仓库提交、推送部署后生效; "
                   "提交前须用户针对本 run_id 明确同意 (固定规则 9)"),
    }


@router.post("/accept/{run_id}")
async def accept_ci_run(run_id: str, request: Request):
    """
    第 0 轮 0a-3 (2026-11-05): 只记录批准, 返回参数补丁与审阅摘要, 不写任何配置文件。
    - 鉴权由 ApiKeyMiddleware 在前 (无令牌 401)
    - 请求体 {confirm_run_id, note} 不合规 → 400; run_id 不存在 → 404
    - 非 PENDING / ERP / validation 缺失 / 已被取代 / 已过期 / 补丁校验不通过 → 409 (不改记录, 返回当前状态)
    """
    from datetime import datetime as _dt
    from services.strategy_params import (RUNTIME_TIMEZONE, build_ci_patch, compute_ci_update,
                                          load_runtime_config)

    _wl.attach(request, kind="ci_accept", run_id=run_id[:64], result="rejected")
    try:
        note = _parse_accept_body(await request.body(), run_id)
    except HTTPException as exc:
        _wl.attach(request, error_code=(exc.detail or {}).get("code") if isinstance(exc.detail, dict) else None)
        raise
    _wl.attach(request, note=note)

    base = load_runtime_config(force=True)
    now = _dt.now(RUNTIME_TIMEZONE)
    rec = ac_db.get_ci_run_state(run_id, runtime_config=base)
    if rec is None:
        _wl.attach(request, error_code="not_found")
        raise HTTPException(status_code=404, detail={"code": "not_found", "message": f"run_id 不存在: {run_id[:64]}"})

    code = _eligibility(rec)
    if code:
        _wl.attach(request, error_code=code)
        _reject(code, rec)

    run = {k: v for k, v in rec.items() if k != "_state"}
    try:
        updated = compute_ci_update(base, run, now=now)
        patch = build_ci_patch(base, run, now=now)
    except (ValueError, KeyError, TypeError) as exc:
        _wl.attach(request, error_code="patch_invalid")
        _reject("patch_invalid", rec, str(exc)[:200])

    approved_at = now.isoformat()
    detail = _request_source(request)
    detail["note"] = note
    if not ac_db.approve_ci_run(run_id, approved_at, detail):
        rec = ac_db.get_ci_run_state(run_id, runtime_config=base) or rec
        _wl.attach(request, error_code="concurrent_update")
        _reject("concurrent_update", rec)
    _wl.attach(request, result="approved", error_code=None, approved_at=approved_at,
               base_revision=patch.get("base_revision"))

    review = build_review(run, base, updated, patch, approved_at=approved_at, note=note)
    logger.info("[CI] 批准已记录 (未改配置): run_id=%s regime=%s base_revision=%s",
                run_id, run.get("regime"), base.get("revision"))
    return {"status": "success", "data": {
        "run_id": run_id,
        "approval_status": "APPROVED",
        "approved_at": approved_at,
        "patch": patch,
        "review": review,
    }}


# ── GET /ci/quality-gate — 质量门配置 ──
@router.get("/quality-gate")
async def get_quality_gate():
    """返回当前质量门阈值配置"""
    from services.strategy_pipeline import QUALITY_GATE
    return {"status": "success", "data": QUALITY_GATE}
