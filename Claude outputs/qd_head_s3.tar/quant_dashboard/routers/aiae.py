"""AlphaCore AIAE 宏观仓位 + MR参数 + 港股ERP API — 从 main.py 提取"""
import asyncio
import time
import json
import os

import traceback
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor
from fastapi import APIRouter
from services.logger import get_logger

logger = get_logger("aiae")

from models.schemas import (
    FundPositionUpdate, HKSouthboundUpdate, HKAHPremiumUpdate,
    JPMarginUpdate, JPForeignUpdate,
)
from aiae_engine import get_aiae_engine
from aiae_us_engine import get_us_aiae_engine
from aiae_jp_engine import get_jp_aiae_engine
from aiae_hk_engine import get_hk_aiae_engine
from erp_hk_engine import get_hk_erp_engine
from mean_reversion_engine import detect_regime, get_all_regime_params, needs_reoptimize
# Batch 7: 统一缓存层 — 消除 cache_store 双写, 全部走 cache_manager
from services.cache_service import cache_manager, adaptive_fresh_ttl
from services.cache_store import get_global_aiae_ttl as _get_global_aiae_ttl
from services.fred_guard import fred_get_series
from services.locks import AIAE_GLOBAL_LOCK as _AIAE_GLOBAL_LOCK
from services.aiae_normalizer import get_region_thresholds
from services import overseas_aiae_background as _oab


router = APIRouter(prefix="/api/v1", tags=["aiae"])
executor = ThreadPoolExecutor(max_workers=6)


# ─── AIAE 中国 ───

@router.get("/aiae/report")
async def get_aiae_report():
    """中国 AIAE 完整报告 — V2: SWR 三级缓存 (30min fresh / 4h stale)"""
    from services.cache_service import stale_while_revalidate

    def _compute():
        engine = get_aiae_engine()
        report = engine.generate_report()
        return {"status": "success", "data": report, "timestamp": __import__('datetime').datetime.now().isoformat()}

    return stale_while_revalidate("swr_aiae_cn_report", _compute, fresh_ttl=adaptive_fresh_ttl(1800, 'strategy'), stale_ttl=14400)

@router.get("/aiae/chart")
async def get_aiae_chart():
    """AIAE 历史走势图数据 — P1 修复: run_in_executor 防止阻塞"""
    try:
        loop = asyncio.get_running_loop()
        engine = get_aiae_engine()
        chart = await loop.run_in_executor(executor, engine.get_chart_data)
        return {"status": "success", "data": chart}
    except Exception as e:
        return {"status": "error", "message": str(e)}

@router.get("/aiae/refresh")
async def refresh_aiae():
    """强制刷新AIAE数据(清除SWR缓存 + 重算)"""
    from services.cache_service import swr_clear
    try:
        swr_clear("swr_aiae_cn_report")  # 清除 SWR 缓存
        loop = asyncio.get_running_loop()
        engine = get_aiae_engine()
        engine.refresh()
        report = await loop.run_in_executor(executor, engine.generate_report)
        return {"status": "success", "data": report, "timestamp": datetime.now().isoformat()}
    except Exception as e:
        return {"status": "error", "message": str(e)}

@router.post("/aiae/update_fund_position")
async def update_fund_position(req: FundPositionUpdate):
    """手动更新基金仓位数据 (C1: 季报发布后调用)"""
    try:
        engine = get_aiae_engine()
        result = engine.update_fund_position(req.value, req.date)
        if result["success"]:
            engine.refresh()
            return {"status": "success", **result}
        else:
            return {"status": "error", "message": result["message"]}
    except Exception as e:
        return {"status": "error", "message": str(e)}


# ─── AIAE 偏差分析 (P2-A) ───

@router.get("/aiae/deviation")
async def get_position_deviation():
    """实盘持仓 vs AIAE 建议偏差分析"""
    try:
        from engines.position_deviation_engine import get_deviation_engine
        dev_engine = get_deviation_engine()
        portfolio = dev_engine.load_portfolio()
        if not portfolio:
            return {"status": "error", "message": "portfolio_store.json 不存在或不可读"}

        # 尝试获取 AIAE 报告
        aiae_report = None
        try:
            engine = get_aiae_engine()
            aiae_report = engine.generate_report()
        except Exception:
            pass

        # 2026-10-31: 执行层当前目标 (偏差主口径 + 成本估算基准)
        exec_state = None
        try:
            from services.aiae_execution import load_state
            exec_state = load_state() or None
        except Exception:
            pass

        result = dev_engine.compute_deviation(portfolio, aiae_report, exec_state=exec_state)
        return result
    except Exception as e:
        logger.error(f"Deviation analysis error: {e}")
        return {"status": "error", "message": str(e)}


@router.get("/aiae/beta_exposure")
async def get_aiae_beta_exposure():
    """P1-a (2026-10-30): 持仓 β 调整后的有效敞口 vs AIAE β 预算 (只读读数, 不参与决策约束)"""
    try:
        from services import portfolio_vol
        from services.aiae_safety import build_aiae_context
        from services.aiae_beta_exposure import build_beta_exposure

        report = await get_aiae_report()          # 与 /aiae/report 共用 SWR 缓存, 不重复拉数据
        report_data = report.get("data") if isinstance(report, dict) else None
        ctx = build_aiae_context(report_data)
        loop = asyncio.get_running_loop()
        portfolio = await loop.run_in_executor(executor, portfolio_vol.compute_from_store)
        return {"status": "success", "data": build_beta_exposure(portfolio, ctx)}
    except Exception as e:
        logger.error(f"Beta exposure error: {e}")
        return {"status": "error", "message": str(e)}


@router.get("/aiae/hf_proxy")
async def get_hf_proxy():
    """AIAE 高频代理估算"""
    try:
        from engines.hf_proxy_engine import get_hf_engine
        engine = get_aiae_engine()
        report = engine.generate_report()
        # 2026-10-31: 基准改为分档依据 AIAE_简 (V1 自 V5 起已不参与决策); M2 时滞校准见 current.m2_nowcast
        cur = report.get("current", {})
        base = cur.get("aiae_simple", cur.get("aiae_v1", 22.0))

        hf = get_hf_engine().get_aiae_hf_estimate(base)
        hf["m2_nowcast"] = cur.get("m2_nowcast")
        return {"status": "success", "data": hf}
    except Exception as e:
        logger.error(f"HF Proxy error: {e}")
        return {"status": "error", "message": str(e)}


# ─── AIAE 回测对账 (P4-A) ───

@router.get("/aiae/reconciliation")
async def get_reconciliation_report():
    """回测-实盘综合对账报告"""
    try:
        from engines.backtest_reconciliation import get_reconciliation_engine
        return get_reconciliation_engine().generate_full_report()
    except Exception as e:
        logger.error(f"Reconciliation error: {e}")
        return {"status": "error", "message": str(e)}


# ─── 跨市场联动预警 (P3-A) ───

@router.get("/aiae/cross_market_alerts")
async def get_cross_market_alerts():
    """跨市场 AIAE 联动预警"""
    try:
        from engines.cross_market_alert import get_cross_alert_engine
        from services.cache_service import cache_manager as _cm

        # 获取四市场 regime
        cn_regime = 3
        try:
            cn_report = get_aiae_engine().generate_report()
            cn_regime = cn_report.get("current", {}).get("regime", 3)
        except Exception:
            pass

        # 2026-11-01 海外 AIAE P0: 只用新口径缓存的 display_regimes; 缺失 / 降级 / 锁定的地区为 None,
        # 不再默认 Ⅲ 档 (旧做法会把"没数据"显示成"中性")
        _g = _cm.get_json("aiae_global_report_data") or {}
        if not _oab.is_current_payload(_g):   # 旧版本缓存 (含旧档位) 不用于展示
            _g = {}
        _dr = (_g.get("global_comparison") or {}).get("display_regimes") or {}
        regimes = {"CN": cn_regime, "US": _dr.get("US"), "HK": _dr.get("HK"), "JP": _dr.get("JP")}
        # P3: 海外不分档, 改为展示读数 (美股真实 AIAE / 港股南向与 AH 溢价 / 日股代理值)
        readings = (_g.get("global_comparison") or {}).get("display_readings") or {}

        alerts = get_cross_alert_engine().scan_alerts(regimes)
        matrix = get_cross_alert_engine().get_contagion_matrix()

        return {
            "status": "success",
            "role": "background",
            "note": "海外市场不分档, 只展示读数, 仅作背景; 不构成 A 股操作建议",
            "regimes": regimes,
            "readings": readings,
            "alerts": alerts,
            "alert_count": len(alerts),
            "contagion_matrix": matrix,
        }
    except Exception as e:
        logger.error(f"Cross-market alert error: {e}")
        return {"status": "error", "message": str(e)}


# ─── AIAE 因子分解 (P1-B) ───

@router.get("/aiae/decomposition")
async def get_aiae_decomposition():
    """AIAE V1 三因子贡献分解 (Waterfall 图数据) — P1 修复: run_in_executor"""
    try:
        loop = asyncio.get_running_loop()
        engine = get_aiae_engine()
        report = await loop.run_in_executor(executor, engine.generate_report)
        current = report.get("current", {})
        return {
            "status": "success",
            "aiae_v1": current.get("aiae_v1"),
            "regime": current.get("regime"),
            "decomposition": current.get("decomposition"),
            "hf_estimate": report.get("hf_estimate"),
        }
    except Exception as e:
        logger.error(f"Decomposition error: {e}")
        return {"status": "error", "message": str(e)}


# ─── AIAE 因子趋势 (P4-B) ───

@router.get("/aiae/factor_trend")
async def get_factor_trend(days: int = 60):
    """AIAE 三因子贡献趋势 (堆叠面积图数据)"""
    try:
        from engines.factor_trend_engine import get_factor_trend_engine
        return get_factor_trend_engine().get_trend_data(days=min(days, 180))
    except Exception as e:
        logger.error(f"Factor trend error: {e}")
        return {"status": "error", "message": str(e)}


# ─── HF 权重校准 (P5-B) ───

@router.get("/aiae/hf_calibration")
async def get_hf_calibration():
    """HF 代理权重 OLS 校准"""
    try:
        from engines.hf_calibration import get_calibration_engine
        return get_calibration_engine().calibrate()
    except Exception as e:
        logger.error(f"HF Calibration error: {e}")
        return {"status": "error", "message": str(e)}


# ─── AIAE 全球 (US + JP + HK) ───

@router.get("/aiae_global/report")
async def get_aiae_global_report():
    """海外 AIAE 全球报告: L1缓存 + 并行执行 US + JP + HK 引擎, 含四地对比 V2.0"""
    current_time = time.time()
    ttl = _get_global_aiae_ttl()
    with _AIAE_GLOBAL_LOCK:
        _aiae_g_ts = cache_manager.get_json("aiae_global_last_update")
        _aiae_g_data = cache_manager.get_json("aiae_global_report_data")
    # 旧格式缓存 (P0 之前写入, 无 role=background) 视为未命中, 立即按新口径重建
    _legacy = not _oab.is_current_payload(_aiae_g_data)
    if _aiae_g_ts and (current_time - _aiae_g_ts < ttl) and not _legacy:
        age = int(current_time - _aiae_g_ts)
        ttl_label = "美股盘中30min" if ttl == 1800 else ("周末24h" if ttl == 86400 else "盘后4h")
        logger.info(f"Global AIAE Cache Hit [{ttl_label}] ({age}s ago)")
        return _aiae_g_data

    try:
        loop = asyncio.get_running_loop()
        us_engine = get_us_aiae_engine()
        jp_engine = get_jp_aiae_engine()
        hk_engine = get_hk_aiae_engine()

        us_task = loop.run_in_executor(executor, us_engine.generate_report)
        jp_task = loop.run_in_executor(executor, jp_engine.generate_report)
        hk_task = loop.run_in_executor(executor, hk_engine.generate_report)

        us_report, jp_report, hk_report = await asyncio.gather(us_task, jp_task, hk_task)

        # 获取中国 AIAE 用于四地对比
        cn_aiae_v1 = 22.0
        cn_regime = 3
        try:
            cn_engine = get_aiae_engine()
            cn_report = cn_engine.generate_report()
            if cn_report.get("status") in ("success", "fallback"):
                cn_aiae_v1 = cn_report["current"]["aiae_v1"]
                cn_regime = cn_report["current"]["regime"]
        except Exception as e:
            logger.warning(f"CN engine fallback: {e}")

        # 2026-11-01 海外 AIAE P0 (docs/AIAE_GLOBAL_OPTIMIZATION_PLAN.md): 降为估值背景;
        # 载荷由 services.overseas_aiae_background 统一构建 (与 warmup_pipeline 共用), 含审计 #26 的 deprecated 标记
        data = _oab.build_global_payload(us_report, jp_report, hk_report, cn_aiae_v1, cn_regime,
                                         get_region_thresholds())
        _gc = data["global_comparison"]
        us_v1, jp_v1, hk_v1 = _gc["us_aiae"], _gc["jp_aiae"], _gc["hk_aiae"]

        with _AIAE_GLOBAL_LOCK:
            cache_manager.set_json("aiae_global_last_update", current_time)
            cache_manager.set_json("aiae_global_report_data", data)
        logger.info(f"Global AIAE Cache Miss -> 已重建 (US={us_v1:.1f}% JP={jp_v1:.1f}% HK={hk_v1:.1f}%)")

        return data
    except Exception as e:
        logger.error(f"Global AIAE Error: {traceback.format_exc()}")
        return {"status": "error", "message": str(e)}

@router.get("/aiae_global/refresh")
async def refresh_aiae_global():
    """强制刷新海外 AIAE 数据: 清除L1+L2缓存后重建"""
    try:
        cache_manager.set_json("aiae_global_last_update", None)
        cache_manager.set_json("aiae_global_report_data", None)
        us_engine = get_us_aiae_engine()
        jp_engine = get_jp_aiae_engine()
        hk_engine = get_hk_aiae_engine()
        us_engine.refresh()
        jp_engine.refresh()
        hk_engine.refresh()
        return await get_aiae_global_report()
    except Exception as e:
        return {"status": "error", "message": str(e)}

@router.get("/aiae_global/chart")
async def get_aiae_global_chart():
    """海外 AIAE 历史走势数据 (V2.0: US+JP+HK)"""
    try:
        us_engine = get_us_aiae_engine()
        jp_engine = get_jp_aiae_engine()
        hk_engine = get_hk_aiae_engine()
        return {
            "status": "success",
            "role": "background",
            # 历史锚点为按比值反推的估算点, 不是逐期计算的序列 (P1 用真实数据替换)
            "estimated_points": True,
            "note": "历史点为估算锚点, 非实测序列",
            "us_chart": us_engine.get_chart_data(),
            "jp_chart": jp_engine.get_chart_data(),
            "hk_chart": hk_engine.get_chart_data(),
        }
    except Exception as e:
        return {"status": "error", "message": str(e)}

@router.get("/aiae_global/diagnose")
async def diagnose_aiae_data_sources():
    """诊断各数据源可用性 — 用于排查本地/云端数值不一致"""
    import os as _os
    from config import FRED_API_KEY as _fk
    results = {"status": "success", "checks": {}}

    # 1. FRED API Key
    results["checks"]["fred_api_key"] = {
        "configured": bool(_fk and len(_fk) > 5),
        "key_preview": (_fk[:6] + "...") if _fk else "(empty)",
    }

    # 2. yfinance 可用性
    try:
        import yfinance as yf
        df = yf.download("VTI", period="5d", progress=False)
        if df is not None and not df.empty:
            results["checks"]["yfinance"] = {"status": "ok", "vti_close": float(df["Close"].iloc[-1]) if "Close" in df.columns else "parse_error"}
        else:
            results["checks"]["yfinance"] = {"status": "fail", "reason": "empty_response"}
    except Exception as e:
        results["checks"]["yfinance"] = {"status": "fail", "reason": str(e)[:200]}

    # 3. Stooq 可用性
    try:
        import urllib.request
        req = urllib.request.Request("https://stooq.com/q/l/?s=spy.us&f=sd2t2ohlcv&h&e=csv",
                                     headers={"User-Agent": "Mozilla/5.0"})
        with urllib.request.urlopen(req, timeout=8) as resp:
            raw = resp.read().decode('utf-8')
        results["checks"]["stooq"] = {"status": "ok" if "Close" in raw else "fail", "response_len": len(raw), "preview": raw[:200]}
    except Exception as e:
        results["checks"]["stooq"] = {"status": "fail", "reason": str(e)[:200]}

    # 4. FRED API 可用性
    try:
        from fredapi import Fred
        fred = Fred(api_key=_fk)
        series = fred_get_series(
            "DGS10",
            lambda: fred.get_series(
                "DGS10",
                observation_start=datetime.now() - __import__('datetime').timedelta(days=7),
            ),
        )
        if series is not None and not series.empty:
            results["checks"]["fred_api"] = {"status": "ok", "latest_10y": float(series.dropna().iloc[-1])}
        else:
            results["checks"]["fred_api"] = {"status": "fail", "reason": "empty_response"}
    except Exception as e:
        results["checks"]["fred_api"] = {"status": "fail", "reason": str(e)[:200]}

    # 5. 磁盘缓存状态
    cache_dir = "data_lake"
    cache_files = ["aiae_us_wilshire.json", "aiae_us_m2.json", "aiae_us_margin.json", "aaii_sentiment.json"]
    for cf in cache_files:
        fp = _os.path.join(cache_dir, cf)
        if _os.path.exists(fp):
            try:
                import json as _json
                with open(fp, 'r', encoding='utf-8') as f:
                    data = _json.load(f)
                age_hours = (time.time() - _os.path.getmtime(fp)) / 3600
                results["checks"][cf] = {"exists": True, "age_hours": round(age_hours, 1),
                                         "source": data.get("source", "unknown"),
                                         "key_value": data.get("market_cap_trillion_usd") or data.get("m2_trillion_usd") or data.get("spread")}
            except Exception as e:
                results["checks"][cf] = {"exists": True, "error": str(e)[:100]}
        else:
            results["checks"][cf] = {"exists": False}

    # 6. 当前 AIAE 计算值 (不触发缓存, 直接读缓存的报告)
    cached_report = cache_manager.get_json("aiae_global_report_data")
    if cached_report:
        us = cached_report.get("us", {})
        us_raw = us.get("raw_data", {}).get("mkt", {})
        results["checks"]["current_us_aiae"] = {
            "aiae_v1": (us.get("current") or {}).get("aiae_v1"),
            "mkt_source": us_raw.get("source"),
            "mkt_wilshire": us_raw.get("wilshire_index"),
            "mkt_cap_T": us_raw.get("market_cap_trillion_usd"),
            "is_fallback": us_raw.get("is_fallback", False),
            "is_stale_cache": us_raw.get("is_stale_cache", False),
        }
    else:
        results["checks"]["current_us_aiae"] = {"cached": False}

    return results


# ─── 港股 ERP 择时 ───

@router.get("/strategy/erp-hk")
async def get_erp_hk(market: str = "HSI"):
    """港股ERP择时 — 五维信号 + HSI/HSTECH 双轨"""
    try:
        if market not in ("HSI", "HSTECH"):
            return {"status": "error", "message": "market must be HSI or HSTECH"}
        engine = get_hk_erp_engine(market)
        loop = asyncio.get_running_loop()
        report = await loop.run_in_executor(executor, engine.generate_report)
        return {"status": "success", "data": report}
    except Exception as e:
        logger.error(f"HK ERP Error: {traceback.format_exc()}")
        return {"status": "error", "message": str(e)}


# ─── 港股 AIAE ───

@router.get("/aiae_hk/report")
async def get_aiae_hk_report():
    """港股 AIAE 完整报告"""
    try:
        engine = get_hk_aiae_engine()
        loop = asyncio.get_running_loop()
        report = await loop.run_in_executor(executor, engine.generate_report)
        report = _oab.demote_region_report(report, "hk")
        return {"status": "success", "data": report, "timestamp": datetime.now().isoformat()}
    except Exception as e:
        logger.error(f"HK AIAE report error: {e}")
        return {"status": "error", "message": str(e)}

@router.get("/aiae_hk/refresh")
async def refresh_aiae_hk():
    """强制刷新港股AIAE数据"""
    try:
        engine = get_hk_aiae_engine()
        engine.refresh()
        loop = asyncio.get_running_loop()
        report = await loop.run_in_executor(executor, engine.generate_report)
        report = _oab.demote_region_report(report, "hk")
        cache_manager.set_json("aiae_global_last_update", None)
        cache_manager.set_json("aiae_global_report_data", None)
        return {"status": "success", "data": report, "timestamp": datetime.now().isoformat()}
    except Exception as e:
        return {"status": "error", "message": str(e)}

@router.get("/aiae_hk/chart")
async def get_aiae_hk_chart():
    """港股 AIAE 历史走势数据"""
    try:
        engine = get_hk_aiae_engine()
        return {"status": "success", "data": engine.get_chart_data()}
    except Exception as e:
        return {"status": "error", "message": str(e)}


# ─── 港股手动更新 ───

@router.post("/aiae_hk/update_southbound")
async def update_hk_southbound(req: HKSouthboundUpdate):
    """手动更新南向资金数据: 写入文件 + 清除缓存"""
    try:
        engine = get_hk_aiae_engine()
        engine.update_southbound(
            req.weekly_net_buy_billion_rmb,
            req.monthly_net_buy_billion_rmb,
            req.cumulative_12m_billion_rmb
        )
        for mkt in ["HSI", "HSTECH"]:
            erp_engine = get_hk_erp_engine(mkt)
            erp_engine.update_southbound(
                req.weekly_net_buy_billion_rmb,
                req.monthly_net_buy_billion_rmb,
                req.cumulative_12m_billion_rmb
            )
        cache_manager.set_json("aiae_global_last_update", None)
        cache_manager.set_json("aiae_global_report_data", None)
        return {"status": "success", "message": f"南向资金已更新: 周净买入={req.weekly_net_buy_billion_rmb}亿RMB"}
    except Exception as e:
        return {"status": "error", "message": str(e)}

@router.post("/aiae_hk/update_ah_premium")
async def update_hk_ah_premium(req: HKAHPremiumUpdate):
    """手动更新AH溢价指数"""
    try:
        engine = get_hk_aiae_engine()
        engine.update_ah_premium(req.index_value)
        cache_manager.set_json("aiae_global_last_update", None)
        cache_manager.set_json("aiae_global_report_data", None)
        return {"status": "success", "message": f"AH溢价指数已更新为 {req.index_value}"}
    except Exception as e:
        return {"status": "error", "message": str(e)}


# ─── 日股手动更新 ───

@router.post("/aiae_jp/update_margin")
async def update_jp_margin(req: JPMarginUpdate):
    """手动更新日股信用取引残高"""
    try:
        engine = get_jp_aiae_engine()
        engine.update_jp_margin(req.margin_buying_trillion_jpy)
        cache_manager.set_json("aiae_global_last_update", None)
        cache_manager.set_json("aiae_global_report_data", None)
        return {"status": "success", "message": f"信用取引残高已更新为 {req.margin_buying_trillion_jpy}兆円"}
    except Exception as e:
        return {"status": "error", "message": str(e)}

@router.post("/aiae_jp/update_foreign")
async def update_jp_foreign(req: JPForeignUpdate):
    """手动更新日股外国人投資家流向"""
    try:
        engine = get_jp_aiae_engine()
        engine.update_jp_foreign(req.net_buy_billion_jpy, req.cumulative_12m_billion_jpy)
        cache_manager.set_json("aiae_global_last_update", None)
        cache_manager.set_json("aiae_global_report_data", None)
        return {"status": "success", "message": f"外資流向已更新: 周次净買越={req.net_buy_billion_jpy}億円"}
    except Exception as e:
        return {"status": "error", "message": str(e)}


# ─── 均值回归 V4.0 三态参数 ───

@router.get("/mr_backtest_results")
async def get_mr_backtest_results():
    fp = "mr_optimization_results.json"
    if not os.path.exists(fp):
        return {"status": "error", "message": "请先运行 mr_regime_backtest.py"}
    try:
        with open(fp, "r", encoding="utf-8") as f:
            data = json.load(f)
        return data
    except Exception as e:
        return {"status": "error", "message": str(e)}

@router.get("/mr_per_regime_params")
async def get_per_regime_params():
    """返回三态（BEAR/RANGE/BULL）各自的回测最优参数"""
    try:
        return {
            "status": "ok",
            "regimes": get_all_regime_params(),
            "needs_reoptimize": needs_reoptimize(),
        }
    except Exception as e:
        return {"status": "error", "message": str(e)}

@router.get("/mr_current_params")
async def get_current_regime_params():
    """实时识别当前市场状态，返回对应的最优参数"""
    try:
        info = detect_regime()
        return {
            "status":      "ok",
            "regime":      info.get("regime"),
            "params":      info.get("params", {}),
            "pos_cap":     info.get("pos_cap"),
            "score_gate":  info.get("score_gate"),
            "csi300":      info.get("csi300"),
            "ret5":        info.get("ret5"),
            "ret20":       info.get("ret20"),
            "needs_reoptimize": info.get("needs_reoptimize", False),
            "all_regimes": get_all_regime_params(),
        }
    except Exception as e:
        return {"status": "error", "message": str(e)}


# ─── AIAE V5 仓位策略回测结果 ───

@router.get("/aiae_v5_backtest")
async def get_aiae_v5_backtest():
    """返回 AIAE V5 回测预计算结果 (权益曲线 + 信号时序)"""
    fp = os.path.join(os.path.dirname(os.path.dirname(__file__)),
                      "aiae_backtest_v4_results.json")
    if not os.path.exists(fp):
        return {"status": "error", "message": "请先运行 aiae_backtest_v4.py"}
    try:
        with open(fp, "r", encoding="utf-8") as f:
            data = json.load(f)
        return {"status": "ok", "data": data}
    except Exception as e:
        return {"status": "error", "message": str(e)}


@router.get("/aiae_v5_signal_history")
async def get_aiae_v5_signal_history():
    """返回 AIAE 真实信号时序 (137个月 regime/position/erp)"""
    import pandas as pd
    fp = os.path.join(os.path.dirname(os.path.dirname(__file__)),
                      "data_lake", "aiae_true_history.parquet")
    if not os.path.exists(fp):
        return {"status": "error", "message": "请先运行 aiae_data_builder.py"}
    try:
        df = pd.read_parquet(fp)
        records = []
        for _, row in df.iterrows():
            records.append({
                "month": row["month"],
                "aiae_simple": round(float(row["aiae_simple"]), 2),
                "aiae_v1": round(float(row["aiae_v1"]), 2),
                "regime": int(row["regime"]),
                "erp": round(float(row["erp"]), 2),
                "erp_tier": str(row["erp_tier"]),
                "matrix_position": int(row["matrix_position"]),
                "data_quality": str(row.get("data_quality", "medium")),
            })
        return {"status": "ok", "data": records}
    except Exception as e:
        return {"status": "error", "message": str(e)}


# ─── V5 配额 · ETF 持有代理回测 (F2 2026-10-27: 非子策略实盘, 非业绩证据) ───

@router.get("/portfolio_backtest")
async def get_portfolio_backtest():
    """返回 V5 配额 ETF 持有代理回测 (研究用, is_performance_evidence 恒为 False)。

    旧版结果文件 (同月信号/合成回退) 原样返回但标记 evidence_status=invalidated_legacy。
    文件不存在时只用真实行情运行; 行情不可用时返回 data_unavailable, 不生成合成结果。
    """
    from engines.portfolio_backtest import load_backtest_results, run_portfolio_backtest, _results_path
    fp = _results_path()
    if not os.path.exists(fp):
        try:
            result = run_portfolio_backtest("2018-01", allow_synthetic=False)
            status = "ok" if result.get("status") == "success" else "unavailable"
            return {"status": status, "data": result}
        except Exception as e:
            return {"status": "error", "message": f"回测执行失败: {e}"}
    try:
        return {"status": "ok", "data": load_backtest_results(fp)}
    except Exception as e:
        return {"status": "error", "message": str(e)}

