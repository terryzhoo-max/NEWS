"""AlphaCore 审计 API (只读)

2026-11-02: 旧执行器 (自动强平 / 交易阻断 / 静音降级 / 执行器开关) 已退役, 相关接口删除。
GET /audit 只读: 不写交易阻断, 不写审计历史; 历史由每日定时任务或 POST /audit/save 写入。
"""
import asyncio
import traceback
import logging
from concurrent.futures import ThreadPoolExecutor
from fastapi import APIRouter

from engines.audit_engine import run_full_audit, save_audit_snapshot

router = APIRouter(prefix="/api/v1", tags=["audit"])
executor = ThreadPoolExecutor(max_workers=4)
logger = logging.getLogger("alphacore.audit")


def _warming():
    """2026-11-02: 启动预热期不出审计结论 (否则会把"数据缺失"误记为否决项)。"""
    from services import warmup_state
    st = warmup_state.status()
    return warmup_state.warming_payload(st) if st["phase"] == "warming" else None


@router.get("/audit")
async def api_audit():
    """系统审计 (只读)。风控部分读取合规引擎在决策中枢快照上的结果。"""
    warming = _warming()
    if warming is not None:
        return warming
    try:
        report = await asyncio.get_running_loop().run_in_executor(executor, run_full_audit)
        return {"status": "ok", **report}
    except Exception as e:
        logger.error(f"[Audit] Error: {traceback.format_exc()}")
        return {"status": "error", "message": str(e)}


@router.post("/audit/save")
async def api_audit_save():
    """手动"保存审计": 重新跑一次审计并写入审计历史。预热期拒绝保存。"""
    warming = _warming()
    if warming is not None:
        return {**warming, "saved": False, "message": "服务启动预热中，暂不保存审计（避免把数据缺失记入审计历史）"}
    try:
        result = await asyncio.get_running_loop().run_in_executor(
            executor, lambda: save_audit_snapshot(trigger="manual"))
        return {"status": "ok", **result}
    except Exception as e:
        logger.error(f"[Audit] save failed: {traceback.format_exc()}")
        return {"status": "error", "message": str(e)}


@router.get("/audit/history")
async def get_audit_history(limit: int = 10):
    """获取审计历史 (服务端持久化)"""
    try:
        from services.db import get_audit_history
        history = get_audit_history(limit)
        return {"status": "ok", "count": len(history), "history": history}
    except Exception as e:
        return {"status": "error", "message": str(e)}


@router.get("/audit/trend")
async def get_audit_trend(days: int = 90):
    """审计趋势: 只取当前口径 (schema_version) 的服务端审计历史, 每日一个点 (定时优先)。"""
    try:
        from services.db import get_audit_trend as _trend
        from engines.audit_engine import AUDIT_SCHEMA_VERSION, TRUST_PASS_MIN, TRUST_WARN_MIN
        days = max(7, min(int(days), 90))
        data = _trend(AUDIT_SCHEMA_VERSION, days)
        return {"status": "ok", **data, "thresholds": {"pass": TRUST_PASS_MIN, "warn": TRUST_WARN_MIN}}
    except Exception as e:
        logger.error(f"[Audit] trend failed: {traceback.format_exc()}")
        return {"status": "error", "message": str(e)}
