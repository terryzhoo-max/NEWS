"""AlphaCore 持仓跟踪止盈 + 历史成交导入 API

GET  /api/v1/portfolio/trailing-stops            每只持仓的止损线 / 阶段 / 状态 / 指令 / 条件单
POST /api/v1/portfolio/trailing-stops/run        同步行情 + 重算 + 推送 (与 15:50 定时任务相同)
POST /api/v1/portfolio/trailing-stops/{code}/rebaseline   遗留持仓重新基准化 (必须填写理由)
POST /api/v1/portfolio/trailing-stops/{code}/sleeve       core / satellite
POST /api/v1/portfolio/trailing-stops/{code}/ack          台账外已执行的分批止盈手动确认
POST /api/v1/portfolio/trailing-stops/{code}/anchor       人工设定建仓日 (成交记录超出通达信 60 天导出范围时)
GET  /api/v1/portfolio/drawdown                  组合级回撤: 实盘净值 / 分档刹车 / 前瞻 MDD / 预算仓位
POST /api/v1/portfolio/drawdown/baseline         重设回撤基准 (必须填写理由, 留痕; date 为空 = 撤销)
POST /api/v1/portfolio/trades/import             导入通达信历史成交 .txt (GBK/UTF-8, 幂等去重)
POST /api/v1/portfolio/trades/scan               扫描 data_lake/trade_imports 文件夹, 自动累积
GET  /api/v1/portfolio/trades                    成交台账
GET  /api/v1/portfolio/trades/review             已完成回合复盘 (最大浮盈/利润回吐/规则 vs 实际)
"""
import asyncio
import logging

from fastapi import APIRouter, File, Form, Request, UploadFile
from pydantic import BaseModel

from models import response as R
from services.account_authority import IMPORT_MESSAGE, WRITE_MESSAGE, require_authoritative
from services import write_log as _wl

router = APIRouter(prefix="/api/v1/portfolio", tags=["trailing-stop"])
logger = logging.getLogger("alphacore.trailing")

MAX_UPLOAD = 2 * 1024 * 1024


class ReasonBody(BaseModel):
    reason: str = ""


class SleeveBody(BaseModel):
    sleeve: str
    reason: str = ""


class AnchorBody(BaseModel):
    date: str = ""          # 空 = 恢复自动锚点
    reason: str = ""


class AckBody(BaseModel):
    stage: int
    note: str = ""


def _clear_cache():
    try:
        from services.cache_service import cache_manager
        cache_manager.delete("trailing_stop_report_full")
    except Exception:
        pass


@router.get("/trailing-stops")
async def get_trailing_stops():
    try:
        from services.trailing_stop_service import ensure_prices_async, get_report
        data = await asyncio.to_thread(get_report)        # 只读; 仅在出现未提交的新收盘时补跑日终
        # 2026-11-02: 合规与执行目标所用的回撤刹车 / 越线状态及其计算时间 (可能早于本页现算)
        try:
            from services.risk_state import drawdown_brake, state_label
            rs = drawdown_brake() or {}
            data["risk_state"] = {"label": state_label(rs), "tier": rs.get("tier"), "invested_pct": rs.get("invested_pct"),
                                  "computed_at": rs.get("computed_at"), "holdings_as_of": rs.get("holdings_as_of"),
                                  "source": rs.get("source")}
        except Exception:
            data["risk_state"] = None
        # 缺行情 / 行情滞后的持仓 → 后台增量同步, 页面不等待
        data["price_sync"] = ensure_prices_async((data.get("price_sync_needed") or [])
                                                 + (data.get("price_sync_history") or []))
        return R.ok(data)
    except Exception as e:
        logger.exception("trailing-stops failed")
        return R.error(str(e), "ERR_TRAILING")


@router.post("/trailing-stops/run")
async def run_trailing_stops():
    require_authoritative(WRITE_MESSAGE)   # 2026-11-04: 非权威环境 (本机) 关闭
    try:
        from services.trailing_stop_service import daily_job
        data = await asyncio.to_thread(daily_job)
        return R.ok(data, "已同步行情并重新计算")
    except Exception as e:
        logger.exception("trailing-stops run failed")
        return R.error(str(e), "ERR_TRAILING_RUN")


@router.post("/trailing-stops/{ts_code}/rebaseline")
async def post_rebaseline(ts_code: str, body: ReasonBody):
    require_authoritative(WRITE_MESSAGE)   # 2026-11-04: 非权威环境 (本机) 关闭
    try:
        from services.trailing_stop_service import rebaseline
        data = await asyncio.to_thread(rebaseline, ts_code, body.reason)
        _clear_cache()
        return R.ok(data, "已重新基准化 (已写入审计日志)")
    except ValueError as e:
        return R.error(str(e), "ERR_REBASELINE")
    except Exception as e:
        return R.error(str(e), "ERR_REBASELINE")


@router.post("/trailing-stops/{ts_code}/sleeve")
async def post_sleeve(ts_code: str, body: SleeveBody):
    require_authoritative(WRITE_MESSAGE)   # 2026-11-04: 非权威环境 (本机) 关闭
    try:
        from services.trailing_stop_service import set_sleeve
        data = await asyncio.to_thread(set_sleeve, ts_code, body.sleeve, body.reason)
        _clear_cache()
        return R.ok(data)
    except ValueError as e:
        return R.error(str(e), "ERR_SLEEVE")


@router.post("/trailing-stops/{ts_code}/anchor")
async def post_anchor(ts_code: str, body: AnchorBody):
    require_authoritative(WRITE_MESSAGE)   # 2026-11-04: 非权威环境 (本机) 关闭
    try:
        from services.trailing_stop_service import clear_anchor, set_anchor
        if not body.date.strip():
            data = await asyncio.to_thread(clear_anchor, ts_code)
            return R.ok(data, "已恢复自动锚点")
        data = await asyncio.to_thread(set_anchor, ts_code, body.date.strip(), body.reason)
        _clear_cache()
        return R.ok(data, "建仓日已设定 (已写入审计日志)")
    except ValueError as e:
        return R.error(str(e), "ERR_ANCHOR")


@router.get("/drawdown")
async def get_drawdown():
    try:
        from services.trailing_stop_service import build_report
        data = await asyncio.to_thread(build_report)
        return R.ok(data.get("drawdown") or {})
    except Exception as e:
        logger.exception("drawdown failed")
        return R.error(str(e), "ERR_DRAWDOWN")


@router.post("/drawdown/baseline")
async def post_drawdown_baseline(body: AnchorBody):
    require_authoritative(WRITE_MESSAGE)   # 2026-11-04: 非权威环境 (本机) 关闭
    try:
        from services.trailing_stop_service import clear_drawdown_baseline, set_drawdown_baseline
        if not body.date.strip():
            data = await asyncio.to_thread(clear_drawdown_baseline)
            _clear_cache()
            return R.ok(data, "已撤销回撤基准, 恢复按实盘高水位计算")
        data = await asyncio.to_thread(set_drawdown_baseline, body.date.strip(), body.reason)
        _clear_cache()
        return R.ok(data, "回撤基准已重设 (已写入审计日志)")
    except ValueError as e:
        return R.error(str(e), "ERR_DD_BASELINE")


@router.post("/trades/scan")
async def scan_trades(request: Request = None):
    require_authoritative(IMPORT_MESSAGE)   # 2026-11-04: 非权威环境 (本机) 关闭
    # 第 0 轮 0a-4: 写操作日志只记每个文件的文件名 / 字节数 / 行数 / 结果 / 错误码, 不记文件内容
    _wl.attach(request, kind="trades_scan", result="rejected")
    try:
        from services.trade_import import scan_import_folder
        data = await asyncio.to_thread(scan_import_folder)
        _clear_cache()
        n = len(data.get("files", []))
        files = [{"file_name": _wl.file_name(f.get("file")), "bytes": f.get("bytes"), "rows": f.get("parsed"),
                  "added": f.get("added"), "duplicates": f.get("duplicates"),
                  "result": "imported" if f.get("status") == "ok" else "rejected",
                  "error_code": f.get("code") if f.get("status") != "ok" else None}
                 for f in data.get("files", [])]
        _wl.attach(request, files=files, added=data.get("added", 0))
        resp = R.ok(data, f"扫描 {n} 个新文件, 新增 {data.get('added', 0)} 笔" if n else "没有新的导出文件")
        ok_result = ("no_new_files" if not files
                     else "imported" if any(f["result"] == "imported" for f in files) else "rejected")
        return _wl.finish(request, resp, ok_result=ok_result)
    except Exception as e:
        logger.exception("trade scan failed")
        return _wl.finish(request, R.error(str(e), "ERR_TRADE_SCAN"))


@router.post("/trailing-stops/{ts_code}/ack")
async def post_ack(ts_code: str, body: AckBody):
    require_authoritative(WRITE_MESSAGE)   # 2026-11-04: 非权威环境 (本机) 关闭
    try:
        from services.trailing_stop_service import ack_stage
        data = await asyncio.to_thread(ack_stage, ts_code, body.stage, body.note)
        _clear_cache()
        return R.ok(data)
    except Exception as e:
        return R.error(str(e), "ERR_ACK")


@router.post("/trades/import")
async def import_trades(file: UploadFile = File(...), after_close: str | None = Form(None),
                        request: Request = None):
    require_authoritative(IMPORT_MESSAGE)   # 2026-11-04: 非权威环境 (本机) 关闭
    # 第 0 轮 0a-4: 写操作日志只记文件名 / 字节数 / 行数 / 结果 / 错误码, 不记文件内容
    _wl.attach(request, kind="trades_import", file_name=_wl.file_name(getattr(file, "filename", None)),
               result="rejected")
    from services.trade_import import TradeImportError, import_trade_file, load_ledger, reconcile_positions
    try:
        raw = await file.read()
        _wl.attach(request, bytes=len(raw))
        if len(raw) > MAX_UPLOAD:
            return _wl.finish(request, R.error(f"文件过大 ({len(raw) // 1024}KB > {MAX_UPLOAD // 1024}KB)",
                                               "ERR_FILE_TOO_LARGE"))
        # 2026-11-04: 用户勾选"收盘后导出" → 交割单入出金覆盖含导出日当天 (仍需导入时北京时间已过 15:00)
        closed = str(after_close or "").strip().lower() in ("1", "true", "on", "yes")
        summary = await asyncio.to_thread(import_trade_file, raw, file.filename or "", None, closed)
        _wl.attach(request, rows=summary.get("parsed"), added=summary.get("added"),
                   duplicates=summary.get("duplicates"), conflicts=summary.get("conflicts"))
        # 导入后立即对账, 让用户看到哪些持仓锚点已精确定位
        try:
            from services.trailing_stop_service import STORE_PATH, _read_json
            store = _read_json(STORE_PATH, {}) or {}
            rec = reconcile_positions(load_ledger().get("trades", []), store.get("positions") or {},
                                      as_of=store.get("import_date"))
            summary["reconciliation"] = list(rec.values())
        except Exception as e:
            summary["reconciliation_error"] = str(e)
        _clear_cache()
        # 2026-11-02: 成交改变持仓还原与越线判定 → 立即重算风险状态并失效决策缓存
        from routers.portfolio import _invalidate_portfolio_caches, refresh_risk_after_import
        summary["risk_state"] = await refresh_risk_after_import("import_trades")
        _invalidate_portfolio_caches(full=True)
        return _wl.finish(request, R.ok(summary, f"新增 {summary['added']} 笔, 重复 {summary['duplicates']} 笔"))
    except TradeImportError as e:
        return _wl.finish(request, R.error(str(e), e.code))
    except Exception as e:
        logger.exception("trade import failed")
        return _wl.finish(request, R.error(str(e), "ERR_TRADE_IMPORT"))


@router.get("/trades")
async def get_trades(limit: int = 200):
    from services.trade_import import load_ledger
    try:
        led = load_ledger()
        trades = led.get("trades", [])
        return R.ok({"count": len(trades), "trades": trades[-max(1, min(limit, 2000)):][::-1],
                     "imports": led.get("imports", [])[-10:]})
    except Exception as e:
        return R.error(str(e), "ERR_TRADES")


@router.get("/trades/review")
async def get_trade_review():
    try:
        from services.trailing_stop_service import _market_context, build_review
        regime, _ = await asyncio.to_thread(_market_context)
        data = await asyncio.to_thread(build_review, regime=regime)
        return R.ok(data)
    except Exception as e:
        logger.exception("trade review failed")
        return R.error(str(e), "ERR_REVIEW")
