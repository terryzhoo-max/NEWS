"""Personal research and manual plan API. Broker execution is not exposed."""
import asyncio
from typing import Annotated, Literal

from fastapi import APIRouter, HTTPException, Query
from pydantic import BaseModel, ConfigDict, Field, StrictBool

from services import manual_decisions as decisions
from services import decision_journal as journal
from services import decision_review as review
from services.account_authority import WRITE_MESSAGE, require_authoritative

router = APIRouter(prefix="/api/v1/analysis", tags=["personal-analysis"])
Code = Annotated[str, Field(pattern=r"^[0-9]{6}\.(SH|SZ)$")]
RequestID = Annotated[str, Field(min_length=8, max_length=80, pattern=r"^[A-Za-z0-9_-]+$")]
Amount = Annotated[int, Field(strict=True, gt=0, le=100000000)]


class PlanConfirmation(BaseModel):
    model_config = ConfigDict(extra="forbid")
    code: Code
    amount: Amount
    request_id: RequestID
    snapshot_id: Annotated[str, Field(pattern=r"^[0-9a-f]{64}$")]
    acknowledged: StrictBool


class Observation(BaseModel):
    model_config = ConfigDict(extra="forbid")
    code: Code
    request_id: RequestID
    action: Literal["watch", "declined", "self_directed"]
    reason: Annotated[str, Field(max_length=2000)] = ""


async def call(function, *args):
    try:
        return {"status": "success", "data": await asyncio.to_thread(function, *args)}
    except decisions.DecisionError as exc:
        raise HTTPException(exc.status_code, detail=str(exc)) from exc


@router.get("/mr")
async def get_research():
    return await call(decisions.analysis_signals)


@router.get("/mr/{code}/preview")
async def preview(code: Code, amount: int = Query(gt=0, le=100000000)):
    return await call(decisions.preview_plan, code, amount)


@router.post("/plans")
async def confirm(body: PlanConfirmation):
    require_authoritative(WRITE_MESSAGE)   # 2026-11-04: 非权威环境 (本机) 不写决定记录 / MR 计划
    return await call(decisions.confirm_plan, body.model_dump())


@router.post("/observations")
async def observe(body: Observation):
    require_authoritative(WRITE_MESSAGE)   # 2026-11-04: 非权威环境 (本机) 不写决定记录 / MR 计划
    return await call(decisions.record_observation, body.code, body.request_id, body.action, body.reason)


@router.get("/records")
async def records(limit: int = Query(default=50, ge=1, le=200)):
    return await call(decisions.list_records, limit)


# ── 阶段4A: 决定记录 (采用/未采用/暂不行动) 与真实成交关联; 均为追加记录, 不下单、不改持仓 ──
AnyCode = Annotated[str, Field(pattern=r"^[0-9]{6}\.(SH|SZ|BJ)$")]
TradeKey = Annotated[str, Field(min_length=10, max_length=200)]
DecisionID = Annotated[str, Field(pattern=r"^[0-9a-f-]{36}$")]


class JournalEntry(BaseModel):
    model_config = ConfigDict(extra="forbid")
    request_id: RequestID
    status: Literal["adopted", "not_adopted", "deferred"]
    intent: Literal["buy", "sell", "rebalance", "hold"]
    codes: Annotated[list[AnyCode], Field(max_length=20)] = []
    thesis: Annotated[str, Field(min_length=1, max_length=4000)]
    counter_evidence: Annotated[str, Field(max_length=4000)] = ""
    expected_holding_days: Annotated[int, Field(strict=True, gt=0, le=3650)] | None = None
    review_after: Annotated[str, Field(pattern=r"^[0-9]{4}-[0-9]{2}-[0-9]{2}$")] | None = None
    relates_to: Annotated[str, Field(max_length=200)] = ""
    decided_on: Annotated[str, Field(pattern=r"^[0-9]{4}-[0-9]{2}-[0-9]{2}$")] | None = None
    retrospective: StrictBool = False


class TradeLink(BaseModel):
    model_config = ConfigDict(extra="forbid")
    trade_key: TradeKey
    reason: Annotated[str, Field(max_length=500)] = ""


@router.post("/journal")
async def journal_record(body: JournalEntry):
    require_authoritative(WRITE_MESSAGE)   # 2026-11-04: 非权威环境 (本机) 不写决定记录 / MR 计划
    return await call(journal.record_decision, body.model_dump())


@router.get("/journal")
async def journal_list(limit: int = Query(default=50, ge=1, le=200)):
    return await call(journal.list_journal, limit)


@router.get("/journal/{decision_id}")
async def journal_detail(decision_id: DecisionID):
    return await call(journal.get_decision, decision_id)


@router.get("/journal/{decision_id}/candidates")
async def journal_candidates(decision_id: DecisionID, window_days: int = Query(default=14, ge=1, le=90)):
    return await call(journal.candidate_trades, decision_id, window_days)


@router.post("/journal/{decision_id}/links")
async def journal_link(decision_id: DecisionID, body: TradeLink):
    require_authoritative(WRITE_MESSAGE)   # 2026-11-04: 非权威环境 (本机) 不写决定记录 / MR 计划
    return await call(journal.link_trade, decision_id, body.trade_key, body.reason)


@router.post("/journal/{decision_id}/unlink")
async def journal_unlink(decision_id: DecisionID, body: TradeLink):
    require_authoritative(WRITE_MESSAGE)   # 2026-11-04: 非权威环境 (本机) 不写决定记录 / MR 计划
    return await call(journal.unlink_trade, decision_id, body.trade_key, body.reason)


# ── 阶段4B-1: 复盘比较 (只读) ──
DAY_PATTERN = r"^[0-9]{4}-[0-9]{2}-[0-9]{2}$"


@router.get("/review/portfolio")
async def review_portfolio(start: str = Query(pattern=DAY_PATTERN),
                           end: str | None = Query(default=None, pattern=DAY_PATTERN)):
    return await call(review.portfolio_review, start, end)


@router.get("/review/decisions")
async def review_decisions(limit: int = Query(default=200, ge=1, le=500)):
    return await call(review.decision_reviews, limit)
