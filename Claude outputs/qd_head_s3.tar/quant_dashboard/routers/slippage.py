"""AlphaCore OMS 滑点归因 API — V26.0"""
import traceback
import logging
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field, model_validator
from typing import Optional, Literal

from models import response as R
from services import db as ac_db

router = APIRouter(prefix="/api/v1", tags=["slippage"])
logger = logging.getLogger("alphacore.slippage")


# ── 请求模型 ──

class CreateOrderRequest(BaseModel):
    ts_code: str = Field(min_length=3, max_length=20, pattern=r"^[A-Za-z0-9.]+$")
    name: str = Field(default="", max_length=100)
    side: Literal["buy", "sell"]
    decision_price: Optional[float] = Field(default=None, gt=0, allow_inf_nan=False)
    exec_price: Optional[float] = Field(default=None, gt=0, allow_inf_nan=False)
    exec_amount: Optional[int] = Field(default=None, gt=0, strict=True)
    notes: str = Field(default="", max_length=2000)
    idempotency_key: Optional[str] = Field(default=None, min_length=1, max_length=128)

    @model_validator(mode="after")
    def paired_fill(self):
        if (self.exec_price is None) != (self.exec_amount is None):
            raise ValueError("成交价和成交数量必须同时提供")
        return self


class FillOrderRequest(BaseModel):
    exec_price: float = Field(gt=0, allow_inf_nan=False)
    exec_amount: int = Field(gt=0, strict=True)
    arrival_price: Optional[float] = Field(default=None, gt=0, allow_inf_nan=False)
    commission: float = Field(default=0, ge=0, allow_inf_nan=False)
    tax: float = Field(default=0, ge=0, allow_inf_nan=False)
    notes: str = Field(default="", max_length=2000)


# ── 查询端点 ──

@router.get("/slippage/summary")
async def get_slippage_summary():
    """滑点统计摘要 (面板总览)"""
    try:
        stats = ac_db.get_slippage_stats()
        return R.ok(stats)
    except Exception as e:
        return R.error(str(e), "ERR_SLIP_SUMMARY")


@router.get("/slippage/history")
async def get_slippage_history(days: int = 30):
    """滑点日度历史曲线"""
    try:
        data = ac_db.get_slippage_history(days)
        return R.ok(data, f"{len(data)} days")
    except Exception as e:
        return R.error(str(e), "ERR_SLIP_HISTORY")


@router.get("/slippage/orders")
async def get_execution_orders(days: int = 30, ts_code: str = None, status: str = None):
    """执行指令列表"""
    try:
        orders = ac_db.get_execution_orders(days=days, ts_code=ts_code, status=status)
        # 过滤掉系统指令, 只返回实际交易
        real = [o for o in orders if o.get("ts_code") not in ("PORTFOLIO", "IMPORT")]
        return R.ok(real, f"{len(real)} orders")
    except Exception as e:
        return R.error(str(e), "ERR_SLIP_ORDERS")


@router.get("/slippage/quality")
async def get_execution_quality():
    """EQS 执行质量评分"""
    try:
        from engines.slippage_engine import get_slippage_engine
        eqs = get_slippage_engine().get_execution_quality_score()
        return R.ok(eqs)
    except Exception as e:
        return R.error(str(e), "ERR_SLIP_EQS")


@router.get("/slippage/attribution")
async def get_attribution():
    """归因分解报告"""
    try:
        from engines.slippage_engine import get_slippage_engine
        report = get_slippage_engine().get_attribution_report()
        return R.ok(report)
    except Exception as e:
        return R.error(str(e), "ERR_SLIP_ATTR")


@router.get("/slippage/diagnose")
async def get_diagnosis():
    """智能诊断"""
    try:
        from engines.slippage_engine import get_slippage_engine
        findings = get_slippage_engine().diagnose()
        return R.ok(findings)
    except Exception as e:
        return R.error(str(e), "ERR_SLIP_DIAG")


# ── 写入端点 ──

@router.post("/slippage/orders")
async def create_order(req: CreateOrderRequest):
    """Record an already executed trade; never turn a research score into an order."""
    if req.exec_price is None:
        raise HTTPException(403, detail="当前接口仅登记成交记录；尚无已验收的订单释放通道，禁止创建执行指令")
    if not req.idempotency_key:
        raise HTTPException(422, detail="登记成交记录必须提供 idempotency_key，重试时保持不变")
    try:
        from services.decision_policy import fingerprint
        from services.db.connection import _get_conn
        request_hash = fingerprint(req.model_dump())
        # Only the atomic insertion owns deduplication. This read merely avoids
        # fetching reference prices or running attribution for a known replay.
        previous = _get_conn().execute(
            "SELECT request_fingerprint,order_id FROM execution_request_keys WHERE request_key=?",
            (req.idempotency_key,),
        ).fetchone()
        if previous:
            if previous["request_fingerprint"] != request_hash:
                raise HTTPException(409, detail="幂等键已被不同成交记录使用")
            return R.ok({"order_id": previous["order_id"], "record_only": True,
                         "execution_allowed": False}, "成交记录已存在，未重复登记")
        from engines.slippage_engine import get_slippage_engine
        se = get_slippage_engine()

        order_data = {
            "ts_code": req.ts_code.strip(),
            "name": req.name.strip(),
            "side": req.side,
            "decision_price": req.decision_price,
            "exec_price": req.exec_price,
            "exec_amount": req.exec_amount,
            "status": "filled" if req.exec_price else "pending",
            "notes": req.notes,
            "exec_source": "manual",
        }

        # 自动填充决策参考价
        if not req.decision_price:
            dp = se._get_prev_close(req.ts_code.strip())
            if dp:
                order_data["decision_price"] = dp

        # 自动填充到达价
        arrival = se._get_today_open(req.ts_code.strip())
        if arrival:
            order_data["arrival_price"] = arrival

        order_id, created = ac_db.create_execution_order(order_data, request_key=req.idempotency_key,
                                                        request_fingerprint=request_hash, return_created=True)

        # 如果已有成交价, 立即归因
        if req.exec_price and created:
            try:
                se._compute_attribution(order_id)
            except Exception:
                logger.warning("Trade record saved; attribution pending for %s", order_id, exc_info=True)

        return R.ok({"order_id": order_id, "record_only": True,
                     "execution_allowed": False}, "成交记录已登记，未提交任何券商订单")
    except HTTPException:
        raise
    except ValueError as e:
        raise HTTPException(409, detail=str(e)) from e
    except Exception as e:
        logger.debug("Traceback", exc_info=True)
        return R.error(str(e), "ERR_SLIP_CREATE")


@router.put("/slippage/orders/{order_id}/fill")
async def fill_order(order_id: str, req: FillOrderRequest):
    """更新成交信息"""
    try:
        from engines.slippage_engine import get_slippage_engine

        from services.db.execution import record_execution_fill
        inserted = record_execution_fill(order_id, {
            "exec_price": req.exec_price,
            "exec_amount": req.exec_amount,
            "arrival_price": req.arrival_price,
            "commission": req.commission,
            "tax": req.tax,
            "notes": req.notes,
            "status": "filled",
        })

        if inserted:
            try:
                get_slippage_engine()._compute_attribution(order_id)
            except Exception:
                logger.warning("Fill recorded; attribution pending for %s", order_id, exc_info=True)
        return R.ok({"record_only": True, "execution_allowed": False}, message="成交信息已登记；未提交券商订单")
    except LookupError as e:
        raise HTTPException(404, detail=str(e)) from e
    except ValueError as e:
        raise HTTPException(409, detail=str(e)) from e
    except Exception as e:
        return R.error(str(e), "ERR_SLIP_FILL")


@router.post("/slippage/bootstrap")
async def bootstrap():
    """从历史交易回填执行记录"""
    try:
        from engines.slippage_engine import get_slippage_engine
        result = get_slippage_engine().bootstrap_from_history()
        return R.ok(result)
    except Exception as e:
        return R.error(str(e), "ERR_SLIP_BOOT")
