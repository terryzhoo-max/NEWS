"""
从 FRED 下载美联储 Z.1 的 6 个季度序列, 生成 data/us_aiae_z1_quarterly.csv (入库, 服务器随代码更新)。

用法 (项目目录 quant_dashboard/quant_dashboard 下):
    python _dev_tools/update_us_aiae_z1.py            # 下载并写入, 打印最近几个季度的 AIAE 与历史锚点
    python _dev_tools/update_us_aiae_z1.py --check    # 只下载并打印, 不写文件

何时运行: Z.1 每季度发布一次 (季末后约 10 周, 例如 Q3 数据约在 12 月中旬)。发布后运行一次即可。
需要: FRED_API_KEY (.env 或 config.py) 与 fredapi。

序列 (单位均为百万美元, 2026-11-01 核实):
  NCBEILQ027S  非金融企业 · 股票负债市值
  FBCELLQ027S  国内金融部门 · 股票负债市值
  TCMILBSHNO   家庭与非营利 · 债务证券与贷款
  TCMILBSNNCB  非金融企业 · 债务证券与贷款
  FGTCMDODNS   联邦政府 · 债务证券与贷款
  SLGTCMDODNS  州与地方政府 · 债务证券与贷款
"""
import argparse
import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
os.chdir(ROOT)

import pandas as pd  # noqa: E402

from engines import us_aiae_real as R  # noqa: E402


def _api_key() -> str:
    key = os.environ.get("FRED_API_KEY", "")
    if not key:
        try:
            from dotenv import load_dotenv
            load_dotenv(os.path.join(ROOT, ".env"))
            key = os.environ.get("FRED_API_KEY", "")
        except Exception:
            pass
    if not key:
        try:
            from config import FRED_API_KEY as key  # type: ignore
        except Exception:
            key = ""
    if not key:
        sys.exit("未找到 FRED_API_KEY")
    return key


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--check", action="store_true", help="只打印, 不写文件")
    args = ap.parse_args()

    from fredapi import Fred
    fred = Fred(api_key=_api_key())
    cols = {}
    for sid in R.SERIES_ALL:
        s = fred.get_series(sid, observation_start="1945-10-01").dropna()
        print(f"{sid:12s} {s.index[0]:%Y-%m-%d} ~ {s.index[-1]:%Y-%m-%d}  n={len(s)}  最新={s.iloc[-1]:,.0f} (百万美元)")
        cols[sid] = s
    raw = pd.DataFrame(cols)
    raw.index = pd.to_datetime(raw.index).strftime("%Y-%m-%d")
    raw.index.name = "date"

    hist = R.aiae_history(R.frame_from_series(cols))
    print("\n最近 6 个季度 AIAE (%):")
    for d, v in hist["aiae"].tail(6).items():
        print(f"  {d.year}Q{d.quarter}  {v:.2f}")
    print("\n历史锚点:")
    for q, label in R.ANCHORS.items():
        ts = pd.Period(q, freq="Q").to_timestamp(how="end").normalize()
        if ts in hist.index:
            print(f"  {q} {label}: {hist.loc[ts, 'aiae']:.1f}")
    print(f"\n历史 ({hist.index[0].year}Q{hist.index[0].quarter} 起) 中位数 {hist['aiae'].median():.1f}, "
          f"最低 {hist['aiae'].min():.1f}, 最高 {hist['aiae'].max():.1f}")

    if args.check:
        print("\n--check: 未写文件")
        return
    out = os.path.join(ROOT, "data", "us_aiae_z1_quarterly.csv")
    os.makedirs(os.path.dirname(out), exist_ok=True)
    raw.to_csv(out, float_format="%.0f")
    print(f"\n已写入 {out} ({len(raw)} 行)")


if __name__ == "__main__":
    main()
