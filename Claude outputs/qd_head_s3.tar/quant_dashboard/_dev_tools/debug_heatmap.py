import tushare as ts
from datetime import datetime

# Tushare token: 从环境变量读取 (不再内置; 缺少时直接退出, 不回退到旧值)
import os
try:
    from dotenv import load_dotenv
    load_dotenv(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", ".env"))
except ImportError:
    pass
TUSHARE_TOKEN = os.environ.get("TUSHARE_TOKEN", "").strip()
if not TUSHARE_TOKEN:
    raise SystemExit("缺少环境变量 TUSHARE_TOKEN: 请在 .env 或系统环境变量中配置 (本脚本不再内置密钥)")
ts.set_token(TUSHARE_TOKEN)
pro = ts.pro_api()

sector_map = {"801730.SI": "电力设备", "801150.SI": "医药生物", "801120.SI": "食品饮料", "801080.SI": "电子", "801750.SI": "计算机"}
try:
    df_sectors = pro.index_daily(ts_code=",".join(sector_map.keys()), start_date='20250101', limit=50)
    print("DataFrame shape:", df_sectors.shape)
    if not df_sectors.empty:
        print(df_sectors.head())
    else:
        print("DataFrame is empty")
except Exception as e:
    print("Error:", e)
