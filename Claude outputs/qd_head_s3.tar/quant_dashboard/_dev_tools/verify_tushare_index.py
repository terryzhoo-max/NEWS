import tushare as ts
import pandas as pd
# Tushare token: 从环境变量读取 (不再内置; 缺少时直接退出, 不回退到旧值)
import os
try:
    from dotenv import load_dotenv
    load_dotenv(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", ".env"))
except ImportError:
    pass
TUSHARE_TOKEN = os.environ.get("TUSHARE_TOKEN", "").strip()
if not TUSHARE_TOKEN:
    raise SystemExit("缺少环境变量 TUSHARE_TOKEN: 请在 .env 或系统环境变量中配置 (本脚本不再内置密钥)")
pro = ts.pro_api(TUSHARE_TOKEN)
df = pro.index_daily(ts_code='801730.SI', limit=1)
print("Data for 801730.SI (Electricity Equipment):")
print(df)
