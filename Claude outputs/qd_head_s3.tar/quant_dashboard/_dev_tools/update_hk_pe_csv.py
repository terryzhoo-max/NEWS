"""
把理杏仁导出的恒生指数 PE-TTM (总市值加权) 整理成仓库内的月度 CSV (data/hk_pe_monthly.csv)。

来源: 理杏仁 → 恒生指数 (HSI) → 基本面 → 估值 → PE-TTM · 总市值加权 → 导出CSV → "按月——全部时间段"
      文件名形如 恒生指数_PE-TTM_总市值加权_上市以来_YYYYMMDD_HHMMSS.csv,
      放在 data_lake/ (项目内层或外层均可), 脚本自动取最新的一份; 也可把路径作为参数传入。
口径: 理杏仁按成分股计算的 PE-TTM (总市值加权), 非恒生指数公司官方公布值; 全历史同一口径。
范围: 只保留 2003-01 起 (DFII10 起点; 2001-2002 年初数值 36~60 明显异常, 不采用)。

用法 (项目目录下):
    .venv\\Scripts\\python _dev_tools\\update_hk_pe_csv.py
"""
import glob
import os
import sys

import pandas as pd

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT_CSV = os.path.join(ROOT, "data", "hk_pe_monthly.csv")
START = "2003-01-01"
SOURCE = "lixinger_pe_ttm_mcap"
PATTERN = "恒生指数_PE-TTM_总市值加权_*.csv"


def find_export() -> str:
    dirs = [os.path.join(ROOT, "data_lake"), os.path.join(os.path.dirname(ROOT), "data_lake")]
    files = [f for d in dirs for f in glob.glob(os.path.join(d, PATTERN))]
    if not files:
        raise FileNotFoundError(f"data_lake/ 下没有 {PATTERN}")
    return max(files, key=os.path.getmtime)


def parse_lixinger(path: str) -> pd.DataFrame:
    """理杏仁 CSV: UTF-8 BOM; 数值带前导 '='; 末尾有"数据来源"说明行。"""
    recs = []
    with open(path, encoding="utf-8-sig") as f:
        header = f.readline().strip().split(",")
        try:
            i_pe = next(i for i, h in enumerate(header) if h.startswith("PE-TTM") and "分位" not in h)
        except StopIteration:
            raise ValueError(f"找不到 PE-TTM 列: {header}")
        for line in f:
            c = [x.strip().lstrip("=") for x in line.strip().split(",")]
            if len(c) <= i_pe or len(c[0]) != 10 or c[0][4] != "-":
                continue
            try:
                recs.append({"date": pd.Timestamp(c[0]), "pe": float(c[i_pe])})
            except ValueError:
                continue
    df = pd.DataFrame(recs)
    if df.empty:
        raise ValueError("没有解析到任何数据行")
    df = df[(df["date"] >= START) & (df["pe"] > 0)].drop_duplicates("date").sort_values("date")
    return df


def main(path: str = None) -> pd.DataFrame:
    path = path or find_export()
    new = parse_lixinger(path)
    new = new.assign(date=new["date"].dt.strftime("%Y-%m-%d"), market="HSI", pe=new["pe"].round(4), source=SOURCE)
    keep = pd.DataFrame(columns=["date", "market", "pe", "source"])
    if os.path.exists(OUT_CSV):
        old = pd.read_csv(OUT_CSV, dtype=str)
        keep = old[old["market"].str.upper() != "HSI"]  # 其他指数 (如 HSTECH) 的行原样保留
    out = pd.concat([keep, new[["date", "market", "pe", "source"]]], ignore_index=True)
    out.to_csv(OUT_CSV, index=False, lineterminator="\n")
    print(f"来源: {os.path.basename(path)}")
    print(f"HSI PE-TTM: {len(new)} 个月, {new['date'].iloc[0]} ~ {new['date'].iloc[-1]}, 最新 {new['pe'].iloc[-1]:.2f}")
    print(f"已写入 {OUT_CSV}")
    return out


if __name__ == "__main__":
    main(sys.argv[1] if len(sys.argv) > 1 else None)
