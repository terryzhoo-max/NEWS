# -*- coding: utf-8 -*-
"""
AIAE 月度历史口径修复 (P0, 2026-10-30)
=====================================
问题: SQLite aiae_monthly 里 2026-03/04/05 是 V1 时代的 json_backfill 估算值 (22.1~22.3, R2),
      2026-06 起才是 V5 的 AIAE_简 (25~27, R3); 2026-08 整月缺失。
      斜率告警与迟滞判断用的"上月值/上月档位"因此混用两种口径。

做法: 对"被污染或缺失"的已完结月份, 用月末最后交易日的真实数据重算 AIAE_简:
      总市值 (daily_basic 全 A 加总) / (总市值 + 当时已公布的 M2), M2 发布延迟按
      engines/aiae_data_builder.TushareClient.get_m2 建模 (不偷看未来)。
      只接受 daily_basic 的真实市值与真实 M2; 任一为估算/降级值则跳过该月, 绝不写入估算值。
      档位按 V5 阈值 + 迟滞, 沿月份顺序链式判定。

用法 (在项目根目录, 即 alpha_core 服务所在目录):
    python _dev_tools/rebuild_aiae_monthly.py            # 只预览, 不写任何文件
    python _dev_tools/rebuild_aiae_monthly.py --apply    # 写 SQLite + 同步 JSON 备份 (先自动备份两者)
    python _dev_tools/rebuild_aiae_monthly.py --start 2026-03 --end 2026-09

不改动: 当月 (仍由引擎实时写入) 与已有的 V5 实测月份 (source 为空)。
"""
import argparse
import json
import os
import shutil
import sys
from datetime import datetime

_HERE = os.path.dirname(os.path.abspath(__file__))
_ROOT = os.path.dirname(_HERE)
for p in (_ROOT, os.path.join(_ROOT, "engines")):
    if p not in sys.path:
        sys.path.insert(0, p)
os.chdir(_ROOT)  # 引擎以相对路径 data_lake 读写

CONTAMINATED_SOURCES = {"json_backfill", "seed_interpolated"}
REBUILD_SOURCE = "month_end_rebuild"
JSON_FILE = os.path.join(_ROOT, "data_lake", "aiae_monthly_history.json")


def _months(start: str, end: str):
    y, m = map(int, start.split("-"))
    ey, em = map(int, end.split("-"))
    while (y, m) <= (ey, em):
        yield f"{y}-{m:02d}"
        m += 1
        if m == 13:
            y, m = y + 1, 1


def _prev_month(month: str) -> str:
    y, m = map(int, month.split("-"))
    return f"{y - 1}-12" if m == 1 else f"{y}-{m - 1:02d}"


def _needs_rebuild(row) -> bool:
    return row is None or (row.get("source") in CONTAMINATED_SOURCES) or bool(row.get("is_seed"))


def main():
    cur_month = datetime.now().strftime("%Y-%m")
    ap = argparse.ArgumentParser()
    ap.add_argument("--start", default="2026-03")
    ap.add_argument("--end", default=_prev_month(cur_month), help="默认上个月 (当月不处理)")
    ap.add_argument("--apply", action="store_true", help="写入 SQLite 并同步 JSON 备份")
    args = ap.parse_args()
    if args.end >= cur_month:
        sys.exit(f"--end 必须早于当月 {cur_month} (当月由引擎实时写入)")

    from services import db as ac_db
    from services.db.connection import DB_PATH
    from engines.aiae_engine import AIAEEngine
    from engines.aiae_data_builder import TushareClient
    from config import TUSHARE_TOKEN

    rows = {r["month"]: r for r in ac_db.get_aiae_history()}
    client = TushareClient(TUSHARE_TOKEN)
    classify = lambda v, prev: AIAEEngine.classify_regime(None, v, prev, aiae_simple=v)  # 纯函数, 不建引擎实例

    prev_regime = (rows.get(_prev_month(args.start)) or {}).get("regime")
    plan = []
    print(f"SQLite: {DB_PATH}")
    print(f"{'月份':<8} {'现值':>7} {'现档':>4} {'来源':<18} → {'月末AIAE_简':>10} {'新档':>4}  说明")
    for month in _months(args.start, args.end):
        row = rows.get(month)
        if not _needs_rebuild(row):
            prev_regime = row.get("regime")
            print(f"{month:<8} {row['aiae_v1']:>7} {row['regime']:>4} {'(V5实测)':<18}   保留")
            continue
        y, m = map(int, month.split("-"))
        td = client.get_last_trade_day(y, m)
        mv = client.get_total_mv(td) if td else None
        m2 = client.get_m2(y, m, int(td[-2:])) if td else None
        if not mv or mv.get("source") != "daily_basic" or not m2 or not m2.get("m2_wan_yi"):
            why = "无交易日" if not td else ("市值非 daily_basic 实测" if not mv or mv.get("source") != "daily_basic" else "M2 缺失")
            print(f"{month:<8} {'-' if not row else row['aiae_v1']:>7} {'-':>4} {(row or {}).get('source') or '缺失':<18}   跳过: {why}")
            continue
        val = round(mv["total_mv_wan_yi"] / (mv["total_mv_wan_yi"] + m2["m2_wan_yi"]) * 100, 2)
        reg = classify(val, prev_regime)
        prev_regime = reg
        old = "-" if not row else row["aiae_v1"]
        oldr = "-" if not row else row["regime"]
        print(f"{month:<8} {old:>7} {oldr:>4} {(row or {}).get('source') or '缺失':<18} → {val:>10} {reg:>4}"
              f"  {td} 市值{mv['total_mv_wan_yi']}万亿 / M2({m2['m2_month']}) {m2['m2_wan_yi']}万亿")
        plan.append({"month": month, "aiae": val, "regime": reg, "trade_date": td})

    if not plan:
        print("\n无需修复。")
        return
    if not args.apply:
        print(f"\n预览: {len(plan)} 个月待修复。确认无误后加 --apply 写入。")
        return

    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    shutil.copy2(DB_PATH, f"{DB_PATH}.{stamp}.bak")
    if os.path.exists(JSON_FILE):
        shutil.copy2(JSON_FILE, f"{JSON_FILE}.{stamp}.bak")
    for p in plan:
        ac_db.upsert_aiae_monthly(p["month"], p["aiae"], p["regime"],
                                  recorded_at=datetime.now().isoformat(), source=REBUILD_SOURCE)

    # JSON 备份与 SQLite 对齐 (保留当月条目的 decomposition 等附加字段)
    old_json = []
    if os.path.exists(JSON_FILE):
        try:
            with open(JSON_FILE, "r", encoding="utf-8") as f:
                old_json = json.load(f)
        except Exception:
            old_json = []
    extra = {e["month"]: e for e in old_json if not e.get("is_seed")}
    synced = []
    for r in ac_db.get_aiae_history():
        e = dict(extra.get(r["month"], {}))
        e.update({"month": r["month"], "aiae_v1": r["aiae_v1"], "regime": r["regime"],
                  "recorded_at": r.get("recorded_at"), "updated_at": r.get("updated_at"),
                  "basis": "aiae_simple"})
        if r.get("source"):
            e["source"] = r["source"]
        e.pop("is_seed", None)
        synced.append(e)
    from engines.aiae_engine import atomic_write_json
    atomic_write_json(synced, JSON_FILE)
    print(f"\n已写入 {len(plan)} 个月 (source={REBUILD_SOURCE}); 备份: *.{stamp}.bak")


if __name__ == "__main__":
    main()
