import tushare as ts
from datetime import datetime

# Tushare token: 从环境变量读取 (不再内置; 缺少时直接退出, 不回退到旧值)
import os
try:
    from dotenv import load_dotenv
    load_dotenv(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", ".env"))
except ImportError:
    pass
TUSHARE_TOKEN = os.environ.get("TUSHARE_TOKEN", "").strip()
if not TUSHARE_TOKEN:
    raise SystemExit("缺少环境变量 TUSHARE_TOKEN: 请在 .env 或系统环境变量中配置 (本脚本不再内置密钥)")
ts.set_token(TUSHARE_TOKEN)
pro = ts.pro_api()
today_str = datetime.now().strftime('%Y%m%d')
df = pro.moneyflow_hsgt(start_date='20260301', end_date=today_str, limit=5)
print(df)
