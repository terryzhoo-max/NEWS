"""
把 JPX 的 PER 文件整理成仓库内的月度 CSV (data/jpx_per_monthly.csv)。

口径: 合并 (連結) · 加权平均 (加重) · 市场整体 (総合)
      2013-01 ~ 2022-03 = 东证一部; 2022-04 起 = Prime 市场
来源 (放在 data_lake/ 下):
  - longrange-perpbr.xlsx      JPX "長期データ（総合）" (可选, 首次建库用)
  - perpbrYYYYMM.xlsx          JPX 每月 PER 文件 (每月第 1 个营业日更新)

用法 (项目目录下):
    .venv\\Scripts\\python _dev_tools\\update_jpx_per_csv.py

每月: 从 https://www.jpx.co.jp/markets/statistics-equities/misc/04.html 下载最新月份的
perpbrYYYYMM.xlsx 放进 data_lake/, 运行本脚本, 推送。已有月份保留, 新月份追加。
"""
import glob
import os
import re

import pandas as pd

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
LAKE = os.path.join(ROOT, "data_lake")
OUT_CSV = os.path.join(ROOT, "data", "jpx_per_monthly.csv")
COLS = ["month", "segment", "companies", "per_weighted", "pbr_weighted",
        "earnings_100m_jpy", "net_assets_100m_jpy"]

LONG_SHEETS = {  # 工作表名 → 第一个数据块对应的市场
    "Consolidated(WT AVG)～202203": "first_section",
    "Consolidated(Weighted avg.)": "prime",
}


def parse_longrange(path: str) -> pd.DataFrame:
    rows = []
    xl = pd.ExcelFile(path)
    for sheet, seg in LONG_SHEETS.items():
        if sheet not in xl.sheet_names:
            continue
        raw = pd.read_excel(xl, sheet_name=sheet, header=None)
        for r in raw.itertuples(index=False):
            y, m = r[0], r[1]
            if not (isinstance(y, (int, float)) and isinstance(m, (int, float))) or pd.isna(y):
                continue
            rows.append([f"{int(y):04d}-{int(m):02d}", seg, r[2], r[3], r[4], r[5], r[6]])
    return pd.DataFrame(rows, columns=COLS)


def parse_monthly(path: str) -> pd.DataFrame:
    """perpbrYYYYMM.xlsx: 取 Prime 市场 '総合 Composite' 行的加权口径。"""
    raw = pd.read_excel(path, sheet_name=0, header=None)
    for r in raw.itertuples(index=False):
        if str(r[2]).strip() == "Prime" and str(r[4]).strip() == "Composite":
            month = str(r[0]).strip().replace("/", "-")
            return pd.DataFrame([[month, "prime", r[5], r[10], r[11],
                                  float(r[12]) / 1e8, float(r[13]) / 1e8]], columns=COLS)
    raise ValueError(f"{os.path.basename(path)}: 找不到 Prime / Composite 行")


def build(lake: str = LAKE, existing_csv: str = OUT_CSV) -> pd.DataFrame:
    parts = []
    if os.path.exists(existing_csv):
        parts.append(pd.read_csv(existing_csv, dtype={"month": str}))
    longp = os.path.join(lake, "longrange-perpbr.xlsx")
    if os.path.exists(longp):
        parts.append(parse_longrange(longp))
    for p in sorted(glob.glob(os.path.join(lake, "perpbr*.xlsx"))):
        if re.search(r"perpbr\d{6}\.xlsx$", p):
            parts.append(parse_monthly(p))
    if not parts:
        raise FileNotFoundError("data_lake/ 下没有 JPX PER 文件")
    df = pd.concat(parts, ignore_index=True)
    df = df.drop_duplicates("month", keep="last").sort_values("month").reset_index(drop=True)
    for c in COLS[2:]:
        df[c] = pd.to_numeric(df[c], errors="coerce")
    return df[COLS]


def main() -> None:
    df = build()
    os.makedirs(os.path.dirname(OUT_CSV), exist_ok=True)
    df.to_csv(OUT_CSV, index=False, float_format="%.6g")
    last = df.iloc[-1]
    print(f"写入 {OUT_CSV}: {len(df)} 行, {df['month'].iloc[0]} ~ {last['month']}, "
          f"最新加权 PER {last['per_weighted']} ({last['segment']})")


if __name__ == "__main__":
    main()
