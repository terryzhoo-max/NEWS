"""AlphaCore SQLite 一致性备份 / 恢复校验 (F5, 2026-10-27; 仅依赖 Python 标准库)。

覆盖的库 (按名称):
  main      主库 alphacore.db          — $ALPHACORE_DB_DIR 或 services/data_lake/
  analysis  人工决策库 analysis_decisions.db — data_lake/

命令:
  python _dev_tools/db_backup.py backup  --out <目录>       在线备份 (sqlite backup API, 含 WAL 未合并数据)
  python _dev_tools/db_backup.py verify  --dir <备份目录>   在临时目录恢复并核对 (完整性/各表行数与内容哈希/关键关联)
  python _dev_tools/db_backup.py restore --dir <备份目录> --to <目标目录> [--force]

- 只读打开源库; 备份目录内写入 <name>.db 与 manifest.json (行数/哈希, 不含明细)。
- restore 默认拒绝覆盖已存在的目标库; 先 verify 再 restore。服务运行中请勿 restore。
- 退出码: 0 成功; 2 校验失败; 1 用法/IO 错误。
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import sqlite3
import sys
import tempfile
from datetime import datetime, timezone

APP_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
MANIFEST = "manifest.json"
TOOL_VERSION = "db-backup-v1"


def source_paths() -> dict:
    main_dir = os.environ.get("ALPHACORE_DB_DIR") or os.path.join(APP_ROOT, "services", "data_lake")
    return {
        "main": os.path.join(os.path.abspath(main_dir), "alphacore.db"),
        "analysis": os.path.join(APP_ROOT, "data_lake", "analysis_decisions.db"),
    }


def _tables(conn) -> list:
    return [r[0] for r in conn.execute(
        "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name")]


def _table_digest(conn, table: str) -> tuple:
    """(行数, 内容哈希)。按全部列排序后逐行哈希, 与物理存储顺序无关。"""
    cols = [r[1] for r in conn.execute(f'PRAGMA table_info("{table}")')]
    order = ", ".join(f'"{c}"' for c in cols)
    h = hashlib.sha256()
    n = 0
    for row in conn.execute(f'SELECT {order} FROM "{table}" ORDER BY {order}'):
        h.update(json.dumps(list(row), ensure_ascii=False, default=str).encode("utf-8"))
        n += 1
    return n, h.hexdigest()


def _schema_hash(conn) -> str:
    rows = conn.execute("SELECT type, name, sql FROM sqlite_master WHERE name NOT LIKE 'sqlite_%' "
                        "ORDER BY type, name").fetchall()
    return hashlib.sha256(json.dumps(rows, ensure_ascii=False).encode("utf-8")).hexdigest()


def _relations(conn, name: str) -> dict:
    """关键关联核对; 返回 {检查名: 违例数}。表不存在则跳过。"""
    tables = set(_tables(conn))
    out = {}
    if name == "main":
        if {"execution_request_keys", "execution_orders"} <= tables:
            out["request_key_without_order"] = conn.execute(
                "SELECT COUNT(*) FROM execution_request_keys k LEFT JOIN execution_orders o "
                "ON k.order_id = o.order_id WHERE o.order_id IS NULL").fetchone()[0]
        if "execution_orders" in tables:
            cols = {r[1] for r in conn.execute("PRAGMA table_info(execution_orders)")}
            if "parent_order_id" in cols:
                out["fill_without_parent_order"] = conn.execute(
                    "SELECT COUNT(*) FROM execution_orders c LEFT JOIN execution_orders p "
                    "ON c.parent_order_id = p.order_id "
                    "WHERE c.parent_order_id IS NOT NULL AND c.parent_order_id <> '' "
                    "AND p.order_id IS NULL").fetchone()[0]
    if name == "analysis" and {"analysis_decisions", "analysis_observations"} <= tables:
        snaps = {r[0] for r in conn.execute("SELECT snapshot_id FROM analysis_observations")}
        missing = 0
        for (payload,) in conn.execute("SELECT payload FROM analysis_decisions"):
            try:
                sid = json.loads(payload).get("snapshot_id")
            except (ValueError, AttributeError):
                sid = None
            if sid and sid not in snaps:
                missing += 1
        # 信息项: 决策引用的快照未单独存档 (不作为失败条件, 现有写入逻辑未保证二者同存)
        out["info_decision_snapshot_not_in_observations"] = missing
    return out


def _describe(path: str, name: str) -> dict:
    conn = sqlite3.connect(f"file:{path}?mode=ro", uri=True)
    try:
        integrity = conn.execute("PRAGMA integrity_check").fetchone()[0]
        tables = {t: dict(zip(("rows", "sha256"), _table_digest(conn, t))) for t in _tables(conn)}
        return {"integrity": integrity, "schema_sha256": _schema_hash(conn), "tables": tables,
                "relations": _relations(conn, name)}
    finally:
        conn.close()


def _file_sha256(path: str) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def cmd_backup(out_dir: str) -> int:
    os.makedirs(out_dir, exist_ok=True)
    manifest = {"tool": TOOL_VERSION, "created_at": datetime.now(timezone.utc).isoformat(), "databases": {}}
    ok = True
    for name, src in source_paths().items():
        if not os.path.exists(src):
            manifest["databases"][name] = {"status": "source_missing", "source": src}
            print(f"[{name}] 源库不存在, 跳过: {src}")
            continue
        dst = os.path.join(out_dir, f"{name}.db")
        s = sqlite3.connect(f"file:{src}?mode=ro", uri=True)
        d = sqlite3.connect(dst)
        try:
            s.backup(d)
        finally:
            d.close()
            s.close()
        desc = _describe(dst, name)
        desc.update(status="ok" if desc["integrity"] == "ok" else "integrity_failed",
                    source=src, file=f"{name}.db", file_sha256=_file_sha256(dst))
        manifest["databases"][name] = desc
        ok &= desc["integrity"] == "ok"
        print(f"[{name}] {desc['status']} · 表 {len(desc['tables'])} · "
              f"行 {sum(t['rows'] for t in desc['tables'].values())} · 关联 {desc['relations']}")
    with open(os.path.join(out_dir, MANIFEST), "w", encoding="utf-8") as f:
        json.dump(manifest, f, ensure_ascii=False, indent=2)
    print(f"备份目录: {out_dir}")
    return 0 if ok else 2


def _load_manifest(backup_dir: str) -> dict:
    with open(os.path.join(backup_dir, MANIFEST), "r", encoding="utf-8") as f:
        return json.load(f)


def cmd_verify(backup_dir: str) -> int:
    manifest = _load_manifest(backup_dir)
    failures = []
    with tempfile.TemporaryDirectory(prefix="alphacore_restore_drill_") as tmp:
        for name, expected in manifest["databases"].items():
            if expected.get("status") == "source_missing":
                print(f"[{name}] 备份时源库不存在 (跳过)")
                continue
            src = os.path.join(backup_dir, expected["file"])
            if _file_sha256(src) != expected["file_sha256"]:
                failures.append(f"{name}: 备份文件哈希不符 (文件被改动或损坏)")
                continue
            restored = os.path.join(tmp, f"{name}.db")
            shutil.copyfile(src, restored)              # 模拟在独立环境恢复
            got = _describe(restored, name)
            if got["integrity"] != "ok":
                failures.append(f"{name}: integrity_check={got['integrity']}")
            if got["schema_sha256"] != expected["schema_sha256"]:
                failures.append(f"{name}: 表结构不一致")
            for t, exp in expected["tables"].items():
                g = got["tables"].get(t)
                if g is None:
                    failures.append(f"{name}.{t}: 恢复后缺表")
                elif g != exp:
                    failures.append(f"{name}.{t}: 行数/内容不一致 ({g['rows']} vs {exp['rows']})")
            for rel, cnt in got["relations"].items():
                if not rel.startswith("info_") and cnt:
                    failures.append(f"{name}: 关联违例 {rel}={cnt}")
            print(f"[{name}] 恢复演练: 完整性 {got['integrity']} · 表 {len(got['tables'])} · "
                  f"关联 {got['relations']}")
    if failures:
        print("❌ 校验失败:\n  " + "\n  ".join(failures))
        return 2
    print("✅ 恢复演练通过: 完整性、表结构、各表行数与内容哈希、关键关联均一致")
    return 0


def cmd_restore(backup_dir: str, to_dir: str, force: bool) -> int:
    if cmd_verify(backup_dir) != 0:
        print("备份未通过校验, 拒绝恢复")
        return 2
    manifest = _load_manifest(backup_dir)
    os.makedirs(to_dir, exist_ok=True)
    targets = {"main": "alphacore.db", "analysis": "analysis_decisions.db"}
    for name, meta in manifest["databases"].items():
        if meta.get("status") == "source_missing":
            continue
        dst = os.path.join(to_dir, targets[name])
        if os.path.exists(dst) and not force:
            print(f"目标已存在, 拒绝覆盖 (需 --force): {dst}")
            return 1
        for suffix in ("-wal", "-shm"):
            if os.path.exists(dst + suffix) and not force:
                print(f"目标存在 {suffix} 文件, 服务可能在运行, 拒绝恢复: {dst + suffix}")
                return 1
        shutil.copyfile(os.path.join(backup_dir, meta["file"]), dst)
        print(f"[{name}] 已恢复到 {dst}")
    return 0


def main(argv=None) -> int:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = p.add_subparsers(dest="cmd", required=True)
    b = sub.add_parser("backup"); b.add_argument("--out", required=True)
    v = sub.add_parser("verify"); v.add_argument("--dir", required=True)
    r = sub.add_parser("restore"); r.add_argument("--dir", required=True)
    r.add_argument("--to", required=True); r.add_argument("--force", action="store_true")
    a = p.parse_args(argv)
    try:
        if a.cmd == "backup":
            return cmd_backup(a.out)
        if a.cmd == "verify":
            return cmd_verify(a.dir)
        return cmd_restore(a.dir, a.to, a.force)
    except (OSError, sqlite3.Error, KeyError, ValueError) as e:
        print(f"错误: {type(e).__name__}: {e}")
        return 1


if __name__ == "__main__":
    sys.exit(main())
