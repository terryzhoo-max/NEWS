import pandas as pd
import tushare as ts
from backtest_engine import AlphaBacktester
import os

# Set token
# Tushare token: 从环境变量读取 (不再内置; 缺少时直接退出, 不回退到旧值)
import os
try:
    from dotenv import load_dotenv
    load_dotenv(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", ".env"))
except ImportError:
    pass
TUSHARE_TOKEN = os.environ.get("TUSHARE_TOKEN", "").strip()
if not TUSHARE_TOKEN:
    raise SystemExit("缺少环境变量 TUSHARE_TOKEN: 请在 .env 或系统环境变量中配置 (本脚本不再内置密钥)")
ts.set_token(TUSHARE_TOKEN)
pro = ts.pro_api()

def debug():
    print("--- Debugging Tushare Data Fetch for 510300.SH ---")
    bt = AlphaBacktester()
    
    # Try fetching data directly
    try:
        df = bt.fetch_tushare_data('510300.SH', '20230101', '20231231', adj='qfq')
        print(f"Fetch success. Rows: {len(df)}")
        if len(df) > 0:
            print(df.head())
        else:
            print("!!! Dataframe is empty")
            
        # Check fund_basic to see if 510300.SH exists
        basic = pro.fund_basic(ts_code='510300.SH')
        print(f"Fund Basic for 510300.SH:\n{basic}")
        
        # Check if daily data exists
        daily = pro.fund_daily(ts_code='510300.SH', start_date='20230101', end_date='20230110')
        print(f"Daily Sample (10 days):\n{daily}")
        
    except Exception as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    debug()
