"""
审核样例: 持仓存储 (portfolio_store.json) vs 券商"资金股份查询"文件头 (已归档)

原脚本含真实账户数值, 已改为人工样本; 核对逻辑保留:
  1. 逐只核对 broker_market_value ≈ amount × broker_price
  2. 持仓市值合计 / 盈亏合计 与文件头"参考市值 / 盈亏"比较
  3. 冻结持仓 ("证券数量=0 但库存数量>0") 被导入跳过时, 市值与总资产的差异如何解释
用法:
  python _audit_import.py                 只运行内置人工样本
  python _audit_import.py <store.json>    对指定持仓文件只做第 1、2 步的逐只与合计检查 (不含文件头比较)
"""
import json
import sys

# ── 人工样本 (虚构数值, 与任何真实账户无关) ──
SAMPLE_STORE = {
    "cash": 8000.00,   # 导入时取的是"可用"而非"余额"
    "positions": {
        "000001.SZ": {"amount": 1000, "cost": 12.00, "broker_price": 12.50,
                      "broker_market_value": 12500.00, "broker_pnl": 500.00, "broker_pnl_pct": 4.17},
        "510300.SH": {"amount": 8000, "cost": 4.00, "broker_price": 4.3125,
                      "broker_market_value": 34500.00, "broker_pnl": 2500.00, "broker_pnl_pct": 7.81},
    },
}
SAMPLE_HEADER = {"balance": 10000.00, "available": 8000.00, "ref_mv": 50000.00,
                 "total_asset": 57200.00, "pnl": 3200.00}
# 冻结持仓 (证券数量=0, 库存数量=200): 被旧导入逻辑跳过, 但计入了文件头的参考市值与盈亏
FROZEN = {"code": "600000.SH", "mv": 3000.00, "cost": 2800.00, "pnl": 200.00}


def check_positions(store):
    print("=== 持仓逐只核对 ===")
    print(f"现金 (cash): {store['cash']}")
    print(f"持仓数: {len(store['positions'])}")
    print(f"{'代码':<12} {'数量':>8} {'成本价':>8} {'券商价':>8} {'券商市值':>12} {'券商盈亏':>10} {'盈亏%':>7}")
    print("-" * 75)
    tot_mv = tot_pnl = tot_cost = 0.0
    for code, pos in store["positions"].items():
        amt, cost = pos["amount"], pos["cost"]
        bp = pos.get("broker_price", 0)
        bmv = pos.get("broker_market_value", 0)
        bpnl = pos.get("broker_pnl", 0)
        bpct = pos.get("broker_pnl_pct", 0)
        tot_mv += bmv
        tot_pnl += bpnl
        tot_cost += amt * cost
        expected = amt * bp if bp > 0 else 0
        ok = abs(bmv - expected) < 1 if bmv > 0 else True
        flag = "OK" if ok else f"MISMATCH (expected {expected:.2f})"
        print(f"{code:<12} {amt:>8} {cost:>8.3f} {bp:>8.3f} {bmv:>12.2f} {bpnl:>10.2f} {bpct:>6.2f}%  {flag}")
    print(f"市值合计 = {tot_mv:.2f} · 盈亏合计 = {tot_pnl:.2f} · 成本合计 = {tot_cost:.2f}")
    return tot_mv, tot_pnl


def check_header(tot_mv, tot_pnl, header, frozen, store_cash):
    print()
    print("=== 与券商文件头比较 ===")
    print(f"参考市值 {header['ref_mv']:.2f} · 持仓市值合计 {tot_mv:.2f} · 差异 {header['ref_mv'] - tot_mv:.2f}")
    print(f"文件头盈亏 {header['pnl']:.2f} · 持仓盈亏合计 {tot_pnl:.2f} · 差异 {header['pnl'] - tot_pnl:.2f}")
    print(f"冻结持仓 {frozen['code']} 市值 {frozen['mv']:.2f} / 盈亏 {frozen['pnl']:.2f} → 解释上述差异: "
          f"{abs(header['ref_mv'] - tot_mv - frozen['mv']) < 1 and abs(header['pnl'] - tot_pnl - frozen['pnl']) < 1}")
    print()
    print("=== 总资产口径 ===")
    a = header["balance"] + header["ref_mv"]
    b = header["available"] + header["ref_mv"]
    c = header["balance"] + (header["ref_mv"] - frozen["cost"])
    print(f"方式A 余额 + 参考市值               = {a:.2f}")
    print(f"方式B 可用 + 参考市值               = {b:.2f}")
    print(f"方式C 余额 + (参考市值 - 冻结成本)  = {c:.2f}")
    print(f"券商总资产                          = {header['total_asset']:.2f} → 方式C {'匹配' if abs(c - header['total_asset']) < 1 else '不匹配'}")
    print(f"store.cash 取'可用' ({store_cash:.2f}), 与'余额'相差 {header['balance'] - store_cash:.2f} (冻结资金)")
    print()
    print("【结论 (与已修复的导入逻辑一致)】")
    print("  1. 现金应取'余额'而非'可用'")
    print("  2. 数量应优先取'库存数量', 避免冻结/在途持仓被跳过")
    print("  3. 文件头的参考市值与总资产可直接用于核对")


if __name__ == "__main__":
    if len(sys.argv) > 1:
        with open(sys.argv[1], encoding="utf-8") as f:
            check_positions(json.load(f))
    else:
        mv, pnl = check_positions(SAMPLE_STORE)
        check_header(mv, pnl, SAMPLE_HEADER, FROZEN, SAMPLE_STORE["cash"])
