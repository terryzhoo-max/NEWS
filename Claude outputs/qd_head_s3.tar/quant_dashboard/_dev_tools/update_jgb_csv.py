"""
把财务省 (MOF) 国债收益率 CSV 整理成仓库内的 10 年期日序列快照 (data/jgb10y_daily.csv)。
服务器优先实时读取 MOF 当月数据; 这份快照只在实时读取失败时作为回退。

来源 (放在 data_lake/ 下):
  - jgbcm_all.csv   https://www.mof.go.jp/jgbs/reference/interest_rate/data/jgbcm_all.csv  (1974 年起, 截至上月末)
  - jgbcm.csv       https://www.mof.go.jp/jgbs/reference/interest_rate/jgbcm.csv           (当月)

用法 (项目目录下):
    .venv\\Scripts\\python _dev_tools\\update_jgb_csv.py
"""
import os
import sys

import pandas as pd

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

from engines.jp_valuation import JGB_CSV, parse_mof_csv  # noqa: E402

LAKE = os.path.join(ROOT, "data_lake")
START = "1999-01-01"


def build(lake: str = LAKE) -> pd.Series:
    parts = []
    for name in ("jgbcm_all.csv", "jgbcm.csv"):
        p = os.path.join(lake, name)
        if os.path.exists(p):
            with open(p, "rb") as f:
                parts.append(parse_mof_csv(f.read()))
    if os.path.exists(JGB_CSV):
        old = pd.read_csv(JGB_CSV)
        parts.insert(0, pd.Series(old["jgb10y"].values, index=pd.to_datetime(old["date"])))
    if not parts:
        raise FileNotFoundError("data_lake/ 下没有 jgbcm_all.csv 或 jgbcm.csv")
    s = pd.concat(parts)
    s = s[~s.index.duplicated(keep="last")].sort_index()
    return s[s.index >= START]


def main() -> None:
    s = build()
    os.makedirs(os.path.dirname(JGB_CSV), exist_ok=True)
    pd.DataFrame({"date": s.index.strftime("%Y-%m-%d"), "jgb10y": s.values}).to_csv(JGB_CSV, index=False)
    print(f"写入 {JGB_CSV}: {len(s)} 行, {s.index[0]:%Y-%m-%d} ~ {s.index[-1]:%Y-%m-%d}, 最新 10Y {s.iloc[-1]:.3f}%")


if __name__ == "__main__":
    main()
