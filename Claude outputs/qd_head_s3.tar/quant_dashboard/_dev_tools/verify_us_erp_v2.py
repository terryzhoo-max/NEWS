"""
美股 ERP V2 预注册检验 (docs/ERP_GLOBAL_PREREGISTRATION.md §2)。

用法 (项目目录下):
    .venv\\Scripts\\python _dev_tools\\verify_us_erp_v2.py            # 拼接版: 2003 年起用 FRED DFII10
    .venv\\Scripts\\python _dev_tools\\verify_us_erp_v2.py --proxy    # 全程代理利率 (离线)

输出: 终端表格 + data_lake/us_erp_v2_validation.json
"""
import json
import os
import sys

import numpy as np
import pandas as pd

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

from engines import us_valuation as uv  # noqa: E402

OUT_JSON = os.path.join(ROOT, "data_lake", "us_erp_v2_validation.json")
HORIZONS = {"10y": 120, "5y": 60, "1y": 12}
ORDER = ["cheap", "neutral", "expensive"]


def _dfii10_from_fred():
    try:
        from config import FRED_API_KEY
        from fredapi import Fred
        s = Fred(api_key=FRED_API_KEY).get_series("DFII10", observation_start="2003-01-01")
        return uv.to_monthly(s.dropna())
    except Exception as e:  # noqa: BLE001
        print(f"[warn] 取 DFII10 失败, 改用全程代理: {e}")
        return None


def forward_real_return(tr: pd.Series, months: int) -> pd.Series:
    """未来 N 个月实际总收益, 年化 (%)。"""
    return ((tr.shift(-months) / tr) ** (12.0 / months) - 1.0) * 100.0


def evaluate(df: pd.DataFrame, tips_m, params=uv.PARAMS) -> dict:
    h = uv.build_history(df, tips_m, params)
    tr = df["real_tr_price"].reindex(h.index)
    res = {"version": params["version"], "infl_years": params["infl_years"],
           "rate_mode": "splice_dfii10" if tips_m is not None else "proxy_only",
           "sample": f"{h['pct'].first_valid_index():%Y-%m} ~ {h.index[-1]:%Y-%m}", "horizons": {}}
    valid = h[h["tier"].notna()]
    for name, n in HORIZONS.items():
        fwd = forward_real_return(tr, n).reindex(valid.index)
        g = pd.DataFrame({"tier": valid["tier"], "fwd": fwd}).dropna()
        stats = {}
        for t in ORDER:
            x = g.loc[g["tier"] == t, "fwd"]
            stats[t] = {"months": int(len(x)),
                        "median": None if x.empty else round(float(x.median()), 2),
                        "mean": None if x.empty else round(float(x.mean()), 2),
                        "pct_negative": None if x.empty else round(float((x < 0).mean() * 100), 1)}
        med = [stats[t]["median"] for t in ORDER]
        stats["monotonic"] = bool(all(m is not None for m in med) and med[0] > med[1] > med[2])
        stats["last_month_with_outcome"] = g.index[-1].strftime("%Y-%m") if len(g) else None
        res["horizons"][name] = stats
    t = valid["tier"]
    switches = int((t != t.shift()).sum() - 1)
    years = len(t) / 12.0
    res["switches"] = switches
    res["switches_per_year"] = round(switches / years, 2)
    res["tier_share_pct"] = {k: round(float((t == k).mean() * 100), 1) for k in ORDER}
    res["H1_10y_monotonic"] = res["horizons"]["10y"]["monotonic"]
    res["H2_5y_monotonic"] = res["horizons"]["5y"]["monotonic"]
    res["H4_switch_ok"] = res["switches_per_year"] <= 1.0
    res["verdict"] = "keep_tier" if (res["H1_10y_monotonic"] and res["H4_switch_ok"]) else "value_only"
    last = h.dropna(subset=["pct"]).iloc[-1]
    res["last_month"] = {"month": h.index[-1].strftime("%Y-%m"), "erp": round(float(last["erp"]), 2),
                         "pct": round(float(last["pct"]), 1), "tier": last["tier"],
                         "real_rate": round(float(last["real_rate"]), 2), "rr_source": last["rr_source"]}
    return res


def _print(res: dict) -> None:
    print(f"\n== {res['version']} · {res['rate_mode']} · 通胀窗口 {res['infl_years']} 年 · 样本 {res['sample']} ==")
    print(f"{'期限':<5}{'档位':<10}{'月数':>6}{'中位%':>8}{'均值%':>8}{'亏损月%':>9}")
    for hz, st in res["horizons"].items():
        for t in ORDER:
            s = st[t]
            print(f"{hz:<5}{uv.TIER_CN[t]:<10}{s['months']:>6}{s['median']!s:>8}{s['mean']!s:>8}{s['pct_negative']!s:>9}")
        print(f"      单调: {st['monotonic']}")
    print(f"切换 {res['switches']} 次, 每年 {res['switches_per_year']} 次; 档位占比 {res['tier_share_pct']}")
    print(f"H1={res['H1_10y_monotonic']} H2={res['H2_5y_monotonic']} H4={res['H4_switch_ok']} → {res['verdict']}")
    print(f"最近月份: {res['last_month']}")


def main(argv):
    df = uv.load_monthly()
    tips = None if "--proxy" in argv else _dfii10_from_fred()
    out = {"primary": evaluate(df, tips)}
    out["sensitivity_infl5y"] = evaluate(df, tips, dict(uv.PARAMS, infl_years=5))  # 附录, 不用于改参
    for k in ("primary", "sensitivity_infl5y"):
        _print(out[k])
    os.makedirs(os.path.dirname(OUT_JSON), exist_ok=True)
    with open(OUT_JSON, "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, indent=2)
    print(f"\n写入 {OUT_JSON}")


if __name__ == "__main__":
    main(sys.argv[1:])
