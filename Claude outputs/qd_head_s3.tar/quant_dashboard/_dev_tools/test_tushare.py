import tushare as ts
import pandas as pd

# Tushare token: 从环境变量读取 (不再内置; 缺少时直接退出, 不回退到旧值)
import os
try:
    from dotenv import load_dotenv
    load_dotenv(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", ".env"))
except ImportError:
    pass
TOKEN = os.environ.get("TUSHARE_TOKEN", "").strip()
if not TOKEN:
    raise SystemExit("缺少环境变量 TUSHARE_TOKEN: 请在 .env 或系统环境变量中配置 (本脚本不再内置密钥)")
ts.set_token(TOKEN)
pro = ts.pro_api()

print("Testing moneyflow_hsgt...")
try:
    # 尝试最基础的调用
    df = pro.moneyflow_hsgt(start_date='20240101', end_date='20260321', limit=10)
    print("Result (HSGT):")
    if df is not None:
        print(df.head())
    else:
        print("DF is None")
except Exception as e:
    print(f"Error (HSGT): {e}")

print("\nTesting daily_basic...")
try:
    df = pro.daily_basic(ts_code='', trade_date='20250101', limit=5)
    print("Result (Daily Basic):")
    if df is not None:
        print(df.head())
    else:
        print("DF is None")
except Exception as e:
    print(f"Error (Daily Basic): {e}")
