"""提交前检查 (只读 git, 不暂存、不提交、不删除任何文件)。

用法 (在仓库内任意目录运行):
  python -B _dev_tools/commit_prep.py inventory --out <输出目录> [--bills <账单文件夹>]
      列出: 拟提交 / 应排除 (保留本地) / 应停止跟踪 (git rm --cached, 文件保留本地) / 需人工决定;
      对拟提交文件做敏感信息扫描 (只报文件、行号、类别, 不输出内容);
      写出 NUL 分隔清单 commit.nul / untrack.nul, 供 git --pathspec-from-file 使用。
  python -B _dev_tools/commit_prep.py verify --out <输出目录> [--bills <账单文件夹>]
      暂存后核对: 暂存区必须与清单完全一致; 对暂存内容再做一次敏感扫描。

真实标识符 (股东代码、成交编号、委托编号) 从 --bills 原始账单与本地真实台账中读取, 只在内存中用于比对,
不写入任何输出。输出目录应位于仓库之外。
"""
from __future__ import annotations

import argparse
import json
import os
import re
import subprocess
import sys
from typing import Iterable, Optional

# ───────────── 分类规则 (路径为仓库相对 posix 路径) ─────────────
BILL_NAME = re.compile(r"(历史成交|交割单|资金股份|成交查询|对账单|资金流水|持仓查询|当日成交|委托查询)")
ACCOUNT_FILES = {"portfolio_store.json", "trade_history.json", "trade_ledger.json", "account_ledger.json",
                 "alert_config.json", "lookthrough_extra_etfs.json"}   # 后者列出实际持有的 ETF
# 已跟踪、由代码生成并经接口展示的研究结果 (公开行情代理回测, 不含账户数据): 随代码一起提交
TRACKED_RESULTS = {"quant_dashboard/portfolio_backtest_results.json"}
SECRET_NAMES = re.compile(r"(^|/)(\.env(\..+)?|.*\.pem|.*\.key|id_rsa.*|credentials.*\.json)$", re.I)
DB_EXT = (".db", ".sqlite", ".sqlite3", ".db-wal", ".db-shm", ".db-journal")
DATA_EXT = (".parquet", ".jsonl", ".csv", ".xlsx", ".xls", ".pkl", ".pickle", ".feather", ".h5", ".npy", ".zip")
TEMP_PARTS = ("__pycache__", ".pytest_cache", ".ruff_cache", ".mypy_cache", "htmlcov", ".push-logs",
              ".worktrees", "node_modules", ".ipynb_checkpoints")
TEMP_EXT = (".pyc", ".pyo", ".tmp", ".plan_b_tmp", ".log", ".orig", ".rej", ".bak", ".swp")
CODE_EXT = (".py", ".js", ".cjs", ".mjs", ".ts", ".css", ".html", ".md", ".yml", ".yaml", ".toml", ".ini",
            ".cfg", ".bat", ".ps1", ".sh", ".svg")
CODE_NAMES = {".gitignore", ".gitattributes", "requirements.txt", "requirements-dev.txt", "pytest.ini",
              "setup.cfg", "pyproject.toml", "package.json", "package-lock.json", ".editorconfig", "Makefile",
              ".dockerignore"}
MAX_CODE_BYTES = 1_000_000


def classify(path: str) -> tuple[str, str]:
    """→ (类别, 原因)。类别: private / temp / data / code / review。"""
    parts = path.split("/")
    name = parts[-1]
    low = name.lower()
    if SECRET_NAMES.search(path) and not low.endswith(".example"):
        return "private", "密钥/环境变量文件"
    if BILL_NAME.search(name) and not low.endswith(CODE_EXT):
        return "private", "券商原始导出"
    if name in ACCOUNT_FILES:
        return "private", "真实台账/持仓/账户配置"
    if low.endswith(DB_EXT):
        return "private", "数据库文件"
    if any(p.lower() in ("alphacore_backups", "backup", "backups") for p in parts[:-1]) or \
            ("backup" in low and not low.endswith(CODE_EXT)):
        return "private", "备份"
    if ".legacy_" in low:
        return "temp", "旧版结果留档 (本地保留)"
    if path in TRACKED_RESULTS:
        return "code", "代码生成的研究结果 (随代码提交)"
    if low.endswith(".example.json"):
        return "code", "示例配置"
    if any(p in TEMP_PARTS for p in parts) or low.endswith(TEMP_EXT) or (parts[0] == "scratch"):
        return "temp", "缓存/临时产物"
    if "scratch" in parts:
        return "temp", "临时产物 (scratch)"
    if "data_lake" in parts or low.endswith(DATA_EXT):
        return "data", "数据缓存"
    if name in CODE_NAMES or low.endswith(CODE_EXT):
        return "code", ""
    if low.endswith(".json"):
        return "review", "JSON (配置还是数据需确认)"
    if low.endswith(".txt"):
        return "review", "文本文件 (可能是导出或日志)"
    return "review", "未识别类型"


# ───────────── git ─────────────
def git(*args: str, root: Optional[str] = None) -> bytes:
    return subprocess.run(["git", *args], cwd=root, capture_output=True, check=True).stdout


def repo_root() -> str:
    return git("rev-parse", "--show-toplevel").decode("utf-8").strip()


def status(root: str) -> list[tuple[str, str]]:
    """git status --porcelain -z -uall → [(XY, path)] (重命名拆为删除+新增, 保持简单)。"""
    raw = git("-c", "core.quotepath=false", "status", "--porcelain=v1", "-z", "-uall", "--no-renames", root=root)
    out = []
    for rec in raw.split(b"\0"):
        if not rec:
            continue
        s = rec.decode("utf-8", "surrogateescape")
        out.append((s[:2], s[3:]))
    return out


def tracked(root: str) -> list[str]:
    raw = git("-c", "core.quotepath=false", "ls-files", "-z", root=root)
    return [p.decode("utf-8", "surrogateescape") for p in raw.split(b"\0") if p]


# ───────────── 敏感扫描 ─────────────
PATTERNS = {
    "疑似股东代码": re.compile(r"(?<![0-9A-Za-z])(?:[AB]\d{9}|0\d{9})(?![0-9])"),
    "16-19位长数字 (银行卡/资金账号/成交编号)": re.compile(r"(?<!\d)\d{16,19}(?!\d)"),
    "疑似密钥赋值": re.compile(r"(?i)(?:token|api[_-]?key|secret|password|passwd)['\"]?\s*[:=]\s*['\"]?(?P<v>[A-Za-z0-9_\-]{16,})"),
    "疑似密钥调用字面量": re.compile(r"(?i)(?:set_token|pro_api|Bearer\s)\(?\s*['\"](?P<v>[A-Za-z0-9_\-]{16,})['\"]"),
    "40位十六进制 (Tushare token 或 git 哈希)": re.compile(r"(?<![0-9a-f])[0-9a-f]{40}(?![0-9a-f])"),
    "手机号": re.compile(r"(?<!\d)1[3-9]\d{9}(?!\d)"),
    "本机用户目录": re.compile(r"(?i)C:\\+Users\\+[^\\\s\"']+"),
    "Windows 绝对路径": re.compile(r"(?i)(?<![A-Za-z])[D-Z]:\\+[^\s\"'`|]+"),
}
# 明显虚构的股东代码 (测试用): A000000001 / 0000000002 / A123456789 等, 不算命中
# 明显的测试占位值 (测试用), 不算密钥命中
PLACEHOLDER_VALUE = re.compile(r"(?i)(test|placeholder|dummy|example|sample|fake|mock|your_|xxx|changeme|not-a-key)")
FAKE_ACCOUNT = re.compile(r"^(?:[AB]0{6,}\d{0,3}|0{7,}\d{0,3}|[AB]123456789)$")


class RealData:
    """真实标识符 + 真实成交 (代码, 数量, 价格) + 真实持仓 (代码, 数量); 只在内存中用于比对。"""

    def __init__(self, ids: set[str], trades: set[tuple[str, int, float]], holdings: set[tuple[str, int]]):
        self.ids, self.trades, self.holdings = ids, trades, holdings

    def __len__(self) -> int:
        return len(self.ids) + len(self.trades) + len(self.holdings)


def _code6(ts: str) -> str:
    return str(ts or "").split(".")[0]


def _real_data(root: str, bills: Optional[str]) -> "RealData":
    ids = _known_identifiers(root, bills)
    trades: set[tuple[str, int, float]] = set()
    holdings: set[tuple[str, int]] = set()
    app = os.path.join(root, "quant_dashboard")
    p = os.path.join(app, "data_lake", "trade_ledger.json")
    if os.path.exists(p):
        try:
            for t in json.load(open(p, encoding="utf-8")).get("trades", []):
                if t.get("qty") and t.get("price"):
                    trades.add((_code6(t.get("ts_code") or t.get("code")), int(t["qty"]), round(float(t["price"]), 4)))
        except Exception:                             # noqa: BLE001
            pass
    for rel in ("portfolio_store.json", os.path.join("data_lake", "portfolio_store.json")):
        p = os.path.join(app, rel)
        if os.path.exists(p):
            try:
                for code, pos in (json.load(open(p, encoding="utf-8")).get("positions") or {}).items():
                    amt = (pos or {}).get("amount") if isinstance(pos, dict) else pos
                    if amt and float(amt) >= 100:
                        holdings.add((_code6(code), int(float(amt))))
            except Exception:                         # noqa: BLE001
                pass
    return RealData(ids, trades, holdings)


NUM = re.compile(r"(?<![\d.])\d*\.?\d+(?![\d.])")
CODE6 = re.compile(r"(?<!\d)\d{6}(?!\d)")


def _real_values_hit(line: str, real: "RealData") -> list[str]:
    if not (real.trades or real.holdings):
        return []
    codes = set(CODE6.findall(line))
    if not codes:
        return []
    nums = set()
    for n in NUM.findall(line.replace(",", "")):
        try:
            nums.add(round(float(n), 4))
        except ValueError:
            pass
    out = []
    if any(c in codes and float(q) in nums and pr in nums for c, q, pr in real.trades):
        out.append("真实成交数值 (代码+数量+价格同行)")
    if any(c in codes and float(q) in nums for c, q in real.holdings):
        out.append("真实持仓数值 (代码+数量同行)")
    return out


def _known_identifiers(root: str, bills: Optional[str]) -> set[str]:
    """从原始账单与本地真实台账收集真实标识符 (只在内存中使用)。"""
    ids: set[str] = set()
    sys.path.insert(0, os.path.join(root, "quant_dashboard"))
    try:
        from services import trade_import as ti      # 复用券商文件解析
    except Exception:                                 # noqa: BLE001
        ti = None
    if bills and ti and os.path.isdir(bills):
        for n in os.listdir(bills):
            p = os.path.join(bills, n)
            if not os.path.isfile(p):
                continue
            try:
                res = ti.parse_trade_file(open(p, "rb").read(), n)
            except Exception:                         # noqa: BLE001  资金股份查询等不是成交文件
                continue
            for t in res.trades:
                ids.update(x for x in (t.trade_id, t.order_id, t.account) if x and len(x) >= 6)
    for rel in ("quant_dashboard/data_lake/trade_ledger.json",):
        p = os.path.join(root, rel)
        if os.path.exists(p):
            try:
                for t in json.load(open(p, encoding="utf-8")).get("trades", []):
                    ids.update(str(t.get(k)) for k in ("trade_id", "order_id", "account")
                               if t.get(k) and len(str(t.get(k))) >= 6)
            except Exception:                         # noqa: BLE001
                pass
    return ids


HARD_BLOCK = {"真实账单中的标识符 (精确匹配)", "疑似股东代码", "疑似密钥赋值", "疑似密钥调用字面量",
              "真实成交数值 (代码+数量+价格同行)", "真实持仓数值 (代码+数量同行)"}   # 暂存内容出现即不得提交
TOKEN = re.compile(r"[A-Za-z0-9]+")


def scan_text(text: str, real) -> dict[str, list[int]]:
    """real: RealData 或标识符集合。"""
    if not isinstance(real, RealData):
        real = RealData(set(real or ()), set(), set())
    hits: dict[str, list[int]] = {}
    for i, line in enumerate(text.splitlines(), 1):
        for name, rx in PATTERNS.items():
            if name in ("疑似密钥赋值", "疑似密钥调用字面量"):
                ms = [m.group("v") for m in rx.finditer(line) if not PLACEHOLDER_VALUE.search(m.group("v"))]
            else:
                ms = rx.findall(line)
            if name == "疑似股东代码":
                ms = [m for m in ms if not FAKE_ACCOUNT.match(m)]
            if ms:
                hits.setdefault(name, []).append(i)
        if real.ids and any(tok in real.ids for tok in TOKEN.findall(line)):
            hits.setdefault("真实账单中的标识符 (精确匹配)", []).append(i)
        for k in _real_values_hit(line, real):
            hits.setdefault(k, []).append(i)
    return hits


def scan_files(root: str, paths: Iterable[str], known) -> dict[str, dict[str, list[int]]]:
    out = {}
    for p in paths:
        fp = os.path.join(root, p)
        if not os.path.isfile(fp):
            continue
        try:
            text = open(fp, encoding="utf-8").read()
        except UnicodeDecodeError:
            try:
                text = open(fp, encoding="gbk").read()
            except UnicodeDecodeError:
                continue
        h = scan_text(text, known)
        if h:
            out[p] = {k: v[:20] for k, v in h.items()}
    return out


# ───────────── inventory / verify ─────────────
def _write_nul(path: str, items: list[str]) -> None:
    with open(path, "wb") as f:
        for it in items:
            f.write(it.encode("utf-8", "surrogateescape") + b"\0")


def inventory(out: str, bills: Optional[str]) -> dict:
    root = repo_root()
    os.makedirs(out, exist_ok=True)
    if os.path.abspath(out).startswith(os.path.abspath(root) + os.sep):
        raise SystemExit("输出目录必须在仓库之外")
    st = status(root)
    tr = set(tracked(root))
    plan = {"commit": [], "untrack": [], "exclude": [], "review": [], "tracked_data_unchanged": []}
    reasons: dict[str, str] = {}
    for xy, p in st:
        cat, why = classify(p)
        reasons[p] = why or cat
        is_tracked = p in tr
        if cat == "code":
            if os.path.isfile(os.path.join(root, p)) and os.path.getsize(os.path.join(root, p)) > MAX_CODE_BYTES:
                plan["review"].append(p)
                reasons[p] = "代码类但超过 1MB"
            else:
                plan["commit"].append(p)
        elif cat in ("private", "temp"):
            (plan["untrack"] if is_tracked else plan["exclude"]).append(p)
        elif cat == "data":
            plan["review" if is_tracked else "exclude"].append(p)
        else:
            plan["review"].append(p)
    # 未改动但已跟踪的私人/临时文件也应停止跟踪
    changed = {p for _, p in st}
    for p in sorted(tr - changed):
        cat, why = classify(p)
        if cat in ("private", "temp"):
            plan["untrack"].append(p)
            reasons[p] = why
        elif cat == "data":
            plan["tracked_data_unchanged"].append(p)
            reasons[p] = why
    known = _real_data(root, bills)
    sens = scan_files(root, plan["commit"] + plan["review"], known)
    status_of = {p: xy for xy, p in st}
    summary = {
        "repo_root": root,
        "head": git("rev-parse", "--short", "HEAD", root=root).decode().strip(),
        "counts": {k: len(v) for k, v in plan.items()},
        "real_data_loaded": {"identifiers": len(known.ids), "trades": len(known.trades), "holdings": len(known.holdings)},
        "lists": {k: [{"path": p, "git": status_of.get(p, "tracked-unchanged"), "reason": reasons.get(p, "")}
                      for p in v] for k, v in plan.items()},
        "sensitive_hits": sens,
    }
    with open(os.path.join(out, "inventory.json"), "w", encoding="utf-8") as f:
        json.dump(summary, f, ensure_ascii=False, indent=1)
    _write_nul(os.path.join(out, "commit.nul"), plan["commit"])
    _write_nul(os.path.join(out, "untrack.nul"), plan["untrack"])
    return summary


def verify(out: str, bills: Optional[str]) -> dict:
    root = repo_root()
    inv = json.load(open(os.path.join(out, "inventory.json"), encoding="utf-8"))
    want = {d["path"] for d in inv["lists"]["commit"]} | {d["path"] for d in inv["lists"]["untrack"]}
    raw = git("-c", "core.quotepath=false", "diff", "--cached", "--name-status", "-z", "--no-renames", root=root)
    parts = [x.decode("utf-8", "surrogateescape") for x in raw.split(b"\0") if x]
    staged = {}
    for i in range(0, len(parts) - 1, 2):
        staged[parts[i + 1]] = parts[i]
    untrack = {d["path"] for d in inv["lists"]["untrack"]}
    bad_untrack = [p for p in untrack if p in staged and staged[p] != "D"]
    still_on_disk = [p for p in untrack if not os.path.exists(os.path.join(root, p))
                     and next((d for d in inv["lists"]["untrack"] if d["path"] == p), {}).get("git") not in (" D", "D ")]
    known = _real_data(root, bills)
    added = git("-c", "core.quotepath=false", "diff", "--cached", "-U0", "--no-renames", root=root).decode("utf-8", "replace")
    cur, hits = None, {}
    for line in added.splitlines():
        if line.startswith("+++ b/"):
            cur = line[6:]
        elif line.startswith("+") and not line.startswith("+++") and cur:
            for k in scan_text(line[1:], known):
                hits.setdefault(cur, {}).setdefault(k, 0)
                hits[cur][k] += 1
    res = {"staged_count": len(staged), "planned_count": len(want),
           "unexpected_staged": sorted(set(staged) - want), "planned_not_staged": sorted(want - set(staged)),
           "untrack_not_as_delete": bad_untrack, "untracked_files_missing_locally": still_on_disk,
           "staged_by_status": {s: sum(1 for v in staged.values() if v == s) for s in sorted(set(staged.values()))},
           "sensitive_in_staged_additions": hits}
    blocking = {f: [k for k in h if k in HARD_BLOCK] for f, h in hits.items()}
    res["blocking_sensitive"] = {f: v for f, v in blocking.items() if v}
    res["ok"] = not (res["unexpected_staged"] or res["planned_not_staged"] or bad_untrack or res["blocking_sensitive"])
    return res


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("cmd", choices=("inventory", "verify"))
    ap.add_argument("--out", required=True)
    ap.add_argument("--bills")
    a = ap.parse_args(argv)
    if a.cmd == "inventory":
        s = inventory(a.out, a.bills)
        print(json.dumps({"head": s["head"], "counts": s["counts"],
                          "real_data_loaded": s["real_data_loaded"],
                          "files_with_sensitive_hits": len(s["sensitive_hits"])}, ensure_ascii=False, indent=1))
        print(f"完整清单: {os.path.join(a.out, 'inventory.json')} (只含路径、类别与行号)")
        return 0
    r = verify(a.out, a.bills)
    print(json.dumps(r, ensure_ascii=False, indent=1))
    return 0 if r["ok"] else 3


if __name__ == "__main__":
    sys.exit(main())
