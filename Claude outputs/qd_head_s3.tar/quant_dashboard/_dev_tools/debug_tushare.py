import tushare as ts
import pandas as pd

# Tushare token: 从环境变量读取 (不再内置; 缺少时直接退出, 不回退到旧值)
import os
try:
    from dotenv import load_dotenv
    load_dotenv(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", ".env"))
except ImportError:
    pass
TUSHARE_TOKEN = os.environ.get("TUSHARE_TOKEN", "").strip()
if not TUSHARE_TOKEN:
    raise SystemExit("缺少环境变量 TUSHARE_TOKEN: 请在 .env 或系统环境变量中配置 (本脚本不再内置密钥)")
ts.set_token(TUSHARE_TOKEN)
pro = ts.pro_api()

ts_code = "510300.SH"
start_date = "20230101"
end_date = "20240101"

print(f"Fetching fund_daily for {ts_code} from {start_date} to {end_date}...")
df = pro.fund_daily(ts_code=ts_code, start_date=start_date, end_date=end_date)
if df is not None and not df.empty:
    print(f"SUCCESS: Result count: {len(df)}")
    print(df.head())
else:
    print("DataFrame is empty.")
