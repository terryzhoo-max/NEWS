"""方案 B 真实数据副本验收: 备份 → 文件清单 → 独立副本试导入 → 重复导入 → 券商对账 → (通过后) 收益/穿透/复盘。

只读真实数据; 所有写入都在 --work 指定的独立副本目录 (默认 %TEMP%/alphacore_plan_b_acceptance/<时间>)。
原始账单、真实持仓 (portfolio_store.json)、真实成交/现金台账、数据库均不修改 (结束时用内容指纹自检)。

输出只含: 计数、匹配率、比例、状态与原因; 不输出账号、绝对金额、交易数量或价格。
文件名中 ≥9 位的连续数字 (可能为账号) 会被打码。

用法 (项目目录下):
  .\\.venv\\Scripts\\python.exe -B _dev_tools\\plan_b_reconcile.py --bills "<账单文件夹>" [--manifest <清单.json>]

清单 (可选, JSON): {"文件名": {"as_of": "YYYY-MM-DD", "valuation_time": "15:10",
                              "period_from": "YYYY-MM-DD", "period_to": "YYYY-MM-DD"}}
  · 资金股份查询类文件本身不含日期: as_of 取清单 > 文件名中的 YYYYMMDD > 未知 (未知则不作为历史快照)。
  · valuation_time 为账单估值时点; 未给则为未知 (整账户 TWR 不会标精确)。
  · period_from/period_to: 交割单/成交导出时在券商软件里选的查询区间 (可选)。未给时覆盖区间按文件内
    最早/最晚行日期计算; 给出后仅在副本中用于覆盖判断, 并在汇总中标为"用户声明"。

退出码: 0 = 对账通过并完成收益验收; 3 = 对账未通过或数据不足 (已停止收益验收); 2 = 真实文件被意外修改; 1 = 用法错误。
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
from datetime import date, datetime, timedelta
from typing import Any, Optional

APP_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if APP_ROOT not in sys.path:
    sys.path.insert(0, APP_ROOT)

REAL_JSON = ("trade_ledger.json", "account_ledger.json", "portfolio_store.json", "trade_history.json")
REAL_DB = ("alphacore.db", "analysis_decisions.db")
TEST_SOURCE_NAMES = {"h.txt", "bad.txt", "a.txt", "t.txt", "交割单_202610.txt", "历史成交.txt", "交割单.txt",
                     "交割单A.txt", "交割单B.txt"}
BILL_EXT = (".txt", ".csv", ".tsv", ".xls")


# ═══════════════════════ 基础 ═══════════════════════

def mask(name: str) -> str:
    return re.sub(r"\d{9,}", lambda m: m.group(0)[:2] + "***" + m.group(0)[-2:], name)


def sha256_file(path: str) -> Optional[str]:
    try:
        with open(path, "rb") as f:
            return hashlib.sha256(f.read()).hexdigest()
    except OSError:
        return None


def pct(a: float, b: float, d: int = 2) -> Optional[float]:
    return round(a / b * 100, d) if b else None


def real_paths(app_root: str) -> dict:
    dl = os.path.join(app_root, "data_lake")
    out = {n: os.path.join(dl, n) for n in REAL_JSON}
    out["alphacore.db"] = os.path.join(dl, "alphacore.db")
    out["services_alphacore.db"] = os.path.join(app_root, "services", "data_lake", "alphacore.db")
    out["analysis_decisions.db"] = os.path.join(dl, "analysis_decisions.db")
    return out


def digests(paths: dict) -> dict:
    return {k: sha256_file(p) for k, p in paths.items()}


def content_fingerprint(copy_dir: str) -> str:
    """副本台账的实质内容指纹: 成交、冲突、现金事件、更正、快照 (不含导入日志 imports / 来源登记时间)。"""
    from services import account_ledger as al
    from services import trade_import as ti
    tl = ti.load_ledger(os.path.join(copy_dir, "trade_ledger.json"))
    ap = os.path.join(copy_dir, "account_ledger.json")
    led = al.load(ap) if os.path.exists(ap) else {}
    snaps = [{k: v for k, v in s.items() if k != "recorded_at"} for s in led.get("snapshots", [])]
    body = {"trades": tl.get("trades", []), "conflicts": [{k: v for k, v in c.items() if k != "at"}
                                                         for c in tl.get("conflicts", [])],
            "events": led.get("events", []), "corrections": [{k: v for k, v in c.items() if k != "at"}
                                                             for c in led.get("corrections", [])],
            "snapshots": snaps}
    return hashlib.sha256(json.dumps(body, sort_keys=True, ensure_ascii=False, default=str).encode()).hexdigest()


# ═══════════════════════ 1. 备份与代码状态 ═══════════════════════

def backup(app_root: str, out_dir: str) -> dict:
    import sqlite3
    os.makedirs(out_dir, exist_ok=True)
    rows = []
    for key, src in real_paths(app_root).items():
        if not os.path.exists(src):
            rows.append({"file": key, "status": "absent"})
            continue
        dst = os.path.join(out_dir, key)
        if key.endswith(".db"):
            s = sqlite3.connect(f"file:{src}?mode=ro", uri=True)
            d = sqlite3.connect(dst)
            try:
                s.backup(d)
                integrity = d.execute("PRAGMA integrity_check").fetchone()[0]
            finally:
                d.close()
                s.close()
        else:
            shutil.copy2(src, dst)
            integrity = "copied"
        rows.append({"file": key, "status": "ok", "integrity": integrity, "sha256": sha256_file(dst)[:12]})
    with open(os.path.join(out_dir, "backup_manifest.json"), "w", encoding="utf-8") as f:
        json.dump({"created_at": datetime.now().isoformat(timespec="seconds"), "files": rows}, f,
                  ensure_ascii=False, indent=1)
    return {"dir": out_dir, "files": rows}


def code_state(app_root: str) -> dict:
    def git(*args):
        try:
            return subprocess.run(["git", *args], cwd=app_root, capture_output=True, text=True,
                                  timeout=20, encoding="utf-8", errors="replace").stdout.strip()
        except Exception:  # noqa: BLE001
            return None
    head = git("rev-parse", "--short", "HEAD")
    status = git("status", "--porcelain")
    changed = [ln[3:] for ln in (status or "").splitlines() if ln.strip()]
    return {"git_head": head or "不可用", "uncommitted_count": len(changed) if status is not None else None,
            "uncommitted_files": changed[:200]}


# ═══════════════════════ 2. 文件清单 ═══════════════════════

def classify(raw: bytes, name: str) -> tuple[str, Any]:
    from services.trade_import import TradeImportError, decode_broker_bytes, parse_trade_text
    try:
        text, _enc = decode_broker_bytes(raw)
    except TradeImportError as e:
        return "unreadable", str(e)
    head = "\n".join(text.splitlines()[:3])
    if "余额" in head and "资产" in head and "证券代码" in text:
        return "holdings_statement", text
    try:
        res = parse_trade_text(text, source=name)
    except TradeImportError as e:
        return "unrecognized", e.code
    return ("settlement_statement" if res.has_net_amount else "trade_history"), res


def inventory(folder: str, manifest: dict) -> list[dict]:
    from engines.portfolio_engine import PortfolioEngine
    out = []
    for name in sorted(os.listdir(folder)):
        p = os.path.join(folder, name)
        if not os.path.isfile(p) or not name.lower().endswith(BILL_EXT):
            continue
        raw = open(p, "rb").read()
        kind, parsed = classify(raw, name)
        meta = manifest.get(name) or {}
        row = {"file": name, "display_name": mask(name), "path": p, "size": len(raw),
               "mtime": datetime.fromtimestamp(os.path.getmtime(p)).isoformat(timespec="seconds"),
               "sha256": hashlib.sha256(raw).hexdigest(), "type": kind,
               "raw_lines": sum(1 for ln in raw.splitlines() if ln.strip())}
        if kind in ("trade_history", "settlement_statement"):
            s = parsed.summary()
            row.update(date_from=s["date_from"], date_to=s["date_to"], parsed_trades=s["parsed"],
                       cash_rows=s["cash_rows"], skipped=s["skipped"], errors=s["error_count"],
                       has_net_amount=s["has_net_amount"])
        elif kind == "holdings_statement":
            try:
                d, basis = PortfolioEngine.resolve_statement_date(meta.get("as_of"), name)
            except ValueError:
                d, basis = None, "invalid_manifest_date"
            row.update(statement_date=d, date_basis=basis, valuation_time=meta.get("valuation_time"))
        else:
            row.update(detail=str(parsed)[:120])
        out.append(row)
    return out


# ═══════════════════════ 3. 副本试导入 ═══════════════════════

def _parse_statement(text: str, name: str, meta: dict) -> dict:
    from engines.portfolio_engine import PortfolioEngine
    eng = object.__new__(PortfolioEngine)
    eng.holdings, eng.trade_history = {"cash": 0, "positions": {}}, []
    return eng.import_from_txt(text, as_of=meta.get("as_of"), valuation_time=meta.get("valuation_time"),
                               source_name=name, persist=False)


def import_round(files: list[dict], work: str, manifest: dict) -> list[dict]:
    from services import account_ledger as al
    from services import trade_import as ti
    tpath = os.path.join(work, "trade_ledger.json")
    apath = al.ledger_path_for(tpath)
    results = []
    order = sorted(files, key=lambda f: (f.get("date_from") or f.get("statement_date") or "9999", f["file"]))
    for f in order:
        raw = open(f["path"], "rb").read()
        r = {"file": f["display_name"], "type": f["type"]}
        if f["type"] in ("trade_history", "settlement_statement"):
            s = ti.import_trade_file(raw, f["file"], path=tpath)
            acc = s.get("account_ledger") or {}
            r.update(parsed=s["parsed"], added=s["added"], duplicates=s["duplicates"], enriched=s.get("enriched", 0),
                     conflicts=s.get("conflicts", 0), possible_duplicates=s.get("possible_duplicates", 0), errors=s["error_count"], skipped=s["skipped"],
                     cash_events_added=acc.get("events_added"), cash_events_duplicate=acc.get("events_duplicate"),
                     cash_events_enriched=acc.get("events_enriched"), cash_issues=acc.get("issue_count"),
                     cash_conflicts=sum(1 for i in acc.get("issues", []) if "冲突" in i))
            meta = manifest.get(f["file"]) or {}
            if meta.get("period_from") and meta.get("period_to"):
                _declare_period(tpath, apath, f["sha256"], f["file"], meta["period_from"], meta["period_to"])
                r["coverage_basis"] = "用户声明的导出区间"
        elif f["type"] == "holdings_statement":
            p = _parse_statement(ti.decode_broker_bytes(raw)[0], f["file"], manifest.get(f["file"]) or {})
            r.update(parsed_positions=len(p.get("parsed_positions") or {}), errors=len(p.get("errors") or []),
                     statement_date=p.get("statement_date"), warnings=p.get("warnings"))
            if p.get("success") and p.get("statement_date"):
                before = len(al.load(apath)["snapshots"]) if os.path.exists(apath) else 0
                al.record_balance_snapshot(p["statement_date"], p["cash"], p["total_asset"] or None,
                                           source=f"资金股份查询 {f['display_name']}", path=apath,
                                           valuation_time=p.get("valuation_time"), date_basis=p["date_basis"],
                                           positions=p["parsed_positions"], source_sha256=f["sha256"])
                after = len(al.load(apath)["snapshots"])
                r.update(snapshot_added=after - before,
                         statement_internal_diff_pct=pct(abs(p["total_asset"] - p["cash"]
                                                             - (p.get("broker_ref_market_value") or 0)),
                                                         p["total_asset"]) if p.get("total_asset") else None)
        else:
            r.update(skipped_reason=f.get("detail") or f["type"])
        results.append(r)
    return results


def _declare_period(tpath: str, apath: str, sha: str, name: str, lo: str, hi: str) -> None:
    """仅在副本中: 用用户声明的导出区间替代"首末行日期"作为覆盖区间 (标注来源)。"""
    from services import account_ledger as al
    from services import trade_import as ti
    led = al.load(apath)
    for s in led.get("sources", []):
        if s.get("sha256") == sha:
            s.update(date_from=lo, date_to=hi, coverage_basis="declared")
    al.save(led, apath)
    tl = ti.load_ledger(tpath)
    for i in tl.get("imports", []):
        if i.get("file") == name:
            i.update(date_from=lo, date_to=hi, coverage_basis="declared")
    ti.save_ledger(tl, tpath)


# ═══════════════════════ 4. 费用补全统计 ═══════════════════════

def fee_backfill(before: list[dict], after: list[dict], files: list[dict], held_existing: set = frozenset()) -> dict:
    missing = [t for t in before if t.get("fees") is None]
    after_by_key = {t["key"]: t for t in after}
    loose = {}
    for t in after:
        if t.get("fees") is not None:
            loose.setdefault((t["date"], t["ts_code"], t["side"], int(t["qty"]), round(float(t["price"]), 4)), []).append(t)
    spans = [(f["date_from"], f["date_to"]) for f in files
             if f["type"] == "settlement_statement" and f.get("date_from")]
    filled = still = key_mismatch = not_covered = covered_no_row = held = 0
    for t in missing:
        a = after_by_key.get(t["key"])
        if a is not None and a.get("fees") is not None:
            filled += 1
            continue
        still += 1
        if t["key"] in held_existing:
            held += 1
        elif any(lo <= t["date"] <= hi for lo, hi in spans):
            if loose.get((t["date"], t["ts_code"], t["side"], int(t["qty"]), round(float(t["price"]), 4))):
                key_mismatch += 1
            else:
                covered_no_row += 1
        else:
            not_covered += 1
    return {"originally_missing": len(missing), "filled": filled, "still_missing": still,
            "reasons": {"交割单未覆盖该日期": not_covered,
                        "交割单已覆盖但无同笔记录": covered_no_row,
                        "疑似同笔但成交编号不同 (key 不一致, 未自动合并)": key_mismatch,
                        "疑似同笔已登记待确认 (possible_duplicate)": held}}


# ═══════════════════════ 5. 券商对账 ═══════════════════════

def _coverage_spans(ledger: dict, cash_ledger: Optional[dict] = None) -> list[tuple[str, str]]:
    """成交覆盖区间 = 成交台账各次导入的成交日期范围 ∪ 现金台账各来源文件的行日期范围 (含资金行)。"""
    spans = [(i["date_from"], i["date_to"]) for i in ledger.get("imports", []) if i.get("date_from") and i.get("date_to")]
    spans += [(s["date_from"], s["date_to"]) for s in (cash_ledger or {}).get("sources", [])
              if s.get("date_from") and s.get("date_to")]
    return sorted(spans)


def _covered(spans, lo: str, hi: str) -> bool:
    from datetime import date, timedelta
    need = date.fromisoformat(lo) + timedelta(days=1)
    end = date.fromisoformat(hi)
    for a, b in spans:
        a, b = date.fromisoformat(a), date.fromisoformat(b)
        if a > need:
            # 周末/节假日的空档不视为缺口: 只要缺口内没有工作日即可
            gap = [need + timedelta(days=k) for k in range((a - need).days)]
            if any(g.weekday() < 5 for g in gap):
                return False
        if b >= need:
            need = b + timedelta(days=1)
        if need > end:
            return True
    return need > end


def holdings_at(anchor_positions: dict, anchor_date: str, target_date: str, trades: list[dict]) -> dict:
    """以锚点持仓按成交回滚/前滚到目标日收盘。"""
    q = {c: float(v) for c, v in anchor_positions.items()}
    for t in trades:
        d = t["date"]
        s = int(t["qty"]) * (1 if t.get("side") == "buy" else -1)
        if target_date < d <= anchor_date:          # 回滚
            q[t["ts_code"]] = q.get(t["ts_code"], 0.0) - s
        elif anchor_date < d <= target_date:        # 前滚
            q[t["ts_code"]] = q.get(t["ts_code"], 0.0) + s
    return {c: v for c, v in q.items() if abs(v) > 1e-9}


def compare_positions(expected: dict, actual: dict) -> dict:
    codes = sorted(set(expected) | set(actual))
    rows = []
    for c in codes:
        e, a = expected.get(c, 0.0), actual.get(c, 0.0)
        if abs(e - a) < 0.5:
            continue
        if a == 0:
            kind = "推算应持有但账单无"
        elif e == 0:
            kind = "账单持有但推算无"
        else:
            r = a / e if e else None
            kind = (f"数量不一致 (账单/推算 = {r:.3g}, 疑似送转或拆分)" if r and abs(r - round(r)) < 1e-6 and r > 1
                    else "数量不一致")
        rows.append({"ts_code": c, "status": kind})
    matched = len(codes) - len(rows)
    return {"codes": len(codes), "matched": matched, "match_rate_pct": pct(matched, len(codes)), "differences": rows}


def reconcile(work: str, app_root: str) -> dict:
    from services import account_ledger as al
    from services import trade_import as ti
    tl = ti.load_ledger(os.path.join(work, "trade_ledger.json"))
    led = al.load(os.path.join(work, "account_ledger.json"))
    trades = tl.get("trades", [])
    snaps = sorted([s for s in led.get("snapshots", []) if s.get("positions") is not None and s.get("as_of")],
                   key=lambda s: s["as_of"])
    out: dict[str, Any] = {"statements_with_positions": len(snaps)}
    if len(snaps) < 2:
        out["status"] = "insufficient_statements"
        out["note"] = "需要至少两个带日期与逐只持仓的资金股份查询快照 (期初/期末) 才能对账"
        return out
    s0, s1 = snaps[0], snaps[-1]
    out["period"] = {"from": s0["as_of"], "to": s1["as_of"],
                     "valuation_timing": [s0.get("valuation_timing"), s1.get("valuation_timing")]}
    spans = _coverage_spans(tl, led)
    trades_covered = _covered(spans, s0["as_of"], s1["as_of"])
    out["trade_coverage"] = "covered" if trades_covered else "insufficient"
    # 期初: 期末账单持仓按成交回滚到期初, 与期初账单比较
    exp0 = holdings_at(s1["positions"], s1["as_of"], s0["as_of"], trades)
    out["opening_positions"] = compare_positions(exp0, s0["positions"])
    # 期末: 以当前持仓文件为锚 (若其日期不早于期末账单) 回滚到期末, 与期末账单比较
    store = json.load(open(os.path.join(app_root, "data_lake", "portfolio_store.json"), encoding="utf-8"))
    sdate = str(store.get("import_date") or "")
    if sdate >= s1["as_of"]:
        cur = {c: float(p.get("amount") or 0) for c, p in (store.get("positions") or {}).items()}
        exp1 = holdings_at(cur, sdate, s1["as_of"], trades)
        out["closing_positions"] = compare_positions(exp1, s1["positions"])
        out["closing_positions"]["anchor"] = f"当前持仓文件 ({sdate})"
        out["closing_positions"]["trade_coverage"] = ("covered" if _covered(spans, s1["as_of"], sdate) or sdate == s1["as_of"]
                                                      else "insufficient")
    else:
        out["closing_positions"] = {"status": "no_independent_anchor",
                                    "note": f"当前持仓文件日期 {sdate or '未知'} 早于期末账单, 无独立锚点核对期末"}
    rc = al.reconcile_cash(led, s0, s1)
    avg_assets = ((s0.get("total_asset") or 0) + (s1.get("total_asset") or 0)) / 2
    out["cash"] = {"status": rc["status"], "coverage": rc["cash_coverage"], "unclassified_rows": rc["unclassified_count"],
                   "difference_pct_of_avg_total_asset": pct(abs(rc["difference"]), avg_assets),
                   "note": rc["note"]}
    summ = rc["summary"]
    period_trades = [t for t in trades if s0["as_of"] < t["date"] <= s1["as_of"]]
    out["fees_dividends"] = {
        "period_trades": len(period_trades),
        "trades_with_known_fees_pct": pct(sum(t.get("fees") is not None for t in period_trades), len(period_trades)),
        "fee_and_tax_events": sum(1 for e in al.effective_events(led)
                                  if e["type"] in ("fee", "tax") and s0["as_of"] < (e.get("date") or "") <= s1["as_of"]),
        "dividend_events": sum(1 for e in al.effective_events(led)
                               if e["type"] == "dividend" and s0["as_of"] < (e.get("date") or "") <= s1["as_of"]),
        "dividends_pct_of_avg_total_asset": pct(abs(summ["by_type"].get("dividend", 0.0)), avg_assets, 3),
        "costs_pct_of_avg_total_asset": pct(abs(summ["costs"]), avg_assets, 3),
        "settlement_estimated_count": summ["settlement_estimated_count"],
    }
    out["total_asset"] = {
        "opening_total_asset_change_pct": None if not s0.get("total_asset") else
        pct((s1.get("total_asset") or 0) - s0["total_asset"], s0["total_asset"]),
        "note": "账单内部一致性 (总资产 vs 现金 + 参考市值) 见各快照的 statement_internal_diff_pct"}
    return out


def gate(trial: list[dict], repeat_ok: bool, rec: dict, fees: dict, resolved: int = 0) -> tuple[bool, list[str]]:
    reasons = []
    if not repeat_ok:
        reasons.append("重复导入后副本台账发生变化 (幂等性失败)")
    conflicts = sum((r.get("conflicts") or 0) + (r.get("cash_conflicts") or 0) for r in trial) - resolved   # 用户已确认的不再计
    if conflicts:
        reasons.append(f"存在 {conflicts} 处成交/现金信息冲突")
    if rec.get("status") == "insufficient_statements":
        reasons.append(rec["note"])
    else:
        if rec.get("trade_coverage") != "covered":
            reasons.append("期初至期末之间成交台账覆盖不连续")
        op = rec.get("opening_positions") or {}
        if op.get("differences"):
            reasons.append(f"期初逐只持仓有 {len(op['differences'])} 只不一致")
        cp = rec.get("closing_positions") or {}
        if cp.get("differences"):
            reasons.append(f"期末逐只持仓有 {len(cp['differences'])} 只不一致")
        if cp.get("status") == "no_independent_anchor":
            reasons.append("期末持仓缺少独立锚点核对")
        cash = rec.get("cash") or {}
        if cash.get("status") != "reconciled":
            reasons.append(f"现金未对平 ({cash.get('status')})")
    if fees.get("still_missing"):
        reasons.append(f"仍有 {fees['still_missing']} 笔成交费用缺失")
    return (not reasons), reasons


# ═══════════════════════ 6. 收益/穿透/复盘 (仅在对账通过后) ═══════════════════════

def metrics(work: str, app_root: str, rec: dict) -> dict:
    from services import account_ledger as al
    from services import decision_review as dr
    from services import return_basis as rb
    from services import trade_import as ti
    led = al.load(os.path.join(work, "account_ledger.json"))
    acc = rb.account_returns(led, rec["period"]["from"], rec["period"]["to"])
    out = {"account": {k: acc.get(k) for k in ("status", "twr", "twr_method", "twr_range", "twr_note",
                                               "mwr_annualized", "from", "to")}}
    store = json.load(open(os.path.join(app_root, "data_lake", "portfolio_store.json"), encoding="utf-8"))
    try:
        from services.concentration import compute_from_store
        c = compute_from_store(store)
        lv = c.get("lookthrough") or {}
        out["lookthrough"] = {"known_pct_of_invested": lv.get("known_pct_of_invested"),
                              "unknown_pct_of_invested": (lv.get("unknown") or {}).get("pct_of_invested"),
                              "top_theme": c.get("top_theme"), "top_pct": c.get("top_pct"), "level": c.get("level")}
    except Exception as e:  # noqa: BLE001
        out["lookthrough"] = {"status": "unavailable", "error": str(e)[:120]}
    try:
        trades = ti.load_ledger(os.path.join(work, "trade_ledger.json")).get("trades", [])
        r = dr.portfolio_comparison(rec["period"]["from"], rec["period"]["to"],
                                    end_holdings={c: float(p.get("amount") or 0) for c, p in store["positions"].items()},
                                    snapshot_date=store.get("import_date"), trades=trades, loader=dr._default_loader())
        out["review"] = {"status": r.get("status"), "reason": r.get("reason"), "trading_days": r.get("trading_days"),
                         "paths": [(p["label"], p["return"]) for p in r.get("paths", [])],
                         "value_added_vs_hold_pct": r.get("value_added_vs_hold_pct"), "caveats": r.get("caveats")}
    except Exception as e:  # noqa: BLE001
        out["review"] = {"status": "unavailable", "error": str(e)[:120]}
    return out


# ═══════════════════════ 7. 污染痕迹 ═══════════════════════

def contamination(app_root: str, bill_hashes: set) -> dict:
    from services import account_ledger as al
    p = os.path.join(app_root, "data_lake", "account_ledger.json")
    if not os.path.exists(p):
        return {"status": "absent"}
    led = al.load(p)
    sus = [s for s in led.get("sources", []) if s.get("file") in TEST_SOURCE_NAMES and s.get("sha256") not in bill_hashes]
    names = {s["file"] for s in sus}
    ev = [e for e in led.get("events", []) if e.get("source_file") in names]
    return {"suspected_test_sources": sorted(names), "suspected_test_events": len(ev),
            "note": "真实现金台账中来源文件名与测试用例一致、且不在本次账单中的记录; 未自动删除, 由用户决定"}


# ═══════════════════════ 8. 核实清单 (期初来源 / 新股 / 测试记录) ═══════════════════════

def store_provenance(app_root: str, trades: list[dict], statement: Optional[dict]) -> dict:
    """当前持仓文件的来源核实。只作"未确认锚点"参考, 不作为期初快照。"""
    sp = os.path.join(app_root, "data_lake", "portfolio_store.json")
    hp = os.path.join(app_root, "data_lake", "trade_history.json")
    if not os.path.exists(sp):
        return {"status": "absent"}
    store = json.load(open(sp, encoding="utf-8"))
    mtime = datetime.fromtimestamp(os.path.getmtime(sp))
    imports = []
    if os.path.exists(hp):
        try:
            imports = [h for h in json.load(open(hp, encoding="utf-8")) if h.get("action") == "import"]
        except (ValueError, OSError):
            imports = []
    last = imports[-1]["timestamp"] if imports else None
    gap_min = None
    if last:
        try:
            gap_min = round((mtime - datetime.strptime(last, "%Y-%m-%d %H:%M:%S")).total_seconds() / 60, 1)
        except ValueError:
            gap_min = None
    out = {"import_date": store.get("import_date"),
           "date_basis": store.get("statement_date_basis") or "旧版导入: import_date 为导入当天, 非券商导出日期",
           "valuation_time": store.get("valuation_time"),
           "file_modified_at": mtime.isoformat(timespec="seconds"), "last_import_record_at": last,
           "minutes_between_import_and_last_modify": gap_min,
           "modified_after_import": None if gap_min is None else abs(gap_min) > 2,
           "positions": len(store.get("positions") or {}),
           "confirmed_as_opening": False,
           "note": "未经用户确认来源与导出时点, 不作为期初快照; 下方比较仅供参考"}
    if statement and statement.get("positions") is not None and store.get("import_date"):
        cur = {c: float(p.get("amount") or 0) for c, p in (store.get("positions") or {}).items()}
        exp = holdings_at(cur, store["import_date"], statement["as_of"], trades)
        cmp_ = compare_positions(exp, statement["positions"])
        out["reference_comparison_to_statement"] = {**cmp_, "basis": "未确认锚点 (仅参考, 不参与验收判定)"}
    return out


def _related_ipo_codes(parsed: list) -> set:
    codes = set()
    for res in parsed:
        for t in res.trades:
            if t.kind == "ipo":
                codes.add(t.ts_code)
        for r in res.ipo_credit_rows:
            codes.add(r["ts_code"])
    return {c for c in codes if c}


def apply_confirmations(copy_dir: str, files: list[dict], decisions: dict) -> dict:
    """仅在副本中执行用户已确认的决定: same_allotment = 确认为同一次中签的证券代码列表。"""
    from services import trade_import as ti
    codes = set(decisions.get("same_allotment") or [])
    out: dict[str, Any] = {"resolved": 0, "items": []}
    if not codes:
        return out
    tp = os.path.join(copy_dir, "trade_ledger.json")
    tl = ti.load_ledger(tp)
    by_key = {t["key"]: t for t in tl.get("trades", [])}
    sources = {f["file"]: open(f["path"], "rb").read() for f in files
               if f["type"] in ("trade_history", "settlement_statement")}
    pend = {c["existing"] for c in tl.get("conflicts", []) if c.get("field") == "possible_duplicate"
            and not c.get("resolution") and (by_key.get(c["existing"]) or {}).get("ts_code") in codes}
    for k in sorted(pend):
        r = ti.confirm_possible_duplicate_same(k, "用户确认为同一次中签 (缴款与申购记录描述同一笔)", sources, path=tp)
        out["resolved"] += r["resolved"]
        out["items"].append({"ts_code": by_key[k]["ts_code"], "date": by_key[k]["date"], "resolved": r["resolved"],
                             "enriched_fields": r["enriched_fields"], "cash_enriched": r["cash_enriched"],
                             "missing_sources": [mask(s) for s in r["missing_sources"]]})
    already = {(by_key.get(c["existing"]) or {}).get("ts_code") for c in tl.get("conflicts", [])
               if c.get("field") == "possible_duplicate" and (c.get("resolution") or {}).get("decision") == "same"}
    out["already_confirmed"] = sorted(codes & already - {by_key[k]["ts_code"] for k in pend})
    out["not_found"] = sorted(codes - already - {by_key[k]["ts_code"] for k in pend})
    return out


def _expected_qty_delta(r: dict, prev: float) -> tuple[Optional[float], str]:
    """该行对"剩余数量"的预期影响。新股缴款/入账两行中只有一行带来股份 (券商口径不一) → 允许 0 或 +数量。"""
    q = abs(r.get("qty") or 0.0)
    if r["category"] in ("trade", "etf_creation", "etf_redemption"):
        return (q if r["side"] == "buy" else -q), "strict"
    if r["category"] in ("ipo", "ipo_credit"):
        return None, "ipo"
    return 0.0, "strict"


def running_balance(files: list[dict], copy_dir: str, statement: Optional[dict]) -> dict:
    """交割单逐笔余额对账: 用券商给出的每行"剩余数量/剩余金额"
    ① 检查券商数据自身连续 (上一行结余 + 本行变动 = 本行结余);
    ② 反推期初 (第一行结余 - 第一行变动), 期间无记录的证券推定不变 (依赖交割单完整);
    ③ 与副本台账推算的期初/期末 (由 10-29 账单按台账成交回滚) 及账单期末逐只比较。
    只输出计数、一致性与差异占总资产比例, 不输出数量与金额。"""
    from services import account_ledger as al
    from services import trade_import as ti
    out: dict[str, Any] = {"status": "unavailable"}
    rows, used = [], []
    for f in files:
        if f["type"] != "settlement_statement":
            continue
        res = ti.parse_trade_file(open(f["path"], "rb").read(), f["file"])
        if res.has_balances and res.balance_rows:
            br = list(res.balance_rows)
            if br[0]["date"] > br[-1]["date"]:          # 倒序导出 → 按时间正序
                br.reverse()
            rows.extend(br)
            used.append(f["display_name"])
    if not rows:
        out["note"] = "交割单无剩余数量/剩余金额列"
        return out
    if len(used) > 1:
        out.update(status="multiple_files", files=used, note="多份交割单的逐笔余额暂不拼接, 请只保留一份覆盖完整区间的交割单")
        return out
    first, last = rows[0]["date"], rows[-1]["date"]
    out.update(status="ok", file=used[0], rows=len(rows), period={"from": first, "to": last})

    # ① 现金连续性
    prev_cash, cash_checked, cash_breaks, opening_cash, closing_cash = None, 0, [], None, None
    for r in rows:
        rc = r.get("remaining_cash")
        if rc is None:
            continue
        net = r.get("net_amount") or 0.0
        if prev_cash is None:
            opening_cash = rc - net
        else:
            cash_checked += 1
            if abs(prev_cash + net - rc) > 0.011:
                cash_breaks.append({"date": r["date"], "business": r["raw_side"]})
        prev_cash = closing_cash = rc
    # ① 数量连续性 (逆回购不是持仓, 不参与)
    prev_q: dict[str, float] = {}
    opening_q: dict[str, float] = {}
    qty_checked, qty_breaks, ipo_rows = 0, [], 0
    cash_row_qty = {"rows": 0, "differs_from_share_balance": 0}
    for r in rows:
        c, rq = r.get("ts_code"), r.get("remaining_qty")
        if not c or rq is None or r["category"] == "repo":
            continue
        if r["category"] == "cash":
            # 红利/扣税/利息等资金行不改变股数; 券商在这类行的"剩余数量"口径不一 (实测出现非持股余额),
            # 不作为股数结余, 也不用来反推期初; 只计数备查
            cash_row_qty["rows"] += 1
            if c in prev_q and abs(rq - prev_q[c]) >= 0.5:
                cash_row_qty["differs_from_share_balance"] += 1
            continue
        exp, mode = _expected_qty_delta(r, prev_q.get(c, 0.0))
        if c not in prev_q:
            if mode == "ipo":
                q = abs(r.get("qty") or 0.0)
                opening_q[c] = rq - (q if rq >= q else 0.0)
            else:
                opening_q[c] = rq - exp
        else:
            qty_checked += 1
            delta = rq - prev_q[c]
            if mode == "ipo":
                ipo_rows += 1
                if not (abs(delta) < 0.5 or abs(delta - abs(r.get("qty") or 0.0)) < 0.5):
                    qty_breaks.append({"date": r["date"], "ts_code": c, "business": r["raw_side"]})
            elif abs(delta - exp) >= 0.5:
                qty_breaks.append({"date": r["date"], "ts_code": c, "business": r["raw_side"]})
        prev_q[c] = rq
    closing_q = dict(prev_q)
    out["cash_chain"] = {"checked": cash_checked, "breaks": len(cash_breaks), "break_rows": cash_breaks[:20]}
    out["qty_chain"] = {"codes": len(prev_q), "checked": qty_checked, "breaks": len(qty_breaks),
                        "break_rows": qty_breaks[:20], "ipo_rows_either_mode": ipo_rows,
                        "cash_rows_not_used_for_shares": cash_row_qty}
    if not statement or statement.get("positions") is None:
        out["note"] = "无带逐只持仓的账单快照, 只完成券商数据自身连续性检查"
        return out

    stmt_pos = {c: float(v) for c, v in statement["positions"].items()}
    tot = statement.get("total_asset") or 0
    # ② 券商口径期初/期末: 交割单出现过的证券取逐笔结余; 只在账单中出现的证券期间无记录 → 推定不变
    untouched = [c for c in stmt_pos if c not in prev_q]
    broker_open = {c: v for c, v in opening_q.items() if abs(v) > 1e-9} | {c: stmt_pos[c] for c in untouched}
    broker_close = {c: v for c, v in closing_q.items() if abs(v) > 1e-9} | {c: stmt_pos[c] for c in untouched}
    # ③ 台账口径: 以账单为锚, 按副本台账成交回滚到交割单首日之前
    tl = ti.load_ledger(os.path.join(copy_dir, "trade_ledger.json"))
    day_before = (date.fromisoformat(first) - timedelta(days=1)).isoformat()
    ledger_open = holdings_at(stmt_pos, statement["as_of"], day_before, tl.get("trades", []))
    out["opening_positions"] = compare_positions(ledger_open, broker_open) | {
        "basis": "券商交割单逐笔剩余数量反推; 期间无记录的证券推定不变",
        "presumed_unchanged_codes": len(untouched)}
    out["closing_positions"] = compare_positions(broker_close, stmt_pos) | {
        "basis": f"交割单最后结余 ({last}) vs 账单 ({statement['as_of']})"}
    # 现金: 台账推算期初现金 = 账单现金 - 期间 (交割单首日..账单日) 台账现金变动
    led = al.load(os.path.join(copy_dir, "account_ledger.json"))
    eff = [e for e in al.effective_events(led) if e.get("date") and first <= e["date"] <= statement["as_of"]]
    ledger_change = sum(float(e.get("amount") or 0) for e in eff)
    after_last = sum(float(e.get("amount") or 0) for e in eff if e["date"] > last)
    est = sum(1 for e in eff if e.get("cash_estimated"))
    if opening_cash is not None:
        d_open = statement["cash"] - ledger_change - opening_cash
        d_close = closing_cash + after_last - statement["cash"]
        out["cash"] = {"opening_diff_pct_of_total": pct(abs(d_open), tot, 3), "opening_match": abs(d_open) <= 1.0,
                       "closing_diff_pct_of_total": pct(abs(d_close), tot, 3), "closing_match": abs(d_close) <= 1.0,
                       "ledger_events_in_period": len(eff), "estimated_events_in_period": est,
                       "tolerance": "≤ 1 元",
                       "basis": "券商剩余金额 vs 账单现金减副本台账期间现金变动"}
    return out


def ipo_checklist(files: list[dict], copy_dir: str, statement: Optional[dict]) -> list[dict]:
    """新股: 逐文件列出申购/中签/缴款/入账行 (只给日期、业务类型、编号有无与一致性), 并统计副本中股份与缴款各计几次。"""
    from services import account_ledger as al
    from services import trade_import as ti
    parsed = []
    for f in files:
        if f["type"] in ("trade_history", "settlement_statement"):
            res = ti.parse_trade_file(open(f["path"], "rb").read(), f["file"])
            parsed.append((f, res))
    codes = _related_ipo_codes([r for _, r in parsed])
    tl = ti.load_ledger(os.path.join(copy_dir, "trade_ledger.json"))
    led = al.load(os.path.join(copy_dir, "account_ledger.json"))
    eff = al.effective_events(led)
    out = []
    for code in sorted(codes):
        rows, ref_qty, ref_amt = [], None, None
        for f, res in parsed:
            for t in res.trades:
                if t.ts_code != code:
                    continue
                if t.kind == "ipo" and ref_qty is None:
                    ref_qty, ref_amt = t.qty, abs(t.net_amount) if t.net_amount is not None else t.amount
                amt = abs(t.net_amount) if t.net_amount is not None else t.amount
                rows.append({"file": f["display_name"], "date": t.date, "business": t.raw_side, "category": t.kind,
                             "side": t.side, "has_trade_id": bool(t.trade_id), "has_net_amount": t.net_amount is not None,
                             "_qty": t.qty, "_amt": amt})
            for r in res.ipo_credit_rows:
                if r["ts_code"] == code:
                    rows.append({"file": f["display_name"], "date": r["date"], "business": r["raw_side"],
                                 "category": "ipo_credit (股份划入, 不计成交/现金)", "side": "", "has_trade_id": bool(r["ref"]),
                                 "has_net_amount": False, "_qty": r["qty"], "_amt": None})
            for c in res.cash_rows:
                if c.get("ts_code") == code or any(k in (c.get("raw_side") or "") for k in ("缴款", "中签")):
                    rows.append({"file": f["display_name"], "date": c["date"], "business": c["raw_side"],
                                 "category": f"资金行:{c['category']}", "side": "", "has_trade_id": bool(c.get("ref")),
                                 "has_net_amount": c.get("net_amount") is not None,
                                 "_qty": c.get("qty"), "_amt": abs(c["net_amount"]) if c.get("net_amount") else None})
        for r in rows:
            q, a = r.pop("_qty"), r.pop("_amt")
            r["qty_matches_ipo"] = None if q in (None, 0) or ref_qty is None else abs(float(q) - ref_qty) < 0.5
            r["amount_matches_ipo"] = None if a in (None, 0) or ref_amt is None else abs(float(a) - ref_amt) <= 0.01
        buys = [t for t in tl.get("trades", []) if t["ts_code"] == code and t["side"] == "buy"]
        sells = [t for t in tl.get("trades", []) if t["ts_code"] == code and t["side"] == "sell"]
        keys = {t["key"] for t in buys}
        settles = [e for e in eff if e["type"] == "settlement" and e.get("trade_key") in keys]
        pay_rows = [e for e in eff if e["type"] not in ("settlement",) and e.get("ts_code") == code]
        held = [c for c in tl.get("conflicts", []) if c.get("field") == "possible_duplicate" and not c.get("resolution")
                and any(t["key"] == c["existing"] for t in buys)]
        confirmed = [c for c in tl.get("conflicts", []) if c.get("field") == "possible_duplicate"
                     and (c.get("resolution") or {}).get("decision") == "same" and any(t["key"] == c["existing"] for t in buys)]
        net_shares = sum(int(t["qty"]) for t in buys) - sum(int(t["qty"]) for t in sells)
        st_qty = (statement or {}).get("positions", {}).get(code, 0.0) if statement else None
        out.append({"ts_code": code, "rows": rows,
                    "copy_ledger": {"share_buy_entries": len(buys), "share_sell_entries": len(sells),
                                    "payment_settlement_events": len(settles), "other_cash_events_same_code": len(pay_rows),
                                    "possible_duplicate_pending": len(held),
                                    "user_confirmed_same": len(confirmed),
                                    "net_shares_matches_statement": None if st_qty is None else abs(net_shares - st_qty) < 0.5},
                    "status": ("股份 1 次 / 缴款 1 次" if len(buys) == 1 and len(settles) == 1 and not pay_rows
                               else "需核对: 股份或缴款计入次数不是各 1 次"),
                    "pending_user_confirmation": bool(held)})
    return out


def test_trace(app_root: str, copy_dir: str, statement: Optional[dict], relabel_shared: bool = False) -> dict:
    """核实真实现金台账中 h.txt 来源的记录是否来自人工测试 (与测试夹具逐条比对, 不仅凭文件名);
    确认后只在副本中作废 (追加 void 更正, 原事件保留), 并给出处理前后的影响。"""
    from services import account_ledger as al
    from services import trade_import as ti
    real = al.load(os.path.join(app_root, "data_lake", "account_ledger.json"))
    ev = [e for e in real.get("events", []) if e.get("source_file") == "h.txt"]
    out: dict[str, Any] = {"events": len(ev)}
    if not ev:
        out["status"] = "none"
        return out
    # 已在真实台账中逐条处理过 (正式导入时写入了作废或改来源更正, 原因已记录) → 不再依赖测试数据比对
    handled = {c["event_key"] for c in real.get("corrections", []) if c.get("action") in ("void", "relabel")}
    if all(e["event_key"] in handled for e in ev):
        acts = {}
        for c in real.get("corrections", []):
            if c["event_key"] in {e["event_key"] for e in ev} and c.get("action") in ("void", "relabel"):
                acts[c["event_key"]] = c["action"]
        out.update(status="resolved_in_ledger", voided=sum(1 for a in acts.values() if a == "void"),
                   relabeled=sum(1 for a in acts.values() if a == "relabel"),
                   note="正式台账中已逐条作废或更正来源 (原事件保留)")
        return out
    tests_dir = os.path.join(app_root, "tests")
    try:
        sys.path.insert(0, tests_dir)
        import importlib
        fx = importlib.import_module("test_trade_import")
        raw = fx.tdx_bytes(fx.ROWS)
    except Exception as e:  # noqa: BLE001
        out.update(status="fixture_unavailable", error=str(e)[:120])
        return out
    finally:
        if tests_dir in sys.path:
            sys.path.remove(tests_dir)
    sha = hashlib.sha256(raw).hexdigest()
    fx_events, _ = al.events_from_parse(ti.parse_trade_file(raw, "h.txt"), "h.txt", sha)
    strip = lambda e: {k: v for k, v in e.items() if k not in ("source_file", "source_sha256")}   # noqa: E731
    fx_by_key = {e["event_key"]: strip(e) for e in fx_events}
    matched = [e for e in ev if fx_by_key.get(e["event_key"]) == strip(e)]
    src = [x for x in real.get("sources", []) if x.get("file") == "h.txt"]
    out["source_sha256_matches_fixture"] = bool(src) and all(x.get("sha256") == sha for x in src)
    out["events_identical_to_fixture"] = len(matched)
    out["confirmed_test_origin"] = out["source_sha256_matches_fixture"] and len(matched) == len(ev)
    # 与真实成交共用同一事件 (测试数据与真实成交 key 相同) → 不作废, 否则会抹掉真实结算
    tl = ti.load_ledger(os.path.join(app_root, "data_lake", "trade_ledger.json"))
    real_keys = {t["key"] for t in tl.get("trades", []) if t.get("source") != "h.txt"}
    shared = [e for e in ev if e.get("trade_key") in real_keys]
    out["shared_with_real_trades"] = len(shared)
    out["origin"] = ("tests/test_trailing_api.py 经接口导入测试夹具 (tests/test_trade_import.py ROWS); "
                     "旧代码在未传路径时把现金台账写到真实 data_lake (2026-10-29 已修复)")
    out["isolation_fix_present"] = "path or LEDGER_PATH" in open(ti.__file__, encoding="utf-8").read()   # 实际加载的代码
    if not out["confirmed_test_origin"]:
        out["status"] = "not_confirmed"
        out["note"] = "内容与测试夹具不完全一致, 不作废, 需人工核对"
        return out
    cp = os.path.join(copy_dir, "account_ledger.json")
    before = al.load(cp)
    tot = (statement or {}).get("total_asset") or 0
    s_before = al.summarize(before)
    voided = 0
    for e in ev:
        if e in shared:
            continue
        if not any(c.get("event_key") == e["event_key"] and c.get("action") == "void" for c in before.get("corrections", [])):
            al.add_correction(e["event_key"], "void", "核实为人工测试写入 (内容与测试夹具逐条一致; test_trailing_api 写入真实路径, 已修复); "
                              "原事件保留", path=cp)
            voided += 1
    relabeled = 0
    if relabel_shared:      # 用户同意: 与真实成交共用的事件只更正来源标签 (原事件保留)
        src_of = {t["key"]: t.get("source") for t in tl.get("trades", []) if t.get("source") != "h.txt"}
        done = {c["event_key"] for c in al.load(cp).get("corrections", []) if c.get("action") == "relabel"}
        for e in shared:
            if e["event_key"] in done:
                continue
            al.add_correction(e["event_key"], "relabel",
                              "用户确认: 该现金记录对应真实成交, 因测试写入而误标为 h.txt; 来源改标为真实账单, 原事件保留",
                              replacement={"source_file": src_of.get(e.get("trade_key")) or "真实账单"}, path=cp)
            relabeled += 1
    after = al.load(cp)
    s_after = al.summarize(after)
    # 逐条去向: 账单中是否另有同日同代码的现金记录 (有 → 作废不丢真实现金; 无 → 作废需人工确认)
    others = [x for x in after.get("events", []) if x.get("source_file") != "h.txt"]
    detail = []
    for e in ev:
        cp_hit = any(x.get("date") == e.get("date") and x.get("ts_code") == e.get("ts_code") for x in others)
        detail.append({"date": e.get("date"), "ts_code": e.get("ts_code"), "side": e.get("side"), "kind": e.get("kind"),
                       "handling": "kept_shared" if e in shared else "voided_in_copy",
                       "bill_counterpart_same_date_code": cp_hit,
                       "cash_estimated": bool(e.get("cash_estimated"))})
    out["per_event"] = detail
    out["voided_without_bill_counterpart"] = sum(1 for d in detail if d["handling"] == "voided_in_copy"
                                                 and not d["bill_counterpart_same_date_code"])
    out["shared_also_in_bill_separately"] = sum(1 for d in detail if d["handling"] == "kept_shared"
                                                and d["bill_counterpart_same_date_code"])
    out.update(status="voided_in_copy", voided_in_copy=voided, kept_shared=len(shared), relabeled_in_copy=relabeled,
               impact={"effective_events_before": len(al.effective_events(before)),
                       "effective_events_after": len(al.effective_events(after)),
                       "net_cash_change_delta_pct_of_statement_total": pct(abs(s_after["net_cash_change"] - s_before["net_cash_change"]), tot, 3),
                       "settlement_estimated_before": s_before["settlement_estimated_count"],
                       "settlement_estimated_after": s_after["settlement_estimated_count"]})
    return out


def difference_list(rec: dict, ipo: list[dict], trace: dict, prov: dict, rb: Optional[dict] = None) -> list[dict]:
    """逐项差异清单。status: 一致 / 不一致 / 资料不足 / 待确认。
    只有一份账单时, 若交割单带逐笔余额, 期初/期末/现金改用券商逐笔余额核对 (rb)。"""
    rows = []
    rb = rb or {}
    if rec.get("status") == "insufficient_statements" and rb.get("opening_positions"):
        qc, cc = rb.get("qty_chain") or {}, rb.get("cash_chain") or {}
        for k, name in (("opening_positions", "期初各证券数量"), ("closing_positions", "期末各证券数量")):
            v = rb[k]
            ok = v.get("differences") == [] and not qc.get("breaks")
            rows.append({"item": name, "status": "一致" if ok else "不一致",
                         "detail": {"basis": v.get("basis"), "match_rate_pct": v.get("match_rate_pct"),
                                    "differences": v.get("differences"), "qty_chain_breaks": qc.get("breaks"),
                                    "presumed_unchanged_codes": v.get("presumed_unchanged_codes")}})
        c = rb.get("cash") or {}
        if c:
            ok = c["opening_match"] and c["closing_match"] and not cc.get("breaks")
            rows.append({"item": "现金变动与余额", "status": "一致" if ok else "不一致",
                         "detail": {k: c.get(k) for k in ("opening_diff_pct_of_total", "closing_diff_pct_of_total",
                                                          "estimated_events_in_period", "basis")}
                         | {"cash_chain_breaks": cc.get("breaks")}})
        else:
            rows.append({"item": "现金变动与余额", "status": "资料不足", "detail": "交割单无剩余金额列"})
    elif rec.get("status") == "insufficient_statements":
        rows.append({"item": "期初各证券数量", "status": "资料不足", "detail": "无可靠期初资金股份查询"})
        rows.append({"item": "期末各证券数量", "status": "资料不足",
                     "detail": "只有期末账单, 无独立锚点 (当前持仓文件来源未确认, 只作参考)"})
        rows.append({"item": "现金变动与余额", "status": "资料不足", "detail": "只有一个余额快照, 无法核对期间现金"})
    else:
        for k, name in (("opening_positions", "期初各证券数量"), ("closing_positions", "期末各证券数量")):
            v = rec.get(k) or {}
            rows.append({"item": name, "status": "一致" if v.get("differences") == [] else
                         ("资料不足" if "differences" not in v else "不一致"),
                         "detail": v.get("differences") or v.get("note")})
        c = rec.get("cash") or {}
        rows.append({"item": "现金变动与余额", "status": {"reconciled": "一致", "unexplained_difference": "不一致"}
                     .get(c.get("status"), "资料不足"), "detail": c.get("note")})
    for x in ipo:
        rows.append({"item": f"{x['ts_code']} 股份与缴款各计一次",
                     "status": "待确认" if x["pending_user_confirmation"] else
                     ("一致" if x["status"].startswith("股份 1 次") else "不一致"),
                     "detail": x["copy_ledger"]})
    st = {"voided_in_copy": "已在副本作废", "none": "无", "resolved_in_ledger": "已在正式台账处理"}.get(trace.get("status"), "待确认")
    per_ = (rec or {}).get("period") or (rb or {}).get("period") or {}      # 无两份快照时用交割单逐笔余额区间
    lo, hi = per_.get("from"), per_.get("to")
    inside = lambda d: not (lo and hi) or (d and lo <= str(d) <= hi)      # noqa: E731  无对账区间时全部视为相关
    unresolved = [d for d in trace.get("per_event") or [] if inside(d.get("date")) and (
        (d["handling"] == "voided_in_copy" and not d["bill_counterpart_same_date_code"])
        or (d["handling"] == "kept_shared" and d["bill_counterpart_same_date_code"]))]
    rbc = (rb or {}).get("cash") or {}
    cash_ok = ((rec or {}).get("cash") or {}).get("status") == "reconciled" or (
        bool(rbc) and rbc.get("opening_match") and rbc.get("closing_match")
        and not ((rb or {}).get("cash_chain") or {}).get("breaks"))
    if unresolved and not cash_ok:
        st = "待确认"      # 区间内: 作废后账单无对应现金记录, 或保留的记录在账单中另有一份 → 需人工核对
    rows.append({"item": "疑似测试记录 (h.txt)", "status": st,
                 "detail": {k: trace.get(k) for k in ("events", "confirmed_test_origin", "shared_with_real_trades",
                                                      "voided_in_copy", "relabeled_in_copy", "voided_without_bill_counterpart",
                                                      "shared_also_in_bill_separately", "impact", "voided", "relabeled")
                            if trace.get(k) is not None}
                 | {"unresolved_in_period": len(unresolved),
                    "resolved_by": "作废后区间现金与券商余额一致" if (unresolved and cash_ok) else None}})
    rows.append({"item": "当前持仓文件作为期初", "status": "未采用",
                 "detail": {k: prov.get(k) for k in ("import_date", "date_basis", "modified_after_import")}})
    return rows


# ═══════════════════════ 主流程 ═══════════════════════

def run(bills: str, manifest: dict, work: str, app_root: str = APP_ROOT) -> dict:
    real = real_paths(app_root)
    before = digests(real)
    os.makedirs(work, exist_ok=True)
    report: dict[str, Any] = {"work_dir": work, "started_at": datetime.now().isoformat(timespec="seconds")}
    report["code"] = code_state(app_root)
    report["backup"] = backup(app_root, os.path.join(work, "backup"))
    files = inventory(bills, manifest)
    report["inventory"] = [{k: v for k, v in f.items() if k not in ("path", "file", "sha256")} | {"sha256": f["sha256"][:12]}
                           for f in files]
    copy_dir = os.path.join(work, "copy")
    os.makedirs(copy_dir, exist_ok=True)
    for n in ("trade_ledger.json", "account_ledger.json"):
        if os.path.exists(real[n]):
            shutil.copy2(real[n], os.path.join(copy_dir, n))
    from services import trade_import as ti
    trades_before = ti.load_ledger(os.path.join(copy_dir, "trade_ledger.json")).get("trades", [])
    report["trial_import"] = import_round(files, copy_dir, manifest)
    trades_after = ti.load_ledger(os.path.join(copy_dir, "trade_ledger.json")).get("trades", [])
    report["ledger_counts"] = {"trades_before": len(trades_before), "trades_after": len(trades_after)}
    decisions = manifest.get("_decisions") or {}
    report["decisions"] = {k: decisions.get(k) for k in ("same_allotment", "relabel_shared_test_events", "returns_start")}
    report["confirmations"] = apply_confirmations(copy_dir, files, decisions)
    trades_after = ti.load_ledger(os.path.join(copy_dir, "trade_ledger.json")).get("trades", [])
    tl_copy = ti.load_ledger(os.path.join(copy_dir, "trade_ledger.json"))
    held_existing = {c["existing"] for c in tl_copy.get("conflicts", []) if c.get("field") == "possible_duplicate"
                     and not c.get("resolution")}
    report["possible_duplicates"] = [{"existing_date": next((t["date"] for t in trades_after if t["key"] == c["existing"]), None),
                                      "ts_code": next((t["ts_code"] for t in trades_after if t["key"] == c["existing"]), None),
                                      "existing_source": mask(c.get("existing_source") or ""), "incoming_source": mask(c["source"])}
                                     for c in tl_copy.get("conflicts", []) if c.get("field") == "possible_duplicate"
                                     and not c.get("resolution")]
    report["fees_backfill"] = fee_backfill(trades_before, trades_after, files, held_existing)
    snap1 = content_fingerprint(copy_dir)
    second = import_round(files, copy_dir, manifest)
    snap2 = content_fingerprint(copy_dir)
    repeat_ok = snap1 == snap2 and all(not (r.get("added") or r.get("enriched") or r.get("cash_events_added")
                                            or r.get("cash_events_enriched") or r.get("snapshot_added")) for r in second)
    report["repeat_import"] = {"idempotent": repeat_ok,
                               "compared": "成交/冲突/现金事件/更正/快照 (导入日志按设计会追加, 不参与比较)",
                               "second_round_added": sum(r.get("added") or 0 for r in second),
                               "second_round_enriched": sum(r.get("enriched") or 0 for r in second),
                               "second_round_cash_events_added": sum(r.get("cash_events_added") or 0 for r in second)}
    # 核实清单: 先在副本中处理已确认的测试记录, 再对账 (否则测试记录会混入现金核对)
    from services import account_ledger as al
    snaps = sorted([s for s in al.load(os.path.join(copy_dir, "account_ledger.json")).get("snapshots", [])
                    if s.get("positions") is not None and s.get("as_of")], key=lambda s: s["as_of"])
    latest = snaps[-1] if snaps else None
    report["test_trace"] = test_trace(app_root, copy_dir, latest, relabel_shared=bool(decisions.get("relabel_shared_test_events")))
    trades_now = ti.load_ledger(os.path.join(copy_dir, "trade_ledger.json")).get("trades", [])
    report["store_provenance"] = store_provenance(app_root, trades_now, latest)
    report["ipo_checklist"] = ipo_checklist(files, copy_dir, latest)
    report["running_balance"] = running_balance(files, copy_dir, latest)
    rec = reconcile(copy_dir, app_root)
    report["reconciliation"] = rec
    ok, reasons = gate(report["trial_import"], repeat_ok, rec, report["fees_backfill"],
                       resolved=report["confirmations"].get("resolved", 0))
    report["acceptance"] = {"reconciled": ok, "stop_reasons": reasons,
                            "returns_acceptance": "executed" if ok else "stopped"}
    if ok:
        report["metrics"] = metrics(copy_dir, app_root, rec)
    report["contamination"] = contamination(app_root, {f["sha256"] for f in files})
    report["differences"] = difference_list(rec, report["ipo_checklist"], report["test_trace"], report["store_provenance"],
                                           report.get("running_balance"))
    rs = decisions.get("returns_start")
    if rs:
        snap_rs = next((s for s in snaps if s["as_of"] == rs), None)
        report["returns_plan"] = {
            "returns_start": rs,
            "start_snapshot": bool(snap_rs), "start_valuation_timing": (snap_rs or {}).get("valuation_timing"),
            "before_start": "不计收益 (用户选择); 仅核对数量与现金",
            "status": ("等待下一份收盘后资金股份查询, 才能计算首个收益区间" if snap_rs and snap_rs.get("valuation_timing") == "close"
                       else "起点快照缺失或估值时点不是收盘后, 不能作为收益起点")}
        report["acceptance"]["stop_reasons"] = [s for s in report["acceptance"]["stop_reasons"]
                                                if not s.startswith("需要至少两个")]
        report["acceptance"]["stop_reasons"].append(f"收益自 {rs} 收盘后起算: {report['returns_plan']['status']}")
    elif rec.get("status") == "insufficient_statements" and (report["running_balance"].get("opening_positions")):
        report["acceptance"]["stop_reasons"].append(
            "期初只有券商逐笔余额反推的数量与现金, 没有期初估值快照; 收益需另行用期初收盘价估值 (尚未实现), 本轮不计算收益")
    if latest and rec.get("status") == "insufficient_statements":
        report["new_baseline"] = {"as_of": latest["as_of"], "valuation_timing": latest.get("valuation_timing"),
                                  "positions": len(latest["positions"]),
                                  "note": "可核实的新起点; 此前区间标记为期初资料不足"}
    unresolved = [d for d in report["differences"] if d["status"] in ("不一致", "待确认")]
    if unresolved:
        report["acceptance"]["stop_reasons"] += [f"未解决: {d['item']} ({d['status']})" for d in unresolved
                                                 if f"未解决: {d['item']} ({d['status']})" not in report["acceptance"]["stop_reasons"]]
        report["acceptance"]["reconciled"] = False
        report["acceptance"]["returns_acceptance"] = "stopped"
        report.pop("metrics", None)
    after = digests(real)
    report["real_digests"] = before
    report["real_files_unchanged"] = before == after
    report["real_files_changed"] = [k for k in real if before.get(k) != after.get(k)]
    report["finished_at"] = datetime.now().isoformat(timespec="seconds")
    with open(os.path.join(work, "acceptance_summary.json"), "w", encoding="utf-8") as f:
        json.dump(report, f, ensure_ascii=False, indent=1, default=str)
    return report


def render(r: dict) -> str:
    L = []
    w = L.append
    w("=== 方案 B 真实数据副本验收 (脱敏汇总) ===")
    c = r["code"]
    w(f"代码: git {c['git_head']} · 未提交改动 {c['uncommitted_count']} 个文件")
    w(f"备份: {len([f for f in r['backup']['files'] if f['status'] == 'ok'])} 个文件 → {r['backup']['dir']}")
    w("— 文件清单 —")
    for f in r["inventory"]:
        span = (f"{f.get('date_from')}~{f.get('date_to')}" if f.get("date_from") else
                f"账单日 {f.get('statement_date') or '未知'} ({f.get('date_basis')}) 估值时点 {f.get('valuation_time') or '未知'}"
                if f["type"] == "holdings_statement" else "-")
        w(f"  {f['display_name']} | {f['type']} | {f['size']}B | 修改 {f['mtime']} | 行 {f['raw_lines']} | {span}"
          + (f" | 成交 {f.get('parsed_trades')} 资金行 {f.get('cash_rows')} 忽略 {f.get('skipped')} 失败 {f.get('errors')}"
             if f.get("parsed_trades") is not None else ""))
    w("— 副本试导入 —")
    for t in r["trial_import"]:
        w("  " + " · ".join(f"{k}={v}" for k, v in t.items()))
    fb = r["fees_backfill"]
    w(f"— 原缺费用成交 {fb['originally_missing']} 笔: 已补全 {fb['filled']} · 仍缺 {fb['still_missing']} · 原因 {fb['reasons']}")
    if r.get("confirmations", {}).get("items") or r.get("confirmations", {}).get("not_found"):
        w(f"— 用户确认 (仅副本): {r['confirmations']}")
    if r.get("returns_plan"):
        w(f"— 收益起点: {r['returns_plan']}")
    if r.get("possible_duplicates"):
        w(f"— 疑似同笔 (编号不同, 未自动合并, 待确认): {r['possible_duplicates']}")
    rp = r["repeat_import"]
    w(f"— 重复导入: {'稳定 ✅' if rp['idempotent'] else '不稳定 ❌'} ({rp})")
    w("— 券商对账 —")
    w("  " + json.dumps(r["reconciliation"], ensure_ascii=False, default=str))
    a = r["acceptance"]
    w(f"— 结论: {'对账通过, 已执行收益验收' if a['reconciled'] else '对账未通过/数据不足 → 已停止收益验收'}")
    for s in a["stop_reasons"]:
        w(f"    · {s}")
    if r.get("metrics"):
        w("  " + json.dumps(r["metrics"], ensure_ascii=False, default=str))
    w(f"— 真实现金台账疑似测试写入: {r['contamination']}")
    w("— 核实清单 —")
    w("  持仓文件来源: " + json.dumps(r.get("store_provenance"), ensure_ascii=False, default=str))
    for x in r.get("ipo_checklist", []):
        w(f"  新股 {x['ts_code']}: {x['status']} · 待确认={x['pending_user_confirmation']} · 副本计数 {x['copy_ledger']}")
        for row in x["rows"]:
            w("     · " + " | ".join(f"{k}={v}" for k, v in row.items()))
    tt = dict(r.get("test_trace") or {})
    per = tt.pop("per_event", None) or []
    w("  测试记录核实: " + json.dumps(tt, ensure_ascii=False, default=str))
    for d in per:
        w("     · " + " | ".join(f"{k}={v}" for k, v in d.items()))
    if r.get("new_baseline"):
        w(f"  新起点: {r['new_baseline']}")
    rb = r.get("running_balance") or {}
    w("— 交割单逐笔余额对账 —")
    w("  " + json.dumps({k: rb.get(k) for k in ("status", "file", "rows", "period", "note", "cash_chain", "qty_chain")
                         if rb.get(k) is not None}, ensure_ascii=False, default=str))
    for k, name in (("opening_positions", "期初数量"), ("closing_positions", "期末数量"), ("cash", "现金")):
        if rb.get(k):
            w(f"  {name}: " + json.dumps(rb[k], ensure_ascii=False, default=str))
    w("— 逐项差异清单 —")
    for d in r.get("differences", []):
        w(f"  [{d['status']}] {d['item']}: {json.dumps(d['detail'], ensure_ascii=False, default=str)}")
    w(f"— 真实文件未被修改: {'是 ✅' if r['real_files_unchanged'] else '否 ❌ ' + str(r['real_files_changed'])}")
    w(f"— 完整汇总 JSON: {os.path.join(r['work_dir'], 'acceptance_summary.json')}")
    return "\n".join(L)


# ═══════════════════════ 8. 正式导入 (用户明确执行 --apply) ═══════════════════════

LEDGER_FILES = ("trade_ledger.json", "account_ledger.json")


def apply_blockers(r: dict) -> list[str]:
    """正式导入的前置条件: 副本核实全部通过 (唯一允许的停止原因是"收益等待下一份快照")。"""
    out = []
    if not r.get("real_files_unchanged"):
        out.append("核实期间真实文件发生变化")
    if not (r.get("repeat_import") or {}).get("idempotent"):
        out.append("重复导入不稳定")
    bad = [d["item"] for d in r.get("differences", []) if d["status"] in ("不一致", "待确认")]
    if bad:
        out.append("差异清单未通过: " + "、".join(bad))
    core = {d["item"]: d["status"] for d in r.get("differences", [])}
    missing = [k for k in ("期初各证券数量", "期末各证券数量", "现金变动与余额") if core.get(k) != "一致"]
    if missing:
        out.append("核心对账项未确认一致: " + "、".join(missing))
    others = [s for s in (r.get("acceptance") or {}).get("stop_reasons", []) if not s.startswith("收益自 ")]
    if others:
        out.append("仍有停止原因: " + "; ".join(others))
    return out


def _replace_atomic(src: str, dst: str) -> None:
    tmp = dst + ".plan_b_tmp"
    shutil.copy2(src, tmp)
    os.replace(tmp, dst)


def apply_formal(r: dict, bills: str, manifest: dict, work: str, backup_dir: str, app_root: str = APP_ROOT) -> dict:
    """把已核实的副本台账 (成交台账 + 现金台账) 写入真实 data_lake。
    先做持久备份并校验; 写入前确认真实文件与核实开始时完全相同; 写入后用同一批账单复核
    (必须无新增、无补全、差异清单全部通过), 复核失败自动从备份还原。不改 portfolio_store / 交易记录库。"""
    out: dict[str, Any] = {"status": "refused", "backup_dir": backup_dir}
    blockers = apply_blockers(r)
    if blockers:
        out["reasons"] = blockers
        return out
    real = real_paths(app_root)
    if digests(real) != r["real_digests"]:
        out["reasons"] = ["核实结束后真实文件又发生变化, 请重新运行核实"]
        return out
    b = backup(app_root, backup_dir)
    for n in LEDGER_FILES:
        if os.path.exists(real[n]) and sha256_file(os.path.join(backup_dir, n)) != r["real_digests"][n]:
            out["reasons"] = [f"备份校验失败: {n}"]
            return out
    copy_dir = os.path.join(work, "copy")
    for n in LEDGER_FILES:
        _replace_atomic(os.path.join(copy_dir, n), real[n])
    out["replaced"] = list(LEDGER_FILES)
    post = run(bills, manifest, os.path.join(work, "post_apply"), app_root=app_root)
    adds = sum((x.get("added") or 0) + (x.get("enriched") or 0) + (x.get("cash_events_added") or 0)
               + (x.get("cash_events_enriched") or 0) + (x.get("snapshot_added") or 0) for x in post["trial_import"])
    problems = apply_blockers(post)
    if adds:
        problems.append(f"复核时同一批账单仍产生 {adds} 处新增或补全")
    if post["confirmations"].get("resolved") or (post["test_trace"].get("voided_in_copy") or 0) \
            or (post["test_trace"].get("relabeled_in_copy") or 0):
        problems.append("复核时决定仍需再次执行 (未完整写入)")
    out["post_check"] = {"differences": {d["item"]: d["status"] for d in post["differences"]},
                         "new_or_enriched": adds, "problems": problems}
    if problems:
        for n in LEDGER_FILES:
            src = os.path.join(backup_dir, n)
            if os.path.exists(src):
                _replace_atomic(src, real[n])
        restored_ok = all(sha256_file(real[n]) == r["real_digests"][n] for n in LEDGER_FILES if os.path.exists(real[n]))
        out.update(status="rolled_back", restored_ok=restored_ok)
        return out
    after = {n: sha256_file(real[n]) for n in LEDGER_FILES}
    receipt = {"applied_at": datetime.now().isoformat(timespec="seconds"), "files": list(LEDGER_FILES),
               "before": {n: r["real_digests"][n] for n in LEDGER_FILES}, "after": after,
               "decisions": r.get("decisions"), "verification_work_dir": work, "backup": b["files"],
               "not_changed": ["portfolio_store.json", "trade_history.json", "数据库文件"]}
    with open(os.path.join(backup_dir, "apply_receipt.json"), "w", encoding="utf-8") as f:
        json.dump(receipt, f, ensure_ascii=False, indent=1)
    out.update(status="applied", receipt=os.path.join(backup_dir, "apply_receipt.json"))
    return out


def restore(backup_dir: str, app_root: str = APP_ROOT, force: bool = False) -> dict:
    """按回执还原两份台账; 默认要求当前真实文件仍是正式导入后的状态 (防止覆盖之后的新记录)。"""
    rp = os.path.join(backup_dir, "apply_receipt.json")
    if not os.path.exists(rp):
        return {"status": "refused", "reason": "备份目录中没有正式导入回执"}
    receipt = json.load(open(rp, encoding="utf-8"))
    real = real_paths(app_root)
    cur = {n: sha256_file(real[n]) for n in receipt["files"]}
    if cur != receipt["after"] and not force:
        return {"status": "refused", "reason": "正式导入后台账已有新变化; 确需还原请加 --force (会丢失之后的记录)"}
    for n in receipt["files"]:
        if sha256_file(os.path.join(backup_dir, n)) != receipt["before"][n]:
            return {"status": "refused", "reason": f"备份文件校验失败: {n}"}
    for n in receipt["files"]:
        _replace_atomic(os.path.join(backup_dir, n), real[n])
    ok = all(sha256_file(real[n]) == receipt["before"][n] for n in receipt["files"])
    return {"status": "restored" if ok else "restore_mismatch", "files": receipt["files"]}


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--bills", help="账单文件夹 (只读)")
    ap.add_argument("--manifest", help="可选: 账单日期/估值时点清单 JSON")
    ap.add_argument("--work", help="副本工作目录 (默认系统临时目录下新建)")
    ap.add_argument("--apply", action="store_true", help="核实全部通过后, 把副本台账正式写入真实 data_lake (先持久备份)")
    ap.add_argument("--backup-dir", help="正式导入的持久备份目录 (默认 用户目录/AlphaCore_backups/时间戳)")
    ap.add_argument("--restore", metavar="BACKUP_DIR", help="按正式导入回执还原两份台账")
    ap.add_argument("--force", action="store_true", help="与 --restore 合用: 即使导入后台账有新变化也还原")
    args = ap.parse_args(argv)
    if args.restore:
        res = restore(args.restore, force=args.force)
        print(json.dumps(res, ensure_ascii=False))
        return 0 if res["status"] == "restored" else 4
    if not args.bills:
        print("需要 --bills")
        return 1
    if not os.path.isdir(args.bills):
        print(f"账单文件夹不存在: {args.bills}")
        return 1
    manifest = {}
    if args.manifest:
        if not os.path.isfile(args.manifest):
            print(f"清单文件不存在: {args.manifest} (不需要清单时去掉 --manifest)")
            return 1
        with open(args.manifest, encoding="utf-8-sig") as f:      # 兼容 PowerShell 写入的 BOM
            manifest = json.load(f)
    work = args.work or os.path.join(tempfile.gettempdir(), "alphacore_plan_b_acceptance",
                                     datetime.now().strftime("%Y%m%d_%H%M%S"))
    if os.path.abspath(work).startswith(os.path.abspath(os.path.join(APP_ROOT, "data_lake"))):
        print("工作目录不能位于 data_lake 内")
        return 1
    r = run(args.bills, manifest, work)
    print(render(r))
    if not r["real_files_unchanged"]:
        return 2
    if args.apply:
        bdir = args.backup_dir or os.path.join(os.path.expanduser("~"), "AlphaCore_backups",
                                               "plan_b_" + datetime.now().strftime("%Y%m%d_%H%M%S"))
        res = apply_formal(r, args.bills, manifest, work, bdir)
        print("=== 正式导入 ===")
        print(json.dumps(res, ensure_ascii=False, indent=1, default=str))
        if res["status"] == "applied":
            print(f"如需撤销: python -B _dev_tools\\plan_b_reconcile.py --bills \"{args.bills}\" --restore \"{bdir}\"")
            return 0
        return 4 if res["status"] == "refused" else 5
    return 0 if r["acceptance"]["reconciled"] else 3


if __name__ == "__main__":
    sys.exit(main())
