"""F1 迁移演练 (只读原库): 在副本上执行 decision_log 迁移并对比前后统计。

用法 (在应用目录 quant_dashboard/quant_dashboard 下):
    .\\.venv\\Scripts\\python.exe -B _dev_tools\\f1_migration_drill.py

- 使用 SQLite 在线备份 API 复制主库 (含 WAL 中尚未合并的数据) 到临时目录;
- 只在副本上运行 init_db + migrate_decision_log_v2, 原库不写入;
- 仅输出 decision_log 的条数/状态统计与各表行数, 不输出成交、持仓等明细。
"""
import os
import sqlite3
import sys
import tempfile
import threading

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

from services.db import connection  # noqa: E402


def _counts(conn):
    tables = [r[0] for r in conn.execute("SELECT name FROM sqlite_master WHERE type='table'")]
    out = {t: conn.execute(f'SELECT COUNT(*) FROM "{t}"').fetchone()[0] for t in sorted(tables)}
    cols = [r[1] for r in conn.execute("PRAGMA table_info(decision_log)")]
    dl = {"rows": out.get("decision_log", 0),
          "signal_correct_not_null": conn.execute(
              "SELECT COUNT(*) FROM decision_log WHERE signal_correct IS NOT NULL").fetchone()[0]}
    if "eval_status" in cols:
        dl["eval_status"] = dict(conn.execute(
            "SELECT COALESCE(eval_status,'<null>'), COUNT(*) FROM decision_log GROUP BY 1").fetchall())
        dl["legacy_signal_correct"] = dict(conn.execute(
            "SELECT COALESCE(legacy_signal_correct,'<null>'), COUNT(*) FROM decision_log "
            "GROUP BY 1").fetchall())
    return out, dl


def main():
    src_path = connection.DB_PATH
    if not os.path.exists(src_path):
        print("主库不存在:", src_path)
        return 1
    work = tempfile.mkdtemp(prefix="f1_drill_")
    copy_path = os.path.join(work, "alphacore_copy.db")
    src = sqlite3.connect(f"file:{src_path}?mode=ro", uri=True)
    dst = sqlite3.connect(copy_path)
    src.backup(dst)
    src.close()
    before_tables, before_dl = _counts(dst)
    dst.close()

    connection.DB_DIR = work
    connection.DB_PATH = copy_path
    connection._local = threading.local()
    connection.init_db()
    connection.migrate_decision_log_v2()
    conn = connection._get_conn()
    after_tables, after_dl = _counts(conn)
    ok = conn.execute("PRAGMA integrity_check").fetchone()[0]

    print("副本位置:", copy_path)
    print("integrity_check:", ok)
    print("decision_log 迁移前:", before_dl)
    print("decision_log 迁移后:", after_dl)
    changed = {t: (before_tables.get(t), after_tables.get(t))
               for t in set(before_tables) | set(after_tables)
               if before_tables.get(t) != after_tables.get(t)}
    print("行数发生变化的表 (应为空):", changed or "无")
    expect = before_dl["signal_correct_not_null"]
    legacy = after_dl.get("legacy_signal_correct", {})
    moved = sum(v for k, v in legacy.items() if k != "<null>")
    print(f"旧判定转存核对: 迁移前有判定 {expect} 条, legacy 列非空 {moved} 条",
          "✅" if moved == expect else "⚠ 不一致, 请勿在真实库执行")
    return 0 if (ok == "ok" and not changed and moved == expect) else 2


if __name__ == "__main__":
    sys.exit(main())
