"""Offline mathematical acceptance and read-only historical evidence inventory.

This does not generate a trading approval or manufacture an out-of-sample run.
Usage: python _dev_tools/validate_jcs_production.py --output docs/audits/jcs-validation.json
"""
import argparse
import itertools
import json
import math
import os
from pathlib import Path
import sqlite3
import sys
import tempfile
from datetime import datetime, timezone

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
os.environ.setdefault("ALPHACORE_LOG_DIR", str(Path(tempfile.gettempdir()) / "alphacore_test_logs"))

from dashboard_modules.decision.jcs import compute_jcs  # noqa: E402 - CLI path bootstrap
from services.jcs_validation import model_fingerprint, validation_status, MODEL_VERSION  # noqa: E402


def validate():
    cases = 0
    for values in itertools.product((1, 2, 3, 4, 5), (0, 35, 50, 55, 100),
                                    (12, 16, 25, 30, 40), ("BULL", "RANGE", "BEAR", "CRASH"),
                                    (None, -100, 0, 100), (None, -100, 0, 100)):
        snap = dict(zip(("aiae_regime", "erp_score", "vix_val", "mr_regime", "gold_signal", "bond_signal"), values))
        result = compute_jcs(snap)
        parts = result["components"]
        reconstructed = round(max(0, min(100, parts["base_agreement"] + parts["data_health"]
                                        + parts["consensus_bonus"] - parts["conflict_penalty"])), 1)
        assert math.isfinite(result["score"]) and 0 <= result["score"] <= 100
        assert reconstructed == result["score"]
        assert abs(sum(result["direction_distribution"].values()) - 100) < 1e-8
        assert result["is_probability"] is False
        assert result["level"] == ("high" if result["score"] >= 70 else "medium" if result["score"] >= 40 else "low")
        assert result["used_for_execution"] is False
        for engine, state in result["signal_states"].items():
            # 移出的读数 (MR/BOND) 与观测时间待核验的读数不赋方向
            if state.get("excluded") or state.get("time_unverified"):
                assert state["direction"] is None
                continue
            assert (state["direction"] is None) == (state["status"] != "available")
        cases += 1

    # Read only, without init_db, migrations, schedulers or market data fetches.
    from services.db.connection import DB_PATH
    historical = {"legacy_rows": 0, "current_model_rows": 0, "earliest_date": None, "latest_date": None,
                  "eligibility": "insufficient_evidence", "detail": "历史分数不自动继承新版本有效性"}
    path = Path(DB_PATH)
    if path.exists():
        with sqlite3.connect(path.resolve().as_uri() + "?mode=ro", uri=True) as conn:
            tables = {row[0] for row in conn.execute("SELECT name FROM sqlite_master WHERE type='table'")}
            if "decision_log" in tables:
                count, first, last = conn.execute("SELECT count(*), min(date), max(date) FROM decision_log").fetchone()
                historical.update(legacy_rows=count, earliest_date=first, latest_date=last)
            if "decision_evidence" in tables:
                historical["current_model_rows"] = conn.execute(
                    "SELECT count(*) FROM decision_evidence WHERE model_fingerprint=?", (model_fingerprint(),)
                ).fetchone()[0]
    return {"generated_at": datetime.now(timezone.utc).isoformat(), "model_version": MODEL_VERSION,
            "model_fingerprint": model_fingerprint(), "mathematical_validation": "passed",
            "deterministic_cases": cases, "statistical_validation": "insufficient_evidence",
            "historical_evidence": historical, "execution_ready": False,
            "validation_gate": validation_status(),
            "remaining_evidence": ["当前版本按时间划分的样本外回放", "原始发布时间与历史版本数据防泄漏证明",
                                   "交易成本、滑点和极端行情检验", "概率声明对应的校准或明确非概率定位",
                                   "真实交易通道的独立账户、行情与订单生命周期验收"]}


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    report = validate()
    encoded = json.dumps(report, ensure_ascii=False, indent=2, allow_nan=False)
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(encoded + "\n", encoding="utf-8")
    print(json.dumps({key: report[key] for key in ("mathematical_validation", "deterministic_cases", "statistical_validation", "historical_evidence", "execution_ready")}, ensure_ascii=True))
