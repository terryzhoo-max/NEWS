"""
推送前检查 (一键推送.bat 在 quant_dashboard 仓库提交前调用)
==========================================================
2026-11-03 起用。起因: 1c 两次提交漏选 3 个文件, CI #123 失败, 本机测试却是绿的 (本机测的是工作区, 不是提交内容)。

顺序:
  1. 暂存区为空而工作区有改动: 先列出将加入的全部文件, 输入 A 才执行 git add -A (直接回车不加入)。
  2. 工作区中已修改 / 新建、但不在本次提交里的代码文件: 逐个列出, 输入 YES 才继续, 否则中止。
     (跳过测试时这一步照样执行)
  3. 没有要推送的内容 (暂存区空且本地不领先远端): 不确认、不跑测试, 直接返回 (在第 2 步之前判断)。
  4. 跳过开关: ALPHACORE_SKIP_TESTS=1 且 ALPHACORE_SKIP_REASON 非空 才跳过测试 (只给紧急情况用),
     原因写入本次推送日志与常设的 .push-logs/skipped-tests.log, 提交说明末尾加 [skip-tests: 原因]。
     只设开关不写原因 → 中止。
  5. 测试干净快照: git checkout-index 导出暂存区 (= 即将提交的内容, 换行同 CI 为 LF) 到临时目录, 用与 CI 相同的步骤跑:
     AST 语法检查、pytest 全量 (离线, 占位令牌)、production_check --code-only、tests/*.cjs 前端测试。
     快照里没有 .env、没有被忽略的 data_lake, 漏选的文件在快照里就不存在, 测试会在本机先失败。
     任一失败 → 列出失败项, 返回 1, 不提交不推送。

退出码: 0 = 可以继续提交 / 推送; 1 = 中止。
"""
from __future__ import annotations

import argparse
import ast
import os
import shutil
import subprocess
import sys
import tempfile
import threading
import time
from datetime import datetime
from pathlib import Path

APP_SUBDIR = "quant_dashboard"          # 应用位于仓库根下的子目录 (与 CI working-directory 一致)

# 需要确认的"代码文件": 漏选这些会让提交内容与本机测试不一致。
CODE_EXTS = {
    ".py", ".js", ".cjs", ".mjs", ".ts", ".html", ".css",
    ".yml", ".yaml", ".ini", ".toml", ".cfg", ".bat", ".cmd", ".ps1", ".sh", ".sql", ".md",
}
CODE_FILENAMES = {"Dockerfile", "requirements.txt", ".gitignore", ".dockerignore"}
# .json 多为运行产物 (回测结果、缓存); 只有 config/ 下的算配置。
CONFIG_JSON_DIRS = ("config/",)

PYTEST_TIMEOUT = 20 * 60
NODE_TIMEOUT = 2 * 60


# ── 小工具 ───────────────────────────────────────────────────────────

def _now() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


class Logger:
    def __init__(self, path: str | None):
        self.path = path

    def __call__(self, msg: str) -> None:
        if not self.path:
            return
        try:
            with open(self.path, "a", encoding="utf-8") as f:
                f.write(f"[{_now()}] {msg}\n")
        except OSError:
            pass


def git(repo: Path, *args: str, check: bool = True) -> subprocess.CompletedProcess:
    return subprocess.run(["git", *args], cwd=repo, capture_output=True, check=check)


def _split_z(out: bytes) -> list[str]:
    return [p for p in out.decode("utf-8", errors="replace").split("\0") if p]


def staged_files(repo: Path) -> list[str]:
    return _split_z(git(repo, "diff", "--cached", "--name-only", "-z").stdout)


def worktree_changes(repo: Path) -> list[tuple[str, str]]:
    """工作区中未暂存的改动: [(状态, 路径)], 状态为 修改 / 删除 / 新建。已忽略的文件不列。"""
    items = _split_z(git(repo, "status", "--porcelain=v1", "-z", "--untracked-files=all").stdout)
    out: list[tuple[str, str]] = []
    i = 0
    while i < len(items):
        entry = items[i]
        x, y, path = entry[0], entry[1], entry[3:]
        if x in "RC":           # 重命名 / 复制: 后面紧跟原路径
            i += 1
        i += 1
        if x == "?" and y == "?":
            out.append(("新建", path))
        elif y == "M":
            out.append(("修改", path))
        elif y == "D":
            out.append(("删除", path))
        elif y != " ":
            out.append(("改动", path))
    return out


def is_code_file(path: str) -> bool:
    p = path.replace("\\", "/")
    name = p.rsplit("/", 1)[-1]
    if name in CODE_FILENAMES:
        return True
    ext = os.path.splitext(name)[1].lower()
    if ext == ".json":
        rel = p.split("/", 1)[1] if p.startswith(APP_SUBDIR + "/") else p
        return rel.startswith(CONFIG_JSON_DIRS)
    return ext in CODE_EXTS


def ahead_count(repo: Path, remote: str, branch: str) -> int:
    r = git(repo, "rev-list", "--count", f"{remote}/{branch}..HEAD", check=False)
    try:
        return int(r.stdout.decode().strip())
    except ValueError:
        return 0


def ask(prompt: str, interactive: bool) -> str:
    if not interactive:
        return ""
    try:
        return input(prompt).strip()
    except EOFError:
        return ""


# ── 测试 ─────────────────────────────────────────────────────────────

def export_snapshot(repo: Path, dest: Path) -> Path:
    """把暂存区 (即将提交的内容) 原样导出到 dest。

    换行与 CI 一致 (仓库内容是 LF, CI 在 Linux 检出也是 LF): 关闭本机的 core.autocrlf,
    否则 Windows 上导出成 CRLF, 依赖换行的前端测试会在本机误报失败 (2026-11-03 首次运行:
    test_warmup_frontend.cjs 按 "\\n" 查找 decision.js 片段)。
    """
    dest.mkdir(parents=True, exist_ok=True)
    prefix = str(dest).replace("\\", "/").rstrip("/") + "/"
    git(repo, "-c", "core.autocrlf=false", "-c", "core.eol=lf", "checkout-index", "-a", f"--prefix={prefix}")
    return dest


def _test_env() -> dict:
    env = dict(os.environ)
    for k in ("API_SECRET_KEY", "ALPHACORE_ENV", "ALPHACORE_SKIP_TESTS", "ALPHACORE_SKIP_REASON",
              "ALPHACORE_TEST_NET", "PYTEST_ADDOPTS"):
        env.pop(k, None)
    env.update({
        "TUSHARE_TOKEN": "ci_dummy_token",     # 与 CI 相同的占位值, 测试不联网
        "FRED_API_KEY": "ci_dummy_key",
        "PYTHONIOENCODING": "utf-8",
        "PYTHONUTF8": "1",
        "PYTHONDONTWRITEBYTECODE": "1",
    })
    return env


def _run_stream(cmd: list[str], cwd: Path, env: dict, timeout: int) -> tuple[int, list[str]]:
    """运行并实时显示输出, 同时保留全部输出行。"""
    lines: list[str] = []
    try:
        p = subprocess.Popen(cmd, cwd=cwd, env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    except OSError as e:
        return 127, [f"无法运行 {cmd[0]}: {e}"]
    timer = threading.Timer(timeout, p.kill)      # 无输出卡住时也能按时终止
    timer.start()
    try:
        assert p.stdout is not None
        for raw in p.stdout:
            line = raw.decode("utf-8", errors="replace").rstrip("\r\n")
            lines.append(line)
            print(line, flush=True)
        code = p.wait()
    finally:
        expired = not timer.is_alive()
        timer.cancel()
    if expired and code != 0:
        lines.append(f"超时 ({timeout} 秒), 已终止")
        return 124, lines
    return code, lines


def ast_check(app: Path) -> list[str]:
    errors = []
    for f in app.glob("**/*.py"):
        if ".venv" in f.parts or "node_modules" in f.parts:
            continue
        try:
            ast.parse(f.read_text(encoding="utf-8-sig"))
        except (SyntaxError, UnicodeDecodeError) as e:
            errors.append(f"{f.relative_to(app).as_posix()}: {e}")
    return errors


def run_suite(app: Path, python: str, node: str | None) -> dict:
    """在快照的应用目录中按 CI 顺序跑检查。返回 {'failures': [...], 'summary': [...]}。"""
    env = _test_env()
    failures: list[str] = []
    summary: list[str] = []

    print("\n  [1/4] AST 语法检查", flush=True)
    errs = ast_check(app)
    failures += [f"语法: {e}" for e in errs]
    summary.append(f"AST: {'失败 ' + str(len(errs)) + ' 个文件' if errs else '通过'}")

    print("\n  [2/4] pytest 全量 (离线, 占位令牌)", flush=True)
    code, lines = _run_stream([python, "-m", "pytest", "tests", "-q", "-rfE", "--tb=short"],
                              app, env, PYTEST_TIMEOUT)
    tail = next((l for l in reversed(lines) if " in " in l and ("passed" in l or "failed" in l or "error" in l)), "")
    summary.append(f"pytest: {tail.strip('= ').strip() or '退出码 ' + str(code)}")
    if code != 0:
        items = [l for l in lines if l.startswith(("FAILED ", "ERROR "))]
        failures += [f"pytest: {l}" for l in items] or [f"pytest: 退出码 {code}, 见上方输出"]

    print("\n  [3/4] 生产就绪契约 (production_check --code-only)", flush=True)
    code, lines = _run_stream([python, "engines/production_check.py", "--code-only"], app, env, NODE_TIMEOUT)
    summary.append(f"production_check: {'通过' if code == 0 else '失败'}")
    if code != 0:
        failures.append(f"production_check: 退出码 {code}, 见上方输出")

    print("\n  [4/4] 前端测试 (tests/*.cjs)", flush=True)
    cjs = sorted((app / "tests").glob("*.cjs"))
    if not node:
        failures.append("前端测试: 找不到 node, 无法运行 (需安装 Node.js 或用跳过开关)")
        summary.append("前端: 未运行 (缺 node)")
    else:
        bad = []
        for f in cjs:
            rel = f.relative_to(app).as_posix()
            try:
                r = subprocess.run([node, rel], cwd=app, env=env, capture_output=True, timeout=NODE_TIMEOUT)
                ok = r.returncode == 0
                out = (r.stdout + r.stderr).decode("utf-8", errors="replace").strip()
            except subprocess.TimeoutExpired:
                ok, out = False, "超时"
            print(f"    {'通过' if ok else '失败'}  {rel}", flush=True)
            if not ok:
                bad.append(rel)
                text = [l for l in out.splitlines() if l.strip()]
                key = [l for l in text if "Error" in l or "assert" in l.lower()][:3]
                for l in key or text[-3:]:
                    print(f"          {l}", flush=True)
        failures += [f"前端: {b}" for b in bad]
        summary.append(f"前端: {len(cjs) - len(bad)}/{len(cjs)} 通过")
    return {"failures": failures, "summary": summary}


# ── 主流程 ───────────────────────────────────────────────────────────

def main(argv: list[str] | None = None, *, runner=run_suite, interactive: bool | None = None) -> int:
    ap = argparse.ArgumentParser(description="AlphaCore 推送前检查")
    ap.add_argument("--repo", default=".")
    ap.add_argument("--remote", default="origin")
    ap.add_argument("--branch", default="main")
    ap.add_argument("--log", default=None, help="本次推送日志 (追加)")
    ap.add_argument("--skip-log", default=None, help="常设的跳过记录 (追加)")
    ap.add_argument("--msg", default="update: daily update", help="默认提交说明")
    ap.add_argument("--msg-out", default=None, help="最终提交说明写到这里 (一键推送.bat 用 git commit -F)")
    a = ap.parse_args(argv)

    repo = Path(a.repo).resolve()
    log = Logger(a.log)
    if interactive is None:
        interactive = sys.stdin is not None and sys.stdin.isatty()
    msg = a.msg

    def write_msg() -> None:
        if a.msg_out:
            Path(a.msg_out).parent.mkdir(parents=True, exist_ok=True)
            Path(a.msg_out).write_text(msg + "\n", encoding="utf-8")

    print("\n  ── 推送前检查 ──", flush=True)

    # 1. 暂存区为空: 列出将加入的全部文件, 输入 A 才加入
    staged = staged_files(repo)
    changes = worktree_changes(repo)
    if not staged and changes:
        print("\n  暂存区为空。工作区有以下改动 (输入 A 将全部加入本次提交):", flush=True)
        for st, p in changes:
            print(f"    {st}  {p}", flush=True)
        ans = ask("\n  输入 A 全部加入; 直接回车不加入: ", interactive)
        if ans.upper() == "A":
            git(repo, "add", "-A")
            log(f"pre-push: 用户选择全部加入 ({len(changes)} 个文件)")
            print("  已全部加入。", flush=True)
            staged = staged_files(repo)
            changes = worktree_changes(repo)
        else:
            log("pre-push: 暂存区为空, 用户未选择全部加入")

    if staged:
        print(f"\n  本次提交 {len(staged)} 个文件:", flush=True)
        for p in staged:
            print(f"    {p}", flush=True)

    # 没有要推送的内容: 不确认、不测试
    ahead = ahead_count(repo, a.remote, a.branch)
    if not staged and ahead == 0:
        print("\n  没有要提交或推送的内容, 不跑测试。", flush=True)
        log("pre-push: 无提交内容, 未跑测试")
        return 0

    # 2. 未加入本次提交的代码文件: 输入 YES 才继续
    left_code = [(st, p) for st, p in changes if is_code_file(p)]
    left_other = [(st, p) for st, p in changes if not is_code_file(p)]
    if left_other:
        print(f"\n  另有 {len(left_other)} 个非代码文件未加入 (仅提示):", flush=True)
        for st, p in left_other[:20]:
            print(f"    {st}  {p}", flush=True)
        if len(left_other) > 20:
            print(f"    …… 另 {len(left_other) - 20} 个", flush=True)
    if left_code:
        print(f"\n  [注意] 以下 {len(left_code)} 个代码文件已修改或新建, 但不在本次提交里:", flush=True)
        for st, p in left_code:
            print(f"    {st}  {p}", flush=True)
        print("  若其中有本次改动需要的文件, 请中止, 用 git add 加入后重新运行。", flush=True)
        ans = ask("\n  确认这些文件不随本次提交: 输入 YES 继续, 其他任意输入中止: ", interactive)
        if ans != "YES":
            log(f"pre-push: 中止, 有 {len(left_code)} 个代码文件未加入: " + ", ".join(p for _, p in left_code))
            print("\n  [中止] 未确认未加入的代码文件。没有提交, 没有推送。", flush=True)
            return 1
        log(f"pre-push: 用户确认 {len(left_code)} 个代码文件不随本次提交: " + ", ".join(p for _, p in left_code))

    # 3. 暂存区为空但本地有未推送的提交: 测这些提交的内容 (暂存区 = HEAD)
    if not staged:
        print(f"\n  暂存区为空, 本地已有 {ahead} 个未推送的提交; 测试这些提交的内容。", flush=True)

    # 4. 跳过开关
    if os.environ.get("ALPHACORE_SKIP_TESTS", "").strip() == "1":
        reason = os.environ.get("ALPHACORE_SKIP_REASON", "").strip()
        if not reason:
            print("\n  [中止] 设置了 ALPHACORE_SKIP_TESTS=1, 但没写 ALPHACORE_SKIP_REASON (跳过原因)。", flush=True)
            log("pre-push: 中止, 跳过开关缺少原因")
            return 1
        head = git(repo, "rev-parse", "--short", "HEAD", check=False).stdout.decode().strip()
        line = (f"跳过测试 | 原因: {reason} | 暂存 {len(staged)} 个文件 | 未推送提交 {ahead} 个 | "
                f"HEAD {head} | 文件: " + ", ".join(staged[:50]))
        print("\n  ************************************************", flush=True)
        print("  [警告] 已用跳过开关, 本次不跑测试 (仅限紧急情况)", flush=True)
        print(f"  原因: {reason}", flush=True)
        print("  ************************************************", flush=True)
        log("pre-push: " + line)
        if a.skip_log:
            Logger(a.skip_log)(line)
        if staged:
            msg = f"{msg} [skip-tests: {reason}]"
        else:
            log("pre-push: 提交已在推送前完成, 提交说明无法追加 [skip-tests] 标记 (以日志为准)")
            print("  提交已存在, 提交说明无法追加 [skip-tests] 标记; 已记入推送日志。", flush=True)
        write_msg()
        return 0

    # 5. 干净快照测试
    print("\n  导出暂存区快照 (即将提交的内容), 按 CI 步骤测试……", flush=True)
    t0 = time.monotonic()
    tmp = Path(tempfile.mkdtemp(prefix="alphacore_prepush_"))
    try:
        export_snapshot(repo, tmp / "snap")
        app = tmp / "snap" / APP_SUBDIR
        if not app.is_dir():
            print(f"  [中止] 快照中没有 {APP_SUBDIR}/ 目录", flush=True)
            return 1
        result = runner(app, sys.executable, shutil.which("node"))
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    secs = int(time.monotonic() - t0)

    print("\n  ── 推送前检查结果 ──", flush=True)
    for s in result["summary"]:
        print(f"    {s}", flush=True)
    log(f"pre-push: 快照测试 {secs}s | " + " | ".join(result["summary"]))
    if result["failures"]:
        print(f"\n  [中止] {len(result['failures'])} 项失败, 没有提交, 没有推送:", flush=True)
        for f in result["failures"]:
            print(f"    {f}", flush=True)
            log(f"pre-push: 失败 {f}")
        return 1
    print(f"\n  全部通过 ({secs} 秒)。", flush=True)
    write_msg()
    return 0


if __name__ == "__main__":
    sys.exit(main())
