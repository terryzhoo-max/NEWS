"""
数据质量审计 #5 诊断: V6-A 阈值在"包含 / 排除市值或 M2 降级月份"两种情况下的差异。只读, 不写任何文件。

用法 (项目目录下, 先关掉本机服务):
    .venv\\Scripts\\python _dev_tools\\check_aiae_v6_history.py
"""
import csv
import os
import sys
from datetime import datetime

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
os.chdir(ROOT)
os.environ.setdefault("PYTEST_CURRENT_TEST", "diagnostic")  # 引擎内的写文件逻辑在此标记下跳过

import pandas as pd  # noqa: E402

from engines.aiae_engine import AIAEEngine, v6_thresholds_from_values  # noqa: E402

PARQUET = os.path.join("data_lake", "aiae_true_history.parquet")
FWD_LOG = os.path.join("data_lake", "aiae_v6_forward_log.csv")


def regime_of(x, th, buf=0.0):
    for i, t in enumerate(th):
        if x < t:
            return i + 1
    return len(th) + 1


def main():
    df = pd.read_parquet(PARQUET)
    flag = df.get("mv_is_fallback", False) | df.get("m2_is_fallback", False)
    bad = df[flag]
    print(f"月末历史: {len(df)} 个月 ({df['month'].min()} ~ {df['month'].max()})")
    print(f"市值或 M2 为降级值的月份: {len(bad)} 个")
    if len(bad):
        cols = [c for c in ["month", "total_mv_wan_yi", "m2_wan_yi", "aiae_simple", "mv_is_fallback", "m2_is_fallback"] if c in bad.columns]
        print(bad[cols].to_string(index=False))
    q = df["data_quality"].value_counts().to_dict() if "data_quality" in df.columns else {}
    print(f"data_quality 分布: {q}")

    eng = AIAEEngine.__new__(AIAEEngine)
    cur = datetime.now().strftime("%Y-%m")
    out = {}
    for label, excl in (("包含降级月份 (旧)", False), ("排除降级月份 (新)", True)):
        vals, meta = eng._v6_monthly_values(cur, exclude_fallback=excl)
        res = v6_thresholds_from_values(vals)
        out[label] = res
        print(f"\n[{label}] 样本 {len(vals)} 个月 ({meta.get('first')} ~ {meta.get('through')}), "
              f"排除 {meta.get('excluded_fallback', 0)} 个")
        print(f"  阈值 {res and res['thresholds']}  缓冲 {res and res['buffer']}")

    if os.path.exists(FWD_LOG):
        with open(FWD_LOG, encoding="utf-8-sig") as f:  # 文件可能带 BOM
            rows = list(csv.DictReader(f))
        if rows:
            last = rows[-1]
            x = float(last["aiae_simple"])
            print(f"\n最近一次前向记录 {last['trade_date']}: AIAE_简 {x}, 实盘 V6 档位 {last['v6_regime']} / 仓位 {last['v6_position']}")
            for label, res in out.items():
                if res:
                    print(f"  按 {label} 阈值: 第 {regime_of(x, res['thresholds'])} 档")


if __name__ == "__main__":
    main()
