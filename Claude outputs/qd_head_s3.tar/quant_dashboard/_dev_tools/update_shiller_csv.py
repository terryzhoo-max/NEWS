"""
把 Shiller 的 ie_data.xls 转成仓库内的精简 CSV (data/shiller_us_monthly.csv)。

用法 (项目目录下):
    .venv\\Scripts\\python _dev_tools\\update_shiller_csv.py [ie_data.xls 路径]

默认读取 data_lake/ie_data.xls。Shiller 数据约每月更新一次:
  1. 打开 https://shillerdata.com/ , 下载 "ie_data (xls)"
  2. 放到 data_lake/ie_data.xls
  3. 运行本脚本, 然后照常推送 (CSV 入库, 服务器随代码更新)

data_lake/ 不入库也不进 Docker 镜像, 所以服务器读的是 data/ 下的 CSV。
"""
import os
import sys

import pandas as pd

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DEFAULT_XLS = os.path.join(ROOT, "data_lake", "ie_data.xls")
OUT_CSV = os.path.join(ROOT, "data", "shiller_us_monthly.csv")

# 表头文本 → 输出列名 (按表头匹配, 不依赖列位置)
WANTED = {
    "date": "month", "p": "price", "d": "dividend", "e": "earnings", "cpi": "cpi",
    "rate gs10": "gs10", "real total return price": "real_tr_price", "cape": "cape",
}


def _norm(x) -> str:
    return " ".join(str(x).replace("\n", " ").split()).strip().lower()


def convert(raw: pd.DataFrame) -> pd.DataFrame:
    """raw: 'Data' 工作表的原始单元格 (header=None)。"""
    header_row = None
    for i in range(min(30, len(raw))):
        cells = [_norm(v) for v in raw.iloc[i].tolist()]
        if "date" in cells and "p" in cells and "e" in cells:
            header_row = i
            break
    if header_row is None:
        raise ValueError("找不到表头行 (Date / P / E)")

    cols = {}
    for j, v in enumerate(raw.iloc[header_row].tolist()):
        # 表头可能跨多行 (如 "Real" / "Total" / "Return" / "Price"), 依次向上拼接 0~3 行再匹配
        parts = [_norm(raw.iloc[r, j]) for r in range(max(0, header_row - 3), header_row + 1)]
        parts = [x for x in parts if x and x != "nan"]
        cands = [" ".join(parts[-k:]) for k in range(1, len(parts) + 1)]
        for cand in cands:
            if cand in WANTED and WANTED[cand] not in cols.values():
                cols[j] = WANTED[cand]
                break
    missing = set(WANTED.values()) - set(cols.values())
    if missing - {"real_tr_price", "cape"}:
        raise ValueError(f"缺少必要列: {sorted(missing)}")

    body = raw.iloc[header_row + 1:, list(cols)].copy()
    body.columns = [cols[j] for j in cols]
    body = body[pd.to_numeric(body["month"], errors="coerce").notna()]
    d = pd.to_numeric(body["month"]).round(2)
    year = d.astype(int)
    month = ((d - year) * 100).round().astype(int)  # 1871.1 = 10 月
    body = body[(month >= 1) & (month <= 12)]
    body["month"] = [f"{y:04d}-{m:02d}" for y, m in zip(year[body.index], month[body.index])]
    for c in body.columns:
        if c != "month":
            body[c] = pd.to_numeric(body[c], errors="coerce")
    body = body.dropna(subset=["price"]).drop_duplicates("month", keep="last")
    return body.reset_index(drop=True)


def main(xls_path: str = DEFAULT_XLS) -> None:
    raw = pd.read_excel(xls_path, sheet_name="Data", header=None)
    out = convert(raw)
    os.makedirs(os.path.dirname(OUT_CSV), exist_ok=True)
    out.to_csv(OUT_CSV, index=False, float_format="%.6g")
    last_e = out.dropna(subset=["earnings"])["month"].iloc[-1]
    print(f"写入 {OUT_CSV}: {len(out)} 行, {out['month'].iloc[0]} ~ {out['month'].iloc[-1]}, "
          f"最新 EPS 月份 {last_e}")


if __name__ == "__main__":
    main(sys.argv[1] if len(sys.argv) > 1 else DEFAULT_XLS)
