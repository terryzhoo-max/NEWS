import tushare as ts
import pandas as pd
from datetime import datetime, timedelta

# Tushare token: 从环境变量读取 (不再内置; 缺少时直接退出, 不回退到旧值)
import os
try:
    from dotenv import load_dotenv
    load_dotenv(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", ".env"))
except ImportError:
    pass
TUSHARE_TOKEN = os.environ.get("TUSHARE_TOKEN", "").strip()
if not TUSHARE_TOKEN:
    raise SystemExit("缺少环境变量 TUSHARE_TOKEN: 请在 .env 或系统环境变量中配置 (本脚本不再内置密钥)")
ts.set_token(TUSHARE_TOKEN)
pro = ts.pro_api()
today_str = datetime.now().strftime('%Y%m%d')
start_str = (datetime.now() - timedelta(days=60)).strftime('%Y%m%d')

print("--- Margin (Financing) ---")
# margin_detail for SSE/SZSE
try:
    df_margin = pro.margin_detail(trade_date=today_str)
    print(df_margin.head())
except:
    print("No margin data for today yet.")

print("\n--- AH Premium ---")
try:
    df_ah = pro.index_daily(ts_code='HSAHP.HI', start_date=start_str, end_date=today_str)
    print(df_ah.head())
except:
    print("No AH Premium data.")

print("\n--- HK Daily (Short Sell) ---")
try:
    # Check if hk_daily has short sell info
    df_hk = pro.hk_daily(ts_code='0700.HK', start_date=start_str, end_date=today_str)
    print(df_hk.columns)
except:
    print("No HK Daily columns found.")
