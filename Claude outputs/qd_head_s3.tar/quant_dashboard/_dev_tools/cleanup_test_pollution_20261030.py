"""
一次性清理: 测试写入真实库的残留数据 (2026-10-30)
=================================================
背景: 测试曾把 services.db 指回真实 services/data_lake/alphacore.db (已于 2026-10-30 修复),
     每跑一次全量测试, trades 表就多出几十条测试记录; AIAE 冷启动种子也覆盖了
     data_lake/aiae_monthly_history.json。

判定规则 (依据 2026-10-30 对真实库的逐条核对, 不按日期一刀切):
  trades 表只保留"真实的券商持仓导入日志":
    action = 'import' 且 message 不是测试夹具固定文本 "导入 1 只持仓，可用资金 ¥10,000.00"
  其余全部删除 —— 测试固定使用的代码 000001.SZ / 999999.SZ / NONEXIST.SZ / X,
  以及 reset / test 动作, 都不是真实交易 (真实成交记在 trade_ledger.json / 账户台账, 不在此表)。
  10-30 核对: 1093 行中真实导入日志 13 行 (16-26 只持仓、真实可用资金), 其余均为测试。

aiae_monthly_history.json 只是 SQLite aiae_monthly 表的备份 (服务读取时 SQLite 优先),
用 SQLite 真实数据重建, 旧文件另存为 .bak。

用法 (项目根目录; 服务运行中也可执行, 备份用 SQLite 在线备份 API):
    .venv\\Scripts\\python.exe _dev_tools\\cleanup_test_pollution_20261030.py           # 只预览, 不改动
    .venv\\Scripts\\python.exe _dev_tools\\cleanup_test_pollution_20261030.py --apply   # 先备份, 再清理
"""
from __future__ import annotations

import argparse
import json
import os
import shutil
import sqlite3
import sys
from collections import Counter
from datetime import datetime

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DB_PATH = os.path.join(os.path.abspath(os.environ.get("ALPHACORE_DB_DIR")
                                       or os.path.join(ROOT, "services", "data_lake")), "alphacore.db")
AIAE_JSON = os.path.join(ROOT, "data_lake", "aiae_monthly_history.json")
TEST_IMPORT_MSG = "导入 1 只持仓，可用资金 ¥10,000.00"
KEEP_WHERE = "action = 'import' AND message NOT LIKE ?"
KEEP_ARGS = (f"%{TEST_IMPORT_MSG}%",)

if sys.platform == "win32":
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass


def plan(conn: sqlite3.Connection) -> dict:
    total = conn.execute("SELECT COUNT(*) FROM trades").fetchone()[0]
    keep = conn.execute(f"SELECT timestamp, message FROM trades WHERE {KEEP_WHERE} ORDER BY timestamp",
                        KEEP_ARGS).fetchall()
    drop = conn.execute(f"SELECT action, ts_code FROM trades WHERE NOT ({KEEP_WHERE})", KEEP_ARGS).fetchall()
    return {"total": total, "keep": keep, "drop_count": len(drop),
            "drop_breakdown": Counter((a, c) for a, c in drop).most_common()}


def aiae_rows(conn: sqlite3.Connection) -> list[dict]:
    cols = [r[1] for r in conn.execute("PRAGMA table_info(aiae_monthly)").fetchall()]
    rows = conn.execute("SELECT * FROM aiae_monthly ORDER BY month").fetchall()
    out = []
    for r in rows:
        d = dict(zip(cols, r))
        d.pop("id", None)
        out.append({k: v for k, v in d.items() if v is not None})
    return out


def main(argv=None) -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--apply", action="store_true", help="执行清理 (默认只预览)")
    args = ap.parse_args(argv)

    if not os.path.exists(DB_PATH):
        print(f"找不到数据库: {DB_PATH}")
        return 1
    conn = sqlite3.connect(DB_PATH, timeout=30)
    conn.execute("PRAGMA busy_timeout=30000")

    p = plan(conn)
    print(f"数据库: {DB_PATH}")
    print(f"trades 表共 {p['total']} 行 → 保留 {len(p['keep'])} 行真实导入日志, 删除 {p['drop_count']} 行")
    print("\n保留:")
    for ts, msg in p["keep"]:
        print(f"  {ts}  {msg}")
    print("\n删除明细 (动作, 代码, 行数):")
    for (a, c), n in p["drop_breakdown"]:
        print(f"  {a:8s} {c:14s} {n}")

    aiae = aiae_rows(conn)
    print(f"\naiae_monthly_history.json 将按 SQLite 重建为 {len(aiae)} 条: "
          + ", ".join(f"{r['month']}={r.get('aiae_v1')}/R{r.get('regime')}" for r in aiae))

    if not args.apply:
        print("\n[预览] 未做任何改动。确认无误后加 --apply 执行。")
        return 0

    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup = os.path.join(os.path.dirname(DB_PATH), f"alphacore_backup_{stamp}_before_cleanup.db")
    dst = sqlite3.connect(backup)
    conn.backup(dst)          # 在线一致性备份 (含未合并的 WAL)
    dst.close()
    chk = sqlite3.connect(backup)
    n_backup = chk.execute("SELECT COUNT(*) FROM trades").fetchone()[0]
    chk.close()
    if n_backup != p["total"]:
        print(f"备份校验失败 (备份 {n_backup} 行 ≠ 当前 {p['total']} 行), 中止, 未做任何删除")
        return 2
    print(f"\n已备份数据库 → {backup} (trades {n_backup} 行, 校验通过)")

    with conn:                # 单一事务: 失败自动回滚
        cur = conn.execute(f"DELETE FROM trades WHERE NOT ({KEEP_WHERE})", KEEP_ARGS)
        deleted = cur.rowcount
    remain = conn.execute("SELECT COUNT(*) FROM trades").fetchone()[0]
    print(f"已删除 {deleted} 行, trades 剩余 {remain} 行")
    if remain != len(p["keep"]):
        print("⚠️ 剩余行数与预览不一致 (可能清理期间服务写入了新记录), 请核对")

    if os.path.exists(AIAE_JSON):
        shutil.copy2(AIAE_JSON, f"{AIAE_JSON}.{stamp}.bak")
    tmp = AIAE_JSON + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(aiae, f, ensure_ascii=False, indent=2)
    os.replace(tmp, AIAE_JSON)
    print(f"已重建 {AIAE_JSON} ({len(aiae)} 条), 旧文件另存为 .{stamp}.bak")
    conn.close()
    print("\n完成。如需恢复: 停止服务后用备份文件替换 alphacore.db。")
    return 0


if __name__ == "__main__":
    sys.exit(main())
