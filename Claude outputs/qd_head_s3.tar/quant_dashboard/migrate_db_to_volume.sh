#!/bin/bash
# ============================================================
#  F5 (2026-10-27): 旧版容器内主库 → 持久卷 一次性迁移
#  旧版主库位于容器内 /app/services/data_lake/alphacore.db (未挂载, 容器重建即丢失);
#  新版通过 ALPHACORE_DB_DIR=/app/data_lake/db 写入宿主机 ./data_lake/db (已挂载)。
#  规则: 宿主机已有主库 → 跳过 (绝不覆盖); 旧容器未运行或无主库 → 跳过;
#        否则在旧容器内用 sqlite backup API 在线复制, 并做 integrity_check。
#  用法: 在应用目录执行  bash migrate_db_to_volume.sh [容器名]
#  须在 docker compose down / docker rm 之前执行 (deploy.sh / update.sh 已调用)。
# ============================================================
set -e
CONTAINER="${1:-quant_dashboard_app}"
HOST_DB_DIR="data_lake/db"

mkdir -p "$HOST_DB_DIR"
chown 1000:1000 "$HOST_DB_DIR" 2>/dev/null || true

if [ -f "$HOST_DB_DIR/alphacore.db" ]; then
    echo "✅ 持久卷已有主库 ($HOST_DB_DIR/alphacore.db), 跳过迁移"
    exit 0
fi
if ! docker ps --format '{{.Names}}' | grep -qx "$CONTAINER"; then
    echo "ℹ️  旧容器 $CONTAINER 未运行, 无可迁移的容器内主库 (新容器将在持久卷新建主库)"
    exit 0
fi

docker exec -i "$CONTAINER" python - <<'PY'
import os, sqlite3, sys
src = "/app/services/data_lake/alphacore.db"
dst = "/app/data_lake/db/alphacore.db"
if not os.path.exists(src):
    print("ℹ️  旧容器内没有主库, 跳过")
    sys.exit(0)
if os.path.exists(dst):
    print("✅ 持久卷已有主库, 不覆盖")
    sys.exit(0)
s = sqlite3.connect(f"file:{src}?mode=ro", uri=True)
d = sqlite3.connect(dst)
s.backup(d)
ok = d.execute("PRAGMA integrity_check").fetchone()[0]
tables = d.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'").fetchall()
counts = {t: d.execute(f'SELECT COUNT(*) FROM "{t}"').fetchone()[0] for (t,) in tables}
d.close(); s.close()
print(f"主库迁移: integrity={ok} 行数={counts}")
sys.exit(0 if ok == "ok" else 2)
PY
echo "✅ 容器内主库已复制到持久卷 $HOST_DB_DIR/alphacore.db"
