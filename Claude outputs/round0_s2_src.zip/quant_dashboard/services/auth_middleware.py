"""
AlphaCore · API Key 认证中间件
================================
Batch 6 安全加固: 保护所有写入操作 (POST/PUT/DELETE)
2026-11-04 读取鉴权 (docs/ACCOUNT_AUTHORITY_AND_RISK_REFRESH_PLAN.md 1.4 续): /api/ 下的读取也要凭据。

规则:
  - POST/PUT/DELETE 请求: 必须携带 X-API-Key header
  - GET/HEAD 读取 /api/*: 读取鉴权开启时 (默认开启) 必须携带 X-API-Key; 页面 / 静态文件 / sw.js /
    manifest.json / /version 不在 /api/ 下, 不受影响
  - 读取鉴权开启时, 原先免认证的 POST 前缀 (_PUBLIC_PREFIXES) 也要凭据 (前端自动带令牌)
  - OPTIONS (CORS 预检), /health, /docs, /redoc, /openapi.json: 始终免认证
  - API Key 从环境变量 API_SECRET_KEY 读取 (与写入共用同一个令牌)
  - 临时关闭读取鉴权: 环境变量 ALPHACORE_READ_AUTH=0 (每次请求读取; 写入鉴权不受影响)

用法:
    from services.auth_middleware import ApiKeyMiddleware
    app.add_middleware(ApiKeyMiddleware)
"""

import os
import secrets
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import JSONResponse
from services.logger import get_logger

logger = get_logger("auth")

# 从环境变量读取 API Key (生产环境必须设置)
API_SECRET_KEY = os.getenv("API_SECRET_KEY", "")
_IS_PRODUCTION = os.getenv("ALPHACORE_ENV", "development").lower() in ("production", "prod")

# P1-1: 启动时强制提醒 API Key 未配置风险
if not API_SECRET_KEY:
    _level = "CRITICAL" if _IS_PRODUCTION else "WARNING"
    logger.log(
        50 if _IS_PRODUCTION else 30,
        "⚠️ API_SECRET_KEY 未设置! %s。请在 .env 中配置 API_SECRET_KEY。",
        "生产模式下所有写入操作将被拒绝" if _IS_PRODUCTION else "开发模式下写入操作将免认证放行",
    )

# 始终免认证的路径 (精确匹配)
_PUBLIC_PATHS = {
    "/health",
    "/docs",
    "/redoc",
    "/openapi.json",
}

# 始终免认证的路径前缀
_PUBLIC_PREFIXES = (
    "/docs",
    "/redoc",
    "/api/v1/decision/alerts",      # V21.2: 预警已读操作 (前端用户按钮)
    "/api/v1/decision/simulate",    # V23.0: 情景模拟 (纯数学推演, 无副作用)
    "/api/v1/decision/shock",       # V23.0: 冲击传播 (纯数学推演, 无副作用)
    "/api/v1/decision/param-snapshot",  # V23.0: 参数快照 (用户操作)
    "/api/v1/decision/narrative",   # V8.2: 叙事报告重新生成 (仪表盘按钮)
    "/api/v1/intelligence/scan",    # V8.1: 情报扫描 (仪表盘内置按钮触发)
    "/api/v1/assistant/chat",       # V27.0: AI 助手对话 (前端用户交互, 无副作用)
)

# 读取方法 (读取鉴权开启时 /api/ 下也要凭据); OPTIONS 是 CORS 预检, 浏览器不带自定义头, 始终放行
_SAFE_METHODS = {"GET", "HEAD", "OPTIONS"}
_READ_METHODS = {"GET", "HEAD"}
_API_PREFIX = "/api/"

READ_AUTH_ENV = "ALPHACORE_READ_AUTH"
_READ_AUTH_OFF = {"0", "false", "off", "no"}


def read_auth_enabled() -> bool:
    """读取鉴权是否开启: 默认开启; ALPHACORE_READ_AUTH=0/false/off/no 临时关闭。每次调用读取环境变量。"""
    return str(os.environ.get(READ_AUTH_ENV, "1") or "1").strip().lower() not in _READ_AUTH_OFF


def read_auth_status() -> str:
    """启动日志 / 部署核对用的一句话。"""
    if not read_auth_enabled():
        return f"读取鉴权: 已关闭 ({READ_AUTH_ENV}=0), /api/ 读取免凭据; 写入鉴权照常"
    if not API_SECRET_KEY:
        return ("读取鉴权: 开启, 但 API_SECRET_KEY 未设置 → "
                + ("生产模式 /api/ 读取一律 503" if _IS_PRODUCTION else "开发模式放行 (仅本机开发)"))
    return "读取鉴权: 开启, /api/ 读取需 X-API-Key (/health 与页面除外)"


def _needs_key(method: str, path: str) -> bool:
    """这次请求是否需要凭据。"""
    if method == "OPTIONS" or path in _PUBLIC_PATHS:
        return False
    read_auth = read_auth_enabled()
    if method in _READ_METHODS:
        return read_auth and path.startswith(_API_PREFIX)
    if path.startswith(_PUBLIC_PREFIXES):
        return read_auth                 # 读取鉴权开启时, 原免认证 POST 也要凭据
    return True


_warned_dev_read = False


class ApiKeyMiddleware(BaseHTTPMiddleware):
    """
    API Key 认证中间件

    保护写入操作 (POST/PUT/DELETE); 读取鉴权开启时 (默认) 也保护 /api/ 下的 GET/HEAD。
    页面、静态文件、/health 不受影响。
    """

    async def dispatch(self, request: Request, call_next):
        global _warned_dev_read
        path = request.url.path
        # 1-2. 不需要凭据: OPTIONS / 公开路径 / 页面与静态文件 / 读取鉴权关闭时的读取与公开 POST
        if not _needs_key(request.method, path):
            return await call_next(request)

        # 3. 检查 API Key 是否已配置
        if not API_SECRET_KEY:
            # P1-1: 生产环境 fail-closed — 拒绝所有未认证写入
            if _IS_PRODUCTION:
                logger.error(
                    "生产模式 API_SECRET_KEY 未配置, 拒绝写入: %s %s",
                    request.method, path,
                )
                return JSONResponse(
                    status_code=503,
                    content={
                        "status": "error",
                        "message": "服务未正确配置认证密钥，写入与 /api/ 读取不可用。",
                    },
                )
            # 开发模式: 放行但记录警告 (读取只警告一次, 避免日志刷屏)
            if request.method in _READ_METHODS:
                if not _warned_dev_read:
                    _warned_dev_read = True
                    logger.warning("API_SECRET_KEY 未设置! /api/ 读取未经认证放行 (开发模式, 只提示一次)。")
            else:
                logger.warning(
                    "API_SECRET_KEY 未设置! 写入操作 %s %s 未经认证放行 (开发模式)。",
                    request.method, path,
                )
            return await call_next(request)

        # 4. 校验 X-API-Key header
        provided_key = request.headers.get("X-API-Key", "")
        if not provided_key:
            logger.warning(f"拒绝未认证请求: {request.method} {path} (缺少 X-API-Key)")
            return JSONResponse(
                status_code=401,
                content={
                    "status": "unauthorized",
                    "message": "缺少 X-API-Key 请求头。请在 header 中携带有效的 API Key。",
                },
            )

        # 使用 secrets.compare_digest 防止时序攻击
        if not secrets.compare_digest(provided_key, API_SECRET_KEY):
            logger.warning(f"拒绝无效 API Key: {request.method} {path}")
            return JSONResponse(
                status_code=403,
                content={
                    "status": "forbidden",
                    "message": "API Key 无效。",
                },
            )

        # 5. 认证通过
        return await call_next(request)


def generate_api_key(length: int = 48) -> str:
    """生成一个安全的随机 API Key (供首次配置使用)"""
    return secrets.token_urlsafe(length)
