"""
AlphaCore · 历史成交导入 (通达信 / 券商客户端导出)
=================================================

职责
----
1. 字节 → 文本: 自动识别 UTF-8(BOM) / GBK / GB18030, 并拦截"已被转码损坏"的文件
   (典型: GBK 文件被当作 UTF-8 打开后另存, 中文变成 � 或 "锟斤拷", 买卖方向不可恢复)。
2. 文本 → 成交记录: 支持三种版式
     - 定宽空格对齐 (通达信 "历史成交" 默认导出, 按 GBK 显示宽度切列, 空列不错位)
     - Tab 分隔 (部分券商 .xls 实为 TSV)
     - 逗号分隔 CSV
   列头按别名映射, 兼容 "历史成交" 与 "交割单" (含手续费/印花税/发生金额)。
3. 业务分类: 买入 / 卖出 / 新股中签 / ETF 申赎 / 逆回购 / 红利 等;
   非持仓类 (逆回购, 红利, 资金划转) 只计数不入持仓。
4. 成交台账 data_lake/trade_ledger.json: 追加去重, 重复导入同一文件幂等。
5. 与券商持仓快照对账 (reconcile_positions): 推出每只持仓的"本轮建仓日"
   (跟踪止盈的高水位锚点), 并标记期初持仓 / 对账不平。

设计原则: 宁可报错, 不可静默算错。方向未知的行一律进入 errors, 不猜。
"""
from __future__ import annotations

import csv
import hashlib
import io
import json
import os
import re
import unicodedata
from dataclasses import dataclass, field, asdict
from datetime import datetime
from typing import Any, Iterable, Mapping, Optional

from services.logger import get_logger

logger = get_logger("ac.trade_import")

_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
LEDGER_PATH = os.path.join(_ROOT, "data_lake", "trade_ledger.json")


class TradeImportError(Exception):
    """可直接展示给用户的导入错误 (code 供前端分支处理)."""

    def __init__(self, message: str, code: str = "ERR_TRADE_IMPORT"):
        super().__init__(message)
        self.code = code


# ═══════════════════════════════════════════════════════
#  ① 编码识别 + 损坏拦截
# ═══════════════════════════════════════════════════════

_CORRUPTION_MARKERS = ("�", "锟斤拷")
_CORRUPTION_HELP = (
    "文件在传输/另存时已被转码损坏 (GBK 被当作 UTF-8 处理), 中文字段与买卖方向已不可恢复。"
    "请在通达信中重新导出 (查询 → 历史成交 → 输出 → 保存为文本文件), "
    "直接上传原始 .txt, 不要经过记事本另存、微信/QQ 转发或在线文档复制。"
)


def decode_broker_bytes(raw: bytes) -> tuple[str, str]:
    """券商导出文件字节 → (文本, 编码)。损坏文件抛 TradeImportError。"""
    if not raw:
        raise TradeImportError("文件为空", "ERR_EMPTY_FILE")

    text: Optional[str] = None
    encoding = ""
    if raw.startswith(b"\xef\xbb\xbf"):
        text, encoding = raw[3:].decode("utf-8", errors="strict"), "utf-8-sig"
    else:
        try:
            text, encoding = raw.decode("utf-8", errors="strict"), "utf-8"
        except UnicodeDecodeError:
            for enc in ("gbk", "gb18030"):
                try:
                    text, encoding = raw.decode(enc, errors="strict"), enc
                    break
                except UnicodeDecodeError:
                    continue
    if text is None:
        raise TradeImportError("无法识别文件编码 (非 UTF-8/GBK/GB18030)。" + _CORRUPTION_HELP,
                               "ERR_ENCODING")

    if any(m in text for m in _CORRUPTION_MARKERS):
        raise TradeImportError(_CORRUPTION_HELP, "ERR_ENCODING_CORRUPTED")
    return text, encoding


# ═══════════════════════════════════════════════════════
#  ② 版式解析
# ═══════════════════════════════════════════════════════

# 规范列名 → 别名 (精确匹配优先, 其次包含匹配)
COLUMN_ALIASES: dict[str, tuple[str, ...]] = {
    "date": ("成交日期", "日期", "发生日期", "交收日期", "清算日期", "业务日期"),
    "time": ("成交时间", "时间", "委托时间"),
    "code": ("证券代码", "代码", "股票代码"),
    "name": ("证券名称", "名称", "股票名称"),
    "side": ("买卖标志", "买卖方向", "操作", "业务名称", "摘要", "委托类别", "交易类别", "买卖类别"),
    "price": ("成交价格", "成交均价", "成交价", "价格"),
    "qty": ("成交数量", "成交股数", "发生数量", "数量"),
    "amount": ("成交金额", "金额"),
    "net_amount": ("发生金额", "清算金额", "收付金额", "资金发生数"),
    "fee_commission": ("手续费", "佣金", "净佣金"),
    "fee_stamp": ("印花税",),
    "fee_transfer": ("过户费",),
    "fee_other": ("其他杂费", "其他费", "其他费用", "规费", "交易所规费", "经手费", "证管费", "结算费"),
    "trade_id": ("成交编号",),
    "order_id": ("委托编号", "合同编号", "申请编号"),
    "account": ("股东代码", "股东帐户", "股东账户", "股东账号"),
    "order_price": ("委托价格",),
    "order_qty": ("委托数量",),
    # 交割单逐笔余额 (券商给出的该行之后的结余): 用于不依赖期初快照的逐笔对账
    "remaining_qty": ("剩余数量", "股份余额", "剩余股数"),
    "remaining_cash": ("剩余金额", "资金余额", "本次余额"),
}
_REQUIRED = ("date", "code", "side", "price", "qty")


def _canon_column(header: str) -> Optional[str]:
    h = header.strip()
    if not h:
        return None
    for key, aliases in COLUMN_ALIASES.items():
        if h in aliases:
            return key
    for key, aliases in COLUMN_ALIASES.items():
        if any(a in h for a in aliases if len(a) >= 2):
            return key
    return None


def _char_width(ch: str) -> int:
    """券商定宽导出按 GBK 字节对齐: 汉字/全角 2, ASCII 1。"""
    if ord(ch) < 128:
        return 1
    try:
        return len(ch.encode("gbk"))
    except UnicodeEncodeError:
        return 2 if unicodedata.east_asian_width(ch) in ("W", "F") else 1


def _tokens_with_offsets(line: str) -> list[tuple[int, str]]:
    """把一行拆成 (显示列起点, 文本) 的非空白片段。"""
    out: list[tuple[int, str]] = []
    col, start, buf = 0, None, []
    for ch in line:
        if ch.isspace() or ch == "　":
            if buf:
                out.append((start, "".join(buf)))
                buf, start = [], None
        else:
            if start is None:
                start = col
            buf.append(ch)
        col += _char_width(ch)
    if buf:
        out.append((start, "".join(buf)))
    return out


def _find_header(lines: list[str]) -> int:
    for i, line in enumerate(lines[:40]):
        if ("代码" in line) and ("成交" in line or "买卖" in line or "操作" in line or "业务" in line):
            return i
    return -1


def _split_fixed_width(header_line: str, data_lines: list[str]) -> tuple[list[str], list[list[str]]]:
    head = _tokens_with_offsets(header_line)
    names = [t for _, t in head]
    starts = [s for s, _ in head]
    rows: list[list[str]] = []
    for line in data_lines:
        cells = [""] * len(names)
        for pos, tok in _tokens_with_offsets(line):
            # 归属到 "起点 ≤ 片段起点(+1 容差)" 的最后一列: 兼容左对齐与右对齐数值
            j = 0
            for k, s in enumerate(starts):
                if s <= pos + 1:
                    j = k
                else:
                    break
            cells[j] = f"{cells[j]} {tok}".strip() if cells[j] else tok
        rows.append(cells)
    return names, rows


def _split_delimited(header_line: str, data_lines: list[str], delim: str) -> tuple[list[str], list[list[str]]]:
    reader = csv.reader(io.StringIO("\n".join([header_line] + data_lines)), delimiter=delim)
    table = [[c.strip().strip('="').strip('"') for c in row] for row in reader]
    return table[0], table[1:]


def _num(s: str) -> Optional[float]:
    if s is None:
        return None
    s = str(s).strip().replace(",", "").replace("¥", "")
    if s in ("", "-", "--"):
        return None
    try:
        return float(s)
    except ValueError:
        return None


def _norm_date(s: str) -> Optional[str]:
    s = (s or "").strip()
    for fmt in ("%Y%m%d", "%Y-%m-%d", "%Y/%m/%d", "%Y.%m.%d"):
        try:
            return datetime.strptime(s, fmt).strftime("%Y-%m-%d")
        except ValueError:
            continue
    return None


# ── 代码 / 市场 ──

_IPO_CODE_MAP = {"787": "688", "730": "600", "780": "601", "732": "603", "707": "605"}


def ts_code_of(code: str, account: str = "") -> str:
    """6 位代码 → ts_code。股东代码优先判断市场 (A/B 开头=沪, 数字开头=深)。"""
    code = (code or "").strip()
    if "." in code:
        return code.upper()
    acct = (account or "").strip().upper()
    if len(code) == 6:
        if code.startswith(("8", "4", "92")) and not code.startswith(("80",)):
            return code + ".BJ"
        if acct[:1] in ("A", "B"):
            return code + ".SH"
        if acct[:1].isdigit():
            return code + ".SZ"
        if code.startswith(("5", "6", "9", "7")):
            return code + ".SH"
        return code + ".SZ"
    if len(code) == 5:
        return code + ".HK"
    return code


def _is_repo(code: str) -> bool:
    return code.startswith("204") or code.startswith("1318")


# ── 业务分类 ──

@dataclass
class Trade:
    date: str
    time: str
    code: str
    ts_code: str
    name: str
    side: str            # buy / sell
    kind: str            # trade / ipo / etf_creation / etf_redemption
    price: float
    qty: int
    amount: float
    fees: Optional[float] = None
    net_amount: Optional[float] = None
    trade_id: str = ""
    order_id: str = ""
    account: str = ""
    raw_side: str = ""
    source: str = ""

    @property
    def key(self) -> str:
        ident = self.trade_id or self.order_id or self.time
        return f"{self.date}|{ident}|{self.ts_code}|{self.side}|{self.qty}|{self.price:.4f}"

    def to_dict(self) -> dict:
        d = asdict(self)
        d["key"] = self.key
        return d


def classify_side(raw_side: str, code: str) -> tuple[str, str]:
    """返回 (category, side)。category ∈ trade/ipo/etf_creation/etf_redemption/repo/cash/unknown."""
    s = (raw_side or "").strip()
    if _is_repo(code) or "回购" in s or "融券" in s:
        return "repo", ""
    if any(k in s for k in ("红利", "股息", "利息", "派息", "扣税", "转账", "银证", "存入", "取出", "划转",
                            "银行转证券", "证券转银行")):
        return "cash", ""
    # 新股上市时把中签股份划入证券账户: 不是买卖, 股份与缴款已由中签/申购行记录 → 单独计数跳过
    if "新股入账" in s or ("入账" in s and "新股" in s):
        return "ipo_credit", ""
    if any(k in s for k in ("中签", "配售", "配号")) or ("申购" in s and ("新股" in s or code[:3] in _IPO_CODE_MAP)):
        return "ipo", "buy"
    if "申购" in s:
        return "etf_creation", "buy"
    if "赎回" in s:
        return "etf_redemption", "sell"
    has_buy, has_sell = "买" in s, "卖" in s
    if has_buy and not has_sell:
        return "trade", "buy"
    if has_sell and not has_buy:
        return "trade", "sell"
    return "unknown", ""


@dataclass
class ParseResult:
    trades: list[Trade] = field(default_factory=list)
    skipped: dict[str, int] = field(default_factory=dict)
    errors: list[str] = field(default_factory=list)
    columns: list[str] = field(default_factory=list)
    layout: str = ""
    encoding: str = ""
    # 阶段2A: 资金类行 (红利/利息/扣税/转账/逆回购) 不入持仓, 但保留给现金台账
    cash_rows: list[dict] = field(default_factory=list)
    has_net_amount: bool = False
    # 新股入账 (股份划转) 行: 不入成交/现金, 仅保留供核对 (代码/数量/日期/编号)
    ipo_credit_rows: list[dict] = field(default_factory=list)
    # 交割单含"剩余数量/剩余金额"列时: 按文件顺序保留每一行的结余 (不论类别), 供逐笔余额对账
    balance_rows: list[dict] = field(default_factory=list)
    has_balances: bool = False

    def summary(self) -> dict:
        dates = sorted(t.date for t in self.trades)
        return {
            "parsed": len(self.trades),
            "buys": sum(1 for t in self.trades if t.side == "buy"),
            "sells": sum(1 for t in self.trades if t.side == "sell"),
            "skipped": dict(self.skipped),
            "errors": self.errors[:50],
            "error_count": len(self.errors),
            "columns": self.columns,
            "layout": self.layout,
            "encoding": self.encoding,
            "date_from": dates[0] if dates else None,
            "date_to": dates[-1] if dates else None,
            "codes": sorted({t.ts_code for t in self.trades}),
            "cash_rows": len(self.cash_rows),
            "has_net_amount": self.has_net_amount,
        }


def parse_trade_text(text: str, source: str = "") -> ParseResult:
    res = ParseResult()
    if any(m in text for m in _CORRUPTION_MARKERS):
        raise TradeImportError(_CORRUPTION_HELP, "ERR_ENCODING_CORRUPTED")

    lines = [l.rstrip("\r") for l in text.replace("\r\n", "\n").split("\n")]
    hi = _find_header(lines)
    if hi < 0:
        raise TradeImportError("未找到列头 (应包含 '证券代码' 与 '成交日期/买卖标志' 等列)。", "ERR_NO_HEADER")
    header_line = lines[hi]
    data_lines = [l for l in lines[hi + 1:] if l.strip() and not set(l.strip()) <= set("-=_ ")]

    if "\t" in header_line:
        names, rows = _split_delimited(header_line, data_lines, "\t")
        res.layout = "tsv"
    elif header_line.count(",") >= 3:
        names, rows = _split_delimited(header_line, data_lines, ",")
        res.layout = "csv"
    else:
        names, rows = _split_fixed_width(header_line, data_lines)
        res.layout = "fixed_width"

    colmap: dict[str, int] = {}
    for i, n in enumerate(names):
        key = _canon_column(n)
        if key and key not in colmap:
            colmap[key] = i
    res.columns = [n for n in names if n]
    missing = [k for k in _REQUIRED if k not in colmap]
    if missing:
        label = {"date": "成交日期", "code": "证券代码", "side": "买卖标志", "price": "成交价格", "qty": "成交数量"}
        raise TradeImportError("缺少必要列: " + "、".join(label[m] for m in missing), "ERR_MISSING_COLUMNS")

    def cell(row: list[str], key: str) -> str:
        i = colmap.get(key)
        return row[i].strip() if i is not None and i < len(row) else ""

    fee_keys = [k for k in ("fee_commission", "fee_stamp", "fee_transfer", "fee_other") if k in colmap]
    res.has_net_amount = "net_amount" in colmap
    res.has_balances = "remaining_qty" in colmap or "remaining_cash" in colmap
    for ln, row in enumerate(rows, start=hi + 2):
        code = re.sub(r"\D", "", cell(row, "code"))
        date = _norm_date(cell(row, "date"))
        raw_side = cell(row, "side")
        category, side = classify_side(raw_side, code)
        if res.has_balances and date:
            bcode = (_IPO_CODE_MAP[code[:3]] + code[3:]) if category == "ipo" and code[:3] in _IPO_CODE_MAP else code
            res.balance_rows.append({
                "line": ln, "date": date, "code": bcode,
                "ts_code": ts_code_of(bcode, cell(row, "account")) if bcode else "",
                "raw_side": raw_side, "category": category, "side": side,
                "qty": _num(cell(row, "qty")), "net_amount": _num(cell(row, "net_amount")),
                "remaining_qty": _num(cell(row, "remaining_qty")),
                "remaining_cash": _num(cell(row, "remaining_cash")),
            })
        # 银证转账等资金行通常没有证券代码: 有日期且属资金类即保留给现金台账
        if date and category in ("repo", "cash"):
            res.skipped[category] = res.skipped.get(category, 0) + 1
            res.cash_rows.append({
                "line": ln, "date": date, "time": cell(row, "time"), "code": code,
                "ts_code": ts_code_of(code, cell(row, "account")) if code else "",
                "raw_side": raw_side, "category": category,
                "net_amount": _num(cell(row, "net_amount")), "amount": _num(cell(row, "amount")),
                "qty": _num(cell(row, "qty")), "ref": cell(row, "trade_id") or cell(row, "order_id"),
            })
            continue
        if category == "ipo_credit":
            res.skipped["ipo_credit"] = res.skipped.get("ipo_credit", 0) + 1
            res.ipo_credit_rows.append({"line": ln, "date": date, "code": code,
                                        "ts_code": ts_code_of(code, cell(row, "account")) if code else "",
                                        "qty": _num(cell(row, "qty")), "raw_side": raw_side,
                                        "ref": cell(row, "trade_id") or cell(row, "order_id")})
            continue
        if not code or not date:
            res.errors.append(f"第{ln}行: 日期或代码无法解析")
            continue
        if category == "unknown":
            res.errors.append(f"第{ln}行: 无法识别买卖方向 '{raw_side}' ({code})")
            continue
        price, qty = _num(cell(row, "price")), _num(cell(row, "qty"))
        if not price or not qty or price <= 0 or qty <= 0:
            res.skipped["zero_qty"] = res.skipped.get("zero_qty", 0) + 1
            continue
        if category == "ipo" and code[:3] in _IPO_CODE_MAP:
            code = _IPO_CODE_MAP[code[:3]] + code[3:]
        amount = _num(cell(row, "amount")) or round(price * qty, 2)
        fees = None
        if fee_keys:
            fees = round(sum(_num(cell(row, k)) or 0.0 for k in fee_keys), 2)
        account = cell(row, "account")
        res.trades.append(Trade(
            date=date,
            time=cell(row, "time") or "",
            code=code,
            ts_code=ts_code_of(code, account),
            name=cell(row, "name"),
            side=side,
            kind=category,
            price=float(price),
            qty=int(round(qty)),
            amount=float(amount),
            fees=fees,
            net_amount=_num(cell(row, "net_amount")),
            trade_id=cell(row, "trade_id"),
            order_id=cell(row, "order_id"),
            account=account,
            raw_side=raw_side,
            source=source,
        ))
    if not res.trades and not res.skipped:
        raise TradeImportError("未解析到任何成交记录", "ERR_NO_ROWS")
    return res


def parse_trade_file(raw: bytes, source: str = "") -> ParseResult:
    text, enc = decode_broker_bytes(raw)
    res = parse_trade_text(text, source=source)
    res.encoding = enc
    return res


# ═══════════════════════════════════════════════════════
#  ③ 成交台账 (追加去重, 原子写)
# ═══════════════════════════════════════════════════════

def load_ledger(path: Optional[str] = None) -> dict:
    path = path or LEDGER_PATH
    if os.path.exists(path):
        try:
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
            if isinstance(data, dict) and isinstance(data.get("trades"), list):
                return data
        except Exception as e:  # 损坏的台账不覆盖, 交给上层报错
            raise TradeImportError(f"成交台账读取失败: {e}", "ERR_LEDGER_CORRUPT")
    return {"version": 1, "trades": [], "imports": []}


def save_ledger(ledger: dict, path: Optional[str] = None) -> None:
    path = path or LEDGER_PATH
    os.makedirs(os.path.dirname(path), exist_ok=True)
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(ledger, f, ensure_ascii=False, indent=1)
    os.replace(tmp, path)


def _sort_key(t: Mapping[str, Any]) -> tuple:
    return (t.get("date", ""), t.get("time", ""), t.get("trade_id", ""), t.get("key", ""))


ENRICHABLE_FIELDS = ("fees", "net_amount")   # 同 key 成交可补全的字段 (其余字段已在 key 中或仅为描述)
_TOL = 0.005


def merge_into_ledger(ledger: dict, trades: Iterable[Trade], meta: Optional[dict] = None) -> dict:
    """追加去重; 同 key 的成交只补全缺失的费用/发生金额, 不覆盖已有值。

    · 补全: 原值为空而新来源有值 → 写入并在该成交的 enrichments 中记录 (字段旧值/新值/来源/时间);
      原 source 不变。
    · 冲突: 两边都有值且不一致 (含成交金额不一致) → 不改动, 登记到 ledger["conflicts"]
      (同一冲突重复导入只登记一次)。
    · 重复导入相同内容: 无任何变化。
    """
    by_key = {t.get("key"): t for t in ledger.get("trades", [])}

    def loose(t):
        return (t.get("date"), t.get("ts_code"), t.get("side"), int(t.get("qty") or 0), round(float(t.get("price") or 0), 4))
    by_loose: dict = {}
    for t in ledger.get("trades", []):
        by_loose.setdefault(loose(t), []).append(t)
    known_conflicts = {(c["key"], c["field"], c["incoming"]) for c in ledger.get("conflicts", [])}
    # 用户已确认为同一笔的疑似重复: 再次导入时按重复处理 (不新增、不再登记冲突、现金结算不记入)
    confirmed_same = {c["incoming"] for c in ledger.get("conflicts", [])
                      if c.get("field") == "possible_duplicate" and (c.get("resolution") or {}).get("decision") == "same"}
    source = (meta or {}).get("file", "")
    now = datetime.now().isoformat(timespec="seconds")
    added = dup = enriched = possible_dup = 0
    conflicts: list[dict] = []
    held_keys: list[str] = []
    for t in trades:
        d = t.to_dict()
        old = by_key.get(d["key"])
        if old is None and d["key"] in confirmed_same:
            dup += 1
            held_keys.append(d["key"])
            continue
        if old is None:
            # 疑似同笔: 来自其他文件、日期/代码/方向/数量/价格相同, 且至少一方无成交编号 (编号不可比)
            # → 不自动新增, 登记待确认 (两边都有编号且不同 = 真实的分笔成交, 正常新增)
            twins = [o for o in by_loose.get(loose(d), []) if o.get("source") != source
                     and (not o.get("trade_id") or not d.get("trade_id"))]
            if twins:
                possible_dup += 1
                held_keys.append(d["key"])
                conflicts.append({"key": d["key"], "field": "possible_duplicate", "existing": twins[0]["key"],
                                  "incoming": d["key"], "source": source,
                                  "existing_source": twins[0].get("source", ""), "at": now,
                                  "note": "疑似与已有成交为同一笔 (成交编号不可比); 未自动新增, 现金结算也未记入, 待人工确认"})
                continue
            by_key[d["key"]] = d
            by_loose.setdefault(loose(d), []).append(d)
            ledger["trades"].append(d)
            added += 1
            continue
        dup += 1
        changes = {}
        checks = [(f, old.get(f), d.get(f)) for f in ENRICHABLE_FIELDS] + [("amount", old.get("amount"), d.get("amount"))]
        for field, ov, nv in checks:
            if nv is None:
                continue
            if ov is None and field in ENRICHABLE_FIELDS:
                changes[field] = {"old": None, "new": nv}
            elif ov is not None and abs(float(ov) - float(nv)) > _TOL:
                c = {"key": d["key"], "field": field, "existing": ov, "incoming": nv, "source": source,
                     "existing_source": old.get("source", ""), "at": now}
                conflicts.append(c)
        if changes:
            for field, ch in changes.items():
                old[field] = ch["new"]
            old.setdefault("enrichments", []).append({"fields": changes, "source": source, "at": now})
            enriched += 1
    new_conflicts = [c for c in conflicts if (c["key"], c["field"], c["incoming"]) not in known_conflicts]
    if new_conflicts:
        ledger.setdefault("conflicts", []).extend(new_conflicts)
    ledger["trades"].sort(key=_sort_key)
    entry = {"at": now, "added": added, "duplicates": dup, "enriched": enriched, "conflicts": len(conflicts),
             "possible_duplicates": possible_dup}
    if meta:
        entry.update(meta)
    ledger.setdefault("imports", []).append(entry)
    ledger["imports"] = ledger["imports"][-50:]
    if conflicts:
        logger.warning("成交台账: %d 处信息冲突未覆盖, 见 ledger.conflicts", len(conflicts))
    return {"added": added, "duplicates": dup, "enriched": enriched, "conflicts": len(conflicts),
            "possible_duplicates": possible_dup, "held_trade_keys": held_keys,
            "conflict_details": conflicts[:50], "total": len(ledger["trades"])}


def confirm_possible_duplicate_same(existing_key: str, reason: str, sources: Mapping[str, bytes],
                                   path: Optional[str] = None) -> dict:
    """用户确认"疑似同笔"确为同一笔: 冲突标记为已解决 (保留原冲突记录与原因);
    用来报方的费用/发生金额补全已有成交 (只补空值, 不覆盖), 现金台账同步补全该笔结算 (enrich 更正)。
    不新增成交、不删除任何记录。sources: 来报文件名 → 原始字节 (用于取回来报行)。"""
    if not reason:
        raise ValueError("确认必须写明原因")
    from services import account_ledger
    ledger = load_ledger(path)
    by_key = {t.get("key"): t for t in ledger.get("trades", [])}
    old = by_key.get(existing_key)
    if old is None:
        raise KeyError(f"未找到成交 {existing_key}")
    pend = [c for c in ledger.get("conflicts", []) if c.get("field") == "possible_duplicate"
            and c.get("existing") == existing_key and not c.get("resolution")]
    now = datetime.now().isoformat(timespec="seconds")
    out = {"resolved": 0, "enriched_fields": [], "cash_enriched": 0, "missing_sources": []}
    apath = account_ledger.ledger_path_for(path or LEDGER_PATH)
    for c in pend:
        raw = sources.get(c.get("source", ""))
        if raw is None:
            out["missing_sources"].append(c.get("source", ""))
            continue
        res = parse_trade_file(raw, source=c["source"])
        inc = next((x for x in res.trades if x.key == c["incoming"]), None)
        if inc is None:
            out["missing_sources"].append(c.get("source", ""))
            continue
        changes = {f: {"old": None, "new": getattr(inc, f)} for f in ENRICHABLE_FIELDS
                   if old.get(f) is None and getattr(inc, f) is not None}
        for f, ch in changes.items():
            old[f] = ch["new"]
        if changes:
            old.setdefault("enrichments", []).append({"fields": changes, "source": c["source"], "at": now,
                                                      "reason": f"用户确认同一笔: {reason}"})
            out["enriched_fields"] += sorted(changes)
        c["resolution"] = {"decision": "same", "reason": reason, "at": now}
        out["resolved"] += 1
        # 现金台账: 以来报行的结算信息补全已有成交的结算事件 (同一事件, 不新增)
        import copy as _copy
        inc2 = _copy.copy(inc)
        pr_ = ParseResult(trades=[inc2])
        evs, _ = account_ledger.events_from_parse(pr_, c["source"], hashlib.sha256(raw).hexdigest())
        if evs and os.path.exists(apath):
            acc = account_ledger.load(apath)
            ev = dict(evs[0])
            ev["event_key"] = "settle:" + account_ledger._fingerprint(("settlement", existing_key))
            ev["trade_key"] = existing_key
            n, _issues = account_ledger._enrich_settlements(acc, [ev], c["source"] + " (用户确认同一笔)",
                                                            hashlib.sha256(raw).hexdigest())
            if n:
                account_ledger.save(acc, apath)
            out["cash_enriched"] += n
    save_ledger(ledger, path)
    return out


def _record_account_ledger(res: "ParseResult", raw: bytes, file_name: str, path: Optional[str],
                           held_keys: Iterable[str] = (), after_close: bool = False) -> dict:
    """阶段2A: 同一次解析同步写入现金台账; 失败不影响成交台账, 但如实返回错误。"""
    try:
        from services import account_ledger
        # 现金台账与成交台账同目录: path 未传时跟随 LEDGER_PATH (测试替换 LEDGER_PATH 后不会写到真实现金台账)
        held = set(held_keys)
        if held:   # 待确认的疑似重复成交: 现金结算暂不记入, 避免重复扣款
            import copy as _copy
            res = _copy.copy(res)
            res.trades = [t for t in res.trades if t.key not in held]
        return account_ledger.record_parse(res, raw, file_name, account_ledger.ledger_path_for(path or LEDGER_PATH),
                                           after_close=after_close)
    except Exception as e:  # noqa: BLE001 — 现金台账问题必须可见, 但不回滚已校验的成交
        logger.error("现金台账写入失败 (%s): %s", file_name, e)
        return {"status": "error", "message": str(e)}


def import_trade_file(raw: bytes, file_name: str = "", path: Optional[str] = None, after_close: bool = False) -> dict:
    """解析 + 写入台账, 返回导入摘要。after_close: 用户声明收盘后导出 (交割单覆盖含导出日当天)。"""
    import hashlib
    res = parse_trade_file(raw, source=file_name)
    ledger = load_ledger(path)
    summary = res.summary()
    ledger["file_hashes"] = sorted(set(ledger.get("file_hashes") or []) | {hashlib.sha256(raw).hexdigest()})[-500:]
    merged = merge_into_ledger(ledger, res.trades, {
        "file": file_name, "date_from": summary["date_from"], "date_to": summary["date_to"],
        "parsed": summary["parsed"],
    })
    save_ledger(ledger, path)
    summary.update(merged)
    summary["account_ledger"] = _record_account_ledger(res, raw, file_name, path, merged.get("held_trade_keys") or (),
                                                       after_close=after_close)
    logger.info("历史成交导入: %s 解析 %d 条, 新增 %d, 重复 %d",
                file_name, summary["parsed"], merged["added"], merged["duplicates"])
    return summary


# ═══════════════════════════════════════════════════════
#  ③b 导入文件夹: 每月把通达信导出丢进去, 台账自动累积 (突破 60 天导出限制)
# ═══════════════════════════════════════════════════════

IMPORT_DIR = os.path.join(_ROOT, "data_lake", "trade_imports")
_IMPORT_EXT = (".txt", ".csv", ".tsv", ".xls")


def scan_import_folder(folder: Optional[str] = None, path: Optional[str] = None) -> dict:
    """扫描导入文件夹, 按文件内容哈希去重 (同一文件只解析一次), 成交按 key 去重合并。"""
    import hashlib
    folder = folder or IMPORT_DIR
    os.makedirs(folder, exist_ok=True)
    ledger = load_ledger(path)
    seen = set(ledger.get("file_hashes") or [])
    out = {"folder": folder, "files": [], "added": 0}
    for fn in sorted(os.listdir(folder)):
        if not fn.lower().endswith(_IMPORT_EXT):
            continue
        fp = os.path.join(folder, fn)
        try:
            raw = open(fp, "rb").read()
        except OSError as e:
            out["files"].append({"file": fn, "status": "error", "message": str(e)})
            continue
        h = hashlib.sha256(raw).hexdigest()
        if h in seen:
            continue
        try:
            res = parse_trade_file(raw, source=fn)
            sm = res.summary()
            merged = merge_into_ledger(ledger, res.trades, {"file": fn, "date_from": sm["date_from"],
                                                            "date_to": sm["date_to"], "parsed": sm["parsed"],
                                                            "via": "folder"})
            out["added"] += merged["added"]
            out["files"].append({"file": fn, "status": "ok", **merged, "date_from": sm["date_from"],
                                 "date_to": sm["date_to"], "errors": sm["error_count"],
                                 "account_ledger": _record_account_ledger(res, raw, fn, path)})
            seen.add(h)
        except TradeImportError as e:
            out["files"].append({"file": fn, "status": "error", "code": e.code, "message": str(e)})
    ledger["file_hashes"] = sorted(seen)[-500:]
    if out["files"]:
        save_ledger(ledger, path)
        logger.info("导入文件夹扫描: %d 个新文件, 新增 %d 笔", len(out["files"]), out["added"])
    return out


# ═══════════════════════════════════════════════════════
#  ④ 对账 + 本轮建仓日 (跟踪止盈锚点)
# ═══════════════════════════════════════════════════════

def _signed(t: Mapping[str, Any]) -> int:
    q = int(t.get("qty") or 0)
    return q if t.get("side") == "buy" else -q


def reconcile_positions(trades: list[Mapping[str, Any]], holdings: Mapping[str, Mapping[str, Any]],
                        as_of: Optional[str] = None) -> dict[str, dict]:
    """券商持仓 (权威数量/成本) × 成交台账 (时间线) → 每只持仓的锚点与对账状态。

    opening = 持仓数量 − 台账净买入; 期初为 0 才能精确定位本轮建仓日。
      anchor_quality: exact      台账内可见 0→正 的建仓时点
                      pre_window 期初已有持仓, 建仓早于台账起点 (锚点取台账首日, 偏保守)
                      no_history 台账中无该标的
      status:         ok / opening_lot / mismatch (台账买多于持仓 → 漏导卖出或快照过期)
    """
    as_of = as_of or "9999-12-31"
    by_code: dict[str, list[Mapping[str, Any]]] = {}
    for t in trades:
        if t.get("date", "") <= as_of:
            by_code.setdefault(t["ts_code"], []).append(t)
    ledger_start = min((t["date"] for t in trades), default=None)

    out: dict[str, dict] = {}
    for code, pos in holdings.items():
        held = int(round(float(pos.get("amount", 0) or 0)))
        tl = sorted(by_code.get(code, []), key=_sort_key)
        net = sum(_signed(t) for t in tl)
        opening = held - net
        info = {
            "ts_code": code, "held_qty": held, "ledger_net": net, "opening_qty": opening,
            "trades": len(tl), "anchor_date": None, "anchor_quality": "no_history",
            "status": "ok", "ledger_start": ledger_start, "last_buy_date": None,
            "last_sell_date": None,
        }
        if not tl:
            info["status"] = "no_history"
            out[code] = info
            continue
        running = opening
        episode_start = None
        for t in tl:
            before = running
            running += _signed(t)
            if before <= 0 < running:
                episode_start = t["date"]
            if running <= 0:
                episode_start = None
            if t.get("side") == "buy":
                info["last_buy_date"] = t["date"]
            else:
                info["last_sell_date"] = t["date"]
        if opening < 0:
            info["status"] = "mismatch"
            info["anchor_date"] = episode_start or tl[0]["date"]
            info["anchor_quality"] = "approx"
        elif opening > 0 and episode_start is None:
            info["status"] = "opening_lot"
            info["anchor_date"] = ledger_start
            info["anchor_quality"] = "pre_window"
        else:
            info["anchor_date"] = episode_start
            info["anchor_quality"] = "exact" if episode_start else "approx"
        out[code] = info
    return out


def closed_round_trips(trades: list[Mapping[str, Any]], held_codes: Iterable[str] = ()) -> list[dict]:
    """台账内已完成的回合 (持仓 0 → 正 → 0)。仅统计成本完全可见的回合。"""
    held = set(held_codes)
    by_code: dict[str, list[Mapping[str, Any]]] = {}
    for t in trades:
        by_code.setdefault(t["ts_code"], []).append(t)
    trips: list[dict] = []
    for code, tl in by_code.items():
        tl = sorted(tl, key=_sort_key)
        net = sum(_signed(t) for t in tl)
        # 对不再持有的标的, 期初持仓 = −净买入; 对仍持有的标的无法确定 → 只用 0 起点
        opening = max(0, -net) if code not in held else 0
        running = opening
        cur: Optional[dict] = None
        for t in tl:
            before = running
            running += _signed(t)
            if before <= 0 < running:
                cur = {"ts_code": code, "name": t.get("name", ""), "entry_date": t["date"],
                       "buy_qty": 0, "buy_amt": 0.0, "sell_qty": 0, "sell_amt": 0.0, "fills": 0}
            if cur is not None:
                cur["fills"] += 1
                if t.get("side") == "buy":
                    cur["buy_qty"] += int(t["qty"]); cur["buy_amt"] += float(t["amount"])
                else:
                    cur["sell_qty"] += int(t["qty"]); cur["sell_amt"] += float(t["amount"])
                    if not cur["name"] or "申购" in cur["name"]:   # 新股: 用上市后的证券简称
                        cur["name"] = re.sub(r"^[NC](?=\S)", "", t.get("name", "")) or cur["name"]
                if running <= 0 and before > 0:
                    cur["exit_date"] = t["date"]
                    if cur["buy_qty"] == cur["sell_qty"] and cur["buy_qty"] > 0:
                        cur["avg_buy"] = cur["buy_amt"] / cur["buy_qty"]
                        cur["avg_sell"] = cur["sell_amt"] / cur["sell_qty"]
                        cur["pnl"] = round(cur["sell_amt"] - cur["buy_amt"], 2)
                        cur["ret"] = cur["avg_sell"] / cur["avg_buy"] - 1
                        trips.append(cur)
                    cur = None
    trips.sort(key=lambda x: x["exit_date"])
    return trips
