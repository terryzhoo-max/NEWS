"""
AlphaCore · ERP回测数据预处理模块
==================================
将 PE-TTM(日频) + 10Y国债(日频) + M1/M2(月频) 合并为日频宽表。

核心防线 (2026-10-24 时点一致改造, 见 docs/ERP_VALIDATION_STEP1_2.md):
  1. M1/M2 按"可得日期"映射到交易日 (数据月 +2 个月的 1 号才可用, 保守于实际发布日)
  2. 只允许 ffill (有天数上限), 永不 bfill —— 起点之前没有数据的行直接丢弃
  3. 10Y / PE 覆盖率不达标直接抛 DataQualityError, 不再静默补齐
  4. 缓存目录锚定项目根 data_lake/ (原为相对 cwd, 不同目录运行会读到不同缓存)
  5. 标记 M1 2025-01 统计口径断点 (m1_new_caliber)

数据源: Tushare Pro (PE / M1) + services.chinabond_yield (10Y)
"""

import os
import sys
import time
from datetime import datetime

import numpy as np
import pandas as pd

_PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)

from services.erp_data_quality import (  # noqa: E402
    FFILL_LIMIT, DataQualityError, check_daily_series,
)

CACHE_DIR = os.path.join(_PROJECT_ROOT, "data_lake")
os.makedirs(CACHE_DIR, exist_ok=True)

DEFAULT_START = "20060301"         # 中债 10Y (AKShare) 最早可得日; 覆盖 2008 / 2015 / 2018 / 2022 完整周期
M1_CALIBER_BREAK = "202501"        # 人民银行 2025-01 起修订 M1 统计口径
M1_MAX_STALENESS_DAYS = 100        # 交易日距所用 M1 可得日超过此值 → 月度数据缺失
PE_CHUNK_YEARS = 5                 # index_dailybasic 单次行数上限内的安全批长

_pro = None


def _get_pro():
    """延迟初始化 Tushare (导入本模块不再触发网络/Token 依赖)。"""
    global _pro
    if _pro is None:
        import tushare as ts
        from config import TUSHARE_TOKEN
        _pro = ts.pro_api(TUSHARE_TOKEN)
    return _pro


def _atomic_write_parquet(df: pd.DataFrame, path: str):
    tmp = path + ".tmp"
    df.to_parquet(tmp, index=False)
    os.replace(tmp, path)


def _fetch_pe_ttm(start_date: str, end_date: str, index_code: str = "000300.SH") -> pd.DataFrame:
    """
    获取指数 PE-TTM 日频数据 (parquet 缓存, 缓存起点晚于 start_date 时自动向前补拉)
    返回: DataFrame[trade_date, pe_ttm, turnover_rate] (已裁剪到 [start_date, end_date])
    """
    cache_file = os.path.join(CACHE_DIR, "erp_pe_ttm.parquet")
    existing = None
    if os.path.exists(cache_file):
        existing = pd.read_parquet(cache_file)
        existing['trade_date'] = pd.to_datetime(existing['trade_date'])

    start_ts = pd.Timestamp(start_date)
    end_ts = pd.Timestamp(end_date)
    ranges = []
    if existing is None or existing.empty:
        ranges.append((start_ts, end_ts))
    else:
        first, last = existing['trade_date'].min(), existing['trade_date'].max()
        if first > start_ts + pd.Timedelta(days=10):
            ranges.append((start_ts, first - pd.Timedelta(days=1)))
        if last < end_ts:
            ranges.append((last - pd.Timedelta(days=3), end_ts))

    new_parts = []
    for s, e in ranges:
        cur = s
        while cur <= e:
            nxt = min(cur + pd.DateOffset(years=PE_CHUNK_YEARS) - pd.Timedelta(days=1), e)
            try:
                part = _get_pro().index_dailybasic(
                    ts_code=index_code, start_date=cur.strftime("%Y%m%d"),
                    end_date=nxt.strftime("%Y%m%d"),
                    fields="ts_code,trade_date,pe,pe_ttm,pb,turnover_rate")
            except Exception as ex:  # 网络失败: 用已有缓存, 由覆盖率检查决定能否继续
                print(f"[ERP Data] PE-TTM 拉取失败 {cur.date()}~{nxt.date()}: {ex}")
                part = None
            if part is not None and not part.empty:
                part['trade_date'] = pd.to_datetime(part['trade_date'], format='%Y%m%d')
                new_parts.append(part)
            cur = nxt + pd.Timedelta(days=1)
            time.sleep(0.3)

    frames = [d for d in [existing] + new_parts if d is not None and not d.empty]
    if not frames:
        raise DataQualityError("PE-TTM 数据为空且无缓存")
    df = pd.concat(frames).drop_duplicates(subset='trade_date', keep='last')
    df = df.sort_values('trade_date').reset_index(drop=True)
    if new_parts:
        _atomic_write_parquet(df, cache_file)
        print(f"[ERP Data] PE-TTM: {len(df)} rows cached "
              f"({df['trade_date'].min().date()} → {df['trade_date'].max().date()})")
    df = df[(df['trade_date'] >= start_ts) & (df['trade_date'] <= end_ts)]
    return df[['trade_date', 'pe_ttm', 'turnover_rate']].reset_index(drop=True)


def _fetch_yield_10y(start_date: str, end_date: str, bond_code: str = "1001.CB") -> pd.DataFrame:
    """
    获取10Y国债收益率日频数据 (统一走 services.chinabond_yield, 按回测起点补拉)
    返回: DataFrame[trade_date, yield_10y] (已裁剪到 [start_date, end_date])

    旧版的直接 yc_cb 回退路径已删除: 它不限定 curve_term, 同样会被单次行数上限截断,
    且写入相对 cwd 的缓存目录。
    """
    from services.chinabond_yield import get_yield_10y_history
    df = get_yield_10y_history(start_date=start_date)
    df = df.copy()
    df['trade_date'] = pd.to_datetime(df['trade_date'])
    start_dt = pd.Timestamp(start_date)
    end_dt = pd.Timestamp(end_date)
    df = df[(df['trade_date'] >= start_dt) & (df['trade_date'] <= end_dt)]
    print(f"[ERP Data] 10Y Yield: {len(df)} rows")
    return df[['trade_date', 'yield_10y']].sort_values('trade_date').reset_index(drop=True)


def _fetch_m1_m2(start_month: str = "200501", months: int = None) -> pd.DataFrame:
    """
    获取M1/M2同比月频数据 (起点固定, 不再随"今天"滚动后移)
    返回: DataFrame[month, m1_yoy, m2_yoy]
    """
    end_m = datetime.now().strftime("%Y%m")
    if months is not None:  # 兼容旧调用
        start_m = (pd.Timestamp(datetime.now()) - pd.DateOffset(months=months)).strftime("%Y%m")
        start_month = min(start_month, start_m)
    df = _get_pro().cn_m(start_m=start_month, end_m=end_m, fields="month,m1,m1_yoy,m2,m2_yoy")
    if df is None or df.empty:
        raise DataQualityError("M1/M2 数据拉取失败")
    df = df.sort_values('month').reset_index(drop=True)
    df['m1_yoy'] = pd.to_numeric(df['m1_yoy'], errors='coerce')
    df['m2_yoy'] = pd.to_numeric(df['m2_yoy'], errors='coerce')
    print(f"[ERP Data] M1/M2: {len(df)} months ({df['month'].iloc[0]} → {df['month'].iloc[-1]})")
    return df[['month', 'm1_yoy', 'm2_yoy']]


def _expand_monthly_to_daily(m_df: pd.DataFrame, daily_dates,
                              publish_delay_months: int = 1) -> pd.DataFrame:
    """
    将月频 M1/M2 数据展开为日频 (核心防未来函数逻辑)

    - 数据月 M 在 (M + publish_delay_months + 1) 月 1 号才可用
      (例: 2024-01 的 M1 从 2024-03-01 起可用; 实际发布约在次月 10-15 日, 此处偏保守)
    - 可得日之前的交易日 → NaN (不 bfill)
    - 输出附带 m1_month (所用数据月) 与 m1_new_caliber (是否为 2025-01 起新口径)
    """
    m_df = m_df.copy()
    m_df['month'] = m_df['month'].astype(str)
    m_df['month_dt'] = pd.to_datetime(m_df['month'], format='%Y%m')
    m_df['available_date'] = (m_df['month_dt'] + pd.DateOffset(months=publish_delay_months + 1)
                              ).astype('datetime64[ns]')
    m_df = m_df.dropna(subset=['m1_yoy', 'm2_yoy']).sort_values('available_date')

    daily_df = pd.DataFrame({'trade_date': pd.to_datetime(pd.Series(daily_dates)).astype('datetime64[ns]')})
    daily_df = daily_df.sort_values('trade_date').reset_index(drop=True)

    result = pd.merge_asof(
        daily_df,
        m_df[['available_date', 'month', 'm1_yoy', 'm2_yoy']],
        left_on='trade_date',
        right_on='available_date',
        direction='backward'
    )
    result['scissor'] = result['m1_yoy'] - result['m2_yoy']
    result['m1_staleness_days'] = (result['trade_date'] - result['available_date']).dt.days
    result['m1_month'] = result['month']
    result['m1_new_caliber'] = result['month'].fillna('000000') >= M1_CALIBER_BREAK
    return result[['trade_date', 'm1_yoy', 'm2_yoy', 'scissor',
                   'm1_month', 'm1_new_caliber', 'm1_staleness_days']]


def build_erp_frame(pe_df: pd.DataFrame, yield_df: pd.DataFrame, m1_df: pd.DataFrame,
                    start_date: str, end_date: str, strict: bool = True) -> pd.DataFrame:
    """纯函数: 合并三路原始数据 → 日频宽表 (便于离线测试)。

    strict=True: 覆盖率不达标抛 DataQualityError。
    """
    pe_df = pe_df.copy()
    pe_df['trade_date'] = pd.to_datetime(pe_df['trade_date'])
    pe_df = pe_df[pe_df['pe_ttm'].notna() & (pe_df['pe_ttm'] > 0)]
    calendar = pe_df['trade_date']   # 指数日频基础数据即 A 股交易日历

    # ── 守卫 1: PE 起点 ──
    check_daily_series("PE-TTM", calendar, calendar, start=start_date, end=end_date,
                       strict=strict)
    # ── 守卫 2: 10Y 覆盖率 (按 PE 交易日历) ──
    check_daily_series("10Y 国债收益率", yield_df['trade_date'], calendar,
                       start=start_date, end=end_date, strict=strict)

    merged = pd.merge(pe_df[['trade_date', 'pe_ttm', 'turnover_rate']],
                      yield_df[['trade_date', 'yield_10y']], on='trade_date', how='left')
    merged = merged.sort_values('trade_date')
    merged['yield_10y'] = merged['yield_10y'].ffill(limit=FFILL_LIMIT)   # 只向前, 有上限
    merged['turnover_rate'] = merged['turnover_rate'].ffill(limit=FFILL_LIMIT)
    merged = merged.dropna(subset=['pe_ttm', 'yield_10y']).copy()

    merged['earnings_yield'] = 1.0 / merged['pe_ttm'] * 100
    merged['erp'] = merged['earnings_yield'] - merged['yield_10y']
    merged['pe_vol'] = merged['pe_ttm'].rolling(60, min_periods=20).std()

    m1_daily = _expand_monthly_to_daily(m1_df, merged['trade_date'])
    merged = pd.merge(merged, m1_daily, on='trade_date', how='left')

    # ── 守卫 3: M1 月度数据不能长期断档 ──
    stale = merged['m1_staleness_days'] > M1_MAX_STALENESS_DAYS
    if stale.any():
        d = merged.loc[stale, 'trade_date']
        msg = (f"[数据质量] M1/M2: {int(stale.sum())} 个交易日所用 M1 超过 "
               f"{M1_MAX_STALENESS_DAYS} 天未更新 ({d.min().date()} ~ {d.max().date()})")
        if strict:
            raise DataQualityError(msg)
        print(msg)

    # 起点之前没有可得数据的行直接丢弃 (原先 bfill = 用未来值填过去)
    merged = merged.dropna(subset=['erp', 'm1_yoy', 'm2_yoy', 'scissor', 'pe_vol'])
    merged = merged.drop(columns=['m1_staleness_days'])
    return merged.reset_index(drop=True)


def prepare_erp_backtest_data(start_date: str = DEFAULT_START,
                               end_date: str = None,
                               index_code: str = "000300.SH",
                               strict: bool = True) -> pd.DataFrame:
    """
    核心函数: 构建ERP回测日频宽表

    返回 DataFrame 列:
      - trade_date, pe_ttm, turnover_rate, yield_10y
      - earnings_yield: 盈利收益率 (1/PE × 100, %)
      - erp: 股权风险溢价 (earnings_yield - yield_10y, %)
      - m1_yoy / m2_yoy / scissor: 按可得日期映射 (%)
      - m1_month: 所用 M1 数据月; m1_new_caliber: 是否 2025-01 起新口径
      - pe_vol: PE 60 日滚动标准差

    注意:
      - 宽表起点 = max(start_date, 各数据首个可得日), 不再用 bfill 补齐起点之前
      - ERP 分位需要 ERP_WINDOW 回溯期, 回测区间应晚于宽表起点至少 4 年
    """
    if end_date is None:
        end_date = datetime.now().strftime("%Y%m%d")
    print(f"[ERP Backtest Data] 构建日频宽表: {start_date} → {end_date}")

    pe_df = _fetch_pe_ttm(start_date, end_date, index_code)
    yield_df = _fetch_yield_10y(start_date, end_date)
    start_month = (pd.Timestamp(start_date) - pd.DateOffset(months=3)).strftime("%Y%m")
    m1_df = _fetch_m1_m2(start_month=start_month)

    merged = build_erp_frame(pe_df, yield_df, m1_df, start_date, end_date, strict=strict)

    print(f"[ERP Backtest Data] 宽表构建完成: {len(merged)} 行, "
          f"{merged['trade_date'].min().strftime('%Y-%m-%d')} → "
          f"{merged['trade_date'].max().strftime('%Y-%m-%d')}")
    return merged


# ===== CLI Self-Test =====
if __name__ == "__main__":
    print("=" * 60)
    print("ERP Backtest Data Pipeline — Self-Test")
    print("=" * 60)
    df = prepare_erp_backtest_data(DEFAULT_START)
    print(f"\n✅ 宽表形状: {df.shape}")
    print(f"列: {list(df.columns)}")
    print(f"\n最新5行:")
    print(df.tail())
    print(f"\n统计:")
    print(df[['erp', 'm1_yoy', 'scissor', 'pe_vol']].describe())
    null_count = df[['erp', 'm1_yoy', 'scissor', 'pe_vol']].isnull().sum().sum()
    print(f"\n关键列空值: {null_count} {'✅' if null_count == 0 else '❌'}")
