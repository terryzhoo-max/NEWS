# 第 0 轮实施方案 · 月度 CI 只评估不发布、触发来源、写操作日志、去外链头像

- 状态：**用户 2026-11-04 21:28（美中）确认**；21:32 授权按专业判断定剩余细节（见第 7 节）。权威环境收尾轮完成后（11-05 起）开始实施
- 依据：`docs/SITE_SLIMMING_ROUNDS.md` 第 0 轮提示词；`docs/PLAN_B_IMPLEMENTATION_LOG.md` 末尾「插入任务 · 暂停月度 CI 与 11-01 月度 CI 只读核实」；11-04 本机代码静态阅读（行号为 11-04 本机位置，实施时先核对）
- 方案会话没有调用任何 `/ci/*` 接口，没有改服务器状态

---

## 1. 拍板（11-04 21:28）

| 编号 | 问题 | 决定 |
|---|---|---|
| D1 | 批准后参数怎么生效 | **A**：批准只做记录并生成参数补丁；参数经仓库提交、推送部署后生效。服务器进程不再写 `config/strategy_runtime.json` |
| D2 | 回测页按钮 | "运行 CI"与"批准"在 0b 一起隐藏 |
| D3 | 服务器写操作日志（0a-4） | 做。不记录 X-API-Key 等令牌；不记录导入文件内容（对账单 / 交割单 / 成交文件只记文件名、大小、行数和结果）；设大小上限或按月轮换 |
| D4 | 接口触发 CI | `reason` 必填 |

约定：
- 0a 部署前，回测页"运行 CI""批准"按钮都不点（扩大 11-04 20:35 的约定）
- 第 0 轮完成前，会话不调用任何 `/ci/*` 接口（包括 GET）。部署后核对 CI 相关结果，靠用户在服务器执行只读 sqlite 命令，或者看审计页（0a-6）
- 通用约束固定规则 8（改变服务器状态的操作须事先告知并记日志）和规则 9（参数补丁须用户逐次明确同意后才提交）已写入通用约束；推送时间见实施日志
- 暂停月度 CI 的配置（提交 `1cec27a`）：用户 21:28 核对，服务器已生效。0a-1 开工前，经隧道在审计页 A 区「定时任务运行」再确认一次，应显示「已暂停: 策略 CI 每月1日」

---

## 2. 现状（11-04 静态阅读）

| # | 事实 | 位置 | 状态 |
|---|---|---|---|
| F1 | MR 结果为 ACCEPT / REVALIDATED 时，`_publish_accepted_run` 调 `publish_ci_parameters`，改写 `config/strategy_runtime.json`（revision + 1） | `services/strategy_pipeline.py` 179–209、311–312；`services/strategy_params.py` 723 起 | 已核实 |
| F2 | 发布同时把该状态的 lifecycle 设为 `validated`，于是 `allow_new_entries=true`，MR 买入信号从 `no_entry` 变成可开仓，进入 MR 预览和买入门控 | `strategy_params._apply_ci_update` 656–668；`get_mr_lifecycle` 491–526；`engines/mean_reversion_engine.py` 418–464 | 已核实 |
| F3 | 容器里的 `config/` 不在持久卷上（docker-compose 只挂 `./data_lake`），运行时写入会在下次 `update.sh` 被仓库版本覆盖。**现有的人工批准也一样留不住** | `docker-compose.yml` | 已核实 |
| F4 | REJECT / INSUFFICIENT_EVIDENCE 经 `record_ci_outcome` 也会写运行时配置的 MR lifecycle（revision + 1） | `strategy_params.py` 550–612；`strategy_pipeline.py` 313–324 | 已核实 |
| F5 | 两种情况静默跳过、不写记录：MR 某状态缺 `REGIME_PERIODS`，或优化器返回空结果（`continue`）；ERP 为 `DISABLED` 时直接返回 | `strategy_pipeline.py` 245–259、372–380 | 已核实 |
| F6 | `ci_runs` 表没有触发来源和批准相关字段 | `services/db/connection.py` 241–256；`services/db/ci.py` | 已核实 |
| F7 | 批准接口只接受 REVIEW 状态，但 MR 只产出 ACCEPT / REVALIDATED / REJECT / INSUFFICIENT_EVIDENCE，**MR 从来走不到批准**；只有已停用的 ERP 路径会产出 REVIEW | `routers/ci.py` 83–117；`strategy_pipeline.py` 280–285、131–157 | 已核实 |
| F8 | `POST /ci/run` 没有来源字段，也没有 reason；接口内同步执行 CI | `routers/ci.py` 25–55 | 已核实 |
| F9 | 回测页用裸 `fetch` 调 `/ci/run` 和 `/ci/accept`，不带 X-API-Key。11-04 读取鉴权后，`alphacore_utils.js`（回测页已加载 v5）会自动给同源 `/api/` 请求带令牌，所以**现在在 18000 点按钮能真正触发 CI，结果为 ACCEPT 就会发布** | `static/js/backtest.js` 1274、1307、1367、1384；`backtest.html` 19、149 | 已核实 |
| F10 | 推断：11-01 时按钮不带令牌，生产环境下 `POST /ci/run` 应返回 401，所以 09:07 那次基本可以排除回测页 | — | 推断。待核实两点：① 11-01 服务器为生产模式且配置了令牌；② 当时没有别的自动带令牌机制（本机 `git log -p static/js/alphacore_utils.js`） |
| F11 | 月度任务里含 AIAE V5 自检（`_run_aiae_v5_monthly_check`）：会写应用根目录的 `portfolio_backtest_results.json`（部署即丢），并推送告警 | `strategy_pipeline.py` 473–479、505–667；`engines/portfolio_backtest.py` 68、387–389 | 已核实 |
| F12 | 外链头像 pravatar 共 12 处：`static/js/sidebar.js` 163–168，加上 audit / decision / index / strategy / treasury / 7 个个股页的 `user-profile` 块（第 0 轮提示词原只列了 3 处） | 各 HTML `user-profile` | 已核实（`static/js` 下其余文件实施时全文再搜） |
| F13 | 自 10-24 起 `ERP_CI_AUTO_OPTIMIZE=False`，`run_erp_ci` 返回 DISABLED | `engines/erp_params.py` 约 107 | 已核实 |

**MR CI 参数影响哪些输出：**
- 参数（N_trend、rsi、bias、stop_loss）影响：MR 信号、MR 预览、执行总览"独立策略共振"里的 MR 一项、事件监控里的 MR 跳变
- lifecycle 决定 MR 能不能开新仓
- 执行目标、合规、跟踪止盈不读这些参数
- ERP 的 `erp.params` 被谁读，实施时核实；本方案让流水线不再发布任何参数，所以无论谁读都不受影响

---

## 3. 设计

### 3.1 CI 只评估不发布（0a-1）
- `strategy_pipeline` 删除 `_publish_accepted_run` 及所有调用，不再 import `publish_ci_parameters`。MR 和 ERP 一样处理（即使 `ERP_CI_AUTO_OPTIMIZE` 重新打开，也不发布）
- 评估结果 `status` 保持原有取值：ACCEPT / REVALIDATED / REJECT / INSUFFICIENT_EVIDENCE / REVIEW / ERROR，另新增 DISABLED、SKIPPED
- 新增批准状态 `approval_status`：
  - ACCEPT / REVALIDATED / REVIEW → PENDING
  - 其余结果 → NOT_APPLICABLE
  - `diff_summary` 末尾写"待人工批准（批准后经仓库提交生效）"
- `publish_ci_parameters` 保留，但 `path` 改为必填关键字参数（不传就报错），服务器进程内不再有调用方。本机应用批准补丁时，对仓库文件使用
- 落库补全：
  - MR 缺 `REGIME_PERIODS` 或优化器返回空 → SKIPPED（写原因）
  - ERP 停用 → DISABLED
  - `run_full_ci` 各阶段出错 → ERROR
  - 都写一条 `ci_runs`
- 补测试锁住 `engines/erp_params.ERP_CI_AUTO_OPTIMIZE is False`
- 实施补充（用户 11-05 08:3x 确认，0a-1 已做）：
  - ERP 优化器返回空结果：原来只返回 `{"run_id","status":"ERROR"}`、不落库，改为写一条 ERROR
  - `POST /ci/accept`：0a-1 先改为鉴权照旧在前（无令牌 401），通过后一律 409，不查库、不发布；0a-3 再按 3.4 重做
  - 原 `tests/test_strategy_pipeline.py` 里测 `_publish_accepted_run` 的 4 条测试随函数删除，按对照换成 `tests/test_round0_ci.py` 的新测试；dry_run 测试改为 spy 断言发布函数没被调用（对照见实施日志）

### 3.2 触发来源（0a-1）
- `run_full_ci` / `run_mr_ci` / `run_erp_ci` 增加关键字参数 `trigger`。同一次调用里的各状态共用一个 `batch_id`
- 没传 `trigger` 时一律记为 **direct**，并打 WARNING 日志"CI 直接调用（非定时 / 非接口）"。记录主机名、pid、`sys.argv`、线程名，以及调用栈里流水线之外最近的 文件:行号
- 定时任务回调（`main.py` 253–259）传 `source=scheduler`，记任务名和应运行时间
- `POST /ci/run` 的处理：
  - 请求体增加 `reason`，去空格后 2–200 字，必填；缺失返回 422
  - 记 `source=api`，以及客户端 IP、X-Forwarded-For、User-Agent（截断 200 字）、Origin、Referer、`X-AC-Caller`（前端自带的调用方标记，可选）、strategy、regime、reason
  - 不记任何令牌，只记一个认证结果标记
- `ci_runs` 表加列：`trigger_source`、`trigger_detail`（JSON）、`batch_id`、`reason`、`approval_status`、`approved_at`、`approval_detail`（JSON）
  - 加 `validation`（JSON，用户 11-05 08:3x 确认）：冻结样本外验证结果，带 `schema_version`（现为 1）。迁移前的旧记录为空
  - 迁移照 `connection.py` 377–405 decision_log 的做法：先查 `PRAGMA table_info`，缺哪列就 `ALTER TABLE ADD COLUMN`
  - 11-04 前的旧记录，来源显示"未记录（第 0 轮前）"
- 推断（实施时用一次只读请求核实）：经隧道的请求，客户端 IP 是 docker 网关地址；在容器里 curl 是 127.0.0.1。两者可以区分

### 3.3 MR lifecycle 移出运行时配置（0a-2）
- 新文件 `data_lake/strategy_state/mr_lifecycle.json`，各状态一条：status、validated_at、data_through、validation_run_id、next_validate_after、`params_revision`、written_at、trigger_source
- 写入方：只有 `record_ci_outcome`，改成写这个文件，不再写运行时配置
  - **只允许写 rejected / insufficient_evidence，写 validated 直接报错**（"自动只会更严"）
  - validated 只能和参数一起，经仓库提交进入 `strategy_runtime.json`
- 读取（`get_mr_lifecycle`）：以运行时配置为基础；data_lake 条目同时满足两个条件才用它：
  - `params_revision` 等于当前 revision（参数一换版，旧条目自动失效）
  - validated_at 比基础记录新
  - 返回结果增加 `lifecycle_source`（runtime / data_lake）
- data_lake 文件损坏时 **fail-closed**：三态一律按 stale 处理（`allow_new_entries=false`），并写日志。不能退回基础记录，因为基础记录可能比 data_lake 宽松
- 部署时这个文件还不存在，所以 lifecycle 和现在完全相同：BEAR 为 stale，RANGE / BULL 为 insufficient_evidence，MR 信号不变
- 已核实（`services/mr_validation.py` 321–341）：REJECT 只在挑战者不能被接受、**且现任参数也通不过绝对门槛**时出现；现任通过就是 REVALIDATE_INCUMBENT。所以 REJECT 把 lifecycle 写成 rejected、关掉开仓，语义正确，属于"只会更严"。本轮不改
- 实施补充（11-05，0a-2 已做）：
  - 文件格式 `{schema_version: 1, updated_at, entries: {BEAR / RANGE / BULL: 条目}}`
  - 损坏的判定：JSON 解析失败、结构不对、`schema_version` 不是 1、未知状态名、条目缺字段或日期不合法、status 不是 rejected / insufficient_evidence。任一处不合规整份作废；`lifecycle_source` 为 `data_lake_error`，reason 为 `lifecycle_state_unreadable`；WARNING 每种错误只打一次
  - 写入时现有文件损坏：拒绝覆盖（保留现场，等人工处理），流水线记 ERROR 日志
  - 至此服务器进程内写 `config/strategy_runtime.json` 的只剩发布函数，且它在服务器进程内没有调用方

### 3.4 批准流程 A（0a-3）
- `POST /api/v1/ci/accept/{run_id}`：
  - **不设环境开关**（第 7 节 J4）。门槛是：写入令牌、请求体 `{confirm_run_id, note}`，`confirm_run_id` 必须与路径中的 run_id 一致，`note` 必填 2–200 字；不满足返回 400；每次批准都进写操作日志
  - 只记录批准、不改参数；参数生效仍要靠仓库提交，由用户推送部署
  - 只接受 `approval_status=PENDING` 的记录（不再只认 REVIEW，MR 的 ACCEPT / REVALIDATED 也可以批准）
  - `validation` 为空（迁移前的旧记录）或缺 `schema_version` 的记录一律拒绝批准，不当作通过（用户 11-05 08:3x）
- 批准成功后：
  - 写入 `approval_status=APPROVED`、`approved_at`、`approval_detail`（来源字段同 3.2，含 note）
  - 返回**参数补丁**：用 `_apply_ci_update` 的同一套校验，在当前配置的副本上算出改动（该状态参数、stop_loss、lifecycle validated、revision + 1、`published_by="manual:ci:<run_id>"`）
  - 同时返回**审阅摘要** `review`，供会话原样列给用户：run_id、策略 / 状态、评估结果；参数逐项改前 → 改后（含 stop_loss，未变的项标"不变"）；lifecycle 改前 → 改后；验证结果（方法、oos_start、data_through、结论与原因、现任与挑战者的 Sharpe / MaxDD / Calmar / 交易次数 / 状态天数）；质量门逐条；批准时间与 note
  - **不写任何配置文件**
- 生效（用户 11-04 22:08 规定，见第 7 节 J10）：
  1. **会话不得自行提交补丁。** 先把审阅摘要列给用户：参数改前 / 改后、对应 run_id、验证结果
  2. **用户明确同意后才提交。** 同意必须针对这一个 run_id 的补丁；"按专业判断"之类的概括授权、没有反对、批准接口已调用，都不算同意
  3. 同意后，会话按补丁改仓库里的 `config/strategy_runtime.json`，走测试，给出推送命令（提交说明含 run_id），由用户推送和部署
  4. 实施日志记录：用户何时同意（美中和北京时间）、同意的原话、run_id、改前 / 改后摘要、提交号、推送时间、部署时间
- "已生效"在读取时现算，不另外写库：当前配置里该状态的 `validation_run_id` 等于这条 run_id，就显示"已生效"
- 读取时现算的显示状态：
  - 同一策略 / 状态有更新的运行时，较旧的 PENDING 显示"已被取代"
  - PENDING 超过 35 天显示"待批准（已过期）"
- 回测页不做批准界面（0b 隐藏）。批准由用户在服务器用 curl 执行，命令由会话给出，按规则 8 事先告知并记日志

### 3.5 服务器写操作日志（0a-4）
- 新文件 `services/write_log.py`，内含 Starlette 中间件。`main.py` 里**在 `ApiKeyMiddleware`（414 行）之后添加**，使它处在认证的外层，401 / 403 也能记到
- 范围：`/api/` 下的 POST / PUT / PATCH / DELETE。GET / HEAD / OPTIONS 不记
- 每条记录的字段：
  - 时间：北京时间和 UTC 各一份
  - 请求：method、path
  - query：只记键名；键名含 key / token / secret / password / auth 的连值也不记
  - 结果：status、duration_ms
  - 来源：client_host、x_forwarded_for、user_agent（截断）、origin、referer、caller（`X-AC-Caller`）
  - `auth`：ok / missing / invalid / not_required
  - 请求体：只记 content_type 和 content_length
  - `detail`：接口自己附加的安全摘要
- **不记令牌**：中间件从不读取或保存 X-API-Key 和 Authorization 的值
- **不记文件内容**：中间件不读请求体。导入类接口（`/portfolio/import`、`/portfolio/trades/import`、`/portfolio/trades/scan`）在 `request.state.write_log` 里写入文件名、字节数、行数、结果（imported / rejected）、错误码；`/ci/run`、`/ci/accept` 写 strategy、regime、reason、run_id
- 存储：
  - `data_lake/audit/write_log-YYYY-MM.jsonl`，按北京时间分月轮换
  - 单个文件上限 20 MB；超出后当月只追加一条 `{"truncated": true}`，并打 WARNING
  - 不自动删除旧文件
- 写日志失败不影响请求本身（只打 ERROR 日志），审计页（0a-6）会显示出来
- 服务器上的读法（只读）：`tail -n 50 /root/quant_dashboard/quant_dashboard/data_lake/audit/write_log-2026-11.jsonl`
- 局限：在容器里直接调用函数不经过 HTTP，这个日志看不到。CI 由 3.2 的 direct 来源兜住，其他操作靠规则 8
- 测试路径：`tests/conftest.py` 加 autouse fixture，把写日志目录重定向到临时目录（只是重定向，不放宽真实数据写入守卫）

### 3.6 AIAE V5 自检拆分（0a-5）
- `run_full_ci` 只跑 MR 和 ERP。V5 自检改为公开函数 `run_aiae_v5_monthly_check`，独立任务 `aiae_v5_monthly_check`，每月 1 日 02:30（北京时间）运行
- 在 `services/job_runs.JOB_LABELS` 加标签"AIAE V5 月度自检 每月1日"。不是关键任务，不列入 job_switches，默认运行
- 提醒（按规则 8 事先说明）：0a-5 部署后，12-01 02:30 北京时间（11-30 12:30 美中）V5 自检会照常运行，即使月度 CI 还没恢复。它会写 `portfolio_backtest_results.json`，有告警时会推送
- 结果文件移到 `data_lake/` 列为待办，本轮不做

### 3.7 审计页 A 区（0a-6）
- 在 `engines/audit_engine.py` 新增读数"策略 CI"，放在 `_job_runs_readout`（1708、1746 行）旁边，只读、不计分：
  - MR / ERP 最近一次运行：时间、来源、结果
  - 待批准条数：大于 0 显示警告
  - 近 35 天有 direct 来源的运行：显示警告
  - 写操作日志：当月文件大小、最后写入时间、是否已截断 / 写入失败；截断或失败显示警告
- 已核实：A 区读数是通用行（`{name, status, detail, explanation, threshold}`，`static/js/audit.js` `renderCheckRow`），0a-6 不需要改前端
- 0a-2 后顺带（11-05 登记）：审计页"均值回归"行的来源说明写的是"strategy_runtime.json runtime lifecycle"，0a-2 后 lifecycle 也可能来自 data_lake。0a-6 改为按 `lifecycle_source` 显示来源，`data_lake_error` 时写明"lifecycle 状态文件不可用，三态按 stale"

### 3.8 界面（0b）
- 回测页：
  - 隐藏"运行 CI"按钮
  - 历史记录里不再渲染"批准"按钮；PENDING 改为文字"待批准 · 人工流程"
    - 判断（用户 11-05 02:25）：`approval_status` 有值（非空）时只看它是否 PENDING；缺失、null 或空串时回退 `status === 'REVIEW'`（0a-1 迁移后旧记录可能是 null）
    - 策略下拉框只给"运行 CI"用，随按钮一起用注释隐藏；"↻ 刷新"保留
  - CI 面板保留，只读历史
  - `backtest.js` 版本号加 1
- 去掉 `sidebar.js` 和 11 个 HTML 里的 `user-profile` 头像和"基金经理 Pro / 顶级投研权限"，所有页面保持一致
  - 整块去掉（第 7 节 J5）；只有侧栏布局因此错位时，才换成本地中性文字占位
  - 检查侧栏收起 / 展开和手机端截图
  - `sidebar.js` 及引用页面的版本号加 1

### 3.9 恢复月度任务（0c，0a 部署后）
- 删去 `config/job_switches.json` 里 `strategy_ci_monthly` 的暂停条目
- 前提：服务器上已核实 `ci_runs` 新列存在（用户执行只读 sqlite 命令），且 0a-1 到 0a-6 都已部署
  - 11-05：新列已核实（0a-1 + 0a-2 于 23:40:03 北京部署，用户 09:41 美中执行只读命令，8 列都在）；0a-3 到 0a-6 未做
- 部署后在审计页 A 区确认任务状态正常
- 下次运行：12-01 02:00 北京时间 = 11-30 12:00 美中

---

## 4. 提交拆分与测试

顺序：0a-1 → 0a-2 → 0a-3 → 0a-4 → 0a-5 → 0a-6 → 0b → 0c。每个提交单独推送、部署，部署后经隧道做 5 项核对（不调 `/ci/*`）。

**11-05 调整（用户）**：0b 提前到 0a 之前单独做，实际顺序 0b → 0a-1 → … → 0a-6 → 0c；会话三改为 0a-5 + 0a-6。理由见第 7 节 J1。

| 提交 | 主要文件 | 新测试（对改前代码失败、对改后代码通过） |
|---|---|---|
| 0a-1 行为（规则 8 文档随同） | `services/strategy_pipeline.py`、`routers/ci.py`、`services/db/ci.py`、`services/db/connection.py`、`services/strategy_params.py`（`path` 必填）、`main.py`（定时回调传来源）。**实际（11-05）**：另改 `services/db/__init__.py`（导出迁移函数）、`tests/test_strategy_pipeline.py`（删 4 条旧测试、dry_run 改 spy） | 优化器打桩返回 ACCEPT / REVALIDATED，运行后 `strategy_runtime.json` 字节不变，`approval_status=PENDING`；源码契约：pipeline 不引用发布函数；SKIPPED / DISABLED / ERROR 都落库；三种来源各自正确；`/ci/run` 缺 reason 返回 422；旧表结构迁移；`ERP_CI_AUTO_OPTIMIZE is False`。实际：`tests/test_round0_ci.py`（26 条） |
| 0a-2 行为 | `services/strategy_params.py`。**实际（11-05）**：另改 `tests/conftest.py`（重定向状态文件）、`services/strategy_pipeline.py`（一行日志与模块说明） | 拒绝写 validated；版本号不一致时忽略 data_lake 条目；文件损坏时三态都为 stale；文件不存在时与现状一致；运行时配置不变。实际：`tests/test_round0_mr_lifecycle.py`（25 条） |
| 0a-3 行为 | `routers/ci.py`、`services/strategy_params.py`（纯函数生成补丁） | run_id 不一致或缺 note 返回 400；非 PENDING 拒绝；审阅摘要含 run_id、逐项改前 / 改后（未变标"不变"）、lifecycle 改前 / 改后、验证结果与质量门；批准后配置文件不变、补丁正确；"已生效""已被取代"在读取时现算 |
| 0a-4 行为 | `services/write_log.py`、`main.py`、导入类接口与 `/ci/*`（写安全摘要）、`tests/conftest.py`（重定向） | 带唯一令牌值请求后，日志文件不含该值；上传含唯一标记的文件后，日志不含标记，但有文件名 / 大小 / 行数 / 结果；401 记为 missing；GET 不记；query 敏感键不记；按月轮换；超上限截断；写入失败请求照常返回 |
| 0a-5 行为 | `services/strategy_pipeline.py`、`main.py`、`services/job_runs.py` | `run_full_ci` 不再调用 V5 自检；新任务已注册且有标签；job_switches 配置测试通过 |
| 0a-6 行为 | `engines/audit_engine.py` | 待批准、direct 来源、写日志截断 / 失败分别显示警告；无记录时显示"无数据"，不报错 |
| 0b 界面 | `backtest.html`、`static/js/backtest.js`、`static/js/sidebar.js`、11 个 HTML。**实际（11-05）**：头像块 13 处 = `sidebar.js` + 12 个 HTML（F12 与 3.8 的"12 处 / 11 个 HTML"不准）；共改 19 个文件 + 新增 1 个测试：`backtest.js` v52→53、`sidebar.js`（17 个引用页统一 v=206，原为 v=5 ×9、v=4 ×7、v=205 ×1）、17 个 HTML（12 个删头像块，`backtest.html` 另隐藏入口并加载 `ac_tokens.css?v=2`） | `.cjs`：全站 HTML / JS 不含 `pravatar.cc` 和"基金经理 Pro"；回测页没有运行 / 批准按钮；版本号已升。实际：`tests/test_round0_ui.cjs` |
| 0c 配置 | `config/job_switches.json` | `test_job_switches.py` 通过；暂停集合不再含 strategy_ci_monthly |

5 项核对：8 个提交都不改执行目标、合规、跟踪止盈、买入门控、当前仓位。0a-2 部署时 data_lake 里还没有 lifecycle 文件，MR 信号不变。

会话分组与部署（第 7 节 J1、J2）：
- 会话一：0a-1、0a-2；会话二：0a-3、0a-4；会话三：0a-5、0a-6、0b；0a 全部部署核对后：0c
  - 11-05 调整：0b 提前单独一个会话先做；会话三改为 0a-5、0a-6。0b 不单独部署，与决策中枢视觉 2（`3fa18c1`、`3d0612a`）合并部署，或并入 0a 会话一的部署，由用户定
  - 用户定（11-05 07:48 美中）：与决策中枢视觉 2 合并部署。权威环境收尾核对 08:02 完成后，11-05 22:04:58 北京部署 `ad0989d`（含 `3fa18c1`、`3d0612a`），部署后经隧道复核通过（见实施日志）
- 每步单独提交、单独推送（每次推送都跑全量测试）；**每组结束部署一次**，部署前后经隧道各做一次 5 项核对

---

## 5. 实施会话开头

```
读 docs/SITE_SLIMMING_ROUNDS.md 的「通用约束」，然后按 docs/ROUND0_CI_EVALUATE_ONLY_PLAN.md 实施第 <0a-1> 步，只做这一步。
1. 先读方案、docs/PLAN_B_IMPLEMENTATION_LOG.md 末尾，以及本步涉及的代码
2. 核对方案里的行号和描述与现状是否一致；不一致先告诉我
3. 然后按通用约束实施、测试、做 5 项核对、写日志，最后给我推送命令
本会话不得调用任何 /ci/* 接口。
```

---

## 6. 不做 / 待办
- 不改任何现有参数值和 lifecycle 内容；不改 MR / ERP 优化器和验证算法；不改 `compare_regime` 的语义（只核实）
- 待办：V5 自检结果文件移到 `data_lake/`；容器内直接调用其他函数（导入、重设基准等）的技术记录（目前靠规则 8）；回测页本身第 2 轮处理

---

## 7. 实施细节的判断（用户 21:32 授权"以专业科学决策"）

| 编号 | 问题 | 决定 | 理由 |
|---|---|---|---|
| J1 | 会话怎么分 | 三个会话：0a-1+0a-2 / 0a-3+0a-4 / 0a-5+0a-6+0b，0c 单独。**11-05 调整（用户）**：0b 提前到 0a 之前单独做，会话三改为 0a-5+0a-6 | 组内改的是同一批文件（前两步都改 pipeline 和 strategy_params；中间两步都改 `routers/ci.py` 和请求处理），放在一起读代码只读一遍，用量最省；每步仍然单独提交，出问题能按提交回退。0b 提前的理由：0b 与 0a 没有代码依赖、文件不重叠（0a 全是后端，0a-6 已核实不改前端）；提前能更早关掉 F9（回测页"运行 CI""批准"按钮在 18000 点了能真正触发 CI，结果为 ACCEPT 就会发布） |
| J2 | 多久部署一次 | 每组结束部署一次，不是每个提交部署一次 | 每次部署都重建镜像、重启服务（会打断当时的数据抓取）。每个提交在推送前都跑全量测试，按组部署能少重启 5 次。有先例：权威收尾轮 2a、2b 也是一起部署的。风险在于组内某一步有问题时要逐个排查，但提交是分开的，可以单独回退 |
| J3 | 暂停配置是否已生效 | 不靠回忆，0a-1 开工时在审计页 A 区读一次 | 这是事实问题，不该推断；审计页读取是 GET `/api/v1/audit`，不碰 `/ci/*`，也不改服务器状态 |
| J4 | 批准接口是否保留环境开关 | **不保留**（这是对 21:28 确认内容唯一的改动） | 原方案里批准会直接改参数，开关有意义。方案 A 下批准只记录，参数生效要经仓库提交和用户推送，那一步才是真正的闸门。开关要改服务器 `.env` 并重建容器，一次批准就要重启两次（开、关），每次都是改变服务器状态的操作。保留的门槛：写入令牌、手输 run_id、必填 note、写操作日志留痕。用户想保留开关的话，0a-3 时加回即可，成本很小 |
| J5 | 头像块怎么处理 | 整块去掉，只有布局错位时才放中性文字 | 头像和"基金经理 Pro"不是信息，留占位没有意义；去掉外链也就少一个第三方请求 |
| J6 | `compare_regime` 的 REJECT | 已核实：现任也不过门槛才是 REJECT，自动写 rejected 是对的 | 见 3.3 |
| J7 | 0a-6 是否要改前端 | 不需要 | 见 3.7 |
| J8 | 11-01 09:07 的来源（F10） | 0a-1 开工读代码时，在本机跑一次只读的 `git log -p --since=2026-10-25 -- static/js/alphacore_utils.js`，确认当时没有自动带令牌的机制，结果写进日志，此后不再追查 | 不影响设计（0a-1 后所有入口都不发布，且都记来源）；但只需一条只读命令，能把这件事落成结论 |
| J9 | 0a-5 后 V5 自检恢复运行 | 接受：11-30 12:30（美中）照常运行 | 它是 V5 影子监控（12 周复查要用），不改参数；之前停掉只是因为和 CI 绑在一个任务里 |
| J10 | 批准后的参数补丁谁来提交 | **用户 11-04 22:08 规定**：会话不得自行提交；先列出参数改前 / 改后、run_id、验证结果，用户针对该 run_id 明确同意后才提交；实施日志记录用户何时同意。概括授权不算同意。此规则同时写入通用约束固定规则 9，第 0 轮之后同样适用 | 参数变更是策略行为的根本改动，必须由用户逐次确认，并且事后可查 |
