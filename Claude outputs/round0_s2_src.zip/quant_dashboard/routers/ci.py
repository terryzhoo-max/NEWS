"""
AlphaCore · 策略 CI/CD API 路由 (P1-3)
========================================
/api/v1/ci/run         POST  手动触发 CI (只评估不发布; reason 必填)
/api/v1/ci/history     GET   查看历史 CI 记录
/api/v1/ci/latest/{s}  GET   某策略最近一次 CI
/api/v1/ci/accept/{id} POST  第 0 轮 0a-1 起鉴权通过后一律 409 (0a-3 改为只记录批准 + 返回参数补丁)

第 0 轮 0a-1 (2026-11-05, docs/ROUND0_CI_EVALUATE_ONLY_PLAN.md 3.1 / 3.2): 本路由不再发布任何参数。
"""

import asyncio
from concurrent.futures import ThreadPoolExecutor
from fastapi import APIRouter, HTTPException, Query, Request
from pydantic import BaseModel, constr
from typing import Optional
from services.logger import get_logger
from services import db as ac_db

logger = get_logger("ci.api")
router = APIRouter(prefix="/api/v1/ci", tags=["CI/CD"])

_ci_executor = ThreadPoolExecutor(max_workers=1, thread_name_prefix="ci")


class CIRunRequest(BaseModel):
    strategy: str = "all"       # "all" | "mr" | "erp"
    regime: Optional[str] = None  # MR 专用: "BEAR" | "RANGE" | "BULL"
    # 第 0 轮 0a-1: 触发理由必填, 去掉首尾空格后 2–200 字; 缺失或长度不符 → 422
    reason: constr(strip_whitespace=True, min_length=2, max_length=200)


_HEADER_MAX = 200


def _api_trigger(request: Request, req: CIRunRequest) -> dict:
    """接口来源。只记请求头里的来源信息与一个认证结果标记, 不读取、不保存任何令牌值。"""
    from services import auth_middleware as _am

    def _cut(value):
        return value[:_HEADER_MAX] if value else None

    h = request.headers
    detail = {
        "path": request.url.path,
        "client_host": request.client.host if request.client else None,
        "x_forwarded_for": _cut(h.get("x-forwarded-for")),
        "user_agent": _cut(h.get("user-agent")),
        "origin": _cut(h.get("origin")),
        "referer": _cut(h.get("referer")),
        "caller": _cut(h.get("x-ac-caller")),      # 前端自带的调用方标记 (可选)
        "strategy": req.strategy,
        "regime": req.regime,
        # 能走到这里说明已过 ApiKeyMiddleware: 配了令牌 = 校验通过; 没配 = 开发模式免认证 (生产模式已被 503 拦下)
        "auth": "ok" if _am.API_SECRET_KEY else "not_required",
    }
    return {"source": "api", "detail": detail, "reason": req.reason}


# ── POST /ci/run — 手动触发 CI ──
@router.post("/run")
async def trigger_ci(req: CIRunRequest, request: Request):
    """
    手动触发 CI 管道 (只评估不发布; 在 CI 线程池执行, 请求等待结果返回)
    注意: 全量优化耗时可能 5-30 分钟
    """
    from services.strategy_pipeline import run_full_ci, run_mr_ci, run_erp_ci

    trig = _api_trigger(request, req)
    logger.info("[CI API] 手动触发: strategy=%s regime=%s reason=%s client=%s",
                req.strategy, req.regime, req.reason, trig["detail"]["client_host"])

    def _run():
        if req.strategy == "all":
            return run_full_ci(trigger=trig)
        elif req.strategy == "mr":
            return run_mr_ci(regime=req.regime, trigger=trig)
        elif req.strategy == "erp":
            return run_erp_ci(trigger=trig)
        else:
            raise ValueError(f"Unknown strategy: {req.strategy}")

    try:
        loop = asyncio.get_event_loop()
        result = await loop.run_in_executor(_ci_executor, _run)
        return {"status": "success", "data": result}
    except Exception as e:
        logger.error("[CI API] 执行异常: %s", e)
        raise HTTPException(status_code=500, detail=str(e))


# ── GET /ci/history — 查看历史 ──
@router.get("/history")
async def get_ci_history(
    strategy: Optional[str] = Query(None, description="筛选策略: mr / erp"),
    limit: int = Query(20, ge=1, le=100),
):
    """获取 CI 运行历史"""
    try:
        rows = ac_db.get_ci_history(strategy=strategy, limit=limit)
        return {"status": "success", "data": rows, "total": len(rows)}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# ── GET /ci/latest/{strategy} — 最近一次 CI ──
@router.get("/latest/{strategy}")
async def get_ci_latest(strategy: str):
    """获取某策略最近一次 CI 结果"""
    result = ac_db.get_ci_latest(strategy)
    if not result:
        return {"status": "success", "data": None, "message": f"无 {strategy} CI 记录"}
    return {"status": "success", "data": result}


# ── POST /ci/accept/{run_id} — 人工批准 ──
@router.post("/accept/{run_id}")
async def accept_ci_run(run_id: str):
    """
    第 0 轮 0a-1 (2026-11-05) 起停用: CI 只评估不发布 (方案 D1 = A)。
    鉴权仍由 ApiKeyMiddleware 在前 (无令牌照旧 401); 通过后一律 409, 不查库、不改任何参数或记录。
    0a-3 改为只记录批准并返回参数补丁; 参数经仓库提交、推送部署后生效。
    """
    logger.warning("[CI] 批准接口已停用 (第 0 轮 0a-1), 拒绝: run_id=%s", str(run_id)[:64])
    raise HTTPException(
        status_code=409,
        detail="第 0 轮起 CI 只评估不发布, 批准接口暂停 (0a-3 改为只记录批准并返回参数补丁, "
               "参数经仓库提交生效)。本次未改任何参数或记录。",
    )


# ── GET /ci/quality-gate — 质量门配置 ──
@router.get("/quality-gate")
async def get_quality_gate():
    """返回当前质量门阈值配置"""
    from services.strategy_pipeline import QUALITY_GATE
    return {"status": "success", "data": QUALITY_GATE}
