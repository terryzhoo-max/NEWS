"""AlphaCore 投资组合管理 API — V15.1 标准化响应"""
import asyncio
import traceback
import logging
from concurrent.futures import ThreadPoolExecutor
from fastapi import APIRouter, Body, UploadFile, File, Form, HTTPException

from models.schemas import TradeRequest
from models import response as R
from portfolio_engine import get_portfolio_engine
from services import db as ac_db
from services.cache_service import adaptive_fresh_ttl
from services.account_authority import IMPORT_MESSAGE, WRITE_MESSAGE, require_authoritative

router = APIRouter(prefix="/api/v1", tags=["portfolio"])
logger = logging.getLogger("alphacore.portfolio")
executor = ThreadPoolExecutor(max_workers=4)

# V26.0: 统一持仓变更后缓存失效 (import / trade / reset 共用)
_PORTFOLIO_SWR_KEYS = ("swr_portfolio_risk", "swr_corr_matrix", "swr_compliance")
# Import/Reset 是全量覆盖操作, 额外清决策层缓存
_DECISION_SWR_KEYS = ("swr_decision_hub", "swr_risk_matrix", "swr_drift_status")


async def refresh_risk_after_import(trigger: str) -> dict:
    """2026-11-02: 导入对账单 / 成交后立即重算回撤刹车与跟踪止盈状态 (合规与执行层所用)。失败不影响导入结果, 但显式返回。"""
    try:
        from services.trailing_stop_service import refresh_risk_state
        st = await asyncio.to_thread(refresh_risk_state, trigger)
        b = st.get("drawdown_brake") or {}
        return {"status": "ok", "computed_at": st.get("computed_at"), "holdings_as_of": st.get("holdings_as_of"),
                "drawdown_tier": b.get("tier"), "invested_pct": b.get("invested_pct")}
    except Exception as e:
        logger.warning("导入后风险状态重算失败: %s", e, exc_info=True)
        return {"status": "error", "error": str(e)[:200]}


def _invalidate_portfolio_caches(full: bool = False):
    """清除持仓相关 SWR 缓存。full=True 时额外清决策中枢缓存。"""
    from services.cache_service import swr_clear
    for key in _PORTFOLIO_SWR_KEYS:
        swr_clear(key)
    if full:
        for key in _DECISION_SWR_KEYS:
            swr_clear(key)
        logger.info("[Cache] 全量持仓变更: 已失效 %d 个 SWR 缓存",
                    len(_PORTFOLIO_SWR_KEYS) + len(_DECISION_SWR_KEYS))
        # 持仓结构变了, 组合波动预算 (合规规则 vol_budget 的数据源) 立即重算
        try:
            from services.cache_service import cache_manager
            from services.cache_store import get_cache_ttl
            from services.portfolio_vol import compute_from_store, summarize
            vb = summarize(compute_from_store())
            if vb:
                cache_manager.set_json("vol_budget", vb, ttl_seconds=get_cache_ttl())
            else:
                cache_manager.delete("vol_budget")
        except Exception as e:
            logger.warning("[Cache] 组合波动预算重算失败 (非致命): %s", e)


@router.get("/portfolio/vol-budget")
async def get_portfolio_vol_budget(refresh: bool = False):
    """波动率仓位预算决策视图: 上限瀑布 + 约束来源 + 结论 + 减仓草案 (只读, 不下单).

    结果按输入指纹缓存 (持仓 + 参数 + 行情文件 mtime); refresh=true 强制重算。
    """
    try:
        # 与决策中枢共用同一实现 (services.aiae_execution.current_view_and_execution)。
        # P1-c (2026-10-30): 执行层 (周频执行目标 + 非对称偏离分区), 规则见 docs/AIAE_EXECUTION_RULES.md;
        # 原日频结论 view["verdict"] 保留为对照; 执行层失败不影响决策视图。
        from services.aiae_execution import current_view_and_execution
        view, execution = await asyncio.to_thread(current_view_and_execution, refresh)
        view["execution_layer"] = execution
        return R.ok(view)
    except Exception as e:
        logger.error("vol-budget 计算失败: %s", e)
        return R.error(f"波动预算计算失败: {e}")


@router.get("/portfolio/modules")
async def get_portfolio_modules():
    """组合页模块开关 (2026-11-03 精简 P4): 前端据此隐藏面板、跳过加载。只读。"""
    from services.portfolio_modules import load_modules
    return {"status": "success", **load_modules()}


@router.get("/portfolio/valuation")
async def get_portfolio_valuation():
    try:
        engine = get_portfolio_engine()
        val = engine.get_valuation()
    except Exception as e:
        return R.error(str(e), "ERR_VALUATION")
    # 2026-11-03 组合页精简 P2: 附带全站唯一的当前仓位 (同一次估值, services/account_exposure.from_valuation);
    # 组合页只读该字段, 不再前端自算。失败 → unavailable (调用方不得用其他数字替代)。
    try:
        from services.account_exposure import from_valuation
        val["account_exposure"] = from_valuation(val)
    except Exception as e:
        logger.warning("account_exposure 计算失败: %s", e)
        val["account_exposure"] = {"status": "unavailable", "pct": None, "reason": str(e)[:200]}
    return R.ok(val)

@router.get("/portfolio/risk")
async def get_portfolio_risk():
    """V25.0: SWR 缓存 (5min/30min), 交易后自动失效"""
    from services.cache_service import stale_while_revalidate

    def _compute():
        engine = get_portfolio_engine()
        return R.ok(engine.calculate_risk_metrics())

    return await asyncio.get_running_loop().run_in_executor(
        executor, lambda: stale_while_revalidate("swr_portfolio_risk", _compute, fresh_ttl=adaptive_fresh_ttl(300, 'decision'), stale_ttl=1800))

@router.get("/portfolio/history")
async def get_portfolio_history():
    try:
        engine = get_portfolio_engine()
        return R.ok(engine.get_trade_history(30))
    except Exception as e:
        return R.error(str(e), "ERR_HISTORY")

@router.get("/portfolio/nav")
async def get_portfolio_nav():
    try:
        engine = get_portfolio_engine()
        return R.ok(engine.get_nav_history(120))
    except Exception as e:
        return R.error(str(e), "ERR_NAV")

@router.get("/portfolio/returns")
async def get_portfolio_returns(start: str = None, end: str = None):
    """阶段2B: 整账户实际收益 (TWR/MWR) + 四种收益口径目录。

    整账户收益只用券商总资产快照与现金台账入出金; 覆盖不足时返回 insufficient_*, 不估算。
    """
    try:
        from services import account_ledger
        from services.return_basis import BASES, account_returns
        ledger = account_ledger.load()
        catalog = {
            "account_total_actual": {**BASES["account_total_actual"], "endpoint": "/api/v1/portfolio/returns"},
            "risk_asset_twr": {**BASES["risk_asset_twr"], "endpoint": "决策页 组合回撤 (drawdown.realized)"},
            "current_holdings_simulation": {**BASES["current_holdings_simulation"],
                                            "endpoint": "/api/v1/portfolio/nav; drawdown.proforma"},
            "strategy_backtest": {**BASES["strategy_backtest"], "endpoint": "/api/v1/aiae/portfolio_backtest"},
        }
        return R.ok({"account": account_returns(ledger, start, end), "bases": catalog})
    except Exception as e:
        return R.error(str(e), "ERR_RETURNS")

def _compute_lookthrough(top: int = 30) -> dict:
    """当前持仓穿透 (供 /lookthrough 与 /stress-lookthrough 共用)。"""
    import os
    import pandas as pd
    from services.industry_constituents import STOCK_LIST_PATH, get_constituents_for_etf
    from services.lookthrough import build_lookthrough
    engine = get_portfolio_engine()
    val = engine.get_valuation()
    stock_info = {}
    if os.path.exists(STOCK_LIST_PATH):
        try:
            df = pd.read_parquet(STOCK_LIST_PATH)
            cols = [c for c in ("ts_code", "name", "industry") if c in df.columns]
            if "ts_code" in cols:
                stock_info = {str(r["ts_code"]): {k: r.get(k) for k in cols if k != "ts_code"}
                              for r in df[cols].to_dict("records")}
        except Exception as e:
            logger.warning("stock_list 读取失败, 行业记为未知: %s", e)
    return build_lookthrough(val.get("positions") or [], cash=val.get("cash"),
                             constituent_lookup=get_constituents_for_etf, stock_info=stock_info, top=top)


@router.get("/portfolio/lookthrough")
async def get_portfolio_lookthrough():
    """阶段3A: 实际持仓穿透 — 公司/行业暴露, 未知部分单列 (不当作零风险)。

    ETF 部分为跟踪指数权重近似或基金报告持仓 (逐 ETF 标注口径与日期)。
    """
    try:
        lt = _compute_lookthrough()
    except Exception as e:
        return R.error(str(e), "ERR_LOOKTHROUGH")
    # 2026-11-03 组合页精简 P3: 行业 → 合规主题 (同一 INDUSTRY_THEME_MAP) 的加总, 供页面说明"合规主题 = 行业 a + b + …";
    # 判定仍只来自合规引擎, 本字段不设阈值。
    try:
        from services.concentration import industry_theme_breakdown
        lt["theme_view"] = {"mapping": "services.concentration.INDUSTRY_THEME_MAP",
                            "themes": industry_theme_breakdown(lt.get("industries") or [])}
    except Exception as e:
        logger.warning("theme_view 计算失败: %s", e)
        lt["theme_view"] = None
    return R.ok(lt)


@router.get("/portfolio/stress-lookthrough")
async def get_portfolio_stress_lookthrough():
    """阶段3B-3: 按穿透主题暴露的压力情景 (条件估计, 非预测; 参数显式且可配置)。"""
    try:
        from services.concentration import INDUSTRY_THEME_MAP
        from services.stress_lookthrough import run
        lt = _compute_lookthrough(top=10 ** 6)
        return R.ok(run(lt, lambda ind: INDUSTRY_THEME_MAP.get(ind, ind)))
    except Exception as e:
        return R.error(str(e), "ERR_STRESS_LOOKTHROUGH")

@router.get("/portfolio/snapshots")
async def get_portfolio_snapshots():
    """获取组合每日净值快照 (SQLite, Batch 11)"""
    try:
        data = ac_db.get_portfolio_snapshots(90)
        return R.ok(data, f"{len(data)} snapshots")
    except Exception as e:
        return R.error(str(e), "ERR_SNAPSHOTS")

@router.post("/portfolio/trade")
async def execute_trade(req: TradeRequest):
    require_authoritative(IMPORT_MESSAGE)   # 2026-11-04: 非权威环境 (本机) 关闭
    # This mutates the portfolio ledger; research-mode permissions cannot be
    # bypassed by calling the old endpoint directly or by selling instead.
    from services.decision_policy import get_mode
    if get_mode() != "legacy":
        raise HTTPException(403, detail="个人分析模式禁止通过交易接口改写持仓；请使用成交登记或持仓导入")
    from dashboard_modules.decision_engine import get_hub_data
    decision = get_hub_data()  # uncached, server-owned account/risk context
    if (decision.get("permissions") or {}).get("create_order") is not True:
        raise HTTPException(403, detail="当前决策未获订单权限；禁止直接改写账户持仓")
    try:
        if req.price <= 0:
            return R.error("价格必须大于 0", "ERR_INVALID_PRICE")
        if req.amount <= 0:
            return R.error("数量必须大于 0", "ERR_INVALID_AMOUNT")
        if req.action not in ("buy", "sell"):
            return R.error("操作类型必须为 buy 或 sell", "ERR_INVALID_ACTION")
        if not req.ts_code or len(req.ts_code.strip()) < 3:
            return R.error("请输入有效的证券代码", "ERR_INVALID_CODE")

        engine = get_portfolio_engine()
        if req.action == "buy":
            success, msg = engine.add_position(req.ts_code.strip(), req.amount, req.price, req.name.strip())
        else:
            success, msg = engine.reduce_position(req.ts_code.strip(), req.amount, req.price)

        if success:
            # V26.0: 交易成功后，失效持仓相关 SWR 缓存
            _invalidate_portfolio_caches(full=False)
            return R.ok(message=msg)
        else:
            return R.error(msg, "ERR_TRADE_REJECTED")
    except Exception as e:
        return R.error(str(e), "ERR_TRADE")

@router.post("/portfolio/import")
async def import_portfolio(file: UploadFile = File(...), as_of: str | None = Form(None),
                           valuation_time: str | None = Form(None)):
    # 真实数据验收 (2026-10-29): as_of = 券商账单实际日期 (未传则取文件名中的 YYYYMMDD; 都没有则不记历史快照);
    # valuation_time = 账单估值时点 (如 15:10), 未传为未知
    """接收券商导出的 资金股份查询.txt，解析并覆盖当前持仓"""
    require_authoritative(IMPORT_MESSAGE)   # 2026-11-04: 非权威环境 (本机) 关闭
    try:
        # P1-6: 限制上传文件大小 (1MB), 防止内存耗尽
        MAX_UPLOAD_SIZE = 1 * 1024 * 1024  # 1MB
        content = await file.read()
        if len(content) > MAX_UPLOAD_SIZE:
            return R.error(
                f"文件过大 ({len(content) / 1024:.0f}KB > {MAX_UPLOAD_SIZE // 1024}KB 限制)",
                "ERR_FILE_TOO_LARGE",
            )

        text = None
        for enc in ['gbk', 'gb18030', 'utf-8']:
            try:
                text = content.decode(enc)
                break
            except (UnicodeDecodeError, LookupError):
                continue
        if text is None:
            text = content.decode('gbk', errors='replace')

        # 2026-11-04: 估值时点 HH:MM (收盘后导出填 15:00, 盘中导出填实际时间); 未填 = 未知 (门控按持仓过时处理)
        if valuation_time is not None and str(valuation_time).strip():
            from services.account_exposure import parse_valuation_time
            vt = parse_valuation_time(valuation_time)
            if vt is None:
                return R.error("估值时点格式应为 HH:MM（如 15:00）", "ERR_VALUATION_TIME")
            valuation_time = vt.strftime("%H:%M")
        else:
            valuation_time = None

        engine = get_portfolio_engine()
        result = engine.import_from_txt(text, as_of=as_of, valuation_time=valuation_time,
                                        source_name=file.filename or "")
        if result["success"]:
            # 2026-11-02: 先按新持仓重算回撤刹车 / 跟踪止盈状态, 再失效持仓+决策缓存 (V26.0)
            result["risk_state"] = await refresh_risk_after_import("import_statement")
            _invalidate_portfolio_caches(full=True)
            return R.ok(result)
        else:
            return R.error("导入解析失败", "ERR_IMPORT", data=result)
    except Exception as e:
        logger.debug("Traceback", exc_info=True)
        return R.error(str(e), "ERR_IMPORT")

# 2026-11-03 组合页精简 P0 (docs/PORTFOLIO_SLIMMING_PLAN.md): 清零默认拒绝。
# 放行条件: 环境变量 ALPHACORE_ALLOW_PORTFOLIO_RESET=1, 且请求体 confirm_total_asset 与当前估值总资产相差 ≤ ¥1;
# 执行前持仓文件备份到 data_lake/archive/ (备份失败不清零)。
RESET_ENV_FLAG = "ALPHACORE_ALLOW_PORTFOLIO_RESET"
RESET_CONFIRM_TOLERANCE = 1.0


def _reset_allowed() -> bool:
    import os
    return os.environ.get(RESET_ENV_FLAG, "").strip() == "1"


@router.post("/portfolio/reset")
async def reset_portfolio(payload: dict | None = Body(None)):
    """清零组合: 清除所有持仓和现金 (默认拒绝; 见上方放行条件)"""
    require_authoritative(WRITE_MESSAGE)   # 2026-11-04: 非权威环境 (本机) 关闭
    if not _reset_allowed():
        raise HTTPException(403, detail=f"清零已停用: 需在服务端设置环境变量 {RESET_ENV_FLAG}=1 后重启服务才可使用")
    raw = (payload or {}).get("confirm_total_asset")
    try:
        confirm = float(str(raw).replace(",", "").replace("¥", "").strip())
    except (TypeError, ValueError):
        raise HTTPException(422, detail="请输入当前总资产 (confirm_total_asset) 作为确认")
    try:
        engine = get_portfolio_engine()
        total = float(engine.get_valuation().get("total_asset") or 0.0)
    except Exception as e:
        raise HTTPException(503, detail=f"无法读取当前总资产, 不执行清零: {str(e)[:200]}")
    if abs(confirm - total) > RESET_CONFIRM_TOLERANCE:
        raise HTTPException(409, detail=f"输入的总资产与当前总资产不一致 (当前 ¥{total:,.2f}), 未清零")
    try:
        result = engine.reset_portfolio()   # 先备份到 archive/, 备份失败抛异常且不清零
    except Exception as e:
        logger.error("清零失败 (未执行或备份失败): %s", e)
        return R.error(f"清零未执行: {str(e)[:200]}", "ERR_RESET")
    logger.warning("组合已清零: %s 只持仓, 备份 %s", result.get("cleared_positions"), result.get("backup_path"))
    # V26.0: 清零后失效所有缓存
    _invalidate_portfolio_caches(full=True)
    return R.ok(result)

@router.post("/portfolio/sync")
async def sync_portfolio_prices():
    """同步持仓行情: 从 Tushare 拉取最新日线数据到 data_lake"""
    try:
        engine = get_portfolio_engine()
        loop = asyncio.get_running_loop()
        result = await loop.run_in_executor(executor, engine.sync_prices)
        return R.ok(result)
    except Exception as e:
        logger.error(f"[Portfolio Sync] Error: {traceback.format_exc()}")
        return R.error(str(e), "ERR_SYNC")


@router.get("/portfolio/brinson")
async def get_brinson_attribution(days: int = 20):
    """V24.0: Brinson-Fachler 收益归因 (配置效应 / 选股效应 / 交互效应)"""
    from services.cache_service import stale_while_revalidate

    # 参数校验
    days = max(5, min(120, days))

    def _compute():
        from engines.brinson_engine import compute_brinson_attribution
        result = compute_brinson_attribution(lookback=days)
        return R.ok(result) if result.get("status") == "success" else R.error(
            result.get("error", "归因计算失败"), "ERR_BRINSON", data=result)

    return await asyncio.get_running_loop().run_in_executor(
        executor, lambda: stale_while_revalidate(
            f"swr_brinson_{days}", _compute, fresh_ttl=adaptive_fresh_ttl(3600, 'strategy'), stale_ttl=14400))


@router.get("/portfolio/factor-attribution")
async def get_factor_attribution(days: int = 60):
    """V24.1: 三因子风险归因 (Market/SMB/HML) + 个股横截面画像"""
    from services.cache_service import stale_while_revalidate

    days = max(20, min(252, days))

    def _compute():
        from engines.factor_attribution_engine import compute_factor_attribution
        result = compute_factor_attribution(lookback=days)
        return R.ok(result) if result.get("status") == "success" else R.error(
            result.get("error", "因子归因失败"), "ERR_FACTOR_ATTR", data=result)

    return await asyncio.get_running_loop().run_in_executor(
        executor, lambda: stale_while_revalidate(
            f"swr_factor_attr_{days}", _compute, fresh_ttl=adaptive_fresh_ttl(7200, 'slow'), stale_ttl=28800))


@router.get("/portfolio/intraday-pnl")
async def get_intraday_pnl():
    """V27.0 P1-A: 盘中实时P&L — 今日涨跌归因 (每只持仓 + 行业聚合)"""
    from services.cache_service import stale_while_revalidate

    def _compute():
        engine = get_portfolio_engine()
        result = engine.get_intraday_pnl()
        return R.ok(result)

    return await asyncio.get_running_loop().run_in_executor(
        executor, lambda: stale_while_revalidate(
            "swr_intraday_pnl", _compute, fresh_ttl=adaptive_fresh_ttl(60, 'realtime'), stale_ttl=300))


@router.get("/portfolio/rebalance")
async def get_rebalance_orders():
    """已停用 (2026-11-02, docs/ACCOUNT_EXPOSURE_AND_MR_LIMITS_PLAN.md 1.3)。

    原接口用券商表头「资产」作分母、AIAE 矩阵上限作目标, 与"执行目标是全站唯一仓位数字"冲突;
    目标逻辑不改 (engines/rebalance_engine.py 保留), 11-30 隐藏模块复查时决定是否删除。
    """
    return R.ok({"status": "disabled", "message": "已停用：调仓指令接口已停用，仓位以 AIAE 执行目标为准"},
                "已停用")


@router.get("/portfolio/stress-test")
async def get_stress_test():
    """V5.0: 组合压力测试 — R1~R5 全场景调仓模拟 + 流动性评估"""
    try:
        from engines.rebalance_engine import run_stress_test
        result = run_stress_test()
        if result["status"] == "success":
            return R.ok(result)
        else:
            return R.error(result.get("error", "压力测试异常"), "ERR_STRESS")
    except Exception as e:
        return R.error(str(e), "ERR_STRESS")


